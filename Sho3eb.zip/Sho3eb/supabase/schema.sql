-- =====================================================================
--  Sho3eb Chat — مخطط قاعدة البيانات (Supabase)
--  انسخ هذا الملف كاملاً والصقه في: Supabase → SQL Editor → New query → Run
-- =====================================================================

-- ---------- الملفات الشخصية ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique,
  name text not null default '',
  avatar text not null default '',
  about text not null default '',
  pubkey text not null default '',
  lang text not null default 'ar',
  last_seen timestamptz not null default now(),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
drop policy if exists "profiles read" on public.profiles;
create policy "profiles read" on public.profiles for select to authenticated using (true);
drop policy if exists "profiles insert own" on public.profiles;
create policy "profiles insert own" on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists "profiles update own" on public.profiles;
create policy "profiles update own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- ---------- الرسائل (المحتوى مشفر من طرف لطرف) ----------
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender uuid not null references auth.users(id) on delete cascade,
  recipient uuid not null references auth.users(id) on delete cascade,
  body text,
  reply_to uuid,
  group_id text,
  reactions jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted boolean not null default false,
  delivered_at timestamptz,
  read_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.messages add column if not exists updated_at timestamptz not null default now();
create index if not exists messages_recipient_idx on public.messages (recipient, created_at);
create index if not exists messages_sender_idx on public.messages (sender, created_at);
create index if not exists messages_updated_idx on public.messages (updated_at);
alter table public.messages enable row level security;
drop policy if exists "messages read own" on public.messages;
create policy "messages read own" on public.messages for select to authenticated using (auth.uid() = sender or auth.uid() = recipient);
drop policy if exists "messages send" on public.messages;
create policy "messages send" on public.messages for insert to authenticated with check (auth.uid() = sender);
drop policy if exists "messages update" on public.messages;
create policy "messages update" on public.messages for update to authenticated using (auth.uid() = sender or auth.uid() = recipient);

-- المستقبل يغيّر فقط: التسليم والقراءة والتفاعلات؛ المرسل يعدّل المحتوى أو يحذفه
create or replace function public.messages_guard() returns trigger language plpgsql as $$
begin
  if new.sender <> old.sender or new.recipient <> old.recipient or new.created_at <> old.created_at then
    raise exception 'not allowed';
  end if;
  if auth.uid() = old.recipient and auth.uid() <> old.sender then
    if new.body is distinct from old.body or new.deleted <> old.deleted or new.edited_at is distinct from old.edited_at then
      raise exception 'not allowed';
    end if;
  end if;
  if auth.uid() = old.sender and auth.uid() <> old.recipient then
    if new.read_at is distinct from old.read_at or new.delivered_at is distinct from old.delivered_at then
      raise exception 'not allowed';
    end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists messages_guard on public.messages;
create trigger messages_guard before update on public.messages for each row execute function public.messages_guard();

-- ---------- إشارات المكالمات ----------
create table if not exists public.signals (
  id bigserial primary key,
  sender uuid not null references auth.users(id) on delete cascade,
  recipient uuid not null references auth.users(id) on delete cascade,
  call_id text not null,
  type text not null,
  payload text,
  created_at timestamptz not null default now()
);
create index if not exists signals_recipient_idx on public.signals (recipient, id);
alter table public.signals enable row level security;
drop policy if exists "signals read" on public.signals;
create policy "signals read" on public.signals for select to authenticated using (auth.uid() = recipient or auth.uid() = sender);
drop policy if exists "signals send" on public.signals;
create policy "signals send" on public.signals for insert to authenticated with check (auth.uid() = sender);
drop policy if exists "signals delete" on public.signals;
create policy "signals delete" on public.signals for delete to authenticated using (auth.uid() = recipient or auth.uid() = sender);

-- ---------- البث اللحظي ----------
do $$ begin
  begin alter publication supabase_realtime add table public.messages; exception when others then null; end;
  begin alter publication supabase_realtime add table public.signals; exception when others then null; end;
end $$;

-- ---------- تخزين الملفات (مشفرة) ----------
insert into storage.buckets (id, name, public) values ('chat', 'chat', false) on conflict (id) do nothing;
drop policy if exists "chat upload own" on storage.objects;
create policy "chat upload own" on storage.objects for insert to authenticated with check (bucket_id = 'chat' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "chat read" on storage.objects;
create policy "chat read" on storage.objects for select to authenticated using (bucket_id = 'chat');
drop policy if exists "chat update own" on storage.objects;
create policy "chat update own" on storage.objects for update to authenticated using (bucket_id = 'chat' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "chat delete own" on storage.objects;
create policy "chat delete own" on storage.objects for delete to authenticated using (bucket_id = 'chat' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------- تنظيف الإشارات القديمة ----------
create or replace function public.cleanup_signals() returns void language sql security definer as $$
  delete from public.signals where created_at < now() - interval '1 hour';
$$;

-- صلاحيات الوصول (مطلوبة في مشاريع Supabase الجديدة)
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.profiles to authenticated;
grant select, insert, update, delete on public.messages to authenticated;
grant select, insert, update, delete on public.signals to authenticated;
grant execute on function public.cleanup_signals() to authenticated;

-- نقل رقم الهاتف تلقائياً إلى أحدث حساب (عند إعادة تثبيت التطبيق)
create or replace function public.claim_phone(p text) returns void
language sql security definer set search_path = public as $$
  update public.profiles set phone = null where phone = p and id <> auth.uid();
$$;
grant execute on function public.claim_phone(text) to authenticated;

create or replace function public.release_phone() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.phone is not null then
    update public.profiles set phone = null where phone = new.phone and id <> new.id;
  end if;
  return new;
end $$;
drop trigger if exists profiles_release_phone on public.profiles;
create trigger profiles_release_phone before insert or update of phone on public.profiles
for each row execute function public.release_phone();
