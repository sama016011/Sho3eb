# إعداد خادم «التواصل» (Supabase مجاني)

1. أنشئ حساباً مجانياً على https://supabase.com ثم **New project** (اختر أقرب منطقة، واحفظ كلمة مرور قاعدة البيانات).
2. افتح **SQL Editor → New query**، والصق محتوى الملف `schema.sql` كاملاً، ثم **Run**.
3. افتح **Authentication → Sign In / Providers** وفعّل **Allow anonymous sign-ins**.
4. افتح **Project Settings → API** وانسخ:
   - **Project URL** (مثل `https://abcd.supabase.co`)
   - **anon public key**
5. في التطبيق: التواصل ← ⚙️ إعداد الخادم ← الصق الرابط والمفتاح ← حفظ.
   - أو ضع ملفاً باسم `supabase.properties` في جذر المستودع يحتوي:
     ```
     SUPABASE_URL=https://abcd.supabase.co
     SUPABASE_ANON_KEY=eyJ...
     ```
     فيُضمَّن تلقائياً في كل نسخة يبنيها GitHub (ونُسخ المشاركة تحمل الإعداد تلقائياً).

**الخصوصية:** الرسائل والملفات تُشفَّر على الهاتف قبل الإرسال (ECDH P-256 + AES-256-GCM)، فلا يقرؤها أحد غير المرسل والمستقبل، حتى صاحب الخادم.
