package com.sho3eb.app.core

import com.sho3eb.app.Sho3ebApp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/**
 * القنوات المجانية المتاحة للعامة (قوائم iptv-org المفتوحة) + قوائم M3U الخاصة بالمستخدم.
 * التشغيل يتم داخل المشغل الداخلي للتطبيق.
 */
object FreeTv {
    data class Ch(val name: String, val url: String, val group: String, val logo: String, val country: String = "")
    data class Source(val key: String, val ar: String, val en: String, val emoji: String, val url: String) { val label get() = tr(ar, en) }

    private const val IPTV = "https://iptv-org.github.io/iptv/"
    val sources = listOf(
        Source("ara", "كل القنوات العربية", "All Arabic", "🌍", IPTV + "languages/ara.m3u"),
        Source("eg", "مصر", "Egypt", "🇪🇬", IPTV + "countries/eg.m3u"),
        Source("sa", "السعودية", "Saudi Arabia", "🇸🇦", IPTV + "countries/sa.m3u"),
        Source("ae", "الإمارات", "UAE", "🇦🇪", IPTV + "countries/ae.m3u"),
        Source("kw", "الكويت", "Kuwait", "🇰🇼", IPTV + "countries/kw.m3u"),
        Source("qa", "قطر", "Qatar", "🇶🇦", IPTV + "countries/qa.m3u"),
        Source("bh", "البحرين", "Bahrain", "🇧🇭", IPTV + "countries/bh.m3u"),
        Source("om", "عُمان", "Oman", "🇴🇲", IPTV + "countries/om.m3u"),
        Source("jo", "الأردن", "Jordan", "🇯🇴", IPTV + "countries/jo.m3u"),
        Source("iq", "العراق", "Iraq", "🇮🇶", IPTV + "countries/iq.m3u"),
        Source("lb", "لبنان", "Lebanon", "🇱🇧", IPTV + "countries/lb.m3u"),
        Source("ps", "فلسطين", "Palestine", "🇵🇸", IPTV + "countries/ps.m3u"),
        Source("ma", "المغرب", "Morocco", "🇲🇦", IPTV + "countries/ma.m3u"),
        Source("dz", "الجزائر", "Algeria", "🇩🇿", IPTV + "countries/dz.m3u"),
        Source("tn", "تونس", "Tunisia", "🇹🇳", IPTV + "countries/tn.m3u"),
        Source("ly", "ليبيا", "Libya", "🇱🇾", IPTV + "countries/ly.m3u"),
        Source("sd", "السودان", "Sudan", "🇸🇩", IPTV + "countries/sd.m3u"),
        Source("ye", "اليمن", "Yemen", "🇾🇪", IPTV + "countries/ye.m3u"),
        Source("sy", "سوريا", "Syria", "🇸🇾", IPTV + "countries/sy.m3u"),
        Source("sports", "رياضة (عالمية)", "Sports (world)", "⚽", IPTV + "categories/sports.m3u"),
        Source("kids", "أطفال (عالمية)", "Kids (world)", "🧸", IPTV + "categories/kids.m3u"),
        Source("animation", "رسوم متحركة", "Animation", "🎨", IPTV + "categories/animation.m3u"),
        Source("news", "أخبار (عالمية)", "News (world)", "📰", IPTV + "categories/news.m3u"),
        Source("religious", "دينية", "Religious", "🕋", IPTV + "categories/religious.m3u"),
        Source("movies", "أفلام", "Movies", "🎬", IPTV + "categories/movies.m3u"),
        Source("series", "مسلسلات", "Series", "📺", IPTV + "categories/series.m3u"),
        Source("music", "موسيقى", "Music", "🎵", IPTV + "categories/music.m3u"),
        Source("documentary", "وثائقية", "Documentary", "🌍", IPTV + "categories/documentary.m3u")
    )

    private fun dir() = File(Sho3ebApp.instance.filesDir, "tv").apply { mkdirs() }

    /** تحميل نص من رابط مع متابعة التحويلات وفك الضغط */
    fun fetch(url: String): String? {
        var u = url.trim()
        repeat(6) {
            val c = runCatching { URL(u).openConnection() as HttpURLConnection }.getOrNull() ?: return null
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 15000; c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
                c.setRequestProperty("Accept", "*/*")
                c.setRequestProperty("Accept-Encoding", "gzip")
                val code = c.responseCode
                if (code in 300..399) { u = URL(URL(u), c.getHeaderField("Location") ?: return null).toString(); return@repeat }
                if (code !in 200..299) return null
                val raw = c.inputStream
                val ins = if (c.contentEncoding?.contains("gzip", true) == true) GZIPInputStream(raw) else raw
                return ins.use { s -> String(s.readBytes().let { if (it.size > 40_000_000) it.copyOf(40_000_000) else it }, Charsets.UTF_8) }
            } catch (e: Throwable) { return null } finally { c.disconnect() }
        }
        return null
    }

    /** تحليل M3U / M3U8 (يدعم سمات tvg و group-title و EXTGRP) */
    fun parse(text: String, country: String = ""): List<Ch> {
        val out = mutableListOf<Ch>()
        var name = ""; var group = ""; var logo = ""
        val attr = { l: String, k: String -> Regex("$k=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(l)?.groupValues?.get(1) ?: "" }
        text.lineSequence().map { it.trim().removePrefix("﻿") }.forEach { l ->
            when {
                l.startsWith("#EXTINF", true) -> {
                    val afterAttrs = l.replace(Regex("[a-zA-Z-]+=\"[^\"]*\""), "")
                    name = afterAttrs.substringAfter(",", "").trim().ifBlank { attr(l, "tvg-name") }
                    group = attr(l, "group-title"); logo = attr(l, "tvg-logo")
                }
                l.startsWith("#EXTGRP:", true) -> group = l.substringAfter(":").trim()
                l.isNotBlank() && !l.startsWith("#") && (l.contains("://")) -> {
                    out += Ch(name.ifBlank { l.substringAfterLast('/').take(40) }, l, group.ifBlank { tr("عام", "General") }, logo, country); name = ""; group = ""; logo = ""
                }
            }
        }
        return out
    }

    private fun toJson(l: List<Ch>) = JSONArray(l.map { JSONObject().put("n", it.name).put("u", it.url).put("g", it.group).put("l", it.logo).put("c", it.country) }).toString()
    private fun fromJson(s: String): List<Ch> = runCatching { JSONArray(s).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> Ch(o.optString("n"), o.optString("u"), o.optString("g"), o.optString("l"), o.optString("c")) } } } }.getOrDefault(emptyList())

    /** قائمة مصدر (مخزنة 12 ساعة) */
    fun load(src: Source, force: Boolean = false): List<Ch> = load0(src, force).also { remember(it) }
    private fun load0(src: Source, force: Boolean): List<Ch> {
        val f = File(dir(), "src_${src.key}.json")
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < 12 * 3600_000L) return fromJson(f.readText())
        val t = fetch(src.url)
        if (t != null) {
            val l = parse(t, src.key).distinctBy { it.url }
            if (l.isNotEmpty()) { f.writeText(toJson(l)); return l }
        }
        return if (f.exists()) fromJson(f.readText()) else emptyList()
    }

    // ---------- بدائل القناة: إن توقف رابط أو كان محجوباً يُجرَّب رابط آخر لنفس القناة ----------
    private val pool = java.util.concurrent.ConcurrentHashMap<String, MutableSet<Ch>>()
    fun baseName(n: String) = n.replace(Regex("\\((.*?)\\)|\\[(.*?)]"), " ").replace(Regex("(?i)\\b(hd|fhd|sd|uhd|4k|\\d{3,4}p)\\b"), " ").lowercase().replace(Regex("[^a-z0-9\\u0600-\\u06ff]+"), "")
    fun isGeoBlocked(c: Ch) = c.name.contains("Geo-blocked", true) || c.name.contains("geoblocked", true)
    fun isNot247(c: Ch) = c.name.contains("Not 24/7", true)
    private fun remember(l: List<Ch>) { l.forEach { c -> pool.getOrPut(baseName(c.name)) { java.util.Collections.synchronizedSet(LinkedHashSet()) }.add(c) } }
    /** القناة نفسها أولاً ثم بدائلها (غير المحجوبة أولاً) */
    fun alternatives(c: Ch): List<Ch> {
        runCatching { remember(mine) }
        val alts = pool[baseName(c.name)]?.toList().orEmpty().filter { it.url != c.url }
        return listOf(c) + alts.sortedBy { (if (isGeoBlocked(it)) 2 else 0) + (if (isNot247(it)) 1 else 0) }
    }
    fun cachedOnly(key: String): List<Ch> = File(dir(), "src_$key.json").let { if (it.exists()) fromJson(it.readText()) else emptyList() }

    // ---------- قنوات المستخدم (M3U) ----------
    private fun mineFile() = File(dir(), "mine.json")
    var mine: List<Ch>
        get() = if (mineFile().exists()) fromJson(mineFile().readText()) else migrateOld()
        set(v) = mineFile().writeText(toJson(v))
    private fun migrateOld(): List<Ch> {
        val old = runCatching { JSONArray(Extras.s("m3u_list", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> Ch(o.getString("n"), o.getString("u"), o.optString("g"), o.optString("l")) } } } }.getOrDefault(emptyList())
        if (old.isNotEmpty()) { mineFile().writeText(toJson(old)); Extras.ps("m3u_list", "[]") }
        return old
    }
    /** قوائم M3U محفوظة بروابطها لتحديثها */
    var playlistUrls: List<String>
        get() = Extras.s("m3u_urls", "").split("\n").filter { it.isNotBlank() }
        set(v) = Extras.ps("m3u_urls", v.distinct().joinToString("\n"))

    /** استيراد قائمة من رابط؛ يعيد عدد القنوات أو رسالة خطأ */
    fun importUrl(url: String): Pair<Int, String?> {
        val u = url.trim()
        if (!u.startsWith("http")) return 0 to tr("الرابط يجب أن يبدأ بـ http أو https", "The link must start with http or https")
        val low = u.lowercase().substringBefore('?')
        // رابط بث مباشر لقناة واحدة
        if (low.endsWith(".m3u8") && !low.contains("playlist") || low.endsWith(".mpd") || low.endsWith(".ts")) {
            val t = fetch(u)
            if (t == null || !t.contains("#EXTINF") || t.contains("#EXT-X-STREAM-INF") || t.contains("#EXT-X-TARGETDURATION")) {
                mine = (mine + Ch(u.substringAfterLast('/').substringBefore('?'), u, tr("روابط مباشرة", "Direct links"), "")).distinctBy { it.url }
                return 1 to null
            }
        }
        val t = fetch(u) ?: return 0 to tr("تعذر تحميل الرابط (تحقق من الإنترنت أو صلاحية الاشتراك)", "Couldn't load the link (check internet or subscription)")
        if (t.contains("#EXT-X-STREAM-INF") || t.contains("#EXT-X-TARGETDURATION")) {
            mine = (mine + Ch(u.substringAfterLast('/').substringBefore('?'), u, tr("روابط مباشرة", "Direct links"), "")).distinctBy { it.url }
            return 1 to null
        }
        val l = parse(t)
        if (l.isEmpty()) return 0 to tr("الملف لا يحتوي على قنوات بصيغة M3U", "No M3U channels found in the file")
        mine = (mine + l).distinctBy { it.url }
        playlistUrls = playlistUrls + u
        return l.size to null
    }

    fun importText(text: String): Int {
        val l = parse(text)
        if (l.isNotEmpty()) mine = (mine + l).distinctBy { it.url }
        return l.size
    }

    var favs: Set<String>
        get() = Extras.s("tv_favs", "").split("\n").filter { it.isNotBlank() }.toSet()
        set(v) = Extras.ps("tv_favs", v.joinToString("\n"))

    // ---------- البحث عن قناة بالاسم ----------
    private fun norm(s: String) = s.lowercase().replace(Regex("\\((.*?)\\)|\\[(.*?)]"), " ").replace("hd", " ").replace("fhd", " ").replace("4k", " ")
        .replace(Regex("[^a-z0-9\\u0600-\\u06FF]+"), " ").trim()

    /** أفضل رابط مطابق لاسم قناة من القوائم المحملة وقوائم المستخدم */
    // ---------- مصدر خاص بصاحب البرنامج (النسخة الأصلية فقط، لا يُصدَّر) ----------
    private fun ownFile() = File(dir(), "own_private.json")
    var ownChannels: List<Ch>
        get() = if (Edition.isShared) emptyList() else if (ownFile().exists()) fromJson(ownFile().readText()) else emptyList()
        set(v) { if (!Edition.isShared) ownFile().writeText(toJson(v)) }
    var ownUrl: String get() = if (Edition.isShared) "" else Extras.s("own_src_url", ""); set(v) = Extras.ps("own_src_url", v.trim())
    /** تحميل/تحديث المصدر الخاص (رابط M3U من اشتراكك) */
    fun loadOwn(url: String = ownUrl): Pair<Int, String?> {
        if (Edition.isShared) return 0 to null
        val u = url.trim(); if (!u.startsWith("http")) return 0 to tr("الرابط يجب أن يبدأ بـ http", "Link must start with http")
        val t = fetch(u) ?: return 0 to tr("تعذر تحميل الرابط", "Couldn't load the link")
        val l = if (t.contains("#EXTINF")) parse(t, "own").distinctBy { it.url } else listOf(Ch("ON Time Sports 1", u, "own", ""))
        if (l.isEmpty()) return 0 to tr("لا توجد قنوات في الرابط", "No channels in the link")
        ownUrl = u; ownChannels = l
        return l.size to null
    }

    fun find(keys: List<String>, extraLoad: Boolean = true): Ch? {
        val pool = ownChannels + mine + listOf("ara", "eg", "sports", "sa", "ae", "qa").flatMap { k -> cachedOnly(k).ifEmpty { if (extraLoad && k in setOf("ara", "sports")) sources.firstOrNull { it.key == k }?.let { load(it) } ?: emptyList() else emptyList() } }
        for (k in keys) {
            val nk = norm(k)
            if (nk.isBlank()) continue
            pool.firstOrNull { norm(it.name) == nk }?.let { return it }
            // مطابقة دقيقة: «ON Time Sports» لا تطابق «ON Time Sports 2»، والرقم يجب أن يطابق
            fun ok(n: String, i: Int): Boolean { val rest = n.substring(i + nk.length).trimStart(); return rest.isEmpty() || !rest[0].isDigit() }
            pool.firstOrNull { val n = norm(it.name); n.startsWith(nk) && ok(n, 0) }?.let { return it }
            if (nk.length > 5) pool.firstOrNull { val n = norm(it.name); val i = n.indexOf(nk); i >= 0 && ok(n, i) && (i == 0 || n[i - 1] == ' ') }?.let { return it }
        }
        return null
    }
}
