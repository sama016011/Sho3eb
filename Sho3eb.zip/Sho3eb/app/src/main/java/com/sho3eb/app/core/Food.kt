package com.sho3eb.app.core

import android.content.Context
import com.sho3eb.app.data.UserRecipe
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

/** قاعدة بيانات الوصفات والأطعمة والأجهزة ودليل السكري (من ملفات assets/food) */
object Food {

    data class Ing(val q: String, val u: String, val n: String) { val text get() = listOf(q, u, n).filter { it.isNotBlank() }.joinToString(" ") }
    data class Recipe(
        val id: String, val ar: String, val en: String, val cuisine: String, val meal: String, val servings: Int, val minutes: Int,
        val kcal: Int, val carbs: Double, val protein: Double, val fat: Double, val diab: String, val apps: List<String>,
        val ing: List<Ing>, val steps: List<String>, val benefits: String, val harms: String, val priceEG: String, val priceGulf: String,
        val userId: Long? = null, val videoUrl: String = "", val favorite: Boolean = false
    ) {
        val name get() = tr(ar, en)
        val carbServings get() = (carbs / 15.0)
    }
    data class FoodItem(
        val ar: String, val en: String, val emoji: String, val type: String, val kcal: Double, val carbs: Double, val gi: Int,
        val serving: String, val benefits: String, val cautions: String, val diab: String
    ) { val name get() = tr(ar, en) }
    data class Appliance(val id: String, val ar: String, val en: String, val emoji: String, val caps: List<String>, val tips: List<String>, val brands: List<String>, val priceEG: String, val priceGulf: String) {
        val name get() = tr(ar, en)
    }
    data class GuideSection(val emoji: String, val title: String, val body: String)

    // -------- التصنيفات --------
    val cuisines = listOf(Opt("ALL", "الكل", "All", "🍽️"), Opt("EG", "مصري", "Egyptian", "🇪🇬"), Opt("GULF", "خليجي", "Gulf", "🇸🇦"), Opt("HEALTHY", "صحي", "Healthy", "🥗"), Opt("MINE", "وصفاتي", "My recipes", "⭐"))
    val meals = listOf(
        Opt("ALL", "كل الوجبات", "All meals", "🍽️"), Opt("BREAKFAST", "فطور", "Breakfast", "🍳"), Opt("LUNCH", "غداء", "Lunch", "🍛"),
        Opt("DINNER", "عشاء", "Dinner", "🌙"), Opt("SOUP", "شوربة", "Soup", "🥣"), Opt("SALAD", "سلطة", "Salad", "🥗"),
        Opt("SNACK", "سناك", "Snack", "🥟"), Opt("DESSERT", "حلويات", "Dessert", "🍰"), Opt("DRINK", "مشروبات", "Drinks", "☕")
    )
    fun meal(k: String) = meals.firstOrNull { it.key == k } ?: meals.first()
    fun diabLabel(d: String) = when (d) { "G" -> tr("مناسبة لمرضى السكري", "Diabetes-friendly"); "M" -> tr("باعتدال لمرضى السكري", "OK in moderation"); else -> tr("يتجنبها مريض السكري", "Avoid if diabetic") }
    fun diabEmoji(d: String) = when (d) { "G" -> "🟢"; "M" -> "🟡"; else -> "🔴" }
    val foodTypes = listOf(
        Opt("ALL", "الكل", "All", "🍽️"), Opt("VEG", "خضار", "Vegetables", "🥦"), Opt("FRUIT", "فاكهة", "Fruit", "🍎"), Opt("GRAIN", "حبوب ونشويات", "Grains", "🌾"),
        Opt("LEGUME", "بقوليات", "Legumes", "🫘"), Opt("PROTEIN", "بروتين", "Protein", "🍗"), Opt("DAIRY", "ألبان", "Dairy", "🥛"), Opt("NUT", "مكسرات وبذور", "Nuts & seeds", "🌰"),
        Opt("DRINK", "مشروبات", "Drinks", "🥤"), Opt("SWEET", "حلويات", "Sweets", "🍰"), Opt("SPICE", "توابل وأعشاب", "Spices & herbs", "🌿"), Opt("PRODUCT", "منتجات السوق", "Products", "🏷️")
    )

    // -------- التحميل --------
    private var recipesC: List<Recipe>? = null
    private var foodsC: List<FoodItem>? = null
    private var appsC: List<Appliance>? = null
    private var guideC: List<GuideSection>? = null

    private fun read(ctx: Context, name: String) = ctx.assets.open("food/$name.json").bufferedReader().use { it.readText() }
    private fun JSONArray.strings() = (0 until length()).map { getString(it) }

    fun recipes(ctx: Context): List<Recipe> = recipesC ?: runCatching {
        val a = JSONArray(read(ctx, "recipes"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val ing = o.getJSONArray("ing").let { arr -> (0 until arr.length()).map { j -> arr.getJSONObject(j).let { Ing(it.optString("q"), it.optString("u"), it.optString("n")) } } }
            Recipe(o.getString("id"), o.getString("ar"), o.getString("en"), o.getString("cuisine"), o.getString("meal"), o.getInt("servings"), o.getInt("minutes"),
                o.getInt("kcal"), o.getDouble("carbs"), o.getDouble("protein"), o.getDouble("fat"), o.getString("diab"), o.getJSONArray("apps").strings(),
                ing, o.getJSONArray("steps").strings(), o.getString("benefits"), o.getString("harms"), o.getString("priceEG"), o.getString("priceGulf"))
        }
    }.getOrDefault(emptyList()).also { recipesC = it }

    fun foods(ctx: Context): List<FoodItem> = foodsC ?: runCatching {
        val a = JSONArray(read(ctx, "foods"))
        (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
            FoodItem(o.getString("ar"), o.getString("en"), o.getString("emoji"), o.getString("type"), o.getDouble("kcal"), o.getDouble("carbs"), o.getInt("gi"),
                o.getString("serving"), o.getString("benefits"), o.getString("cautions"), o.getString("diab"))
        } }
    }.getOrDefault(emptyList()).also { foodsC = it }

    fun appliances(ctx: Context): List<Appliance> = appsC ?: runCatching {
        val a = JSONArray(read(ctx, "appliances"))
        (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
            Appliance(o.getString("id"), o.getString("ar"), o.getString("en"), o.getString("emoji"), o.getJSONArray("caps").strings(), o.getJSONArray("tips").strings(),
                o.getJSONArray("brands").strings(), o.getString("priceEG"), o.getString("priceGulf"))
        } }
    }.getOrDefault(emptyList()).also { appsC = it }

    fun guide(ctx: Context): List<GuideSection> = guideC ?: runCatching {
        val a = JSONArray(read(ctx, "diabetes"))
        (0 until a.length()).map { i -> a.getJSONObject(i).let { GuideSection(it.getString("emoji"), it.getString("title"), it.getString("body")) } }
    }.getOrDefault(emptyList()).also { guideC = it }

    fun applianceName(ctx: Context, id: String) = when (id) {
        "stove" -> tr("🔥 البوتاجاز", "🔥 Stove"); "none" -> tr("🥗 بدون طهي", "🥗 No cooking")
        else -> appliances(ctx).firstOrNull { it.id == id }?.let { it.emoji + " " + it.name } ?: id
    }

    fun fromUser(u: UserRecipe) = Recipe(
        "u${u.id}", u.name, u.name, "MINE", u.meal.ifBlank { "LUNCH" }, u.servings, u.minutes, u.calories, u.carbs, u.protein, u.fat,
        when { u.carbs <= 0 -> "M"; u.carbs <= 30 -> "G"; u.carbs <= 50 -> "M"; else -> "A" }, emptyList(),
        u.ingredients.lines().filter { it.isNotBlank() }.map { Ing("", "", it.trim()) }, u.steps.lines().filter { it.isNotBlank() },
        u.notes, "", "", "", u.id, u.videoUrl, u.favorite
    )

    // -------- التأثير على السكر --------
    data class Effect(val level: Int, val label: String, val emoji: String) // 0 يخفض/يساعد، 1 آمن، 2 منخفض، 3 متوسط، 4 مرتفع، 5 سريع جداً
    private val helpers = setOf("قرفة", "حلبة", "حبة البركة", "خل التفاح", "كركم", "زنجبيل", "بذور شيا", "بذور الكتان", "شاي أخضر", "بامية", "ليمون", "لوز", "جوز (عين الجمل)", "أفوكادو")

    fun effect(f: FoodItem): Effect {
        val gl = if (f.gi >= 0) f.gi * f.carbs / 100.0 else 0.0
        return when {
            f.ar in helpers -> Effect(0, tr("قد يساعد على ضبط السكر", "May help control sugar"), "💚")
            f.carbs < 0 -> Effect(3, tr("حسب المكونات", "Depends on ingredients"), "🟡")
            f.carbs <= 5 || f.gi < 0 -> Effect(1, tr("لا يرفع السكر تقريباً", "Barely raises sugar"), "🟢")
            f.gi >= 70 && f.carbs >= 15 -> Effect(5, tr("يرفع السكر بسرعة كبيرة", "Spikes sugar fast"), "🔴")
            f.gi >= 70 || (f.gi >= 56 && f.carbs >= 20) || gl >= 20 -> Effect(4, tr("يرفع السكر بشكل واضح", "Raises sugar noticeably"), "🟠")
            f.gi >= 56 || gl >= 11 -> Effect(3, tr("رفع متوسط — باعتدال", "Moderate rise"), "🟡")
            else -> Effect(2, tr("رفع بطيء ومنخفض", "Slow, low rise"), "🟢")
        }
    }
    fun giLabel(gi: Int) = when { gi < 0 -> tr("لا ينطبق", "N/A"); gi <= 55 -> tr("منخفض", "Low"); gi <= 69 -> tr("متوسط", "Medium"); else -> tr("مرتفع", "High") }

    fun searchFoods(ctx: Context, q: String): List<FoodItem> {
        val n = VoiceParse.norm(q.trim())
        if (n.isBlank()) return foods(ctx)
        val words = n.split(" ").filter { it.length >= 2 }
        return foods(ctx).map { f ->
            val a = VoiceParse.norm(f.ar); val e = f.en.lowercase()
            val score = when {
                a == n || e == n -> 100
                a.startsWith(n) || e.startsWith(n) -> 80
                a.contains(n) || e.contains(n) -> 60
                words.isNotEmpty() && words.all { w -> a.contains(w) || e.contains(w) } -> 40
                words.any { w -> w.length >= 3 && (a.contains(w) || e.contains(w)) } -> 20
                else -> 0
            }
            f to score
        }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
    }

    fun searchRecipes(list: List<Recipe>, q: String): List<Recipe> {
        val n = VoiceParse.norm(q.trim())
        if (n.isBlank()) return list
        return list.filter { r -> VoiceParse.norm(r.ar).contains(n) || r.en.lowercase().contains(n) || r.ing.any { VoiceParse.norm(it.n).contains(n) } }
    }

    // -------- اقتراح حسب المكونات والأجهزة --------
    data class Match(val r: Recipe, val have: Int, val total: Int, val missing: List<String>, val appsOk: Boolean) { val pct get() = if (total > 0) have * 100 / total else 0 }
    private val staples = listOf("ملح", "ماء", "زيت", "فلفل", "بهارات", "رشة", "سكر")

    fun suggest(list: List<Recipe>, pantry: Set<String>, myApps: Set<String>): List<Match> {
        val pn = pantry.map { VoiceParse.norm(it) }
        return list.map { r ->
            val core = r.ing.filter { i -> staples.none { VoiceParse.norm(i.n).startsWith(VoiceParse.norm(it)) } }
            val have = core.filter { i -> val n = VoiceParse.norm(i.n); pn.any { p -> n.contains(p) || p.contains(n.split(" ").first()) } }
            val appsOk = r.apps.isEmpty() || r.apps.any { it == "stove" && "stove" in myApps || it == "none" || it in myApps }
            Match(r, have.size, core.size, core.filter { it !in have }.map { it.n }, appsOk)
        }.filter { it.have > 0 }.sortedWith(compareByDescending<Match> { it.appsOk }.thenByDescending { it.pct }.thenByDescending { it.have })
    }

    /** المكونات الشائعة للاختيار السريع */
    val pantryChoices = listOf(
        "دجاج", "لحم", "لحم مفروم", "سمك", "تونة", "بيض", "أرز", "مكرونة", "شعيرية", "عيش", "دقيق", "شوفان", "برغل", "عدس", "فول", "حمص", "فاصوليا",
        "طماطم", "بصل", "ثوم", "بطاطس", "كوسة", "باذنجان", "فلفل", "جزر", "خيار", "خس", "سبانخ", "ملوخية", "بامية", "كرنب", "بروكلي", "ورق عنب", "بقدونس", "كزبرة",
        "حليب", "زبادي", "جبن", "قشطة", "زبدة", "سمن", "ليمون", "صلصة", "كينوا", "مكسرات", "تمر", "سميد", "جوز هند"
    )
    val myAppliancesKey = "kitchen_apps"
    val pantryKey = "kitchen_pantry"
    fun savedSet(key: String) = Extras.s(key, "").split("|").filter { it.isNotBlank() }.toSet()
    fun saveSet(key: String, s: Set<String>) = Extras.ps(key, s.joinToString("|"))

    // -------- روابط خارجية --------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    fun youtube(q: String) = "https://www.youtube.com/results?search_query=" + enc(q + " " + tr("طريقة عمل", "recipe"))
    fun google(q: String) = "https://www.google.com/search?q=" + enc(q)
    fun priceLinks(model: String) = listOf(
        "Amazon.eg" to "https://www.amazon.eg/s?k=" + enc(model), "Jumia" to "https://www.jumia.com.eg/catalog/?q=" + enc(model),
        "Noon" to "https://www.noon.com/saudi-en/search/?q=" + enc(model), "Amazon.sa" to "https://www.amazon.sa/s?k=" + enc(model),
        "Google" to google(model + " " + tr("سعر ومواصفات", "price specs"))
    )

    /** البحث عن وصفة غير موجودة في TheMealDB (بالإنجليزية) */
    data class Online(val name: String, val area: String, val category: String, val ingredients: List<String>, val steps: List<String>, val video: String, val thumb: String)
    fun searchOnline(q: String): List<Online> = runCatching {
        val c = URL("https://www.themealdb.com/api/json/v1/1/search.php?s=" + enc(q)).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        val txt = c.inputStream.bufferedReader().use { it.readText() }
        val meals = JSONObject(txt).optJSONArray("meals") ?: return@runCatching emptyList()
        (0 until meals.length()).map { i -> meals.getJSONObject(i).let { m ->
            val ings = (1..20).mapNotNull { k -> val n = m.optString("strIngredient$k").trim(); val ms = m.optString("strMeasure$k").trim(); if (n.isBlank() || n == "null") null else "$ms $n".trim() }
            Online(m.optString("strMeal"), m.optString("strArea"), m.optString("strCategory"), ings,
                m.optString("strInstructions").split(Regex("\\r?\\n|(?<=\\.)\\s+(?=[A-Z])")).map { it.trim() }.filter { it.length > 3 },
                m.optString("strYoutube").takeIf { it != "null" } ?: "", m.optString("strMealThumb"))
        } }
    }.getOrDefault(emptyList())

    // -------- السكر --------
    val glucoseContexts = listOf(Opt("FASTING", "صائم", "Fasting", "🌅"), Opt("BEFORE", "قبل الأكل", "Before meal", "🍽️"), Opt("AFTER", "بعد الأكل بساعتين", "2h after meal", "⏱️"), Opt("BEDTIME", "قبل النوم", "Bedtime", "🌙"), Opt("RANDOM", "عشوائي", "Random", "🎲"))
    var glucoseUnit: String get() = Extras.s("glu_unit", "mg"); set(v) = Extras.ps("glu_unit", v)
    fun fmtGlucose(mg: Double) = if (glucoseUnit == "mmol") String.format(java.util.Locale.US, "%.1f mmol/L", mg / 18.0) else "${mg.roundToInt()} mg/dL"
    fun toMg(v: Double) = if (glucoseUnit == "mmol") v * 18.0 else v
    /** 0 هبوط، 1 طبيعي، 2 مرتفع قليلاً، 3 مرتفع */
    fun glucoseLevel(mg: Double, context: String) = when {
        mg < 70 -> 0
        context == "AFTER" -> if (mg < 180) 1 else if (mg < 250) 2 else 3
        context == "FASTING" || context == "BEFORE" -> if (mg <= 130) 1 else if (mg < 180) 2 else 3
        else -> if (mg <= 180) 1 else if (mg < 250) 2 else 3
    }
    fun levelLabel(l: Int) = when (l) { 0 -> tr("هبوط ⚠️", "Low ⚠️"); 1 -> tr("ضمن الهدف", "In range"); 2 -> tr("مرتفع قليلاً", "Slightly high"); else -> tr("مرتفع", "High") }
    /** التراكمي التقديري من متوسط القراءات (معادلة ADAG) */
    fun estimatedA1c(avgMg: Double) = (avgMg + 46.7) / 28.7
}
