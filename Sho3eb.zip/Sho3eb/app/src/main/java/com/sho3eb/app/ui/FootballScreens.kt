@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** ذاكرة المباريات المحملة لكل الدوريات (تتحدث كل دقيقة أثناء البث) */
object FootballStore {
    val matches = mutableStateMapOf<String, List<Football.Match>>()
    val loading = mutableStateOf(false)
    fun all() = matches.values.flatten()
    fun byId(id: String) = all().firstOrNull { it.id == id }
}

@Composable
fun rememberFootballLoader(leagues: List<Football.League>, tick: Int) {
    LaunchedEffect(leagues.map { it.id }, tick) {
        FootballStore.loading.value = true
        for (l in leagues) {
            val live = FootballStore.matches[l.id]?.any { it.live } == true
            val m = withContext(Dispatchers.IO) { runCatching { Football.around(l, live) }.getOrDefault(emptyList()) }
            if (m.isNotEmpty() || FootballStore.matches[l.id] == null) FootballStore.matches[l.id] = m
        }
        FootballStore.loading.value = false
    }
}

@Composable
fun TeamBadge(url: String, size: androidx.compose.ui.unit.Dp = 28.dp) {
    if (url.isBlank()) Box(Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text("⚽", fontSize = (size.value * 0.5f).sp) }
    else UrlImage(if (url.contains("thesportsdb") && !url.endsWith("/tiny") && !url.endsWith("/small")) "$url/small" else url, Modifier.size(size))
}

@Composable
fun MatchRow(m: Football.Match, onClick: () -> Unit) {
    val fav = Football.favTeamId
    val isFav = fav.isNotBlank() && (m.homeId == fav || m.awayId == fav)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (isFav) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surfaceVariant)) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                Text(m.homeAr, fontWeight = if (m.finished && (m.hs ?: 0) > (m.aws ?: 0)) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(6.dp)); TeamBadge(m.homeBadge)
            }
            Column(Modifier.width(78.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    m.live -> { Text(m.score, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = DangerRed); Text("🔴 " + Football.statusLabel(m.status), style = MaterialTheme.typography.labelSmall, color = DangerRed, maxLines = 1) }
                    m.finished -> { Text(m.score, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp); Text(Football.statusLabel(m.status), style = MaterialTheme.typography.labelSmall) }
                    else -> { Text(Football.localTime(m.time), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary); Text(if (m.status == "NS" || m.status.isBlank()) Football.relDay(m.date) else Football.statusLabel(m.status), style = MaterialTheme.typography.labelSmall, maxLines = 1) }
                }
            }
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                TeamBadge(m.awayBadge); Spacer(Modifier.width(6.dp))
                Text(m.awayAr, fontWeight = if (m.finished && (m.aws ?: 0) > (m.hs ?: 0)) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
        }
    }
}

// ================================ الشاشة الرئيسية لكرة القدم ================================
@Composable
fun FootballScreen(nav: NavController) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var leagues by remember { mutableStateOf(Football.leagues()) }
    var tick by remember { mutableIntStateOf(0) }
    rememberFootballLoader(leagues, tick)
    val anyLive = FootballStore.all().any { it.live }
    LaunchedEffect(anyLive) { while (anyLive) { delay(60_000); tick++ } }
    val notifPerm = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        FootballAlerts.channel(ctx); FootballAlerts.schedule(ctx)
        if (android.os.Build.VERSION.SDK_INT >= 33 && !Notifier.canNotify(ctx)) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }
    ScreenScaffold(
        title = tr("⚽ كرة القدم", "⚽ Football"), onBack = { nav.popBackStack() },
        actions = {
            if (FootballStore.loading.value) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            IconButton(onClick = { tick++ }) { Icon(Icons.Filled.Refresh, null) }
            IconButton(onClick = { nav.navigate("media") }) { Icon(Icons.Filled.LiveTv, contentDescription = tr("شاشة العرض", "Media screen")) }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(tab, edgePadding = 8.dp) {
                listOf(tr("المباريات", "Matches"), tr("الترتيب", "Table"), tr("الهدافون", "Top players"), tr("الأخبار", "News"), tr("دورياتي", "My leagues")).forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> MatchesTab(nav, leagues)
                1 -> TableTab(nav, leagues)
                2 -> PlayersTab(leagues)
                3 -> NewsTab(nav, leagues)
                else -> LeaguesSettingsTab(leagues) { leagues = it; Football.saveLeagues(it); tick++ }
            }
        }
    }
}

@Composable
private fun MatchesTab(nav: NavController, leagues: List<Football.League>) {
    var day by rememberSaveable { mutableIntStateOf(0) }
    var onlyLive by rememberSaveable { mutableStateOf(false) }
    val date = LocalDate.now().plusDays(day.toLong())
    val all = FootballStore.all()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items((-3..6).toList()) { d ->
                    val dt = LocalDate.now().plusDays(d.toLong())
                    val n = all.count { it.date == dt }
                    FilterChip(day == d, { day = d }, label = { Text(Football.relDay(dt) + if (n > 0) " ($n)" else "") })
                }
            }
        }
        item {
            HChips {
                FilterChip(onlyLive, { onlyLive = !onlyLive }, label = { Text(tr("🔴 المباشر فقط", "🔴 Live only")) })
                Football.favTeamName.takeIf { it.isNotBlank() }?.let { AssistChip({ nav.navigate("team/${Football.favTeamId}") }, label = { Text("⭐ " + TeamAr.name(it)) }) }
            }
        }
        var any = false
        leagues.sortedBy { if (it.id == Football.favLeague) 0 else 1 }.forEach { l ->
            val list = (FootballStore.matches[l.id] ?: emptyList()).filter { (onlyLive && it.live) || (!onlyLive && it.date == date) }.sortedBy { it.time }
            if (list.isNotEmpty()) {
                any = true
                item(key = "h" + l.id) {
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (l.id == Football.favLeague) "⭐ " else "🏆 ", fontSize = 14.sp)
                        Text(l.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        Text(tr("الجولة ", "Round ") + list.first().round, style = MaterialTheme.typography.labelSmall)
                    }
                }
                items(list, key = { "m" + it.id }) { m -> MatchRow(m) { nav.navigate("match/${m.id}") } }
            }
        }
        if (!any) item {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                if (FootballStore.loading.value) CircularProgressIndicator()
                else Text(if (onlyLive) tr("لا توجد مباريات مباشرة الآن", "No live matches now") else tr("لا توجد مباريات في هذا اليوم ضمن دورياتك", "No matches on this day in your leagues"), color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
        item { Text(tr("المواعيد بتوقيت جهازك. البيانات من TheSportsDB وتتحدث كل دقيقة أثناء المباريات.", "Times in your device's timezone. Data from TheSportsDB, refreshed every minute during matches."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun LeaguePicker(leagues: List<Football.League>, sel: String, onSel: (String) -> Unit) {
    HChips { leagues.forEach { l -> FilterChip(sel == l.id, { onSel(l.id) }, label = { Text(l.title, maxLines = 1) }) } }
}

@Composable
private fun TableTab(nav: NavController, leagues: List<Football.League>) {
    var sel by rememberSaveable { mutableStateOf(Football.favLeague.takeIf { id -> leagues.any { it.id == id } } ?: leagues.firstOrNull()?.id ?: "") }
    var rows by remember { mutableStateOf<List<Football.Row>?>(null) }
    var src by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(sel, refresh) {
        val l = leagues.firstOrNull { it.id == sel } ?: return@LaunchedEffect
        if (refresh == 0) rows = null
        busy = true
        val res = withContext(Dispatchers.IO) {
            runCatching {
                val official = FootballLive.standings(l, true)
                if (official != null) {
                    val known = FootballStore.all().filter { it.leagueId == l.id }.flatMap { listOf(Triple(it.home, it.homeId, it.homeBadge), Triple(it.away, it.awayId, it.awayBadge)) }.distinctBy { it.first }
                    "ESPN" to official.map { r -> val k = known.firstOrNull { FootballLive.same(it.first, r.team) }; r.copy(teamId = k?.second ?: "", badge = r.badge.ifBlank { k?.third ?: "" }) }
                } else "TheSportsDB" to Football.table(Football.season(l))
            }.getOrDefault("" to emptyList())
        }
        if (res.second.isNotEmpty() || rows == null) { rows = res.second; src = res.first }
        busy = false
    }
    // تحديث تلقائي كل دقيقتين أثناء المباريات وكل 10 دقائق في غيرها
    LaunchedEffect(sel) { while (true) { delay(if (FootballStore.all().any { it.live && it.leagueId == sel }) 120_000 else 600_000); refresh++ } }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { LeaguePicker(leagues, sel) { sel = it } }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (busy) tr("⏳ جارٍ التحديث…", "⏳ Updating…") else tr("✅ محدث الآن", "✅ Up to date"), style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), color = if (busy) WarnAmber else SuccessGreen)
                IconButton(onClick = { refresh++ }) { Icon(Icons.Filled.Refresh, null) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp)) {
                Text("#", Modifier.width(24.dp), fontWeight = FontWeight.Bold); Text(tr("الفريق", "Team"), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                listOf(tr("لعب", "P"), tr("ف", "W"), tr("ت", "D"), tr("خ", "L"), "±", tr("نقاط", "Pts")).forEach { Text(it, Modifier.width(32.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium) }
            }
        }
        val r = rows
        if (r == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        else if (r.isEmpty()) item { Text(tr("لا يتوفر ترتيب لهذه البطولة (قد تكون بنظام خروج المغلوب)", "No table for this competition (may be knockout)"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        else items(r.size) { i ->
            val x = r[i]; val fav = x.teamId == Football.favTeamId
            Row(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.small).background(if (fav) MaterialTheme.colorScheme.primaryContainer else if (i % 2 == 0) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else Color.Transparent)
                .clickable { if (x.teamId.isNotBlank()) nav.navigate("team/${x.teamId}") }.padding(vertical = 6.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", Modifier.width(24.dp), fontWeight = FontWeight.Bold, color = when { i < 2 -> SuccessGreen; i >= r.size - 3 -> DangerRed; else -> MaterialTheme.colorScheme.onSurface })
                TeamBadge(x.badge, 22.dp); Spacer(Modifier.width(4.dp))
                Column(Modifier.weight(1f)) {
                    Text(TeamAr.name(x.team), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = if (fav) FontWeight.Bold else FontWeight.Normal, style = MaterialTheme.typography.bodyMedium)
                    Row { x.form.takeLast(5).forEach { c -> Box(Modifier.padding(end = 2.dp).size(7.dp).clip(CircleShape).background(when (c) { 'W' -> SuccessGreen; 'L' -> DangerRed; else -> WarnAmber })) } }
                }
                listOf(x.p, x.w, x.d, x.l, x.gd).forEach { Text("$it", Modifier.width(32.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall) }
                Text("${x.pts}", Modifier.width(32.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold)
            }
        }
        item { Text(if (src == "ESPN") tr("الترتيب الرسمي من ESPN ويتحدث تلقائياً.", "Official table from ESPN, auto-updated.") else tr("الترتيب محسوب من نتائج المباريات المنتهية ويتحدث تلقائياً.", "Table computed from finished results, auto-updated."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)) }
    }
}

@Composable
private fun PlayersTab(leagues: List<Football.League>) {
    var sel by rememberSaveable { mutableStateOf(Football.favLeague.takeIf { id -> leagues.any { it.id == id } } ?: leagues.firstOrNull()?.id ?: "") }
    var assists by rememberSaveable { mutableStateOf(false) }
    var res by remember { mutableStateOf<Pair<List<Football.Player>, String?>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(sel, assists, reload) {
        res = null
        res = withContext(Dispatchers.IO) {
            val lg = leagues.firstOrNull { it.id == sel }
            val free = lg?.let { FootballLive.leaders(it) }
            if (free != null && (free.first.isNotEmpty() || free.second.isNotEmpty())) {
                return@withContext (if (assists) free.second.sortedByDescending { it.assists } else free.first.sortedByDescending { it.goals }) to null
            }
            // مفتاح API-Football اختياري فقط (احتياطي إن أدخله المستخدم)
            if (Football.apiKey.isNotBlank()) {
                if (Extras.s("af_map_$sel", "").isBlank()) FootballStore.matches[sel]?.firstOrNull { it.apiId.isNotBlank() }?.let { Football.apifEvents(it) }
                val r = Football.apifPlayers(sel, assists)
                if (r.first.isNotEmpty()) return@withContext r
            }
            emptyList<Football.Player>() to tr("تعذر جلب قائمة الهدافين الآن من المصادر المجانية. اسحب للتحديث أو أعد المحاولة بعد قليل.", "Couldn't load top scorers from the free sources right now. Try again shortly.")
        }
    }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { LeaguePicker(leagues, sel) { sel = it } }
        item {
            HChips {
                FilterChip(!assists, { assists = false }, label = { Text(tr("⚽ الأكثر تهديفاً", "⚽ Top scorers")) })
                FilterChip(assists, { assists = true }, label = { Text(tr("🎯 الأكثر صناعة", "🎯 Top assists")) })
            }
        }
        val r = res
        if (r == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        else {
            r.second?.let { e -> item { Card { Column(Modifier.padding(12.dp)) { Text(e, style = MaterialTheme.typography.bodySmall); TextButton(onClick = { reload++ }) { Text(tr("إعادة المحاولة", "Retry")) } } } } }
            items(r.first.size) { i ->
                val p = r.first[i]
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", Modifier.width(26.dp), fontWeight = FontWeight.Bold, color = if (i < 3) WarnAmber else MaterialTheme.colorScheme.onSurface)
                        UrlImage(p.photo, Modifier.size(40.dp).clip(CircleShape)); Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) { Text(TeamAr.player(p.name), fontWeight = FontWeight.Bold); Text(TeamAr.name(p.team) + (if (p.apps > 0) tr(" • ${p.apps} مباراة", " • ${p.apps} apps") else ""), style = MaterialTheme.typography.bodySmall) }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${if (assists) p.assists else p.goals}", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                            Text(if (assists) tr("تمريرة", "assists") else tr("هدف", "goals"), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NewsTab(nav: NavController, leagues: List<Football.League>) {
    val ctx = LocalContext.current
    val favTeam = Football.favTeamName
    val opts = listOfNotNull(favTeam.takeIf { it.isNotBlank() }?.let { "T" to it }) + leagues.map { "L" + it.id to it.title } + listOf("Q" to tr("كرة القدم المصرية", "Egyptian football"))
    var sel by rememberSaveable { mutableStateOf(opts.first().first) }
    var news by remember { mutableStateOf<List<Football.News>?>(null) }
    LaunchedEffect(sel) {
        news = null
        val q = opts.firstOrNull { it.first == sel }?.second ?: ""
        val l = leagues.firstOrNull { "L" + it.id == sel }
        news = withContext(Dispatchers.IO) { (Football.news(q + " " + tr("كرة القدم", "football")) + (l?.let { Football.espnNews(it) } ?: emptyList())).sortedByDescending { it.time } }
    }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HChips { opts.forEach { (k, n) -> FilterChip(sel == k, { sel = k }, label = { Text(n, maxLines = 1) }) } } }
        val n = news
        if (n == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        else if (n.isEmpty()) item { Text(tr("لا توجد أخبار حالياً", "No news right now")) }
        else items(n) { x ->
            Card(onClick = { nav.openWeb(x.link, x.source) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(x.title, fontWeight = FontWeight.SemiBold)
                    Text(x.source + (if (x.time > 0) " • " + java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US).format(java.util.Date(x.time)) else ""), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun LeaguesSettingsTab(leagues: List<Football.League>, onChange: (List<Football.League>) -> Unit) {
    val ctx = LocalContext.current
    var country by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf<List<Football.League>?>(null) }
    var notify by remember { mutableStateOf(Football.notify) }
    var nGoals by remember { mutableStateOf(Football.notifyGoals) }
    var nStart by remember { mutableStateOf(Football.notifyStart) }
    var nEnd by remember { mutableStateOf(Football.notifyEnd) }
    var nLeague by remember { mutableStateOf(Football.notifyAllFavLeague) }
    var favLeague by remember { mutableStateOf(Football.favLeague) }
    var key by remember { mutableStateOf(Football.apiKey) }
    LaunchedEffect(country) { country?.let { c -> found = null; found = withContext(Dispatchers.IO) { Football.searchLeagues(c) } } }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { SectionTitle(tr("دورياتي (المفضل ⭐)", "My leagues (⭐ favorite)")) }
        items(leagues.size) { i ->
            val l = leagues[i]
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { favLeague = l.id; Football.favLeague = l.id }) { Icon(if (favLeague == l.id) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = WarnAmber) }
                    Column(Modifier.weight(1f)) { Text(l.title, fontWeight = FontWeight.SemiBold); Text(l.country, style = MaterialTheme.typography.labelSmall) }
                    IconButton(onClick = { if (i > 0) onChange(leagues.toMutableList().apply { add(i - 1, removeAt(i)) }) }, enabled = i > 0) { Icon(Icons.Filled.KeyboardArrowUp, null) }
                    IconButton(onClick = { onChange(leagues.filterIndexed { k, _ -> k != i }) }) { Icon(Icons.Filled.Close, null, tint = DangerRed) }
                }
            }
        }
        item { TextButton(onClick = { onChange(Football.defaults) }) { Text(tr("استعادة الدوريات الافتراضية", "Restore default leagues")) } }
        item { SectionTitle(tr("➕ إضافة دوري أو بطولة", "➕ Add a league / cup")) }
        item { HChips { Football.countries.forEach { (en, ar) -> FilterChip(country == en, { country = en }, label = { Text(tr(ar, en)) }) } } }
        if (country != null) {
            val f = found
            if (f == null) item { CircularProgressIndicator() }
            else items(f, key = { "f" + it.id }) { l ->
                val added = leagues.any { it.id == l.id }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(l.name, Modifier.weight(1f))
                        if (added) Icon(Icons.Filled.Check, null, tint = SuccessGreen, modifier = Modifier.padding(12.dp))
                        else IconButton(onClick = { onChange(leagues + l) }) { Icon(Icons.Filled.AddCircle, null, tint = MaterialTheme.colorScheme.primary) }
                    }
                }
            }
        }
        item { SectionTitle(tr("🔔 الإشعارات", "🔔 Notifications")) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp)) {
                    SwitchRow(tr("إشعارات المباريات", "Match notifications"), tr("لفريقك المفضل والمباريات التي تتابعها", "For your favorite team and followed matches"), notify) { notify = it; Football.notify = it; FootballAlerts.schedule(ctx) }
                    if (notify) {
                        SwitchRow(tr("⏰ قبل البداية وعند الانطلاق", "⏰ Before and at kick-off"), null, nStart) { nStart = it; Football.notifyStart = it }
                        SwitchRow(tr("⚽ الأهداف لحظة بلحظة", "⚽ Goals live"), null, nGoals) { nGoals = it; Football.notifyGoals = it }
                        SwitchRow(tr("⏸️ بين الشوطين والنهاية مع النتيجة", "⏸️ Half-time and full-time with score"), null, nEnd) { nEnd = it; Football.notifyEnd = it }
                        var nSubs by remember { mutableStateOf(Football.notifySubs) }
                        var nCards by remember { mutableStateOf(Football.notifyCards) }
                        var nLineup by remember { mutableStateOf(Football.notifyLineups) }
                        SwitchRow(tr("🔄 التبديلات بأسماء اللاعبين", "🔄 Substitutions with names"), null, nSubs) { nSubs = it; Football.notifySubs = it }
                        SwitchRow(tr("🟥 البطاقات الحمراء وقرارات الفيديو", "🟥 Red cards & VAR decisions"), null, nCards) { nCards = it; Football.notifyCards = it }
                        SwitchRow(tr("👥 التشكيل فور إعلانه", "👥 Lineups once announced"), null, nLineup) { nLineup = it; Football.notifyLineups = it }
                        SwitchRow(tr("كل مباريات الدوري المفضل", "All matches of favorite league"), null, nLeague) { nLeague = it; Football.notifyAllFavLeague = it }
                    }
                }
            }
        }
        item { SectionTitle(tr("📊 الهدافون والأحداث التفصيلية (اختياري)", "📊 Scorers & detailed events (optional)")) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr("الهدافون والأحداث والتشكيل تعمل تلقائياً بدون مفتاح من ESPN وSofaScore. مفتاح API-Football اختياري كمصدر احتياطي.", "Scorers, events and lineups work automatically without a key (ESPN, SofaScore). An API-Football key is an optional backup."), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(key, { key = it.trim() }, label = { Text("API-Football key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { Football.apiKey = key; toast(ctx, tr("تم الحفظ ✅", "Saved ✅")) }) { Text(tr("حفظ المفتاح", "Save key")) }
                        OutlinedButton(onClick = { Share.openUrl(ctx, "https://dashboard.api-football.com/register") }) { Text(tr("احصل على مفتاح مجاني", "Get a free key")) }
                    }
                    Text(tr("الأحداث التفصيلية للدوريات الأوروبية تظهر بدون مفتاح.", "Detailed events for European leagues work without a key."), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        item { TextButton(onClick = { Football.clearCache(); toast(ctx, tr("تم مسح الذاكرة المؤقتة", "Cache cleared")) }) { Text(tr("مسح بيانات كرة القدم المؤقتة", "Clear football cache")) } }
    }
}

// ================================ تفاصيل المباراة ================================
@Composable
fun MatchScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val leagues = remember { Football.leagues() }
    rememberFootballLoader(leagues, tick)
    val m = FootballStore.byId(id)
    var events by remember { mutableStateOf<List<Football.Event>>(emptyList()) }
    var lineups by remember { mutableStateOf<List<FootballLive.Lineup>>(emptyList()) }
    var detSrc by remember { mutableStateOf("") }
    var evErr by remember { mutableStateOf<String?>(null) }
    var tv by remember { mutableStateOf<List<Football.Tv>>(emptyList()) }
    var followed by remember { mutableStateOf(id in Football.followedMatches()) }
    var watchDlg by remember { mutableStateOf(false) }
    LaunchedEffect(m?.status, m?.hs, m?.aws) {
        val mm = m ?: return@LaunchedEffect
        val l = Football.leagueOf(mm.leagueId)
        withContext(Dispatchers.IO) {
            val d = FootballLive.details(mm)
            events = d.events; lineups = d.lineups; detSrc = d.source
            if (d.events.isEmpty() && d.lineups.isEmpty() && l?.espn.isNullOrBlank()) evErr = tr("لم تتوفر أحداث لهذه المباراة من المصادر المجانية حالياً. تُحدَّث تلقائياً.", "No events from free sources yet. Auto-refreshing.")
            tv = Football.tv(mm.id)
        }
    }
    // تحديث التفاصيل والتشكيل كل دقيقة قبل وأثناء المباراة
    LaunchedEffect(m?.id) { while (true) { delay(60_000); val mm = m ?: break; if (mm.finished) break; val d = withContext(Dispatchers.IO) { FootballLive.details(mm) }; if (d.events.isNotEmpty()) events = d.events; if (d.lineups.isNotEmpty()) lineups = d.lineups } }
    LaunchedEffect(m?.live) { while (m?.live == true) { delay(60_000); tick++ } }
    if (m == null) { ScreenScaffold(tr("المباراة", "Match"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }; return }
    val sameSeason = FootballStore.all().filter { it.id != m.id && setOf(it.homeId, it.awayId) == setOf(m.homeId, m.awayId) }
    ScreenScaffold(title = m.homeAr + " × " + m.awayAr, onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { Football.toggleFollow(m.id); Football.addFollowLeague(m.leagueId); followed = !followed; FootballAlerts.schedule(ctx); toast(ctx, if (followed) tr("🔔 ستصلك إشعارات هذه المباراة", "🔔 You'll get alerts") else tr("تم إيقاف الإشعارات", "Alerts off")) }) {
            Icon(if (followed) Icons.Filled.NotificationsActive else Icons.Filled.NotificationsNone, null, tint = if (followed) WarnAmber else MaterialTheme.colorScheme.onSurface)
        }
        IconButton(onClick = { Share.shareText(ctx, "⚽ ${m.homeAr} ${m.score} ${m.awayAr}\n${Football.leagueOf(m.leagueId)?.title ?: m.leagueName} • ${Football.relDay(m.date)} ${Football.localTime(m.time)}") }) { Icon(Icons.Filled.Share, null) }
    }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text((Football.leagueOf(m.leagueId)?.title ?: m.leagueName) + tr(" • الجولة ", " • Round ") + m.round, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { nav.navigate("team/${m.homeId}") }, horizontalAlignment = Alignment.CenterHorizontally) { TeamBadge(m.homeBadge, 58.dp); Text(m.homeAr, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (m.notStarted) Football.localTime(m.time) else m.score, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = if (m.live) DangerRed else MaterialTheme.colorScheme.onPrimaryContainer)
                                Text((if (m.live) "🔴 " else "") + Football.statusLabel(m.status), color = if (m.live) DangerRed else MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.SemiBold)
                                Text(Football.relDay(m.date), style = MaterialTheme.typography.labelSmall)
                            }
                            Column(Modifier.weight(1f).clickable { nav.navigate("team/${m.awayId}") }, horizontalAlignment = Alignment.CenterHorizontally) { TeamBadge(m.awayBadge, 58.dp); Text(m.awayAr, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
                        }
                        if (m.venue.isNotBlank()) Text("🏟️ " + m.venue, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { watchDlg = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = DangerRed)) { Icon(Icons.Filled.LiveTv, null); Spacer(Modifier.width(4.dp)); Text(tr("أين أشاهد؟", "Where to watch")) }
                    Button(onClick = { nav.openWeb(m.video.ifBlank { Football.highlightsSearch(m) }, tr("ملخص المباراة", "Highlights")) }, modifier = Modifier.weight(1f), enabled = !m.notStarted) { Icon(Icons.Filled.Slideshow, null); Spacer(Modifier.width(4.dp)); Text(tr("الملخص", "Highlights")) }
                }
            }
            item { SectionTitle(tr("📋 أحداث المباراة", "📋 Match events")) }
            if (events.isEmpty()) item {
                Text(when {
                    m.notStarted -> tr("لم تبدأ المباراة بعد", "Not started yet")
                    evErr != null -> evErr!!
                    else -> tr("لا توجد أحداث مسجلة بعد", "No events yet")
                }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(events.size) { i ->
                val e = events[i]
                val home = e.home ?: (e.team.isNotBlank() && FootballLive.same(e.team, m.home))
                val icon = when (e.kind) {
                    "goal", "pen" -> "⚽"; "owngoal" -> "⚽🔙"; "penmiss" -> "❌"; "red" -> "🟥"; "yellow" -> "🟨"; "sub" -> "🔄"; "var" -> "📺"
                    else -> when { e.type.contains("Goal", true) -> "⚽"; e.type.contains("Red", true) || e.detail.contains("Red", true) -> "🟥"; e.type.contains("Card", true) -> "🟨"; e.type.contains("subst", true) -> "🔄"; else -> "•" }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = if (home) Arrangement.Start else Arrangement.End) {
                    Surface(shape = MaterialTheme.shapes.medium, color = if (e.isGoal) SuccessGreen.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(e.minute, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(6.dp))
                            Text(icon); Spacer(Modifier.width(6.dp))
                            Column {
                                if (e.kind == "sub") {
                                    Text("⬆️ " + TeamAr.player(e.player), fontWeight = FontWeight.SemiBold, color = SuccessGreen)
                                    if (e.playerOut.isNotBlank()) Text("⬇️ " + TeamAr.player(e.playerOut), style = MaterialTheme.typography.bodySmall, color = DangerRed)
                                } else Text(TeamAr.player(e.player).ifBlank { e.type }, fontWeight = FontWeight.SemiBold)
                                if (e.assist.isNotBlank()) Text(tr("🎯 صناعة: ", "🎯 Assist: ") + TeamAr.player(e.assist), style = MaterialTheme.typography.labelSmall)
                                val extra = listOf(e.detail, TeamAr.name(e.team)).filter { it.isNotBlank() }.joinToString(" • ")
                                if (extra.isNotBlank()) Text(extra, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
            if (lineups.isNotEmpty()) {
                item { SectionTitle(tr("👥 التشكيل", "👥 Lineups") + if (lineups.any { !it.confirmed }) tr(" (متوقع)", " (predicted)") else "") }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        lineups.take(2).forEach { lu ->
                            Card(Modifier.weight(1f)) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(TeamAr.name(lu.team), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (lu.formation.isNotBlank()) Text("📐 " + lu.formation, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    HorizontalDivider()
                                    lu.starters.forEach { p -> Text((if (p.number.isNotBlank()) p.number + ". " else "") + TeamAr.player(p.name) + (if (p.pos.isNotBlank()) " (" + p.pos + ")" else "") + if (p.subOut.isNotBlank()) " ⬇️" else "", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                    if (lu.bench.isNotEmpty()) {
                                        Text(tr("الاحتياط", "Bench"), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                                        lu.bench.forEach { p -> Text((if (p.number.isNotBlank()) p.number + ". " else "") + TeamAr.player(p.name), style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (!m.finished) item { Text(tr("👥 سيظهر التشكيل هنا فور إعلانه (عادة قبل المباراة بساعة) وستصلك إشعار به.", "👥 Lineups appear here once announced (usually 1h before) and you'll be notified."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (detSrc.isNotBlank()) item { Text(tr("المصدر: ", "Source: ") + detSrc, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (sameSeason.isNotEmpty()) {
                item { SectionTitle(tr("🤝 مواجهات أخرى بين الفريقين", "🤝 Other meetings")) }
                items(sameSeason, key = { "h" + it.id }) { x -> MatchRow(x) { nav.navigate("match/${x.id}") } }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { nav.openWeb(Football.goalsSearch(m), tr("الأهداف", "Goals")) }, modifier = Modifier.weight(1f), enabled = !m.notStarted) { Text(tr("⚽ الأهداف", "⚽ Goals")) }
                    OutlinedButton(onClick = { nav.openWeb(Football.highlightsSearch(m), tr("الملخص", "Highlights")) }, modifier = Modifier.weight(1f), enabled = !m.notStarted) { Text(tr("🎬 فيديوهات", "🎬 Videos")) }
                }
            }
        }
    }
    if (watchDlg) WatchSourcesDialog(nav, m, tv) { watchDlg = false }
}

/** مصادر المشاهدة المرقمة: القنوات الرسمية + منصات + روابطك القانونية */
@Composable
private fun WatchSourcesDialog(nav: NavController, m: Football.Match, tv: List<Football.Tv>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val mine = remember { Football.userStreams() }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("📺 مصادر المشاهدة", "📺 Watch sources")) }, text = {
        LazyColumn(Modifier.heightIn(max = 460.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (tv.isNotEmpty()) {
                item { Text(tr("القنوات الناقلة الرسمية", "Official broadcasters"), fontWeight = FontWeight.Bold) }
                items(tv.size) { ix -> val c = tv[ix]; val k = ix + 1; OutlinedButton(onClick = { nav.openWeb(Channels.liveSearch(c.channel), c.channel) }, modifier = Modifier.fillMaxWidth()) { Text(tr("مصدر $k", "Source $k") + " • " + c.channel + if (c.country.isNotBlank()) " (${c.country})" else "", maxLines = 1) } }
            }
            if (mine.isNotEmpty()) {
                item { Text(tr("روابطي القانونية", "My legal links"), fontWeight = FontWeight.Bold) }
                items(mine.size) { ix -> val s = mine[ix]; val k = tv.size + ix + 1; OutlinedButton(onClick = { onDismiss(); nav.openPlayer(s.url, m.homeAr + " × " + m.awayAr) }, modifier = Modifier.fillMaxWidth()) { Text(tr("رابط $k", "Link $k") + " • " + s.name, maxLines = 1) } }
            }
            item { Text(tr("المنصات الرسمية", "Official platforms"), fontWeight = FontWeight.Bold) }
            items(Football.platforms) { p ->
                OutlinedButton(onClick = {
                    val i = ctx.packageManager.getLaunchIntentForPackage(p.pkg)
                    if (i != null) ctx.startActivity(i) else Share.openUrl(ctx, p.url)
                }, modifier = Modifier.fillMaxWidth()) { Text(p.name) }
            }
            item { TextButton(onClick = { nav.openWeb(Football.whereToWatch(m), tr("القناة الناقلة", "Broadcaster")) }) { Text(tr("🔎 ابحث عن القناة الناقلة لهذه المباراة", "🔎 Find this match's broadcaster")) } }
            item { Text(tr("يتطلب البث المباشر للمباريات اشتراكاً في القناة أو المنصة صاحبة الحقوق.", "Live match streams require a subscription to the rights holder."), style = MaterialTheme.typography.labelSmall) }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } })
}

// ================================ صفحة الفريق ================================
@Composable
fun TeamScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    var team by remember { mutableStateOf<Football.Team?>(null) }
    var news by remember { mutableStateOf<List<Football.News>>(emptyList()) }
    var season by remember { mutableStateOf<List<Football.Match>>(emptyList()) }
    var isFav by remember { mutableStateOf(Football.favTeamId == id) }
    var teamLeague by remember { mutableStateOf("") }
    LaunchedEffect(id) {
        team = withContext(Dispatchers.IO) { Football.team(id) }
        val t = team ?: return@LaunchedEffect
        val l = Football.leagues().firstOrNull { FootballStore.matches[it.id]?.any { m -> m.homeId == id || m.awayId == id } == true }
        teamLeague = l?.id ?: ""
        launch { news = withContext(Dispatchers.IO) { Football.news(t.name) } }
        if (l != null) season = withContext(Dispatchers.IO) { Football.season(l).filter { it.homeId == id || it.awayId == id } }
    }
    val t = team
    ScreenScaffold(title = t?.name ?: tr("الفريق", "Team"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (t == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            else {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            TeamBadge(t.badge, 64.dp); Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(TeamAr.name(t.name), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                Text(listOf(t.league, t.stadium, t.year.takeIf { it.isNotBlank() }?.let { tr("تأسس ", "Founded ") + it }).filterNotNull().filter { it.isNotBlank() }.joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Button(onClick = {
                            if (isFav) { Football.favTeamId = ""; Football.favTeamName = ""; Football.favTeamBadge = "" } else { Football.favTeamId = t.id; Football.favTeamName = t.name; Football.favTeamBadge = t.badge; Football.favTeamLeague = teamLeague }
                            isFav = !isFav; FootballAlerts.schedule(ctx)
                        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) { Icon(if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder, null); Spacer(Modifier.width(6.dp)); Text(if (isFav) tr("فريقي المفضل ✓", "My favorite team ✓") else tr("اجعله فريقي المفضل", "Make it my favorite")) }
                    }
                }
                val upcoming = season.filter { it.notStarted }.sortedBy { it.time }
                val past = season.filter { it.finished }.sortedByDescending { it.time }
                if (past.isNotEmpty()) {
                    val w = past.count { (it.homeId == id && (it.hs ?: 0) > (it.aws ?: 0)) || (it.awayId == id && (it.aws ?: 0) > (it.hs ?: 0)) }
                    val d = past.count { it.hs == it.aws }
                    item { Text(tr("هذا الموسم: ${past.size} مباراة • $w فوز • $d تعادل • ${past.size - w - d} خسارة", "This season: ${past.size} played • $w W • $d D • ${past.size - w - d} L"), fontWeight = FontWeight.SemiBold) }
                }
                if (upcoming.isNotEmpty()) { item { SectionTitle(tr("📅 المباريات القادمة", "📅 Upcoming")) }; items(upcoming.take(5), key = { "u" + it.id }) { m -> MatchRow(m) { nav.navigate("match/${m.id}") } } }
                if (past.isNotEmpty()) { item { SectionTitle(tr("✅ النتائج", "✅ Results")) }; items(past.take(10), key = { "p" + it.id }) { m -> MatchRow(m) { nav.navigate("match/${m.id}") } } }
                if (news.isNotEmpty()) { item { SectionTitle(tr("📰 أخبار الفريق", "📰 Team news")) }; items(news.take(10)) { x -> Card(onClick = { nav.openWeb(x.link, x.source) }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) { Text(x.title, fontWeight = FontWeight.SemiBold); Text(x.source, style = MaterialTheme.typography.labelSmall) } } } }
                if (t.desc.isNotBlank()) item { Card { Text(t.desc.take(1200), Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall) } }
            }
        }
    }
}

// ================================ بطاقة الرئيسية ================================
@Composable
fun FootballHomeCard(nav: NavController) {
    val fav = Football.favTeamId
    val leagues = remember { Football.leagues() }
    LaunchedEffect(Unit) {
        if (FootballStore.matches.isEmpty()) for (l in leagues.filter { it.id == Football.favLeague }) {
            val m = withContext(Dispatchers.IO) { runCatching { Football.around(l) }.getOrDefault(emptyList()) }
            FootballStore.matches[l.id] = m
        }
    }
    val all = FootballStore.all()
    val next = (if (fav.isNotBlank()) all.filter { it.homeId == fav || it.awayId == fav } else all.filter { it.leagueId == Football.favLeague })
        .let { l -> l.firstOrNull { it.live } ?: l.filter { it.notStarted }.minByOrNull { it.time } ?: l.filter { it.finished }.maxByOrNull { it.time } }
    Card(onClick = { if (next != null) nav.navigate("match/${next.id}") else nav.navigate("football") }, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⚽ " + (TeamAr.name(Football.favTeamName).ifBlank { Football.leagueOf(Football.favLeague)?.title ?: tr("كرة القدم", "Football") }), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { nav.navigate("football") }) { Text(tr("كل المباريات", "All matches")) }
            }
            if (next != null) MatchRow(next) { nav.navigate("match/${next.id}") }
            else Text(tr("اختر فريقك المفضل من قسم كرة القدم لتظهر مبارياته هنا", "Pick your favorite team in Football to see its matches here"), style = MaterialTheme.typography.bodySmall)
        }
    }
}
