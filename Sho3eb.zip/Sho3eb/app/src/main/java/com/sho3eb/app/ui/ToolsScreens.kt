@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.islam.Content
import com.sho3eb.app.islam.Occ
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** كل البيانات المالية للوحة والبحث */
data class FinData(
    val all: AllData = AllData(),
    val accounts: List<Account> = emptyList(),
    val accTx: List<AccountTx> = emptyList(),
    val livPeriods: List<LivPeriod> = emptyList(),
    val livEntries: List<LivEntry> = emptyList(),
    val propExpenses: List<PropExpense> = emptyList(),
    val workers: List<Worker> = emptyList(),
    val workerEntries: List<WorkerEntry> = emptyList(),
    val assets: List<Asset> = emptyList(),
    val splitGroups: List<SplitGroup> = emptyList(),
    val carExpenses: List<CarExpense> = emptyList(),
    val subPayments: List<SubPayment> = emptyList(),
    val loaded: Boolean = false
)

suspend fun loadFin(dao: AppDao): FinData = withContext(Dispatchers.IO) {
    FinData(loadAllData(dao), dao.allAccounts(), dao.allAccountTx(), dao.allLivPeriods(), dao.allLivEntries(), dao.allPropExpenses(),
        dao.allWorkers(), dao.allWorkerEntrys(), dao.allAssets(), dao.allSplitGroups(), dao.allCarExpenses(), dao.allSubPayments(), true)
}

// =====================================================================
//                        اللوحة المالية الموحدة
// =====================================================================
@Composable
fun DashboardScreen(nav: NavController) {
    val dao = remember { appDao() }
    val data by produceState(FinData()) { value = loadFin(dao) }
    val d = data.all
    val today = LocalDate.now()

    val loansOut = loanSummaries(d.loanTx).sumOf { it.balance.coerceAtLeast(0.0) }
    val salesRem = d.sales.sumOf { s -> saleRemaining(s, d.salePayments.filter { it.saleId == s.id }) }
    val rentOverdue = d.leases.filter { it.active }.sumOf { l -> Rent.overdue(l, d.leasePayments).sumOf { it.remaining } }
    val accBal = data.accounts.sumOf { a -> accountBalance(data.accTx.filter { it.accountId == a.id }) }
    val myDebts = d.debts.filter { !it.closed }.sumOf { Debts.balance(it, d.debtTx).coerceAtLeast(0.0) }
    val receivables = loansOut + salesRem + rentOverdue
    val assetsVal = data.assets.filter { !it.sold }.sumOf { Assets.value(it) }
    val workersDue = data.workers.sumOf { w -> Workers.sum(w, data.workerEntries.filter { it.workerId == w.id }).balance.coerceAtLeast(0.0) }
    val subsMonthly = d.subscriptions.filter { it.active }.sumOf { Subs.monthly(it) }
    val shopRows = Shop.rows(d.invoices, d.invoiceItems, d.invoicePayments)
    val shopRecv = Shop.parties(shopRows, true).sumOf { it.remaining.coerceAtLeast(0.0) }
    val shopPay = Shop.parties(shopRows, false).sumOf { it.remaining.coerceAtLeast(0.0) }
    val net = accBal + receivables + assetsVal + shopRecv - myDebts - workersDue - shopPay
    val month = LivingAuto.monthRange()
    val livIn = data.livEntries.filter { it.kind == Living.INCOME && it.date in month }.sumOf { it.amount }
    val livOut = data.livEntries.filter { it.kind == Living.EXPENSE && it.date in month }.sumOf { it.amount }
    val rentStats = Rent.stats(null, d.units, d.leases, d.leasePayments, data.propExpenses)
    val activeAssocs = d.associations.count { a -> val m = d.members.filter { it.associationId == a.id }; m.isNotEmpty() && !assocFinished(associationRounds(a, m, d.assocPayments.filter { it.associationId == a.id }, d.payouts.filter { it.associationId == a.id })) }
    val dues = remember(data) { if (data.loaded) computeDueItems(d, today, 7, false) else emptyList() }
    val overdueCount = dues.count { it.due.isBefore(today) }

    // التدفق النقدي لآخر 6 أشهر (من المصادر مباشرة لتجنب التكرار مع الترحيل)
    val months = (5 downTo 0).map { today.minusMonths(it.toLong()) }
    val flows = months.map { m ->
        val r = LivingAuto.monthRange(m)
        val inflow = d.loanTx.filter { it.type == LoanTx.PAY && it.date in r }.sumOf { it.amount } +
            d.salePayments.filter { it.date in r }.sumOf { it.amount } +
            d.leasePayments.filter { it.date in r }.sumOf { it.amount } +
            data.livEntries.filter { it.kind == Living.INCOME && it.date in r }.sumOf { it.amount } +
            d.debtTx.filter { it.type == DebtTx.BORROW && it.date in r }.sumOf { it.amount }
        val outflow = d.loanTx.filter { it.type == LoanTx.LOAN && it.date in r }.sumOf { it.amount } +
            data.livEntries.filter { it.kind == Living.EXPENSE && it.date in r }.sumOf { it.amount } +
            data.propExpenses.filter { it.date in r }.sumOf { it.amount } +
            d.debtTx.filter { it.type == DebtTx.PAY && it.date in r }.sumOf { it.amount }
        Triple(Living.monthName(m.monthValue).take(if (AppState.isAr) 6 else 3), inflow, outflow)
    }

    ScreenScaffold(
        title = tr("اللوحة المالية", "Financial dashboard"), onBack = { nav.popBackStack() },
        actions = { IconButton(onClick = { nav.navigate("search") }) { Icon(Icons.Filled.Search, null) } }
    ) { pad ->
        if (!data.loaded) { Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return@ScreenScaffold }
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(tr("صافي مركزك المالي", "Your net position"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                        Text(Fmt.money(net), color = MaterialTheme.colorScheme.onPrimary, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text(tr("= الحسابات + ما لك + الأصول − ديونك − مستحقات العمال", "= accounts + receivables + assets − debts − wages due"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashTile(tr("أرصدة الحسابات", "Accounts"), accBal, Icons.Filled.AccountBalance, MaterialTheme.colorScheme.primary, Modifier.weight(1f)) { nav.navigate("accounts") }
                    DashTile(tr("ما عليّ (ديوني)", "I owe"), myDebts, Icons.Filled.CreditCard, DangerRed, Modifier.weight(1f)) { nav.navigate("debts") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashTile(tr("الذهب والأصول", "Assets"), assetsVal, Icons.Filled.Diamond, WarnAmber, Modifier.weight(1f)) { nav.navigate("assets") }
                    DashTile(tr("مستحقات العمال", "Wages due"), workersDue, Icons.Filled.Engineering, DangerRed, Modifier.weight(1f)) { nav.navigate("workers") }
                    DashTile(tr("اشتراكات/شهر", "Subs / month"), subsMonthly, Icons.Filled.Autorenew, MaterialTheme.colorScheme.secondary, Modifier.weight(1f)) { nav.navigate("subs") }
                }
            }
            if (d.invoices.isNotEmpty()) item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashTile(tr("ديون عملاء المحل", "Shop receivables"), shopRecv, Icons.Filled.Storefront, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f)) { nav.navigate("shop") }
                    DashTile(tr("مستحقات الموردين", "Owed to suppliers"), shopPay, Icons.Filled.LocalShipping, DangerRed, Modifier.weight(1f)) { nav.navigate("shop") }
                }
            }
            item { SectionTitle(tr("ما لك عند الآخرين", "Receivables") + " • " + Fmt.money(receivables)) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DashTile(tr("السلف", "Loans"), loansOut, Icons.Filled.Payments, MaterialTheme.colorScheme.secondary, Modifier.weight(1f)) { nav.navigate("loans") }
                    DashTile(tr("التقسيط", "Installments"), salesRem, Icons.Filled.ShoppingCart, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f)) { nav.navigate("sales") }
                    DashTile(tr("متأخرات الإيجار", "Rent overdue"), rentOverdue, Icons.Filled.Apartment, WarnAmber, Modifier.weight(1f)) { nav.navigate("props") }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(tr("هذا الشهر", "This month"), fontWeight = FontWeight.Bold)
                        KeyValue(tr("دخل المعيشة", "Living income"), Fmt.money(livIn), SuccessGreen)
                        KeyValue(tr("مصروفات المعيشة", "Living expenses"), Fmt.money(livOut), DangerRed)
                        KeyValue(tr("الإيجار الشهري المتوقع", "Expected rent"), Fmt.money(rentStats.monthlyRent))
                        KeyValue(tr("إشغال العقارات", "Occupancy"), "${rentStats.occupancy}% (${rentStats.occupied}/${rentStats.units})")
                        KeyValue(tr("جمعيات نشطة", "Active associations"), "$activeAssocs")
                    }
                }
            }
            item { SectionTitle(tr("التدفق النقدي (آخر 6 أشهر)", "Cash flow (last 6 months)")) }
            item { CashFlowChart(flows) }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr("المستحقات خلال 7 أيام", "Due within 7 days"), Modifier.weight(1f))
                    if (overdueCount > 0) StatusChip(tr("$overdueCount متأخر", "$overdueCount late"), DangerRed)
                }
            }
            if (dues.isEmpty()) item { Text(tr("لا توجد مستحقات قريبة ✅", "Nothing due soon ✅"), color = SuccessGreen) }
            items(dues.take(12)) { it0 ->
                Card(onClick = {
                    when (it0.kind) {
                        DueKind.ASSOC -> nav.navigate("assoc/${it0.refId}"); DueKind.LOAN -> nav.navigate("loan/${it0.refId}")
                        DueKind.SALE -> nav.navigate("sale/${it0.refId}"); DueKind.RENT -> nav.navigate("lease/${it0.refId}"); DueKind.DEBT -> nav.navigate("debt/${it0.refId}")
                        DueKind.CAR -> nav.navigate("car/${it0.refId}"); DueKind.SUB -> nav.navigate("subs"); DueKind.INV -> nav.navigate("invoice/${it0.refId}"); DueKind.DOC -> nav.navigate("vault")
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(it0.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(it0.subtitle + " • " + Fmt.date(it0.due), style = MaterialTheme.typography.bodySmall, color = if (it0.due.isBefore(today)) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (it0.amount > 0) Text(Fmt.money(it0.amount), fontWeight = FontWeight.Bold, color = if (it0.kind == DueKind.DEBT) DangerRed else MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun DashTile(title: String, value: Double, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Icon(icon, null, tint = color)
            Spacer(Modifier.height(4.dp))
            Text(title, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(Fmt.num(value), fontWeight = FontWeight.Bold, color = color, maxLines = 1)
        }
    }
}

@Composable
private fun CashFlowChart(flows: List<Triple<String, Double, Double>>) {
    val mx = flows.maxOfOrNull { maxOf(it.second, it.third) }?.takeIf { it > 0 } ?: 1.0
    val inC = SuccessGreen
    val outC = DangerRed
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                flows.forEach { (_, i, o) ->
                    Canvas(Modifier.width(34.dp).fillMaxHeight()) {
                        val bw = size.width / 2.4f
                        val hi = (i / mx * size.height).toFloat()
                        val ho = (o / mx * size.height).toFloat()
                        drawRoundRect(inC, Offset(0f, size.height - hi), Size(bw, hi), CornerRadius(6f, 6f))
                        drawRoundRect(outC, Offset(size.width - bw, size.height - ho), Size(bw, ho), CornerRadius(6f, 6f))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                flows.forEach { Text(it.first, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(50.dp), maxLines = 1) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("■ " + tr("داخل", "In"), color = inC, style = MaterialTheme.typography.bodySmall)
                Text("■ " + tr("خارج", "Out"), color = outC, style = MaterialTheme.typography.bodySmall)
            }
            val last = flows.last()
            Text(tr("هذا الشهر: داخل ", "This month: in ") + Fmt.money(last.second) + tr(" • خارج ", " • out ") + Fmt.money(last.third), style = MaterialTheme.typography.bodySmall)
        }
    }
}

// =====================================================================
//                            البحث الشامل
// =====================================================================
private data class Hit(val section: String, val title: String, val sub: String, val route: String, val icon: ImageVector)

@Composable
fun GlobalSearchScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val data by produceState(FinData()) { value = loadFin(dao) }
    val content by produceState(emptyList<Hit>()) {
        value = withContext(Dispatchers.IO) {
            val files = listOf(Content.SIRA, Content.PROPHETS, Content.COMPANIONS, Content.MIRACLES, Content.BATTLES, Content.RULINGS, Content.HAJJ, Content.MEDICINE)
            files.flatMap { f ->
                try {
                    Content.load(ctx, f).flatMapIndexed { gi, g -> g.items.mapIndexed { ii, it -> Hit(contentTitle(f), it.title, g.title, "cread/$f/$gi/$ii", Icons.Filled.MenuBook) } }
                } catch (_: Exception) { emptyList() }
            }
        }
    }
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) {} }

    val hits = remember(q, data, content) {
        val s = q.trim()
        if (s.length < 2) emptyList() else {
            fun m(x: String?) = x != null && x.contains(s, ignoreCase = true)
            val d = data.all
            val pm = d.people.associateBy { it.id }
            val out = mutableListOf<Hit>()
            d.people.filter { m(it.name) || m(it.phone) || m(it.notes) }.forEach { out += Hit(tr("الأشخاص", "People"), it.name, it.phone, "person/${it.id}", Icons.Filled.Person) }
            d.associations.filter { m(it.name) || m(it.notes) }.forEach { out += Hit(tr("الجمعيات", "Associations"), it.name, Fmt.money(it.shareAmount), "assoc/${it.id}", Icons.Filled.Groups) }
            d.loanTx.filter { m(it.note) || m(pm[it.personId]?.name) }.map { it.personId }.distinct().forEach { pid ->
                out += Hit(tr("السلف", "Loans"), pm[pid]?.name ?: "-", tr("الرصيد ", "Balance ") + Fmt.money(loanBalance(d.loanTx.filter { it.personId == pid })), "loan/$pid", Icons.Filled.Payments)
            }
            d.sales.filter { m(it.product) || m(it.notes) || m(pm[it.personId]?.name) }.forEach { out += Hit(tr("التقسيط", "Installments"), it.product, pm[it.personId]?.name ?: "", "sale/${it.id}", Icons.Filled.ShoppingCart) }
            data.accounts.filter { m(it.name) || m(it.notes) }.forEach { out += Hit(tr("الحسابات", "Accounts"), it.name, "", "account/${it.id}", Icons.Filled.AccountBalance) }
            val am = data.accounts.associateBy { it.id }
            data.accTx.filter { m(it.note) }.take(30).forEach { out += Hit(tr("حركات الحسابات", "Account transactions"), it.note, (am[it.accountId]?.name ?: "") + " • " + Fmt.money(it.amount) + " • " + Fmt.date(it.date), "account/${it.accountId}", Icons.Filled.SwapVert) }
            data.livPeriods.filter { m(it.name) }.forEach { out += Hit(tr("مصاريف المعيشة", "Living"), it.name, Fmt.date(it.startDate), "living_period/${it.id}", Icons.Filled.ShoppingBasket) }
            data.livEntries.filter { m(it.name) || m(it.note) }.take(30).forEach { out += Hit(tr("حركات المعيشة", "Living entries"), it.name, Fmt.money(it.amount) + " • " + Fmt.date(it.date), "living_period/${it.periodId}", Icons.Filled.Receipt) }
            d.properties.filter { m(it.name) || m(it.address) || m(it.notes) }.forEach { out += Hit(tr("العقارات", "Properties"), it.name, it.address, "prop/${it.id}", Icons.Filled.Apartment) }
            val um = d.units.associateBy { it.id }
            d.leases.filter { m(pm[it.tenantId]?.name) || m(um[it.unitId]?.name) || m(it.notes) }.forEach { out += Hit(tr("المستأجرون", "Tenants"), pm[it.tenantId]?.name ?: "-", um[it.unitId]?.name ?: "", "lease/${it.id}", Icons.Filled.Key) }
            d.debts.filter { m(it.creditor) || m(it.notes) }.forEach { out += Hit(tr("ديوني", "My debts"), it.creditor, Fmt.money(Debts.balance(it, d.debtTx)), "debt/${it.id}", Icons.Filled.CreditCard) }
            data.workers.filter { m(it.name) || m(it.phone) || m(it.job) || m(it.notes) }.forEach { out += Hit(tr("العمال", "Workers"), it.name, it.job, "worker/${it.id}", Icons.Filled.Engineering) }
            data.workerEntries.filter { m(it.project) || m(it.note) }.take(20).forEach { e -> out += Hit(tr("اليوميات", "Daily log"), e.project.ifBlank { e.note }, Fmt.date(e.date), "worker/${e.workerId}", Icons.Filled.EventNote) }
            data.assets.filter { m(it.name) || m(it.notes) }.forEach { out += Hit(tr("الأصول والاستثمارات", "Assets"), it.name, Fmt.money(Assets.value(it)), "assets", Icons.Filled.Diamond) }
            data.splitGroups.filter { m(it.name) || m(it.notes) }.forEach { out += Hit(tr("تقسيم المصاريف", "Split"), it.name, "", "split/${it.id}", Icons.Filled.Groups) }
            d.vehicles.filter { m(it.name) || m(it.plate) || m(it.model) }.forEach { out += Hit(tr("السيارات", "Cars"), it.name, it.plate, "car/${it.id}", Icons.Filled.DirectionsCar) }
            data.carExpenses.filter { m(it.note) }.take(20).forEach { e -> out += Hit(tr("مصاريف السيارة", "Car expenses"), e.note, Fmt.money(e.amount) + " • " + Fmt.date(e.date), "car/${e.vehicleId}", Icons.Filled.LocalGasStation) }
            d.invoices.filter { m(it.partyName) || m(it.partyPhone) || m(it.notes) || m(Shop.numberText(it)) }.take(30).forEach { out += Hit(tr("فواتير المحل", "Shop invoices"), Shop.numberText(it) + " • " + it.partyName, Shop.type(it.type).label + " • " + Fmt.date(it.date), "invoice/${it.id}", Icons.Filled.Receipt) }
            d.invoiceItems.filter { m(it.name) }.distinctBy { it.name }.take(15).forEach { x -> out += Hit(tr("أصناف الفواتير", "Invoice items"), x.name, Fmt.money(x.price), "invoice/${x.invoiceId}", Icons.Filled.Inventory2) }
            d.vaultDocs.filter { m(it.title) || m(it.holder) || m(it.number) || m(it.notes) }.forEach { out += Hit(tr("خزنة المستندات", "Documents"), it.title, Vault.status(it), "vault", Icons.Filled.FolderShared) }
            d.subscriptions.filter { m(it.name) || m(it.notes) }.forEach { out += Hit(tr("الاشتراكات", "Subscriptions"), it.name, Fmt.money(it.amount), "subs", Icons.Filled.Autorenew) }
            content.filter { m(it.title) }.take(30).forEach { out += it }
            out
        }
    }

    ScreenScaffold(title = tr("البحث الشامل", "Search everything"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                q, { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(12.dp).focusRequester(focus),
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Filled.Clear, null) } },
                placeholder = { Text(tr("اسم، رقم جوال، ملاحظة، منتج، عقار، صحابي...", "Name, phone, note, product, property...")) }
            )
            if (q.trim().length < 2) {
                Text(tr("ابحث في كل الأقسام: الأشخاص، الجمعيات، السلف، التقسيط، الحسابات، المعيشة، العقارات، الديون، العمال، الأصول، السيارات، الاشتراكات، والمحتوى الإسلامي.", "Search all sections at once."), Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else if (hits.isEmpty()) {
                EmptyState(Icons.Filled.Search, tr("لا توجد نتائج", "No results"))
            }
            LazyColumn(contentPadding = PaddingValues(12.dp, 0.dp, 12.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                hits.groupBy { it.section }.forEach { (sec, list) ->
                    item(key = "h_$sec") { Text("$sec (${list.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp)) }
                    items(list.take(40)) { h ->
                        Card(onClick = { nav.navigate(h.route) }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(h.icon, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(h.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (h.sub.isNotBlank()) Text(h.sub, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
//                            حاسبة الزكاة
// =====================================================================
@Composable
fun ZakatScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val data by produceState(FinData()) { value = loadFin(dao) }
    var cash by remember { mutableStateOf("") }
    var useAccounts by remember { mutableStateOf(true) }
    var useReceivables by remember { mutableStateOf(true) }
    var gold24 by remember { mutableStateOf("") }
    var gold21 by remember { mutableStateOf("") }
    var gold18 by remember { mutableStateOf("") }
    var silver by remember { mutableStateOf("") }
    var trade by remember { mutableStateOf("") }
    var stocks by remember { mutableStateOf("") }
    var other by remember { mutableStateOf("") }
    var debtsDue by remember { mutableStateOf("") }
    var price24 by remember { mutableStateOf(Extras.goldPrice24.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var priceSilver by remember { mutableStateOf(Extras.silverPrice.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var nisabBy by remember { mutableIntStateOf(0) }
    var hawl by remember { mutableStateOf(Extras.zakatHawl.takeIf { it > 0 }) }
    var useAssets by remember { mutableStateOf(true) }

    val d = data.all
    val accBal = data.accounts.sumOf { a -> accountBalance(data.accTx.filter { it.accountId == a.id }) }.coerceAtLeast(0.0)
    val recv = loanSummaries(d.loanTx).sumOf { it.balance.coerceAtLeast(0.0) } + d.sales.sumOf { s -> saleRemaining(s, d.salePayments.filter { it.saleId == s.id }) }
    val p24 = Fmt.parse(price24) ?: 0.0
    val pS = Fmt.parse(priceSilver) ?: 0.0
    fun v(s: String) = Fmt.parse(s) ?: 0.0
    val goldPure = v(gold24) + v(gold21) * 21 / 24 + v(gold18) * 18 / 24
    val goldValue = goldPure * p24
    val silverValue = v(silver) * pS
    val assetsZ = Assets.zakatableValue(data.assets)
    val total = v(cash) + (if (useAccounts) accBal else 0.0) + (if (useAssets) assetsZ else 0.0) + (if (useReceivables) recv else 0.0) + goldValue + silverValue + v(trade) + v(stocks) + v(other) - v(debtsDue)
    val nisab = if (nisabBy == 0) 85 * p24 else 595 * pS
    val reached = nisab > 0 && total >= nisab
    val zakat = if (reached) total * 0.025 else 0.0

    ScreenScaffold(title = tr("حاسبة الزكاة", "Zakat calculator"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoBanner(tr(
                "تجب الزكاة إذا بلغ المال النصاب وحال عليه الحول (سنة هجرية). النصاب: قيمة 85 جراماً من الذهب الخالص أو 595 جراماً من الفضة، والمقدار ربع العشر (2.5%). هذه أداة تقديرية، وللحالات الخاصة راجع أهل العلم.",
                "Zakat is due when wealth reaches the nisab and a lunar year passes. Nisab: 85 g gold or 595 g silver; rate 2.5%. Consult a scholar for special cases."
            ))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("الأسعار اليوم", "Today's prices"), fontWeight = FontWeight.Bold)
                    MoneyField(price24, { price24 = it; Fmt.parse(it)?.let { x -> Extras.goldPrice24 = x } }, tr("سعر جرام الذهب عيار 24", "Gold 24k per gram"))
                    MoneyField(priceSilver, { priceSilver = it; Fmt.parse(it)?.let { x -> Extras.silverPrice = x } }, tr("سعر جرام الفضة (اختياري)", "Silver per gram (optional)"))
                    var metalBusy by remember { mutableStateOf(false) }
                    val zScope = rememberCoroutineScope()
                    val zCtx = LocalContext.current
                    OutlinedButton(onClick = {
                        metalBusy = true
                        zScope.launch {
                            val ok = Metals.refresh(true)
                            metalBusy = false
                            if (ok) { price24 = Fmt.plain(Extras.goldPrice24); priceSilver = Fmt.plain(Extras.silverPrice); Metals.auto = true }
                            else toast(zCtx, tr("تعذّر جلب الأسعار، تحقق من الاتصال", "Couldn't fetch prices, check your connection"))
                        }
                    }, enabled = !metalBusy, modifier = Modifier.fillMaxWidth()) {
                        if (metalBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.Refresh, null)
                        Spacer(Modifier.width(6.dp)); Text(tr("جلب سعر اليوم من الإنترنت", "Fetch today's price online") + " (" + Metals.currency + ")")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(nisabBy == 0, { nisabBy = 0 }, label = { Text(tr("النصاب بالذهب", "Gold nisab")) })
                        FilterChip(nisabBy == 1, { nisabBy = 1 }, enabled = pS > 0, label = { Text(tr("النصاب بالفضة", "Silver nisab")) })
                    }
                    Text(tr("أدخل السعر من محل الذهب أو موقع موثوق، لأن الأسعار تتغير يومياً.", "Enter prices from a trusted source; they change daily."), style = MaterialTheme.typography.bodySmall)
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("أموالك", "Your wealth"), fontWeight = FontWeight.Bold)
                    MoneyField(cash, { cash = it }, tr("النقد في اليد والبنوك (خارج التطبيق)", "Cash & bank (outside the app)"))
                    SwitchRow(tr("أرصدة حساباتي في التطبيق", "My in-app account balances"), Fmt.money(accBal), useAccounts) { useAccounts = it }
                    SwitchRow(tr("ديون مرجوّة لي (السلف والتقسيط)", "Collectible receivables"), Fmt.money(recv) + tr(" • تُزكّى الديون التي على مليء باذل", " • only debts likely to be repaid"), useReceivables) { useReceivables = it }
                    if (data.assets.any { it.zakatable && !it.sold }) SwitchRow(tr("أصولي المسجّلة (ذهب، أسهم، عملات...)", "My recorded assets"), Fmt.money(assetsZ) + tr(" • لا تُدخل الذهب يدوياً مرة أخرى إذا سجّلته هنا", " • don't re-enter recorded gold below"), useAssets) { useAssets = it }
                    NumberField(gold24, { gold24 = it }, tr("ذهب عيار 24 (جرام)", "Gold 24k (g)"))
                    NumberField(gold21, { gold21 = it }, tr("ذهب عيار 21 (جرام)", "Gold 21k (g)"))
                    NumberField(gold18, { gold18 = it }, tr("ذهب عيار 18 (جرام)", "Gold 18k (g)"))
                    NumberField(silver, { silver = it }, tr("فضة (جرام)", "Silver (g)"))
                    MoneyField(trade, { trade = it }, tr("عروض التجارة (قيمة البضاعة للبيع)", "Trade goods (sale value)"))
                    MoneyField(stocks, { stocks = it }, tr("أسهم واستثمارات للمتاجرة", "Stocks held for trading"))
                    MoneyField(other, { other = it }, tr("أموال أخرى", "Other"))
                    MoneyField(debtsDue, { debtsDue = it }, tr("يُخصم: ديون حالّة عليك الآن", "Deduct: debts due now"))
                    Text(tr("ذهب الزينة المستعمل فيه خلاف بين العلماء، والأحوط زكاته.", "Worn jewelry: scholars differ; paying is more cautious."), style = MaterialTheme.typography.bodySmall)
                }
            }
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = (if (reached) SuccessGreen else WarnAmber).copy(alpha = 0.12f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    KeyValue(tr("الوعاء الزكوي", "Zakatable wealth"), Fmt.money(total))
                    KeyValue(tr("الذهب الخالص المعادل", "Pure gold equiv."), String.format(java.util.Locale.US, "%.2f g", goldPure))
                    KeyValue(tr("النصاب", "Nisab"), if (nisab > 0) Fmt.money(nisab) else tr("أدخل سعر الذهب", "Enter gold price"))
                    HorizontalDivider()
                    if (nisab <= 0) Text(tr("أدخل سعر الذهب لحساب النصاب", "Enter the gold price"), color = WarnAmber)
                    else if (reached) {
                        Text(tr("الزكاة الواجبة", "Zakat due"), fontWeight = FontWeight.Bold)
                        Text(Fmt.money(zakat), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                    } else Text(tr("لم يبلغ المال النصاب، فلا زكاة فيه.", "Below nisab: no zakat due."), color = WarnAmber, fontWeight = FontWeight.SemiBold)
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr("الحول والتذكير", "Lunar year & reminder"), fontWeight = FontWeight.Bold)
                    DateField(tr("تاريخ بلوغ النصاب (بداية الحول)", "Nisab date (year start)"), hawl, { x -> hawl = x; Extras.zakatHawl = x ?: -1L }, allowClear = true)
                    hawl?.let { h ->
                        val next = Occ.nextHawl(h)
                        Text(tr("موعد الزكاة القادم: ", "Next zakat date: ") + Fmt.date(next) + " (" + com.sho3eb.app.islam.Prayer.hijri(LocalDate.ofEpochDay(next)) + ")", style = MaterialTheme.typography.bodyMedium)
                    }
                    SwitchRow(tr("ذكّرني قبل موعد الزكاة بأسبوع", "Remind me a week before"), null, Extras.zakatRemind) { Extras.zakatRemind = it }
                }
            }
            Button(onClick = {
                shareText(ctx, tr("حساب الزكاة", "Zakat calculation") + "\n" + tr("الوعاء: ", "Wealth: ") + Fmt.money(total) + "\n" + tr("النصاب: ", "Nisab: ") + Fmt.money(nisab) + "\n" + tr("الزكاة: ", "Zakat: ") + Fmt.money(zakat))
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(6.dp)); Text(tr("مشاركة النتيجة", "Share result")) }
        }
    }
}

// ---------------- اختصارات الرئيسية ----------------
@Composable
fun HomeShortcuts(nav: NavController) {
    val items = listOf(
        Triple(Icons.Filled.Dashboard, tr("اللوحة المالية", "Dashboard"), "dashboard"),
        Triple(Icons.Filled.Apartment, tr("العقارات", "Properties"), "props"),
        Triple(Icons.Filled.CreditCard, tr("ديوني", "My debts"), "debts"),
        Triple(Icons.Filled.Engineering, tr("العمال", "Workers"), "workers"),
        Triple(Icons.Filled.Diamond, tr("الأصول", "Assets"), "assets"),
        Triple(Icons.Filled.Groups, tr("تقسيم", "Split"), "splits"),
        Triple(Icons.Filled.DirectionsCar, tr("السيارة", "Car"), "cars"),
        Triple(Icons.Filled.Autorenew, tr("الاشتراكات", "Subs"), "subs"),
        Triple(Icons.Filled.Storefront, tr("المحل", "Shop"), "shop"),
        Triple(Icons.Filled.FolderShared, tr("المستندات", "Docs"), "vault"),
        Triple(Icons.Filled.Insights, tr("المستشار", "Advisor"), "advisor"),
        Triple(Icons.Filled.MenuBook, tr("دفتر البقالة", "Credit book"), "grocery"),
        Triple(Icons.Filled.Restaurant, tr("الوصفات", "Recipes"), "recipes"),
        Triple(Icons.Filled.Bloodtype, tr("السكري", "Diabetes"), "diabetes"),
        Triple(Icons.Filled.Chair, tr("التصميم", "Design"), "design")
    )
    var quick by remember { mutableIntStateOf(0) }
    if (quick > 0) QuickEntryDialog(startVoice = quick == 1, startScan = quick == 2) { quick = 0 }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { quick = 1 }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Mic, null); Spacer(Modifier.width(6.dp)); Text(tr("سجّل بصوتك", "Say it"), maxLines = 1) }
            FilledTonalButton(onClick = { quick = 2 }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.DocumentScanner, null); Spacer(Modifier.width(6.dp)); Text(tr("صوّر فاتورة", "Scan receipt"), maxLines = 1) }
            FilledTonalIconButton(onClick = { quick = 3 }) { Icon(Icons.Filled.Add, null) }
        }
        items.chunked(5).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (icon, label, route) ->
                    Card(onClick = { nav.navigate(route) }, modifier = Modifier.weight(1f)) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(4.dp))
                            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }
                repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun NextOccasionCard(nav: NavController) {
    val next = remember { try { Occ.upcoming().firstOrNull() } catch (_: Exception) { null } }
    val ramadanNow = remember { try { Occ.isRamadan() } catch (_: Exception) { false } }
    if (next == null && !ramadanNow) return
    Card(onClick = { nav.navigate(if (ramadanNow) "ramadan" else "occasions") }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (ramadanNow) "🌙" else next?.def?.emoji ?: "🌙", fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                if (ramadanNow) {
                    Text(tr("رمضان كريم", "Ramadan Kareem"), fontWeight = FontWeight.Bold)
                    Text(tr("الإمساكية والعد التنازلي للإفطار", "Timetable & iftar countdown"), style = MaterialTheme.typography.bodySmall)
                } else next?.let { u ->
                    Text(u.def.name, fontWeight = FontWeight.Bold)
                    Text(if (u.isNow) tr("الآن", "Now") else if (u.daysLeft == 1) tr("غداً", "Tomorrow") else tr("بعد ${u.daysLeft} يوم • ", "In ${u.daysLeft} days • ") + Fmt.date(u.date), style = MaterialTheme.typography.bodySmall)
                }
            }
            Icon(Icons.Filled.ChevronLeft, null)
        }
    }
}
