@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
private fun DChips(content: @Composable RowScope.() -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), content = content)

// =====================================================================
//                              ديوني
// =====================================================================
@Composable
fun DebtsScreen(nav: NavController) {
    val dao = remember { appDao() }
    val debts by flowState(emptyList<Debt>()) { dao.debtsFlow() }
    val txs by flowState(emptyList<DebtTx>()) { dao.debtTxFlow() }
    val items by flowState(emptyList<LivItem>()) { dao.livItemsFlow() }
    var add by remember { mutableStateOf(false) }
    var showClosed by rememberSaveable { mutableStateOf(false) }
    var snowball by rememberSaveable { mutableStateOf(true) }
    val today = LocalDate.now()
    val open = debts.filter { !it.closed && Debts.balance(it, txs) > 0.005 }
    val totalOwed = open.sumOf { Debts.balance(it, txs) }
    val totalPaid = debts.sumOf { Debts.paid(it, txs) }
    val month = LivingAuto.monthRange()
    val dueMonth = open.mapNotNull { d -> Debts.nextDue(d, txs)?.takeIf { it.toEpochDay() <= month.last }?.let { Debts.nextAmount(d, txs) } }.sum()
    val overdue = open.filter { d -> Debts.nextDue(d, txs)?.isBefore(today) == true }
    // ميزانية السداد المقترحة: فائض ديباجة المعيشة الشهري
    val surplus = remember(items) { items.filter { it.kind == Living.INCOME }.sumOf { Living.monthly(it.amount, it.freq) } - items.filter { it.kind == Living.EXPENSE }.sumOf { Living.monthly(it.amount, it.freq) } }
    var budget by rememberSaveable { mutableStateOf("") }
    val budgetVal = Fmt.parse(budget) ?: open.sumOf { if (it.installment > 0) it.installment / it.periodMonths else 0.0 }.let { if (it > 0) it else surplus.coerceAtLeast(0.0) }
    val plan = remember(debts, txs, budgetVal, snowball) { Debts.payoffPlan(debts, txs, budgetVal, snowball) }
    val list = debts.filter { showClosed || (!it.closed && Debts.balance(it, txs) > 0.005) }

    ScreenScaffold(
        title = tr("ديوني (ما عليّ)", "My debts"), onBack = { nav.popBackStack() },
        fab = { ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("دين", "Debt")) }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("إجمالي ما عليّ", "Total I owe"), Fmt.money(totalOwed), Icons.Filled.CreditCard, DangerRed, Modifier.weight(1f))
                    StatCard(tr("مستحق هذا الشهر", "Due this month"), Fmt.money(dueMonth), Icons.Filled.CalendarMonth, WarnAmber, Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("سددت حتى الآن", "Paid so far"), Fmt.money(totalPaid), Icons.Filled.CheckCircle, SuccessGreen, Modifier.weight(1f))
                    StatCard(tr("ديون متأخرة", "Overdue debts"), "${overdue.size}", Icons.Filled.Warning, if (overdue.isEmpty()) SuccessGreen else DangerRed, Modifier.weight(1f))
                }
            }
            if (open.isNotEmpty()) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Insights, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text(tr("خطة السداد المقترحة", "Suggested payoff plan"), fontWeight = FontWeight.Bold)
                        }
                        MoneyField(budget, { budget = it }, tr("المبلغ الشهري المتاح للسداد", "Monthly amount for repayment"))
                        if (budget.isBlank()) Text(
                            tr("القيمة الافتراضية: ", "Default: ") + Fmt.money(budgetVal) + tr(" (مجموع الأقساط أو فائض ديباجة المعيشة)", " (installments or living surplus)"),
                            style = MaterialTheme.typography.bodySmall
                        )
                        DChips {
                            FilterChip(snowball, { snowball = true }, label = { Text(tr("كرة الثلج (الأصغر أولاً)", "Snowball (smallest first)")) })
                            FilterChip(!snowball, { snowball = false }, label = { Text(tr("حسب الأولوية", "By priority")) })
                        }
                        Text(
                            if (snowball) tr("تسدد الحد الأدنى للكل، والزيادة للدين الأصغر حتى ينتهي؛ يمنحك دفعة معنوية سريعة.", "Pay minimums on all, extra to the smallest; quick wins.")
                            else tr("تبدأ بالديون الأعلى أولوية (مثل البنوك أو الأشد إلحاحاً).", "Start with highest-priority debts."),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        plan.forEachIndexed { i, pl ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${i + 1}.", Modifier.width(24.dp), fontWeight = FontWeight.Bold)
                                Column(Modifier.weight(1f)) {
                                    Text(pl.debt.creditor, fontWeight = FontWeight.SemiBold)
                                    Text(Fmt.money(pl.balance), style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    if (pl.months >= 600) tr("لا يكفي المبلغ", "Not enough") else tr("${pl.months} شهر • ", "${pl.months} mo • ") + Fmt.date(pl.finishDate),
                                    style = MaterialTheme.typography.bodySmall, color = if (pl.months >= 600) DangerRed else SuccessGreen
                                )
                            }
                        }
                        plan.maxOfOrNull { it.months }?.takeIf { it < 600 }?.let {
                            Text(tr("🎯 تنتهي كل ديونك خلال $it شهر بإذن الله", "🎯 Debt-free in $it months"), fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr("الديون", "Debts"), Modifier.weight(1f))
                    FilterChip(showClosed, { showClosed = !showClosed }, label = { Text(tr("إظهار المسددة", "Show settled")) })
                }
            }
            if (list.isEmpty()) item { EmptyState(Icons.Filled.CreditCard, tr("لا توجد ديون عليك. سجّل أي دين عليك للبنوك أو الأشخاص لتتابع سداده.", "No debts. Record what you owe to track repayment.")) }
            items(list, key = { it.id }) { d ->
                val bal = Debts.balance(d, txs)
                val tot = Debts.borrowed(d, txs)
                val nd = Debts.nextDue(d, txs)
                val late = nd?.isBefore(today) == true
                val t = Debts.type(d.type)
                Card(onClick = { nav.navigate("debt/${d.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t.emoji, fontSize = 26.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.creditor, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(t.label + " • " + tr("أولوية ", "priority ") + Debts.priorityName(d.priority), style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(Fmt.money(bal), fontWeight = FontWeight.Bold, color = if (bal > 0.005) DangerRed else SuccessGreen)
                                if (bal <= 0.005 || d.closed) StatusChip(tr("مسدد", "Settled"), SuccessGreen)
                                else if (late) StatusChip(tr("متأخر", "Late"), DangerRed)
                            }
                        }
                        if (tot > 0) {
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(progress = { ((tot - bal) / tot).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = SuccessGreen)
                        }
                        nd?.let {
                            Text(tr("القادم: ", "Next: ") + Fmt.money(Debts.nextAmount(d, txs)) + " • " + Fmt.date(it), style = MaterialTheme.typography.bodySmall, color = if (late) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
    if (add) DebtDialog(null, onDismiss = { add = false }) { id -> add = false; nav.navigate("debt/$id") }
}

@Composable
private fun DebtDialog(existing: Debt?, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var creditor by remember { mutableStateOf(existing?.creditor ?: "") }
    var personId by remember { mutableStateOf(existing?.personId) }
    var type by remember { mutableStateOf(existing?.type ?: "PERSON") }
    var amount by remember { mutableStateOf("") }
    var start by remember { mutableStateOf(existing?.startDate ?: Fmt.today()) }
    var due by remember { mutableStateOf(existing?.dueDate) }
    var hasInst by remember { mutableStateOf((existing?.installment ?: 0.0) > 0) }
    var inst by remember { mutableStateOf(existing?.installment?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var period by remember { mutableIntStateOf(existing?.periodMonths ?: 1) }
    var firstDue by remember { mutableStateOf(existing?.firstDue ?: LocalDate.now().plusMonths(1).toEpochDay()) }
    var priority by remember { mutableIntStateOf(existing?.priority ?: 2) }
    var remind by remember { mutableStateOf(existing?.reminderEnabled ?: true) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    val post = remember { mutableStateOf<Long?>(null) }
    val pending = remember { mutableStateListOf<Uri>() }
    val person = people.firstOrNull { it.id == personId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("دين جديد عليّ", "New debt I owe") else tr("تعديل الدين", "Edit debt")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DChips { Debts.types.forEach { t -> FilterChip(type == t.key, { type = t.key }, label = { Text(t.emoji + " " + t.label) }) } }
                OutlinedTextField(creditor, { creditor = it }, label = { Text(tr("الدائن (لمن الدين)", "Creditor")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                PersonSelector(person, tr("أو اختر من جهات الاتصال (اختياري)", "Or pick a contact (optional)")) { personId = it.id; if (creditor.isBlank()) creditor = it.name }
                if (existing == null) {
                    MoneyField(amount, { amount = it }, tr("قيمة الدين", "Debt amount"))
                    DateField(tr("تاريخ الاستدانة", "Borrowed on"), start, { d -> if (d != null) start = d })
                    AccountPickRow(post, tr("إيداع المبلغ في حساب (اختياري)", "Deposit into an account (optional)"))
                    PendingAttachRow(pending)
                }
                SwitchRow(tr("السداد على أقساط", "Pay in installments"), null, hasInst, Icons.Filled.CalendarMonth) { hasInst = it }
                if (hasInst) {
                    MoneyField(inst, { inst = it }, tr("قيمة القسط", "Installment amount"))
                    DChips { Rent.periods.forEach { m -> FilterChip(period == m, { period = m }, label = { Text(Rent.periodName(m)) }) } }
                    DateField(tr("موعد أول قسط", "First installment"), firstDue, { d -> if (d != null) firstDue = d })
                } else {
                    DateField(tr("موعد السداد (اختياري)", "Due date (optional)"), due, { d -> due = d }, allowClear = true)
                }
                Text(tr("الأولوية", "Priority"), style = MaterialTheme.typography.labelLarge)
                DChips { listOf(1, 2, 3).forEach { p -> FilterChip(priority == p, { priority = p }, label = { Text(Debts.priorityName(p)) }) } }
                SwitchRow(tr("تذكيري بموعد السداد", "Remind me"), null, remind, Icons.Filled.NotificationsActive) { remind = it }
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(amount)
                if (creditor.isBlank()) { toast(ctx, tr("أدخل اسم الدائن", "Enter creditor")); return@TextButton }
                if (existing == null && (v == null || v <= 0)) { toast(ctx, tr("أدخل قيمة الدين", "Enter the amount")); return@TextButton }
                val iv = if (hasInst) Fmt.parse(inst) ?: 0.0 else 0.0
                scope.launch {
                    if (existing != null) {
                        dao.updateDebt(existing.copy(creditor = creditor.trim(), personId = personId, type = type, dueDate = if (hasInst) null else due, installment = iv, periodMonths = period, firstDue = if (hasInst) firstDue else null, priority = priority, reminderEnabled = remind, notes = notes.trim()))
                        onSaved(existing.id)
                    } else {
                        val id = dao.insertDebt(Debt(creditor = creditor.trim(), personId = personId, type = type, startDate = start, dueDate = if (hasInst) null else due, installment = iv, periodMonths = period, firstDue = if (hasInst) firstDue else null, priority = priority, reminderEnabled = remind, notes = notes.trim()))
                        val txId = dao.insertDebtTx(DebtTx(debtId = id, type = DebtTx.BORROW, amount = v!!, date = start, note = tr("أصل الدين", "Principal")))
                        Attachments.addAll(ctx, Attachments.DEBT_TX, txId, pending.toList())
                        Posting.post(post.value, AccountTx.SRC_DEBT, txId, true, v, start, tr("دين من ", "Borrowed from ") + creditor.trim())
                        onSaved(id)
                    }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
fun DebtDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val debt by flowState<Debt?>(null, id) { dao.debtFlow(id) }
    val allTx by flowState(emptyList<DebtTx>()) { dao.debtTxFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val linked = rememberLinkedIds(AccountTx.SRC_DEBT)
    var pay by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var delTx by remember { mutableStateOf<DebtTx?>(null) }
    var postTx by remember { mutableStateOf<DebtTx?>(null) }
    val pending = remember { mutableStateListOf<Uri>() }
    val postTo = remember { mutableStateOf(Posting.lastAccount("debt")) }

    val d = debt
    if (d == null) { ScreenScaffold(tr("الدين", "Debt"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val txs = allTx.filter { it.debtId == d.id }
    val bal = Debts.balance(d, allTx)
    val tot = Debts.borrowed(d, allTx)
    val paid = Debts.paid(d, allTx)
    val nd = Debts.nextDue(d, allTx)
    val person = people.firstOrNull { it.id == d.personId }
    var running = 0.0
    val lines = txs.sortedWith(compareBy({ it.date }, { it.id })).map { t -> running += if (t.type == DebtTx.BORROW) t.amount else -t.amount; t to running }.reversed()

    ScreenScaffold(
        title = d.creditor, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(person?.phone, doc = { Docs.debt(d, allTx) }) { c -> Reports.doc(c, Docs.debt(d, allTx)) }
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(Debts.type(d.type).emoji + " " + Debts.type(d.type).label + " • " + tr("أولوية ", "priority ") + Debts.priorityName(d.priority), style = MaterialTheme.typography.bodySmall)
                        Text(Fmt.money(bal), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = if (bal > 0.005) DangerRed else SuccessGreen)
                        Text(tr("المتبقي عليّ", "Remaining"), style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(progress = { if (tot > 0) (paid / tot).toFloat().coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = SuccessGreen)
                        KeyValue(tr("إجمالي الدين", "Total"), Fmt.money(tot))
                        KeyValue(tr("المسدد", "Paid"), Fmt.money(paid), SuccessGreen)
                        if (d.installment > 0) {
                            KeyValue(tr("القسط", "Installment"), Fmt.money(d.installment) + " • " + Rent.periodName(d.periodMonths))
                            KeyValue(tr("الأقساط المتبقية", "Installments left"), "${Debts.remainingInstallments(d, allTx)}")
                        }
                        nd?.let { KeyValue(tr("الاستحقاق القادم", "Next due"), Fmt.money(Debts.nextAmount(d, allTx)) + " • " + Fmt.date(it), if (it.isBefore(LocalDate.now())) DangerRed else androidx.compose.ui.graphics.Color.Unspecified) }
                        if (d.notes.isNotBlank()) Text(d.notes, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { pay = true }, modifier = Modifier.weight(1f), enabled = bal > 0.005) { Icon(Icons.Filled.Payments, null); Spacer(Modifier.width(4.dp)); Text(tr("سداد", "Pay")) }
                    OutlinedButton(onClick = { more = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text(tr("زيادة الدين", "Borrow more")) }
                }
            }
            if (bal <= 0.005 && !d.closed) item {
                OutlinedButton(onClick = { scope.launch { dao.updateDebt(d.copy(closed = true)); toast(ctx, tr("تم إغلاق الدين 🎉", "Debt closed 🎉")) } }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.CheckCircle, null, tint = SuccessGreen); Spacer(Modifier.width(6.dp)); Text(tr("إغلاق الدين كمسدد", "Mark as settled"))
                }
            }
            if (d.closed) item {
                TextButton(onClick = { scope.launch { dao.updateDebt(d.copy(closed = false)) } }, modifier = Modifier.fillMaxWidth()) { Text(tr("إعادة فتح الدين", "Reopen debt")) }
            }
            item { SectionTitle(tr("الحركات", "Transactions")) }
            items(lines, key = { it.first.id }) { (t, after) ->
                val isPay = t.type == DebtTx.PAY
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (isPay) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward, null, tint = if (isPay) SuccessGreen else DangerRed)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text((if (isPay) tr("سداد ", "Paid ") else tr("استدانة ", "Borrowed ")) + Fmt.money(t.amount), fontWeight = FontWeight.SemiBold, color = if (isPay) SuccessGreen else DangerRed)
                            Text(Fmt.date(t.date) + (if (t.note.isNotBlank()) " • " + t.note else "") + tr(" • المتبقي ", " • left ") + Fmt.num(after), style = MaterialTheme.typography.bodySmall)
                        }
                        AttachmentButton(Attachments.DEBT_TX, t.id)
                        PostButton(t.id in linked) { postTx = t }
                        IconButton(onClick = { delTx = t }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                    }
                }
            }
        }
    }

    if (pay) AmountDialog(
        title = tr("سداد إلى ", "Pay ") + d.creditor,
        initial = Debts.nextAmount(d, allTx),
        info = tr("المتبقي: ", "Remaining: ") + Fmt.money(bal),
        maxAmount = bal, pending = pending, postTo = postTo,
        postLabel = tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"),
        onDismiss = { pay = false }
    ) { amount, date, _, note ->
        scope.launch {
            val tid = dao.insertDebtTx(DebtTx(debtId = d.id, type = DebtTx.PAY, amount = amount, date = date, note = note))
            Attachments.addAll(ctx, Attachments.DEBT_TX, tid, pending.toList())
            Posting.setLastAccount("debt", postTo.value)
            Posting.post(postTo.value, AccountTx.SRC_DEBT, tid, false, amount, date, tr("سداد دين ", "Debt payment ") + d.creditor + if (note.isNotBlank()) " - $note" else "")
            pending.clear(); pay = false
            if (bal - amount <= 0.005) { dao.updateDebt(d.copy(closed = true)); toast(ctx, tr("الحمد لله، تم سداد الدين كاملاً 🎉", "Debt fully paid 🎉")) }
        }
    }
    if (more) AmountDialog(
        title = tr("زيادة الدين", "Borrow more"), pending = pending, postTo = postTo,
        postLabel = tr("إيداع في حساب (اختياري)", "Deposit into account (optional)"),
        onDismiss = { more = false }
    ) { amount, date, _, note ->
        scope.launch {
            val tid = dao.insertDebtTx(DebtTx(debtId = d.id, type = DebtTx.BORROW, amount = amount, date = date, note = note))
            Attachments.addAll(ctx, Attachments.DEBT_TX, tid, pending.toList())
            Posting.post(postTo.value, AccountTx.SRC_DEBT, tid, true, amount, date, tr("دين من ", "Borrowed from ") + d.creditor + if (note.isNotBlank()) " - $note" else "")
            if (d.closed) dao.updateDebt(d.copy(closed = false))
            pending.clear(); more = false
        }
    }
    if (edit) DebtDialog(d, onDismiss = { edit = false }) { edit = false }
    if (del) ConfirmDialog(tr("حذف الدين", "Delete debt"), tr("حذف «${d.creditor}» بكل حركاته والحركات المرحّلة منه؟", "Delete with all transactions and posted entries?"), onDismiss = { del = false }) {
        del = false
        scope.launch { txs.forEach { Attachments.deleteFor(Attachments.DEBT_TX, it.id) }; dao.deleteDebtFull(d.id); nav.popBackStack() }
    }
    delTx?.let { t ->
        ConfirmDialog(tr("حذف الحركة", "Delete"), tr("حذف حركة بمبلغ ${Fmt.money(t.amount)}؟", "Delete ${Fmt.money(t.amount)}?"), onDismiss = { delTx = null }) {
            delTx = null
            scope.launch { Attachments.deleteFor(Attachments.DEBT_TX, t.id); dao.deleteLinkedTx(AccountTx.SRC_DEBT, t.id); dao.deleteDebtTx(t.id) }
        }
    }
    postTx?.let { t ->
        val isIn = t.type == DebtTx.BORROW
        PostToAccountDialog(if (isIn) tr("إيداع في حساب", "Deposit") else tr("خصم من حساب", "Withdraw"), isIn, onDismiss = { postTx = null }) { acc ->
            postTx = null
            scope.launch { Posting.post(acc, AccountTx.SRC_DEBT, t.id, isIn, t.amount, t.date, (if (isIn) tr("دين من ", "Borrowed from ") else tr("سداد دين ", "Debt payment ")) + d.creditor); toast(ctx, tr("تم الترحيل", "Posted")) }
        }
    }
}
