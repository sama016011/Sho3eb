package com.sho3eb.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.core.chat.CallBus
import com.sho3eb.app.core.chat.Chat
import com.sho3eb.app.core.chat.ChatService
import com.sho3eb.app.core.chat.Realtime
import com.sho3eb.app.core.chat.Supa
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.first

/** حالة أذونات المكالمات */
object CallPerms {
    fun has(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun notifications(ctx: Context) = Build.VERSION.SDK_INT < 33 || has(ctx, Manifest.permission.POST_NOTIFICATIONS)
    fun mic(ctx: Context) = has(ctx, Manifest.permission.RECORD_AUDIO)
    fun camera(ctx: Context) = has(ctx, Manifest.permission.CAMERA)
    fun overlay(ctx: Context) = Settings.canDrawOverlays(ctx)
    fun fullScreen(ctx: Context) = Build.VERSION.SDK_INT < 34 || ctx.getSystemService(android.app.NotificationManager::class.java).canUseFullScreenIntent()
    fun battery(ctx: Context) = ctx.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    fun runtimeMissing(ctx: Context): List<String> = buildList {
        if (!mic(ctx)) add(Manifest.permission.RECORD_AUDIO)
        if (!camera(ctx)) add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33 && !notifications(ctx)) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun allOk(ctx: Context) = runtimeMissing(ctx).isEmpty() && overlay(ctx) && fullScreen(ctx) && battery(ctx)

    fun openOverlay(ctx: Context) = open(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
    fun openFullScreen(ctx: Context) { if (Build.VERSION.SDK_INT >= 34) open(ctx, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + ctx.packageName))) }
    @android.annotation.SuppressLint("BatteryLife")
    fun openBattery(ctx: Context) { if (!open(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))) open(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
    fun openAppSettings(ctx: Context) = open(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    private fun open(ctx: Context, i: Intent): Boolean = runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
}

/** طلب أذونات المكالمات خطوة بخطوة (يُستدعى عند حفظ إعدادات التواصل) */
@Composable
fun rememberCallPermissionsFlow(): () -> Unit {
    val ctx = LocalContext.current
    var step by remember { mutableStateOf<String?>(null) }
    fun next() {
        step = when {
            !CallPerms.overlay(ctx) -> "overlay"
            !CallPerms.fullScreen(ctx) -> "full"
            !CallPerms.battery(ctx) -> "battery"
            else -> null
        }
    }
    val runtime = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { next() }
    step?.let { st ->
        val (title, body) = when (st) {
            "overlay" -> tr("الظهور فوق التطبيقات", "Display over other apps") to tr("ليظهر الاتصال الوارد مباشرة على الشاشة حتى والتطبيق مغلق. فعّل الخيار لتطبيق Sho3eb ثم ارجع.", "So incoming calls pop up even when the app is closed. Enable it for Sho3eb, then come back.")
            "full" -> tr("إشعارات ملء الشاشة", "Full-screen notifications") to tr("ليظهر الاتصال الوارد بملء الشاشة على شاشة القفل.", "So incoming calls show full-screen on the lock screen.")
            else -> tr("تشغيل في الخلفية", "Run in background") to tr("استثنِ التطبيق من توفير البطارية حتى لا يوقفه الهاتف فتضيع المكالمات.", "Exclude the app from battery optimization so the phone doesn't stop it and miss calls.")
        }
        AlertDialog(onDismissRequest = { step = null }, title = { Text("📞 " + title) }, text = { Text(body) },
            confirmButton = { Button(onClick = {
                when (st) { "overlay" -> CallPerms.openOverlay(ctx); "full" -> CallPerms.openFullScreen(ctx); else -> CallPerms.openBattery(ctx) }
                step = null
            }) { Text(tr("فتح الإعداد", "Open setting")) } },
            dismissButton = { TextButton(onClick = { val cur = st; step = null; if (cur == "overlay") step = if (!CallPerms.fullScreen(ctx)) "full" else if (!CallPerms.battery(ctx)) "battery" else null else if (cur == "full" && !CallPerms.battery(ctx)) step = "battery" }) { Text(tr("لاحقاً", "Later")) } })
    }
    return {
        val miss = CallPerms.runtimeMissing(ctx)
        if (miss.isNotEmpty()) runtime.launch(miss.toTypedArray()) else next()
    }
}

@Composable
fun ChatCallSettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    // تحديث حالة الأذونات عند الرجوع من إعدادات الهاتف
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    val runtime = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val single = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> tick++; if (!ok) CallPerms.openAppSettings(ctx) }

    var tone by remember { mutableStateOf(Chat.callRingtone) }
    val toneName = remember(tone) {
        runCatching { RingtoneManager.getRingtone(ctx, if (tone.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE) else Uri.parse(tone))?.getTitle(ctx) }.getOrNull()
            ?: tr("النغمة الافتراضية", "Default ringtone")
    }
    val pickTone = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            @Suppress("DEPRECATION") val u = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            tone = u?.toString() ?: ""; Chat.callRingtone = tone; CallBus.channel(ctx)
        }
    }
    var vib by remember { mutableStateOf(Chat.callVibrate) }
    var who by remember { mutableStateOf(Chat.callWho) }
    var spk by remember { mutableStateOf(Chat.callSpeakerVideo) }
    var camOff by remember { mutableStateOf(Chat.callStartCamOff) }
    var saver by remember { mutableStateOf(Chat.callDataSaver) }
    var keep by remember { mutableStateOf(Chat.keepConnected) }
    val ver = Chat.version.intValue
    val blocked = remember(ver) { Chat.blocked().toList() }
    var testMsg by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val sharedCopy = Edition.isShared && Supa.configured
    var turn by remember { mutableStateOf(Chat.turnUrl) }
    var tu by remember { mutableStateOf(Chat.turnUser) }
    var tp by remember { mutableStateOf(Chat.turnPass) }

    ScreenScaffold(title = tr("📞 إعدادات المكالمات", "📞 Call settings"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            key(tick) {
                // ===== الأذونات =====
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        SectionTitle(tr("🔐 أذونات الهاتف", "🔐 Phone permissions"))
                        Text(tr("هذه الأذونات ضرورية لوصول المكالمات وعملها باحترافية:", "These are needed for calls to arrive and work properly:"), style = MaterialTheme.typography.bodySmall)
                        PermRow(Icons.Filled.Mic, tr("الميكروفون", "Microphone"), CallPerms.mic(ctx)) { single.launch(Manifest.permission.RECORD_AUDIO) }
                        PermRow(Icons.Filled.Videocam, tr("الكاميرا (مكالمات الفيديو)", "Camera (video calls)"), CallPerms.camera(ctx)) { single.launch(Manifest.permission.CAMERA) }
                        PermRow(Icons.Filled.Notifications, tr("الإشعارات", "Notifications"), CallPerms.notifications(ctx)) { if (Build.VERSION.SDK_INT >= 33) single.launch(Manifest.permission.POST_NOTIFICATIONS) }
                        PermRow(Icons.Filled.Layers, tr("الظهور فوق التطبيقات (لظهور الاتصال الوارد)", "Display over apps (incoming call screen)"), CallPerms.overlay(ctx)) { CallPerms.openOverlay(ctx) }
                        if (Build.VERSION.SDK_INT >= 34) PermRow(Icons.Filled.Fullscreen, tr("إشعارات ملء الشاشة", "Full-screen notifications"), CallPerms.fullScreen(ctx)) { CallPerms.openFullScreen(ctx) }
                        PermRow(Icons.Filled.BatteryChargingFull, tr("العمل في الخلفية (استثناء البطارية)", "Background (battery exception)"), CallPerms.battery(ctx)) { CallPerms.openBattery(ctx) }
                        if (!CallPerms.allOk(ctx)) Button(onClick = {
                            val m = CallPerms.runtimeMissing(ctx)
                            if (m.isNotEmpty()) runtime.launch(m.toTypedArray())
                            else if (!CallPerms.overlay(ctx)) CallPerms.openOverlay(ctx)
                            else if (!CallPerms.fullScreen(ctx)) CallPerms.openFullScreen(ctx)
                            else CallPerms.openBattery(ctx)
                        }, Modifier.fillMaxWidth()) { Text(tr("منح الأذونات الناقصة", "Grant missing permissions")) }
                        else Text(tr("✅ كل الأذونات ممنوحة", "✅ All permissions granted"), color = SuccessGreen, fontWeight = FontWeight.Bold)
                        Text(tr("في هواتف شاومي/أوبو/ريلمي/هواوي: فعّل أيضاً «التشغيل التلقائي» للتطبيق من إعدادات الهاتف.", "On Xiaomi/Oppo/Realme/Huawei also enable \"Autostart\" for the app in phone settings."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // ===== الاتصال الدائم =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    CallSwitchRow(Icons.Filled.Wifi, tr("البقاء متصلاً لاستقبال المكالمات", "Stay connected to receive calls"), keep, tr("ضروري لوصول المكالمات والتطبيق مغلق", "Required to receive calls when the app is closed")) {
                        keep = it; Chat.keepConnected = it; ChatService.apply(ctx)
                    }
                }
            }

            // ===== الرنين =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(tr("🔔 الرنين", "🔔 Ringing"))
                    ListItem(leadingContent = { Icon(Icons.Filled.MusicNote, null) }, headlineContent = { Text(tr("نغمة الرنين", "Ringtone")) }, supportingContent = { Text(toneName) },
                        trailingContent = { TextButton(onClick = {
                            pickTone.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, tr("نغمة مكالمات Sho3eb", "Sho3eb call ringtone"))
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true).putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, if (tone.isBlank()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE) else Uri.parse(tone)))
                        }) { Text(tr("تغيير", "Change")) } })
                    CallSwitchRow(Icons.Filled.Vibration, tr("الاهتزاز عند الرنين", "Vibrate when ringing"), vib) { vib = it; Chat.callVibrate = it; CallBus.channel(ctx) }
                }
            }

            // ===== الخصوصية والحظر =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(tr("🛡️ من يمكنه الاتصال بي", "🛡️ Who can call me"))
                    listOf("all" to tr("الجميع", "Everyone"), "friends" to tr("أصدقائي فقط", "My friends only"), "nobody" to tr("لا أحد", "Nobody")).forEach { (k, l) ->
                        Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(who == k, { who = k; Chat.callWho = k }); Text(l) }
                    }
                    HorizontalDivider()
                    SectionTitle(tr("🚫 المحظورون", "🚫 Blocked"))
                    if (blocked.isEmpty()) Text(tr("لا يوجد محظورون. للحظر: افتح المحادثة ← ⋮ ← حظر.", "No one blocked. To block: open the chat ← ⋮ ← Block."), style = MaterialTheme.typography.bodySmall)
                    blocked.forEach { id ->
                        ListItem(leadingContent = { ChatAvatar(id, 40) }, headlineContent = { Text(Chat.nameOf(id)) },
                            trailingContent = { TextButton(onClick = { Chat.setBlocked(id, false) }) { Text(tr("إلغاء الحظر", "Unblock")) } })
                    }
                }
            }

            // ===== الفيديو والجودة =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    SectionTitle(tr("🎥 الفيديو والجودة", "🎥 Video & quality"))
                    CallSwitchRow(Icons.Filled.VolumeUp, tr("تشغيل مكبر الصوت تلقائياً في مكالمات الفيديو", "Speaker on for video calls"), spk) { spk = it; Chat.callSpeakerVideo = it }
                    CallSwitchRow(Icons.Filled.VideocamOff, tr("بدء مكالمة الفيديو والكاميرا مغلقة", "Start video calls with camera off"), camOff) { camOff = it; Chat.callStartCamOff = it }
                    CallSwitchRow(Icons.Filled.DataSaverOn, tr("توفير البيانات (جودة أقل)", "Data saver (lower quality)"), saver) { saver = it; Chat.callDataSaver = it }
                }
            }

            // ===== التسجيلات =====
            CallRecordingsCard()

            // ===== اختبار =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(tr("🧪 اختبار المكالمات", "🧪 Call test"))
                    Text(tr("يتحقق من الاتصال بالخادم ووصول إشارات الرنين إلى هذا الهاتف.", "Checks the server connection and that ringing signals reach this phone."), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        testing = true; testMsg = ""
                        scope.launch {
                            val sb = StringBuilder()
                            sb.append(if (Supa.configured) "✅ " + tr("الخادم مضبوط", "Server configured") else "❌ " + tr("الخادم غير مضبوط", "Server not configured")).append('\n')
                            val sess = withContext(Dispatchers.IO) { runCatching { Supa.ensureSession() } }
                            sb.append(if (sess.isSuccess) "✅ " + tr("تسجيل الدخول للخادم", "Signed in to server") else "❌ " + tr("تعذر الدخول: ", "Sign-in failed: ") + sess.exceptionOrNull()?.message?.take(120)).append('\n')
                            sb.append(if (Realtime.connected) "✅ " + tr("الاتصال اللحظي يعمل", "Realtime connected") else "⚠️ " + tr("الاتصال اللحظي غير متصل (يُستخدم الاستطلاع الاحتياطي)", "Realtime not connected (fallback polling used)")).append('\n')
                            sb.append(if (Chat.myPhone().isNotBlank()) "✅ " + tr("رقمك: +", "Your phone: +") + Chat.myPhone() else "❌ " + tr("لم تُدخل رقم هاتفك", "No phone number set")).append('\n')
                            val id = "test-" + System.currentTimeMillis()
                            val t0 = System.currentTimeMillis()
                            val sent = withContext(Dispatchers.IO) { runCatching { CallBus.sendNow(Supa.uid, id, "ring", "{}") } }
                            if (sent.isFailure) sb.append("❌ " + tr("تعذر إرسال إشارة: ", "Couldn't send a signal: ") + sent.exceptionOrNull()?.message?.take(160)).append('\n')
                            else {
                                Chat.start()
                                val got = withTimeoutOrNull(12_000) { CallBus.flow.first { it.callId == id } }
                                sb.append(if (got != null) "✅ " + tr("وصلت إشارة الرنين خلال ", "Ring signal arrived in ") + "${(System.currentTimeMillis() - t0) / 100 / 10.0}s"
                                    else "❌ " + tr("لم تصل إشارة الرنين (", "Ring signal didn't arrive (") + Chat.ringError.take(120) + ")").append('\n')
                            }
                            sb.append(if (CallPerms.allOk(ctx)) "✅ " + tr("الأذونات مكتملة", "Permissions complete") else "⚠️ " + tr("بعض الأذونات ناقصة (أعلاه)", "Some permissions are missing (above)"))
                            testMsg = sb.toString(); testing = false
                        }
                    }, enabled = !testing, modifier = Modifier.fillMaxWidth()) { if (testing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text(tr("ابدأ الاختبار", "Run test")) }
                    if (testMsg.isNotBlank()) Text(testMsg, style = MaterialTheme.typography.bodySmall)
                }
            }

            // ===== TURN (للنسخة الأصلية فقط) =====
            if (!sharedCopy) Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(tr("🌐 خادم TURN (متقدم)", "🌐 TURN server (advanced)"))
                    Text(tr("لا علاقة له بوصول الرنين. يلزم فقط إن رنّ الاتصال وتم الرد لكن بلا صوت/صورة (شبكات جوال مختلفة). تُرسل قيمته تلقائياً ضمن نسخ المشاركة.", "Not related to ringing. Needed only if a call is answered but has no audio/video (different mobile networks)."), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(turn, { turn = it }, label = { Text("TURN URL(s)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(tu, { tu = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(tp, { tp = it }, label = { Text("Credential") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row {
                        Button(onClick = { Chat.turnUrl = turn.trim(); Chat.turnUser = tu.trim(); Chat.turnPass = tp.trim(); toast(ctx, tr("تم الحفظ", "Saved")) }) { Text(tr("حفظ", "Save")) }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { turn = "turn:openrelay.metered.ca:443?transport=tcp"; tu = "openrelayproject"; tp = "openrelayproject"; Chat.turnUrl = turn; Chat.turnUser = tu; Chat.turnPass = tp }) { Text(tr("الافتراضي", "Default")) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermRow(icon: ImageVector, label: String, ok: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (ok) SuccessGreen else DangerRed); Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        if (ok) Text("✅") else TextButton(onClick = onFix) { Text(tr("منح", "Grant")) }
    }
}

@Composable
private fun CallSwitchRow(icon: ImageVector, label: String, value: Boolean, sub: String = "", onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) { Text(label); if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        Switch(value, onChange)
    }
}
