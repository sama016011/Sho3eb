package com.sho3eb.app.core

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.CRC32
import java.util.zip.Inflater

/**
 * إنشاء نسخة مستقلة من التطبيق على نفس الهاتف (باسم حزمة مختلف) من داخل التطبيق نفسه:
 * 1) تعديل AndroidManifest.xml الثنائي: تغيير آخر حرف في اسم الحزمة (بنفس الطول) واسم التطبيق الظاهر.
 * 2) إعادة كتابة ملف ZIP مع محاذاة الملفات غير المضغوطة.
 * 3) توقيع الملف بتوقيع APK v2 بمفتاح خاص بالنسخ، مع تضمين إعدادات النسخة.
 */
object ApkCopy {
    private const val EDITION_ID = 0x53484F33          // نفس معرّف ApkEdition
    private const val V2_ID = 0x7109871a
    private const val ALG_RSA_SHA256 = 0x0103
    private val MAGIC = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)
    private const val CHUNK = 1 shl 20

    class CopyError(msg: String) : Exception(msg)

    /** اسم حزمة النسخة: نفس الطول مع تغيير الحرف الأخير */
    fun copyPackage(base: String, n: Int): String {
        val c = ('0' + n)
        val last = base.last()
        val ch = if (last == c) ('a' + n) else c
        return base.dropLast(1) + ch
    }

    private fun le(n: Int) = ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN)
    private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8)
    private fun u32(b: ByteArray, o: Int) = (u16(b, o).toLong() or (u16(b, o + 2).toLong() shl 16))
    private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte() }
    private fun put32(b: ByteArray, o: Int, v: Long) { put16(b, o, (v and 0xffff).toInt()); put16(b, o + 2, ((v shr 16) and 0xffff).toInt()) }

    // ======================= تعديل المانيفست الثنائي =======================
    /** يعيد عدد التعديلات */
    fun patchManifest(axml: ByteArray, base: String, newPkg: String, labelFrom: Int, labelTo: Int): Int {
        var changes = 0
        val newCh = newPkg.last()
        val idx = base.length - 1
        fun shouldReplace(s: String): Boolean {
            if (s == base) return true
            if (!s.startsWith("$base.")) return false
            val rest = s.substring(base.length + 1)
            if (rest.endsWith("PERMISSION")) return true
            return rest.none { it.isUpperCase() }   // مُعرّفات المزوّدات (authorities)؛ أسماء الكلاسات تبقى كما هي
        }
        var pos = 8
        val size = minOf(u32(axml, 4).toInt(), axml.size)
        while (pos + 8 <= size) {
            val type = u16(axml, pos); val hsize = u16(axml, pos + 2); val csize = u32(axml, pos + 4).toInt()
            if (csize <= 0) break
            if (type == 0x0001) {
                val count = u32(axml, pos + 8).toInt()
                val flags = u32(axml, pos + 16)
                val stringsStart = u32(axml, pos + 20).toInt()
                val utf8 = (flags and 0x100L) != 0L
                for (i in 0 until count) {
                    val off = pos + stringsStart + u32(axml, pos + hsize + i * 4).toInt()
                    if (utf8) {
                        var p = off
                        var cl = axml[p].toInt() and 0xff; p++; if (cl and 0x80 != 0) { cl = ((cl and 0x7f) shl 8) or (axml[p].toInt() and 0xff); p++ }
                        var bl = axml[p].toInt() and 0xff; p++; if (bl and 0x80 != 0) { bl = ((bl and 0x7f) shl 8) or (axml[p].toInt() and 0xff); p++ }
                        val s = String(axml, p, bl, Charsets.UTF_8)
                        if (shouldReplace(s)) { axml[p + idx] = newCh.code.toByte(); changes++ }
                    } else {
                        var p = off
                        var len = u16(axml, p); p += 2
                        if (len and 0x8000 != 0) { len = ((len and 0x7fff) shl 16) or u16(axml, p); p += 2 }
                        val s = String(axml, p, len * 2, Charsets.UTF_16LE)
                        if (shouldReplace(s)) { put16(axml, p + idx * 2, newCh.code); changes++ }
                    }
                }
            } else if (type == 0x0102 && labelFrom != 0 && labelTo != 0) {
                val attrStart = u16(axml, pos + 24); val attrSize = u16(axml, pos + 26); val attrCount = u16(axml, pos + 28)
                for (k in 0 until attrCount) {
                    val a = pos + 16 + attrStart + k * attrSize
                    val dataType = axml[a + 15].toInt() and 0xff
                    if (dataType == 0x01 && u32(axml, a + 16).toInt() == labelFrom) { put32(axml, a + 16, labelTo.toLong() and 0xffffffffL); changes++ }
                }
            }
            pos += csize
        }
        return changes
    }

    // ======================= بناء النسخة =======================
    private class Entry(val name: String, val cd: ByteArray, val localOff: Long, val method: Int, val compSize: Long, val flags: Int)

    fun build(src: File, out: File, base: String, newPkg: String, labelFrom: Int, labelTo: Int, editionJson: String,
              keyPk8: ByteArray, certDer: ByteArray, onProgress: (Int) -> Unit = {}) {
        val tmp = File(out.parentFile, out.name + ".entries")
        RandomAccessFile(src, "r").use { f ->
            val len = f.length()
            val scan = minOf(len, 65_557L).toInt()
            val tail = ByteArray(scan); f.seek(len - scan); f.readFully(tail)
            var e = -1
            for (i in scan - 22 downTo 0) if (tail[i] == 0x50.toByte() && tail[i + 1] == 0x4b.toByte() && tail[i + 2] == 0x05.toByte() && tail[i + 3] == 0x06.toByte()) { e = i; break }
            if (e < 0) throw CopyError("EOCD")
            val eocd = tail.copyOfRange(e, scan)
            val cdSize = u32(eocd, 12); val cdOff = u32(eocd, 16)
            val cd = ByteArray(cdSize.toInt()); f.seek(cdOff); f.readFully(cd)
            // قراءة الدليل المركزي
            val entries = mutableListOf<Entry>()
            var p = 0
            while (p + 46 <= cd.size && u32(cd, p) == 0x02014b50L) {
                val nl = u16(cd, p + 28); val el = u16(cd, p + 30); val cl = u16(cd, p + 32)
                val name = String(cd, p + 46, nl, Charsets.UTF_8)
                val rec = cd.copyOfRange(p, p + 46 + nl + el + cl)
                entries += Entry(name, rec, u32(cd, p + 42), u16(cd, p + 10), u32(cd, p + 20), u16(cd, p + 8))
                p += 46 + nl + el + cl
            }
            val sigFile = Regex("^META-INF/(MANIFEST\\.MF|.*\\.(SF|RSA|DSA|EC))$", RegexOption.IGNORE_CASE)
            val kept = entries.filter { !sigFile.matches(it.name) }.sortedBy { it.localOff }
            val newCd = ByteArrayOutputStream()
            var patched = false
            tmp.outputStream().buffered(1 shl 16).use { o ->
                var pos = 0L
                val buf = ByteArray(1 shl 16)
                kept.forEachIndexed { idx, en ->
                    val lh = ByteArray(30); f.seek(en.localOff); f.readFully(lh)
                    if (u32(lh, 0) != 0x04034b50L) throw CopyError("local header")
                    val nl = u16(lh, 26); val el = u16(lh, 28)
                    val nameBytes = ByteArray(nl); f.readFully(nameBytes)
                    val dataStart = en.localOff + 30 + nl + el
                    var method = en.method; var crc = u32(en.cd, 16); var comp = en.compSize; var uncomp = u32(en.cd, 24)
                    var data: ByteArray? = null
                    if (en.name == "AndroidManifest.xml") {
                        val raw = ByteArray(comp.toInt()); f.seek(dataStart); f.readFully(raw)
                        val x = if (method == 8) Inflater(true).run { setInput(raw); val r = ByteArray(uncomp.toInt()); var n = 0; while (n < r.size) { val k = inflate(r, n, r.size - n); if (k <= 0 && (finished() || needsInput())) break; n += k }; end(); r } else raw
                        if (patchManifest(x, base, newPkg, labelFrom, labelTo) == 0) throw CopyError("manifest")
                        data = x; method = 0; comp = x.size.toLong(); uncomp = comp
                        crc = CRC32().apply { update(x) }.value
                        patched = true
                    }
                    // محاذاة الملفات غير المضغوطة (resources.arsc على 4 بايت، ومكتبات .so على 4096)
                    val align = if (method == 0) (if (en.name.endsWith(".so")) 4096 else 4) else 1
                    val pad = ((align - ((pos + 30 + nl) % align)) % align).toInt()
                    val h = ByteArray(30)
                    System.arraycopy(lh, 0, h, 0, 30)
                    put16(h, 6, u16(lh, 6) and 0x8.inv())
                    put16(h, 8, method); put32(h, 14, crc); put32(h, 18, comp); put32(h, 22, uncomp); put16(h, 28, pad)
                    val localNew = pos
                    o.write(h); o.write(nameBytes); if (pad > 0) o.write(ByteArray(pad))
                    pos += 30 + nl + pad
                    if (data != null) { o.write(data); pos += data.size }
                    else {
                        f.seek(dataStart); var left = comp
                        while (left > 0) { val n = f.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (n <= 0) throw CopyError("read"); o.write(buf, 0, n); left -= n }
                        pos += comp
                    }
                    // سجل الدليل المركزي الجديد
                    val r = en.cd.copyOf()
                    put16(r, 8, u16(r, 8) and 0x8.inv()); put16(r, 10, method); put32(r, 16, crc); put32(r, 20, comp); put32(r, 24, uncomp); put32(r, 42, localNew)
                    newCd.write(r)
                    onProgress(5 + idx * 55 / kept.size)
                }
            }
            if (!patched) throw CopyError("no manifest")
            val cdBytes = newCd.toByteArray()
            val entriesLen = tmp.length()
            val newEocd = eocd.copyOf()
            put16(newEocd, 8, kept.size); put16(newEocd, 10, kept.size); put32(newEocd, 12, cdBytes.size.toLong())
            // ===== توقيع v2 =====
            val eocdForDigest = newEocd.copyOf(); put32(eocdForDigest, 16, entriesLen)
            val digest = v2Digest(tmp, cdBytes, eocdForDigest) { onProgress(60 + it * 30 / 100) }
            val block = signingBlock(digest, keyPk8, certDer, editionJson.toByteArray(Charsets.UTF_8))
            put32(newEocd, 16, entriesLen + block.size)
            out.outputStream().buffered(1 shl 16).use { o ->
                tmp.inputStream().use { it.copyTo(o) }
                o.write(block); o.write(cdBytes); o.write(newEocd)
            }
            tmp.delete()
            onProgress(100)
        }
    }

    private fun v2Digest(entries: File, cd: ByteArray, eocd: ByteArray, onProgress: (Int) -> Unit): ByteArray {
        val chunkDigests = ByteArrayOutputStream(); var chunks = 0
        val md = MessageDigest.getInstance("SHA-256")
        fun chunk(b: ByteArray, off: Int, n: Int) {
            md.reset(); md.update(0xa5.toByte()); md.update(le(4).putInt(n).array()); md.update(b, off, n)
            chunkDigests.write(md.digest()); chunks++
        }
        val total = entries.length()
        entries.inputStream().buffered(1 shl 16).use { inp ->
            val buf = ByteArray(CHUNK); var done = 0L
            while (true) {
                var n = 0
                while (n < CHUNK) { val k = inp.read(buf, n, CHUNK - n); if (k <= 0) break; n += k }
                if (n <= 0) break
                chunk(buf, 0, n); done += n
                onProgress((done * 100 / total.coerceAtLeast(1)).toInt())
                if (n < CHUNK) break
            }
        }
        var o = 0; while (o < cd.size) { val n = minOf(CHUNK, cd.size - o); chunk(cd, o, n); o += n }
        chunk(eocd, 0, eocd.size)
        md.reset(); md.update(0x5a.toByte()); md.update(le(4).putInt(chunks).array()); md.update(chunkDigests.toByteArray())
        return md.digest()
    }

    private fun lp(b: ByteArray): ByteArray = le(4 + b.size).putInt(b.size).put(b).array()
    private fun cat(vararg parts: ByteArray): ByteArray = ByteArrayOutputStream().apply { parts.forEach { write(it) } }.toByteArray()
    private fun i32(v: Int) = le(4).putInt(v).array()

    private fun signingBlock(digest: ByteArray, keyPk8: ByteArray, certDer: ByteArray, edition: ByteArray): ByteArray {
        val key: PrivateKey = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyPk8))
        val cert = CertificateFactory.getInstance("X.509").generateCertificate(certDer.inputStream()) as X509Certificate
        val signedData = cat(
            lp(lp(cat(i32(ALG_RSA_SHA256), lp(digest)))),
            lp(lp(cert.encoded)),
            lp(ByteArray(0))
        )
        val sig = Signature.getInstance("SHA256withRSA").run { initSign(key); update(signedData); sign() }
        val signer = cat(lp(signedData), lp(lp(cat(i32(ALG_RSA_SHA256), lp(sig)))), lp(cert.publicKey.encoded))
        val v2 = lp(lp(signer))
        val pairs = listOf(V2_ID to v2, EDITION_ID to edition)
        val pairsLen = pairs.sumOf { 12L + it.second.size }
        val size = pairsLen + 24
        val b = le((size + 8).toInt())
        b.putLong(size)
        pairs.forEach { (id, v) -> b.putLong(v.size + 4L); b.putInt(id); b.put(v) }
        b.putLong(size); b.put(MAGIC)
        return b.array()
    }
}
