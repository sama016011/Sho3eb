@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import kotlin.math.roundToInt

/** عنصر قابل للترتيب */
data class ReorderItem(val id: String, val emoji: String, val label: String)

/** قائمة قابلة للترتيب بالسحب (ضغطة طويلة) أو بالأسهم، مع مفتاح إظهار/إخفاء */
@Composable
fun ReorderList(items: List<ReorderItem>, hidden: Set<String>, onMove: (Int, Int) -> Unit, onToggle: (String) -> Unit) {
    val rowH = 58.dp
    val rowPx = with(LocalDensity.current) { rowH.toPx() }
    var dragIndex by remember { mutableIntStateOf(-1) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    Column {
        items.forEachIndexed { i, it ->
            val dragging = i == dragIndex
            val isHidden = it.id in hidden
            Surface(
                modifier = Modifier.fillMaxWidth().height(rowH).padding(vertical = 3.dp)
                    .graphicsLayer { translationY = if (dragging) dragOffset else 0f; scaleX = if (dragging) 1.03f else 1f; scaleY = if (dragging) 1.03f else 1f }
                    .then(if (dragging) Modifier.shadow(8.dp, MaterialTheme.shapes.medium) else Modifier),
                shape = MaterialTheme.shapes.medium,
                color = if (dragging) MaterialTheme.colorScheme.primaryContainer else if (isHidden) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = if (dragging) 6.dp else 0.dp
            ) {
                Row(Modifier.fillMaxSize().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.DragIndicator, contentDescription = tr("اسحب للترتيب", "Drag to reorder"),
                        modifier = Modifier.size(32.dp).pointerInput(items.size) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = { dragIndex = i; dragOffset = 0f },
                                onDragEnd = { dragIndex = -1; dragOffset = 0f },
                                onDragCancel = { dragIndex = -1; dragOffset = 0f }
                            ) { ch, d ->
                                ch.consume()
                                dragOffset += d.y
                                val steps = (dragOffset / rowPx).roundToInt()
                                val target = (dragIndex + steps).coerceIn(0, items.size - 1)
                                if (target != dragIndex) { onMove(dragIndex, target); dragOffset -= (target - dragIndex) * rowPx; dragIndex = target }
                            }
                        }, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(it.emoji, fontSize = 22.sp, modifier = Modifier.padding(horizontal = 6.dp))
                    Text(it.label, Modifier.weight(1f), fontWeight = if (isHidden) FontWeight.Normal else FontWeight.SemiBold, color = if (isHidden) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface, maxLines = 1)
                    IconButton(onClick = { if (i > 0) onMove(i, i - 1) }, enabled = i > 0, modifier = Modifier.size(34.dp)) { Icon(Icons.Filled.KeyboardArrowUp, null) }
                    IconButton(onClick = { if (i < items.size - 1) onMove(i, i + 1) }, enabled = i < items.size - 1, modifier = Modifier.size(34.dp)) { Icon(Icons.Filled.KeyboardArrowDown, null) }
                    Switch(!isHidden, { _ -> onToggle(it.id) }, modifier = Modifier.padding(start = 4.dp))
                }
            }
        }
    }
}

@Composable
fun HomeEditScreen(nav: NavController) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val secOrder = remember { mutableStateListOf<String>().apply { addAll(HomeLayout.sectionOrder().map { it.id }) } }
    val scOrder = remember { mutableStateListOf<String>().apply { addAll(HomeLayout.shortcutOrder().map { it.id }) } }
    var secHidden by remember { mutableStateOf(HomeLayout.hiddenSections()) }
    var scHidden by remember { mutableStateOf(HomeLayout.hiddenShortcuts()) }
    var cols by remember { mutableIntStateOf(HomeLayout.columns) }
    var compact by remember { mutableStateOf(HomeLayout.compact) }
    var confirmReset by remember { mutableStateOf(false) }
    fun save() { HomeLayout.save(secOrder.toList(), secHidden, scOrder.toList(), scHidden); HomeLayout.columns = cols; HomeLayout.compact = compact }
    ScreenScaffold(
        title = tr("تخصيص الواجهة الرئيسية", "Customize home"), onBack = { save(); nav.popBackStack() },
        actions = {
            IconButton(onClick = { confirmReset = true }) { Icon(Icons.Filled.RestartAlt, contentDescription = tr("استعادة الافتراضي", "Reset")) }
            TextButton(onClick = { save(); toast(ctx, tr("تم الحفظ ✅", "Saved ✅")); nav.popBackStack() }) { Text(tr("حفظ", "Save"), fontWeight = FontWeight.Bold) }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("الأيقونات", "Icons")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("الأقسام", "Sections")) })
                Tab(tab == 2, { tab = 2 }, text = { Text(tr("المعاينة", "Preview")) })
            }
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (tab) {
                    0 -> {
                        Text(tr("فعّل الأيقونات التي تريدها ورتّبها بالسحب (ضغطة طويلة على ⠿) أو بالأسهم.", "Toggle icons and reorder by long-press dragging ⠿ or with the arrows."), style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("عدد الأيقونات في الصف", "Icons per row"), Modifier.weight(1f))
                            listOf(3, 4, 5).forEach { n -> FilterChip(cols == n, { cols = n }, label = { Text("$n") }, modifier = Modifier.padding(start = 4.dp)) }
                        }
                        Row {
                            TextButton(onClick = { scHidden = emptySet() }) { Text(tr("إظهار الكل", "Show all")) }
                            TextButton(onClick = { scHidden = scOrder.toSet() }) { Text(tr("إخفاء الكل", "Hide all")) }
                        }
                        ReorderList(scOrder.mapNotNull { id -> HomeLayout.shortcuts.firstOrNull { it.id == id }?.let { ReorderItem(it.id, it.emoji, it.label) } }, scHidden,
                            onMove = { a, b -> scOrder.add(b, scOrder.removeAt(a)) }, onToggle = { id -> scHidden = if (id in scHidden) scHidden - id else scHidden + id })
                    }
                    1 -> {
                        Text(tr("رتّب أقسام الصفحة الرئيسية وأخفِ ما لا تحتاجه.", "Reorder home sections and hide what you don't need."), style = MaterialTheme.typography.bodySmall)
                        SwitchRow(tr("عرض مضغوط", "Compact view"), tr("مسافات أقل وبطاقات أصغر", "Tighter spacing, smaller cards"), compact) { compact = it }
                        ReorderList(secOrder.mapNotNull { id -> HomeLayout.sections.firstOrNull { it.id == id }?.let { ReorderItem(it.id, it.emoji, it.label) } }, secHidden,
                            onMove = { a, b -> secOrder.add(b, secOrder.removeAt(a)) }, onToggle = { id -> secHidden = if (id in secHidden) secHidden - id else secHidden + id })
                    }
                    else -> {
                        Text(tr("هكذا ستظهر الأيقونات:", "Your icons will look like this:"), style = MaterialTheme.typography.labelLarge)
                        val vis = scOrder.filter { it !in scHidden }.mapNotNull { id -> HomeLayout.shortcuts.firstOrNull { it.id == id } }
                        ShortcutGrid(vis, cols) { }
                        Text(tr("ترتيب الأقسام:", "Section order:"), style = MaterialTheme.typography.labelLarge)
                        secOrder.filter { it !in secHidden }.forEachIndexed { i, id -> HomeLayout.sections.firstOrNull { it.id == id }?.let { Text("${i + 1}. ${it.emoji} ${it.label}") } }
                    }
                }
            }
        }
    }
    if (confirmReset) ConfirmDialog(tr("استعادة الافتراضي", "Reset to default"), tr("سيُعاد ترتيب وإظهار الأيقونات والأقسام كما كانت.", "Icons and sections will return to default."), onDismiss = { confirmReset = false }) {
        confirmReset = false; HomeLayout.reset()
        secOrder.clear(); secOrder.addAll(HomeLayout.sectionOrder().map { it.id }); scOrder.clear(); scOrder.addAll(HomeLayout.shortcutOrder().map { it.id })
        secHidden = HomeLayout.hiddenSections(); scHidden = HomeLayout.hiddenShortcuts(); cols = HomeLayout.columns; compact = HomeLayout.compact
    }
}

/** شبكة الأيقونات */
@Composable
fun ShortcutGrid(list: List<HomeLayout.Shortcut>, cols: Int, onClick: (HomeLayout.Shortcut) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.chunked(cols).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { s ->
                    Card(onClick = { onClick(s) }, modifier = Modifier.weight(1f)) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(38.dp).background(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.shapes.medium), contentAlignment = Alignment.Center) { Text(s.emoji, fontSize = 20.sp) }
                            Spacer(Modifier.height(4.dp))
                            Text(s.label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }
                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
