@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.WarnAmber

@Composable
fun AlarmsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val v = Alarms.version.intValue
    val list = remember(v) { Alarms.schedules }
    var newDlg by remember { mutableStateOf(false) }
    var perms by remember { mutableIntStateOf(0) }
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycle) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) perms++ }
        lifecycle.lifecycle.addObserver(obs); onDispose { lifecycle.lifecycle.removeObserver(obs) }
    }
    ScreenScaffold(title = tr("المنبه وجداول المواعيد", "Alarms & schedules"), onBack = { nav.popBackStack() },
        fab = { ExtendedFloatingActionButton(onClick = { newDlg = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("جدول جديد", "New schedule")) }) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                key(perms) {
                    val exact = Alarms.canExact(ctx); val fs = Alarms.canFullScreen(ctx); val ov = Alarms.canOverlay(ctx)
                    if (!exact || !fs || !ov) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(tr("⚠️ لضمان رنين المنبه في موعده فوق كل شيء فعّل:", "⚠️ To make alarms ring on time above everything, allow:"), fontWeight = FontWeight.Bold)
                            if (!exact) OutlinedButton(onClick = { Alarms.openExactSettings(ctx) }) { Text(tr("المنبهات الدقيقة", "Exact alarms")) }
                            if (!fs) OutlinedButton(onClick = { Alarms.openFullScreenSettings(ctx) }) { Text(tr("الإشعارات بملء الشاشة", "Full-screen notifications")) }
                            if (!ov) OutlinedButton(onClick = { Alarms.openOverlaySettings(ctx) }) { Text(tr("الظهور فوق التطبيقات الأخرى", "Display over other apps")) }
                            Text(tr("💡 واستثنِ التطبيق من «تحسين البطارية» إن توفر في هاتفك.", "💡 Also exclude the app from battery optimization if available."), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            Alarms.upcoming()?.let { (s, i, d) ->
                item {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("⏰", fontSize = 32.sp); Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                val on = MaterialTheme.colorScheme.onPrimary
                                Text(tr("المنبه القادم", "Next alarm"), color = on.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                                Text(i.title.ifBlank { s.name }, color = on, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text(s.emoji + " " + s.name + " • " + Fmt.date(d.toLocalDate().toEpochDay()) + " " + String.format(java.util.Locale.US, "%02d:%02d", d.hour, d.minute), color = on, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            if (list.isEmpty()) item { EmptyState(Icons.Filled.Alarm, tr("أنشئ جدولاً مثل «العلاج» وأضف إليه مواعيد الجرعات بوصف لكل موعد.", "Create a schedule like «Medicine» and add doses with a note for each.")) }
            items(list, key = { it.id }) { s ->
                Card(onClick = { nav.navigate("alarm_edit/${s.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(s.emoji, fontSize = 30.sp); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            if (s.desc.isNotBlank()) Text(s.desc, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(tr("${s.items.count { it.enabled }} موعد مفعّل", "${s.items.count { it.enabled }} active") + (if (s.vibrate) " • 📳" else "") + " • 🔔 " + s.soundName.ifBlank { tr("الافتراضي", "Default") },
                                style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Switch(s.enabled, { Alarms.upsert(ctx, s.copy(enabled = it)) })
                    }
                }
            }
        }
    }
    if (newDlg) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var emoji by remember { mutableStateOf("⏰") }
        AlertDialog(onDismissRequest = { newDlg = false }, title = { Text(tr("جدول جديد", "New schedule")) }, text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("قوالب سريعة", "Quick templates"), style = MaterialTheme.typography.labelLarge)
                FlowRowChips(Alarms.templates.map { it.first + " " + it.second }) { i -> val t = Alarms.templates[i]; emoji = t.first; name = t.second; desc = t.third }
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم الجدول (مثال: العلاج)", "Schedule name (e.g. Medicine)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text(tr("وصف (اختياري)", "Description (optional)")) }, modifier = Modifier.fillMaxWidth())
                HChips { listOf("⏰", "💊", "🩺", "📚", "💼", "🏃", "💧", "🕌", "🍽️", "👶", "🚗", "⭐").forEach { e -> FilterChip(emoji == e, { emoji = e }, label = { Text(e) }) } }
            }
        }, confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                val s = Alarms.Schedule(System.currentTimeMillis(), name.trim(), desc.trim(), emoji)
                Alarms.upsert(ctx, s); newDlg = false; nav.navigate("alarm_edit/${s.id}")
            }) { Text(tr("إنشاء", "Create")) }
        }, dismissButton = { TextButton(onClick = { newDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
}

@Composable
private fun FlowRowChips(labels: List<String>, onClick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        labels.chunked(2).forEachIndexed { r, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { row.forEachIndexed { c, l -> AssistChip(onClick = { onClick(r * 2 + c) }, label = { Text(l) }) } }
        }
    }
}

@Composable
fun AlarmEditScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val v = Alarms.version.intValue
    val s = remember(v) { Alarms.schedule(id) }
    if (s == null) { LaunchedEffect(Unit) { nav.popBackStack() }; return }
    var itemDlg by remember { mutableStateOf<Alarms.Item?>(null) }
    var newItem by remember { mutableStateOf(false) }
    var soundDlg by remember { mutableStateOf(false) }
    var editInfo by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    fun save(n: Alarms.Schedule) = Alarms.upsert(ctx, n)

    ScreenScaffold(title = s.emoji + " " + s.name, onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { editInfo = true }) { Icon(Icons.Filled.Edit, null) }
        IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null) }
    }, fab = { ExtendedFloatingActionButton(onClick = { newItem = true }, icon = { Icon(Icons.Filled.AddAlarm, null) }, text = { Text(tr("موعد", "Alarm")) }) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (s.desc.isNotBlank()) item { Text(s.desc, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        SectionTitle(tr("🔔 الصوت والاهتزاز", "🔔 Sound & vibration"))
                        Row(Modifier.fillMaxWidth().clickable { soundDlg = true }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.MusicNote, null); Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) { Text(tr("نغمة التنبيه", "Alert sound")); Text(s.soundName.ifBlank { tr("نغمة المنبه الافتراضية", "Default alarm sound") }, style = MaterialTheme.typography.bodySmall) }
                            Icon(Icons.Filled.ChevronRight, null)
                        }
                        SwitchRow(tr("الاهتزاز", "Vibration"), null, s.vibrate, Icons.Filled.Vibration) { save(s.copy(vibrate = it)) }
                        SwitchRow(tr("رفع الصوت تدريجياً", "Gradually increase volume"), null, s.ramp, Icons.Filled.TrendingUp) { save(s.copy(ramp = it)) }
                        Text(tr("مستوى الصوت: ${s.volume}%", "Volume: ${s.volume}%"), style = MaterialTheme.typography.bodySmall)
                        var vol by remember(s.id) { mutableFloatStateOf(s.volume.toFloat()) }
                        Slider(vol, { vol = it }, valueRange = 10f..100f, onValueChangeFinished = { save(s.copy(volume = vol.toInt())) })
                        Text(tr("مدة التأجيل", "Snooze length"), style = MaterialTheme.typography.bodySmall)
                        HChips { listOf(5, 10, 15, 30).forEach { m -> FilterChip(s.snooze == m, { save(s.copy(snooze = m)) }, label = { Text(tr("$m د", "$m min")) }) } }
                        OutlinedButton(onClick = { Alarms.test(ctx, s) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(tr("تجربة الرنين الآن", "Test ring now")) }
                    }
                }
            }
            item { SectionTitle(tr("المواعيد (${s.items.size})", "Alarms (${s.items.size})")) }
            if (s.items.isEmpty()) item { EmptyState(Icons.Filled.AlarmAdd, tr("أضف مواعيد لهذا الجدول، لكل موعد وصف خاص (مثال: قرص الضغط بعد الأكل).", "Add alarms; each has its own note (e.g. BP pill after meals).")) }
            items(s.items.sortedBy { it.hour * 60 + it.minute }, key = { it.id }) { i ->
                Card(onClick = { itemDlg = i }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(String.format(java.util.Locale.US, "%02d:%02d", i.hour, i.minute), fontSize = 28.sp, fontWeight = FontWeight.Light,
                            color = if (i.enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(i.title.ifBlank { s.name }, fontWeight = FontWeight.Bold)
                            if (i.note.isNotBlank()) Text(i.note, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(Alarms.describe(i), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        Switch(i.enabled, { on -> save(s.copy(items = s.items.map { x -> if (x.id == i.id) x.copy(enabled = on) else x })) })
                    }
                }
            }
        }
    }
    if (newItem || itemDlg != null) AlarmItemDialog(itemDlg, onDismiss = { newItem = false; itemDlg = null },
        onDelete = { d -> save(s.copy(items = s.items.filter { it.id != d.id })); itemDlg = null }) { it2 ->
        save(s.copy(items = s.items.filter { x -> x.id != it2.id } + it2)); newItem = false; itemDlg = null
        Alarms.next(it2)?.let { d -> toast(ctx, tr("سيرن في ", "Rings on ") + Fmt.date(d.toLocalDate().toEpochDay()) + " " + String.format(java.util.Locale.US, "%02d:%02d", d.hour, d.minute)) }
    }
    if (soundDlg) SoundPickerDialog(s.sound, onDismiss = { soundDlg = false }) { snd -> save(s.copy(sound = snd.uri, soundName = snd.name)); soundDlg = false }
    if (editInfo) {
        var name by remember { mutableStateOf(s.name) }
        var desc by remember { mutableStateOf(s.desc) }
        AlertDialog(onDismissRequest = { editInfo = false }, title = { Text(tr("تعديل الجدول", "Edit schedule")) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true)
                OutlinedTextField(desc, { desc = it }, label = { Text(tr("الوصف", "Description")) })
            }
        }, confirmButton = { TextButton(onClick = { save(s.copy(name = name.trim().ifBlank { s.name }, desc = desc.trim())); editInfo = false }) { Text(tr("حفظ", "Save")) } },
            dismissButton = { TextButton(onClick = { editInfo = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
    if (del) ConfirmDialog(tr("حذف الجدول", "Delete schedule"), tr("حذف «${s.name}» وكل مواعيده؟", "Delete «${s.name}» and all its alarms?"), onDismiss = { del = false }) {
        del = false; Alarms.delete(ctx, s.id); nav.popBackStack()
    }
}

@Composable
private fun AlarmItemDialog(item: Alarms.Item?, onDismiss: () -> Unit, onDelete: (Alarms.Item) -> Unit, onSave: (Alarms.Item) -> Unit) {
    val now = java.time.LocalTime.now()
    var title by remember { mutableStateOf(item?.title ?: "") }
    var note by remember { mutableStateOf(item?.note ?: "") }
    var mode by remember { mutableStateOf(item?.mode ?: Alarms.MODE_DAILY) }
    var days by remember { mutableStateOf(item?.days ?: setOf(6, 7, 1, 2, 3, 4, 5)) }
    var date by remember { mutableStateOf<Long?>(item?.date?.takeIf { it > 0 } ?: Fmt.today()) }
    var every by remember { mutableIntStateOf(item?.everyHours ?: 8) }
    val tp = rememberTimePickerState(item?.hour ?: ((now.hour + 1) % 24), item?.minute ?: 0, is24Hour = false)
    var showTime by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (item == null) tr("موعد جديد", "New alarm") else tr("تعديل الموعد", "Edit alarm")) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showTime = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Schedule, null); Spacer(Modifier.width(8.dp))
                Text(String.format(java.util.Locale.US, "%02d:%02d", tp.hour, tp.minute), fontSize = 26.sp)
            }
            OutlinedTextField(title, { title = it }, label = { Text(tr("العنوان (مثال: دواء الضغط)", "Title (e.g. BP medicine)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(note, { note = it }, label = { Text(tr("وصف الموعد (الجرعة، قبل/بعد الأكل...)", "Note (dose, before/after meals...)")) }, modifier = Modifier.fillMaxWidth())
            Text(tr("التكرار", "Repeat"), style = MaterialTheme.typography.labelLarge)
            HChips {
                listOf(Alarms.MODE_DAILY to tr("يومياً", "Daily"), Alarms.MODE_WEEKLY to tr("أيام محددة", "Weekdays"), Alarms.MODE_ONCE to tr("تاريخ محدد", "Specific date"), Alarms.MODE_INTERVAL to tr("كل عدة ساعات", "Every N hours"))
                    .forEach { (k, l) -> FilterChip(mode == k, { mode = k }, label = { Text(l) }) }
            }
            when (mode) {
                Alarms.MODE_WEEKLY -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Alarms.weekOrder.chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { d -> FilterChip(d in days, { days = if (d in days) days - d else days + d }, label = { Text(Alarms.dayName(d)) }) }
                        }
                    }
                }
                Alarms.MODE_ONCE -> DateField(tr("التاريخ", "Date"), date, { date = it })
                Alarms.MODE_INTERVAL -> HChips { listOf(2, 3, 4, 6, 8, 12).forEach { h -> FilterChip(every == h, { every = h }, label = { Text(tr("كل $h س", "Every $h h")) }) } }
                else -> {}
            }
        }
    }, confirmButton = {
        TextButton(enabled = !(mode == Alarms.MODE_WEEKLY && days.isEmpty()), onClick = {
            onSave(Alarms.Item(item?.id ?: System.currentTimeMillis(), title.trim(), note.trim(), tp.hour, tp.minute, mode, days, date ?: Fmt.today(), true, every))
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = {
        Row {
            if (item != null) TextButton(onClick = { onDelete(item) }) { Text(tr("حذف", "Delete"), color = DangerRed) }
            TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) }
        }
    })
    if (showTime) AlertDialog(onDismissRequest = { showTime = false }, confirmButton = { TextButton(onClick = { showTime = false }) { Text(tr("تم", "OK")) } }, text = { TimePicker(tp) })
}

@Composable
private fun SoundPickerDialog(current: String, onDismiss: () -> Unit, onPick: (Alarms.Sound) -> Unit) {
    val ctx = LocalContext.current
    var ver by remember { mutableIntStateOf(0) }
    val system = remember { Alarms.systemSounds(ctx) }
    val user = remember(ver) { Alarms.userSounds(ctx) }
    var playing by remember { mutableStateOf<android.media.Ringtone?>(null) }
    var q by remember { mutableStateOf("") }
    DisposableEffect(Unit) { onDispose { runCatching { playing?.stop() } } }
    val add = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { Alarms.addUserSound(ctx, u)?.let { toast(ctx, tr("تمت إضافة النغمة", "Sound added")) }; ver++ } }
    fun preview(uri: String) {
        runCatching { playing?.stop() }
        playing = runCatching { android.media.RingtoneManager.getRingtone(ctx, android.net.Uri.parse(uri))?.apply { play() } }.getOrNull()
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("نغمة التنبيه", "Alert sound")) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { add.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.LibraryMusic, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة نغمة من ملفاتك", "Add a sound from your files")) }
            SearchField(q) { q = it }
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                item { SoundRow(Alarms.Sound("", tr("نغمة المنبه الافتراضية", "Default alarm sound")), current.isBlank(), { preview(Alarms.defaultSound().toString()) }) { onPick(it) } }
                if (user.isNotEmpty()) item { Text(tr("نغماتك", "Your sounds"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
                items(user.filter { q.isBlank() || it.name.contains(q, true) }, key = { "u" + it.uri }) { snd ->
                    SoundRow(snd, snd.uri == current, { preview(snd.uri) }, onDelete = { runCatching { java.io.File(android.net.Uri.parse(snd.uri).path ?: "").delete() }; ver++ }) { onPick(it) }
                }
                item { Text(tr("نغمات الجهاز", "Device sounds"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
                items(system.filter { q.isBlank() || it.name.contains(q, true) }, key = { "s" + it.uri }) { snd -> SoundRow(snd, snd.uri == current, { preview(snd.uri) }) { onPick(it) } }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } })
}

@Composable
private fun SoundRow(s: Alarms.Sound, selected: Boolean, onPlay: () -> Unit, onDelete: (() -> Unit)? = null, onPick: (Alarms.Sound) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onPick(s) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, { onPick(s) })
        Text(s.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        IconButton(onClick = onPlay) { Icon(Icons.Filled.PlayCircle, null) }
        if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, null, tint = WarnAmber) }
    }
}
