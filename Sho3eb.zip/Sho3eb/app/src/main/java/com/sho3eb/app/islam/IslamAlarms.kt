package com.sho3eb.app.islam

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.sho3eb.app.R
import com.sho3eb.app.core.AppState
import com.sho3eb.app.core.tr
import com.sho3eb.app.ui.MainActivity
import java.io.File
import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

object IslamNotify {
    const val CH_PRAYER = "sho3eb_prayer"
    const val CH_AZKAR = "sho3eb_azkar"
    const val CH_HADITH = "sho3eb_hadith"
    const val CH_AZAN = "sho3eb_azan_play"
    const val CH_DHIKR = "sho3eb_dhikr"
    const val CH_DHIKR_SILENT = "sho3eb_dhikr_silent"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_PRAYER, tr("مواقيت الصلاة", "Prayer times"), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_AZKAR, tr("تذكير الأذكار", "Azkar reminders"), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_HADITH, tr("حديث نبوي", "Hadith of the moment"), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_DHIKR, tr("تذكير الاستغفار والصلاة على النبي ﷺ", "Istighfar & salawat reminders"), NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_DHIKR_SILENT, tr("تذكير صامت بالذكر", "Silent dhikr reminders"), NotificationManager.IMPORTANCE_LOW).apply { setSound(null, null) })
        nm.createNotificationChannel(NotificationChannel(CH_AZAN, tr("تشغيل الأذان", "Azan playback"), NotificationManager.IMPORTANCE_LOW).apply { setSound(null, null) })
    }

    fun canNotify(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun openApp(ctx: Context, route: String? = null): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (route != null) i.putExtra("route", route)
        return PendingIntent.getActivity(ctx, route?.hashCode() ?: 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun show(ctx: Context, channel: String, id: Int, title: String, text: String, route: String? = null, silent: Boolean = false, actions: List<NotificationCompat.Action> = emptyList()) {
        if (!canNotify(ctx)) return
        val nb = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF0F766E.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx, route))
            .setAutoCancel(true)
            .setSilent(silent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        actions.forEach { nb.addAction(it) }
        val n = nb.build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }
}

/** جدولة تنبيهات الصلاة والأذكار */
object IslamAlarms {
    const val ACTION_PRAYER = "com.sho3eb.app.PRAYER"
    const val ACTION_PRE = "com.sho3eb.app.PRAYER_PRE"
    const val ACTION_AZKAR = "com.sho3eb.app.AZKAR"
    const val ACTION_PRAYED = "com.sho3eb.app.PRAYED"
    const val ACTION_RAMADAN = "com.sho3eb.app.RAMADAN"
    const val ACTION_WIRD = "com.sho3eb.app.WIRD"
    private const val RC_RAMADAN = 7005
    private const val RC_WIRD = 7006
    private const val RC_PRAYER = 7001
    private const val RC_PRE = 7002
    private const val RC_MORNING = 7003
    private const val RC_EVENING = 7004

    private fun pi(ctx: Context, rc: Int, action: String, extra: (Intent) -> Unit = {}): PendingIntent {
        val i = Intent(ctx, IslamAlarmReceiver::class.java).setAction(action)
        extra(i)
        return PendingIntent.getBroadcast(ctx, rc, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun set(ctx: Context, at: Long, p: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    private fun cancel(ctx: Context, rc: Int, action: String) {
        ctx.getSystemService(AlarmManager::class.java)?.cancel(pi(ctx, rc, action))
    }

    fun rescheduleAll(ctx: Context) {
        schedulePrayer(ctx)
        scheduleAzkar(ctx)
        HadithWorker.schedule(ctx)
        DhikrWorker.scheduleAll(ctx)
        scheduleRamadan(ctx)
        scheduleWird(ctx)
    }

    /** تذكير السحور قبل الفجر ودعاء الإفطار عند المغرب في رمضان */
    fun scheduleRamadan(ctx: Context) {
        cancel(ctx, RC_RAMADAN, ACTION_RAMADAN)
        val sOn = com.sho3eb.app.core.Extras.suhoorRemind
        val iOn = com.sho3eb.app.core.Extras.iftarDua
        if (!sOn && !iOn) return
        val z = Prayer.zone()
        val now = ZonedDateTime.now(z)
        for (d in 0..2) {
            val date = now.toLocalDate().plusDays(d.toLong())
            if (!Occ.isRamadan(date)) continue
            val t = Prayer.timesFor(date)
            val events = mutableListOf<Pair<String, ZonedDateTime>>()
            if (sOn) events += "S" to t[Prayer.FAJR].minusMinutes(com.sho3eb.app.core.Extras.suhoorMinutes.toLong())
            if (iOn) events += "I" to t[Prayer.MAGHRIB]
            val e = events.filter { it.second.isAfter(now.plusSeconds(5)) }.minByOrNull { it.second } ?: continue
            set(ctx, Prayer.epochMs(e.second), pi(ctx, RC_RAMADAN, ACTION_RAMADAN) { it.putExtra("k", e.first) })
            return
        }
    }

    /** تذكير ورد الختمة اليومي */
    fun scheduleWird(ctx: Context) {
        cancel(ctx, RC_WIRD, ACTION_WIRD)
        if (!com.sho3eb.app.core.Extras.wirdRemind || com.sho3eb.app.core.Extras.khatmaStart < 0) return
        val z = Prayer.zone()
        val now = ZonedDateTime.now(z)
        var t = LocalDate.now(z).atStartOfDay(z).plusMinutes(com.sho3eb.app.core.Extras.wirdMinute.toLong())
        if (!t.isAfter(now)) t = t.plusDays(1)
        set(ctx, Prayer.epochMs(t), pi(ctx, RC_WIRD, ACTION_WIRD))
    }

    fun schedulePrayer(ctx: Context) {
        cancel(ctx, RC_PRAYER, ACTION_PRAYER)
        cancel(ctx, RC_PRE, ACTION_PRE)
        if (!IslamPrefs.prayerNotify) return
        val z = Prayer.zone()
        val now = ZonedDateTime.now(z)
        var target: Pair<Int, ZonedDateTime>? = null
        loop@ for (d in 0..2) {
            val times = Prayer.timesFor(now.toLocalDate().plusDays(d.toLong()))
            for (k in times.indices) {
                if (IslamPrefs.notifyFor(k) && times[k].isAfter(now.plusSeconds(5))) { target = k to times[k]; break@loop }
            }
        }
        val (k, t) = target ?: return
        set(ctx, Prayer.epochMs(t), pi(ctx, RC_PRAYER, ACTION_PRAYER) { it.putExtra("p", k) })
        val pre = IslamPrefs.preReminder
        if (pre > 0 && k != Prayer.SUNRISE) {
            val preAt = t.minusMinutes(pre.toLong())
            if (preAt.isAfter(now)) set(ctx, Prayer.epochMs(preAt), pi(ctx, RC_PRE, ACTION_PRE) { it.putExtra("p", k) })
        }
    }

    fun scheduleAzkar(ctx: Context) {
        cancel(ctx, RC_MORNING, ACTION_AZKAR)
        cancel(ctx, RC_EVENING, ACTION_AZKAR + "_E")
        if (!IslamPrefs.azkarRemind) return
        val z = Prayer.zone()
        val now = ZonedDateTime.now(z)
        fun nextAt(min: Int): ZonedDateTime {
            var t = LocalDate.now(z).atStartOfDay(z).plusMinutes(min.toLong())
            if (!t.isAfter(now)) t = t.plusDays(1)
            return t
        }
        set(ctx, Prayer.epochMs(nextAt(IslamPrefs.morningMin)), pi(ctx, RC_MORNING, ACTION_AZKAR) { it.putExtra("m", true) })
        set(ctx, Prayer.epochMs(nextAt(IslamPrefs.eveningMin)), pi(ctx, RC_EVENING, ACTION_AZKAR + "_E") { it.putExtra("m", false) })
    }
}

class IslamAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        AppState.lang.value = com.sho3eb.app.Sho3ebApp.instance.prefs.lang
        when (intent.action) {
            IslamAlarms.ACTION_PRAYER -> {
                val k = intent.getIntExtra("p", 0)
                val name = Prayer.names.getOrElse(k) { "" }
                val text = if (k == Prayer.SUNRISE) tr("وقت الشروق في ${IslamPrefs.cityName}", "Sunrise in ${IslamPrefs.cityName}")
                else tr("حان الآن موعد أذان $name حسب التوقيت المحلي لمدينة ${IslamPrefs.cityName}", "It is time for $name prayer in ${IslamPrefs.cityName}")
                val custom = com.sho3eb.app.core.Extras.azanFor(k)
                val path = when {
                    custom == "none" -> ""
                    custom.isNotBlank() && File(custom).exists() -> custom
                    k == Prayer.FAJR && IslamPrefs.fajrAzanPath.isNotBlank() -> IslamPrefs.fajrAzanPath
                    else -> IslamPrefs.azanPath
                }
                val am = ctx.getSystemService(android.media.AudioManager::class.java)
                val muted = com.sho3eb.app.core.Extras.azanSilentInPocket && am != null && am.ringerMode != android.media.AudioManager.RINGER_MODE_NORMAL
                val playAzan = k != Prayer.SUNRISE && path.isNotBlank() && File(path).exists() && !muted
                val ti = PrayerLog.idx(k)
                val actions = if (ti >= 0 && com.sho3eb.app.core.Extras.prayerTrackNotify) listOf(
                    NotificationCompat.Action(0, tr("✓ صليت", "✓ Prayed"), PendingIntent.getBroadcast(ctx, 7100 + k,
                        Intent(ctx, IslamAlarmReceiver::class.java).setAction(IslamAlarms.ACTION_PRAYED).putExtra("p", k).putExtra("d", LocalDate.now(Prayer.zone()).toEpochDay()),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                ) else emptyList()
                IslamNotify.show(ctx, IslamNotify.CH_PRAYER, 3000 + k, tr("صلاة ", "") + name, text, "prayer", silent = playAzan, actions = actions)
                if (playAzan) AzanService.start(ctx, path, name)
                IslamAlarms.schedulePrayer(ctx)
            }
            IslamAlarms.ACTION_PRE -> {
                val k = intent.getIntExtra("p", 0)
                IslamNotify.show(
                    ctx, IslamNotify.CH_PRAYER, 3100 + k, tr("اقترب موعد الصلاة", "Prayer is near"),
                    tr("بقي ${IslamPrefs.preReminder} دقيقة على أذان ${Prayer.names.getOrElse(k) { "" }}", "${IslamPrefs.preReminder} minutes until ${Prayer.names.getOrElse(k) { "" }}"), "prayer"
                )
            }
            IslamAlarms.ACTION_AZKAR, IslamAlarms.ACTION_AZKAR + "_E" -> {
                val morning = intent.getBooleanExtra("m", true)
                IslamNotify.show(
                    ctx, IslamNotify.CH_AZKAR, if (morning) 3201 else 3202,
                    if (morning) tr("أذكار الصباح ☀️", "Morning Azkar ☀️") else tr("أذكار المساء 🌙", "Evening Azkar 🌙"),
                    if (morning) tr("حان وقت أذكار الصباح، حصّن يومك بذكر الله", "Time for your morning remembrance")
                    else tr("حان وقت أذكار المساء، حصّن ليلتك بذكر الله", "Time for your evening remembrance"),
                    if (morning) "azkar/0" else "azkar/1"
                )
                IslamAlarms.scheduleAzkar(ctx)
            }
            IslamAlarms.ACTION_PRAYED -> {
                val k = intent.getIntExtra("p", 0)
                val day = intent.getLongExtra("d", com.sho3eb.app.core.Fmt.today())
                val i = PrayerLog.idx(k)
                if (i >= 0) PrayerLog.set(day, i, 1)
                NotificationManagerCompat.from(ctx).cancel(3000 + k)
                com.sho3eb.app.core.toast(ctx, tr("تقبّل الله ✅", "May Allah accept ✅"))
            }
            IslamAlarms.ACTION_RAMADAN -> {
                if (intent.getStringExtra("k") == "S") IslamNotify.show(
                    ctx, IslamNotify.CH_PRAYER, 3301, tr("🌙 وقت السحور", "🌙 Suhoor time"),
                    tr("بقي ${com.sho3eb.app.core.Extras.suhoorMinutes} دقيقة على أذان الفجر. «تسحّروا فإن في السحور بركة» (متفق عليه).", "${com.sho3eb.app.core.Extras.suhoorMinutes} min to Fajr. Eat suhoor, for there is blessing in it."), "ramadan"
                ) else IslamNotify.show(
                    ctx, IslamNotify.CH_PRAYER, 3302, tr("🍽️ حان وقت الإفطار", "🍽️ Iftar time"),
                    tr("دعاء الإفطار: «ذهب الظمأ، وابتلّت العروق، وثبت الأجر إن شاء الله» (أبو داود). وللصائم عند فطره دعوة لا تُرد.", "Iftar du'a: “The thirst has gone, the veins are moistened, and the reward is assured, if Allah wills.”"), "ramadan"
                )
                IslamAlarms.scheduleRamadan(ctx)
            }
            IslamAlarms.ACTION_WIRD -> {
                val e = com.sho3eb.app.core.Extras
                if (e.khatmaStart >= 0) {
                    val target = Khatma.todayTarget()
                    if (e.khatmaDone < target.last) IslamNotify.show(
                        ctx, IslamNotify.CH_AZKAR, 3303, tr("📖 وردك اليومي من القرآن", "📖 Your daily Quran portion"),
                        tr("اقرأ من صفحة ${maxOf(e.khatmaDone + 1, target.first)} إلى ${target.last} لتبقى على خطة ختمتك.", "Read pages ${maxOf(e.khatmaDone + 1, target.first)}–${target.last} to stay on track."), "khatma"
                    )
                }
                IslamAlarms.scheduleWird(ctx)
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED,
            "android.intent.action.MY_PACKAGE_REPLACED", "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" ->
                IslamAlarms.rescheduleAll(ctx)
        }
    }
}

/** خدمة تشغيل الأذان */
class AzanService : Service() {
    private var mp: MediaPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val path = intent?.getStringExtra("path") ?: run { stopSelf(); return START_NOT_STICKY }
        val name = intent?.getStringExtra("name") ?: ""
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, AzanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, IslamNotify.CH_AZAN)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(tr("الأذان", "Azan") + " • " + name)
            .setContentText(tr("الله أكبر", "Allahu Akbar"))
            .setContentIntent(IslamNotify.openApp(this, "prayer"))
            .addAction(0, tr("إيقاف", "Stop"), stopPi)
            .setOngoing(true)
            .build()
        try {
            ServiceCompat.startForeground(this, 4001, n, if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        mp?.release()
        handler.removeCallbacksAndMessages(null)
        val preview = intent.getBooleanExtra("preview", false)
        val vol = (com.sho3eb.app.core.Extras.azanVolume.coerceIn(5, 100)) / 100f
        val fade = com.sho3eb.app.core.Extras.azanFadeIn && !preview
        mp = try {
            MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(path)
                setOnCompletionListener { finished(preview) }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepare()
                setVolume(if (fade) vol * 0.15f else vol, if (fade) vol * 0.15f else vol)
                start()
            }
        } catch (e: Exception) {
            stopSelf(); null
        }
        if (fade) {
            for (s in 1..10) handler.postDelayed({ try { val v = vol * (0.15f + 0.085f * s); mp?.setVolume(v, v) } catch (_: Exception) {} }, s * 1000L)
        }
        val short = com.sho3eb.app.core.Extras.azanShortSec
        if (short > 0 && !preview) handler.postDelayed({ finished(false) }, short * 1000L)
        return START_NOT_STICKY
    }

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun finished(preview: Boolean) {
        if (!preview && com.sho3eb.app.core.Extras.azanDuaAfter) IslamNotify.show(
            this, IslamNotify.CH_PRAYER, 3310, tr("🤲 الدعاء بعد الأذان", "🤲 Du'a after the adhan"),
            tr("«اللهم رب هذه الدعوة التامة، والصلاة القائمة، آتِ محمداً الوسيلة والفضيلة، وابعثه مقاماً محموداً الذي وعدته» — من قالها حلّت له شفاعتي يوم القيامة (البخاري).",
                "“O Allah, Lord of this perfect call and established prayer, grant Muhammad al-Wasilah and virtue, and raise him to the praised station You promised him.” (Bukhari)"), "prayer", silent = true
        )
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        mp?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        mp = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.sho3eb.app.AZAN_STOP"
        fun start(ctx: Context, path: String, name: String, preview: Boolean = false) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, AzanService::class.java).putExtra("path", path).putExtra("name", name).putExtra("preview", preview))
            } catch (_: Exception) {
            }
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AzanService::class.java))
        }
    }
}

/** إرسال حديث نبوي كل فترة + تحديث الودجت */
class HadithWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        AppState.lang.value = com.sho3eb.app.Sho3ebApp.instance.prefs.lang
        val h = Content.randomHadith(ctx) ?: return Result.success()
        IslamNotify.show(ctx, IslamNotify.CH_HADITH, 3300, tr("قال رسول الله ﷺ", "The Prophet ﷺ said"), h.first + if (h.second.isNotBlank()) "\n[${h.second}]" else "", "hadith")
        HadithWidget.updateAll(ctx, h)
        return Result.success()
    }

    companion object {
        private const val NAME = "sho3eb_hadith"
        fun schedule(ctx: Context) {
            val hours = IslamPrefs.hadithHours
            val wm = WorkManager.getInstance(ctx)
            if (hours <= 0) { wm.cancelUniqueWork(NAME); return }
            val req = PeriodicWorkRequestBuilder<HadithWorker>(hours.toLong(), TimeUnit.HOURS)
                .setInitialDelay(hours.toLong(), TimeUnit.HOURS).build()
            wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}

/** تذكير دوري بالاستغفار أو الصلاة على النبي ﷺ */
class DhikrWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        AppState.lang.value = com.sho3eb.app.Sho3ebApp.instance.prefs.lang
        val type = inputData.getString("t") ?: ISTIGHFAR
        val now = java.time.LocalTime.now()
        if (inQuiet(now.hour)) return Result.success()
        val (title, body) = message(type)
        val ch = if (IslamPrefs.dhikrSilent) IslamNotify.CH_DHIKR_SILENT else IslamNotify.CH_DHIKR
        IslamNotify.show(ctx, ch, if (type == ISTIGHFAR) 3401 else 3402, title, body, "azkar", silent = IslamPrefs.dhikrSilent)
        return Result.success()
    }

    companion object {
        const val ISTIGHFAR = "ISTIGHFAR"
        const val SALAWAT = "SALAWAT"

        fun inQuiet(h: Int): Boolean {
            val a = IslamPrefs.quietFrom
            val b = IslamPrefs.quietTo
            if (a == b) return false
            return if (a < b) h in a until b else (h >= a || h < b)
        }

        private val istighfar = listOf(
            "أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه",
            "أستغفر الله وأتوب إليه",
            "رب اغفر لي وتب عليّ إنك أنت التواب الرحيم",
            "سبحانك اللهم وبحمدك، أشهد أن لا إله إلا أنت، أستغفرك وأتوب إليك",
            "لا إله إلا أنت سبحانك إني كنت من الظالمين",
            "اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت، أعوذ بك من شر ما صنعت، أبوء لك بنعمتك عليّ، وأبوء بذنبي فاغفر لي، فإنه لا يغفر الذنوب إلا أنت",
            "ربنا ظلمنا أنفسنا وإن لم تغفر لنا وترحمنا لنكونن من الخاسرين",
            "اللهم إنك عفو تحب العفو فاعفُ عني"
        )
        private val istighfarFadl = listOf(
            "قال ﷺ: «والله إني لأستغفر الله وأتوب إليه في اليوم أكثر من سبعين مرة» (البخاري)",
            "قال ﷺ: «يا أيها الناس توبوا إلى الله، فإني أتوب في اليوم إليه مائة مرة» (مسلم)",
            "﴿فَقُلْتُ اسْتَغْفِرُوا رَبَّكُمْ إِنَّهُ كَانَ غَفَّارًا ۝ يُرْسِلِ السَّمَاءَ عَلَيْكُم مِّدْرَارًا﴾ [نوح: 10-11]",
            "سيد الاستغفار: «من قالها من النهار موقناً بها فمات من يومه قبل أن يمسي فهو من أهل الجنة» (البخاري)",
            "﴿وَمَا كَانَ اللَّهُ مُعَذِّبَهُمْ وَهُمْ يَسْتَغْفِرُونَ﴾ [الأنفال: 33]"
        )
        private val salawat = listOf(
            "اللهم صلِّ وسلم وبارك على نبينا محمد",
            "اللهم صلِّ على محمد وعلى آل محمد، كما صليت على إبراهيم وعلى آل إبراهيم، إنك حميد مجيد، اللهم بارك على محمد وعلى آل محمد، كما باركت على إبراهيم وعلى آل إبراهيم، إنك حميد مجيد",
            "صلى الله عليه وسلم",
            "اللهم صلِّ على محمد وعلى أزواجه وذريته، كما صليت على آل إبراهيم، وبارك على محمد وعلى أزواجه وذريته، كما باركت على آل إبراهيم، إنك حميد مجيد"
        )
        private val salawatFadl = listOf(
            "قال ﷺ: «من صلى عليّ صلاة واحدة صلى الله عليه عشراً» (مسلم)",
            "﴿إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ ۚ يَا أَيُّهَا الَّذِينَ آمَنُوا صَلُّوا عَلَيْهِ وَسَلِّمُوا تَسْلِيمًا﴾ [الأحزاب: 56]",
            "قال ﷺ: «البخيل الذي من ذُكرتُ عنده فلم يصلِّ عليّ» (الترمذي وصححه)",
            "قال ﷺ: «إن من أفضل أيامكم يوم الجمعة... فأكثروا عليّ من الصلاة فيه» (أبو داود)"
        )

        fun message(type: String): Pair<String, String> =
            if (type == ISTIGHFAR) tr("🤲 تذكير بالاستغفار", "🤲 Seek forgiveness") to (istighfar.random() + "\n\n" + istighfarFadl.random())
            else {
                val fri = java.time.LocalDate.now().dayOfWeek == java.time.DayOfWeek.FRIDAY
                tr(if (fri) "ﷺ الصلاة على النبي — يوم الجمعة" else "ﷺ الصلاة على النبي", "ﷺ Send blessings on the Prophet") to (salawat.random() + "\n\n" + salawatFadl.random())
            }

        private fun name(type: String) = "sho3eb_dhikr_$type"

        fun schedule(ctx: Context, type: String) {
            val min = if (type == ISTIGHFAR) IslamPrefs.istighfarMin else IslamPrefs.salawatMin
            val wm = WorkManager.getInstance(ctx)
            if (min <= 0) { wm.cancelUniqueWork(name(type)); return }
            val m = maxOf(15, min).toLong()
            // إزاحة بسيطة حتى لا يتزامن التذكيران
            val delay = if (type == ISTIGHFAR) m else m + m / 2
            val req = PeriodicWorkRequestBuilder<DhikrWorker>(m, TimeUnit.MINUTES)
                .setInitialDelay(delay, TimeUnit.MINUTES)
                .setInputData(androidx.work.workDataOf("t" to type))
                .build()
            wm.enqueueUniquePeriodicWork(name(type), ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun scheduleAll(ctx: Context) {
            schedule(ctx, ISTIGHFAR)
            schedule(ctx, SALAWAT)
        }
    }
}

/** ودجت الشاشة الرئيسية: حديث نبوي */
class HadithWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        update(ctx, mgr, ids, Content.randomHadith(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_REFRESH) updateAll(ctx, Content.randomHadith(ctx))
    }

    companion object {
        const val ACTION_REFRESH = "com.sho3eb.app.HADITH_REFRESH"

        fun updateAll(ctx: Context, h: Pair<String, String>?) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, HadithWidget::class.java))
            if (ids.isNotEmpty()) update(ctx, mgr, ids, h)
        }

        private fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray, h: Pair<String, String>?) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_hadith)
            rv.setTextViewText(R.id.w_text, h?.first ?: "")
            rv.setTextViewText(R.id.w_src, h?.second ?: "")
            rv.setOnClickPendingIntent(R.id.w_root, IslamNotify.openApp(ctx, "hadith"))
            val refresh = PendingIntent.getBroadcast(
                ctx, 11, Intent(ctx, HadithWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.w_refresh, refresh)
            ids.forEach { mgr.updateAppWidget(it, rv) }
        }
    }
}
