@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
private fun MenuItem(icon: ImageVector, title: String, subtitle: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconCircle(icon, MaterialTheme.colorScheme.primary, 38.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun MoreScreen(nav: NavController) {
    var about by remember { mutableStateOf(false) }
    var logout by remember { mutableStateOf(false) }
    var exportAll by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    LaunchedEffect(exportAll) {
        if (exportAll) {
            try {
                val f = withContext(Dispatchers.IO) { Xlsx.exportAll(ctx, appDao()) }
                Share.shareFile(ctx, f, Xlsx.MIME, null, false)
            } catch (e: Exception) { toast(ctx, tr("تعذر التصدير", "Export failed")) }
            exportAll = false
        }
    }
    ScreenScaffold(title = tr("المزيد", "More")) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(onClick = { nav.navigate("profile") }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(AppState.photoPath.value, AppState.displayName.value, 60.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(AppState.displayName.value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("@" + appPrefs().username, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(Icons.Filled.Edit, null)
                }
            }
            Card(Modifier.fillMaxWidth()) {
                MenuItem(Icons.Filled.Dashboard, tr("اللوحة المالية الموحدة", "Financial dashboard"), tr("صافي مركزك المالي وكل الأقسام في شاشة واحدة", "Your net position across all sections")) { nav.navigate("dashboard") }
                HorizontalDivider()
                MenuItem(Icons.Filled.Search, tr("البحث الشامل", "Search everything"), tr("ابحث في كل الأقسام مرة واحدة", "Search all sections at once")) { nav.navigate("search") }
            }
            Card(Modifier.fillMaxWidth()) {
                MenuItem(Icons.Filled.Apartment, tr("العقارات والإيجارات", "Properties & rentals"), tr("الوحدات والمستأجرون والعقود والمصروفات", "Units, tenants, leases & expenses")) { nav.navigate("props") }
                HorizontalDivider()
                MenuItem(Icons.Filled.CreditCard, tr("ديوني (ما عليّ)", "My debts"), tr("الديون والأقساط عليّ وخطة السداد", "What I owe & payoff plan")) { nav.navigate("debts") }
                MenuItem(Icons.Filled.Storefront, tr("المحل والمخزون والفواتير", "Shop, stock & invoices"), tr("فواتير بيع وشراء وعروض أسعار، مخزون، أرباح، عملاء وموردون", "Invoices, quotes, stock, profit, customers")) { nav.navigate("shop") }
                MenuItem(Icons.Filled.FolderShared, tr("خزنة المستندات", "Documents vault"), tr("الهوية والجواز والرخص والضمانات مع تذكير الانتهاء", "IDs, passports, warranties with expiry reminders")) { nav.navigate("vault") }
                MenuItem(Icons.Filled.Engineering, tr("العمال واليوميات", "Workers & daily wages"), tr("الحضور والأجور والسلف والمستحقات", "Attendance, wages, advances")) { nav.navigate("workers") }
                MenuItem(Icons.Filled.Diamond, tr("الذهب والاستثمارات والأصول", "Gold, investments & assets"), tr("قيمة المحفظة والأرباح والزكاة", "Portfolio value, profit, zakat")) { nav.navigate("assets") }
                MenuItem(Icons.Filled.Groups, tr("تقسيم المصاريف", "Split expenses"), tr("رحلات وسكن مشترك: من يدين لمن", "Trips & shared costs")) { nav.navigate("splits") }
                MenuItem(Icons.Filled.DirectionsCar, tr("السيارة", "My car"), tr("الوقود والصيانة والتذكيرات", "Fuel, maintenance, reminders")) { nav.navigate("cars") }
                MenuItem(Icons.Filled.Autorenew, tr("الاشتراكات والفواتير الدورية", "Subscriptions & bills"), tr("تذكير قبل الموعد وتسجيل تلقائي", "Reminders & auto-logging")) { nav.navigate("subs") }
                HorizontalDivider()
                MenuItem(Icons.Filled.Calculate, tr("حاسبة الزكاة", "Zakat calculator"), tr("النصاب والحول والتذكير", "Nisab, lunar year & reminder")) { nav.navigate("zakat") }
                MenuItem(Icons.Filled.FamilyRestroom, tr("حاسبة المواريث", "Inheritance calculator"), tr("تقسيم التركة على الفرائض مع الحجب والعول والرد", "Islamic estate shares with exclusion, ‘awl & radd")) { nav.navigate("faraid") }
                HorizontalDivider()
                MenuItem(Icons.Filled.AccountBalanceWallet, tr("الحسابات", "Accounts"), tr("إضافة وصرف المبالغ وكشوف الحساب", "Deposits, withdrawals & statements")) { nav.navigate("accounts") }
                MenuItem(Icons.Filled.ShoppingBasket, tr("مصاريف المعيشة", "Living expenses"), tr("الدخل والمصروفات والميزانية والنصائح", "Income, expenses, budget & advice")) { nav.navigate("living") }
                HorizontalDivider()
                MenuItem(Icons.Filled.People, tr("الأشخاص", "People"), tr("الأعضاء والعملاء والمستلفين", "Members, customers & borrowers")) { nav.navigate("people") }
                HorizontalDivider()
                MenuItem(Icons.Filled.TableChart, tr("تصدير كل البيانات Excel", "Export all data to Excel"), tr("ملف واحد بأوراق لكل قسم", "One workbook, a sheet per section")) { exportAll = true }
                HorizontalDivider()
                MenuItem(Icons.Filled.Settings, tr("الإعدادات", "Settings"), tr("اللغة، الوضع الليلي، التنبيهات، النسخ الاحتياطي", "Language, dark mode, reminders, backup")) { nav.navigate("settings") }
                HorizontalDivider()
                MenuItem(Icons.Filled.AccountCircle, tr("الملف الشخصي", "Profile"), tr("الصورة، الاسم، كلمة المرور", "Photo, name, password")) { nav.navigate("profile") }
                HorizontalDivider()
                MenuItem(Icons.Filled.Info, tr("حول التطبيق", "About")) { about = true }
                HorizontalDivider()
                MenuItem(Icons.AutoMirrored.Filled.Logout, tr("تسجيل الخروج", "Sign out")) { logout = true }
            }
        }
    }
    if (about) AlertDialog(
        onDismissRequest = { about = false },
        icon = { AppLogo(56) },
        title = { Text("Sho3eb 1.0") },
        text = {
            Text(
                tr(
                    "تطبيق لإدارة الجمعيات النقدية والسلف والبيع بالتقسيط باحترافية: تنبيهات بالمواعيد، تقارير PDF ترسل عبر واتساب، نسخ احتياطي، ووضع ليلي.\n\nجميع البيانات محفوظة على جهازك فقط.",
                    "Manage cash associations, personal loans and installment sales: due reminders, PDF reports via WhatsApp, backups and dark mode.\n\nAll data stays on your device."
                )
            )
        },
        confirmButton = { TextButton(onClick = { about = false }) { Text(tr("حسناً", "OK")) } }
    )
    if (logout) ConfirmDialog(
        title = tr("تسجيل الخروج", "Sign out"),
        text = tr("هل تريد تسجيل الخروج؟", "Do you want to sign out?"),
        confirmText = tr("خروج", "Sign out"),
        danger = false,
        onDismiss = { logout = false }
    ) { AppState.loggedIn.value = false }
}

@Composable
fun SettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val prefs = remember { appPrefs() }
    val scope = rememberCoroutineScope()
    var reminders by remember { mutableStateOf(prefs.remindersEnabled) }
    var daysBefore by remember { mutableStateOf(prefs.remindDaysBefore.toString()) }
    var hour by remember { mutableIntStateOf(prefs.remindHour) }
    var bio by remember { mutableStateOf(prefs.biometric) }
    var currency by remember { mutableStateOf(prefs.currency) }
    var cc by remember { mutableStateOf(prefs.countryCode) }
    var confirmRestore by remember { mutableStateOf<android.net.Uri?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { Backup.export(ctx, uri) }
            toast(ctx, if (ok) tr("تم حفظ النسخة الاحتياطية ✅", "Backup saved ✅") else tr("فشل النسخ الاحتياطي", "Backup failed"))
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) confirmRestore = uri
    }

    ScreenScaffold(title = tr("الإعدادات", "Settings"), onBack = { nav.popBackStack() }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ----- المظهر واللغة -----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("اللغة", "Language"))
                    HChips {
                        I18n.languages.forEach { lg ->
                            FilterChip(selected = AppState.lang.value == lg.code, onClick = {
                                prefs.lang = lg.code; AppState.lang.value = lg.code; Notifier.createChannel(ctx)
                            }, label = { Text(lg.name) }, leadingIcon = { Icon(Icons.Filled.Language, null, Modifier.size(18.dp)) })
                        }
                    }
                    SectionTitle(tr("المظهر", "Appearance"))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            Triple("system", tr("تلقائي", "System"), Icons.Filled.BrightnessAuto),
                            Triple("light", tr("فاتح", "Light"), Icons.Filled.LightMode),
                            Triple("dark", tr("ليلي", "Dark"), Icons.Filled.DarkMode)
                        ).forEach { (k, l, ic) ->
                            FilterChip(selected = AppState.theme.value == k, onClick = {
                                prefs.theme = k; AppState.theme.value = k
                            }, label = { Text(l) }, leadingIcon = { Icon(ic, null, Modifier.size(18.dp)) })
                        }
                    }
                }
            }
            // ----- العملة والدولة -----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("العملة والأرقام", "Currency & numbers"))
                    OutlinedTextField(currency, {
                        currency = it; prefs.currency = it.trim(); AppState.currency.value = it.trim()
                    }, label = { Text(tr("رمز العملة (مثال: ر.س، ج.م، د.ك)", "Currency symbol (e.g. SAR, EGP)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(cc, {
                        cc = it.filter { ch -> ch.isDigit() }; prefs.countryCode = cc
                    }, label = { Text(tr("مفتاح الدولة لواتساب (966 السعودية، 20 مصر)", "Country code for WhatsApp (966, 20...)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
            // ----- التنبيهات -----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("التنبيهات", "Reminders"))
                    SwitchRow(tr("تفعيل تنبيهات المدفوعات", "Enable payment reminders"), null, reminders, Icons.Filled.Notifications) {
                        reminders = it; prefs.remindersEnabled = it
                    }
                    NumberField(daysBefore, {
                        daysBefore = it
                        Fmt.parseInt(it)?.let { d -> prefs.remindDaysBefore = d.coerceIn(0, 30) }
                    }, tr("التنبيه قبل الموعد بـ (أيام)", "Remind days before due"))
                    Text(tr("وقت التنبيه اليومي: $hour:00", "Daily reminder time: $hour:00"))
                    Slider(
                        value = hour.toFloat(), onValueChange = { hour = it.toInt() }, valueRange = 6f..22f, steps = 15,
                        onValueChangeFinished = { prefs.remindHour = hour; ReminderWorker.schedule(ctx, hour) }
                    )
                    OutlinedButton(onClick = {
                        ReminderWorker.runNow(ctx)
                        toast(ctx, tr("جاري الفحص وإرسال التنبيهات...", "Checking and sending reminders..."))
                    }) { Icon(Icons.Filled.NotificationsActive, null); Spacer(Modifier.width(8.dp)); Text(tr("تجربة التنبيهات الآن", "Test reminders now")) }
                }
            }
            // ----- الأمان -----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    SectionTitle(tr("الأمان", "Security"))
                    val bioAvailable = remember { Bio.available(ctx) }
                    SwitchRow(
                        tr("الدخول بالبصمة / الوجه", "Biometric sign-in"),
                        if (bioAvailable) null else tr("غير متاح على هذا الجهاز", "Not available on this device"),
                        bio, Icons.Filled.Fingerprint
                    ) { v ->
                        if (!bioAvailable) return@SwitchRow
                        if (v) Bio.prompt(ctx) { bio = true; prefs.biometric = true } else { bio = false; prefs.biometric = false }
                    }
                }
            }
            // ----- رابط مشاركة الكشوف -----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("رابط مشاركة الكشوف", "Statement share link"))
                    var base by remember { mutableStateOf(Extras.shareBaseUrl) }
                    Text(tr("عنوان صفحة العرض التي تفتح الكشوف المرسلة للأعضاء والعملاء. بيانات الكشف تكون داخل الرابط نفسه ولا تُرفع لأي خادم.", "The viewer page that opens statements you send. Statement data lives inside the link itself."), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(base, { base = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text(tr("عنوان صفحة العرض", "Viewer URL")) })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { Extras.shareBaseUrl = base; toast(ctx, tr("تم الحفظ", "Saved")) }) { Text(tr("حفظ", "Save")) }
                        OutlinedButton(onClick = {
                            val url = ShareLink.build(ReportDoc(tr("كشف تجريبي", "Test statement"), tr("تجربة الرابط", "Link test"), listOf(tr("الحالة", "Status") to tr("الرابط يعمل ✅", "Link works ✅")), emptyList()))
                            try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (_: Exception) {}
                        }) { Text(tr("تجربة", "Test")) }
                    }
                }
            }
            // ----- النسخ الاحتياطي -----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("النسخ الاحتياطي", "Backup"))
                    Text(
                        tr("احفظ نسخة من بياناتك في Google Drive أو ملفات الهاتف واستعدها عند تغيير الجهاز.", "Save a copy of your data to Drive or Files and restore it on a new phone."),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { exportLauncher.launch("Sho3eb_backup_${LocalDate.now()}.db") }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Backup, null); Spacer(Modifier.width(6.dp)); Text(tr("نسخ احتياطي", "Backup"))
                        }
                        OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Restore, null); Spacer(Modifier.width(6.dp)); Text(tr("استعادة", "Restore"))
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    confirmRestore?.let { uri ->
        ConfirmDialog(
            title = tr("استعادة نسخة احتياطية", "Restore backup"),
            text = tr("سيتم استبدال كل البيانات الحالية بالنسخة المختارة ثم إعادة تشغيل التطبيق.", "All current data will be replaced and the app will restart."),
            confirmText = tr("استعادة", "Restore"),
            onDismiss = { confirmRestore = null }
        ) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { Backup.import(ctx, uri) }
                if (!ok) toast(ctx, tr("الملف غير صالح", "Invalid backup file"))
            }
        }
    }
}

@Composable
fun ProfileScreen(nav: NavController) {
    val ctx = LocalContext.current
    val prefs = remember { appPrefs() }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(prefs.displayName) }
    var user by remember { mutableStateOf(prefs.username) }
    var phone by remember { mutableStateOf(prefs.phone) }
    var email by remember { mutableStateOf(prefs.email) }
    var showPwd by remember { mutableStateOf(false) }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val path = withContext(Dispatchers.IO) { Photos.copyFromUri(ctx, uri) }
            if (path != null) { prefs.photoPath = path; AppState.photoPath.value = path }
        }
    }

    ScreenScaffold(title = tr("الملف الشخصي", "Profile"), onBack = { nav.popBackStack() }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                Avatar(AppState.photoPath.value, name, 120.dp, Modifier.clip(CircleShape).clickable {
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                })
                SmallFloatingActionButton(onClick = {
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Icon(Icons.Filled.CameraAlt, null) }
            }
            if (AppState.photoPath.value != null) TextButton(onClick = { prefs.photoPath = null; AppState.photoPath.value = null }) {
                Text(tr("إزالة الصورة", "Remove photo"))
            }
            OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Badge, null) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(user, { user = it.trim() }, label = { Text(tr("اسم المستخدم", "Username")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Person, null) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(phone, { phone = it }, label = { Text(tr("رقم الجوال", "Phone")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Phone, null) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                email, { email = it.trim() }, label = { Text(tr("البريد الإلكتروني", "Email")) }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Email, null) }, modifier = Modifier.fillMaxWidth(),
                supportingText = { Text(if (prefs.hasRecovery && email == prefs.email && email.isNotBlank()) tr("✅ مربوط برمز استعادة", "✅ Linked with a recovery code") else tr("للدخول بالبريد واستعادة كلمة المرور", "For email sign-in and password recovery")) },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email)
            )
            Button(onClick = {
                if (name.isBlank() || user.length < 3) { toast(ctx, tr("تحقق من الاسم واسم المستخدم", "Check name and username")); return@Button }
                if (email.isNotBlank() && !Mail.valid(email)) { toast(ctx, tr("البريد الإلكتروني غير صحيح", "Invalid email")); return@Button }
                val emailChanged = email != prefs.email
                prefs.email = email
                if (emailChanged && email.isNotBlank()) Mail.sendRecovery(ctx, prefs)
                prefs.displayName = name.trim(); prefs.phone = phone.trim(); prefs.setUsername(user)
                AppState.displayName.value = name.trim()
                toast(ctx, tr("تم الحفظ", "Saved"))
            }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(tr("حفظ", "Save")) }
            OutlinedButton(onClick = { showPwd = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Lock, null); Spacer(Modifier.width(8.dp)); Text(tr("تغيير كلمة المرور", "Change password"))
            }
            if (prefs.email.isNotBlank()) {
                OutlinedButton(onClick = { Mail.sendRecovery(ctx, prefs) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Key, null); Spacer(Modifier.width(8.dp)); Text(tr("إرسال رمز استعادة جديد إلى بريدي", "Email me a new recovery code"))
                }
                OutlinedButton(onClick = { Mail.sendBackup(ctx, prefs) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Backup, null); Spacer(Modifier.width(8.dp)); Text(tr("إرسال نسخة احتياطية إلى بريدي", "Email me a backup"))
                }
                OutlinedButton(onClick = {
                    scope.launch {
                        try {
                            val f = withContext(Dispatchers.IO) { Xlsx.exportAll(ctx, appDao()) }
                            Mail.compose(ctx, prefs.email, tr("بيانات شعيب Excel", "Sho3eb data (Excel)"), tr("ملف Excel بكل بيانات التطبيق.", "Excel file with all app data."), f, Xlsx.MIME)
                        } catch (e: Exception) { toast(ctx, tr("تعذر التصدير", "Export failed")) }
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.TableChart, null); Spacer(Modifier.width(8.dp)); Text(tr("إرسال كل البيانات Excel إلى بريدي", "Email me all data (Excel)"))
                }
            }
        }
    }

    if (showPwd) {
        var old by remember { mutableStateOf("") }
        var new1 by remember { mutableStateOf("") }
        var new2 by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPwd = false },
            title = { Text(tr("تغيير كلمة المرور", "Change password")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(old, { old = it }, label = { Text(tr("كلمة المرور الحالية", "Current password")) }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    OutlinedTextField(new1, { new1 = it }, label = { Text(tr("كلمة المرور الجديدة", "New password")) }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    OutlinedTextField(new2, { new2 = it }, label = { Text(tr("تأكيد كلمة المرور", "Confirm password")) }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    when {
                        !prefs.verify(prefs.username, old) -> toast(ctx, tr("كلمة المرور الحالية غير صحيحة", "Current password is wrong"))
                        new1.length < 4 -> toast(ctx, tr("كلمة المرور 4 أحرف على الأقل", "At least 4 characters"))
                        new1 != new2 -> toast(ctx, tr("كلمتا المرور غير متطابقتين", "Passwords do not match"))
                        else -> {
                            prefs.setPassword(new1); showPwd = false
                            toast(ctx, tr("تم تغيير كلمة المرور", "Password changed"))
                        }
                    }
                }) { Text(tr("حفظ", "Save")) }
            },
            dismissButton = { TextButton(onClick = { showPwd = false }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
}
