@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.appDao
import com.sho3eb.app.core.tr
import com.sho3eb.app.data.Account
import com.sho3eb.app.data.AccountTx

/** اختيار حساب لترحيل الحركة إليه (اختياري) */
@Composable
fun AccountPickRow(selected: MutableState<Long?>, label: String) {
    val dao = remember { appDao() }
    val accounts by flowState(emptyList<Account>()) { dao.accountsFlow() }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.AccountBalanceWallet, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
        if (accounts.isEmpty()) {
            Text(
                tr("لا توجد حسابات بعد. أنشئ حساباً من قسم الحسابات لترحيل الحركات إليه.", "No accounts yet. Create one in Accounts to post transactions."),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected.value == null, { selected.value = null }, label = { Text(tr("بدون", "None")) })
                accounts.forEach { a -> FilterChip(selected.value == a.id, { selected.value = a.id }, label = { Text(a.name) }) }
            }
        }
    }
}

/** ترحيل حركة موجودة إلى حساب */
@Composable
fun PostToAccountDialog(title: String, isIn: Boolean, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val dao = remember { appDao() }
    val accounts by flowState(emptyList<Account>()) { dao.accountsFlow() }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.AccountBalanceWallet, null) },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (isIn) tr("ستُسجَّل كإضافة (إيداع) في الحساب المختار.", "Will be recorded as a deposit in the selected account.")
                    else tr("ستُسجَّل كصرف (خصم) من الحساب المختار.", "Will be recorded as a withdrawal from the selected account."),
                    style = MaterialTheme.typography.bodySmall
                )
                if (accounts.isEmpty()) Text(tr("لا توجد حسابات. أنشئ حساباً أولاً من قسم الحسابات.", "No accounts. Create one first."))
                accounts.forEach { a ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(a.id) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AccountBalanceWallet, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text(a.name)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/** مجموعة معرّفات الحركات المرحّلة من نوع معين */
@Composable
fun rememberLinkedIds(srcType: String): Set<Long> {
    val dao = remember { appDao() }
    val linked by flowState(emptyList<AccountTx>()) { dao.linkedAccountTxFlow() }
    return remember(linked, srcType) { linked.filter { it.srcType == srcType }.mapNotNull { it.srcId }.toSet() }
}

/** زر الترحيل/مؤشر الترحيل على بطاقة الحركة */
@Composable
fun PostButton(linked: Boolean, onPost: () -> Unit) {
    if (linked) Icon(
        Icons.Filled.AccountBalanceWallet, contentDescription = tr("مرحّلة لحساب", "Posted"),
        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 6.dp).size(20.dp)
    )
    else IconButton(onClick = onPost) {
        Icon(Icons.Filled.PostAdd, contentDescription = tr("ترحيل إلى حساب", "Post to account"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
