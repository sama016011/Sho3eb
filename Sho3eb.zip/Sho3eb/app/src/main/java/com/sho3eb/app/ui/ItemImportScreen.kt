@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ItemImportScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<List<String>>>(emptyList()) }
    var fileName by remember { mutableStateOf("") }
    var map by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var hasHeader by remember { mutableStateOf(true) }
    var kind by remember { mutableStateOf("SALE") }
    var source by remember { mutableStateOf("FILE") }
    var party by remember { mutableStateOf("") }
    var defCat by remember { mutableStateOf("") }
    var update by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ItemImport.Result?>(null) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            busy = true; result = null
            val r = withContext(Dispatchers.IO) { runCatching { ItemImport.read(ctx, u) } }
            busy = false
            r.onSuccess { l -> rows = l; fileName = MediaTools.nameOf(ctx, u); map = l.firstOrNull()?.let { ItemImport.autoMap(it) } ?: emptyMap(); if (map.isEmpty()) { hasHeader = false; map = mapOf("name" to 0, "price" to 1) } }
                .onFailure { toast(ctx, tr("تعذر قراءة الملف. احفظه بصيغة xlsx أو csv.", "Couldn't read the file. Save it as xlsx or csv.")) }
        }
    }
    val cols = rows.maxOfOrNull { it.size } ?: 0
    val header = rows.firstOrNull().orEmpty()
    fun colName(i: Int) = (if (hasHeader) header.getOrNull(i)?.takeIf { it.isNotBlank() } else null) ?: (tr("عمود ", "Column ") + ('A' + i))

    ScreenScaffold(title = tr("📥 استيراد الأصناف", "📥 Import items"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("1️⃣ نوع الأصناف", "1️⃣ Item type"))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(kind == "SALE", { kind = "SALE" }, label = { Text(tr("🛒 منتجات للبيع / تامة الصنع", "🛒 Products for sale / finished")) })
                        FilterChip(kind == "RAW", { kind = "RAW" }, label = { Text(tr("🧱 خامات تصنيع", "🧱 Raw materials")) })
                    }
                    SectionTitle(tr("2️⃣ مصدر القائمة", "2️⃣ Source"))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(source == "FILE", { source = "FILE" }, label = { Text(tr("📊 ملف إكسيل خاص بي", "📊 My Excel file")) })
                        FilterChip(source == "SUPPLIER", { source = "SUPPLIER" }, label = { Text(tr("🚚 قائمة مورد", "🚚 Supplier list")) })
                        FilterChip(source == "CUSTOMER", { source = "CUSTOMER" }, label = { Text(tr("👤 قائمة عميل", "👤 Customer list")) })
                    }
                    if (source != "FILE") OutlinedTextField(party, { party = it }, label = { Text(if (source == "SUPPLIER") tr("اسم المورد", "Supplier name") else tr("اسم العميل", "Customer name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (source == "SUPPLIER") Text(tr("💡 في قائمة المورد يُعتبر السعر سعر شراء (تكلفة) إن لم يوجد عمود تكلفة منفصل.", "💡 In a supplier list the price is treated as your cost unless a cost column exists."), style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { pick.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv", "text/comma-separated-values", "text/plain", "application/vnd.ms-excel", "*/*")) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.UploadFile, null); Spacer(Modifier.width(6.dp)); Text(tr("اختيار ملف Excel / CSV", "Choose Excel / CSV"))
                        }
                        OutlinedButton(onClick = { runCatching { Share.shareFile(ctx, ItemImport.template(ctx), Xlsx.MIME, null, false) } }) { Icon(Icons.Filled.Description, null); Spacer(Modifier.width(4.dp)); Text(tr("نموذج", "Template")) }
                    }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(tr("يقبل ملفات xlsx و csv (من Excel أو Google Sheets أو قائمة أرسلها لك مورد أو عميل). ملفات xls القديمة: احفظها أولاً بصيغة xlsx.", "Accepts xlsx and csv (Excel, Google Sheets, or a list sent by a supplier/customer). Old .xls: save as xlsx first."),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (rows.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionTitle(tr("3️⃣ ربط الأعمدة", "3️⃣ Map columns") + " — " + fileName)
                        SwitchRow(tr("الصف الأول عناوين أعمدة", "First row is a header"), null, hasHeader) { hasHeader = it }
                        ItemImport.fields.forEach { (f, label) ->
                            var open by remember { mutableStateOf(false) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(label, Modifier.weight(1f), fontWeight = if (f == "name") FontWeight.Bold else FontWeight.Normal)
                                Box {
                                    AssistChip({ open = true }, label = { Text(map[f]?.let { colName(it) } ?: tr("— لا شيء —", "— none —"), maxLines = 1, overflow = TextOverflow.Ellipsis) }, modifier = Modifier.widthIn(max = 180.dp))
                                    DropdownMenu(open, { open = false }) {
                                        DropdownMenuItem(text = { Text(tr("— لا شيء —", "— none —")) }, onClick = { map = map - f; open = false })
                                        (0 until cols).forEach { i -> DropdownMenuItem(text = { Text(colName(i)) }, onClick = { map = map + (f to i); open = false }) }
                                    }
                                }
                            }
                        }
                        if (kind == "SALE") OutlinedTextField(defCat, { defCat = it }, label = { Text(tr("تصنيف افتراضي للأصناف بدون تصنيف", "Default category")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        SwitchRow(tr("تحديث الأصناف الموجودة بنفس الاسم أو الكود", "Update existing items with same name/code"), tr("وإلا تُتخطى", "Otherwise skipped"), update) { update = it }
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        val data = if (hasHeader) rows.drop(1) else rows
                        SectionTitle(tr("معاينة (${data.size} صف)", "Preview (${data.size} rows)"))
                        Column(Modifier.horizontalScroll(rememberScrollState())) {
                            data.take(8).forEach { r ->
                                Row {
                                    listOf("name", "price", "cost", "unit", "category").forEach { f ->
                                        Text(map[f]?.let { r.getOrNull(it) } ?: "—", Modifier.width(if (f == "name") 150.dp else 80.dp).padding(2.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
                Button(onClick = {
                    if (map["name"] == null) { toast(ctx, tr("اختر عمود اسم الصنف", "Choose the item name column")); return@Button }
                    busy = true
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { runCatching { ItemImport.import(dao, rows, map, hasHeader, kind, source, party.trim(), update, defCat.trim()) } }
                        busy = false
                        r.onSuccess { result = it }.onFailure { toast(ctx, it.message ?: "") }
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Download, null); Spacer(Modifier.width(6.dp)); Text(tr("استيراد الأصناف", "Import items")) }
                result?.let { r ->
                    Text(tr("✅ تمت إضافة ${r.added} صنف، وتحديث ${r.updated}، وتخطي ${r.skipped}", "✅ Added ${r.added}, updated ${r.updated}, skipped ${r.skipped}"), color = SuccessGreen, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
