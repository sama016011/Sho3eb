package com.sho3eb.app.core

import android.content.Context
import android.net.Uri
import java.io.File
import java.nio.charset.Charset

/** الترجمة النصية للفيديو: قراءة SRT/VTT، ترجمتها للعربية على الجهاز، والدبلجة الصوتية بالنطق */
object Subtitles {
    data class Cue(val start: Long, val end: Long, val text: String)

    fun dir(ctx: Context) = File(ctx.filesDir, "subs").apply { mkdirs() }

    /** قراءة النص مع اكتشاف الترميز (UTF-8 أو Windows-1256 للعربية القديمة) */
    fun readText(ctx: Context, uri: Uri): String {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return ""
        val utf = String(bytes, Charsets.UTF_8)
        if (!utf.contains('�')) return utf.removePrefix("﻿")
        return runCatching { String(bytes, Charset.forName("windows-1256")) }.getOrDefault(utf)
    }

    private fun time(s: String): Long {
        val t = s.trim().replace(',', '.')
        val p = t.split(':')
        return runCatching {
            val (h, m, sec) = when (p.size) { 3 -> Triple(p[0].toLong(), p[1].toLong(), p[2].toDouble()); 2 -> Triple(0L, p[0].toLong(), p[1].toDouble()); else -> Triple(0L, 0L, p[0].toDouble()) }
            ((h * 3600 + m * 60) * 1000 + (sec * 1000).toLong())
        }.getOrDefault(0L)
    }

    /** تحليل SRT أو VTT */
    fun parse(text: String): List<Cue> {
        val out = mutableListOf<Cue>()
        val blocks = text.replace("\r", "").split(Regex("\n\\s*\n"))
        for (b in blocks) {
            val lines = b.lines().filter { it.isNotBlank() }
            val ti = lines.indexOfFirst { it.contains("-->") }
            if (ti < 0) continue
            val (a, z) = lines[ti].split("-->").let { it[0] to it.getOrElse(1) { "" }.trim().split(" ")[0] }
            val body = lines.drop(ti + 1).joinToString("\n").replace(Regex("<[^>]+>"), "").replace(Regex("\\{[^}]*\\}"), "").trim()
            if (body.isNotBlank()) out += Cue(time(a), time(z), body)
        }
        return out.sortedBy { it.start }
    }

    private fun fmt(ms: Long): String = String.format(java.util.Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000)

    fun toSrt(cues: List<Cue>): String = cues.mapIndexed { i, c -> "${i + 1}\n${fmt(c.start)} --> ${fmt(c.end)}\n${c.text}\n" }.joinToString("\n")

    fun save(ctx: Context, name: String, cues: List<Cue>): File {
        val f = File(dir(ctx), name.replace(Regex("[^\\p{L}\\p{N}._-]"), "_").take(60) + ".srt")
        f.writeText(toSrt(cues))
        return f
    }

    /** نسخ ملف ترجمة للتطبيق وتحويله لـ SRT */
    fun importFile(ctx: Context, uri: Uri): Pair<File, List<Cue>>? = runCatching {
        val name = MediaTools.nameOf(ctx, uri).substringBeforeLast('.')
        val cues = parse(readText(ctx, uri))
        if (cues.isEmpty()) return null
        save(ctx, name, cues) to cues
    }.getOrNull()

    /** ترجمة الترجمة إلى لغة أخرى (العربية افتراضياً) على الجهاز */
    suspend fun translate(ctx: Context, cues: List<Cue>, to: String = "ar", onProgress: (Int) -> Unit = {}): List<Cue> {
        val sample = cues.take(15).joinToString(" ") { it.text }
        val from = Translate.detect(sample) ?: "en"
        if (from == to) return cues
        val out = ArrayList<Cue>(cues.size)
        cues.forEachIndexed { i, c ->
            val t = runCatching { Translate.translate(c.text, from, to) }.getOrDefault(c.text)
            out += c.copy(text = t)
            if (i % 10 == 0) onProgress(i * 100 / cues.size)
        }
        onProgress(100)
        return out
    }

    fun mime(name: String) = when (name.substringAfterLast('.').lowercase()) {
        "vtt" -> androidx.media3.common.MimeTypes.TEXT_VTT
        "ass", "ssa" -> androidx.media3.common.MimeTypes.TEXT_SSA
        else -> androidx.media3.common.MimeTypes.APPLICATION_SUBRIP
    }

    /** مواقع ترجمات مجانية */
    fun searchSites(title: String): List<Pair<String, String>> {
        val q = java.net.URLEncoder.encode(title, "UTF-8")
        return listOf(
            "SubDL" to "https://subdl.com/search/$q",
            "OpenSubtitles" to "https://www.opensubtitles.org/ar/search2/sublanguageid-ara/moviename-$q",
            "Subsource" to "https://subsource.net/search/$q"
        )
    }
}
