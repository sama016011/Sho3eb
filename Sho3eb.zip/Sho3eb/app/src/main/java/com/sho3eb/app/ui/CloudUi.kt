package com.sho3eb.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.*
import com.sho3eb.app.core.chat.Chat
import com.sho3eb.app.core.chat.Cloud
import com.sho3eb.app.core.chat.Supa
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** نافذة التحقق من رقم الهاتف برمز يصل عبر SMS أو واتساب */
@Composable
fun PhoneVerifyDialog(phone: String, required: Boolean = Supa.verifyPhone, onDone: (Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var channel by remember { mutableStateOf(Supa.otpChannel) }
    var sent by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var providerMissing by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = { if (!required || providerMissing) onDone(false) },
        icon = { Icon(Icons.Filled.VerifiedUser, null) },
        title = { Text(tr("التحقق من رقم الهاتف", "Verify phone number")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("للتأكد أن الرقم ‎+${Chat.normPhone(phone)} يخصك، سنرسل رمزاً إليه.", "To confirm +${Chat.normPhone(phone)} is yours, we'll send a code to it."), style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(channel == "whatsapp", { channel = "whatsapp" }, label = { Text(tr("واتساب", "WhatsApp")) })
                    FilterChip(channel == "sms", { channel = "sms" }, label = { Text("SMS") })
                }
                if (sent) OutlinedTextField(code, { code = it.filter { c -> c.isDigit() }.take(8) }, label = { Text(tr("الرمز المرسل", "Code")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (msg.isNotBlank()) Text(msg, color = if (msg.startsWith("✅")) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(enabled = !busy, onClick = {
                busy = true; msg = ""
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { if (!sent) Cloud.sendPhoneCode(phone, channel) else Cloud.verifyPhoneCode(phone, code) } }
                    busy = false
                    r.onSuccess { if (!sent) { sent = true; msg = tr("✅ أُرسل الرمز", "✅ Code sent") } else { toast(ctx, tr("✅ تم توثيق رقمك", "✅ Phone verified")); onDone(true) } }
                        .onFailure { e -> msg = Cloud.friendly(e.message ?: ""); if (msg.contains("مزود") || msg.contains("provider")) providerMissing = true }
                }
            }) { Text(if (!sent) tr("إرسال الرمز", "Send code") else tr("تأكيد", "Verify")) }
        },
        dismissButton = { if (!required || providerMissing) TextButton(onClick = { onDone(false) }) { Text(tr("لاحقاً", "Later")) } })
}

/** بطاقة الحساب السحابي والنسخ الاحتياطي */
@Composable
fun CloudAccountCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf("") }
    var auto by remember { mutableStateOf(Extras.b("cloud_auto_backup", true)) }
    var confirmRestore by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SectionTitle(tr("☁️ الحساب والنسخ الاحتياطي", "☁️ Account & backup"))
            if (!Cloud.loggedIn) {
                Text(tr("أنت غير مسجل بحساب سحابي. سجّل الخروج ثم ادخل برقمك وكلمة المرور (أو أنشئ حساباً) لحفظ بياناتك واستعادتها على أي جهاز.", "Not signed in to a cloud account. Sign out and sign in with your phone & password to back up and restore your data on any device."), style = MaterialTheme.typography.bodySmall)
                return@Column
            }
            Text(tr("الحساب: ", "Account: ") + Cloud.loginId.let { if (it.endsWith("@sho3eb.app")) "+" + it.removePrefix("p").substringBefore('@') else it }, style = MaterialTheme.typography.bodyMedium)
            Text(tr("آخر نسخة: ", "Last backup: ") + (if (Cloud.lastBackup > 0) java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.US).format(java.util.Date(Cloud.lastBackup)) else tr("لا يوجد", "none")), style = MaterialTheme.typography.bodySmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("نسخ احتياطي تلقائي يومي", "Daily auto backup"), Modifier.weight(1f)); Switch(auto, { auto = it; Extras.pb("cloud_auto_backup", it) })
            }
            if (busy.isNotBlank()) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(busy, style = MaterialTheme.typography.labelSmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = busy.isBlank(), onClick = {
                    busy = tr("جارٍ رفع بياناتك…", "Uploading your data…")
                    scope.launch { val r = withContext(Dispatchers.IO) { runCatching { Cloud.backup(ctx) } }; busy = ""; toast(ctx, r.fold({ tr("✅ تم حفظ نسخة من كل بياناتك", "✅ Backup saved") }, { Cloud.friendly(it.message ?: "") })) }
                }, modifier = Modifier.weight(1f)) { Text(tr("☁️ نسخ الآن", "☁️ Back up now")) }
                OutlinedButton(enabled = busy.isBlank(), onClick = { confirmRestore = true }, modifier = Modifier.weight(1f)) { Text(tr("⬇️ استعادة", "⬇️ Restore")) }
            }
        }
    }
    if (confirmRestore) AlertDialog(onDismissRequest = { confirmRestore = false }, title = { Text(tr("استعادة البيانات", "Restore data")) },
        text = { Text(tr("ستُستبدل بيانات هذا الجهاز بآخر نسخة محفوظة في حسابك ثم يُعاد تشغيل التطبيق. متابعة؟", "This device's data will be replaced with your latest cloud backup and the app will restart. Continue?")) },
        confirmButton = { Button(onClick = {
            confirmRestore = false; busy = tr("جارٍ تنزيل بياناتك…", "Downloading your data…")
            scope.launch { val r = withContext(Dispatchers.IO) { runCatching { Cloud.restore(ctx) } }; busy = ""; r.onFailure { toast(ctx, tr("لا توجد نسخة أو تعذر التنزيل: ", "No backup or download failed: ") + (it.message ?: "")) } }
        }) { Text(tr("استعادة", "Restore")) } }, dismissButton = { TextButton(onClick = { confirmRestore = false }) { Text(tr("إلغاء", "Cancel")) } })
}

/** إعدادات الخادم كاملة (تغيير/تحديث الخادم بدون تعديل الكود) */
@Composable
fun ServerSettingsCard(onChanged: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(Supa.url) }
    var key by remember { mutableStateOf(Supa.key) }
    var bucket by remember { mutableStateOf(Supa.bucket) }
    var bbucket by remember { mutableStateOf(Supa.backupBucket) }
    var verify by remember { mutableStateOf(Supa.verifyPhone) }
    var channel by remember { mutableStateOf(Supa.otpChannel) }
    var importDlg by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(tr("🖧 إعدادات الخادم", "🖧 Server settings"))
            Text(tr("كل ما يلزم لتغيير الخادم أو تحديثه دون تعديل البرنامج. تُنسخ هذه الإعدادات تلقائياً إلى نسخ المشاركة.", "Everything needed to change/update the server without code changes. Copied into shared editions automatically."), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(url, { url = it.trim() }, label = { Text("Project URL (https://xxxx.supabase.co)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(key, { key = it.trim() }, label = { Text("anon / publishable key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(bucket, { bucket = it.trim() }, label = { Text(tr("حاوية الملفات", "Files bucket")) }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(bbucket, { bbucket = it.trim() }, label = { Text(tr("حاوية النسخ", "Backup bucket")) }, singleLine = true, modifier = Modifier.weight(1f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("اشتراط توثيق رقم الهاتف برسالة", "Require phone verification"))
                    Text(tr("يتطلب ضبط مزود SMS/واتساب (مثل Twilio) في Supabase ← Authentication ← Providers ← Phone", "Needs an SMS/WhatsApp provider (e.g. Twilio) in Supabase ← Authentication ← Providers ← Phone"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(verify, { verify = it })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("قناة الرموز:", "Code channel:"))
                FilterChip(channel == "whatsapp", { channel = "whatsapp" }, label = { Text(tr("واتساب", "WhatsApp")) })
                FilterChip(channel == "sms", { channel = "sms" }, label = { Text("SMS") })
            }
            Button(onClick = {
                Supa.setServer(url, key); Supa.bucket = bucket.ifBlank { "chat" }; Supa.backupBucket = bbucket.ifBlank { "backups" }; Supa.verifyPhone = verify; Supa.otpChannel = channel
                toast(ctx, tr("✅ حُفظت إعدادات الخادم", "✅ Server settings saved")); onChanged()
            }, modifier = Modifier.fillMaxWidth()) { Text(tr("حفظ إعدادات الخادم", "Save server settings")) }
            HorizontalDivider()
            OutlinedButton(onClick = {
                val sql = runCatching { ctx.assets.open("chat_schema.sql").bufferedReader().readText() }.getOrDefault("")
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sql", sql))
                toast(ctx, tr("📋 نُسخت أوامر تجهيز الخادم. الصقها في Supabase ← SQL Editor ثم Run", "📋 Setup SQL copied. Paste in Supabase ← SQL Editor, then Run"))
            }, modifier = Modifier.fillMaxWidth()) { Text(tr("📋 نسخ أوامر تجهيز خادم جديد (SQL)", "📋 Copy new-server setup SQL")) }
            OutlinedButton(onClick = { url.takeIf { it.startsWith("https://") }?.let { u -> ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://supabase.com/dashboard/project/" + u.removePrefix("https://").substringBefore('.'))).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                modifier = Modifier.fillMaxWidth()) { Text(tr("🌐 فتح لوحة Supabase", "🌐 Open Supabase dashboard")) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val j = JSONObject().put("supa_url", Supa.url).put("supa_key", Supa.key).put("supa_bucket", Supa.bucket).put("supa_backup_bucket", Supa.backupBucket)
                        .put("supa_verify_phone", if (Supa.verifyPhone) "1" else "0").put("supa_otp_channel", Supa.otpChannel).put("chat_turn", Chat.turnUrl).put("chat_turn_u", Chat.turnUser).put("chat_turn_p", Chat.turnPass)
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("server", "SHO3EB-SERVER:" + j))
                    toast(ctx, tr("📤 نُسخت الإعدادات", "📤 Settings copied"))
                }, modifier = Modifier.weight(1f)) { Text(tr("📤 نسخ الإعدادات", "📤 Copy config")) }
                OutlinedButton(onClick = { importDlg = true }, modifier = Modifier.weight(1f)) { Text(tr("📥 لصق إعدادات", "📥 Paste config")) }
            }
            Button(enabled = !testing, onClick = {
                testing = true; report = ""
                scope.launch {
                    report = withContext(Dispatchers.IO) {
                        val sb = StringBuilder()
                        fun line(ok: Boolean, t: String) { sb.append(if (ok) "✅ " else "❌ ").append(t).append('\n') }
                        val s = runCatching { Supa.ensureSession() }; line(s.isSuccess, tr("تسجيل الدخول للخادم", "Server sign-in") + (s.exceptionOrNull()?.message?.let { " — " + it.take(100) } ?: ""))
                        listOf("profiles", "messages", "signals").forEach { t -> val r = runCatching { Supa.select("$t?select=id&limit=1") }; line(r.isSuccess, tr("جدول ", "Table ") + t + (r.exceptionOrNull()?.message?.let { " — " + it.take(100) } ?: "")) }
                        val c = runCatching { Supa.rpc("claim_phone", JSONObject().put("p", "000")) }; line(c.isSuccess, tr("دالة نقل الأرقام", "Phone transfer function"))
                        val a = runCatching { Supa.rpc("account_email", JSONObject().put("p", "000"), anon = true) }; line(a.isSuccess, tr("دالة دخول الحسابات", "Account login function"))
                        val sg = runCatching { com.sho3eb.app.core.chat.CallBus.sendNow(Supa.uid, "test-" + System.currentTimeMillis(), "ping", "") }; line(sg.isSuccess, tr("إرسال إشارات المكالمات", "Call signals") + (sg.exceptionOrNull()?.message?.let { " — " + it.take(100) } ?: ""))
                        val up = runCatching { Supa.upload("${Supa.uid}/_test.txt", "ok".toByteArray(), "text/plain") }; line(up.isSuccess, tr("حاوية الملفات ", "Files bucket ") + Supa.bucket)
                        val bk = runCatching { Supa.upload("${Supa.uid}/_test.txt", "ok".toByteArray(), "text/plain", Supa.backupBucket) }; line(bk.isSuccess, tr("حاوية النسخ ", "Backup bucket ") + Supa.backupBucket)
                        if (sb.contains("❌")) sb.append(tr("\nلإصلاح الأخطاء: انسخ أوامر التجهيز (SQL) ونفّذها في Supabase.", "\nTo fix: copy the setup SQL and run it in Supabase."))
                        sb.toString()
                    }
                    testing = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (testing) tr("جارٍ الفحص…", "Checking…") else tr("🧪 فحص الخادم", "🧪 Check server")) }
            if (report.isNotBlank()) Text(report, style = MaterialTheme.typography.bodySmall)
        }
    }
    if (importDlg) {
        var t by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { importDlg = false }, title = { Text(tr("لصق إعدادات خادم", "Paste server config")) },
            text = { OutlinedTextField(t, { t = it }, label = { Text("SHO3EB-SERVER:{…}") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp)) },
            confirmButton = { TextButton(onClick = {
                runCatching {
                    val o = JSONObject(t.substringAfter("SHO3EB-SERVER:").trim())
                    Supa.setServer(o.optString("supa_url"), o.optString("supa_key"))
                    o.keys().forEach { k -> if (k != "supa_url" && k != "supa_key") Extras.ps(k, o.optString(k)) }
                    url = Supa.url; key = Supa.key; bucket = Supa.bucket; bbucket = Supa.backupBucket; verify = Supa.verifyPhone; channel = Supa.otpChannel
                    importDlg = false; toast(ctx, tr("✅ تم تطبيق الإعدادات", "✅ Applied")); onChanged()
                }.onFailure { toast(ctx, tr("النص غير صالح", "Invalid text")) }
            }) { Text(tr("تطبيق", "Apply")) } },
            dismissButton = { TextButton(onClick = { importDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
}
