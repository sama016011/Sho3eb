@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sho3eb.app.core.AppState
import com.sho3eb.app.core.Edition
import com.sho3eb.app.core.tr
import com.sho3eb.app.ui.theme.Sho3ebTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent?.getStringExtra("route")?.let { AppState.pendingRoute.value = it }
        handleShare(intent)
        com.sho3eb.app.core.chat.Cloud.handleLink(intent?.data)
        setContent { Sho3ebRoot() }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("route")?.let { AppState.pendingRoute.value = it }
        handleShare(intent)
        com.sho3eb.app.core.chat.Cloud.handleLink(intent.data)
    }

    /** استقبال ملفات/نصوص مشاركة من أقسام التطبيق أو من تطبيقات أخرى لإرسالها عبر التواصل */
    private fun handleShare(i: android.content.Intent?) {
        i ?: return
        val uris: List<android.net.Uri> = when (i.action) {
            android.content.Intent.ACTION_SEND -> listOfNotNull(if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri::class.java) else i.getParcelableExtra(android.content.Intent.EXTRA_STREAM))
            android.content.Intent.ACTION_SEND_MULTIPLE -> (if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri::class.java) else i.getParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM)) ?: emptyList()
            else -> return
        }
        // نسخ الملفات للتطبيق حتى تبقى متاحة بعد انتهاء صلاحية المشاركة
        val local = uris.mapNotNull { u ->
            runCatching {
                val name = com.sho3eb.app.core.MediaTools.nameOf(this, u)
                val f = java.io.File(java.io.File(cacheDir, "shared_in").apply { mkdirs() }, System.currentTimeMillis().toString() + "_" + name.replace('/', '_'))
                contentResolver.openInputStream(u)?.use { inp -> f.outputStream().use { inp.copyTo(it) } }
                android.net.Uri.fromFile(f)
            }.getOrNull()
        }
        com.sho3eb.app.core.chat.Chat.pendingShare.value = local
        com.sho3eb.app.core.chat.Chat.pendingText.value = i.getStringExtra(android.content.Intent.EXTRA_TEXT) ?: ""
        AppState.pendingRoute.value = "chat_share"
    }

    override fun onResume() { super.onResume(); com.sho3eb.app.core.chat.Chat.foreground = true; if (com.sho3eb.app.core.chat.Supa.configured) com.sho3eb.app.core.chat.Chat.start() }
    override fun onPause() { super.onPause(); com.sho3eb.app.core.chat.Chat.foreground = false }
}

@Composable
fun Sho3ebRoot() {
    val dark = when (AppState.theme.value) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    Sho3ebTheme(dark) {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (AppState.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
        ) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                if (AppState.loggedIn.value) {
                    MainShell()
                    // رابط استعادة كلمة المرور وصل والتطبيق مفتوح بالفعل
                    if (com.sho3eb.app.core.chat.Cloud.pendingLink.value != null) LinkResetDialog { p, _ -> runCatching { com.sho3eb.app.Sho3ebApp.instance.prefs.setPassword(p) } }
                } else AuthScreen()
            }
        }
    }
}

private data class NavTab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun MainShell() {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val tabsVer = BottomTabs.version.intValue
    val tabs = remember(tabsVer) { BottomTabs.tabs().map { NavTab(it.route, it.label, it.icon) } }

    // طلب صلاحية الإشعارات (أندرويد 13+)
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    // فتح شاشة محددة من إشعار
    val pending = AppState.pendingRoute.value
    LaunchedEffect(pending) {
        if (pending != null) {
            AppState.pendingRoute.value = null
            try { nav.navigate(pending) } catch (_: Exception) {}
        }
    }

    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, null) },
                            alwaysShowLabel = false,
                            label = { Text(t.label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize()) {
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(nav) }
            composable("assocs") { AssocListScreen(nav) }
            composable("loans") { LoanListScreen(nav, openNew = false) }
            composable("loans_new") { LoanListScreen(nav, openNew = true) }
            composable("sales") { SaleListScreen(nav) }
            composable("more") { MoreScreen(nav) }
            composable("people") { PeopleScreen(nav) }
            composable("settings") { SettingsScreen(nav) }
            composable("bottom_tabs") { BottomTabsScreen(nav) }
            composable("profile") { ProfileScreen(nav) }
            composable("accounts") { AccountListScreen(nav) }
            composable("living") { LivingHomeScreen(nav) }
            composable("tts_voice") { VoiceSettingsScreen(nav) }
            composable("dashboard") { DashboardScreen(nav) }
            composable("search") { GlobalSearchScreen(nav) }
            composable("zakat") { ZakatScreen(nav) }
            composable("props") { PropertiesScreen(nav) }
            composable("prop/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { PropertyDetailScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("lease/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { LeaseDetailScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("debts") { DebtsScreen(nav) }
            composable("debt/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { DebtDetailScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("workers") { WorkersScreen(nav) }
            composable("worker/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { WorkerDetailScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("assets") { AssetsScreen(nav) }
            composable("splits") { SplitGroupsScreen(nav) }
            composable("split/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { SplitGroupScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("cars") { CarsScreen(nav) }
            composable("car/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { CarDetailScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("subs") { SubsScreen(nav) }
            composable("props_report") { PropertiesReportScreen(nav) }
            composable("shop") { ShopScreen(nav) }
            composable("invoice/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { InvoiceScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("invoice_edit/{type}/{id}?party={party}", arguments = listOf(navArgument("type") { type = NavType.StringType }, navArgument("id") { type = NavType.LongType }, navArgument("party") { type = NavType.LongType; defaultValue = 0L })) {
                InvoiceEditScreen(nav, it.arguments?.getString("type") ?: "SALE", it.arguments?.getLong("id") ?: 0L, it.arguments?.getLong("party") ?: 0L)
            }
            composable("shop_side/{side}", arguments = listOf(navArgument("side") { type = NavType.StringType })) { ShopSideScreen(nav, it.arguments?.getString("side") ?: "CUSTOMER") }
            composable("party/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { PartyScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("product/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { ProductLedgerScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("shop_accounts") { ShopAccountsScreen(nav) }
            composable("grocery") { GroceryScreen(nav) }
            composable("credit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { CreditBookScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("advisor") { AdvisorScreen(nav) }
            composable("chat") { ChatHomeScreen(nav) }
            composable("chat_setup") { ChatSetupScreen(nav) }
            composable("chat_calls") { ChatCallSettingsScreen(nav) }
            composable("chat_friends") { ChatFriendsScreen(nav) }
            composable("chat_share") { ChatShareScreen(nav) }
            composable("chat/{peer}") { ChatRoomScreen(nav, peer = it.arguments?.getString("peer") ?: "") }
            composable("chat_group/{id}") { ChatRoomScreen(nav, groupId = it.arguments?.getString("id") ?: "") }
            composable("chat_group_edit/{id}") { ChatGroupEditScreen(nav, it.arguments?.getString("id") ?: "new") }
            composable("brand") { BrandScreen(nav) }
            composable("contact") { ContactScreen(nav) }
            composable("edition_studio") { EditionStudioScreen(nav) }
            composable("fx") { FxScreen(nav) }
            composable("alarms") { AlarmsScreen(nav) }
            composable("alarm_edit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { AlarmEditScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("manufacture") { ManufactureScreen(nav) }
            composable("manufacture_bom/{pid}", arguments = listOf(navArgument("pid") { type = NavType.LongType })) { BomScreen(nav, it.arguments?.getLong("pid") ?: 0L) }
            composable("learn") { LearnScreen(nav) }
            composable("translate") { TranslateScreen(nav) }
            composable("course") { CourseScreen(nav) }
            composable("lesson/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { LessonScreen(nav, it.arguments?.getString("id") ?: "") }
            composable("roleplay") { RoleplayListScreen(nav) }
            composable("roleplay/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { RoleplayScreen(nav, it.arguments?.getString("id") ?: "") }
            composable("home_edit") { HomeEditScreen(nav) }
            composable("football") { FootballScreen(nav) }
            composable("match/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { MatchScreen(nav, it.arguments?.getString("id") ?: "") }
            composable("team/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { TeamScreen(nav, it.arguments?.getString("id") ?: "") }
            composable("media") { MediaHubScreen(nav) }
            composable("media_tools") { MediaToolsScreen(nav) }
            composable("player?u={u}&t={t}", arguments = listOf(navArgument("u") { type = NavType.StringType; defaultValue = "" }, navArgument("t") { type = NavType.StringType; defaultValue = "" })) {
                VideoPlayerScreen(nav, it.arguments?.getString("u") ?: "", it.arguments?.getString("t") ?: "")
            }
            composable("web?u={u}&t={t}", arguments = listOf(navArgument("u") { type = NavType.StringType; defaultValue = "" }, navArgument("t") { type = NavType.StringType; defaultValue = "" })) {
                WebWatchScreen(nav, it.arguments?.getString("u") ?: "", it.arguments?.getString("t") ?: "")
            }
            composable("recipes") { RecipesScreen(nav) }
            composable("recipe/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { RecipeScreen(nav, it.arguments?.getString("id") ?: "") }
            composable("diabetes") { DiabetesScreen(nav) }
            composable("design") { DesignScreen(nav) }
            composable("design/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { DesignEditScreen(nav, it.arguments?.getLong("id") ?: 0L) }
            composable("faraid") { FaraidScreen(nav) }
            composable("vault") { VaultScreen(nav) }
            composable("asma") { AsmaScreen(nav) }
            composable("tasbeeh") { TasbeehScreen(nav) }
            composable("occasions") { OccasionsScreen(nav) }
            composable("ramadan") { RamadanScreen(nav) }
            composable("khatma") { KhatmaScreen(nav) }
            composable("prayer_track") { PrayerTrackerScreen(nav) }
            composable("azan_settings") { AzanSettingsScreen(nav) }
            composable("living_period/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                LivingPeriodScreen(nav, it.arguments?.getLong("id") ?: 0L)
            }
            // ---------- إسلاميات ----------
            composable("islam") { IslamHomeScreen(nav) }
            composable("quran") { QuranIndexScreen(nav) }
            composable(
                "mushaf/{page}?hl={hl}",
                arguments = listOf(navArgument("page") { type = NavType.IntType }, navArgument("hl") { type = NavType.IntType; defaultValue = 0 })
            ) { MushafScreen(nav, it.arguments?.getInt("page") ?: 1, it.arguments?.getInt("hl") ?: 0) }
            composable("reciters") { RecitersScreen(nav) }
            composable("prayer") { PrayerScreen(nav) }
            composable("qibla") { QiblaScreen(nav) }
            composable("azkar") { AzkarHomeScreen(nav) }
            composable("azkar/{g}", arguments = listOf(navArgument("g") { type = NavType.IntType })) { AzkarListScreen(nav, it.arguments?.getInt("g") ?: 0) }
            composable("ruqyah") { RuqyahHomeScreen(nav) }
            composable("ruqyah_audio") { RuqyahAudioScreen(nav) }
            composable("ruqyah/{g}", arguments = listOf(navArgument("g") { type = NavType.IntType })) { RuqyahDetailScreen(nav, it.arguments?.getInt("g") ?: 0) }
            composable("hadith") { HadithHomeScreen(nav) }
            composable("hadith/{g}", arguments = listOf(navArgument("g") { type = NavType.IntType })) { HadithListScreen(nav, it.arguments?.getInt("g") ?: 0) }
            composable(
                "hadith_check?q={q}",
                arguments = listOf(navArgument("q") { type = NavType.StringType; defaultValue = "" })
            ) { HadithCheckScreen(nav, it.arguments?.getString("q") ?: "") }
            composable("clist/{file}", arguments = listOf(navArgument("file") { type = NavType.StringType })) {
                ContentListScreen(nav, it.arguments?.getString("file") ?: "")
            }
            composable(
                "cread/{file}/{g}/{i}",
                arguments = listOf(navArgument("file") { type = NavType.StringType }, navArgument("g") { type = NavType.IntType }, navArgument("i") { type = NavType.IntType })
            ) { ContentReaderScreen(nav, it.arguments?.getString("file") ?: "", it.arguments?.getInt("g") ?: 0, it.arguments?.getInt("i") ?: 0) }
            composable("islam_settings") { IslamSettingsScreen(nav) }
            composable("account/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                AccountDetailScreen(nav, it.arguments?.getLong("id") ?: 0L)
            }
            composable("person/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                PersonEditScreen(nav, it.arguments?.getLong("id") ?: 0L)
            }
            composable("assoc_edit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                AssocEditScreen(nav, it.arguments?.getLong("id") ?: 0L)
            }
            composable("assoc/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                AssocDetailScreen(nav, it.arguments?.getLong("id") ?: 0L)
            }
            composable("loan/{pid}", arguments = listOf(navArgument("pid") { type = NavType.LongType })) {
                LoanDetailScreen(nav, it.arguments?.getLong("pid") ?: 0L)
            }
            composable("sale_edit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                SaleEditScreen(nav, it.arguments?.getLong("id") ?: 0L)
            }
            composable("sale/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                SaleDetailScreen(nav, it.arguments?.getLong("id") ?: 0L)
            }
        }
            MiniPlayerOverlay(nav)
        }
    }
}
