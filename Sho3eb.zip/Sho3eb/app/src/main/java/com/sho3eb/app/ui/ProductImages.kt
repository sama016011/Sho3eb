package com.sho3eb.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sho3eb.app.core.Extras
import com.sho3eb.app.core.Photos
import com.sho3eb.app.core.tr
import org.json.JSONObject
import java.io.File

/** صور الأصناف (المنتجات، الخامات، العادية): تُحفظ داخل التطبيق ومربوطة برقم الصنف */
object ProductImages {
    val version = mutableIntStateOf(0)
    private fun map(): JSONObject = runCatching { JSONObject(Extras.s("product_imgs", "{}")) }.getOrDefault(JSONObject())
    fun get(id: Long?): String? = id?.let { map().optString(it.toString()).takeIf { p -> p.isNotBlank() && File(p).exists() } }
    fun set(id: Long, path: String?) {
        val m = map()
        val old = m.optString(id.toString())
        if (path.isNullOrBlank()) m.remove(id.toString()) else m.put(id.toString(), path)
        Extras.ps("product_imgs", m.toString())
        if (old.isNotBlank() && old != path) runCatching { File(old).delete() }
        version.intValue++
    }
}

private val palette = listOf(0xFF5C6BC0, 0xFF26A69A, 0xFFEF6C00, 0xFF8E24AA, 0xFF00897B, 0xFFD81B60, 0xFF3949AB, 0xFF6D4C41)

/** صورة مصغرة للصنف بزوايا مستديرة (أو أول حرف بلون مميز إن لم توجد صورة) */
@Composable
fun ProductThumb(id: Long?, name: String, size: Dp = 48.dp, emoji: String = "", path: String? = null) {
    val ver = ProductImages.version.intValue
    val p = path ?: remember(id, ver) { ProductImages.get(id) }
    val bmp = remember(p) { p?.let { runCatching { Photos.load(it) }.getOrNull() } }
    val shape = RoundedCornerShape(size * 0.22f)
    if (bmp != null) {
        Image(bmp.asImageBitmap(), null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape).border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape))
    } else {
        val c = Color(palette[(name.hashCode() and 0x7fffffff) % palette.size])
        Box(Modifier.size(size).clip(shape).background(Brush.linearGradient(listOf(c, c.copy(alpha = 0.7f)))), contentAlignment = Alignment.Center) {
            Text(emoji.ifBlank { name.trim().take(1).uppercase().ifEmpty { "?" } }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
        }
    }
}

/** خانة اختيار صورة الصنف داخل نوافذ الإضافة والتعديل */
@Composable
fun ProductPhotoField(path: String?, name: String, onChange: (String?) -> Unit) {
    val pick = rememberPhotoPicker(tr("صورة الصنف", "Item photo")) { onChange(it) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.clickable { pick() }) { ProductThumb(null, name.ifBlank { "?" }, 72.dp, emoji = if (path == null) "📷" else "", path = path) }
        Column(Modifier.weight(1f)) {
            OutlinedButton(onClick = pick) { Icon(Icons.Filled.AddAPhoto, null); Spacer(Modifier.width(6.dp)); Text(if (path == null) tr("إضافة صورة", "Add photo") else tr("تغيير الصورة", "Change photo")) }
            if (path != null) TextButton(onClick = { onChange(null) }) { Icon(Icons.Filled.Delete, null); Text(tr("إزالة الصورة", "Remove photo")) }
        }
    }
}
