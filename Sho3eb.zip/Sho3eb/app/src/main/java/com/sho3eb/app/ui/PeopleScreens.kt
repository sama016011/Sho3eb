@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.app.Activity
import android.content.Intent
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.Person
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PeopleScreen(nav: NavController) {
    val dao = remember { appDao() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var q by remember { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }

    ScreenScaffold(
        title = tr("الأشخاص", "People"),
        onBack = { nav.popBackStack() },
        fab = {
            ExtendedFloatingActionButton(
                onClick = { showPicker = true },
                icon = { Icon(Icons.Filled.PersonAdd, null) },
                text = { Text(tr("إضافة", "Add")) }
            )
        }
    ) { pad ->
        val list = people.filter { q.isBlank() || it.name.contains(q, true) || it.phone.contains(q) }
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { SearchField(q) { q = it } }
            item { Text(tr("${people.size} شخص", "${people.size} people"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (list.isEmpty()) item { EmptyState(Icons.Filled.People, tr("لا يوجد أشخاص بعد", "No people yet")) }
            items(list, key = { it.id }) { p ->
                Card(onClick = { nav.navigate("person/${p.id}") }, modifier = Modifier.fillMaxWidth()) {
                    PersonRow(p.name, p.phone, p.photoPath, Modifier.padding(12.dp)) {
                        Icon(Icons.Filled.ChevronRight, null)
                    }
                }
            }
        }
    }
    if (showPicker) PersonPickerDialog(multi = true, exclude = people.map { it.id }.toSet(), onDismiss = { showPicker = false }) {
        showPicker = false
    }
}

@Composable
fun PersonEditScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    var person by remember { mutableStateOf<Person?>(null) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        dao.person(id)?.let { p -> person = p; name = p.name; phone = p.phone; notes = p.notes; photo = p.photoPath }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { photo = withContext(Dispatchers.IO) { Photos.copyFromUri(ctx, uri) } ?: photo }
    }
    val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) scope.launch {
            val c = withContext(Dispatchers.IO) { Contacts.readPicked(ctx, uri) } ?: return@launch
            name = c.name; phone = c.phone
            c.photoUri?.let { u -> withContext(Dispatchers.IO) { Photos.copyFromUri(ctx, android.net.Uri.parse(u)) } }?.let { photo = it }
        }
    }

    ScreenScaffold(
        title = tr("بيانات الشخص", "Person"),
        onBack = { nav.popBackStack() },
        actions = { IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, null) } }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                Avatar(photo, name, 110.dp, Modifier.clip(CircleShape).clickable {
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                })
                SmallFloatingActionButton(onClick = {
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Icon(Icons.Filled.CameraAlt, null) }
            }
            OutlinedButton(onClick = {
                try { pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)) } catch (_: Exception) {}
            }) { Icon(Icons.Filled.ContactPhone, null); Spacer(Modifier.width(8.dp)); Text(tr("تعبئة من جهات الاتصال", "Fill from contacts")) }
            OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                phone, { phone = it }, label = { Text(tr("رقم الجوال", "Phone")) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    if (phone.isNotBlank()) Row {
                        IconButton(onClick = { Share.dial(ctx, phone) }) { Icon(Icons.Filled.Call, null) }
                        IconButton(onClick = { Share.whatsappMessage(ctx, phone, tr("السلام عليكم ", "Hello ") + name) }) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                    }
                }
            )
            NotesField(notes) { notes = it }
            Button(onClick = {
                val p = person ?: return@Button
                if (name.isBlank()) { toast(ctx, tr("أدخل الاسم", "Enter the name")); return@Button }
                scope.launch {
                    dao.updatePerson(p.copy(name = name.trim(), phone = Contacts.cleanPhone(phone), notes = notes.trim(), photoPath = photo))
                    toast(ctx, tr("تم الحفظ", "Saved"))
                    nav.popBackStack()
                }
            }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(tr("حفظ", "Save")) }
        }
    }
    if (confirmDelete) ConfirmDialog(
        title = tr("حذف الشخص", "Delete person"),
        text = tr("لا يمكن حذف شخص مرتبط بجمعية أو سلفة أو بيع.", "A person linked to an association, loan or sale cannot be deleted."),
        confirmText = tr("حذف", "Delete"),
        onDismiss = { confirmDelete = false }
    ) {
        scope.launch {
            if (dao.personUsage(id) > 0) toast(ctx, tr("هذا الشخص مرتبط بسجلات، لا يمكن حذفه", "This person has records and can't be deleted"))
            else { dao.deletePerson(id); nav.popBackStack() }
        }
    }
}
