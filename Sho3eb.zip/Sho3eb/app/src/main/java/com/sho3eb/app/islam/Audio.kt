package com.sho3eb.app.islam

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.mutableStateOf
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale

/** القراءة الصوتية للنصوص (تحويل النص إلى كلام) */
object Tts {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private val callbacks = HashMap<String, () -> Unit>()
    private val waiters = HashMap<String, CompletableDeferred<Boolean>>()
    val speaking = mutableStateOf(false)

    private fun init(ctx: Context, onReady: (Boolean) -> Unit) {
        if (tts != null && ready) { onReady(true); return }
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                val r = tts?.setLanguage(Locale("ar"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    main.post { toast(ctx, tr("ثبّت اللغة العربية في محرك تحويل النص إلى كلام من إعدادات الهاتف", "Install Arabic voice data in your phone's text-to-speech settings")) }
                }
                tts?.setSpeechRate(IslamPrefs.ttsRate)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) = finish(id, true)
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) = finish(id, false)
                    override fun onError(id: String?, errorCode: Int) = finish(id, false)
                })
            }
            main.post { onReady(ready) }
        }
    }

    private fun finish(id: String?, ok: Boolean) {
        if (id == null) return
        main.post {
            callbacks.remove(id)?.invoke()
            waiters.remove(id)?.complete(ok)
        }
    }

    fun chunks(text: String, max: Int = 3000): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        text.split(Regex("(?<=[.،؛!؟?\\n])")).forEach { part ->
            if (sb.length + part.length > max && sb.isNotEmpty()) { out += sb.toString(); sb.clear() }
            if (part.length > max) part.chunked(max).forEach { out += it } else sb.append(part)
        }
        if (sb.isNotBlank()) out += sb.toString()
        return out.filter { it.isNotBlank() }
    }

    /** قراءة نص بصوت، ثم استدعاء onDone عند الانتهاء */
    fun speak(ctx: Context, text: String, onDone: () -> Unit = {}) {
        init(ctx) { ok ->
            if (!ok) { toast(ctx, tr("محرك القراءة الصوتية غير متاح", "Text-to-speech is not available")); onDone(); return@init }
            val parts = chunks(text)
            if (parts.isEmpty()) { onDone(); return@init }
            speaking.value = true
            tts?.setSpeechRate(IslamPrefs.ttsRate)
            parts.forEachIndexed { i, p ->
                val id = "sp_${System.nanoTime()}_$i"
                if (i == parts.size - 1) callbacks[id] = { speaking.value = false; onDone() }
                tts?.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
            }
        }
    }

    fun stop() {
        tts?.stop()
        callbacks.clear()
        speaking.value = false
    }

    /** حفظ النص كملف صوتي WAV */
    suspend fun exportWav(ctx: Context, text: String, out: File): Boolean {
        val okInit = CompletableDeferred<Boolean>()
        withContext(Dispatchers.Main) { init(ctx) { okInit.complete(it) } }
        if (!okInit.await()) return false
        val parts = chunks(text)
        val dir = File(ctx.cacheDir, "tts_parts").apply { deleteRecursively(); mkdirs() }
        val files = mutableListOf<File>()
        for ((i, p) in parts.withIndex()) {
            val f = File(dir, "p$i.wav")
            val id = "ex_${System.nanoTime()}_$i"
            val waiter = CompletableDeferred<Boolean>()
            withContext(Dispatchers.Main) { waiters[id] = waiter }
            val r = tts?.synthesizeToFile(p, Bundle(), f, id)
            if (r != TextToSpeech.SUCCESS) return false
            val ok = withTimeoutOrNull(120_000) { waiter.await() } ?: false
            if (!ok || !f.exists()) return false
            files += f
        }
        return withContext(Dispatchers.IO) { Wav.merge(files, out).also { dir.deleteRecursively() } }
    }
}

/** دمج ملفات WAV بنفس الصيغة */
object Wav {
    private fun le32(b: ByteArray, o: Int) = (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8) or
        ((b[o + 2].toInt() and 0xff) shl 16) or ((b[o + 3].toInt() and 0xff) shl 24)

    fun merge(files: List<File>, out: File): Boolean = try {
        var fmt: ByteArray? = null
        val data = ByteArrayOutputStream()
        for (f in files) {
            val b = f.readBytes()
            var p = 12
            while (p + 8 <= b.size) {
                val id = String(b, p, 4, Charsets.US_ASCII)
                var len = le32(b, p + 4)
                if (len < 0 || p + 8 + len > b.size) len = b.size - p - 8
                if (id == "fmt " && fmt == null) fmt = b.copyOfRange(p + 8, p + 8 + len)
                if (id == "data") data.write(b, p + 8, len)
                p += 8 + len + (len and 1)
            }
        }
        val f = fmt ?: throw IllegalStateException("no fmt")
        val d = data.toByteArray()
        out.parentFile?.mkdirs()
        RandomAccessFile(out, "rw").use { w ->
            w.setLength(0)
            fun i32(v: Int) { w.write(byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())) }
            w.writeBytes("RIFF"); i32(4 + 8 + f.size + 8 + d.size); w.writeBytes("WAVE")
            w.writeBytes("fmt "); i32(f.size); w.write(f)
            w.writeBytes("data"); i32(d.size); w.write(d)
        }
        true
    } catch (e: Exception) {
        false
    }
}

/** مقطع في قائمة التشغيل: آية بصوت القارئ أو نص يُقرأ آلياً */
sealed class Seg {
    data class AyahSeg(val global: Int) : Seg()
    data class Speak(val text: String) : Seg()
}

/** مشغّل متسلسل للآيات والأدعية */
object SeqPlayer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var mp: MediaPlayer? = null
    private var queue: List<Seg> = emptyList()
    private var idx = 0
    private var repeat = 1
    private var repeatDone = 0
    private var reciter: Reciter? = null
    private var appCtx: Context? = null

    val playingAyah = mutableStateOf<Int?>(null)
    val active = mutableStateOf(false)
    val label = mutableStateOf("")
    val loading = mutableStateOf(false)

    fun play(ctx: Context, segs: List<Seg>, r: Reciter, title: String = "", repeatEach: Int = 1) {
        stop()
        appCtx = ctx.applicationContext
        queue = segs
        idx = 0
        repeat = repeatEach.coerceAtLeast(1)
        repeatDone = 0
        reciter = r
        label.value = title
        active.value = segs.isNotEmpty()
        playCurrent()
    }

    fun stop() {
        mp?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        mp = null
        Tts.stop()
        active.value = false
        playingAyah.value = null
        loading.value = false
        queue = emptyList()
    }

    private fun advance() {
        repeatDone++
        if (repeatDone < repeat && queue.getOrNull(idx) is Seg.AyahSeg) { playCurrent(); return }
        repeatDone = 0
        idx++
        if (idx >= queue.size) stop() else playCurrent()
    }

    private fun playCurrent() {
        val ctx = appCtx ?: return
        when (val s = queue.getOrNull(idx) ?: return) {
            is Seg.Speak -> {
                playingAyah.value = null
                Tts.speak(ctx, s.text) { if (active.value) advance() }
            }
            is Seg.AyahSeg -> {
                playingAyah.value = s.global
                loading.value = true
                val r = reciter ?: return
                scope.launch {
                    val src = try {
                        QuranRepo.audioSource(ctx, r, s.global)
                    } catch (e: Exception) {
                        null
                    }
                    if (!active.value) return@launch
                    if (src == null) {
                        loading.value = false
                        toast(ctx, tr("تعذر تحميل الصوت. تحقق من الاتصال بالإنترنت", "Could not load audio. Check your connection"))
                        stop(); return@launch
                    }
                    mp?.release()
                    mp = MediaPlayer().apply {
                        setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        setOnPreparedListener { loading.value = false; it.start() }
                        setOnCompletionListener { if (active.value) advance() }
                        setOnErrorListener { _, _, _ -> loading.value = false; if (active.value) advance(); true }
                        try {
                            setDataSource(src)
                            prepareAsync()
                        } catch (e: Exception) {
                            loading.value = false
                            advance()
                        }
                    }
                }
            }
        }
    }
}
