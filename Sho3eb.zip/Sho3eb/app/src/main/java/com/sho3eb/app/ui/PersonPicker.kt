@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.sho3eb.app.core.*
import com.sho3eb.app.data.Person
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** اختيار شخص/أشخاص: من القائمة، أو إضافة يدوية، أو من جهات الاتصال */
@Composable
fun PersonPickerDialog(
    multi: Boolean,
    exclude: Set<Long> = emptySet(),
    onDismiss: () -> Unit,
    onPicked: (List<Person>) -> Unit
) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var query by remember { mutableStateOf("") }
    val selected = remember { mutableStateListOf<Long>() }
    var showNew by remember { mutableStateOf(false) }
    var showContacts by remember { mutableStateOf(false) }

    fun addPicked(p: Person) {
        if (multi) {
            if (p.id !in selected) selected.add(p.id)
        } else onPicked(listOf(p))
    }

    val pickOne = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            scope.launch {
                val c = withContext(Dispatchers.IO) { Contacts.readPicked(ctx, uri) }
                if (c != null) addPicked(Contacts.upsert(ctx, dao, c))
            }
        }
    }
    val pickIntent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) showContacts = true else pickOne.launch(pickIntent)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (multi) tr("اختيار الأعضاء", "Select members") else tr("اختيار شخص", "Select person")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SearchField(query) { query = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(
                        onClick = { showNew = true },
                        label = { Text(tr("إضافة يدوي", "Add manually")) },
                        leadingIcon = { Icon(Icons.Filled.PersonAdd, null, Modifier.size(18.dp)) }
                    )
                    AssistChip(
                        onClick = {
                            if (multi) {
                                val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
                                if (granted) showContacts = true else perm.launch(Manifest.permission.READ_CONTACTS)
                            } else {
                                try { pickOne.launch(pickIntent) } catch (e: Exception) { toast(ctx, tr("تعذر فتح جهات الاتصال", "Cannot open contacts")) }
                            }
                        },
                        label = { Text(tr("جهات الاتصال", "Contacts")) },
                        leadingIcon = { Icon(Icons.Filled.ContactPhone, null, Modifier.size(18.dp)) }
                    )
                }
                val list = people.filter {
                    it.id !in exclude && (query.isBlank() || it.name.contains(query, true) || it.phone.contains(query))
                }
                if (list.isEmpty()) {
                    Text(
                        tr("لا يوجد أشخاص. أضف يدوياً أو من جهات الاتصال.", "No people. Add manually or from contacts."),
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    items(list, key = { it.id }) { p ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (multi) {
                                    if (p.id in selected) selected.remove(p.id) else selected.add(p.id)
                                } else onPicked(listOf(p))
                            }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (multi) Checkbox(checked = p.id in selected, onCheckedChange = null)
                            if (multi) Spacer(Modifier.width(8.dp))
                            PersonRow(p.name, p.phone, p.photoPath)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (multi) TextButton(onClick = { onPicked(selected.mapNotNull { id -> people.firstOrNull { it.id == id } }) }, enabled = selected.isNotEmpty()) {
                Text(tr("إضافة (${selected.size})", "Add (${selected.size})"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )

    if (showNew) QuickPersonDialog(onDismiss = { showNew = false }) { p -> showNew = false; addPicked(p) }
    if (showContacts) ContactsMultiDialog(onDismiss = { showContacts = false }) { contacts ->
        showContacts = false
        scope.launch { contacts.forEach { c -> addPicked(Contacts.upsert(ctx, dao, c)) } }
    }
}

/** إضافة شخص سريع (اسم + جوال) */
@Composable
fun QuickPersonDialog(onDismiss: () -> Unit, onCreated: (Person) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("إضافة شخص", "Add person")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    phone, { phone = it }, label = { Text(tr("رقم الجوال", "Phone")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) {
                    toast(ctx, tr("أدخل الاسم", "Enter the name")); return@TextButton
                }
                scope.launch {
                    val p = Person(name = name.trim(), phone = Contacts.cleanPhone(phone))
                    val id = appDao().insertPerson(p)
                    onCreated(p.copy(id = id))
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/** اختيار عدة جهات اتصال دفعة واحدة */
@Composable
fun ContactsMultiDialog(onDismiss: () -> Unit, onDone: (List<ContactItem>) -> Unit) {
    val ctx = LocalContext.current
    val all by produceState<List<ContactItem>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { Contacts.loadAll(ctx) }
    }
    var q by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<Int>() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("جهات الاتصال", "Contacts")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SearchField(q) { q = it }
                val list = all
                if (list == null) {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        itemsIndexed(list) { i, c ->
                            if (q.isBlank() || c.name.contains(q, true) || c.phone.contains(q)) {
                                Row(
                                    Modifier.fillMaxWidth().clickable {
                                        if (i in sel) sel.remove(i) else sel.add(i)
                                    }.padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(checked = i in sel, onCheckedChange = null)
                                    Spacer(Modifier.width(8.dp))
                                    PersonRow(c.name, c.phone, null)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDone(sel.mapNotNull { all?.getOrNull(it) }) }, enabled = sel.isNotEmpty()) {
                Text(tr("إضافة (${sel.size})", "Add (${sel.size})"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/** بطاقة الشخص المختار مع زر تغيير */
@Composable
fun PersonSelector(person: Person?, label: String, onPick: (Person) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedCard(Modifier.fillMaxWidth().clickable { show = true }) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (person == null) {
                Icon(Icons.Filled.PersonAdd, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text(label, color = MaterialTheme.colorScheme.primary)
            } else {
                PersonRow(person.name, person.phone, person.photoPath, Modifier.weight(1f))
                Icon(Icons.Filled.Edit, null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
    if (show) PersonPickerDialog(multi = false, onDismiss = { show = false }) { list ->
        show = false
        list.firstOrNull()?.let(onPick)
    }
}
