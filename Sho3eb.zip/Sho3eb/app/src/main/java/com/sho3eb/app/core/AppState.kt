package com.sho3eb.app.core

import androidx.compose.runtime.mutableStateOf
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.AppDao

/** الحالة العامة للتطبيق (اللغة، المظهر، المستخدم). قراءتها داخل Compose تعيد الرسم تلقائياً. */
object AppState {
    val lang = mutableStateOf("ar")
    val theme = mutableStateOf("system")
    val currency = mutableStateOf("ر.س")
    val loggedIn = mutableStateOf(false)
    val displayName = mutableStateOf("")
    val photoPath = mutableStateOf<String?>(null)

    val isAr: Boolean get() = lang.value == "ar"

    fun init(p: Prefs) {
        lang.value = p.lang
        theme.value = p.theme
        currency.value = p.currency
        displayName.value = p.displayName
        photoPath.value = p.photoPath
    }
}

/** ترجمة سريعة: النص العربي (الأساسي) والنص الإنجليزي */
fun tr(ar: String, en: String): String = if (AppState.lang.value == "ar") ar else en

fun appDao(): AppDao = Sho3ebApp.instance.db.dao()
fun appPrefs(): Prefs = Sho3ebApp.instance.prefs
