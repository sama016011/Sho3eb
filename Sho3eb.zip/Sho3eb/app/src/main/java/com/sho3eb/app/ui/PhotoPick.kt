package com.sho3eb.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.sho3eb.app.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * اختيار صورة شخصية: من معرض الصور (كل صور الجهاز)، أو منتقي الصور، أو الكاميرا.
 * يعيد دالة لفتح نافذة الاختيار؛ ويستدعي onPicked بمسار الصورة المحفوظة داخل التطبيق.
 */
@Composable
fun rememberPhotoPicker(onPicked: (String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var show by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onPicked)

    fun handleUri(uri: android.net.Uri?) {
        if (uri == null) return
        busy = true
        scope.launch {
            val path = withContext(Dispatchers.IO) { Photos.copyFromUri(ctx, uri, 720) }
            busy = false
            if (path != null) cb(path) else toast(ctx, tr("تعذر قراءة الصورة، جرّب صورة أخرى", "Couldn't read the image, try another"))
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r -> handleUri(r.data?.data) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { handleUri(it) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) scope.launch {
            val path = withContext(Dispatchers.IO) {
                runCatching {
                    val f = File(File(ctx.filesDir, "photos").apply { mkdirs() }, "${UUID.randomUUID()}.jpg")
                    FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }; f.absolutePath
                }.getOrNull()
            }
            if (path != null) cb(path)
        }
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) runCatching { camera.launch(null) } }

    if (show) AlertDialog(onDismissRequest = { show = false }, confirmButton = {}, dismissButton = { TextButton(onClick = { show = false }) { Text(tr("إلغاء", "Cancel")) } },
        title = { Text(tr("الصورة الشخصية", "Profile photo")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = {
                    show = false
                    val i = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).setType("image/*")
                    runCatching { gallery.launch(i) }.onFailure { runCatching { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) } }
                }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.PhotoLibrary, null); Spacer(Modifier.width(8.dp)); Text(tr("معرض الصور", "Gallery")) }
                OutlinedButton(onClick = { show = false; runCatching { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) } }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Image, null); Spacer(Modifier.width(8.dp)); Text(tr("منتقي الصور / الملفات", "Photo picker / Files"))
                }
                OutlinedButton(onClick = {
                    show = false
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) runCatching { camera.launch(null) }
                    else camPerm.launch(Manifest.permission.CAMERA)
                }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.PhotoCamera, null); Spacer(Modifier.width(8.dp)); Text(tr("الكاميرا", "Camera")) }
            }
        })
    if (busy) AlertDialog(onDismissRequest = {}, confirmButton = {}, text = { Row { CircularProgressIndicator(Modifier.size(22.dp)); Spacer(Modifier.width(12.dp)); Text(tr("جارٍ تجهيز الصورة…", "Preparing photo…")) } })
    return { show = true }
}
