package com.sho3eb.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        Person::class, Association::class, AssocMember::class, AssocPayment::class,
        AssocPayout::class, LoanTx::class, Sale::class, SalePayment::class,
        Account::class, AccountTx::class, Attachment::class,
        LivItem::class, LivPeriod::class, LivEntry::class,
        Property::class, PropUnit::class, Lease::class, LeasePayment::class, PropExpense::class, Debt::class, DebtTx::class,
        Worker::class, WorkerEntry::class, Asset::class, SplitGroup::class, SplitMember::class, SplitExpense::class, SplitSettle::class, Vehicle::class, CarExpense::class, CarReminder::class, Subscription::class, SubPayment::class
    ],
    version = 7,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        const val NAME = "sho3eb.db"

        /** العمال والأصول وتقسيم المصاريف والسيارة والاشتراكات */
        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `workers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `personId` INTEGER, `phone` TEXT NOT NULL, `job` TEXT NOT NULL, `wageType` TEXT NOT NULL, `wage` REAL NOT NULL, `otRate` REAL NOT NULL, `startDate` INTEGER NOT NULL, `active` INTEGER NOT NULL, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `worker_entries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `workerId` INTEGER NOT NULL, `date` INTEGER NOT NULL, `type` TEXT NOT NULL, `qty` REAL NOT NULL, `amount` REAL NOT NULL, `project` TEXT NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_worker_entries_workerId` ON `worker_entries` (`workerId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `assets` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `type` TEXT NOT NULL, `qty` REAL NOT NULL, `unit` TEXT NOT NULL, `karat` INTEGER NOT NULL, `buyPrice` REAL NOT NULL, `buyDate` INTEGER NOT NULL, `unitPrice` REAL NOT NULL, `currentValue` REAL NOT NULL, `priceDate` INTEGER NOT NULL, `zakatable` INTEGER NOT NULL, `sold` INTEGER NOT NULL, `sellPrice` REAL NOT NULL, `sellDate` INTEGER, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `split_groups` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `notes` TEXT NOT NULL, `closed` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `split_members` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `groupId` INTEGER NOT NULL, `name` TEXT NOT NULL, `phone` TEXT NOT NULL, `personId` INTEGER, `isMe` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_split_members_groupId` ON `split_members` (`groupId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `split_expenses` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `groupId` INTEGER NOT NULL, `title` TEXT NOT NULL, `amount` REAL NOT NULL, `payerId` INTEGER NOT NULL, `date` INTEGER NOT NULL, `shares` TEXT NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_split_expenses_groupId` ON `split_expenses` (`groupId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `split_settles` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `groupId` INTEGER NOT NULL, `fromId` INTEGER NOT NULL, `toId` INTEGER NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_split_settles_groupId` ON `split_settles` (`groupId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `vehicles` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `plate` TEXT NOT NULL, `model` TEXT NOT NULL, `year` INTEGER NOT NULL, `odometer` INTEGER NOT NULL, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `car_expenses` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `vehicleId` INTEGER NOT NULL, `type` TEXT NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `odometer` INTEGER NOT NULL, `liters` REAL NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_car_expenses_vehicleId` ON `car_expenses` (`vehicleId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `car_reminders` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `vehicleId` INTEGER NOT NULL, `title` TEXT NOT NULL, `type` TEXT NOT NULL, `lastDate` INTEGER, `lastKm` INTEGER NOT NULL, `intervalMonths` INTEGER NOT NULL, `intervalKm` INTEGER NOT NULL, `dueDate` INTEGER, `enabled` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_car_reminders_vehicleId` ON `car_reminders` (`vehicleId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `subscriptions` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `category` TEXT NOT NULL, `amount` REAL NOT NULL, `periodMonths` INTEGER NOT NULL, `nextDate` INTEGER NOT NULL, `variable` INTEGER NOT NULL, `remindDays` INTEGER NOT NULL, `active` INTEGER NOT NULL, `toLiving` INTEGER NOT NULL, `accountId` INTEGER, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `sub_payments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `subId` INTEGER NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_sub_payments_subId` ON `sub_payments` (`subId`)")
            }
        }

        /** الإضافة التلقائية للمصروفات المتكررة */
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `liv_items` ADD COLUMN `autoDay` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("CREATE TABLE IF NOT EXISTS `properties` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `type` TEXT NOT NULL, `address` TEXT NOT NULL, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `prop_units` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `propertyId` INTEGER NOT NULL, `name` TEXT NOT NULL, `type` TEXT NOT NULL, `rent` REAL NOT NULL, `notes` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_prop_units_propertyId` ON `prop_units` (`propertyId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `leases` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `unitId` INTEGER NOT NULL, `tenantId` INTEGER NOT NULL, `startDate` INTEGER NOT NULL, `endDate` INTEGER NOT NULL, `rentAmount` REAL NOT NULL, `periodMonths` INTEGER NOT NULL, `deposit` REAL NOT NULL, `active` INTEGER NOT NULL, `reminderEnabled` INTEGER NOT NULL, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_leases_unitId` ON `leases` (`unitId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `lease_payments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `leaseId` INTEGER NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_lease_payments_leaseId` ON `lease_payments` (`leaseId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `prop_expenses` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `propertyId` INTEGER NOT NULL, `unitId` INTEGER, `category` TEXT NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_prop_expenses_propertyId` ON `prop_expenses` (`propertyId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `debts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `creditor` TEXT NOT NULL, `personId` INTEGER, `type` TEXT NOT NULL, `startDate` INTEGER NOT NULL, `dueDate` INTEGER, `installment` REAL NOT NULL, `periodMonths` INTEGER NOT NULL, `firstDue` INTEGER, `priority` INTEGER NOT NULL, `reminderEnabled` INTEGER NOT NULL, `notes` TEXT NOT NULL, `closed` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `debt_tx` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `debtId` INTEGER NOT NULL, `type` TEXT NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `note` TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_debt_tx_debtId` ON `debt_tx` (`debtId`)")
            }
        }

        /** جداول مصاريف المعيشة */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `liv_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `kind` TEXT NOT NULL, `name` TEXT NOT NULL, `category` TEXT NOT NULL, `amount` REAL NOT NULL, `freq` TEXT NOT NULL, `priority` TEXT NOT NULL, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `liv_periods` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `startDate` INTEGER NOT NULL, `endDate` INTEGER NOT NULL, `notes` TEXT NOT NULL, `savingsGoal` REAL NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `liv_entries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `periodId` INTEGER NOT NULL, `kind` TEXT NOT NULL, `itemId` INTEGER, `name` TEXT NOT NULL, `category` TEXT NOT NULL, `priority` TEXT NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_liv_entries_periodId` ON `liv_entries` (`periodId`)")
            }
        }

        /** ربط حركات الحسابات بحركات السلف والأقساط */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `account_tx` ADD COLUMN `srcType` TEXT")
                db.execSQL("ALTER TABLE `account_tx` ADD COLUMN `srcId` INTEGER")
            }
        }

        /** إضافة جدول المرفقات */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `attachments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `ownerType` TEXT NOT NULL, `ownerId` INTEGER NOT NULL, `name` TEXT NOT NULL, `path` TEXT NOT NULL, `mime` TEXT NOT NULL, `size` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_attachments_ownerType_ownerId` ON `attachments` (`ownerType`, `ownerId`)")
            }
        }

        /** إضافة جداول الحسابات مع الحفاظ على البيانات السابقة */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `accounts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `personId` INTEGER, `notes` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_accounts_personId` ON `accounts` (`personId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `account_tx` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `accountId` INTEGER NOT NULL, `type` TEXT NOT NULL, `amount` REAL NOT NULL, `date` INTEGER NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_account_tx_accountId` ON `account_tx` (`accountId`)")
            }
        }

        fun build(ctx: Context): AppDatabase =
            Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, NAME)
                // ملف واحد بدون WAL لتسهيل النسخ الاحتياطي
                .setJournalMode(JournalMode.TRUNCATE)
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7)
                .build()
    }
}
