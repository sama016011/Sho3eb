package com.sho3eb.app.core

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * إنشاء نسخة مشاركة مباشرة من داخل التطبيق:
 * تُكتب إعدادات النسخة داخل «كتلة توقيع APK» (APK Signing Block) كزوج معرّف/قيمة إضافي.
 * أنظمة التحقق v2/v3 لا تتحقق من الأزواج غير المعروفة، لذا يبقى التوقيع سليماً ويُثبَّت الملف عادياً.
 */
object ApkEdition {
    private const val ID = 0x53484F33          // "SHO3"
    private const val VERITY_PAD = 0x42726577   // يُحذف لأن الحجم يتغير
    private val MAGIC = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)

    private class Layout(val blockStart: Long, val cdOffset: Long, val eocdOffset: Long, val pairs: List<Pair<Int, ByteArray>>)

    private fun le(n: Int) = ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN)

    private fun layout(f: RandomAccessFile): Layout {
        val len = f.length()
        // البحث عن نهاية الدليل المركزي (EOCD)
        val scan = minOf(len, 65_557L).toInt()
        val tail = ByteArray(scan); f.seek(len - scan); f.readFully(tail)
        var eocd = -1
        for (i in scan - 22 downTo 0) {
            if (tail[i] == 0x50.toByte() && tail[i + 1] == 0x4b.toByte() && tail[i + 2] == 0x05.toByte() && tail[i + 3] == 0x06.toByte()) { eocd = i; break }
        }
        require(eocd >= 0) { "EOCD not found" }
        val eocdOffset = len - scan + eocd
        val cdOffset = ByteBuffer.wrap(tail, eocd + 16, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
        // التذييل: الحجم (8) + MAGIC (16)
        val foot = ByteArray(24); f.seek(cdOffset - 24); f.readFully(foot)
        require(foot.copyOfRange(8, 24).contentEquals(MAGIC)) { "APK is not v2-signed" }
        val size = ByteBuffer.wrap(foot, 0, 8).order(ByteOrder.LITTLE_ENDIAN).long
        val blockStart = cdOffset - size - 8
        val pairsBytes = ByteArray((size - 24).toInt()); f.seek(blockStart + 8); f.readFully(pairsBytes)
        val bb = ByteBuffer.wrap(pairsBytes).order(ByteOrder.LITTLE_ENDIAN)
        val pairs = mutableListOf<Pair<Int, ByteArray>>()
        while (bb.remaining() >= 12) {
            val l = bb.long.toInt()
            val id = bb.int
            val v = ByteArray(l - 4); bb.get(v)
            pairs += id to v
        }
        return Layout(blockStart, cdOffset, eocdOffset, pairs)
    }

    /** قراءة إعدادات النسخة من ملف APK (إن وُجدت) */
    fun read(apk: File): String? = runCatching {
        RandomAccessFile(apk, "r").use { f -> layout(f).pairs.firstOrNull { it.first == ID }?.second?.toString(Charsets.UTF_8) }
    }.getOrNull()

    /** نسخ APK مع إضافة/استبدال إعدادات النسخة؛ onProgress من 0 إلى 100 */
    fun write(src: File, dst: File, json: String?, onProgress: (Int) -> Unit = {}) {
        RandomAccessFile(src, "r").use { f ->
            val lo = layout(f)
            val pairs = lo.pairs.filter { it.first != ID && it.first != VERITY_PAD }.toMutableList()
            if (json != null) pairs += ID to json.toByteArray(Charsets.UTF_8)
            val pairsLen = pairs.sumOf { 12L + it.second.size }
            val size = pairsLen + 24
            val block = le((size + 8).toInt())
            block.putLong(size)
            pairs.forEach { (id, v) -> block.putLong(v.size + 4L); block.putInt(id); block.put(v) }
            block.putLong(size); block.put(MAGIC)
            val newBlock = block.array()
            val delta = (lo.blockStart + newBlock.size) - lo.cdOffset
            dst.outputStream().buffered(1 shl 16).use { out ->
                val buf = ByteArray(1 shl 16)
                fun copy(from: Long, to: Long) {
                    f.seek(from); var left = to - from
                    while (left > 0) { val n = f.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (n <= 0) break; out.write(buf, 0, n); left -= n; onProgress(((to - left) * 95 / f.length()).toInt()) }
                }
                copy(0, lo.blockStart)
                out.write(newBlock)
                copy(lo.cdOffset, lo.eocdOffset)
                val eocd = ByteArray((f.length() - lo.eocdOffset).toInt()); f.seek(lo.eocdOffset); f.readFully(eocd)
                ByteBuffer.wrap(eocd, 16, 4).order(ByteOrder.LITTLE_ENDIAN).putInt((lo.cdOffset + delta).toInt())
                out.write(eocd)
            }
            onProgress(100)
        }
    }
}
