package com.sho3eb.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.WebPanel
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.delay

/** فتح البرنامج على الكمبيوتر من متصفح Chrome */
@Composable
fun WebPanelCard() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(WebPanel.enabled) }
    var url by remember { mutableStateOf(WebPanel.url()) }
    var running by remember { mutableStateOf(WebPanel.running) }
    LaunchedEffect(on) { while (true) { url = WebPanel.url(); running = WebPanel.running; delay(3000) } }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(tr("🖥️ فتح البرنامج على الكمبيوتر (Chrome)", "🖥️ Open on your computer (Chrome)"))
            Text(tr("شغّل الخاصية ثم انسخ الرابط وافتحه في Chrome على اللاب توب. يجب أن يكون الهاتف والكمبيوتر على نفس شبكة الواي فاي، والبيانات تبقى على هاتفك.",
                "Turn it on, copy the link and open it in Chrome on your laptop. Phone and computer must be on the same Wi-Fi; your data stays on the phone."),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SwitchRow(tr("تشغيل الوصول من الكمبيوتر", "Enable computer access"), null, on) {
                on = it; WebPanel.enabled = it
                if (it) WebPanel.start(ctx) else WebPanel.stop()
                running = WebPanel.running; url = WebPanel.url()
            }
            if (on) {
                val u = url
                if (u == null) Text(tr("⚠️ الهاتف غير متصل بشبكة واي فاي. اتصل بالواي فاي (أو شغّل نقطة اتصال الهاتف واتصل بها من اللاب توب).", "⚠️ Not on Wi-Fi. Connect to Wi-Fi (or turn on the phone hotspot and join it from the laptop)."), color = WarnAmber)
                else {
                    SelectionContainer { Text(u, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", u))
                            toast(ctx, tr("تم نسخ الرابط", "Link copied"))
                        }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text(tr("نسخ الرابط", "Copy link")) }
                        OutlinedButton(onClick = { runCatching { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, u), null)) } }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Share, null); Spacer(Modifier.width(6.dp)); Text(tr("إرسال للكمبيوتر", "Send to PC"))
                        }
                    }
                    Text(if (running) tr("🟢 يعمل الآن", "🟢 Running") else tr("🔴 متوقف — أعد تشغيل الخاصية", "🔴 Stopped — toggle again"), style = MaterialTheme.typography.labelMedium)
                    TextButton(onClick = { WebPanel.newToken(); url = WebPanel.url(); toast(ctx, tr("تم تغيير الرابط، والرابط القديم لم يعد يعمل", "Link changed; the old one no longer works")) }) {
                        Text(tr("🔒 تغيير الرابط (لإلغاء أي جهاز آخر)", "🔒 Change link (revoke other devices)"))
                    }
                    Text(tr("في المتصفح: لوحة الإحصاءات، الأصناف (إضافة وتعديل وصور)، بيع سريع، الفواتير، العملاء والموردون، وقائمة الأسعار. أبقِ التطبيق يعمل على الهاتف أثناء الاستخدام.",
                        "In the browser: dashboard, items (add/edit/photos), quick sale, invoices, customers & suppliers, and price list. Keep the app running on the phone."),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
