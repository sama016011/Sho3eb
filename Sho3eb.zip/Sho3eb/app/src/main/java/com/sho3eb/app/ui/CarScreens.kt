@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Locale

// =====================================================================
//                              السيارة
// =====================================================================
@Composable
fun CarsScreen(nav: NavController) {
    val dao = remember { appDao() }
    val cars by flowState(emptyList<Vehicle>()) { dao.vehiclesFlow() }
    val exps by flowState(emptyList<CarExpense>()) { dao.carExpensesFlow() }
    val rems by flowState(emptyList<CarReminder>()) { dao.carRemindersFlow() }
    var add by remember { mutableStateOf(false) }
    val month = LivingAuto.monthRange()

    ScreenScaffold(
        title = tr("السيارة", "Vehicles"), onBack = { nav.popBackStack() },
        fab = { ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("سيارة", "Vehicle")) }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (cars.isEmpty()) item { EmptyState(Icons.Filled.DirectionsCar, tr("أضف سيارتك لتسجيل الوقود والصيانة، ومعرفة الاستهلاك، والتذكير بالزيت والتأمين والاستمارة.", "Add your car to track fuel, maintenance and reminders.")) }
            items(cars, key = { it.id }) { v ->
                val mine = exps.filter { it.vehicleId == v.id }
                val due = rems.filter { it.vehicleId == v.id && Cars.isDue(it, v.odometer) }
                Card(onClick = { nav.navigate("car/${v.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🚗", fontSize = 30.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(v.name, fontWeight = FontWeight.Bold)
                                Text(listOf(v.model, if (v.year > 0) "${v.year}" else "", v.plate).filter { it.isNotBlank() }.joinToString(" • ") + tr(" • العداد ", " • ") + "${v.odometer}" + tr(" كم", " km"), style = MaterialTheme.typography.bodySmall)
                            }
                            if (due.isNotEmpty()) StatusChip(tr("${due.size} موعد", "${due.size} due"), WarnAmber)
                        }
                        Spacer(Modifier.height(6.dp))
                        Row {
                            KeyMini(tr("هذا الشهر", "This month"), Fmt.num(mine.filter { it.date in month }.sumOf { it.amount }), Modifier.weight(1f))
                            KeyMini(tr("الإجمالي", "Total"), Fmt.num(mine.sumOf { it.amount }), Modifier.weight(1f))
                            val st = Cars.stats(mine)
                            KeyMini(tr("لتر/100كم", "L/100km"), if (st.per100 > 0) String.format(Locale.US, "%.1f", st.per100) else "-", Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
    if (add) VehicleDialog(null, onDismiss = { add = false }) { id -> add = false; nav.navigate("car/$id") }
}

@Composable
private fun VehicleDialog(existing: Vehicle?, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var model by remember { mutableStateOf(existing?.model ?: "") }
    var year by remember { mutableStateOf(existing?.year?.takeIf { it > 0 }?.toString() ?: "") }
    var plate by remember { mutableStateOf(existing?.plate ?: "") }
    var odo by remember { mutableStateOf(existing?.odometer?.takeIf { it > 0 }?.toString() ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var presets by remember { mutableStateOf(existing == null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("إضافة سيارة", "Add vehicle") else tr("تعديل السيارة", "Edit vehicle")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم مميز (مثل: سيارتي، سيارة البيت)", "Nickname")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(model, { model = it }, label = { Text(tr("الماركة والموديل", "Make & model")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField(year, { year = it }, tr("سنة الصنع", "Year"), Modifier.weight(1f))
                    OutlinedTextField(plate, { plate = it }, label = { Text(tr("اللوحة", "Plate")) }, singleLine = true, modifier = Modifier.weight(1f))
                }
                NumberField(odo, { odo = it }, tr("قراءة العداد الحالية (كم)", "Current odometer (km)"))
                if (existing == null) SwitchRow(tr("إضافة المواعيد الأساسية", "Add standard schedules"), tr("الزيت، التأمين، الاستمارة، الفحص، الإطارات، الصيانة", "Oil, insurance, registration, inspection, tires, service"), presets) { presets = it }
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank() && model.isBlank()) { toast(ctx, tr("أدخل اسم السيارة", "Enter a name")); return@TextButton }
                val nm = name.trim().ifBlank { model.trim() }
                val km = odo.toLongOrNull() ?: 0L
                scope.launch {
                    if (existing != null) { dao.updateVehicle(existing.copy(name = nm, model = model.trim(), year = year.toIntOrNull() ?: 0, plate = plate.trim(), odometer = km, notes = notes.trim())); onSaved(existing.id) }
                    else {
                        val id = dao.insertVehicle(Vehicle(name = nm, model = model.trim(), year = year.toIntOrNull() ?: 0, plate = plate.trim(), odometer = km, notes = notes.trim()))
                        if (presets) Cars.presets.forEach { (t, title, iv) ->
                            dao.insertCarReminder(CarReminder(vehicleId = id, title = title, type = t, lastDate = Fmt.today(), lastKm = km, intervalMonths = iv.first, intervalKm = iv.second))
                        }
                        onSaved(id)
                    }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
fun CarDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val car by flowState<Vehicle?>(null, id) { dao.vehicleFlow(id) }
    val allExp by flowState(emptyList<CarExpense>()) { dao.carExpensesFlow() }
    val allRem by flowState(emptyList<CarReminder>()) { dao.carRemindersFlow() }
    val linked = rememberLinkedIds(AccountTx.SRC_CAR)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var range by rememberSaveable { mutableIntStateOf(2) }
    var addExp by remember { mutableStateOf(false) }
    var remEdit by remember { mutableStateOf<CarReminder?>(null) }
    var newRem by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var delE by remember { mutableStateOf<CarExpense?>(null) }
    var postE by remember { mutableStateOf<CarExpense?>(null) }
    var odoDlg by remember { mutableStateOf(false) }

    val v = car
    if (v == null) { ScreenScaffold(tr("السيارة", "Vehicle"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val now = LocalDate.now()
    val rng: LongRange? = when (range) { 0 -> LivingAuto.monthRange(); 1 -> now.withDayOfYear(1).toEpochDay()..now.withDayOfYear(now.lengthOfYear()).toEpochDay(); else -> null }
    val exps = allExp.filter { it.vehicleId == v.id && (rng == null || it.date in rng) }
    val rems = allRem.filter { it.vehicleId == v.id }
    val st = Cars.stats(exps)

    ScreenScaffold(
        title = v.name, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(null, doc = { Docs.car(v, allExp, allRem, rng) }) { c -> Reports.doc(c, Docs.car(v, allExp, allRem, rng)) }
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null) }
        },
        fab = {
            if (tab == 0) ExtendedFloatingActionButton(onClick = { addExp = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("مصروف", "Expense")) })
            else ExtendedFloatingActionButton(onClick = { newRem = true }, icon = { Icon(Icons.Filled.AddAlarm, null) }, text = { Text(tr("موعد", "Schedule")) })
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("المصروفات", "Expenses")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("المواعيد", "Schedules") + if (rems.any { Cars.isDue(it, v.odometer) }) " •" else "") })
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Card(onClick = { odoDlg = true }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Speed, null)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(tr("العداد: ", "Odometer: ") + "${v.odometer}" + tr(" كم", " km"), fontWeight = FontWeight.Bold)
                                Text(tr("اضغط لتحديث القراءة", "Tap to update"), style = MaterialTheme.typography.bodySmall)
                            }
                            Icon(Icons.Filled.Edit, null)
                        }
                    }
                }
                if (tab == 0) {
                    item { HChips { listOf(tr("هذا الشهر", "This month"), tr("هذه السنة", "This year"), tr("الكل", "All")).forEachIndexed { i, s -> FilterChip(range == i, { range = i }, label = { Text(s) }) } } }
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                KeyValue(tr("إجمالي المصروفات", "Total"), Fmt.money(st.total), DangerRed)
                                KeyValue(tr("الوقود", "Fuel"), Fmt.money(st.fuel))
                                if (st.per100 > 0) KeyValue(tr("الاستهلاك", "Consumption"), String.format(Locale.US, "%.1f L/100km • %.1f km/L", st.per100, st.kmPerLiter))
                                if (st.costPerKm > 0) KeyValue(tr("تكلفة الكيلو", "Cost per km"), Fmt.money(st.costPerKm))
                                exps.groupBy { it.type }.map { it.key to it.value.sumOf { e -> e.amount } }.sortedByDescending { it.second }.forEach { (k, x) ->
                                    val t = Cars.type(k)
                                    KeyValue(t.emoji + " " + t.label, Fmt.num(x))
                                }
                            }
                        }
                    }
                    if (exps.isEmpty()) item { Text(tr("لا توجد مصروفات في هذه الفترة. سجّل التعبئة مع قراءة العداد واللترات لحساب الاستهلاك.", "No expenses. Log fuel with odometer & liters to compute consumption."), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(exps, key = { it.id }) { e ->
                        val t = Cars.type(e.type)
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(t.emoji, fontSize = 22.sp)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(t.label + " • " + Fmt.money(e.amount), fontWeight = FontWeight.SemiBold)
                                    Text(Fmt.date(e.date) + (if (e.odometer > 0) " • ${e.odometer} " + tr("كم", "km") else "") + (if (e.liters > 0) " • " + Fmt.num(e.liters) + tr(" لتر", " L") else "") + (if (e.note.isNotBlank()) " • " + e.note else ""), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                }
                                AttachmentButton(Attachments.CAR_EXP, e.id)
                                PostButton(e.id in linked) { postE = e }
                                IconButton(onClick = { delE = e }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                            }
                        }
                    }
                } else {
                    if (rems.isEmpty()) item { EmptyState(Icons.Filled.Alarm, tr("أضف مواعيد مثل تغيير الزيت والتأمين والاستمارة", "Add schedules like oil change and insurance")) }
                    items(rems, key = { "r${it.id}" }) { r ->
                        val due = Cars.isDue(r, v.odometer)
                        Card(onClick = { remEdit = r }, modifier = Modifier.fillMaxWidth(), colors = if (due) CardDefaults.cardColors(containerColor = WarnAmber.copy(alpha = 0.12f)) else CardDefaults.cardColors()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(Cars.type(r.type).emoji, fontSize = 24.sp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(r.title, fontWeight = FontWeight.Bold)
                                    Text(Cars.statusText(r, v.odometer), style = MaterialTheme.typography.bodySmall, color = if (due) WarnAmber else MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(listOfNotNull(
                                        if (r.intervalMonths > 0) tr("كل ${r.intervalMonths} شهر", "every ${r.intervalMonths} mo") else null,
                                        if (r.intervalKm > 0) tr("كل ${r.intervalKm} كم", "every ${r.intervalKm} km") else null
                                    ).joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                                }
                                if (!r.enabled) StatusChip(tr("متوقف", "Off"), MaterialTheme.colorScheme.outline)
                                else TextButton(onClick = {
                                    scope.launch { dao.updateCarReminder(r.copy(lastDate = Fmt.today(), lastKm = v.odometer, dueDate = null)); toast(ctx, tr("تم ✅ وجُدّد الموعد القادم", "Done ✅ next scheduled")) }
                                }) { Text(tr("تم", "Done")) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (addExp) CarExpenseDialog(v) { addExp = false }
    if (newRem) CarReminderDialog(v, null) { newRem = false }
    remEdit?.let { r -> CarReminderDialog(v, r) { remEdit = null } }
    if (edit) VehicleDialog(v, onDismiss = { edit = false }) { edit = false }
    if (odoDlg) {
        var km by remember { mutableStateOf(v.odometer.toString()) }
        AlertDialog(
            onDismissRequest = { odoDlg = false },
            title = { Text(tr("قراءة العداد", "Odometer")) },
            text = { NumberField(km, { km = it }, tr("الكيلومترات", "Kilometers")) },
            confirmButton = { TextButton(onClick = { km.toLongOrNull()?.let { k -> scope.launch { dao.updateVehicle(v.copy(odometer = k)) } }; odoDlg = false }) { Text(tr("حفظ", "Save")) } },
            dismissButton = { TextButton(onClick = { odoDlg = false }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
    if (del) ConfirmDialog(tr("حذف السيارة", "Delete vehicle"), tr("حذف «${v.name}» بكل مصروفاتها ومواعيدها والحركات المرتبطة بها؟", "Delete with all expenses, schedules and linked entries?"), onDismiss = { del = false }) {
        del = false
        scope.launch { allExp.filter { it.vehicleId == v.id }.forEach { Attachments.deleteFor(Attachments.CAR_EXP, it.id) }; dao.deleteVehicleFull(v.id); nav.popBackStack() }
    }
    delE?.let { e ->
        ConfirmDialog(tr("حذف المصروف", "Delete expense"), tr("حذف ${Cars.type(e.type).label} بمبلغ ${Fmt.money(e.amount)}؟", "Delete ${Fmt.money(e.amount)}?"), onDismiss = { delE = null }) {
            delE = null
            scope.launch { Attachments.deleteFor(Attachments.CAR_EXP, e.id); dao.deleteLinkedTx(AccountTx.SRC_CAR, e.id); LivingLink.remove(LivingLink.CAR, e.id); dao.deleteCarExpense(e.id) }
        }
    }
    postE?.let { e ->
        PostToAccountDialog(tr("خصم من حساب", "Withdraw"), false, onDismiss = { postE = null }) { acc ->
            postE = null
            scope.launch { Posting.post(acc, AccountTx.SRC_CAR, e.id, false, e.amount, e.date, v.name + " - " + Cars.type(e.type).label); toast(ctx, tr("تم الترحيل", "Posted")) }
        }
    }
}

@Composable
private fun CarExpenseDialog(v: Vehicle, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var type by remember { mutableStateOf("FUEL") }
    var amount by remember { mutableStateOf("") }
    var liters by remember { mutableStateOf("") }
    var odo by remember { mutableStateOf(if (v.odometer > 0) v.odometer.toString() else "") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var note by remember { mutableStateOf("") }
    var toLiving by remember { mutableStateOf(true) }
    var doneRem by remember { mutableStateOf(true) }
    val pending = remember { mutableStateListOf<Uri>() }
    val post = remember { mutableStateOf(Posting.lastAccount("car")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("مصروف ", "Expense • ") + v.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HChips { Cars.expenseTypes.forEach { t -> FilterChip(type == t.key, { type = t.key }, label = { Text(t.emoji + " " + t.label) }) } }
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                if (type == "FUEL") NumberField(liters, { liters = it }, tr("عدد اللترات (لحساب الاستهلاك)", "Liters (for consumption)"))
                NumberField(odo, { odo = it }, tr("قراءة العداد (اختياري)", "Odometer (optional)"))
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة / المحطة / الورشة", "Note / station / garage")) }, modifier = Modifier.fillMaxWidth())
                if (type in listOf("OIL", "INSURANCE", "REG", "INSPECT", "TIRES", "MAINT")) SwitchRow(tr("تحديث موعد التذكير المرتبط", "Update related schedule"), null, doneRem) { doneRem = it }
                SwitchRow(tr("تسجيل في مصاريف المعيشة (مواصلات)", "Record in living expenses (transport)"), null, toLiving) { toLiving = it }
                AccountPickRow(post, tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
                PendingAttachRow(pending)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Fmt.parse(amount)
                if (a == null || a <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                val km = odo.toLongOrNull() ?: 0L
                scope.launch {
                    val id = dao.insertCarExpense(CarExpense(vehicleId = v.id, type = type, amount = a, date = date, odometer = km, liters = Fmt.parse(liters) ?: 0.0, note = note.trim()))
                    Attachments.addAll(ctx, Attachments.CAR_EXP, id, pending.toList())
                    if (km > v.odometer) dao.updateVehicle(v.copy(odometer = km))
                    if (doneRem) dao.allCarReminders().filter { it.vehicleId == v.id && it.type == type }.forEach { dao.updateCarReminder(it.copy(lastDate = date, lastKm = if (km > 0) km else v.odometer, dueDate = null)) }
                    Posting.setLastAccount("car", post.value)
                    Posting.post(post.value, AccountTx.SRC_CAR, id, false, a, date, v.name + " - " + Cars.type(type).label)
                    if (toLiving) LivingLink.addExpense(ctx, LivingLink.CAR, id, v.name + " - " + Cars.type(type).label, "TRANSPORT", a, date, note.trim())
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun CarReminderDialog(v: Vehicle, existing: CarReminder?, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: "OTHER") }
    var months by remember { mutableStateOf(existing?.intervalMonths?.takeIf { it > 0 }?.toString() ?: "") }
    var km by remember { mutableStateOf(existing?.intervalKm?.takeIf { it > 0 }?.toString() ?: "") }
    var lastDate by remember { mutableStateOf(existing?.lastDate ?: Fmt.today()) }
    var lastKm by remember { mutableStateOf((existing?.lastKm ?: v.odometer).takeIf { it > 0 }?.toString() ?: "") }
    var dueDate by remember { mutableStateOf(existing?.dueDate) }
    var enabled by remember { mutableStateOf(existing?.enabled ?: true) }
    var confirmDel by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("موعد جديد", "New schedule") else existing.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (existing == null) HChips {
                    Cars.presets.forEach { (t, n, iv) -> AssistChip(onClick = { type = t; title = n; months = iv.first.toString(); km = if (iv.second > 0) iv.second.toString() else "" }, label = { Text(n) }) }
                }
                OutlinedTextField(title, { title = it }, label = { Text(tr("البند", "Item")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField(months, { months = it }, tr("كل كم شهر", "Every N months"), Modifier.weight(1f))
                    NumberField(km, { km = it }, tr("كل كم كيلو", "Every N km"), Modifier.weight(1f))
                }
                DateField(tr("آخر مرة (التاريخ)", "Last done (date)"), lastDate, { d -> if (d != null) lastDate = d })
                NumberField(lastKm, { lastKm = it }, tr("آخر مرة (العداد)", "Last done (km)"))
                DateField(tr("أو تاريخ محدد (مثل انتهاء التأمين)", "Or a fixed date (e.g. expiry)"), dueDate, { d -> dueDate = d }, allowClear = true)
                SwitchRow(tr("التذكير مفعّل", "Enabled"), null, enabled) { enabled = it }
                if (existing != null) TextButton(onClick = { confirmDel = true }) { Text(tr("حذف الموعد", "Delete"), color = DangerRed) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val r = CarReminder(
                    vehicleId = v.id, title = title.trim().ifBlank { tr("موعد", "Schedule") }, type = type, lastDate = lastDate, lastKm = lastKm.toLongOrNull() ?: 0L,
                    intervalMonths = months.toIntOrNull() ?: 0, intervalKm = km.toLongOrNull() ?: 0L, dueDate = dueDate, enabled = enabled
                )
                scope.launch { if (existing == null) dao.insertCarReminder(r) else dao.updateCarReminder(r.copy(id = existing.id)); onDismiss() }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
    if (confirmDel && existing != null) ConfirmDialog(tr("حذف الموعد", "Delete"), existing.title, onDismiss = { confirmDel = false }) {
        scope.launch { dao.deleteCarReminder(existing.id); confirmDel = false; onDismiss() }
    }
}
