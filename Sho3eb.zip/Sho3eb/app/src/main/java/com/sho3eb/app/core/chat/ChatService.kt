package com.sho3eb.app.core.chat

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.sho3eb.app.R
import com.sho3eb.app.core.tr
import java.util.concurrent.TimeUnit

/** «البقاء متصلاً»: يبقي الاتصال اللحظي لاستقبال الرسائل والمكالمات فوراً والتطبيق مغلق */
class ChatService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Chat.channels()
        val pi = PendingIntent.getActivity(this, 7, Intent(this, com.sho3eb.app.ui.MainActivity::class.java).putExtra("route", "chat"), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, Chat.bgChannel).setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(tr("التواصل متصل", "Chat connected")).setContentText(tr("جاهز لاستقبال الرسائل والمكالمات", "Ready for messages and calls"))
            .setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).setSilent(true).setShowWhen(false)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).setCategory(NotificationCompat.CATEGORY_SERVICE).setContentIntent(pi).build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING else if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        runCatching { ServiceCompat.startForeground(this, 4601, n, type) }.onFailure { stopSelf(); return START_NOT_STICKY }
        Chat.start()
        return START_STICKY
    }

    companion object {
        /** إعادة تشغيل الخدمة لتطبيق إعداد إخفاء الإشعار */
        fun restart(ctx: Context) { runCatching { ctx.stopService(Intent(ctx, ChatService::class.java)) }; apply(ctx) }
        fun apply(ctx: Context) {
            val i = Intent(ctx, ChatService::class.java)
            if (Chat.keepConnected && Supa.configured) runCatching { ContextCompat.startForegroundService(ctx, i) } else ctx.stopService(i)
            ChatWorker.schedule(ctx)
        }
    }
}

/** مزامنة دورية للرسائل (كل 15 دقيقة) عندما لا يكون الاتصال الدائم مفعلاً */
class ChatWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        if (!Supa.configured) return Result.success()
        runCatching { Chat.channels(); Supa.ensureSession(); Chat.sync() }
        return Result.success()
    }
    companion object {
        fun schedule(ctx: Context) {
            if (!Supa.configured) return
            val req = PeriodicWorkRequestBuilder<ChatWorker>(15, TimeUnit.MINUTES).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("chat_sync", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
