package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToLong

fun round2(v: Double): Double = (v * 100).roundToLong() / 100.0

fun dueDate(startEpochDay: Long, type: String, count: Int, k: Int): LocalDate {
    val s = LocalDate.ofEpochDay(startEpochDay)
    val n = (count.coerceAtLeast(1) * k).toLong()
    return when (type) {
        Period.DAY -> s.plusDays(n)
        Period.WEEK -> s.plusWeeks(n)
        else -> s.plusMonths(n)
    }
}

// ======================= الجمعيات =======================
data class RoundInfo(
    val round: Int,
    val due: LocalDate,
    val recipient: AssocMember,
    val paidMemberIds: Set<Long>,
    val collected: Double,
    val expected: Double,
    val payout: AssocPayout?
) {
    val allPaid: Boolean get() = collected + 0.005 >= expected
}

fun associationRounds(
    a: Association,
    members: List<AssocMember>,
    payments: List<AssocPayment>,
    payouts: List<AssocPayout>
): List<RoundInfo> {
    val sorted = members.sortedBy { it.turnOrder }
    val n = sorted.size
    return (0 until n).map { r ->
        val pr = payments.filter { it.round == r }
        RoundInfo(
            round = r,
            due = dueDate(a.startDate, a.periodType, a.periodCount, r),
            recipient = sorted[r],
            paidMemberIds = pr.map { it.memberId }.toSet(),
            collected = pr.sumOf { it.amount },
            expected = a.shareAmount * n,
            payout = payouts.firstOrNull { it.round == r }
        )
    }
}

fun assocFinished(rounds: List<RoundInfo>): Boolean = rounds.isNotEmpty() && rounds.all { it.payout != null }

// ======================= السلف =======================
data class LoanSummary(
    val personId: Long,
    val taken: Double,
    val paid: Double,
    val lastDate: Long,
    val dueDate: Long?
) {
    val balance: Double get() = round2(taken - paid)
}

fun loanSummaries(txs: List<LoanTx>): List<LoanSummary> =
    txs.groupBy { it.personId }.map { (pid, l) ->
        LoanSummary(
            personId = pid,
            taken = l.filter { it.type == LoanTx.LOAN }.sumOf { it.amount },
            paid = l.filter { it.type == LoanTx.PAY }.sumOf { it.amount },
            lastDate = l.maxOf { it.date },
            dueDate = l.filter { it.type == LoanTx.LOAN }.mapNotNull { it.dueDate }.maxOrNull()
        )
    }

fun loanBalance(txs: List<LoanTx>): Double =
    round2(txs.sumOf { if (it.type == LoanTx.LOAN) it.amount else -it.amount })

// ======================= البيع بالتقسيط =======================
data class Installment(val index: Int, val due: LocalDate, val amount: Double, val paid: Double) {
    val remaining: Double get() = round2((amount - paid).coerceAtLeast(0.0))
    val isPaid: Boolean get() = remaining < 0.005
}

fun installmentAmount(s: Sale): Double {
    val count = s.installmentsCount.coerceAtLeast(1)
    val financed = (s.totalPrice - s.downPayment).coerceAtLeast(0.0)
    return floor(financed / count * 100) / 100
}

fun saleSchedule(s: Sale, payments: List<SalePayment>): List<Installment> {
    val count = s.installmentsCount.coerceAtLeast(1)
    val financed = (s.totalPrice - s.downPayment).coerceAtLeast(0.0)
    val base = installmentAmount(s)
    var pool = payments.sumOf { it.amount }
    return (0 until count).map { i ->
        val amt = if (i == count - 1) round2(financed - base * (count - 1)) else base
        val p = min(pool, amt).coerceAtLeast(0.0)
        pool -= p
        Installment(i, dueDate(s.startDate, s.periodType, s.periodCount, i), amt, p)
    }
}

fun saleRemaining(s: Sale, payments: List<SalePayment>): Double =
    round2((s.totalPrice - s.downPayment - payments.sumOf { it.amount }).coerceAtLeast(0.0))

// ======================= المستحقات =======================
enum class DueKind { ASSOC, LOAN, SALE, RENT, DEBT, CAR, SUB, INV, DOC }

data class DueItem(
    val kind: DueKind,
    val refId: Long,
    val title: String,
    val subtitle: String,
    val amount: Double,
    val due: LocalDate,
    val phone: String
)

data class AllData(
    val people: List<Person> = emptyList(),
    val associations: List<Association> = emptyList(),
    val members: List<AssocMember> = emptyList(),
    val assocPayments: List<AssocPayment> = emptyList(),
    val payouts: List<AssocPayout> = emptyList(),
    val loanTx: List<LoanTx> = emptyList(),
    val sales: List<Sale> = emptyList(),
    val salePayments: List<SalePayment> = emptyList(),
    val properties: List<Property> = emptyList(),
    val units: List<PropUnit> = emptyList(),
    val leases: List<Lease> = emptyList(),
    val leasePayments: List<LeasePayment> = emptyList(),
    val debts: List<Debt> = emptyList(),
    val debtTx: List<DebtTx> = emptyList(),
    val vehicles: List<Vehicle> = emptyList(),
    val carReminders: List<CarReminder> = emptyList(),
    val subscriptions: List<Subscription> = emptyList(),
    val invoices: List<Invoice> = emptyList(),
    val invoiceItems: List<InvoiceItem> = emptyList(),
    val invoicePayments: List<InvoicePayment> = emptyList(),
    val vaultDocs: List<VaultDoc> = emptyList()
)

suspend fun loadAllData(dao: AppDao): AllData = AllData(
    dao.allPeople(), dao.allAssociations(), dao.allMembers(), dao.allAssocPayments(),
    dao.allPayouts(), dao.allLoanTx(), dao.allSales(), dao.allSalePayments(),
    dao.allProperties(), dao.allUnits(), dao.allLeases(), dao.allLeasePayments(), dao.allDebts(), dao.allDebtTx(),
    dao.allVehicles(), dao.allCarReminders(), dao.allSubscriptions(),
    dao.allInvoices(), dao.allInvoiceItems(), dao.allInvoicePayments(), dao.allVaultDocs()
)

fun computeDueItems(d: AllData, today: LocalDate, horizonDays: Int, onlyWithReminders: Boolean): List<DueItem> {
    val limit = today.plusDays(horizonDays.toLong())
    val pm = d.people.associateBy { it.id }
    val out = mutableListOf<DueItem>()

    for (a in d.associations) {
        if (onlyWithReminders && !a.reminderEnabled) continue
        val mem = d.members.filter { it.associationId == a.id }
        if (mem.isEmpty()) continue
        val rounds = associationRounds(
            a, mem,
            d.assocPayments.filter { it.associationId == a.id },
            d.payouts.filter { it.associationId == a.id }
        )
        for (r in rounds) {
            if (r.due.isAfter(limit)) break
            val unpaid = mem.count { it.id !in r.paidMemberIds }
            val recipient = pm[r.recipient.personId]
            if (unpaid > 0) {
                out += DueItem(
                    DueKind.ASSOC, a.id, a.name,
                    tr("الدورة ${r.round + 1} • لم يدفع $unpaid", "Round ${r.round + 1} • $unpaid unpaid"),
                    unpaid * a.shareAmount, r.due, ""
                )
            } else if (r.payout == null && !r.due.isAfter(today)) {
                out += DueItem(
                    DueKind.ASSOC, a.id, a.name,
                    tr("تسليم الدورة ${r.round + 1} إلى ${recipient?.name ?: "-"}", "Deliver round ${r.round + 1} to ${recipient?.name ?: "-"}"),
                    r.collected, r.due, recipient?.phone ?: ""
                )
            }
        }
    }

    for (s in d.sales) {
        if (onlyWithReminders && !s.reminderEnabled) continue
        val sch = saleSchedule(s, d.salePayments.filter { it.saleId == s.id })
        val pending = sch.filter { !it.isPaid && !it.due.isAfter(limit) }
        if (pending.isNotEmpty()) {
            val p = pm[s.personId]
            out += DueItem(
                DueKind.SALE, s.id, p?.name ?: "-",
                tr("قسط ${s.product} (${pending.size})", "${s.product} installment (${pending.size})"),
                pending.sumOf { it.remaining }, pending.first().due, p?.phone ?: ""
            )
        }
    }

    for (ls in loanSummaries(d.loanTx)) {
        val dd = ls.dueDate ?: continue
        if (ls.balance <= 0.005) continue
        val due = LocalDate.ofEpochDay(dd)
        if (due.isAfter(limit)) continue
        val p = pm[ls.personId]
        out += DueItem(DueKind.LOAN, ls.personId, p?.name ?: "-", tr("سداد سلفة", "Loan repayment"), ls.balance, due, p?.phone ?: "")
    }

    // الإيجارات: الدفعات المستحقة وقرب انتهاء العقد
    val um = d.units.associateBy { it.id }
    val prm = d.properties.associateBy { it.id }
    for (l in d.leases) {
        if (!l.active || (onlyWithReminders && !l.reminderEnabled)) continue
        val t = pm[l.tenantId]
        val u = um[l.unitId]
        val place = (prm[u?.propertyId]?.name ?: "") + (u?.let { " - " + it.name } ?: "")
        val pending = Rent.schedule(l, d.leasePayments).filter { !it.isPaid && !it.due.isAfter(limit) }
        if (pending.isNotEmpty()) out += DueItem(
            DueKind.RENT, l.id, t?.name ?: "-", tr("إيجار $place (${pending.size})", "Rent $place (${pending.size})"),
            pending.sumOf { it.remaining }, pending.first().due, t?.phone ?: ""
        )
        val end = LocalDate.ofEpochDay(l.endDate)
        if (!end.isBefore(today) && !end.isAfter(today.plusDays(30))) out += DueItem(
            DueKind.RENT, l.id, t?.name ?: "-", tr("ينتهي عقد $place", "Lease ends: $place"), 0.0, end, t?.phone ?: ""
        )
    }

    // ديوني: الأقساط والمواعيد المستحقة عليّ
    for (db in d.debts) {
        if (db.closed || (onlyWithReminders && !db.reminderEnabled)) continue
        val nd = Debts.nextDue(db, d.debtTx) ?: continue
        if (nd.isAfter(limit)) continue
        out += DueItem(DueKind.DEBT, db.id, db.creditor, tr("سداد دين عليّ", "Debt payment I owe"), Debts.nextAmount(db, d.debtTx), nd, "")
    }

    // السيارة: مواعيد الزيت والتأمين والاستمارة والفحص
    val vm = d.vehicles.associateBy { it.id }
    for (r in d.carReminders) {
        val v = vm[r.vehicleId] ?: continue
        if (!r.enabled) continue
        val nd = Cars.nextDate(r)
        val byKm = Cars.nextKm(r)?.let { v.odometer >= it - 500 } == true
        val due = when {
            nd != null && !nd.isAfter(limit) -> nd
            byKm -> today
            else -> continue
        }
        out += DueItem(DueKind.CAR, v.id, v.name, r.title, 0.0, due, "")
    }

    // الاشتراكات والفواتير الدورية
    for (s in d.subscriptions) {
        if (!s.active) continue
        val nd = LocalDate.ofEpochDay(s.nextDate)
        val lim = maxOf(limit, today.plusDays(s.remindDays.toLong()))
        if (nd.isAfter(lim)) continue
        out += DueItem(DueKind.SUB, s.id, s.name, Subs.cat(s.category).label, s.amount, nd, "")
    }

    // فواتير المحل الآجلة (لي على العملاء أو عليّ للموردين)
    for (r in Shop.rows(d.invoices.filter { (it.dueDate != null || it.instCount > 0) && (it.type == Shop.SALE || it.type == Shop.PURCHASE) }, d.invoiceItems, d.invoicePayments)) {
        if (r.isPaid) continue
        if (r.hasInst) {
            val ni = r.nextInst ?: continue
            val nd = LocalDate.ofEpochDay(ni.due)
            if (nd.isAfter(limit)) continue
            val amount = if (r.lateAmount > 0) r.lateAmount else ni.remaining
            val sub = Shop.instLabel(ni, r.inv.instCount) + " • " + Shop.numberText(r.inv)
            out += DueItem(DueKind.INV, r.inv.id, r.inv.partyName.ifBlank { Shop.numberText(r.inv) }, sub, amount, nd, if (r.inv.type == Shop.SALE) r.inv.partyPhone else "")
            continue
        }
        val nd = LocalDate.ofEpochDay(r.inv.dueDate!!)
        if (nd.isAfter(limit)) continue
        val sub = (if (r.inv.type == Shop.SALE) tr("فاتورة بيع ", "Sales invoice ") else tr("فاتورة مورد ", "Supplier invoice ")) + Shop.numberText(r.inv)
        out += DueItem(DueKind.INV, r.inv.id, r.inv.partyName.ifBlank { Shop.numberText(r.inv) }, sub, r.remaining, nd, if (r.inv.type == Shop.SALE) r.inv.partyPhone else "")
    }

    // المستندات القريبة من الانتهاء
    for (v in d.vaultDocs) {
        val exp = v.expiryDate ?: continue
        val nd = LocalDate.ofEpochDay(exp)
        if (nd.isAfter(maxOf(limit, today.plusDays(v.remindDays.toLong())))) continue
        if (nd.isBefore(today.minusDays(90))) continue
        out += DueItem(DueKind.DOC, v.id, v.title, Vault.type(v.type).label + (if (v.holder.isNotBlank()) " • " + v.holder else ""), 0.0, nd, "")
    }
    return out.sortedBy { it.due }
}

// ======================= الحسابات =======================
/** حركة مع الرصيد قبلها وبعدها */
data class AccountLine(val tx: AccountTx, val before: Double, val after: Double)

fun accountLines(txs: List<AccountTx>): List<AccountLine> {
    var b = 0.0
    return txs.sortedWith(compareBy<AccountTx>({ it.date }, { it.id })).map { t ->
        val before = b
        b = round2(b + if (t.type == AccountTx.IN) t.amount else -t.amount)
        AccountLine(t, round2(before), b)
    }
}

fun accountBalance(txs: List<AccountTx>): Double =
    round2(txs.sumOf { if (it.type == AccountTx.IN) it.amount else -it.amount })
