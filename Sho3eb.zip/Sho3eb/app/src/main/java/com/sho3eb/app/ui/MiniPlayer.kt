package com.sho3eb.app.ui

import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.sho3eb.app.core.Extras
import com.sho3eb.app.core.tr
import kotlin.math.roundToInt

/** مشغل عائم: يستمر تشغيل القناة/الفيديو في نافذة صغيرة عند التنقل داخل التطبيق */
object MiniPlayer {
    var player: ExoPlayer? = null; private set
    var url = ""; private set
    var title = ""; private set
    val active = mutableStateOf(false)
    var enabled: Boolean get() = Extras.b("mini_player", true); set(v) = Extras.pb("mini_player", v)

    /** استلام المشغل الحالي إن كان لنفس الرابط (عند فتح الشاشة الكاملة مجدداً) */
    fun take(u: String): ExoPlayer? {
        val p = player ?: return null
        active.value = false
        if (u == url) { player = null; return p }
        p.release(); player = null; return null
    }
    /** نقل المشغل إلى النافذة العائمة عند مغادرة شاشة التشغيل */
    fun park(p: ExoPlayer, u: String, t: String): Boolean {
        if (!enabled || !(p.playWhenReady && p.playbackState != Player.STATE_ENDED && p.playbackState != Player.STATE_IDLE)) return false
        player?.takeIf { it !== p }?.release()
        player = p; url = u; title = t; active.value = true
        return true
    }
    fun close() { player?.release(); player = null; active.value = false }
}

@Composable
fun MiniPlayerOverlay(nav: NavController) {
    val route = nav.currentBackStackEntryAsState().value?.destination?.route ?: ""
    if (!MiniPlayer.active.value || route.startsWith("player")) return
    val p = MiniPlayer.player ?: return
    val d = LocalDensity.current
    var off by remember { mutableStateOf(IntOffset(0, 0)) }
    var playing by remember { mutableStateOf(p.isPlaying) }
    DisposableEffect(p) {
        val l = object : Player.Listener { override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying } }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
        Column(Modifier.padding(end = 12.dp, bottom = 90.dp).offset { off }.width(230.dp).shadow(10.dp, RoundedCornerShape(14.dp)).clip(RoundedCornerShape(14.dp)).background(Color.Black)
            .pointerInput(Unit) { detectDragGestures { c, drag -> c.consume(); off = IntOffset(off.x + drag.x.roundToInt(), off.y + drag.y.roundToInt()) } }) {
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                AndroidView(factory = { c -> PlayerView(c).apply { useController = false; player = p; layoutParams = ViewGroup.LayoutParams(-1, -1) } },
                    update = { it.player = p }, onRelease = { it.player = null }, modifier = Modifier.fillMaxSize())
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF1B1B1B)).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(MiniPlayer.title.ifBlank { tr("جارٍ التشغيل", "Playing") }, Modifier.weight(1f).padding(start = 6.dp), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
                IconButton(onClick = { if (p.isPlaying) p.pause() else p.play() }, Modifier.size(36.dp)) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White) }
                IconButton(onClick = { nav.openPlayer(MiniPlayer.url, MiniPlayer.title) }, Modifier.size(36.dp)) { Icon(Icons.Filled.OpenInFull, null, tint = Color.White) }
                IconButton(onClick = { MiniPlayer.close() }, Modifier.size(36.dp)) { Icon(Icons.Filled.Close, null, tint = Color.White) }
            }
        }
    }
}
