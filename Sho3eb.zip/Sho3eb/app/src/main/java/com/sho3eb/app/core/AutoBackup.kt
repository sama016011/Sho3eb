package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.work.*
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.AppDatabase
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

/**
 * نسخ احتياطي تلقائي دوري:
 *  - نسخة داخل مجلد التطبيق (تُرفع تلقائياً مع نسخ أندرويد الاحتياطي إلى حساب Google)
 *  - نسخة في مجلد يختاره المستخدم (Google Drive / OneDrive / Dropbox / ذاكرة الهاتف) عبر نظام الملفات
 *  - الاحتفاظ بآخر N نسخ فقط
 */
object AutoBackup {
    private const val WORK = "sho3eb_auto_backup"
    private const val PREFIX = "Sho3eb_auto_"

    /** 0 = متوقف، 1 = يومي، 7 = أسبوعي، 30 = شهري */
    var everyDays: Int get() = Extras.i("ab_days", 0); set(v) = Extras.pi("ab_days", v)
    var keep: Int get() = Extras.i("ab_keep", 7); set(v) = Extras.pi("ab_keep", v)
    var folder: String get() = Extras.s("ab_folder", ""); set(v) = Extras.ps("ab_folder", v)
    var wifiOnly: Boolean get() = Extras.b("ab_wifi", false); set(v) = Extras.pb("ab_wifi", v)
    var lastAt: Long get() = Extras.l("ab_last", 0L); set(v) = Extras.pl("ab_last", v)
    var lastOk: Boolean get() = Extras.b("ab_lastOk", true); set(v) = Extras.pb("ab_lastOk", v)
    var lastMsg: String get() = Extras.s("ab_msg", ""); set(v) = Extras.ps("ab_msg", v)

    fun localDir(ctx: Context) = File(ctx.filesDir, "auto_backups").apply { mkdirs() }

    fun localFiles(ctx: Context): List<File> = localDir(ctx).listFiles()?.filter { it.name.startsWith(PREFIX) }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun folderName(ctx: Context): String {
        val f = folder.ifBlank { return "" }
        return runCatching {
            val id = DocumentsContract.getTreeDocumentId(Uri.parse(f))
            val auth = Uri.parse(f).authority ?: ""
            val where = when {
                auth.contains("google") -> "Google Drive"
                auth.contains("onedrive") || auth.contains("skydrive") -> "OneDrive"
                auth.contains("dropbox") -> "Dropbox"
                auth.contains("externalstorage") -> tr("ذاكرة الهاتف", "Phone storage")
                else -> auth
            }
            where + " • " + id.substringAfterLast(':').substringAfterLast('/').ifBlank { "/" }
        }.getOrDefault(f)
    }

    fun setFolder(ctx: Context, uri: Uri?) {
        if (uri == null) { folder = ""; return }
        runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
        folder = uri.toString()
    }

    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        val d = everyDays
        if (d <= 0) { wm.cancelUniqueWork(WORK); return }
        val c = Constraints.Builder().setRequiresBatteryNotLow(true)
            .setRequiredNetworkType(if (wifiOnly && folder.isNotBlank()) NetworkType.UNMETERED else NetworkType.NOT_REQUIRED).build()
        val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(d.toLong(), TimeUnit.DAYS)
            .setConstraints(c).setInitialDelay(if (lastAt == 0L) 15 else (d * 24 * 60).toLong().coerceAtMost(60), TimeUnit.MINUTES)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.MINUTES).build()
        wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    /** تنفيذ النسخ الآن. يعيد رسالة النتيجة */
    fun run(ctx: Context): Pair<Boolean, String> {
        val name = PREFIX + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm")) + ".db"
        return try {
            Sho3ebApp.instance.db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
            val src = ctx.getDatabasePath(AppDatabase.NAME)
            val local = File(localDir(ctx), name)
            src.copyTo(local, overwrite = true)
            localFiles(ctx).drop(keep.coerceAtLeast(1)).forEach { it.delete() }
            var msg = tr("نسخة محلية ✅", "Local copy ✅")
            var ok = true
            if (folder.isNotBlank()) {
                val r = runCatching { writeToFolder(ctx, Uri.parse(folder), name, local) }
                if (r.isSuccess) msg += tr(" • في المجلد السحابي ✅", " • cloud folder ✅")
                else { ok = false; msg += tr(" • تعذر الكتابة في المجلد المختار ❌", " • couldn't write to the chosen folder ❌") }
            }
            try { android.app.backup.BackupManager(ctx).dataChanged() } catch (_: Exception) {}
            lastAt = System.currentTimeMillis(); lastOk = ok; lastMsg = msg
            ok to msg
        } catch (e: Exception) {
            lastAt = System.currentTimeMillis(); lastOk = false; lastMsg = e.message ?: "error"
            false to (tr("فشل النسخ: ", "Backup failed: ") + (e.message ?: ""))
        }
    }

    private fun writeToFolder(ctx: Context, tree: Uri, name: String, file: File) {
        val cr = ctx.contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(cr, parent, "application/octet-stream", name) ?: error("create failed")
        cr.openOutputStream(doc)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: error("open failed")
        // حذف النسخ القديمة الزائدة في المجلد
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val found = mutableListOf<Pair<String, Long>>()
        cr.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(1) ?: continue
                if (n.startsWith(PREFIX)) found += c.getString(0) to (if (c.isNull(2)) 0L else c.getLong(2))
            }
        }
        found.sortedByDescending { it.second }.drop(keep.coerceAtLeast(1)).forEach { (id, _) ->
            runCatching { DocumentsContract.deleteDocument(cr, DocumentsContract.buildDocumentUriUsingTree(tree, id)) }
        }
    }
}

class AutoBackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val (ok, _) = AutoBackup.run(applicationContext)
        return if (ok || runAttemptCount >= 2) Result.success() else Result.retry()
    }
}
