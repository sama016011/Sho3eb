package com.sho3eb.app.core

import android.content.Context
import android.net.Uri
import android.util.Xml
import com.sho3eb.app.data.AppDao
import com.sho3eb.app.data.Product
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.util.zip.ZipInputStream

/** استيراد الأصناف من Excel (xlsx) أو CSV — مع تعرّف تلقائي على الأعمدة */
object ItemImport {
    /** الحقول القابلة للربط بأعمدة الملف */
    val fields = listOf(
        "name" to tr("اسم الصنف", "Item name"), "price" to tr("سعر البيع", "Sale price"), "cost" to tr("سعر الشراء / التكلفة", "Cost"),
        "unit" to tr("الوحدة", "Unit"), "category" to tr("التصنيف", "Category"), "sku" to tr("الكود / الباركود", "Code / barcode"),
        "qty" to tr("الكمية الحالية", "Quantity"), "min" to tr("حد الطلب", "Min qty"), "notes" to tr("الوصف", "Description")
    )
    private val hints = mapOf(
        "name" to listOf("اسم", "الصنف", "المنتج", "البيان", "الماده", "الخامه", "name", "item", "product", "description"),
        "price" to listOf("سعر البيع", "البيع", "سعر", "price", "sale", "selling"),
        "cost" to listOf("تكلفه", "التكلفه", "الشراء", "سعر الشراء", "cost", "purchase", "buy"),
        "unit" to listOf("الوحده", "وحده", "unit", "uom"),
        "category" to listOf("التصنيف", "تصنيف", "القسم", "المجموعه", "الفئه", "category", "group", "type"),
        "sku" to listOf("كود", "الكود", "باركود", "رقم الصنف", "sku", "code", "barcode", "ref"),
        "qty" to listOf("الكميه", "الرصيد", "المخزون", "كميه", "qty", "quantity", "stock", "balance"),
        "min" to listOf("حد", "الحد الادني", "min", "reorder"),
        "notes" to listOf("ملاحظات", "الوصف", "وصف", "notes", "details")
    )
    private fun norm(s: String) = s.trim().lowercase().replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي')

    /** قراءة الملف إلى صفوف */
    fun read(ctx: Context, uri: Uri): List<List<String>> {
        val name = MediaTools.nameOf(ctx, uri).lowercase()
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        return if (isZip || name.endsWith(".xlsx")) xlsx(bytes) else csv(String(bytes, if (looksUtf16(bytes)) Charsets.UTF_16 else Charsets.UTF_8))
    }
    private fun looksUtf16(b: ByteArray) = b.size > 2 && ((b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) || (b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()))

    fun csv(text: String): List<List<String>> {
        val t = text.removePrefix("﻿")
        val first = t.lineSequence().firstOrNull().orEmpty()
        val sep = listOf(',', ';', '\t', '|').maxBy { c -> first.count { it == c } }
        val rows = mutableListOf<List<String>>()
        var cur = mutableListOf<String>(); val cell = StringBuilder(); var q = false; var i = 0
        while (i < t.length) {
            val ch = t[i]
            when {
                q && ch == '"' && i + 1 < t.length && t[i + 1] == '"' -> { cell.append('"'); i++ }
                ch == '"' -> q = !q
                !q && ch == sep -> { cur += cell.toString(); cell.clear() }
                !q && (ch == '\n' || ch == '\r') -> { if (ch == '\r' && i + 1 < t.length && t[i + 1] == '\n') i++; cur += cell.toString(); cell.clear(); if (cur.any { it.isNotBlank() }) rows += cur; cur = mutableListOf() }
                else -> cell.append(ch)
            }
            i++
        }
        cur += cell.toString(); if (cur.any { it.isNotBlank() }) rows += cur
        return rows
    }

    /** قارئ xlsx بسيط: أول ورقة عمل + النصوص المشتركة */
    fun xlsx(bytes: ByteArray): List<List<String>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(bytes.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) { if (e.name == "xl/sharedStrings.xml" || e.name.startsWith("xl/worksheets/sheet") || e.name == "xl/workbook.xml") files[e.name] = z.readBytes(); e = z.nextEntry }
        }
        val shared = mutableListOf<String>()
        files["xl/sharedStrings.xml"]?.let { b ->
            val p = Xml.newPullParser(); p.setInput(b.inputStream(), "UTF-8")
            var inSi = false; val sb = StringBuilder(); var inT = false
            while (p.eventType != XmlPullParser.END_DOCUMENT) {
                when (p.eventType) {
                    XmlPullParser.START_TAG -> when (p.name) { "si" -> { inSi = true; sb.clear() }; "t" -> inT = true; "rPh" -> inT = false }
                    XmlPullParser.TEXT -> if (inSi && inT) sb.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) { "si" -> { shared += sb.toString(); inSi = false }; "t" -> inT = false }
                }
                p.next()
            }
        }
        val sheet = files.keys.filter { it.startsWith("xl/worksheets/sheet") }.minByOrNull { it.filter { c -> c.isDigit() }.toIntOrNull() ?: 99 } ?: return emptyList()
        val rows = sortedMapOf<Int, MutableMap<Int, String>>()
        val p = Xml.newPullParser(); p.setInput(files[sheet]!!.inputStream(), "UTF-8")
        var ref = ""; var type = ""; var inV = false; var inIs = false; val v = StringBuilder()
        fun colOf(r: String): Int { var n = 0; for (ch in r) { if (ch.isLetter()) n = n * 26 + (ch.uppercaseChar() - 'A' + 1) else break }; return n - 1 }
        fun rowOf(r: String) = r.dropWhile { it.isLetter() }.toIntOrNull() ?: 0
        while (p.eventType != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "c" -> { ref = p.getAttributeValue(null, "r") ?: ""; type = p.getAttributeValue(null, "t") ?: ""; v.clear() }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "t" -> if (inIs) inV = true
                }
                XmlPullParser.TEXT -> if (inV) v.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v", "t" -> inV = false
                    "is" -> inIs = false
                    "c" -> {
                        val raw = v.toString()
                        val value = when (type) { "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1) ?: ""; else -> raw }
                        if (ref.isNotBlank() && value.isNotBlank()) rows.getOrPut(rowOf(ref)) { sortedMapOf() }[colOf(ref)] = value
                    }
                }
            }
            p.next()
        }
        return rows.values.map { m -> val max = m.keys.maxOrNull() ?: -1; (0..max).map { m[it] ?: "" } }
    }

    /** ربط تلقائي: حقل ← رقم العمود */
    fun autoMap(header: List<String>): MutableMap<String, Int> {
        val map = mutableMapOf<String, Int>()
        val h = header.map { norm(it) }
        // الأولوية للمطابقات الأطول (مثل «سعر الشراء» قبل «سعر»)
        for (f in listOf("cost", "price", "sku", "category", "unit", "qty", "min", "notes", "name")) {
            val ws = hints[f]!!.map { norm(it) }.sortedByDescending { it.length }
            val idx = h.indices.firstOrNull { i -> i !in map.values && ws.any { w -> h[i] == w || h[i].contains(w) } }
            if (idx != null) map[f] = idx
        }
        return map
    }

    data class Result(val added: Int, val updated: Int, val skipped: Int)

    /**
     * kind: SALE (منتج للبيع/تام الصنع) أو RAW (خامة تصنيع)
     * source: FILE / SUPPLIER / CUSTOMER — في قائمة المورد يُعتبر السعر تكلفة شراء
     */
    suspend fun import(dao: AppDao, rows: List<List<String>>, map: Map<String, Int>, hasHeader: Boolean, kind: String, source: String, party: String, updateExisting: Boolean, defaultCategory: String): Result {
        val existing = dao.allProducts()
        val byName = existing.associateBy { norm(it.name) }
        val bySku = existing.filter { it.sku.isNotBlank() }.associateBy { norm(it.sku) }
        var add = 0; var upd = 0; var skip = 0
        fun get(r: List<String>, f: String) = map[f]?.let { r.getOrNull(it) }?.trim().orEmpty()
        fun num(s: String) = Xlsx.num(s.replace("٫", ".").map { ch -> if (ch in '٠'..'٩') '0' + (ch - '٠') else ch }.joinToString("").replace(Regex("[^0-9.,-]"), "").replace(",", ""))
        val data = if (hasHeader) rows.drop(1) else rows
        for (r in data) {
            val name = get(r, "name"); if (name.isBlank()) { skip++; continue }
            var price = num(get(r, "price")); var cost = num(get(r, "cost"))
            if (source == "SUPPLIER" && cost == null && price != null) { cost = price; price = null }
            val note = when (source) { "SUPPLIER" -> tr("مورد: ", "Supplier: ") + party; "CUSTOMER" -> tr("عميل: ", "Customer: ") + party; else -> "" }.takeIf { party.isNotBlank() }.orEmpty()
            val cat = if (kind == "RAW") Manufacture.RAW_CAT else get(r, "category").ifBlank { defaultCategory }
            val ex = get(r, "sku").takeIf { it.isNotBlank() }?.let { bySku[norm(it)] } ?: byName[norm(name)]
            if (ex != null) {
                if (!updateExisting) { skip++; continue }
                dao.updateProduct(ex.copy(price = price ?: ex.price, cost = cost ?: ex.cost, unit = get(r, "unit").ifBlank { ex.unit },
                    category = if (kind == "RAW") Manufacture.RAW_CAT else get(r, "category").ifBlank { ex.category }, sku = get(r, "sku").ifBlank { ex.sku },
                    minQty = num(get(r, "min")) ?: ex.minQty, notes = get(r, "notes").ifBlank { ex.notes }))
                upd++
            } else {
                dao.insertProduct(Product(name = name, sku = get(r, "sku"), category = cat, unit = get(r, "unit"), cost = cost ?: 0.0, price = if (kind == "RAW") 0.0 else (price ?: 0.0),
                    openingQty = num(get(r, "qty")) ?: 0.0, minQty = num(get(r, "min")) ?: 0.0, notes = listOf(get(r, "notes"), note).filter { it.isNotBlank() }.joinToString(" • ")))
                add++
            }
        }
        return Result(add, upd, skip)
    }

    /** نموذج Excel جاهز للتعبئة */
    fun template(ctx: Context): File {
        val f = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "items_template.xlsx")
        val head = fields.map { Xlsx.Cell(it.second, 1) }
        val sample = listOf(
            listOf(tr("قميص قطن", "Cotton shirt"), 250.0, 180.0, tr("قطعة", "pc"), tr("ملابس", "Clothes"), "SH-01", 20.0, 5.0, ""),
            listOf(tr("بنطلون جينز", "Jeans"), 400.0, 290.0, tr("قطعة", "pc"), tr("ملابس", "Clothes"), "JN-02", 12.0, 3.0, "")).map { r -> r.map { Xlsx.Cell(it) } }
        Xlsx.write(f, listOf(Xlsx.Sheet(tr("الأصناف", "Items"), listOf(head) + sample)))
        return f
    }
}
