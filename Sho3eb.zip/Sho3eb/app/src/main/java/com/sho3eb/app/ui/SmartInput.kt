@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// =====================================================================
//                         الإدخال بالصوت
// =====================================================================
/** يعيد دالة تفتح التعرّف على الكلام وتعيد النص */
@Composable
fun rememberSpeech(prompt: String = tr("تكلّم الآن…", "Speak now…"), onText: (String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) onText(t)
        }
    }
    return {
        val lang = AppState.lang.value.let { l -> if (l == "en") "en-US" else if (l == "ar") Extras.s("voiceLang", "ar-EG") else l }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, prompt)
        try { launcher.launch(i) } catch (e: Exception) {
            toast(ctx, tr("التعرف على الصوت غير متاح. ثبّت تطبيق Google أو فعّل الكتابة الصوتية.", "Speech recognition unavailable. Install the Google app."))
        }
    }
}

@Composable
fun MicButton(onText: (String) -> Unit) {
    val speak = rememberSpeech(onText = onText)
    IconButton(onClick = speak) { Icon(Icons.Filled.Mic, contentDescription = tr("إدخال بالصوت", "Voice input"), tint = MaterialTheme.colorScheme.primary) }
}

// =====================================================================
//                     تصوير الفاتورة وقراءتها
// =====================================================================
class ScanState(val camera: () -> Unit, val gallery: () -> Unit, val busy: State<Boolean>)

@Composable
fun rememberReceiptScanner(onResult: (ReceiptScan.Result, File) -> Unit): ScanState {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var camFile by remember { mutableStateOf<File?>(null) }
    val busy = remember { mutableStateOf(false) }
    fun process(uri: Uri, file: File) {
        busy.value = true
        scope.launch {
            val text = withContext(Dispatchers.IO) { ReceiptScan.recognize(ctx, uri) }
            busy.value = false
            if (text.isBlank()) toast(ctx, tr("لم أستطع قراءة الفاتورة، جرّب صورة أوضح", "Couldn't read the receipt, try a clearer photo"))
            onResult(ReceiptScan.parse(text), file)
        }
    }
    var camPending by remember { mutableStateOf<android.net.Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = camFile
        if (ok && f != null) process(Uri.fromFile(f), f) else f?.delete()
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> val u = camPending; if (ok && u != null) camera.launch(u) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val f = withContext(Dispatchers.IO) {
                val out = Attachments.newCameraFile(ctx)
                runCatching { ctx.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { i.copyTo(it) } } }
                out
            }
            process(Uri.fromFile(f), f)
        }
    }
    return remember {
        ScanState(
            camera = {
                try { val f = Attachments.newCameraFile(ctx); camFile = f; Share.uriFor(ctx, f).let { u -> if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) camera.launch(u) else { camPending = u; camPerm.launch(android.Manifest.permission.CAMERA) } } }
                catch (e: Exception) { toast(ctx, tr("الكاميرا غير متاحة", "Camera unavailable")) }
            },
            gallery = { gallery.launch("image/*") },
            busy = busy
        )
    }
}

/** زر تصوير الفاتورة مع قائمة (كاميرا / معرض) */
@Composable
fun ScanButton(onResult: (ReceiptScan.Result, File) -> Unit) {
    val s = rememberReceiptScanner(onResult)
    var menu by remember { mutableStateOf(false) }
    Box {
        if (s.busy.value) CircularProgressIndicator(Modifier.size(28.dp).padding(2.dp), strokeWidth = 2.dp)
        else IconButton(onClick = { menu = true }) { Icon(Icons.Filled.DocumentScanner, contentDescription = tr("تصوير فاتورة", "Scan receipt"), tint = MaterialTheme.colorScheme.primary) }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text(tr("📷 تصوير الفاتورة", "📷 Take a photo")) }, onClick = { menu = false; s.camera() })
            DropdownMenuItem(text = { Text(tr("🖼️ من المعرض", "🖼️ From gallery")) }, onClick = { menu = false; s.gallery() })
        }
    }
}

/** صف أدوات الإدخال الذكي: صوت + تصوير */
@Composable
fun SmartInputRow(onVoice: (VoiceParse.Result) -> Unit, onScan: ((ReceiptScan.Result, File) -> Unit)?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(tr("إدخال سريع:", "Quick input:"), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
        MicButton { onVoice(VoiceParse.parse(it)) }
        if (onScan != null) ScanButton(onScan)
    }
}

// =====================================================================
//               إدخال سريع (من الشاشة الرئيسية) للمعيشة
// =====================================================================
@Composable
fun QuickEntryDialog(startVoice: Boolean, startScan: Boolean, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf(Living.EXPENSE) }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("OTHER") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var note by remember { mutableStateOf("") }
    var heard by remember { mutableStateOf("") }
    var scanned by remember { mutableStateOf<ReceiptScan.Result?>(null) }
    var photo by remember { mutableStateOf<File?>(null) }
    val acc = remember { mutableStateOf<Long?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun applyVoice(r: VoiceParse.Result) {
        heard = r.text; kind = r.kind; cat = r.category; date = r.date
        if (r.title.isNotBlank()) title = r.title
        r.amount?.let { amount = Fmt.plain(it) }
    }
    val speak = rememberSpeech { applyVoice(VoiceParse.parse(it)) }
    val scanner = rememberReceiptScanner { r, f ->
        scanned = r; photo = f; kind = Living.EXPENSE
        r.total?.let { amount = Fmt.plain(it) }
        r.date?.let { date = it }
        if (title.isBlank()) title = r.store.ifBlank { tr("فاتورة مشتريات", "Purchase receipt") }
        cat = VoiceParse.category(r.store + " " + r.lines.joinToString(" ") { it.name }, Living.EXPENSE).let { if (it == "OTHER") "FOOD" else it }
        note = r.lines.take(12).joinToString("، ") { it.name + (if (it.qty > 1) " ×" + Fmt.num(it.qty) else "") }
    }
    LaunchedEffect(Unit) { if (startVoice) speak(); if (startScan) scanner.camera() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("⚡ إدخال سريع", "⚡ Quick entry")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = speak, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Mic, null); Spacer(Modifier.width(4.dp)); Text(tr("بالصوت", "Voice")) }
                    FilledTonalButton(onClick = scanner.camera, modifier = Modifier.weight(1f), enabled = !scanner.busy.value) {
                        if (scanner.busy.value) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.DocumentScanner, null)
                        Spacer(Modifier.width(4.dp)); Text(tr("فاتورة", "Receipt"))
                    }
                }
                TextButton(onClick = scanner.gallery) { Text(tr("🖼️ اختيار صورة فاتورة من المعرض", "🖼️ Pick a receipt photo")) }
                if (heard.isNotBlank()) Text("🎙️ «$heard»", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                scanned?.let { s ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(tr("📄 تمت قراءة الفاتورة", "📄 Receipt read"), fontWeight = FontWeight.Bold)
                            if (s.store.isNotBlank()) Text(s.store, style = MaterialTheme.typography.bodySmall)
                            Text(tr("الإجمالي: ", "Total: ") + (s.total?.let { Fmt.money(it) } ?: tr("غير واضح", "unclear")) + (s.vat?.let { tr(" • الضريبة ", " • VAT ") + Fmt.num(it) } ?: ""), style = MaterialTheme.typography.bodySmall)
                            if (s.lines.isNotEmpty()) Text(tr("بنود: ", "Items: ") + s.lines.size, style = MaterialTheme.typography.bodySmall)
                            Text(tr("راجع المبلغ قبل الحفظ", "Check the amount before saving"), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Text(tr("مثال: «صرفت ميتين وخمسين على بنزين» أو «قبضت الراتب ٨٠٠٠»", "e.g. \"spent 250 on fuel\" or \"received salary 8000\""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                HChips {
                    FilterChip(kind == Living.EXPENSE, { kind = Living.EXPENSE; cat = "OTHER" }, label = { Text(tr("مصروف", "Expense")) })
                    FilterChip(kind == Living.INCOME, { kind = Living.INCOME; cat = "OTHER" }, label = { Text(tr("دخل", "Income")) })
                }
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                OutlinedTextField(title, { title = it }, label = { Text(tr("البيان", "Description")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                HChips { Living.cats(kind).forEach { c -> FilterChip(cat == c.key, { cat = c.key }, label = { Text(c.emoji + " " + c.label) }) } }
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                if (note.isNotBlank()) OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
                AccountPickRow(acc, if (kind == Living.INCOME) tr("إيداع في حساب (اختياري)", "Deposit to account (optional)") else tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val v = Fmt.parse(amount)
                if (v == null || v <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                busy = true
                scope.launch {
                    val id = QuickAdd.living(ctx, kind, title.trim(), cat, v, date, note.trim(), acc.value)
                    photo?.let { f -> runCatching { Attachments.registerFile(Attachments.LIV_ENTRY, id, f) } }
                    toast(ctx, tr("تمت الإضافة لمصاريف المعيشة ✅", "Added to living expenses ✅"))
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = { photo?.delete(); onDismiss() }) { Text(tr("إلغاء", "Cancel")) } }
    )
}
