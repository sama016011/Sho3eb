package com.sho3eb.app.core

import com.sho3eb.app.data.AccountTx
import com.sho3eb.app.data.AppDao
import com.sho3eb.app.data.Invoice
import com.sho3eb.app.data.InvoiceItem
import com.sho3eb.app.data.InvoicePayment

/** حفظ فاتورة من نقطة البيع أو من نسخة الكمبيوتر (بيع، شراء، مرتجعات، عرض سعر) */
object Pos {
    data class Line(val productId: Long?, val name: String, val qty: Double, val price: Double)

    suspend fun save(dao: AppDao, type: String, lines: List<Line>, partyId: Long?, partyName: String, partyPhone: String,
                     discount: Double, taxPct: Double, paid: Double, method: String, notes: String, date: Long = Fmt.today()): Long {
        val prods = dao.allProducts().associateBy { it.id }
        val party = partyId?.let { id -> dao.allPartys().firstOrNull { it.id == id } }
        val items = lines.filter { it.qty != 0.0 && it.name.isNotBlank() }.map { l ->
            InvoiceItem(invoiceId = 0, productId = l.productId, name = l.name, qty = l.qty, price = l.price, cost = l.productId?.let { prods[it]?.cost } ?: 0.0)
        }
        require(items.isNotEmpty()) { "empty" }
        val number = Shop.nextNumber(dao, type)
        val inv = Invoice(type = type, number = number, partyName = party?.name ?: partyName.trim(), partyPhone = party?.phone ?: partyPhone.trim(), personId = party?.personId,
            date = date, discount = discount, taxPct = taxPct, notes = notes, partyId = party?.id)
        val id = dao.saveInvoice(inv, items)
        if (paid > 0 && Shop.isMoney(type)) {
            val tot = Shop.totals(inv.copy(id = id), items).total
            val amt = minOf(paid, tot)
            val pid = dao.insertInvoicePayment(InvoicePayment(invoiceId = id, amount = amt, date = date, method = method))
            Posting.post(Extras.shopAccount.takeIf { it > 0 }, AccountTx.SRC_INV, pid, Shop.isIncoming(type), amt, date,
                Shop.type(type).label + " " + Shop.prefix(type) + "-" + number + (if (inv.partyName.isNotBlank()) " • " + inv.partyName else ""))
        }
        return id
    }
}
