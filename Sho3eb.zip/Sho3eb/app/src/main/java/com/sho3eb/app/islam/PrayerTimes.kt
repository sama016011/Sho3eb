package com.sho3eb.app.islam

import com.sho3eb.app.core.tr
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.chrono.HijrahChronology
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.*

/** طرق الحساب المعتمدة */
enum class CalcMethod(val ar: String, val en: String, val fajr: Double, val isha: Double, val ishaMinutes: Int = 0) {
    UMM_AL_QURA("أم القرى (السعودية)", "Umm al-Qura (Makkah)", 18.5, 0.0, 90),
    EGYPT("الهيئة المصرية العامة للمساحة", "Egyptian General Authority", 19.5, 17.5),
    MWL("رابطة العالم الإسلامي", "Muslim World League", 18.0, 17.0),
    KARACHI("جامعة العلوم الإسلامية بكراتشي", "Univ. of Islamic Sciences, Karachi", 18.0, 18.0),
    ISNA("أمريكا الشمالية (ISNA)", "North America (ISNA)", 15.0, 15.0),
    GULF("منطقة الخليج", "Gulf region", 19.5, 0.0, 90),
    KUWAIT("الكويت", "Kuwait", 18.0, 17.5),
    QATAR("قطر", "Qatar", 18.0, 0.0, 90),
    DUBAI("دبي", "Dubai", 18.2, 18.2);

    val label: String get() = tr(ar, en)
}

data class City(val ar: String, val en: String, val lat: Double, val lng: Double, val zone: String, val method: CalcMethod)

object Prayer {
    const val FAJR = 0
    const val SUNRISE = 1
    const val DHUHR = 2
    const val ASR = 3
    const val MAGHRIB = 4
    const val ISHA = 5
    val names get() = listOf(tr("الفجر", "Fajr"), tr("الشروق", "Sunrise"), tr("الظهر", "Dhuhr"), tr("العصر", "Asr"), tr("المغرب", "Maghrib"), tr("العشاء", "Isha"))

    val cities = listOf(
        City("الرياض", "Riyadh", 24.7136, 46.6753, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("مكة المكرمة", "Makkah", 21.4225, 39.8262, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("المدينة المنورة", "Madinah", 24.4672, 39.6111, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("جدة", "Jeddah", 21.4858, 39.1925, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("الدمام", "Dammam", 26.4207, 50.0888, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("الطائف", "Taif", 21.2703, 40.4158, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("أبها", "Abha", 18.2164, 42.5053, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("تبوك", "Tabuk", 28.3835, 36.5662, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("بريدة", "Buraydah", 26.3260, 43.9750, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("حائل", "Hail", 27.5114, 41.7208, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("جازان", "Jazan", 16.8892, 42.5511, "Asia/Riyadh", CalcMethod.UMM_AL_QURA),
        City("القاهرة", "Cairo", 30.0444, 31.2357, "Africa/Cairo", CalcMethod.EGYPT),
        City("الإسكندرية", "Alexandria", 31.2001, 29.9187, "Africa/Cairo", CalcMethod.EGYPT),
        City("أسيوط", "Asyut", 27.1783, 31.1859, "Africa/Cairo", CalcMethod.EGYPT),
        City("الأقصر", "Luxor", 25.6872, 32.6396, "Africa/Cairo", CalcMethod.EGYPT),
        City("المنصورة", "Mansoura", 31.0409, 31.3785, "Africa/Cairo", CalcMethod.EGYPT),
        City("دبي", "Dubai", 25.2048, 55.2708, "Asia/Dubai", CalcMethod.DUBAI),
        City("أبوظبي", "Abu Dhabi", 24.4539, 54.3773, "Asia/Dubai", CalcMethod.DUBAI),
        City("الكويت", "Kuwait City", 29.3759, 47.9774, "Asia/Kuwait", CalcMethod.KUWAIT),
        City("الدوحة", "Doha", 25.2854, 51.5310, "Asia/Qatar", CalcMethod.QATAR),
        City("المنامة", "Manama", 26.2285, 50.5860, "Asia/Bahrain", CalcMethod.GULF),
        City("مسقط", "Muscat", 23.5880, 58.3829, "Asia/Muscat", CalcMethod.GULF),
        City("عمّان", "Amman", 31.9454, 35.9284, "Asia/Amman", CalcMethod.MWL),
        City("القدس", "Jerusalem", 31.7683, 35.2137, "Asia/Jerusalem", CalcMethod.MWL),
        City("بيروت", "Beirut", 33.8938, 35.5018, "Asia/Beirut", CalcMethod.MWL),
        City("دمشق", "Damascus", 33.5138, 36.2765, "Asia/Damascus", CalcMethod.MWL),
        City("بغداد", "Baghdad", 33.3152, 44.3661, "Asia/Baghdad", CalcMethod.MWL),
        City("صنعاء", "Sanaa", 15.3694, 44.1910, "Asia/Aden", CalcMethod.MWL),
        City("الخرطوم", "Khartoum", 15.5007, 32.5599, "Africa/Khartoum", CalcMethod.EGYPT),
        City("طرابلس", "Tripoli", 32.8872, 13.1913, "Africa/Tripoli", CalcMethod.EGYPT),
        City("تونس", "Tunis", 36.8065, 10.1815, "Africa/Tunis", CalcMethod.MWL),
        City("الجزائر", "Algiers", 36.7538, 3.0588, "Africa/Algiers", CalcMethod.MWL),
        City("الرباط", "Rabat", 34.0209, -6.8416, "Africa/Casablanca", CalcMethod.MWL),
        City("الدار البيضاء", "Casablanca", 33.5731, -7.5898, "Africa/Casablanca", CalcMethod.MWL),
        City("إسطنبول", "Istanbul", 41.0082, 28.9784, "Europe/Istanbul", CalcMethod.MWL),
        City("كراتشي", "Karachi", 24.8607, 67.0011, "Asia/Karachi", CalcMethod.KARACHI),
        City("جاكرتا", "Jakarta", -6.2088, 106.8456, "Asia/Jakarta", CalcMethod.MWL),
        City("كوالالمبور", "Kuala Lumpur", 3.1390, 101.6869, "Asia/Kuala_Lumpur", CalcMethod.MWL),
        City("لندن", "London", 51.5074, -0.1278, "Europe/London", CalcMethod.MWL),
        City("نيويورك", "New York", 40.7128, -74.0060, "America/New_York", CalcMethod.ISNA)
    )

    // ---------- رياضيات فلكية (مبنية على خوارزمية PrayTimes) ----------
    private fun dsin(d: Double) = sin(Math.toRadians(d))
    private fun dcos(d: Double) = cos(Math.toRadians(d))
    private fun dtan(d: Double) = tan(Math.toRadians(d))
    private fun darcsin(x: Double) = Math.toDegrees(asin(x))
    private fun darccos(x: Double) = Math.toDegrees(acos(x.coerceIn(-1.0, 1.0)))
    private fun darctan2(y: Double, x: Double) = Math.toDegrees(atan2(y, x))
    private fun darccot(x: Double) = Math.toDegrees(atan(1 / x))
    private fun fix(a: Double, b: Double): Double { val r = a - b * floor(a / b); return if (r < 0) r + b else r }

    /** الميل الشمسي ومعادلة الزمن */
    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fix(357.529 + 0.98560028 * d, 360.0)
        val q = fix(280.459 + 0.98564736 * d, 360.0)
        val l = fix(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g), 360.0)
        val e = 23.439 - 0.00000036 * d
        val ra = fix(darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0, 24.0)
        val eqt = q / 15.0 - ra
        val decl = darcsin(dsin(e) * dsin(l))
        return decl to eqt
    }

    /** أوقات اليوم بالتوقيت المحلي (ساعات عشرية) */
    fun computeHours(date: LocalDate, lat: Double, lng: Double, tz: Double, m: CalcMethod, hanafi: Boolean): DoubleArray {
        val jd = date.toEpochDay() + 2440587.5 - lng / (15.0 * 24.0)
        fun midDay(t: Double): Double { val eqt = sunPosition(jd + t / 24.0).second; return fix(12 - eqt, 24.0) }
        fun sunAngleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPosition(jd + t / 24.0).first
            val noon = midDay(t)
            val tt = 1.0 / 15.0 * darccos((-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat)))
            return noon + if (ccw) -tt else tt
        }
        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPosition(jd + t / 24.0).first
            val angle = -darccot(factor + dtan(abs(lat - decl)))
            return sunAngleTime(angle, t, false)
        }
        // تقريب ابتدائي ثم دورتان للتحسين
        var t = doubleArrayOf(5.0, 6.0, 12.0, 13.0, 18.0, 18.0)
        repeat(2) {
            val dt = t.map { it / 24.0 }.toDoubleArray()
            t = doubleArrayOf(
                sunAngleTime(m.fajr, dt[0] * 24, true),
                sunAngleTime(0.833, dt[1] * 24, true),
                midDay(dt[2] * 24),
                asrTime(if (hanafi) 2.0 else 1.0, dt[3] * 24),
                sunAngleTime(0.833, dt[4] * 24, false),
                if (m.ishaMinutes > 0) 0.0 else sunAngleTime(m.isha, dt[5] * 24, false)
            )
            if (m.ishaMinutes > 0) t[5] = t[4] + m.ishaMinutes / 60.0
        }
        val adj = tz - lng / 15.0
        return DoubleArray(6) { k -> t[k] + adj + if (k == DHUHR) 1.0 / 60.0 else 0.0 }
    }

    fun zone(): ZoneId = try {
        if (IslamPrefs.zoneId.isNotBlank()) ZoneId.of(IslamPrefs.zoneId) else ZoneId.systemDefault()
    } catch (e: Exception) {
        ZoneId.systemDefault()
    }

    /** أوقات يوم كتواريخ كاملة حسب إعدادات المستخدم */
    fun timesFor(date: LocalDate): List<ZonedDateTime> {
        val z = zone()
        val m = try { CalcMethod.valueOf(IslamPrefs.method) } catch (e: Exception) { CalcMethod.UMM_AL_QURA }
        val tz = z.rules.getOffset(date.atTime(12, 0).atZone(z).toInstant()).totalSeconds / 3600.0
        // أم القرى: العشاء 120 دقيقة في رمضان
        val ramadan = try { HijrahDate.from(date).get(java.time.temporal.ChronoField.MONTH_OF_YEAR) == 9 } catch (e: Exception) { false }
        val method = if (m == CalcMethod.UMM_AL_QURA && ramadan) m else m
        val h = computeHours(date, IslamPrefs.lat, IslamPrefs.lng, tz, method, IslamPrefs.asrHanafi)
        if (m == CalcMethod.UMM_AL_QURA && ramadan) h[ISHA] = h[MAGHRIB] + 2.0
        return h.mapIndexed { k, v ->
            val totalMin = (v * 60).roundToLong() + IslamPrefs.offsetFor(k)
            date.atStartOfDay(z).plusMinutes(totalMin)
        }
    }

    /** الصلاة القادمة: (رقمها، وقتها) */
    fun next(now: ZonedDateTime = ZonedDateTime.now(zone()), includeSunrise: Boolean = false): Pair<Int, ZonedDateTime> {
        for (d in 0..1) {
            val times = timesFor(now.toLocalDate().plusDays(d.toLong()))
            times.forEachIndexed { k, t -> if ((includeSunrise || k != SUNRISE) && t.isAfter(now)) return k to t }
        }
        return FAJR to timesFor(now.toLocalDate().plusDays(1))[FAJR]
    }

    fun hijri(date: LocalDate = LocalDate.now()): String = try {
        val h = HijrahChronology.INSTANCE.date(date)
        val f = DateTimeFormatter.ofPattern("d MMMM yyyy", if (com.sho3eb.app.core.AppState.isAr) Locale("ar") else Locale.ENGLISH)
            .withChronology(HijrahChronology.INSTANCE)
        f.format(h) + tr(" هـ", " AH")
    } catch (e: Exception) {
        ""
    }

    fun fmt(t: ZonedDateTime): String = t.format(DateTimeFormatter.ofPattern("hh:mm a", if (com.sho3eb.app.core.AppState.isAr) Locale("ar") else Locale.ENGLISH))

    /** اتجاه القبلة بالدرجات من الشمال الحقيقي */
    fun qibla(lat: Double, lng: Double): Double {
        val kLat = Math.toRadians(21.422487)
        val kLng = Math.toRadians(39.826206)
        val p = Math.toRadians(lat)
        val dl = kLng - Math.toRadians(lng)
        val b = Math.toDegrees(atan2(sin(dl), cos(p) * tan(kLat) - sin(p) * cos(dl)))
        return (b + 360) % 360
    }

    /** المسافة إلى مكة بالكيلومتر */
    fun distanceToMakkah(lat: Double, lng: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(21.422487 - lat)
        val dLng = Math.toRadians(39.826206 - lng)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat)) * cos(Math.toRadians(21.422487)) * sin(dLng / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    fun epochMs(t: ZonedDateTime): Long = t.toInstant().toEpochMilli()
    @Suppress("unused") fun fromMs(ms: Long): LocalDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), zone())
}
