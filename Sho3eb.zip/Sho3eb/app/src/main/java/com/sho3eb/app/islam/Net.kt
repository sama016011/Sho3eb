package com.sho3eb.app.islam

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** اتصال بسيط بالإنترنت (بدون مكتبات خارجية) */
object Net {
    private fun open(url: String, timeout: Int): HttpURLConnection {
        var current = url
        repeat(5) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Sho3eb/1.0 (Android)")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw IOException("Redirect without location")
                current = URL(URL(current), loc).toString()
            } else {
                if (code !in 200..299) {
                    c.disconnect(); throw IOException("HTTP $code")
                }
                return c
            }
        }
        throw IOException("Too many redirects")
    }

    fun get(url: String, timeout: Int = 20000): String {
        val c = open(url, timeout)
        try {
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** تنزيل ملف مع تقدم اختياري. يكتب إلى ملف مؤقت ثم يعيد التسمية */
    fun download(url: String, dest: File, timeout: Int = 30000, onProgress: ((Long, Long) -> Unit)? = null) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        val c = open(url, timeout)
        try {
            val total = c.contentLengthLong
            c.inputStream.use { inp ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    var done = 0L
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress?.invoke(done, total)
                    }
                }
            }
            if (tmp.length() == 0L) throw IOException("Empty file")
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true); tmp.delete()
            }
        } catch (e: Exception) {
            tmp.delete(); throw e
        } finally {
            c.disconnect()
        }
    }
}
