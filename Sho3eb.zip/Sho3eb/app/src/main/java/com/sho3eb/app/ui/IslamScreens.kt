@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.Html
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import com.sho3eb.app.islam.*
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.Locale

private data class Feature(val route: String, val title: String, val sub: String, val icon: ImageVector, val color: Color)

private fun copyText(ctx: Context, t: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", t))
    toast(ctx, tr("تم النسخ", "Copied"))
}

fun shareText(ctx: Context, t: String) {
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null))
}

// ============================ الصفحة الرئيسية للإسلاميات ============================
@Composable
fun IslamHomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(ZonedDateTime.now(Prayer.zone())) }
    LaunchedEffect(Unit) { QuranRepo.ensureLoaded(ctx); while (true) { now = ZonedDateTime.now(Prayer.zone()); delay(1000) } }
    val next = remember(now.minute) { Prayer.next(now) }
    val hadith = remember { Content.randomHadith(ctx) }
    val c = MaterialTheme.colorScheme
    val features = listOf(
        Feature("quran", tr("المصحف الشريف", "Holy Quran"), tr("قراءة • تفسير • تلاوات", "Read • Tafsir • Audio"), Icons.Filled.MenuBook, Color(0xFF0F766E)),
        Feature("prayer", tr("مواقيت الصلاة", "Prayer times"), tr("الأذان والتنبيهات", "Azan & alerts"), Icons.Filled.AccessTime, Color(0xFF4F46E5)),
        Feature("azkar", tr("الأذكار", "Azkar"), tr("الصباح • المساء • اليوم", "Morning • Evening • Daily"), Icons.Filled.WbSunny, Color(0xFFD97706)),
        Feature("ruqyah", tr("الرقية الشرعية", "Ruqyah"), tr("للنفس • للأطفال • للغير", "Self • Children • Others"), Icons.Filled.HealthAndSafety, Color(0xFF059669)),
        Feature("hadith", tr("السنة النبوية", "Sunnah"), tr("أحاديث مصنفة", "Hadith by topic"), Icons.Filled.FormatQuote, Color(0xFF9333EA)),
        Feature("asma", tr("أسماء الله الحسنى", "Names of Allah"), tr("المعاني والاستماع", "Meanings & audio"), Icons.Filled.AutoAwesome, Color(0xFF0F766E)),
        Feature("tasbeeh", tr("السبحة الإلكترونية", "Tasbeeh"), tr("عدّاد وأهداف وإحصائيات", "Counter & stats"), Icons.Filled.TouchApp, Color(0xFF7C3AED)),
        Feature("khatma", tr("الختمة والورد", "Khatma"), tr("ورد يومي وتذكير", "Daily portion & reminder"), Icons.Filled.Bookmarks, Color(0xFF155E75)),
        Feature("prayer_track", tr("متابعة الصلوات", "Prayer tracker"), tr("الفرائض والسنن", "Fard & sunnah"), Icons.Filled.CheckCircle, Color(0xFF16A34A)),
        Feature("ramadan", tr("أوقات رمضان", "Ramadan"), tr("الإمساكية والعد التنازلي", "Timetable & countdown"), Icons.Filled.NightsStay, Color(0xFF4338CA)),
        Feature("occasions", tr("المناسبات الإسلامية", "Islamic occasions"), tr("التقويم الهجري والتذكير", "Hijri calendar & reminders"), Icons.Filled.Event, Color(0xFFB91C1C)),
        Feature("zakat", tr("حاسبة الزكاة", "Zakat"), tr("النصاب والحول", "Nisab & hawl"), Icons.Filled.Calculate, Color(0xFFCA8A04)),
        Feature("faraid", tr("المواريث", "Inheritance"), tr("تقسيم التركة", "Estate shares"), Icons.Filled.FamilyRestroom, Color(0xFF7C3AED)),
        Feature("clist/rulings", tr("أحكام الإسلام", "Islamic rulings"), tr("العبادات وآداب اليوم", "Worship & daily etiquette"), Icons.Filled.Gavel, Color(0xFF0369A1)),
        Feature("clist/sira", tr("السيرة النبوية", "Prophet's biography"), tr("من المولد إلى الوفاة", "From birth to passing"), Icons.Filled.Star, Color(0xFF047857)),
        Feature("clist/hajj", tr("الحج والعمرة", "Hajj & Umrah"), tr("خطوة بخطوة", "Step by step"), Icons.Filled.Place, Color(0xFF78350F)),
        Feature("clist/companions", tr("قصص الصحابة", "Companions"), tr("سير مفصلة", "Detailed stories"), Icons.Filled.Groups, Color(0xFF1D4ED8)),
        Feature("clist/miracles", tr("معجزات الأنبياء", "Prophets' miracles"), tr("من القرآن والسنة", "From Quran & Sunnah"), Icons.Filled.AutoAwesome, Color(0xFFA21CAF)),
        Feature("clist/medicine", tr("الطب النبوي", "Prophetic medicine"), tr("الوقاية والتداوي", "Prevention & remedies"), Icons.Filled.LocalHospital, Color(0xFF0E7490)),
        Feature("clist/prophets", tr("قصص الأنبياء", "Prophets' stories"), tr("قراءة واستماع", "Read & listen"), Icons.Filled.AutoStories, Color(0xFFB45309)),
        Feature("clist/battles", tr("غزوات الإسلام", "Battles of Islam"), tr("الأحداث والدروس", "Events & lessons"), Icons.Filled.Shield, Color(0xFFBE123C)),
        Feature("clist/signs", tr("علامات الساعة", "Signs of the Hour"), tr("الصغرى والكبرى بالترتيب", "Minor & major, in order"), Icons.Filled.HourglassBottom, Color(0xFF7F1D1D)),
        Feature("qibla", tr("اتجاه القبلة", "Qibla"), tr("بوصلة القبلة", "Qibla compass"), Icons.Filled.Explore, Color(0xFF15803D)),
        Feature("hadith_check", tr("تحقق من حديث", "Check a hadith"), tr("درجة الحديث وحكمه", "Grade & ruling"), Icons.Filled.FactCheck, Color(0xFF7C3AED))
    )
    ScreenScaffold(
        title = tr("إسلاميات", "Islamic"),
        actions = { IconButton(onClick = { nav.navigate("islam_settings") }) { Icon(Icons.Filled.Settings, null) } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                val left = Duration.between(now, next.second).coerceAtLeast(Duration.ZERO)
                Card(onClick = { nav.navigate("prayer") }) {
                    Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF0F766E), Color(0xFF1E3A8A)))).padding(18.dp)) {
                        Text(Prayer.hijri(), color = Color(0xFFFDE68A), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("الصلاة القادمة • ", "Next prayer • ") + IslamPrefs.cityName, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                                Text(Prayer.names[next.first] + "  " + Prayer.fmt(next.second), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Text(String.format(Locale.US, "-%02d:%02d:%02d", left.toHours(), left.toMinutes() % 60, left.seconds % 60), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            items(features.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { f ->
                        Card(onClick = { nav.navigate(f.route) }, modifier = Modifier.weight(1f)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                IconCircle(f.icon, f.color, 44.dp)
                                Spacer(Modifier.height(8.dp))
                                Text(f.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(f.sub, style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (hadith != null) item {
                Card(colors = CardDefaults.cardColors(containerColor = c.secondaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(tr("قال رسول الله ﷺ", "The Prophet ﷺ said"), fontWeight = FontWeight.Bold, color = c.secondary)
                        Spacer(Modifier.height(6.dp))
                        Text(hadith.first, lineHeight = 26.sp)
                        if (hadith.second.isNotBlank()) Text("[" + hadith.second + "]", style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ============================ الأذكار ============================
@Composable
fun AzkarHomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val groups = remember { Content.load(ctx, Content.AZKAR) }
    ScreenScaffold(title = tr("الأذكار", "Azkar"), onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { nav.navigate("islam_settings") }) { Icon(Icons.Filled.NotificationsActive, null) }
    }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(groups.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { g ->
                        val gi = groups.indexOf(g)
                        Card(onClick = { nav.navigate("azkar/$gi") }, modifier = Modifier.weight(1f)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(g.icon.ifBlank { "📿" }, fontSize = 30.sp)
                                Text(g.title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2)
                                Text(tr("${g.items.size} ذكر", "${g.items.size} azkar"), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/** نص الذكر: يستخدم نص المصحف إن توفر */
fun itemDisplayText(item: CItem): String {
    val refs = item.m("ayat")
    val q = if (refs != null) QuranRepo.refs(refs) else emptyList()
    val core = if (q.isNotEmpty()) ayatText(q) else item.body
    val pre = item.m("pre")
    return if (pre != null) "$pre\n$core" else core
}

private fun vibrate(ctx: Context) {
    try {
        val v = ctx.getSystemService(Vibrator::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (_: Exception) {}
}

@Composable
fun AzkarListScreen(nav: NavController, gi: Int) {
    val ctx = LocalContext.current
    val ready = rememberQuranReady()
    val groups = remember { Content.load(ctx, Content.AZKAR) }
    val g = groups.getOrNull(gi) ?: return
    // تصفير العدادات يومياً
    remember {
        val today = LocalDate.now().toEpochDay()
        if (IslamPrefs.azkarCountDay != today) { IslamPrefs.resetAzkarCounts(); IslamPrefs.azkarCountDay = today }
        0
    }
    var counts by remember { mutableStateOf(g.items.indices.map { IslamPrefs.azkarCount("${gi}_$it") }) }
    val done = g.items.indices.count { counts[it] >= g.items[it].count }
    val fs = IslamPrefs.readerFont + 2

    ScreenScaffold(
        title = g.title, onBack = { nav.popBackStack() },
        actions = {
            IconButton(onClick = {
                g.items.indices.forEach { IslamPrefs.setAzkarCount("${gi}_$it", 0) }
                counts = g.items.indices.map { 0 }
            }) { Icon(Icons.Filled.RestartAlt, null) }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            LinearProgressIndicator(progress = { if (g.items.isEmpty()) 0f else done.toFloat() / g.items.size }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
            Text(
                tr("أنجزت $done من ${g.items.size}", "Completed $done of ${g.items.size}") + if (done == g.items.size) tr(" • تقبّل الله 🤍", " • May Allah accept 🤍") else "",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall
            )
            LazyColumn(contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 90.dp), verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                if (!ready && g.items.any { it.m("ayat") != null }) item { QuranDownloadCard() }
                itemsIndexed(g.items) { i, item ->
                    val text = remember(item, ready) { itemDisplayText(item) }
                    val target = item.count
                    val c = counts.getOrElse(i) { 0 }
                    val finished = c >= target
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (finished) SuccessGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth().animateContentSize()
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                            Spacer(Modifier.height(6.dp))
                            SelectionContainer { Text(text, fontSize = fs.sp, lineHeight = (fs * 1.8).sp) }
                            item.m("fadl")?.let {
                                Spacer(Modifier.height(6.dp))
                                Text("✨ $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                            }
                            item.m("src")?.let { Text("[$it]", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val refs = item.m("ayat")
                                    if (refs != null && QuranRepo.ready.value) SeqPlayer.play(ctx, QuranRepo.refs(refs).map { Seg.AyahSeg(it.global) }, QuranRepo.reciterById(IslamPrefs.reciter), item.title)
                                    else { SeqPlayer.stop(); Tts.speak(ctx, text) }
                                }) { Icon(Icons.Filled.VolumeUp, null) }
                                IconButton(onClick = { copyText(ctx, text) }) { Icon(Icons.Filled.ContentCopy, null) }
                                IconButton(onClick = { shareText(ctx, text + (item.m("src")?.let { "\n[$it]" } ?: "")) }) { Icon(Icons.Filled.Share, null) }
                                Spacer(Modifier.weight(1f))
                                Box(
                                    Modifier.size(64.dp).clip(CircleShape)
                                        .background(if (finished) SuccessGreen else MaterialTheme.colorScheme.primary)
                                        .clickable {
                                            if (!finished) {
                                                val nc = c + 1
                                                IslamPrefs.setAzkarCount("${gi}_$i", nc)
                                                counts = counts.toMutableList().also { it[i] = nc }
                                                vibrate(ctx)
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (finished) Icon(Icons.Filled.Check, null, tint = Color.White)
                                    else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("${target - c}", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                                        if (target > 1) Text("/$target", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            MiniPlayerBar()
        }
    }
    DisposableEffect(Unit) { onDispose { Tts.stop() } }
}

// ============================ الرقية الشرعية ============================
@Composable
fun RuqyahHomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val groups = remember { Content.load(ctx, Content.RUQYAH) }
    ScreenScaffold(title = tr("الرقية الشرعية", "Ruqyah"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                InfoBanner(tr(
                    "الرقية الشرعية تكون بكلام الله وأسمائه وصفاته وبالأدعية الثابتة عن النبي ﷺ، باللسان العربي، مع اعتقاد أن الشفاء من الله وحده. ويُستحب أن يرقي المسلم نفسه.",
                    "Ruqyah is with the Quran, Allah's names and authentic prophetic supplications, believing that healing is from Allah alone."
                ), MaterialTheme.colorScheme.primary)
            }
            item {
                Card(onClick = { nav.navigate("ruqyah_audio") }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🎧", fontSize = 28.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tr("الرقية كاملة بأصوات المشايخ", "Complete ruqyah by sheikhs"), fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
                            Text(tr("العفاسي، المنشاوي، الحذيفي، الغامدي، العجمي وغيرهم • استماع وتنزيل", "Alafasy, Minshawi, Hudhaifi, Ghamdi, Ajmi and more • listen & download"), style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(Icons.Filled.ChevronLeft, null)
                    }
                }
            }
            itemsIndexed(groups) { gi, g ->
                Card(onClick = { nav.navigate("ruqyah/$gi") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(g.icon.ifBlank { "🤲" }, fontSize = 28.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(g.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(tr("${g.items.size} أجزاء", "${g.items.size} parts"), style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(Icons.Filled.ChevronLeft, null)
                    }
                }
            }
        }
    }
}

@Composable
fun RuqyahDetailScreen(nav: NavController, gi: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ready = rememberQuranReady()
    val groups = remember { Content.load(ctx, Content.RUQYAH) }
    val g = groups.getOrNull(gi) ?: return
    val fs = IslamPrefs.readerFont + 2
    var dl by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val reciter = QuranRepo.reciterById(IslamPrefs.reciter)
    val globals = remember(ready) { g.items.flatMap { it.m("ayat")?.let { r -> QuranRepo.refs(r).map { a -> a.global } } ?: emptyList() } }
    val duas = remember { g.items.filter { it.m("ayat") == null }.joinToString("\n\n") { it.body } }

    fun segments(): List<Seg> = g.items.flatMap { item ->
        val refs = item.m("ayat")
        val seg: List<Seg> = if (refs != null) QuranRepo.refs(refs).map { Seg.AyahSeg(it.global) } else listOf(Seg.Speak(item.body))
        (1..item.count.coerceIn(1, 7)).flatMap { seg }
    }

    val saveMp3 = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true
            val ok = withContext(Dispatchers.IO) {
                QuranRepo.downloadMany(ctx, reciter, globals) { _, _ -> }
                val out = File(ctx.cacheDir, "ruqyah.mp3")
                val merged = QuranRepo.mergeMp3(globals.map { QuranRepo.audioFile(ctx, reciter.id, it) }, out)
                if (merged) ctx.contentResolver.openOutputStream(uri)?.use { o -> out.inputStream().use { it.copyTo(o) } }
                out.delete()
                merged
            }
            busy = false
            toast(ctx, if (ok) tr("تم حفظ آيات الرقية كملف صوتي ✅", "Ruqyah verses saved as audio ✅") else tr("فشل الحفظ، تحقق من الإنترنت", "Save failed, check connection"))
        }
    }

    ScreenScaffold(title = g.title, onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad)) {
            LazyColumn(contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                if (!ready) item { QuranDownloadCard() }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(tr("القارئ: ", "Reciter: ") + IslamPrefs.reciterName, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    if (SeqPlayer.active.value) SeqPlayer.stop() else SeqPlayer.play(ctx, segments(), reciter, g.title)
                                }, enabled = ready, modifier = Modifier.weight(1f)) {
                                    Icon(if (SeqPlayer.active.value) Icons.Filled.Stop else Icons.Filled.PlayArrow, null)
                                    Text(if (SeqPlayer.active.value) tr("إيقاف", "Stop") else tr("تشغيل الرقية", "Play ruqyah"))
                                }
                                OutlinedButton(onClick = { dl = true }, enabled = ready && globals.isNotEmpty()) {
                                    Icon(Icons.Filled.DownloadForOffline, null)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { saveMp3.launch("Ruqyah_${g.title}.mp3") }, enabled = ready && !busy && globals.isNotEmpty(), modifier = Modifier.weight(1f)) {
                                    if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.Download, null)
                                    Spacer(Modifier.width(4.dp)); Text(tr("حفظ الآيات MP3", "Save verses MP3"), maxLines = 1)
                                }
                            }
                            if (duas.isNotBlank()) TtsControls(duas, "Ruqyah_duas")
                            Text(
                                tr("التشغيل يقرأ الآيات بصوت الشيخ والأدعية بالقراءة الآلية، مع تكرار ما ورد تكراره.", "Plays verses by the reciter and supplications via text-to-speech, repeating where prescribed."),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                items(g.items) { item ->
                    val text = remember(item, ready) { itemDisplayText(item) }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(item.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                                if (item.count > 1) StatusChip(tr("${item.count} مرات", "${item.count}×"), MaterialTheme.colorScheme.secondary)
                            }
                            Spacer(Modifier.height(6.dp))
                            SelectionContainer { Text(text, fontSize = fs.sp, lineHeight = (fs * 1.8).sp) }
                            item.m("note")?.let { Text("💡 $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary) }
                            item.m("src")?.let { Text("[$it]", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
            }
            MiniPlayerBar()
        }
    }
    if (dl) DownloadAyatDialog(tr("تنزيل آيات الرقية", "Download ruqyah verses"), globals) { dl = false }
}

// ============================ السنة النبوية ============================
@Composable
fun HadithHomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val groups = remember { Content.load(ctx, Content.HADITH) }
    var q by remember { mutableStateOf("") }
    ScreenScaffold(title = tr("السنة النبوية", "Sunnah"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { SearchField(q) { q = it } }
            item {
                Card(onClick = { nav.navigate("hadith_check") }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.FactCheck, null, tint = MaterialTheme.colorScheme.tertiary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tr("اكتب حديثاً واعرف درجته", "Write a hadith and check its grade"), fontWeight = FontWeight.Bold)
                            Text(tr("من الموسوعة الحديثية - الدرر السنية", "From Dorar al-Saniyyah encyclopedia"), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (q.length >= 2) {
                val nq = QuranRepo.normalize(q)
                val res = groups.flatMap { g -> g.items.map { g to it } }.filter { QuranRepo.normalize(it.second.body).contains(nq) || it.second.title.contains(q) }
                item { Text(tr("${res.size} نتيجة", "${res.size} results"), color = MaterialTheme.colorScheme.primary) }
                items(res) { (grp, h) -> HadithCard(h, grp.title, nav) }
            } else itemsIndexed(groups) { gi, g ->
                Card(onClick = { nav.navigate("hadith/$gi") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(g.icon.ifBlank { "📜" }, fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(g.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        StatusChip("${g.items.size}", MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun HadithListScreen(nav: NavController, gi: Int) {
    val ctx = LocalContext.current
    val g = remember { Content.load(ctx, Content.HADITH) }.getOrNull(gi) ?: return
    ScreenScaffold(title = g.title, onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(g.items) { HadithCard(it, null, nav) }
        }
    }
    DisposableEffect(Unit) { onDispose { Tts.stop() } }
}

@Composable
private fun HadithCard(item: CItem, group: String?, nav: NavController) {
    val ctx = LocalContext.current
    val fs = IslamPrefs.readerFont + 1
    val full = item.body + (item.m("src")?.let { "\n[$it]" } ?: "")
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            if (group != null) Text(group, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
            Text(item.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            SelectionContainer { Text(item.body, fontSize = fs.sp, lineHeight = (fs * 1.75).sp) }
            item.m("src")?.let { Text("[$it]", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp)) }
            item.m("note")?.let { Text("💡 $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary) }
            Row {
                IconButton(onClick = { SeqPlayer.stop(); Tts.speak(ctx, item.body) }) { Icon(Icons.Filled.VolumeUp, null) }
                IconButton(onClick = { copyText(ctx, full) }) { Icon(Icons.Filled.ContentCopy, null) }
                IconButton(onClick = { shareText(ctx, full) }) { Icon(Icons.Filled.Share, null) }
                IconButton(onClick = { nav.navigate("hadith_check?q=" + Uri.encode(item.body.take(70))) }) { Icon(Icons.Filled.FactCheck, null) }
            }
        }
    }
}

/** التحقق من حديث عبر الموسوعة الحديثية (الدرر السنية) */
@Composable
fun HadithCheckScreen(nav: NavController, initial: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf(initial) }
    var loading by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<String>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val local = remember(results) {
        if (q.length < 4) emptyList() else {
            val nq = QuranRepo.normalize(q).take(40)
            Content.allItems(ctx, Content.HADITH).filter { QuranRepo.normalize(it.second.body).contains(nq) }.take(5)
        }
    }

    fun search() {
        if (q.isBlank()) return
        loading = true; error = null; results = null
        scope.launch {
            try {
                val html = withContext(Dispatchers.IO) {
                    JSONObject(Net.get("https://dorar.net/dorar_api.json?skey=" + URLEncoder.encode(q.trim(), "UTF-8")))
                        .getJSONObject("ahadith").getString("result")
                }
                // كل نتيجة تنتهي بخلاصة حكم المحدث
                val plain = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString()
                results = plain.split(Regex("\\n\\s*-{3,}\\s*\\n|\\n{3,}")).map { it.trim() }.filter { it.length > 20 }
                    .ifEmpty { if (plain.isBlank()) emptyList() else listOf(plain.trim()) }
            } catch (e: Exception) {
                error = tr("تعذر الاتصال بالموسوعة الحديثية. تحقق من الإنترنت ثم حاول مجدداً.", "Could not reach the hadith encyclopedia. Check your connection.")
            }
            loading = false
        }
    }
    LaunchedEffect(Unit) { if (initial.isNotBlank()) search() }

    ScreenScaffold(title = tr("التحقق من حديث", "Check a hadith"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                OutlinedTextField(q, { q = it }, label = { Text(tr("اكتب نص الحديث أو جزءاً منه", "Type the hadith text or part of it")) }, minLines = 3, modifier = Modifier.fillMaxWidth())
            }
            item {
                Button(onClick = { search() }, enabled = !loading && q.isNotBlank(), modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White) else Icon(Icons.Filled.Search, null)
                    Spacer(Modifier.width(8.dp)); Text(tr("ابحث عن درجة الحديث", "Find the grade"))
                }
            }
            item {
                Text(
                    tr(
                        "تُعرض النتائج كما هي من الموسوعة الحديثية بموقع الدرر السنية: الراوي، والمحدث، والمصدر، وخلاصة حكم المحدث. التطبيق لا يحكم على الأحاديث من تلقاء نفسه، وللفتوى يُرجع إلى أهل العلم.",
                        "Results are shown as returned by Dorar al-Saniyyah (narrator, scholar, source and grading). The app does not grade hadith itself."
                    ), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            error?.let { item { InfoBanner(it, MaterialTheme.colorScheme.error) } }
            if (local.isNotEmpty()) {
                item { SectionTitle(tr("موجود في مكتبة التطبيق", "Found in the app library")) }
                items(local) { (grp, h) -> HadithCard(h, grp.title, nav) }
            }
            results?.let { list ->
                item { SectionTitle(tr("نتائج الموسوعة الحديثية (${list.size})", "Encyclopedia results (${list.size})")) }
                if (list.isEmpty()) item { EmptyState(Icons.Filled.Search, tr("لا توجد نتائج. جرّب كلمات أقل أو أدق من الحديث.", "No results. Try fewer or more precise words.")) }
                items(list) { r ->
                    val primary = MaterialTheme.colorScheme.primary
                    val annotated = remember(r) {
                        buildAnnotatedString {
                            r.lines().forEachIndexed { i, line ->
                                if (i > 0) append('\n')
                                when {
                                    line.contains("خلاصة حكم المحدث") -> withStyle(SpanStyle(color = primary, fontWeight = FontWeight.Bold)) { append("⚖️ " + line) }
                                    line.contains("الراوي") || line.contains("المحدث") || line.contains("المصدر") || line.contains("الصفحة أو الرقم") ->
                                        withStyle(SpanStyle(color = Color(0xFF64748B), fontSize = 13.sp)) { append(line) }
                                    else -> append(line)
                                }
                            }
                        }
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            SelectionContainer { Text(annotated, lineHeight = 26.sp) }
                            Row {
                                IconButton(onClick = { copyText(ctx, r) }) { Icon(Icons.Filled.ContentCopy, null) }
                                IconButton(onClick = { shareText(ctx, r) }) { Icon(Icons.Filled.Share, null) }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================ قارئ المحتوى العام ============================
fun contentTitle(file: String) = when (file) {
    Content.RULINGS -> tr("أحكام الإسلام", "Islamic rulings")
    Content.PROPHETS -> tr("قصص الأنبياء", "Stories of the Prophets")
    Content.BATTLES -> tr("غزوات الإسلام", "Battles of Islam")
    Content.SIRA -> tr("السيرة النبوية", "The Prophet's biography")
    Content.COMPANIONS -> tr("قصص الصحابة", "Stories of the Companions")
    Content.MIRACLES -> tr("معجزات الأنبياء", "Miracles of the Prophets")
    Content.MEDICINE -> tr("الطب النبوي", "Prophetic medicine")
    Content.HAJJ -> tr("الحج والعمرة", "Hajj & Umrah")
    Content.SIGNS -> tr("علامات الساعة", "Signs of the Hour")
    else -> ""
}

@Composable
fun ContentListScreen(nav: NavController, file: String) {
    val ctx = LocalContext.current
    val groups = remember(file) { Content.load(ctx, file) }
    var q by remember { mutableStateOf("") }
    ScreenScaffold(title = contentTitle(file), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { SearchField(q) { q = it } }
            groups.forEachIndexed { gi, g ->
                val list = g.items.withIndex().filter { iv -> q.isBlank() || iv.value.title.contains(q) || iv.value.body.contains(q) }
                if (list.isNotEmpty()) {
                    if (g.title.isNotBlank()) item { SectionTitle((if (g.icon.isNotBlank()) g.icon + "  " else "") + g.title) }
                    items(list) { iv ->
                        val ii = iv.index
                        val ci = iv.value
                        Card(onClick = { nav.navigate("cread/$file/$gi/$ii") }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(ci.title, fontWeight = FontWeight.Bold)
                                    val sub = listOfNotNull(ci.m("order"), ci.m("sub"), ci.m("status"), ci.m("date"), ci.m("place")).joinToString(" • ")
                                    if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Icon(Icons.Filled.ChevronLeft, null)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContentReaderScreen(nav: NavController, file: String, gi: Int, ii: Int) {
    val ctx = LocalContext.current
    val groups = remember(file) { Content.load(ctx, file) }
    val item = groups.getOrNull(gi)?.items?.getOrNull(ii) ?: return
    var fs by remember { mutableIntStateOf(IslamPrefs.readerFont) }
    val metaLabels = mapOf(
        "sub" to tr("نبذة", "About"), "date" to tr("التاريخ", "Date"), "place" to tr("المكان", "Place"),
        "muslims" to tr("عدد المسلمين", "Muslims"), "enemy" to tr("الطرف الآخر", "Opponents"),
        "leader" to tr("القائد", "Leader"), "result" to tr("النتيجة", "Result"), "quran" to tr("ذكره في القرآن", "In the Quran"),
        "people" to tr("القوم", "People"), "src" to tr("المصدر", "Source"),
        "lineage" to tr("النسب", "Lineage"), "death" to tr("الوفاة", "Death"), "prophet" to tr("النبي", "Prophet"),
        "order" to tr("الترتيب", "Order"), "status" to tr("الحالة", "Status")
    )
    val speakText = remember(item) { item.title + ".\n" + item.body.replace("■ ", "").replace("• ", "").replace("▪ ", "") }

    ScreenScaffold(
        title = item.title, onBack = { nav.popBackStack() },
        actions = {
            IconButton(onClick = { fs = (fs - 1).coerceAtLeast(13); IslamPrefs.readerFont = fs }) { Icon(Icons.Filled.ZoomOut, null) }
            IconButton(onClick = { fs = (fs + 1).coerceAtMost(30); IslamPrefs.readerFont = fs }) { Icon(Icons.Filled.ZoomIn, null) }
            IconButton(onClick = { shareText(ctx, item.title + "\n\n" + item.body) }) { Icon(Icons.Filled.Share, null) }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val metas = item.meta.filterKeys { it in metaLabels }
            if (metas.isNotEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        metas.forEach { (k, v) -> KeyValue(metaLabels[k] ?: k, v) }
                    }
                }
            }
            TtsControls(speakText, item.title.replace(" ", "_"))
            SelectionContainer { RichBody(item.body, fs) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val g = groups[gi]
                if (ii > 0) OutlinedButton(onClick = { nav.navigate("cread/$file/$gi/${ii - 1}") { popUpTo("cread/{file}/{g}/{i}") { inclusive = true } } }, modifier = Modifier.weight(1f)) {
                    Text(tr("السابق", "Previous"), maxLines = 1)
                }
                if (ii < g.items.size - 1) Button(onClick = { nav.navigate("cread/$file/$gi/${ii + 1}") { popUpTo("cread/{file}/{g}/{i}") { inclusive = true } } }, modifier = Modifier.weight(1f)) {
                    Text(tr("التالي: ", "Next: ") + g.items[ii + 1].title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ============================ إعدادات الإسلاميات ============================
@Composable
fun IslamSettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    var azkar by remember { mutableStateOf(IslamPrefs.azkarRemind) }
    var m by remember { mutableIntStateOf(IslamPrefs.morningMin) }
    var e by remember { mutableIntStateOf(IslamPrefs.eveningMin) }
    var hours by remember { mutableIntStateOf(IslamPrefs.hadithHours) }
    var istg by remember { mutableIntStateOf(IslamPrefs.istighfarMin) }
    var slw by remember { mutableIntStateOf(IslamPrefs.salawatMin) }
    var qFrom by remember { mutableIntStateOf(IslamPrefs.quietFrom) }
    var qTo by remember { mutableIntStateOf(IslamPrefs.quietTo) }
    var silent by remember { mutableStateOf(IslamPrefs.dhikrSilent) }
    fun hm(v: Int) = String.format(Locale.US, "%02d:%02d", v / 60, v % 60)
    fun pickTime(cur: Int, set: (Int) -> Unit) {
        TimePickerDialog(ctx, { _, h, mi -> set(h * 60 + mi) }, cur / 60, cur % 60, false).show()
    }

    ScreenScaffold(title = tr("إعدادات الإسلاميات", "Islamic settings"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("تنبيه الأذكار", "Azkar reminders"))
                    SwitchRow(tr("تذكير بأذكار الصباح والمساء", "Remind me of morning & evening azkar"), null, azkar, Icons.Filled.NotificationsActive) {
                        azkar = it; IslamPrefs.azkarRemind = it; IslamAlarms.scheduleAzkar(ctx)
                    }
                    OutlinedButton(onClick = { pickTime(m) { v -> m = v; IslamPrefs.morningMin = v; IslamAlarms.scheduleAzkar(ctx) } }, enabled = azkar, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.WbSunny, null); Spacer(Modifier.width(8.dp)); Text(tr("أذكار الصباح: ", "Morning: ") + hm(m))
                    }
                    OutlinedButton(onClick = { pickTime(e) { v -> e = v; IslamPrefs.eveningMin = v; IslamAlarms.scheduleAzkar(ctx) } }, enabled = azkar, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Brightness2, null); Spacer(Modifier.width(8.dp)); Text(tr("أذكار المساء: ", "Evening: ") + hm(e))
                    }
                    Text(tr("وقت أذكار الصباح من الفجر إلى طلوع الشمس، والمساء من العصر إلى الغروب.", "Morning azkar: Fajr to sunrise. Evening: Asr to sunset."), style = MaterialTheme.typography.bodySmall)
                }
            }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("حديث على الشاشة", "Hadith notifications"))
                    Text(tr("إرسال حديث نبوي كإشعار يظهر أعلى الشاشة كل:", "Show a hadith notification every:"))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 1, 3, 6, 12, 24).forEach { h ->
                            FilterChip(hours == h, { hours = h; IslamPrefs.hadithHours = h; HadithWorker.schedule(ctx) },
                                label = { Text(if (h == 0) tr("إيقاف", "Off") else tr("$h س", "${h}h")) })
                        }
                    }
                    Text(
                        tr("يمكنك أيضاً إضافة ودجت \"حديث نبوي\" للشاشة الرئيسية: اضغط مطولاً على الشاشة الرئيسية ← الأدوات (Widgets) ← Sho3eb.",
                            "You can also add the \"Hadith\" widget: long-press your home screen → Widgets → Sho3eb."),
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(onClick = {
                        Content.randomHadith(ctx)?.let { h ->
                            IslamNotify.show(ctx, IslamNotify.CH_HADITH, 3300, tr("قال رسول الله ﷺ", "The Prophet ﷺ said"), h.first + "\n[${h.second}]", "hadith")
                            HadithWidget.updateAll(ctx, h)
                        }
                    }) { Text(tr("تجربة الآن", "Try now")) }
                }
            }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("تذكير الاستغفار والصلاة على النبي ﷺ", "Istighfar & salawat reminders"))
                    val opts = listOf(0, 15, 30, 60, 120, 180, 360)
                    fun lbl(v: Int) = when {
                        v == 0 -> tr("إيقاف", "Off")
                        v < 60 -> tr("$v د", "${v}m")
                        else -> tr("${v / 60} س", "${v / 60}h")
                    }
                    SwitchRow(tr("تذكير بالاستغفار", "Istighfar reminder"), tr("صيغ استغفار مأثورة مع فضلها", "Authentic formulas with their virtue"), istg > 0, Icons.Filled.Favorite) {
                        istg = if (it) 60 else 0; IslamPrefs.istighfarMin = istg; DhikrWorker.schedule(ctx, DhikrWorker.ISTIGHFAR)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        opts.forEach { v -> FilterChip(istg == v, { istg = v; IslamPrefs.istighfarMin = v; DhikrWorker.schedule(ctx, DhikrWorker.ISTIGHFAR) }, label = { Text(lbl(v)) }) }
                    }
                    HorizontalDivider()
                    SwitchRow(tr("تذكير بالصلاة على النبي ﷺ", "Salawat reminder"), tr("صيغ الصلاة الإبراهيمية وغيرها", "Ibrahimi and other formulas"), slw > 0, Icons.Filled.NotificationsActive) {
                        slw = if (it) 60 else 0; IslamPrefs.salawatMin = slw; DhikrWorker.schedule(ctx, DhikrWorker.SALAWAT)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        opts.forEach { v -> FilterChip(slw == v, { slw = v; IslamPrefs.salawatMin = v; DhikrWorker.schedule(ctx, DhikrWorker.SALAWAT) }, label = { Text(lbl(v)) }) }
                    }
                    HorizontalDivider()
                    Text(tr("أوقات الهدوء (بدون تذكير):", "Quiet hours (no reminders):"), style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickTime(qFrom * 60) { v -> qFrom = v / 60; IslamPrefs.quietFrom = qFrom } }, modifier = Modifier.weight(1f)) {
                            Text(tr("من ", "From ") + hm(qFrom * 60))
                        }
                        OutlinedButton(onClick = { pickTime(qTo * 60) { v -> qTo = v / 60; IslamPrefs.quietTo = qTo } }, modifier = Modifier.weight(1f)) {
                            Text(tr("إلى ", "To ") + hm(qTo * 60))
                        }
                    }
                    SwitchRow(tr("إشعار صامت", "Silent notification"), tr("يظهر الإشعار دون صوت", "Show without sound"), silent, Icons.Filled.NotificationsOff) {
                        silent = it; IslamPrefs.dhikrSilent = it
                    }
                    Text(
                        tr("ملاحظة: أقل فترة يسمح بها نظام أندرويد للتذكير الدوري هي 15 دقيقة، وقد يتأخر التذكير قليلاً لتوفير البطارية.", "Note: Android's minimum periodic interval is 15 minutes; reminders may be slightly delayed to save battery."),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val (t, b) = DhikrWorker.message(DhikrWorker.ISTIGHFAR)
                            IslamNotify.show(ctx, IslamNotify.CH_DHIKR, 3401, t, b, "azkar")
                        }, modifier = Modifier.weight(1f)) { Text(tr("تجربة الاستغفار", "Test istighfar"), maxLines = 1) }
                        OutlinedButton(onClick = {
                            val (t, b) = DhikrWorker.message(DhikrWorker.SALAWAT)
                            IslamNotify.show(ctx, IslamNotify.CH_DHIKR, 3402, t, b, "azkar")
                        }, modifier = Modifier.weight(1f)) { Text(tr("تجربة الصلاة", "Test salawat"), maxLines = 1) }
                    }
                }
            }
            Card(onClick = { nav.navigate("tts_voice") }) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.RecordVoiceOver, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("صوت القراءة (الأذكار والقصص)", "Reading voice (azkar & stories)"), fontWeight = FontWeight.SemiBold)
                        Text(
                            when (IslamPrefs.ttsVoice) {
                                "" -> tr("تلقائي: صوت رجل", "Auto: male voice")
                                "default" -> tr("صوت المحرك الافتراضي", "Engine default")
                                else -> IslamPrefs.ttsVoice
                            }, style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Icon(Icons.Filled.ChevronLeft, null)
                }
            }
            Card(onClick = { nav.navigate("reciters") }) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.RecordVoiceOver, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("القراء والتلاوات المنزّلة", "Reciters & downloads"), fontWeight = FontWeight.SemiBold)
                        Text(IslamPrefs.reciterName, style = MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Filled.ChevronLeft, null)
                }
            }
        }
    }
}
