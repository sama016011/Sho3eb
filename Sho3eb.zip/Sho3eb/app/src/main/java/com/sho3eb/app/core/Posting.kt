package com.sho3eb.app.core

import com.sho3eb.app.data.AccountTx

/** ترحيل حركات السلف والأقساط إلى الحسابات حسب طبيعتها (صرف / إضافة) */
object Posting {
    private val sp get() = com.sho3eb.app.Sho3ebApp.instance.getSharedPreferences("posting", android.content.Context.MODE_PRIVATE)

    /** آخر حساب اختاره المستخدم لكل نوع (لتسهيل الإدخال) */
    fun lastAccount(kind: String): Long? = sp.getLong("acc_$kind", -1L).takeIf { it > 0 }
    fun setLastAccount(kind: String, id: Long?) = sp.edit().putLong("acc_$kind", id ?: -1L).apply()

    suspend fun post(accountId: Long?, srcType: String, srcId: Long, isIn: Boolean, amount: Double, date: Long, note: String) {
        if (accountId == null || amount <= 0) return
        appDao().insertAccountTx(
            AccountTx(
                accountId = accountId, type = if (isIn) AccountTx.IN else AccountTx.OUT,
                amount = amount, date = date, note = note, srcType = srcType, srcId = srcId
            )
        )
    }

    fun sourceLabel(t: AccountTx): String? = when (t.srcType) {
        AccountTx.SRC_LOAN -> tr("مرحّلة من السلف", "From loans")
        AccountTx.SRC_SALE_PAY -> tr("مرحّلة من الأقساط", "From installments")
        AccountTx.SRC_SALE_DOWN -> tr("دفعة مقدمة - تقسيط", "Down payment")
        AccountTx.SRC_LIV -> tr("مرحّلة من مصاريف المعيشة", "From living expenses")
        else -> null
    }
}
