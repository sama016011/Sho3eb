@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import kotlinx.coroutines.launch

@Composable
private fun ActionRow(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (value.isNotBlank()) Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** تواصل معنا • شراء التطبيق • مشاركة • تقييم */
@Composable
fun ContactScreen(nav: NavController) {
    val ctx = LocalContext.current
    var ver by remember { mutableIntStateOf(0) }
    val c = remember(ver) { Edition.contact }
    var editing by remember { mutableStateOf(false) }
    var askPw by remember { mutableStateOf(false) }
    var unlockDlg by remember { mutableStateOf(false) }

    ScreenScaffold(title = tr("تواصل معنا", "Contact us"), onBack = { nav.popBackStack() }, actions = {
        if (Edition.canEditContact) IconButton(onClick = { if (Edition.hasOwnerPassword) askPw = true else editing = true }) { Icon(Icons.Filled.Edit, null) }
    }) { p ->
        Column(Modifier.padding(p).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AppLogo(64)
                    Spacer(Modifier.height(6.dp))
                    Text(Edition.appName, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    if (Edition.description.isNotBlank()) Text(Edition.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (c.name.isNotBlank()) Text(tr("المطوّر: ", "Developer: ") + c.name, style = MaterialTheme.typography.bodySmall)
                }
            }
            val empty = listOf(c.phone, c.whatsapp, c.email, c.website, c.facebook, c.telegram, c.address).all { it.isBlank() }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    SectionTitle(tr("📞 بيانات التواصل", "📞 Contact details"))
                    if (empty) Text(
                        if (Edition.canEditContact) tr("لم تُضف بيانات التواصل بعد. اضغط ✏️ بالأعلى لإضافتها.", "No contact details yet. Tap ✏️ above to add them.")
                        else tr("لا توجد بيانات تواصل.", "No contact details."), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)
                    )
                    if (c.phone.isNotBlank()) ActionRow(Icons.Filled.Call, tr("اتصال", "Call"), c.phone) { Edition.call(ctx, c.phone) }
                    if (c.whatsapp.isNotBlank()) ActionRow(Icons.Filled.Chat, tr("واتساب", "WhatsApp"), c.whatsapp) { Edition.whatsapp(ctx, c.whatsapp, tr("مرحباً، بخصوص تطبيق ", "Hello, about ") + Edition.appName) }
                    if (c.email.isNotBlank()) ActionRow(Icons.Filled.Email, tr("البريد الإلكتروني", "Email"), c.email) { Edition.mail(ctx, c.email, Edition.appName) }
                    if (c.website.isNotBlank()) ActionRow(Icons.Filled.Language, tr("الموقع", "Website"), c.website) { Edition.open(ctx, c.website) }
                    if (c.facebook.isNotBlank()) ActionRow(Icons.Filled.ThumbUp, "Facebook", c.facebook) { Edition.open(ctx, if (c.facebook.contains("/")) c.facebook else "https://facebook.com/" + c.facebook) }
                    if (c.telegram.isNotBlank()) ActionRow(Icons.AutoMirrored.Filled.Send, "Telegram", c.telegram) { Edition.open(ctx, "https://t.me/" + c.telegram.removePrefix("@").substringAfterLast("/")) }
                    if (c.address.isNotBlank()) ActionRow(Icons.Filled.Place, tr("العنوان", "Address"), c.address) { Edition.open(ctx, "geo:0,0?q=" + android.net.Uri.encode(c.address)) }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("🛒 شراء التطبيق", "🛒 Buy the app"))
                    if (c.price.isNotBlank()) Text(tr("السعر: ", "Price: ") + c.price, fontWeight = FontWeight.Bold)
                    if (c.buyNote.isNotBlank()) Text(c.buyNote, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        when {
                            c.buyUrl.isNotBlank() -> Edition.open(ctx, c.buyUrl)
                            c.whatsapp.isNotBlank() -> Edition.whatsapp(ctx, c.whatsapp, tr("أرغب في شراء تطبيق ", "I'd like to buy ") + Edition.appName)
                            c.phone.isNotBlank() -> Edition.call(ctx, c.phone)
                            else -> Edition.open(ctx, Edition.storeLink())
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.ShoppingCart, null); Spacer(Modifier.width(6.dp)); Text(tr("اطلب / اشترِ الآن", "Order / buy now")) }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("📤 مشاركة وتقييم", "📤 Share & rate"))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { Edition.shareLink(ctx) }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(4.dp)); Text(tr("مشاركة الرابط", "Share link")) }
                        OutlinedButton(onClick = { if (!Edition.shareApk(ctx)) toast(ctx, tr("تعذر تجهيز الملف", "Couldn't prepare file")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Android, null); Spacer(Modifier.width(4.dp)); Text(tr("إرسال التطبيق", "Send APK")) }
                    }
                    OutlinedButton(onClick = { Edition.open(ctx, Edition.storeLink()) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Shop, null); Spacer(Modifier.width(6.dp)); Text(tr("صفحة التطبيق على المتجر", "App page on the store")) }
                    Button(onClick = { Edition.rate(ctx) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Star, null); Spacer(Modifier.width(6.dp)); Text(tr("قيّم التطبيق ⭐⭐⭐⭐⭐", "Rate the app ⭐⭐⭐⭐⭐")) }
                }
            }
            if (Edition.canUnlock) TextButton(onClick = { unlockDlg = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text(tr("🔑 دخول المالك", "🔑 Owner login"), style = MaterialTheme.typography.labelSmall) }
            if (Edition.isUnlockedCopy) OutlinedButton(onClick = { Edition.relock(); toast(ctx, tr("أعد فتح التطبيق للعودة لنسخة المشاركة", "Reopen the app to return to the shared edition")) }, modifier = Modifier.fillMaxWidth()) { Text(tr("🔒 العودة لوضع نسخة المشاركة", "🔒 Back to shared edition mode")) }
            if (Edition.isOwner) Card(onClick = { nav.navigate("edition_studio") }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AppSettingsAlt, null); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("استوديو نسخة المشاركة (للمالك)", "Shared edition studio (owner)"), fontWeight = FontWeight.Bold)
                        Text(tr("اختر الأقسام والاسم والأيقونة والوصف لنسخة توزعها", "Pick sections, name, icon & description for a copy you distribute"), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (unlockDlg) {
        var pw by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { unlockDlg = false }, title = { Text(tr("دخول المالك", "Owner login")) }, text = {
            OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(tr("كلمة مرور المالك", "Owner password")) })
        }, confirmButton = { TextButton(onClick = {
            if (Edition.unlock(pw)) { unlockDlg = false; toast(ctx, tr("✅ تم فتح النسخة الكاملة. أعد فتح التطبيق.", "✅ Full version unlocked. Reopen the app.")); (ctx as? android.app.Activity)?.recreate() }
            else toast(ctx, tr("كلمة المرور غير صحيحة", "Wrong password"))
        }) { Text(tr("دخول", "Enter")) } }, dismissButton = { TextButton(onClick = { unlockDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
    if (askPw) OwnerPasswordDialog(onDismiss = { askPw = false }) { askPw = false; editing = true }
    if (editing) ContactEditDialog(onDismiss = { editing = false }) { editing = false; ver++ }
}

@Composable
fun OwnerPasswordDialog(onDismiss: () -> Unit, onOk: () -> Unit) {
    val ctx = LocalContext.current
    var pw by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("كلمة مرور المالك", "Owner password")) }, text = {
        OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
    }, confirmButton = { TextButton(onClick = { if (Edition.checkOwnerPassword(pw)) onOk() else toast(ctx, tr("كلمة المرور غير صحيحة", "Wrong password")) }) { Text(tr("دخول", "Enter")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } })
}

@Composable
private fun ContactEditDialog(onDismiss: () -> Unit, onSaved: () -> Unit) {
    val c0 = remember { Edition.ownerContact }
    var name by remember { mutableStateOf(c0.name) }
    var phone by remember { mutableStateOf(c0.phone) }
    var wa by remember { mutableStateOf(c0.whatsapp) }
    var email by remember { mutableStateOf(c0.email) }
    var web by remember { mutableStateOf(c0.website) }
    var fb by remember { mutableStateOf(c0.facebook) }
    var tg by remember { mutableStateOf(c0.telegram) }
    var addr by remember { mutableStateOf(c0.address) }
    var buy by remember { mutableStateOf(c0.buyUrl) }
    var note by remember { mutableStateOf(c0.buyNote) }
    var store by remember { mutableStateOf(c0.storeUrl) }
    var price by remember { mutableStateOf(c0.price) }
    var pw by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("تعديل بيانات التواصل", "Edit contact details")) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tr("هذه البيانات تظهر في نسخ المشاركة للعرض فقط ولا يمكن لغيرك تعديلها.", "These details appear read-only in shared copies."), style = MaterialTheme.typography.bodySmall)
            listOf(
                Triple(name, tr("اسمك / اسم الشركة", "Your name / company")) { v: String -> name = v },
                Triple(phone, tr("رقم الهاتف", "Phone")) { v: String -> phone = v },
                Triple(wa, tr("رقم واتساب", "WhatsApp number")) { v: String -> wa = v },
                Triple(email, tr("البريد الإلكتروني", "Email")) { v: String -> email = v },
                Triple(web, tr("الموقع", "Website")) { v: String -> web = v },
                Triple(fb, tr("فيسبوك (رابط أو اسم الصفحة)", "Facebook (link or page)")) { v: String -> fb = v },
                Triple(tg, tr("تيليجرام (@اسم)", "Telegram (@name)")) { v: String -> tg = v },
                Triple(addr, tr("العنوان", "Address")) { v: String -> addr = v },
                Triple(price, tr("سعر التطبيق (اختياري)", "App price (optional)")) { v: String -> price = v },
                Triple(buy, tr("رابط الشراء (اختياري)", "Buy link (optional)")) { v: String -> buy = v },
                Triple(note, tr("ملاحظة الشراء (طرق الدفع...)", "Buying note (payment methods...)")) { v: String -> note = v },
                Triple(store, tr("رابط التطبيق على المتجر (اختياري)", "Store link (optional)")) { v: String -> store = v }
            ).forEach { (v, l, set) -> OutlinedTextField(v, set, label = { Text(l) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            HorizontalDivider()
            OutlinedTextField(pw, { pw = it }, label = { Text(if (Edition.hasOwnerPassword) tr("كلمة مرور جديدة للمالك (اتركها فارغة للإبقاء)", "New owner password (blank = keep)") else tr("تعيين كلمة مرور للمالك (اختياري)", "Set an owner password (optional)")) },
                singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        }
    }, confirmButton = {
        TextButton(onClick = {
            Edition.ownerContact = Edition.Contact(name.trim(), phone.trim(), wa.trim(), email.trim(), web.trim(), fb.trim(), tg.trim(), addr.trim(), buy.trim(), note.trim(), store.trim(), price.trim())
            if (pw.isNotBlank()) Edition.setOwnerPassword(pw)
            onSaved()
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } })
}

/** استوديو نسخة المشاركة: للمالك فقط */
@Composable
fun EditionStudioScreen(nav: NavController) {
    val ctx = LocalContext.current
    if (!Edition.isOwner) { LaunchedEffect(Unit) { nav.popBackStack() }; return }
    var unlocked by remember { mutableStateOf(!Edition.hasOwnerPassword) }
    if (!unlocked) { OwnerPasswordDialog(onDismiss = { nav.popBackStack() }) { unlocked = true }; return }
    var name by remember { mutableStateOf(Edition.edName) }
    var desc by remember { mutableStateOf(Edition.edDesc) }
    var suffix by remember { mutableStateOf(Edition.edSuffix) }
    var secs by remember { mutableStateOf(Edition.edSections) }
    var ver by remember { mutableIntStateOf(0) }
    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { Edition.saveIcon(ctx, u); ver++ } }
    fun save() { Edition.edName = name.trim(); Edition.edDesc = desc.trim(); Edition.edSuffix = suffix.trim(); Edition.edSections = secs }

    ScreenScaffold(title = tr("استوديو نسخة المشاركة", "Shared edition studio"), onBack = { save(); nav.popBackStack() }) { p ->
        Column(Modifier.padding(p).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoBanner(tr("صمّم نسخة من التطبيق توزعها على الآخرين بأقسام محددة فقط، باسم وأيقونة ووصف خاص. الواجهة تتكيف تلقائياً مع الأقسام المختارة، وبيانات التواصل تظهر فيها للعرض فقط.",
                "Design a copy you distribute with only selected sections and its own name, icon and description. The UI adapts automatically and contact details are read-only."))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val ic = remember(ver) { Brand.bmp(Edition.edIcon(ctx)) }
                        Box(Modifier.size(76.dp).clip(RoundedCornerShape(18.dp)).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp)).clickable { pickIcon.launch("image/*") }, contentAlignment = Alignment.Center) {
                            if (ic != null) Image(ic.asImageBitmap(), null, Modifier.fillMaxSize()) else Icon(Icons.Filled.AddPhotoAlternate, null)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name.ifBlank { tr("اسم النسخة", "Edition name") }, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(desc.ifBlank { tr("الوصف تحت الاسم", "Description under the name") }, style = MaterialTheme.typography.bodySmall)
                            Text(tr("اضغط على المربع لاختيار الأيقونة", "Tap the box to pick the icon"), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    OutlinedTextField(name, { name = it }, label = { Text(tr("اسم التطبيق في النسخة", "App name in the edition")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(desc, { desc = it }, label = { Text(tr("وصف يظهر تحت الاسم", "Description under the name")) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(suffix, { suffix = it.filter { ch -> ch.isLetterOrDigit() }.lowercase() }, label = { Text(tr("معرّف النسخة بالإنجليزية (ليتم تثبيتها بجوار نسختك)", "Edition id in English (so it installs alongside yours)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionTitle(tr("الأقسام الظاهرة (${secs.size})", "Visible sections (${secs.size})"), Modifier.weight(1f))
                        TextButton(onClick = { secs = Edition.features.map { it.id }.toSet() }) { Text(tr("الكل", "All")) }
                        TextButton(onClick = { secs = emptySet() }) { Text(tr("لا شيء", "None")) }
                    }
                    Edition.features.forEach { f ->
                        Row(Modifier.fillMaxWidth().clickable { secs = if (f.id in secs) secs - f.id else secs + f.id }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.id in secs, { secs = if (it) secs + f.id else secs - f.id })
                            Text(f.emoji + "  " + f.label)
                        }
                    }
                    Text(tr("💡 إن لم تختر أي قسم تظهر كل الأقسام.", "💡 If none is selected, all sections are shown."), style = MaterialTheme.typography.bodySmall)
                }
            }
            // ---------- الطريقة 1: مباشرة من التطبيق ----------
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(tr("⚡ الطريقة 1: نسخة مباشرة من التطبيق (فوراً)", "⚡ Method 1: Direct edition from the app (instant)"))
                    Text(tr("ينشئ ملف التطبيق بإعداداتك ويرسله فوراً بواتساب أو بلوتوث. تظهر الأقسام المختارة والاسم والأيقونة والوصف داخل التطبيق، أما الاسم والأيقونة على شاشة الهاتف فيبقيان «Sho3eb».",
                        "Builds the app file with your settings and sends it right away. Chosen sections, name, icon and description show inside the app; the home-screen name/icon stay «Sho3eb»."), style = MaterialTheme.typography.bodySmall)
                    Text(tr("⚠️ لا تثبّت نسخة المشاركة على هاتفك: ستحل محل نسختك الكاملة (يمكن استعادتها بكلمة مرور المالك).", "⚠️ Don't install the shared copy on your own phone: it replaces your full app (recoverable with the owner password)."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    var building by remember { mutableStateOf(-1) }
                    var built by remember { mutableStateOf<java.io.File?>(null) }
                    var needPw by remember { mutableStateOf(false) }
                    val scope = rememberCoroutineScope()
                    if (building in 0..99) LinearProgressIndicator(progress = { building / 100f }, modifier = Modifier.fillMaxWidth())
                    Button(enabled = building !in 0..99, onClick = {
                        save()
                        if (!Edition.hasOwnerPassword) { needPw = true; return@Button }
                        building = 0
                        scope.launch {
                            val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { runCatching { Edition.buildDirect(ctx) { p -> building = p } } }
                            building = -1
                            r.onSuccess { f -> built = f; Edition.shareFile(ctx, f) }
                             .onFailure { e -> toast(ctx, tr("تعذر إنشاء النسخة: ", "Couldn't build: ") + (e.message ?: "")) }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Bolt, null); Spacer(Modifier.width(6.dp)); Text(tr("إنشاء نسخة المشاركة وإرسالها", "Create & send shared edition")) }
                    built?.let { f ->
                        Text("✅ " + f.name + " • " + (f.length() / 1_048_576) + " MB", style = MaterialTheme.typography.labelSmall)
                        OutlinedButton(onClick = { Edition.shareFile(ctx, f) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(6.dp)); Text(tr("إرسال مرة أخرى", "Send again")) }
                    }
                    if (needPw) {
                        var pw by remember { mutableStateOf("") }
                        AlertDialog(onDismissRequest = { needPw = false }, title = { Text(tr("عيّن كلمة مرور المالك أولاً", "Set an owner password first")) }, text = {
                            Column {
                                Text(tr("تحمي بيانات التواصل وتسمح لك وحدك بفتح وضع المالك في أي نسخة مشاركة.", "Protects contact details and lets only you unlock owner mode in any shared copy."), style = MaterialTheme.typography.bodySmall)
                                OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text(tr("كلمة المرور", "Password")) })
                            }
                        }, confirmButton = { TextButton(enabled = pw.length >= 4, onClick = { Edition.setOwnerPassword(pw); needPw = false; toast(ctx, tr("تم الحفظ، اضغط إنشاء مرة أخرى", "Saved, tap create again")) }) { Text(tr("حفظ", "Save")) } },
                            dismissButton = { TextButton(onClick = { needPw = false }) { Text(tr("إلغاء", "Cancel")) } })
                    }
                }
            }
            // ---------- الطريقة 2: عبر GitHub ----------
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SectionTitle(tr("🎨 الطريقة 2: نسخة باسمها وأيقونتها على شاشة الهاتف (عبر GitHub)", "🎨 Method 2: Own home-screen name & icon (via GitHub)"))
                    Text(tr("تظهر النسخة على شاشة الهاتف باسمها وأيقونتها الخاصة، وتُثبَّت بجوار نسختك دون أن تستبدلها.", "The edition shows its own name and icon on the home screen and installs alongside your app."), style = MaterialTheme.typography.bodySmall)
                    Text(tr("1) اضغط «تصدير حزمة النسخة» واحفظ الملف.\n2) فك الضغط وارفع مجلد edition إلى جذر مستودع GitHub (بجوار مجلد app).\n3) سيبني GitHub Actions تلقائياً ملفين: Sho3eb-owner.apk (نسختك الكاملة) و Sho3eb-shared.apk (نسخة المشاركة).\n4) لإلغاء نسخة المشاركة احذف مجلد edition.",
                        "1) Tap «Export edition pack» and save it.\n2) Unzip and upload the edition folder to the root of your GitHub repo (next to app).\n3) GitHub Actions builds Sho3eb-owner.apk and Sho3eb-shared.apk.\n4) Delete the edition folder to stop building it."), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        save()
                        val f = Edition.exportPack(ctx)
                        Share.shareFile(ctx, f, "application/zip", null, false)
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Archive, null); Spacer(Modifier.width(6.dp)); Text(tr("تصدير حزمة النسخة", "Export edition pack")) }
                    OutlinedButton(onClick = { save(); nav.navigate("contact") }, modifier = Modifier.fillMaxWidth()) { Text(tr("تعديل بيانات التواصل المضمنة", "Edit embedded contact details")) }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

/** طلب تقييم لطيف */
@Composable
fun RatePrompt() {
    val ctx = LocalContext.current
    var show by remember { mutableStateOf(Edition.shouldAskRating()) }
    if (show) AlertDialog(onDismissRequest = { show = false }, icon = { Icon(Icons.Filled.Star, null) },
        title = { Text(tr("هل أعجبك ", "Enjoying ") + Edition.appName + "?") },
        text = { Text(tr("تقييمك على المتجر يساعدنا كثيراً على التطوير ❤️", "A store rating helps us a lot ❤️")) },
        confirmButton = { TextButton(onClick = { show = false; Edition.rate(ctx) }) { Text(tr("قيّم الآن", "Rate now")) } },
        dismissButton = {
            Row {
                TextButton(onClick = { show = false; Extras.pb("ed_rate_never", true) }) { Text(tr("لا تسألني", "Never")) }
                TextButton(onClick = { show = false }) { Text(tr("لاحقاً", "Later")) }
            }
        })
}
