package com.sho3eb.app.core

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("sho3eb_prefs", Context.MODE_PRIVATE)

    /** تخزين مشفّر لكلمة المرور المحفوظة */
    private val secure: SharedPreferences = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "sho3eb_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        sp
    }

    private fun str(k: String, d: String): String = sp.getString(k, d) ?: d
    private fun putStr(k: String, v: String?) = sp.edit().putString(k, v).apply()

    // -------- الإعدادات --------
    var lang: String
        get() = str("lang", "ar")
        set(v) = putStr("lang", v)
    var theme: String
        get() = str("theme", "system")
        set(v) = putStr("theme", v)
    var currency: String
        get() = str("currency", "ر.س")
        set(v) = putStr("currency", v)
    var countryCode: String
        get() = str("cc", "966")
        set(v) = putStr("cc", v)
    var remindersEnabled: Boolean
        get() = sp.getBoolean("rem", true)
        set(v) = sp.edit().putBoolean("rem", v).apply()
    var remindDaysBefore: Int
        get() = sp.getInt("remDays", 1)
        set(v) = sp.edit().putInt("remDays", v).apply()
    var remindHour: Int
        get() = sp.getInt("remHour", 9)
        set(v) = sp.edit().putInt("remHour", v).apply()
    var biometric: Boolean
        get() = sp.getBoolean("bio", false)
        set(v) = sp.edit().putBoolean("bio", v).apply()
    var rememberMe: Boolean
        get() = sp.getBoolean("rememberMe", true)
        set(v) = sp.edit().putBoolean("rememberMe", v).apply()

    // -------- الحساب --------
    val hasUser: Boolean get() = sp.contains("user")
    val username: String get() = str("user", "")
    var displayName: String
        get() = str("displayName", "")
        set(v) = putStr("displayName", v)
    var phone: String
        get() = str("phone", "")
        set(v) = putStr("phone", v)
    var photoPath: String?
        get() = sp.getString("photo", null)
        set(v) = putStr("photo", v)

    var savedPassword: String?
        get() = secure.getString("pwd", null)
        set(v) {
            if (v == null) secure.edit().remove("pwd").apply() else secure.edit().putString("pwd", v).apply()
        }

    fun register(user: String, pass: String, name: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp.edit()
            .putString("user", user.trim())
            .putString("salt", b64(salt))
            .putString("hash", hash(pass, salt))
            .putString("displayName", name.trim())
            .apply()
    }

    fun setUsername(user: String) = putStr("user", user.trim())

    // -------- البريد الإلكتروني واستعادة كلمة المرور --------
    var email: String
        get() = str("email", "")
        set(v) = putStr("email", v.trim())
    val hasRecovery: Boolean get() = sp.contains("recHash")

    /** يُنشئ رمز استعادة جديد ويحفظ بصمته فقط، ويعيد الرمز ليُرسل إلى البريد */
    fun newRecoveryCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        val code = (1..12).map { chars[r.nextInt(chars.length)] }.joinToString("").chunked(4).joinToString("-")
        val salt = ByteArray(16).also { r.nextBytes(it) }
        sp.edit().putString("recSalt", b64(salt)).putString("recHash", hash(normCode(code), salt)).apply()
        return code
    }

    private fun normCode(c: String) = c.uppercase().filter { it.isLetterOrDigit() }

    fun verifyRecovery(code: String): Boolean {
        if (!hasRecovery) return false
        val salt = Base64.decode(str("recSalt", ""), Base64.NO_WRAP)
        return hash(normCode(code), salt) == str("recHash", "-")
    }

    fun matchesUser(user: String): Boolean {
        val u = user.trim()
        return u.equals(username, ignoreCase = true) || (email.isNotBlank() && u.equals(email, ignoreCase = true))
    }

    fun verify(user: String, pass: String): Boolean {
        if (!matchesUser(user)) return false
        val salt = Base64.decode(str("salt", ""), Base64.NO_WRAP)
        return hash(pass, salt) == str("hash", "-")
    }

    fun setPassword(pass: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp.edit().putString("salt", b64(salt)).putString("hash", hash(pass, salt)).apply()
        if (savedPassword != null) savedPassword = pass
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)

    private fun hash(pass: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pass.toCharArray(), salt, 20000, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return b64(f.generateSecret(spec).encoded)
    }
}
