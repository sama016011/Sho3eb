package com.sho3eb.app.core

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.sho3eb.app.R
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.ui.MainActivity
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    const val CHANNEL = "sho3eb_due"

    fun createChannel(ctx: Context) {
        val ch = NotificationChannel(CHANNEL, tr("تنبيهات المدفوعات", "Payment reminders"), NotificationManager.IMPORTANCE_HIGH)
        ch.description = tr("تذكير بمواعيد الجمعيات والسلف والأقساط", "Association, loan and installment reminders")
        ctx.getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
    }

    fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun show(ctx: Context, id: Int, title: String, text: String) {
        if (!canNotify(ctx)) return
        val intent = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF0F766E.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }
}

/** عامل يومي يفحص المستحقات ويرسل التنبيهات */
class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as Sho3ebApp
        val prefs = app.prefs
        val test = inputData.getBoolean("test", false)
        if (!prefs.remindersEnabled && !test) return Result.success()
        return try {
            val today = LocalDate.now()
            val data = loadAllData(app.db.dao())
            val items = computeDueItems(data, today, prefs.remindDaysBefore, !test)
            if (items.isEmpty() && test) {
                Notifier.show(app, 999, "Sho3eb", tr("التنبيهات تعمل ✅ لا توجد مستحقات حالياً", "Reminders are working ✅ Nothing is due right now"))
            }
            items.take(8).forEachIndexed { i, it ->
                val whenTxt = when {
                    it.due.isBefore(today) -> tr("متأخر منذ ${Fmt.date(it.due)}", "Overdue since ${Fmt.date(it.due)}")
                    it.due == today -> tr("مستحق اليوم", "Due today")
                    else -> tr("مستحق في ${Fmt.date(it.due)}", "Due on ${Fmt.date(it.due)}")
                }
                val kind = when (it.kind) {
                    DueKind.ASSOC -> tr("جمعية", "Association")
                    DueKind.LOAN -> tr("سلفة", "Loan")
                    DueKind.SALE -> tr("قسط", "Installment")
                }
                Notifier.show(app, 1000 + i, "$kind: ${it.title}", "${it.subtitle}\n${Fmt.money(it.amount)} • $whenTxt")
            }
            if (items.size > 8) {
                Notifier.show(app, 1999, "Sho3eb", tr("لديك ${items.size} مستحقات، افتح التطبيق للتفاصيل", "You have ${items.size} due items, open the app for details"))
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val NAME = "sho3eb_reminders"

        fun schedule(ctx: Context, hour: Int) {
            val now = LocalDateTime.now()
            var next = now.toLocalDate().atTime(hour.coerceIn(0, 23), 0)
            if (!next.isAfter(now)) next = next.plusDays(1)
            val delay = Duration.between(now, next).toMinutes()
            val req = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(delay, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun runNow(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<ReminderWorker>().setInputData(workDataOf("test" to true)).build()
            WorkManager.getInstance(ctx).enqueue(req)
        }
    }
}
