package com.sho3eb.app.core

import java.text.Normalizer

/** أسماء الفرق بالعربية: قاموس للفرق الشهيرة + نقل حرفي تلقائي لباقي الأسماء */
object TeamAr {
    private fun key(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        .lowercase().replace("&", " and ").replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private val noise = setOf("fc", "cf", "sc", "afc", "ac", "ssc", "sv", "fk", "sk", "cd", "club", "football", "futbol", "calcio", "1", "sad", "saudi", "egypt", "ksa")

    private val dict: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        fun add(ar: String, vararg en: String) = en.forEach { m[key(it)] = ar }
        // ===== مصر =====
        add("الأهلي", "Al Ahly", "Al-Ahly", "Ahly", "Al Ahly SC", "Al Ahly Cairo")
        add("الزمالك", "Zamalek", "Zamalek SC", "El Zamalek")
        add("بيراميدز", "Pyramids", "Pyramids FC")
        add("المصري", "Al Masry", "El Masry", "Al-Masry")
        add("الإسماعيلي", "Ismaily", "Ismaily SC", "El Ismaily")
        add("إنبي", "ENPPI", "Enppi")
        add("سموحة", "Smouha", "Smouha SC")
        add("مودرن سبورت", "Modern Sport", "Modern Sport FC", "Future FC", "Modern Future")
        add("سيراميكا كليوباترا", "Ceramica Cleopatra", "Ceramica Cleopatra FC")
        add("الاتحاد السكندري", "Al Ittihad Alexandria", "Ittihad Alexandria", "Al Ittihad Al Sakandary", "El Ittihad Alexandria")
        add("طلائع الجيش", "Tala'ea El Gaish", "Talaea El Gaish", "Tala'ea El-Gaish", "El Geish")
        add("الجونة", "El Gouna", "El Gouna FC", "Gouna")
        add("غزل المحلة", "Ghazl El Mahalla", "Ghazl El-Mahalla", "Ghazl El Mehalla")
        add("فاركو", "Pharco", "Pharco FC")
        add("البنك الأهلي", "National Bank of Egypt", "National Bank", "NBE")
        add("زد", "ZED", "ZED FC")
        add("بتروجت", "Petrojet")
        add("حرس الحدود", "Haras El Hodoud", "Haras El-Hodoud")
        add("المقاولون العرب", "Arab Contractors", "El Mokawloon", "Al Mokawloon Al Arab", "El Mokawloon El Arab")
        add("وادي دجلة", "Wadi Degla", "Wadi Degla FC")
        add("كهرباء الإسماعيلية", "Kahraba Ismailia", "Kahrabaa Ismailia")
        add("الداخلية", "El Dakhleya", "El Daklyeh", "Al Dakhleya")
        add("أسوان", "Aswan", "Aswan SC")
        add("المصرية للاتصالات", "Telecom Egypt", "Telephonat Beni Suef")
        add("الإنتاج الحربي", "El Entag El Harby", "Military Production")
        add("بلدية المحلة", "Baladiyat El Mahalla", "Baladeyet El Mahalla")
        add("سموحة", "Smouha")
        add("الترسانة", "Tersana")
        add("الأوليمبي", "Olympic Club")
        // ===== السعودية =====
        add("الهلال", "Al Hilal", "Al-Hilal", "Al Hilal SFC", "Al-Hilal Saudi")
        add("النصر", "Al Nassr", "Al-Nassr", "Al Nasr")
        add("الاتحاد", "Al Ittihad", "Al-Ittihad", "Al Ittihad Jeddah", "Al-Ittihad Club")
        add("الأهلي السعودي", "Al Ahli", "Al-Ahli", "Al Ahli Saudi", "Al-Ahli Saudi", "Al Ahli Jeddah")
        add("الشباب", "Al Shabab", "Al-Shabab")
        add("الاتفاق", "Al Ettifaq", "Al-Ettifaq", "Al Ittifaq")
        add("التعاون", "Al Taawoun", "Al-Taawoun", "Al Taawon")
        add("الفتح", "Al Fateh", "Al-Fateh")
        add("الفيحاء", "Al Fayha", "Al-Fayha", "Al Feiha")
        add("الرائد", "Al Raed", "Al-Raed")
        add("الخليج", "Al Khaleej", "Al-Khaleej")
        add("الرياض", "Al Riyadh", "Al-Riyadh")
        add("الوحدة", "Al Wehda", "Al-Wehda", "Al Wahda")
        add("ضمك", "Damac", "Damac FC", "Dhamk")
        add("الأخدود", "Al Okhdood", "Al-Okhdood", "Al Akhdoud", "Al-Akhdoud")
        add("الخلود", "Al Kholood", "Al-Kholood")
        add("القادسية", "Al Qadsiah", "Al-Qadsiah", "Al Qadisiyah")
        add("العروبة", "Al Orobah", "Al-Orobah", "Al Orubah")
        add("نيوم", "Neom", "NEOM SC")
        add("النجمة", "Al Najma", "Al-Najma")
        add("الحزم", "Al Hazem", "Al-Hazem", "Al Hazm")
        add("الطائي", "Al Tai", "Al-Taee", "Al Taee")
        add("أبها", "Abha")
        add("الباطن", "Al Batin", "Al-Batin")
        add("العين", "Al Ain")
        add("الوصل", "Al Wasl")
        add("شباب الأهلي", "Shabab Al Ahli", "Shabab Al-Ahli")
        add("الشارقة", "Sharjah", "Al Sharjah")
        add("الجزيرة", "Al Jazira")
        add("السد", "Al Sadd")
        add("الدحيل", "Al Duhail", "Al-Duhail")
        add("الريان", "Al Rayyan")
        add("الغرافة", "Al Gharafa")
        add("الوداد", "Wydad", "Wydad Casablanca", "Wydad AC")
        add("الرجاء", "Raja", "Raja Casablanca", "Raja CA")
        add("الترجي", "Esperance", "Esperance Tunis", "Esperance de Tunis", "ES Tunis")
        add("النجم الساحلي", "Etoile du Sahel", "Etoile Sahel")
        add("صن داونز", "Mamelodi Sundowns", "Sundowns")
        add("مولودية الجزائر", "MC Alger", "Mouloudia Alger")
        add("شباب بلوزداد", "CR Belouizdad", "Belouizdad")
        // ===== إنجلترا =====
        add("مانشستر سيتي", "Manchester City", "Man City")
        add("مانشستر يونايتد", "Manchester United", "Man United", "Man Utd")
        add("ليفربول", "Liverpool")
        add("أرسنال", "Arsenal")
        add("تشيلسي", "Chelsea")
        add("توتنهام", "Tottenham", "Tottenham Hotspur", "Spurs")
        add("نيوكاسل", "Newcastle", "Newcastle United")
        add("أستون فيلا", "Aston Villa")
        add("وست هام", "West Ham", "West Ham United")
        add("برايتون", "Brighton", "Brighton and Hove Albion", "Brighton & Hove Albion")
        add("إيفرتون", "Everton")
        add("فولهام", "Fulham")
        add("برينتفورد", "Brentford")
        add("كريستال بالاس", "Crystal Palace")
        add("وولفرهامبتون", "Wolves", "Wolverhampton", "Wolverhampton Wanderers")
        add("بورنموث", "Bournemouth", "AFC Bournemouth")
        add("نوتنغهام فورست", "Nottingham Forest", "Nott'm Forest")
        add("ليستر سيتي", "Leicester", "Leicester City")
        add("ساوثهامبتون", "Southampton")
        add("إيبسويتش", "Ipswich", "Ipswich Town")
        add("ليدز يونايتد", "Leeds", "Leeds United")
        add("بيرنلي", "Burnley")
        add("سندرلاند", "Sunderland")
        add("شيفيلد يونايتد", "Sheffield United", "Sheffield Utd")
        add("لوتون", "Luton", "Luton Town")
        add("واتفورد", "Watford")
        add("نوريتش", "Norwich", "Norwich City")
        add("وست بروميتش", "West Brom", "West Bromwich Albion")
        // ===== إسبانيا =====
        add("ريال مدريد", "Real Madrid")
        add("برشلونة", "Barcelona", "FC Barcelona", "Barca")
        add("أتلتيكو مدريد", "Atletico Madrid", "Atlético Madrid", "Atletico de Madrid", "Atlético de Madrid")
        add("إشبيلية", "Sevilla", "Sevilla FC")
        add("ريال بيتيس", "Real Betis", "Betis")
        add("ريال سوسيداد", "Real Sociedad")
        add("فياريال", "Villarreal")
        add("أتلتيك بلباو", "Athletic Club", "Athletic Bilbao")
        add("فالنسيا", "Valencia")
        add("جيرونا", "Girona")
        add("سيلتا فيغو", "Celta Vigo", "Celta")
        add("أوساسونا", "Osasuna", "CA Osasuna")
        add("خيتافي", "Getafe")
        add("رايو فاييكانو", "Rayo Vallecano")
        add("مايوركا", "Mallorca", "RCD Mallorca")
        add("ألافيس", "Alaves", "Alavés", "Deportivo Alaves")
        add("لاس بالماس", "Las Palmas", "UD Las Palmas")
        add("إسبانيول", "Espanyol", "RCD Espanyol")
        add("ليغانيس", "Leganes", "Leganés")
        add("بلد الوليد", "Real Valladolid", "Valladolid")
        add("ليفانتي", "Levante")
        add("إلتشي", "Elche")
        add("ريال أوفييدو", "Real Oviedo", "Oviedo")
        add("قادش", "Cadiz", "Cádiz")
        add("غرناطة", "Granada")
        add("ألميريا", "Almeria", "Almería")
        // ===== إيطاليا =====
        add("يوفنتوس", "Juventus")
        add("إنتر ميلان", "Inter", "Inter Milan", "Internazionale")
        add("ميلان", "AC Milan", "Milan")
        add("نابولي", "Napoli")
        add("روما", "Roma", "AS Roma")
        add("لاتسيو", "Lazio")
        add("أتالانتا", "Atalanta")
        add("فيورنتينا", "Fiorentina")
        add("بولونيا", "Bologna")
        add("تورينو", "Torino")
        add("جنوى", "Genoa")
        add("أودينيزي", "Udinese")
        add("ساسولو", "Sassuolo")
        add("كالياري", "Cagliari")
        add("ليتشي", "Lecce")
        add("إمبولي", "Empoli")
        add("مونزا", "Monza")
        add("فيرونا", "Verona", "Hellas Verona")
        add("كومو", "Como")
        add("بارما", "Parma")
        add("فينيسيا", "Venezia")
        add("كريمونيزي", "Cremonese")
        add("بيزا", "Pisa")
        add("ساليرنيتانا", "Salernitana")
        add("سامبدوريا", "Sampdoria")
        // ===== ألمانيا =====
        add("بايرن ميونخ", "Bayern Munich", "Bayern München", "FC Bayern Munich", "Bayern")
        add("بوروسيا دورتموند", "Borussia Dortmund", "Dortmund")
        add("باير ليفركوزن", "Bayer Leverkusen", "Leverkusen")
        add("لايبزيغ", "RB Leipzig", "Leipzig")
        add("شتوتغارت", "Stuttgart", "VfB Stuttgart")
        add("آينتراخت فرانكفورت", "Eintracht Frankfurt", "Frankfurt")
        add("فولفسبورغ", "Wolfsburg", "VfL Wolfsburg")
        add("بوروسيا مونشنغلادباخ", "Borussia Monchengladbach", "Borussia Mönchengladbach", "Gladbach")
        add("فرايبورغ", "Freiburg", "SC Freiburg")
        add("هوفنهايم", "Hoffenheim", "TSG Hoffenheim")
        add("فيردر بريمن", "Werder Bremen")
        add("ماينز", "Mainz", "Mainz 05", "FSV Mainz 05")
        add("أوغسبورغ", "Augsburg", "FC Augsburg")
        add("يونيون برلين", "Union Berlin", "1. FC Union Berlin")
        add("بوخوم", "Bochum", "VfL Bochum")
        add("هايدنهايم", "Heidenheim", "1. FC Heidenheim")
        add("سانت باولي", "St. Pauli", "St Pauli", "FC St. Pauli")
        add("هولشتاين كيل", "Holstein Kiel")
        add("كولن", "FC Koln", "Köln", "FC Köln", "Cologne")
        add("هامبورغ", "Hamburg", "Hamburger SV")
        add("شالكه", "Schalke", "Schalke 04")
        add("هيرتا برلين", "Hertha Berlin", "Hertha BSC")
        // ===== فرنسا =====
        add("باريس سان جيرمان", "Paris Saint-Germain", "Paris Saint Germain", "PSG", "Paris SG")
        add("مارسيليا", "Marseille", "Olympique Marseille")
        add("ليون", "Lyon", "Olympique Lyonnais")
        add("موناكو", "Monaco", "AS Monaco")
        add("ليل", "Lille", "LOSC Lille")
        add("نيس", "Nice", "OGC Nice")
        add("لانس", "Lens", "RC Lens")
        add("رين", "Rennes", "Stade Rennais")
        add("ستراسبورغ", "Strasbourg", "RC Strasbourg")
        add("نانت", "Nantes", "FC Nantes")
        add("تولوز", "Toulouse")
        add("مونبلييه", "Montpellier")
        add("ريمس", "Reims", "Stade de Reims")
        add("بريست", "Brest", "Stade Brestois")
        add("أوكسير", "Auxerre", "AJ Auxerre")
        add("أنجيه", "Angers", "Angers SCO")
        add("لوهافر", "Le Havre")
        add("سانت إتيان", "Saint-Etienne", "Saint-Étienne", "St Etienne")
        add("لوريان", "Lorient")
        add("ميتز", "Metz")
        add("باريس إف سي", "Paris FC")
        // ===== أخرى =====
        add("أياكس", "Ajax", "AFC Ajax")
        add("بي إس في آيندهوفن", "PSV", "PSV Eindhoven")
        add("فينورد", "Feyenoord")
        add("بنفيكا", "Benfica", "SL Benfica")
        add("بورتو", "Porto", "FC Porto")
        add("سبورتنغ لشبونة", "Sporting CP", "Sporting Lisbon", "Sporting")
        add("براغا", "Braga", "SC Braga")
        add("سيلتيك", "Celtic")
        add("رينجرز", "Rangers")
        add("غلطة سراي", "Galatasaray")
        add("فنربخشة", "Fenerbahce", "Fenerbahçe")
        add("بشكتاش", "Besiktas", "Beşiktaş")
        add("طرابزون سبور", "Trabzonspor")
        add("كلوب بروج", "Club Brugge", "Club Bruges")
        add("أندرلخت", "Anderlecht")
        add("شاختار دونيتسك", "Shakhtar Donetsk", "Shakhtar")
        add("دينامو زغرب", "Dinamo Zagreb")
        add("سالزبورغ", "Red Bull Salzburg", "Salzburg")
        add("سلافيا براغ", "Slavia Prague", "Slavia Praha")
        add("سبارتا براغ", "Sparta Prague")
        add("يونغ بويز", "Young Boys", "BSC Young Boys")
        add("النجم الأحمر", "Red Star Belgrade", "Crvena Zvezda")
        add("إنتر ميامي", "Inter Miami", "Inter Miami CF")
        add("لوس أنجلوس غالاكسي", "LA Galaxy")
        add("بوكا جونيورز", "Boca Juniors")
        add("ريفر بليت", "River Plate")
        add("فلامنغو", "Flamengo")
        add("بالميراس", "Palmeiras")
        // ===== منتخبات =====
        add("مصر", "Egypt"); add("السعودية", "Saudi Arabia"); add("المغرب", "Morocco"); add("الجزائر", "Algeria"); add("تونس", "Tunisia")
        add("قطر", "Qatar"); add("الإمارات", "United Arab Emirates", "UAE"); add("الأردن", "Jordan"); add("العراق", "Iraq"); add("الكويت", "Kuwait")
        add("عمان", "Oman"); add("البحرين", "Bahrain"); add("لبنان", "Lebanon"); add("سوريا", "Syria"); add("فلسطين", "Palestine"); add("ليبيا", "Libya")
        add("السودان", "Sudan"); add("اليمن", "Yemen"); add("موريتانيا", "Mauritania")
        add("البرازيل", "Brazil"); add("الأرجنتين", "Argentina"); add("فرنسا", "France"); add("إنجلترا", "England"); add("ألمانيا", "Germany")
        add("إسبانيا", "Spain"); add("إيطاليا", "Italy"); add("البرتغال", "Portugal"); add("هولندا", "Netherlands"); add("بلجيكا", "Belgium")
        add("كرواتيا", "Croatia"); add("أوروغواي", "Uruguay"); add("كولومبيا", "Colombia"); add("المكسيك", "Mexico"); add("الولايات المتحدة", "USA", "United States")
        add("اليابان", "Japan"); add("كوريا الجنوبية", "South Korea", "Korea Republic"); add("أستراليا", "Australia"); add("إيران", "Iran")
        add("السنغال", "Senegal"); add("نيجيريا", "Nigeria"); add("الكاميرون", "Cameroon"); add("غانا", "Ghana"); add("كوت ديفوار", "Ivory Coast", "Cote d'Ivoire")
        add("تركيا", "Turkey", "Türkiye"); add("سويسرا", "Switzerland"); add("الدنمارك", "Denmark"); add("بولندا", "Poland"); add("صربيا", "Serbia")
        add("النمسا", "Austria"); add("السويد", "Sweden"); add("النرويج", "Norway"); add("اسكتلندا", "Scotland"); add("ويلز", "Wales")
        add("كندا", "Canada"); add("الإكوادور", "Ecuador"); add("تشيلي", "Chile"); add("بيرو", "Peru"); add("جنوب أفريقيا", "South Africa")
        m
    }

    /** كلمات شائعة داخل أسماء الفرق */
    private val words = mapOf(
        "united" to "يونايتد", "city" to "سيتي", "real" to "ريال", "athletic" to "أتلتيك", "atletico" to "أتلتيكو", "sporting" to "سبورتنغ", "town" to "تاون",
        "rovers" to "روفرز", "wanderers" to "واندررز", "albion" to "ألبيون", "county" to "كاونتي", "saint" to "سانت", "st" to "سانت", "inter" to "إنتر",
        "olympique" to "أولمبيك", "olympic" to "أولمبيك", "racing" to "راسينغ", "deportivo" to "ديبورتيفو", "dynamo" to "دينامو", "dinamo" to "دينامو",
        "borussia" to "بوروسيا", "eintracht" to "آينتراخت", "union" to "يونيون", "stade" to "ستاد", "de" to "دي", "la" to "لا", "le" to "لو", "el" to "ال",
        "al" to "ال", "and" to "و", "young" to "يونغ", "boys" to "بويز", "star" to "ستار", "red" to "ريد", "national" to "الوطني", "women" to "(سيدات)",
        "u23" to "تحت 23", "u21" to "تحت 21", "u20" to "تحت 20", "u19" to "تحت 19", "u17" to "تحت 17", "ii" to "الثاني", "b" to "ب"
    )

    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** الاسم المعروض: عربي عند اختيار العربية، وإلا الاسم الأصلي */
    fun name(en: String): String {
        if (en.isBlank() || AppState.lang.value != "ar") return en
        if (en.any { it in '؀'..'ۿ' }) return en
        return cache.getOrPut(en) { lookup(en) }
    }

    private fun lookup(en: String): String {
        val k = key(en)
        dict[k]?.let { return it }
        val parts = k.split(" ").filter { it !in noise }
        val k2 = parts.joinToString(" ")
        dict[k2]?.let { return it }
        // "Al X" ↔ "Al-X"
        dict[k2.replace("al ", "al")]?.let { return it }
        // تطابق جزئي مع أسماء القاموس الطويلة
        if (k2.length >= 5) dict.entries.firstOrNull { (kk, _) -> kk.length >= 5 && (kk == k2 || (k2.startsWith(kk) && k2.length - kk.length <= 4)) }?.let { return it.value }
        return translit(parts)
    }

    private fun translit(parts: List<String>): String {
        val out = StringBuilder()
        var i = 0
        while (i < parts.size) {
            val w = parts[i]
            val ar = words[w] ?: if (w.all { it.isDigit() }) w else word(w)
            if (ar == "ال" && i + 1 < parts.size) { out.append(if (out.isNotEmpty()) " " else "").append("ال").append(words[parts[i + 1]] ?: word(parts[i + 1])); i += 2; continue }
            if (out.isNotEmpty()) out.append(' ')
            out.append(ar); i++
        }
        return out.toString().ifBlank { parts.joinToString(" ") }
    }

    private val di = listOf("sch" to "ش", "tch" to "تش", "sh" to "ش", "ch" to "تش", "th" to "ث", "kh" to "خ", "gh" to "غ", "ph" to "ف", "ck" to "ك", "qu" to "كو",
        "ou" to "و", "oo" to "و", "ee" to "ي", "ie" to "ي", "ei" to "اي", "ai" to "اي", "ay" to "اي", "au" to "او", "ll" to "ل", "ss" to "س", "tt" to "ت", "ff" to "ف", "rr" to "ر", "nn" to "ن", "mm" to "م", "pp" to "ب", "zz" to "تس")
    private val single = mapOf('b' to "ب", 'c' to "ك", 'd' to "د", 'f' to "ف", 'g' to "غ", 'h' to "ه", 'j' to "ج", 'k' to "ك", 'l' to "ل", 'm' to "م", 'n' to "ن",
        'p' to "ب", 'q' to "ك", 'r' to "ر", 's' to "س", 't' to "ت", 'v' to "ف", 'w' to "و", 'x' to "كس", 'z' to "ز", 'a' to "ا", 'e' to "ي", 'i' to "ي", 'o' to "و", 'u' to "و", 'y' to "ي")

    /** نقل حرفي تقريبي لكلمة لاتينية */
    private fun word(w0: String): String {
        if (w0.isBlank()) return ""
        var w = w0
        if (w.length > 3 && w.endsWith("e") && w[w.length - 2] !in "aeiou") w = w.dropLast(1)
        val sb = StringBuilder()
        var i = 0
        while (i < w.length) {
            val d = di.firstOrNull { w.startsWith(it.first, i) }
            if (d != null) { sb.append(d.second); i += d.first.length; continue }
            val c = w[i]
            if (i == 0 && c in "aeiou") sb.append(when (c) { 'a' -> "أ"; 'e', 'i' -> "إي"; else -> "أو" })
            else sb.append(single[c] ?: c.toString())
            i++
        }
        return sb.toString().replace(Regex("([اوي])\\1+"), "$1")
    }
}
