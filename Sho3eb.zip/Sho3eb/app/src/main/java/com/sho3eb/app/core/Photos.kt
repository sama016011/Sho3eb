package com.sho3eb.app.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object Photos {
    /** نسخ صورة من أي مصدر (المعرض، الملفات، Google Photos، HEIC…) مع تصغيرها وتصحيح دورانها */
    fun copyFromUri(ctx: Context, uri: Uri, max: Int = 512): String? {
        val bmp = decode(ctx, uri, max) ?: return null
        return try {
            val dir = File(ctx.filesDir, "photos").apply { mkdirs() }
            val f = File(dir, "${UUID.randomUUID()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            f.absolutePath
        } catch (e: Throwable) { null }
    }

    private fun decode(ctx: Context, uri: Uri, max: Int): Bitmap? {
        // 1) ImageDecoder: يدعم HEIC/HEIF و WebP ويطبق الدوران تلقائياً
        if (android.os.Build.VERSION.SDK_INT >= 28) runCatching {
            val src = android.graphics.ImageDecoder.createSource(ctx.contentResolver, uri)
            return android.graphics.ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width; val h = info.size.height
                val sc = minOf(1f, max.toFloat() / maxOf(w, h).coerceAtLeast(1))
                if (sc < 1f) dec.setTargetSize((w * sc).toInt().coerceAtLeast(1), (h * sc).toInt().coerceAtLeast(1))
            }
        }
        // 2) BitmapFactory مع نسخة مؤقتة (بعض المصادر لا تسمح بالقراءة مرتين)
        return try {
            val tmp = File(ctx.cacheDir, "pick_${System.nanoTime()}")
            ctx.contentResolver.openInputStream(uri)?.use { i -> FileOutputStream(tmp).use { i.copyTo(it) } } ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(tmp.path, bounds)
            var sample = 1
            while (bounds.outWidth / sample > max * 2 || bounds.outHeight / sample > max * 2) sample *= 2
            var b = BitmapFactory.decodeFile(tmp.path, BitmapFactory.Options().apply { inSampleSize = sample })
            if (b != null) {
                val rot = runCatching {
                    when (android.media.ExifInterface(tmp.path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                        6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                    }
                }.getOrDefault(0f)
                val sc = minOf(1f, max.toFloat() / maxOf(b.width, b.height))
                if (rot != 0f || sc < 1f) {
                    val m = android.graphics.Matrix().apply { postScale(sc, sc); postRotate(rot) }
                    b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
                }
            }
            tmp.delete()
            b
        } catch (e: Throwable) { null }
    }

    fun load(path: String, max: Int = 256): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > max * 2 || bounds.outHeight / sample > max * 2) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }
}
