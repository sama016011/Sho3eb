@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.app.KeyguardManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlarmOff
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sho3eb.app.core.AlarmRingService
import com.sho3eb.app.core.Ringing
import com.sho3eb.app.core.tr
import kotlinx.coroutines.delay

/** شاشة المنبه: تظهر فوق كل شيء وفوق قفل الشاشة */
class AlarmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
            runCatching { getSystemService(KeyguardManager::class.java).requestDismissKeyguard(this, null) }
        }
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        setContent { AlarmContent(onDismiss = { AlarmRingService.dismiss(this); finish() }, onSnooze = { AlarmRingService.snooze(this); finish() }, onGone = { finish() }) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* لا يُغلق بالرجوع: يجب الضغط على إيقاف أو تأجيل */ }
}

@Composable
private fun AlarmContent(onDismiss: () -> Unit, onSnooze: () -> Unit, onGone: () -> Unit) {
    val info = Ringing.current.value
    var seen by remember { mutableStateOf(false) }
    LaunchedEffect(info) { if (info != null) seen = true else { delay(400); if (seen || Ringing.current.value == null) onGone() } }
    var now by remember { mutableStateOf(java.time.LocalTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = java.time.LocalTime.now(); delay(1000) } }
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(1f, 1.12f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s")
    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B3D3A), Color(0xFF0F766E), Color(0xFF134E4A)))), contentAlignment = Alignment.Center) {
            Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(String.format(java.util.Locale.US, "%02d:%02d", now.hour, now.minute), color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light)
                Box(Modifier.size(120.dp).scale(pulse).background(Color.White.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) { Text("⏰", fontSize = 60.sp) }
                Text(info?.title?.ifBlank { info.schedule } ?: tr("منبه", "Alarm"), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                if (info != null) Text(info.schedule, color = Color.White.copy(alpha = 0.85f), fontSize = 18.sp)
                if (!info?.note.isNullOrBlank()) Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.12f))) {
                    Text(info!!.note, Modifier.padding(16.dp), color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(24.dp))
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))) {
                    Icon(Icons.Filled.AlarmOff, null); Spacer(Modifier.width(8.dp)); Text(tr("إيقاف المنبه", "Dismiss"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = onSnooze, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                    Icon(Icons.Filled.Snooze, null, tint = Color.White); Spacer(Modifier.width(8.dp))
                    Text(tr("تأجيل ${info?.snooze ?: 10} دقيقة", "Snooze ${info?.snooze ?: 10} min"), color = Color.White, fontSize = 18.sp)
                }
            }
        }
    }
}
