package com.sho3eb.app.core

import androidx.compose.runtime.mutableIntStateOf

/** تخصيص الواجهة الرئيسية: ترتيب الأقسام والأيقونات وإظهارها وإخفاؤها */
object HomeLayout {
    data class Section(val id: String, val ar: String, val en: String, val emoji: String) { val label get() = tr(ar, en) }
    data class Shortcut(val id: String, val ar: String, val en: String, val emoji: String, val route: String) { val label get() = tr(ar, en) }

    /** يزداد عند أي تعديل لإعادة رسم الرئيسية */
    val version = mutableIntStateOf(0)

    val sections = listOf(
        Section("header", "بطاقة الترحيب", "Welcome card", "👋"),
        Section("prayer", "الصلاة القادمة", "Next prayer", "🕌"),
        Section("football", "مباراة فريقي", "My team's match", "⚽"),
        Section("stats", "ملخص الأرقام", "Key numbers", "📊"),
        Section("quick", "إجراءات سريعة", "Quick actions", "⚡"),
        Section("shortcuts", "أيقونات الأقسام", "Section icons", "🔲"),
        Section("living", "مصاريف الشهر", "This month's spending", "🧾"),
        Section("occasion", "المناسبة القادمة", "Next occasion", "🌙"),
        Section("due", "المستحقات القريبة", "Upcoming dues", "📅")
    )

    val shortcuts = listOf(
        Shortcut("dashboard", "اللوحة المالية", "Dashboard", "📈", "dashboard"),
        Shortcut("football", "كرة القدم", "Football", "⚽", "football"),
        Shortcut("media", "شاشة العرض", "Media screen", "🎬", "media"),
        Shortcut("media_tools", "محرر الفيديو", "Video editor", "✂️", "media_tools"),
        Shortcut("props", "العقارات", "Properties", "🏢", "props"),
        Shortcut("debts", "ديوني", "My debts", "💳", "debts"),
        Shortcut("workers", "العمال", "Workers", "👷", "workers"),
        Shortcut("assets", "الأصول والذهب", "Assets & gold", "💎", "assets"),
        Shortcut("splits", "تقسيم المصاريف", "Split", "👥", "splits"),
        Shortcut("cars", "السيارة", "Car", "🚗", "cars"),
        Shortcut("subs", "الاشتراكات", "Subscriptions", "🔁", "subs"),
        Shortcut("shop", "المحل", "Shop", "🏪", "shop"),
        Shortcut("vault", "المستندات", "Documents", "🗂️", "vault"),
        Shortcut("advisor", "المستشار", "Advisor", "🧠", "advisor"),
        Shortcut("grocery", "دفتر البقالة", "Credit book", "📒", "grocery"),
        Shortcut("recipes", "الوصفات", "Recipes", "🍲", "recipes"),
        Shortcut("diabetes", "السكري", "Diabetes", "🩸", "diabetes"),
        Shortcut("design", "التصميم", "Design", "🛋️", "design"),
        Shortcut("living", "المعيشة", "Living", "🧾", "living"),
        Shortcut("accounts", "الحسابات", "Accounts", "🏦", "accounts"),
        Shortcut("assocs", "الجمعيات", "Associations", "🤝", "assocs"),
        Shortcut("loans", "السلف", "Loans", "💵", "loans"),
        Shortcut("sales", "التقسيط", "Installments", "🛒", "sales"),
        Shortcut("people", "جهات الاتصال", "Contacts", "📇", "people"),
        Shortcut("zakat", "الزكاة", "Zakat", "🤲", "zakat"),
        Shortcut("faraid", "المواريث", "Inheritance", "⚖️", "faraid"),
        Shortcut("search", "البحث", "Search", "🔍", "search"),
        Shortcut("quran", "القرآن", "Quran", "📖", "quran"),
        Shortcut("azkar", "الأذكار", "Azkar", "📿", "azkar"),
        Shortcut("prayer", "مواقيت الصلاة", "Prayer times", "🕌", "prayer"),
        Shortcut("qibla", "القبلة", "Qibla", "🧭", "qibla"),
        Shortcut("tasbeeh", "السبحة", "Tasbeeh", "📿", "tasbeeh"),
        Shortcut("chat", "التواصل", "Chat", "💬", "chat"),
        Shortcut("alarms", "المنبه والمواعيد", "Alarms & schedules", "⏰", "alarms"),
        Shortcut("fx", "العملات الأجنبية", "Foreign currencies", "💱", "fx"),
        Shortcut("learn", "التعلم والترجمة", "Learn & translate", "🌐", "learn"),
        Shortcut("contact", "تواصل معنا", "Contact us", "📞", "contact"),
        Shortcut("settings", "الإعدادات", "Settings", "⚙️", "settings")
    )
    private val defaultHiddenShortcuts = setOf("contact", "living", "accounts", "assocs", "loans", "sales", "people", "zakat", "faraid", "search", "quran", "azkar", "prayer", "qibla", "tasbeeh", "settings", "diabetes", "fx")

    private fun order(key: String, all: List<String>): List<String> {
        val saved = Extras.s(key, "").split(",").filter { it.isNotBlank() && it in all }
        return saved + all.filter { it !in saved }
    }
    private fun hidden(key: String, def: Set<String>): Set<String> {
        val v = Extras.s(key, "\u0000")
        return if (v == "\u0000") def else v.split(",").filter { it.isNotBlank() }.toSet()
    }

    private fun secAllowed(id: String) = when (id) {
        "prayer" -> Edition.allows("islam") || Edition.allows("prayer")
        "football" -> Edition.allows("football")
        "living" -> Edition.allows("living")
        "occasion" -> Edition.allows("islam")
        else -> true
    }
    fun sectionOrder(): List<Section> = order("home_sec_order", sections.map { it.id }).mapNotNull { id -> sections.firstOrNull { it.id == id } }.filter { secAllowed(it.id) }
    fun hiddenSections(): Set<String> = hidden("home_sec_hidden", emptySet())
    fun shortcutOrder(): List<Shortcut> = order("home_sc_order", shortcuts.map { it.id }).mapNotNull { id -> shortcuts.firstOrNull { it.id == id } }
        .filter { it.id == "settings" || it.id == "contact" || Edition.allows(it.id) }
    fun hiddenShortcuts(): Set<String> {
        // ترحيل لمرة واحدة: إخفاء السكري والعملات من الرئيسية افتراضياً
        if (!Extras.b("home_mig_dfx", false)) {
            Extras.pb("home_mig_dfx", true)
            val v = Extras.s("home_sc_hidden", "\u0000")
            if (v != "\u0000") Extras.ps("home_sc_hidden", (v.split(",") + listOf("diabetes", "fx")).filter { it.isNotBlank() }.distinct().joinToString(","))
        }
        return hidden("home_sc_hidden", defaultHiddenShortcuts)
    }
    fun visibleSections() = hiddenSections().let { h -> sectionOrder().filter { it.id !in h } }
    fun visibleShortcuts() = hiddenShortcuts().let { h -> shortcutOrder().filter { it.id !in h } }

    var columns: Int get() = Extras.i("home_cols", 5); set(v) { Extras.pi("home_cols", v); version.intValue++ }
    var compact: Boolean get() = Extras.b("home_compact", false); set(v) { Extras.pb("home_compact", v); version.intValue++ }

    fun save(secOrder: List<String>, secHidden: Set<String>, scOrder: List<String>, scHidden: Set<String>) {
        Extras.ps("home_sec_order", secOrder.joinToString(","))
        Extras.ps("home_sec_hidden", secHidden.joinToString(","))
        Extras.ps("home_sc_order", scOrder.joinToString(","))
        Extras.ps("home_sc_hidden", scHidden.joinToString(","))
        version.intValue++
    }

    fun reset() {
        listOf("home_sec_order", "home_sc_order").forEach { Extras.ps(it, "") }
        Extras.ps("home_sec_hidden", ""); Extras.ps("home_sc_hidden", defaultHiddenShortcuts.joinToString(","))
        Extras.pi("home_cols", 5); Extras.pb("home_compact", false)
        version.intValue++
    }
}
