package com.sho3eb.app.core.chat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import android.util.Base64
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import com.sho3eb.app.R
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.core.Extras
import com.sho3eb.app.core.MediaTools
import com.sho3eb.app.core.Share
import com.sho3eb.app.core.tr
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.OffsetDateTime
import java.util.UUID

/** قسم التواصل: الأصدقاء، المحادثات المشفرة، الملفات، المجموعات، الحالة، الإشعارات */
object Chat {
    // ======================= النماذج =======================
    data class Profile(val id: String, val phone: String, val name: String, val avatar: String, val about: String, val pubkey: String, val lastSeen: Long) {
        val online get() = System.currentTimeMillis() - lastSeen < 75_000
        fun json() = JSONObject().put("id", id).put("phone", phone).put("name", name).put("avatar", avatar).put("about", about).put("pubkey", pubkey).put("ls", lastSeen)
        companion object {
            private fun JSONObject.str(k: String) = optString(k).takeIf { it != "null" } ?: ""
            fun from(o: JSONObject) = Profile(o.str("id"), o.str("phone"), o.str("name"), o.str("avatar"), o.str("about"), o.str("pubkey"),
                if (o.has("ls")) o.optLong("ls") else ts(o.optString("last_seen")))
        }
    }

    /** kind: text, image, video, audio, file, location, contact, call, sticker */
    data class Content(
        val kind: String = "text", val text: String = "", val name: String = "", val size: Long = 0, val mime: String = "", val path: String = "", val fkey: String = "",
        val dur: Long = 0, val lat: Double = 0.0, val lng: Double = 0.0, val cname: String = "", val cphone: String = "", val thumb: String = "",
        val lang: String = "", val orig: String = "", val mentions: List<String> = emptyList(), val video: Boolean = false, val missed: Boolean = false, val fwd: Boolean = false
    ) {
        fun json(): JSONObject = JSONObject().put("k", kind).apply {
            if (text.isNotEmpty()) put("t", text); if (name.isNotEmpty()) put("n", name); if (size > 0) put("s", size); if (mime.isNotEmpty()) put("m", mime)
            if (path.isNotEmpty()) put("p", path); if (fkey.isNotEmpty()) put("fk", fkey); if (dur > 0) put("d", dur); if (lat != 0.0) put("la", lat); if (lng != 0.0) put("lo", lng)
            if (cname.isNotEmpty()) put("cn", cname); if (cphone.isNotEmpty()) put("cp", cphone); if (thumb.isNotEmpty()) put("th", thumb); if (lang.isNotEmpty()) put("lg", lang)
            if (orig.isNotEmpty()) put("o", orig); if (mentions.isNotEmpty()) put("me", JSONArray(mentions)); if (video) put("v", true); if (missed) put("mi", true); if (fwd) put("fw", true)
        }
        val preview: String get() = when (kind) {
            "image" -> "📷 " + tr("صورة", "Photo") + if (text.isNotBlank()) " • $text" else ""
            "video" -> "🎬 " + tr("فيديو", "Video") + if (text.isNotBlank()) " • $text" else ""
            "audio" -> "🎤 " + tr("رسالة صوتية", "Voice message")
            "file" -> "📎 " + name
            "location" -> "📍 " + tr("الموقع", "Location")
            "contact" -> "👤 " + cname
            "call" -> (if (video) "📹 " else "📞 ") + if (missed) tr("مكالمة فائتة", "Missed call") else tr("مكالمة", "Call")
            "pin" -> if (missed) tr("📌 ألغى تثبيت رسالة", "📌 Unpinned a message") else tr("📌 ثبّت رسالة", "📌 Pinned a message")
            else -> text
        }
        companion object {
            fun from(o: JSONObject) = Content(o.optString("k", "text"), o.optString("t"), o.optString("n"), o.optLong("s"), o.optString("m"), o.optString("p"), o.optString("fk"),
                o.optLong("d"), o.optDouble("la", 0.0), o.optDouble("lo", 0.0), o.optString("cn"), o.optString("cp"), o.optString("th"), o.optString("lg"), o.optString("o"),
                o.optJSONArray("me")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList(), o.optBoolean("v"), o.optBoolean("mi"), o.optBoolean("fw"))
        }
    }

    data class Msg(
        val id: String, val sender: String, val recipient: String, val content: Content?, val replyTo: String = "", val groupId: String = "",
        val reactions: Map<String, String> = emptyMap(), val createdAt: Long, val editedAt: Long = 0, val deleted: Boolean = false,
        val deliveredAt: Long = 0, val readAt: Long = 0, val updatedAt: Long = createdAt, val status: Int = 1
    ) {
        val mine get() = sender == Supa.uid
        val peer get() = if (sender == Supa.uid) recipient else sender
        fun json(): JSONObject = JSONObject().put("id", id).put("s", sender).put("r", recipient).put("c", content?.json()).put("rt", replyTo).put("g", groupId)
            .put("re", JSONObject(reactions as Map<*, *>)).put("ca", createdAt).put("ea", editedAt).put("del", deleted).put("da", deliveredAt).put("ra", readAt).put("ua", updatedAt).put("st", status)
        companion object {
            fun from(o: JSONObject) = Msg(o.getString("id"), o.getString("s"), o.getString("r"), o.optJSONObject("c")?.let { Content.from(it) }, o.optString("rt"), o.optString("g"),
                o.optJSONObject("re")?.let { r -> r.keys().asSequence().associateWith { r.optString(it) } } ?: emptyMap(), o.optLong("ca"), o.optLong("ea"), o.optBoolean("del"),
                o.optLong("da"), o.optLong("ra"), o.optLong("ua"), o.optInt("st", 1))
        }
    }

    data class Friend(val phone: String, val localName: String, val uid: String = "")
    data class Group(val id: String, val name: String, val members: List<String>, val emoji: String = "👥")
    data class Conv(val peer: String, val last: Msg?, val unread: Int, val pinned: Boolean, val hidden: Boolean, val muted: Boolean)

    fun ts(s: String?): Long = if (s.isNullOrBlank() || s == "null") 0L else runCatching { OffsetDateTime.parse(s.replace(" ", "T")).toInstant().toEpochMilli() }.getOrDefault(0L)
    fun iso(t: Long): String = Instant.ofEpochMilli(t).toString()

    // ======================= الحالة =======================
    val version = mutableIntStateOf(0)
    val status = mutableStateOf("")
    @Volatile var openPeer: String? = null
    @Volatile var foreground = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private fun bump() { version.intValue++ }

    private val ctx: Context get() = Sho3ebApp.instance
    private fun dir() = File(ctx.filesDir, "chat").apply { mkdirs() }
    fun mediaDir() = File(ctx.filesDir, "chat_media").apply { mkdirs() }

    // ---------- الملفات الشخصية ----------
    private val profiles = HashMap<String, Profile>()
    private var profilesLoaded = false
    private fun loadProfiles() {
        if (profilesLoaded) return; profilesLoaded = true
        runCatching { JSONArray(File(dir(), "profiles.json").readText()).let { a -> for (i in 0 until a.length()) Profile.from(a.getJSONObject(i)).let { profiles[it.id] = it } } }
    }
    private fun saveProfiles() = runCatching { File(dir(), "profiles.json").writeText(JSONArray(profiles.values.map { it.json() }).toString()) }
    fun profile(id: String): Profile? { loadProfiles(); return profiles[id] }
    fun allProfiles(): List<Profile> { loadProfiles(); return profiles.values.toList() }

    /** اسم الصديق: اسمه في نسخته، وإن لم يتوفر فاسمه في جهات الاتصال ثم رقمه */
    fun nameOf(id: String): String {
        if (id == Supa.uid) return tr("أنا", "Me")
        val p = profile(id)
        p?.name?.takeIf { it.isNotBlank() && it != "null" }?.let { return it }
        friendByUid(id)?.localName?.takeIf { it.isNotBlank() }?.let { return it }
        val ph = p?.phone?.takeIf { it.isNotBlank() && it != "null" }
        if (ph != null) friendByPhone(ph)?.localName?.takeIf { it.isNotBlank() }?.let { return it }
        return ph?.let { "+$it" } ?: tr("مستخدم", "User")
    }

    /** بحث بالاسم أو برقم الهاتف (يقبل 010… أو 2010… أو +20…) */
    fun matches(q: String, vararg fields: String): Boolean {
        val t = q.trim(); if (t.isEmpty()) return true
        if (fields.any { it.contains(t, true) }) return true
        val d = t.filter { it.isDigit() }.trimStart('0')
        return d.length >= 3 && fields.any { f -> f.filter { it.isDigit() }.contains(d) }
    }

    fun refreshProfiles(ids: Collection<String>) {
        if (ids.isEmpty()) return
        ids.chunked(80).forEach { ch ->
            runCatching {
                val a = Supa.select("profiles?select=id,phone,name,avatar,about,pubkey,last_seen&id=in.(" + ch.joinToString(",") + ")")
                loadProfiles()
                for (i in 0 until a.length()) Profile.from(a.getJSONObject(i)).let { profiles[it.id] = it }
            }
        }
        saveProfiles(); bump()
    }

    // ---------- الإعدادات المحلية ----------
    private fun set(key: String): Set<String> = Extras.s(key, "").split(",").filter { it.isNotBlank() }.toSet()
    private fun putSet(key: String, v: Set<String>) { Extras.ps(key, v.joinToString(",")); bump(); if (key in syncedKeys) Cloud.vaultPushSoon() }
    /** إعدادات المحادثات التي تُزامن مع الحساب (تظهر كما هي على أي جهاز) */
    val syncedKeys = setOf("chat_pin", "chat_hide", "chat_mute", "chat_delme")
    private fun clearedMap(): JSONObject = runCatching { JSONObject(Extras.s("chat_cleared", "{}")) }.getOrDefault(JSONObject())
    fun clearedAt(peer: String): Long = clearedMap().optLong(peer, 0L)
    val pinned get() = set("chat_pin")
    val hidden get() = set("chat_hide")
    val muted get() = set("chat_mute")
    fun togglePin(p: String) = putSet("chat_pin", if (p in pinned) pinned - p else pinned + p)
    fun toggleHide(p: String) = putSet("chat_hide", if (p in hidden) hidden - p else hidden + p)
    fun toggleMute(p: String) = putSet("chat_mute", if (p in muted) muted - p else muted + p)
    private val deletedForMe get() = set("chat_delme")
    var keepConnected: Boolean get() = Extras.b("chat_keep", true); set(v) = Extras.pb("chat_keep", v)
    // ===== إعدادات المكالمات =====
    var callRingtone: String get() = Extras.s("call_ringtone", ""); set(v) = Extras.ps("call_ringtone", v)
    var callVibrate: Boolean get() = Extras.b("call_vibrate", true); set(v) = Extras.pb("call_vibrate", v)
    var callWho: String get() = Extras.s("call_who", "all"); set(v) = Extras.ps("call_who", v)      // all | friends | nobody
    var callSpeakerVideo: Boolean get() = Extras.b("call_spk_video", true); set(v) = Extras.pb("call_spk_video", v)
    var callDataSaver: Boolean get() = Extras.b("call_saver", false); set(v) = Extras.pb("call_saver", v)
    var callStartCamOff: Boolean get() = Extras.b("call_cam_off", false); set(v) = Extras.pb("call_cam_off", v)
    fun blocked(): Set<String> = Extras.s("chat_blocked", "").split(",").filter { it.isNotBlank() }.toSet()
    fun isBlocked(uid: String) = uid in blocked()
    fun setBlocked(uid: String, b: Boolean) { Extras.ps("chat_blocked", (if (b) blocked() + uid else blocked() - uid).joinToString(",")); bump() }
    fun canCall(uid: String): Boolean = !isBlocked(uid) && when (callWho) { "nobody" -> false; "friends" -> friendByUid(uid) != null; else -> true }
    var notifyOn: Boolean get() = Extras.b("chat_notify", true); set(v) = Extras.pb("chat_notify", v)
    private fun cfg(k: String, def: String) = Extras.s(k, "").ifBlank { com.sho3eb.app.core.Edition.embeddedString(k) }.ifBlank { def }
    var turnUrl: String get() = cfg("chat_turn", "turn:openrelay.metered.ca:443?transport=tcp"); set(v) = Extras.ps("chat_turn", v)
    var turnUser: String get() = cfg("chat_turn_u", "openrelayproject"); set(v) = Extras.ps("chat_turn_u", v)
    var turnPass: String get() = cfg("chat_turn_p", "openrelayproject"); set(v) = Extras.ps("chat_turn_p", v)

    // ---------- الأصدقاء ----------
    @Volatile private var friendsCache: List<Friend>? = null
    @Volatile private var byUid: Map<String, Friend> = emptyMap()
    @Volatile private var byPhone: Map<String, Friend> = emptyMap()
    fun friends(): List<Friend> = friendsCache ?: runCatching {
        JSONArray(Extras.s("chat_friends", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> Friend(o.optString("p"), o.optString("n"), o.optString("u")) } } }
    }.getOrDefault(emptyList()).also { l -> friendsCache = l; byUid = l.filter { it.uid.isNotBlank() }.associateBy { it.uid }; byPhone = l.associateBy { tail(it.phone) } }
    fun friendByUid(uid: String): Friend? { friends(); return byUid[uid] }
    fun friendByPhone(phone: String): Friend? { friends(); return byPhone[tail(phone)] }
    private fun saveFriends(l: List<Friend>) {
        val d = l.distinctBy { it.phone }
        Extras.ps("chat_friends", JSONArray(d.map { JSONObject().put("p", it.phone).put("n", it.localName).put("u", it.uid) }).toString())
        friendsCache = null; friends(); bump()
        Cloud.vaultPushSoon()
    }
    fun removeFriend(phone: String) = saveFriends(friends().filter { it.phone != phone })

    /** توحيد رقم الهاتف بالصيغة الدولية (أرقام فقط) */
    /** تحويل الأرقام العربية والفارسية إلى أرقام لاتينية */
    fun latinDigits(p: String): String = buildString { for (c in p) append(when (c) { in '٠'..'٩' -> '0' + (c - '٠'); in '۰'..'۹' -> '0' + (c - '۰'); else -> c }) }
    fun normPhone(p: String): String = Share.waNumber(latinDigits(p).filter { it in '0'..'9' || it == '+' })

    /** آخر 9 أرقام: تطابق الرقم مهما اختلف مفتاح الدولة أو الصفر في أوله */
    fun tail(p: String) = latinDigits(p).filter { it in '0'..'9' }.takeLast(9)

    /** البحث في الخادم عن حسابات هذه الأرقام (بآخر 9 أرقام) */
    private fun lookupPhones(phones: Collection<String>): Map<String, Profile> {
        val found = HashMap<String, Profile>()
        phones.map { tail(it) }.filter { it.length >= 8 }.distinct().chunked(40).forEach { ch ->
            runCatching {
                val a = Supa.select("profiles?select=id,phone,name,avatar,about,pubkey,last_seen&or=(" + ch.joinToString(",") { "phone.like.*$it" } + ")")
                // إن وُجد أكثر من حساب للرقم نفسه نختار الأحدث نشاطاً
                for (i in 0 until a.length()) Profile.from(a.getJSONObject(i)).let { pr ->
                    if (pr.id != Supa.uid) { val t = tail(pr.phone); val o = found[t]; if (o == null || pr.lastSeen > o.lastSeen) found[t] = pr }
                }
            }
        }
        if (found.isNotEmpty()) { loadProfiles(); found.values.forEach { profiles[it.id] = it }; saveProfiles() }
        return found
    }

    /** إضافة أصدقاء بأرقامهم؛ يعيد المسجلين في التطبيق */
    fun addFriends(list: List<Pair<String, String>>): List<Friend> {
        val norm = list.map { (n, p) -> normPhone(p) to n }.filter { it.first.length >= 8 }.distinctBy { tail(it.first) }
        val found = lookupPhones(norm.map { it.first })
        val old = friends().associateBy { tail(it.phone) }
        val merged = old.toMutableMap()
        norm.forEach { (p, n) -> val t = tail(p); merged[t] = Friend(found[t]?.phone?.takeIf { it.isNotBlank() } ?: p, n.ifBlank { old[t]?.localName ?: "" }, found[t]?.id ?: old[t]?.uid ?: "") }
        saveFriends(merged.values.toList())
        val tails = norm.map { tail(it.first) }.toSet()
        return merged.values.filter { it.uid.isNotBlank() && tail(it.phone) in tails }
    }

    /** تحديث معرّفات الأصدقاء (إن أعاد صديق تثبيت التطبيق أو فعّل التواصل لاحقاً) */
    private var lastFriendRefresh = 0L
    fun refreshFriendUids(force: Boolean = false) {
        if (!force && System.currentTimeMillis() - lastFriendRefresh < 120_000) return
        lastFriendRefresh = System.currentTimeMillis()
        val fl = friends(); if (fl.isEmpty()) return
        val found = lookupPhones(fl.map { it.phone })
        var changed = false
        val moves = mutableListOf<Pair<String, String>>()
        val upd = fl.map { f -> val pr = found[tail(f.phone)]; if (pr != null && pr.id != f.uid) { changed = true; if (f.uid.isNotBlank()) moves += f.uid to pr.id; f.copy(uid = pr.id) } else f }
        if (changed) saveFriends(upd)
        moves.forEach { (o, n) -> mergePeer(o, n) }
    }

    /** قراءة جهات اتصال الهاتف */
    fun deviceContacts(c: Context): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        runCatching {
            c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { cur ->
                while (cur.moveToNext()) out += (cur.getString(0) ?: "") to (cur.getString(1) ?: "")
            }
        }
        return out.distinctBy { normPhone(it.second) }
    }

    // ---------- المجموعات (رسائل مجمعة) ----------
    fun groups(): List<Group> = runCatching {
        JSONArray(Extras.s("chat_groups", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> Group(o.getString("id"), o.optString("n"), o.optJSONArray("m")?.let { m -> (0 until m.length()).map { m.getString(it) } } ?: emptyList(), o.optString("e", "👥")) } } }
    }.getOrDefault(emptyList())
    fun saveGroup(g: Group) { val l = groups().filter { it.id != g.id } + g; Extras.ps("chat_groups", JSONArray(l.map { JSONObject().put("id", it.id).put("n", it.name).put("m", JSONArray(it.members)).put("e", it.emoji) }).toString()); bump() }
    fun deleteGroup(id: String) { Extras.ps("chat_groups", JSONArray(groups().filter { it.id != id }.map { JSONObject().put("id", it.id).put("n", it.name).put("m", JSONArray(it.members)).put("e", it.emoji) }).toString()); bump() }

    // ---------- الرسائل (تخزين محلي) ----------
    private val convs = HashMap<String, MutableList<Msg>>()
    private var convsLoaded = false
    @Synchronized private fun loadAll() {
        if (convsLoaded) return; convsLoaded = true
        dir().listFiles { f -> f.name.startsWith("c_") }?.forEach { f ->
            runCatching { val a = JSONArray(f.readText()); convs[f.name.removePrefix("c_").removeSuffix(".json")] = (0 until a.length()).map { Msg.from(a.getJSONObject(it)) }.toMutableList() }
        }
    }
    @Synchronized private fun saveConv(peer: String) = runCatching { File(dir(), "c_$peer.json").writeText(JSONArray((convs[peer] ?: emptyList<Msg>()).takeLast(3000).map { it.json() }).toString()) }

    @Synchronized fun messages(peer: String): List<Msg> { loadAll(); val c = clearedAt(peer); return (convs[peer] ?: emptyList<Msg>()).filter { it.id !in deletedForMe && it.createdAt > c }.sortedBy { it.createdAt } }
    @Synchronized fun find(id: String): Msg? { loadAll(); return convs.values.firstNotNullOfOrNull { l -> l.firstOrNull { it.id == id } } }

    @Synchronized private fun put(m: Msg, tempId: String? = null) {
        loadAll()
        val l = convs.getOrPut(m.peer) { mutableListOf() }
        val i = l.indexOfFirst { it.id == m.id || (tempId != null && it.id == tempId) }
        if (i >= 0) l[i] = if (m.deleted) m else m.copy(content = m.content ?: l[i].content) else l += m
        saveConv(m.peer)
    }

    // ---------- دمج المحادثات عند إعادة تثبيت أحد الطرفين (نفس رقم الهاتف بحساب جديد) ----------
    private fun aliases(): Map<String, String> = runCatching { JSONObject(Extras.s("chat_alias", "{}")).let { o -> o.keys().asSequence().associateWith { o.getString(it) } } }.getOrDefault(emptyMap())
    fun canonical(uid: String): String { var u = uid; val a = aliases(); var n = 0; while (a.containsKey(u) && n++ < 10) u = a.getValue(u); return u }

    /** نقل محادثة الحساب القديم إلى الحساب الجديد لنفس الشخص (تستمر المحادثة نفسها) */
    @Synchronized fun mergePeer(old: String, new: String) {
        if (old.isBlank() || new.isBlank() || old == new) return
        loadAll()
        Extras.ps("chat_alias", JSONObject((aliases() + (old to new)) as Map<*, *>).toString())
        val moved = convs.remove(old)
        if (moved != null) {
            fun m(u: String) = if (u == old) new else u
            val l = convs.getOrPut(new) { mutableListOf() }
            val ids = l.map { it.id }.toHashSet()
            moved.forEach { x -> if (x.id !in ids) l += x.copy(sender = m(x.sender), recipient = m(x.recipient)) }
            l.sortBy { it.createdAt }
            saveConv(new)
            runCatching { File(dir(), "c_$old.json").delete() }
        }
        listOf("chat_pin", "chat_hide", "chat_mute").forEach { k -> val st = set(k); if (old in st) putSet(k, st - old + new) }
        if (isBlocked(old)) { setBlocked(old, false); setBlocked(new, true) }
        val fl = friends(); if (fl.any { it.uid == old }) saveFriends(fl.map { if (it.uid == old) it.copy(uid = new) else it })
        groups().filter { old in it.members }.forEach { g -> saveGroup(g.copy(members = g.members.map { if (it == old) new else it }.distinct())) }
        bump()
    }

    /** رسالة من حساب جديد: إن كان رقمه يطابق صديقاً/محادثة قديمة ندمجهما */
    private fun linkNewPeer(uid: String) {
        if (uid.isBlank() || uid == Supa.uid) return
        val ph = profile(uid)?.phone?.takeIf { it.length >= 8 } ?: return
        val t = tail(ph)
        val olds = (convs.keys + friends().map { it.uid }).filter { it.isNotBlank() && it != uid }
            .filter { p -> tail(profile(p)?.phone ?: friendByUid(p)?.phone ?: "") == t }.distinct()
        olds.forEach { mergePeer(it, uid) }
    }

    @Synchronized fun conversations(): List<Conv> {
        loadAll()
        val dm = deletedForMe
        val peers = convs.keys + friends().mapNotNull { it.uid.takeIf { u -> u.isNotBlank() } }.filter { convs[it]?.isNotEmpty() == true }
        return peers.distinct().mapNotNull { p ->
            val c = clearedAt(p)
            val l = convs[p]?.filter { it.id !in dm && it.createdAt > c } ?: return@mapNotNull null
            if (l.isEmpty()) return@mapNotNull null
            Conv(p, l.maxByOrNull { it.createdAt }, l.count { !it.mine && it.readAt == 0L && !it.deleted }, p in pinned, p in hidden, p in muted)
        }.sortedWith(compareByDescending<Conv> { it.pinned }.thenByDescending { it.last?.createdAt ?: 0 })
    }
    fun unreadTotal(): Int = conversations().filter { !it.hidden }.sumOf { it.unread }

    // ======================= الاتصال =======================
    private var started = false
    /** تهيئة الحساب ونشر الملف الشخصي وبدء الاستقبال اللحظي */
    /** تبديل الحساب (دخول بحساب دائم): إعادة الاتصال اللحظي وجلب كل المحادثات من الخادم */
    fun reloadForAccount() {
        runCatching { Realtime.stop() }
        synchronized(this) { convs.clear(); convsLoaded = false }
        started = false
        friendsCache = null
        runCatching { publishProfile() }
        start()
        scope.launch { runCatching { sync(); refreshFriendUids(force = true) } }
    }

    fun start() {
        if (!Supa.configured) return
        if (started) { Realtime.start(); return }
        started = true
        channels()
        Realtime.onMessage = { r -> scope.launch { handleRow(r, notify = true) } }
        Realtime.onSignal = { r -> CallBus.onSignal(r) }
        // استقبال المكالمات أولاً وبشكل مستقل (لا يتوقف إن فشلت المزامنة)
        scope.launch { ringLoop() }
        scope.launch {
            runCatching { Supa.ensureSession(); publishProfile() }.onFailure { status.value = it.message ?: "error" }
            runCatching { Realtime.start() }
            runCatching { sync() }
            while (true) { runCatching { presenceLoop() }; delay(10_000) }
        }
    }
    fun onRealtimeConnected() { scope.launch { sync() } }

    /** استطلاع احتياطي للمكالمات الواردة (إن تأخر الاتصال اللحظي) */
    @Volatile var ringPolls = 0L; private set
    @Volatile var ringError = ""; private set
    private suspend fun ringLoop() {
        var cursor = -1L
        while (true) {
            if (Supa.configured && (foreground || keepConnected || CallBus.activeCall != null)) runCatching {
                ringPolls++
                if (cursor < 0) {
                    val a = Supa.select("signals?select=id&recipient=eq.${Supa.uid}&order=id.desc&limit=1")
                    cursor = if (a.length() > 0) a.getJSONObject(0).optLong("id") else 0L
                } else {
                    val a = Supa.select("signals?select=*&recipient=eq.${Supa.uid}&type=eq.ring&id=gt.$cursor&order=id.asc")
                    for (i in 0 until a.length()) { val o = a.getJSONObject(i); cursor = maxOf(cursor, o.optLong("id")); CallBus.onSignal(o) }
                }
                ringError = ""
            }.onFailure { ringError = it.message ?: "error" }
            delay(if (foreground) 2_500 else 5_000)
        }
    }

    private suspend fun presenceLoop() {
        while (true) {
            if (foreground) runCatching { Supa.update("profiles?id=eq.${Supa.uid}", JSONObject().put("last_seen", iso(System.currentTimeMillis()))) }
            delay(30_000)
        }
    }

    /** نشر الملف الشخصي من بيانات التطبيق: الاسم والصورة ورقم الهاتف */
    fun profileComplete(): Boolean { val pr = Sho3ebApp.instance.prefs; return pr.displayName.ifBlank { pr.username }.isNotBlank() && normPhone(pr.phone).length >= 8 }
    /** رقمي بصيغة دولية كما يُنشر */
    fun myPhone(): String = Sho3ebApp.instance.prefs.phone.takeIf { it.isNotBlank() }?.let { normPhone(it) }?.takeIf { it.length >= 8 } ?: ""
    fun forceAvatarUpload() = Extras.ps("chat_avatar_sig", "")

    fun publishProfile() {
        val prefs = Sho3ebApp.instance.prefs
        val phone = normPhone(prefs.phone)
        var avatar = Extras.s("chat_avatar_path", "")
        val photo = prefs.photoPath
        val sig = (photo ?: "") + "|" + (photo?.let { File(it).lastModified() } ?: 0)
        if (photo != null && File(photo).exists() && Extras.s("chat_avatar_sig", "") != sig) runCatching {
            val b = BitmapFactory.decodeFile(photo)
            val s = 320f / maxOf(b.width, b.height)
            val sc = if (s < 1) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
            val bos = java.io.ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 85, bos)
            avatar = Supa.uid + "/avatar_" + System.currentTimeMillis() + ".jpg"
            Supa.upload(avatar, bos.toByteArray(), "image/jpeg")
            Extras.ps("chat_avatar_path", avatar); Extras.ps("chat_avatar_sig", sig)
        }
        val row = JSONObject().put("id", Supa.uid).put("name", prefs.displayName.ifBlank { prefs.username }).put("avatar", avatar)
            .put("pubkey", ChatCrypto.publicKey).put("last_seen", iso(System.currentTimeMillis())).put("about", Extras.s("chat_about", ""))
        if (phone.length >= 8) row.put("phone", phone)
        try { Supa.upsert("profiles", row) }
        catch (e: Supa.SupaError) {
            // الرقم مسجل بحساب قديم (بعد إعادة التثبيت مثلاً): ننقله لهذا الحساب
            if (phone.length >= 8 && (e.message?.contains("duplicate", true) == true || e.message?.contains("23505") == true)) {
                runCatching { Supa.rest("POST", "rpc/claim_phone", JSONObject().put("p", phone)) }
                try { Supa.upsert("profiles", row) } catch (e2: Exception) { row.remove("phone"); runCatching { Supa.upsert("profiles", row) }; throw Supa.SupaError("phone_taken") }
            } else throw e
        }
        loadProfiles(); profiles[Supa.uid] = Profile(Supa.uid, phone, row.optString("name"), avatar, row.optString("about"), ChatCrypto.publicKey, System.currentTimeMillis()); saveProfiles()
    }

    // ======================= المزامنة =======================
    private var syncing = false
    suspend fun sync() {
        if (!Supa.configured || syncing) return
        syncing = true
        try {
            Supa.ensureSession()
            var cursor = Extras.s("chat_cursor", "1970-01-01T00:00:00Z")
            var rounds = 0
            while (rounds++ < 20) {
                val me = Supa.uid
                val a = Supa.select("messages?select=*&or=(sender.eq.$me,recipient.eq.$me)&updated_at=gt." + Uri.encode(cursor) + "&order=updated_at.asc&limit=300")
                if (a.length() == 0) break
                val rows = (0 until a.length()).map { a.getJSONObject(it) }
                val unknown = rows.flatMap { listOf(it.optString("sender"), it.optString("recipient")) }.filter { profile(it)?.pubkey.isNullOrBlank() }.toSet()
                if (unknown.isNotEmpty()) refreshProfiles(unknown)
                rows.forEach { handleRow(it, notify = cursor != "1970-01-01T00:00:00Z") }
                cursor = rows.last().optString("updated_at")
                Extras.ps("chat_cursor", cursor)
                if (a.length() < 300) break
            }
            // تحديث حالة الأصدقاء ومعرّفاتهم
            runCatching { refreshFriendUids() }
            val ids = (convs.keys + friends().map { it.uid }).filter { it.isNotBlank() }.toSet()
            if (ids.isNotEmpty()) refreshProfiles(ids)
            status.value = ""
        } catch (e: Exception) {
            status.value = e.message ?: "sync error"
        } finally { syncing = false; bump() }
    }

    private fun keyFor(peer: String): ByteArray? {
        val pk = profile(peer)?.pubkey?.takeIf { it.isNotBlank() } ?: run { refreshProfiles(listOf(peer)); profile(peer)?.pubkey } ?: return null
        return runCatching { ChatCrypto.sharedKey(pk) }.getOrNull()
    }

    /** معالجة صف رسالة قادم من الخادم */
    fun handleRow(r: JSONObject, notify: Boolean) {
        val sender = canonical(r.optString("sender")); val recipient = canonical(r.optString("recipient"))
        val me = Supa.uid
        val peer = if (sender == me) recipient else sender
        // مرسل جديد لا نعرفه: نتحقق إن كان نفس صديق قديم أعاد تثبيت التطبيق
        if (peer != me && synchronized(this) { loadAll(); convs[peer] == null }) runCatching { refreshProfiles(listOf(peer)); linkNewPeer(peer) }
        if (sender != me && isBlocked(sender)) return   // محظور: لا نعرض رسائله
        val del = r.optBoolean("deleted")
        val body = r.optString("body").takeIf { it.isNotBlank() && it != "null" }
        val content = if (del || body == null) null else keyFor(peer)?.let { k -> ChatCrypto.decrypt(k, body)?.let { runCatching { Content.from(JSONObject(it)) }.getOrNull() } }
            ?: Content(text = tr("🔒 رسالة مشفرة لا يمكن فتحها على هذا الجهاز", "🔒 Encrypted message can't be opened on this device"))
        val id = r.optString("id")
        val existed = find(id)
        val m = Msg(id, sender, recipient, if (del) null else content, r.optString("reply_to").takeIf { it != "null" } ?: "", r.optString("group_id").takeIf { it != "null" } ?: "",
            r.optJSONObject("reactions")?.let { o -> o.keys().asSequence().associateWith { o.optString(it) } } ?: emptyMap(),
            ts(r.optString("created_at")), ts(r.optString("edited_at")), del, ts(r.optString("delivered_at")), ts(r.optString("read_at")), ts(r.optString("updated_at")))
        // محادثة مسحها المستخدم: لا تعود الرسائل القديمة (حتى على جهاز آخر)
        if (m.createdAt <= clearedAt(peer)) { if (!m.mine && m.deliveredAt == 0L) scope.launch { runCatching { Supa.update("messages?id=eq.$id", JSONObject().put("delivered_at", iso(System.currentTimeMillis()))) } }; return }
        put(m)
        bump()
        if (!m.mine && m.deliveredAt == 0L) scope.launch { runCatching { Supa.update("messages?id=eq.$id", JSONObject().put("delivered_at", iso(System.currentTimeMillis()))) } }
        if (!m.mine && existed == null && notify && !del) {
            if (openPeer == peer && foreground) markRead(peer)
            else if (notifyOn && peer !in muted && peer !in hidden && m.content?.kind != "pin") notifyMessage(m)
        }
    }

    // ======================= الإرسال =======================
    /** إرسال محتوى لصديق أو عدة أصدقاء (رسالة مجمعة) */
    suspend fun send(peers: List<String>, content: Content, replyTo: String = "", groupId: String = ""): Boolean {
        var ok = true
        for (peer in peers.distinct()) {
            val temp = "tmp-" + UUID.randomUUID()
            val now = System.currentTimeMillis()
            put(Msg(temp, Supa.uid, peer, content, replyTo, groupId, createdAt = now, status = 0)); bump()
            try {
                val k = keyFor(peer) ?: throw Supa.SupaError(tr("الصديق لم يفعّل التواصل بعد", "Friend hasn't activated chat yet"))
                val row = JSONObject().put("sender", Supa.uid).put("recipient", peer).put("body", ChatCrypto.encrypt(k, content.json().toString()))
                if (replyTo.isNotBlank()) row.put("reply_to", replyTo)
                if (groupId.isNotBlank()) row.put("group_id", groupId)
                val r = Supa.insert("messages", row)
                synchronized(this) { loadAll(); convs[peer]?.removeAll { it.id == temp } }
                handleRow(r, notify = false)
            } catch (e: Exception) {
                ok = false
                put(Msg(temp, Supa.uid, peer, content, replyTo, groupId, createdAt = now, status = -1)); bump()
                status.value = e.message ?: "send error"
            }
        }
        return ok
    }

    suspend fun retry(m: Msg) { synchronized(this) { convs[m.peer]?.removeAll { it.id == m.id } }; m.content?.let { send(listOf(m.peer), it, m.replyTo, m.groupId) } }

    /** رفع ملف مشفر ثم إرساله */
    suspend fun sendFile(peers: List<String>, uri: Uri, kind0: String? = null, caption: String = "", dur: Long = 0): Boolean {
        val c = ctx
        val name = MediaTools.nameOf(c, uri)
        val mime = c.contentResolver.getType(uri) ?: android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
        val kind = kind0 ?: when { mime.startsWith("image") -> "image"; mime.startsWith("video") -> "video"; mime.startsWith("audio") -> "audio"; else -> "file" }
        val bytes = c.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        if (bytes.size > 45 * 1024 * 1024) { status.value = tr("الحد الأقصى للملف 45 ميجا", "Max file size is 45 MB"); return false }
        val thumb = runCatching { thumbOf(kind, uri, bytes) }.getOrNull() ?: ""
        val fkey = ChatCrypto.randomKey()
        val path = Supa.uid + "/" + UUID.randomUUID()
        return try {
            Supa.upload(path, ChatCrypto.encryptBytes(fkey, bytes))
            // نسخة محلية للمرسل
            File(mediaDir(), path.substringAfter('/') + "_" + name.replace('/', '_')).writeBytes(bytes)
            send(peers, Content(kind, caption, name, bytes.size.toLong(), mime, path, ChatCrypto.keyB64(fkey), dur, thumb = thumb))
        } catch (e: Exception) { status.value = e.message ?: "upload error"; false }
    }

    private fun thumbOf(kind: String, uri: Uri, bytes: ByteArray): String? {
        val bmp: Bitmap = when (kind) {
            "image" -> BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = 4 }) ?: return null
            "video" -> android.media.MediaMetadataRetriever().let { r -> try { r.setDataSource(ctx, uri); r.getFrameAtTime(1_000_000) } finally { r.release() } } ?: return null
            else -> return null
        }
        val s = 360f / maxOf(bmp.width, bmp.height)
        val t = Bitmap.createScaledBitmap(bmp, maxOf(1, (bmp.width * s).toInt()), maxOf(1, (bmp.height * s).toInt()), true)
        val bos = java.io.ByteArrayOutputStream(); t.compress(Bitmap.CompressFormat.JPEG, 70, bos)
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    /** الملف المحلي للمرفق (يُنزّل ويُفك تشفيره عند الحاجة) */
    fun localFile(c: Content): File = File(mediaDir(), c.path.substringAfter('/') + "_" + c.name.ifBlank { "file" }.replace('/', '_'))
    suspend fun fetchFile(c: Content): File? {
        val f = localFile(c)
        if (f.exists() && f.length() > 0) return f
        return runCatching { f.writeBytes(ChatCrypto.decryptBytes(ChatCrypto.keyFrom(c.fkey), Supa.download(c.path))); f }.getOrNull()
    }

    fun markRead(peer: String) {
        val l = messages(peer).filter { !it.mine && it.readAt == 0L && !it.id.startsWith("tmp") }
        if (l.isEmpty()) return
        val now = System.currentTimeMillis()
        l.forEach { put(it.copy(readAt = now)) }; bump()
        NotificationManagerCompat.from(ctx).cancel(peer.hashCode())
        scope.launch { runCatching { Supa.update("messages?recipient=eq.${Supa.uid}&sender=eq.$peer&read_at=is.null", JSONObject().put("read_at", iso(now)).put("delivered_at", iso(now))) } }
    }

    suspend fun edit(m: Msg, text: String) {
        val c = (m.content ?: Content()).copy(text = text)
        val k = keyFor(m.peer) ?: return
        runCatching { Supa.update("messages?id=eq.${m.id}", JSONObject().put("body", ChatCrypto.encrypt(k, c.json().toString())).put("edited_at", iso(System.currentTimeMillis()))) }
        put(m.copy(content = c, editedAt = System.currentTimeMillis())); bump()
    }
    suspend fun deleteForAll(m: Msg) {
        runCatching { Supa.update("messages?id=eq.${m.id}", JSONObject().put("deleted", true).put("body", JSONObject.NULL)) }
        put(m.copy(deleted = true, content = null)); bump()
    }
    /** الرسائل المثبتة في المحادثة (تُزامن مع الطرف الآخر عبر رسالة تثبيت) */
    fun pinnedIds(msgs: List<Msg>): List<String> {
        val out = LinkedHashSet<String>()
        msgs.filter { it.content?.kind == "pin" && !it.deleted }.sortedBy { it.createdAt }.forEach { m ->
            val id = m.content?.text ?: return@forEach
            if (m.content?.missed == true) out.remove(id) else { out.remove(id); out.add(id) }
        }
        return out.toList()
    }
    suspend fun pinMessage(peers: List<String>, m: Msg, pin: Boolean, groupId: String = "") = send(peers, Content("pin", m.id, missed = !pin), groupId = groupId)

    fun deleteForMe(m: Msg) = putSet("chat_delme", deletedForMe + m.id)
    /** حذف المحادثة نهائياً من حسابي: تُمسح محلياً ولا تعود عند فتح الحساب من جهاز آخر */
    @Synchronized fun clearChat(peer: String) {
        loadAll()
        val last = maxOf(System.currentTimeMillis(), convs[peer]?.maxOfOrNull { it.createdAt } ?: 0L)
        Extras.ps("chat_cleared", clearedMap().put(peer, last).toString())
        val ids = convs[peer]?.map { it.id }?.toSet().orEmpty()
        convs.remove(peer); runCatching { File(dir(), "c_$peer.json").delete() }
        // لا حاجة لإبقاء معرّفاتها في قائمة الحذف الفردي
        Extras.ps("chat_delme", (deletedForMe - ids).joinToString(","))
        putSet("chat_pin", pinned - peer)
        Cloud.vaultPushSoon()
    }
    suspend fun react(m: Msg, emoji: String) {
        val r = m.reactions.toMutableMap(); if (r[Supa.uid] == emoji) r.remove(Supa.uid) else r[Supa.uid] = emoji
        put(m.copy(reactions = r)); bump()
        runCatching { Supa.update("messages?id=eq.${m.id}", JSONObject().put("reactions", JSONObject(r as Map<*, *>))) }
    }

    // ======================= الإشعارات =======================
    const val CH = "sho3eb_chat"
    fun channels() {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, tr("رسائل التواصل", "Chat messages"), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CallBus.CH, tr("المكالمات الواردة", "Incoming calls"), NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE),
                android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            enableVibration(true); vibrationPattern = longArrayOf(0, 800, 600, 800, 600, 800)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        })
        runCatching { nm.deleteNotificationChannel("sho3eb_calls") }
        nm.createNotificationChannel(NotificationChannel("sho3eb_chat_bg", tr("اتصال التواصل", "Chat connection"), NotificationManager.IMPORTANCE_MIN))
    }
    private fun notifyMessage(m: Msg) {
        val c = ctx
        if (!com.sho3eb.app.core.Notifier.canNotify(c)) return
        val name = nameOf(m.sender)
        val i = Intent(c, com.sho3eb.app.ui.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("route", "chat/${m.sender}")
        val pi = PendingIntent.getActivity(c, m.sender.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val unread = messages(m.sender).filter { !it.mine && it.readAt == 0L }.takeLast(6)
        val style = NotificationCompat.MessagingStyle(Person.Builder().setName(tr("أنا", "Me")).build())
        val person = Person.Builder().setName(name).build()
        unread.forEach { u -> style.addMessage(u.content?.preview ?: "", u.createdAt, person) }
        val mention = m.content?.mentions?.contains(Supa.uid) == true
        val n = NotificationCompat.Builder(c, CH).setSmallIcon(R.drawable.ic_notification).setStyle(style).setContentTitle(if (mention) "@ $name" else name)
            .setContentText(m.content?.preview ?: "").setContentIntent(pi).setAutoCancel(true).setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setNumber(unread.size).build()
        runCatching { NotificationManagerCompat.from(c).notify(m.sender.hashCode(), n) }
    }

    // ======================= مشاركة من الأقسام الأخرى =======================
    val pendingShare = mutableStateOf<List<Uri>>(emptyList())
    val pendingText = mutableStateOf("")

    fun inviteText(): String = tr("انضم إليّ على تطبيق ", "Join me on ") + com.sho3eb.app.core.Edition.appName + tr(" للتواصل والرسائل والمكالمات المجانية المشفرة:\n", " for free encrypted chat & calls:\n") + com.sho3eb.app.core.Edition.storeLink()

    fun lastSeenText(id: String): String {
        val p = profile(id) ?: return ""
        if (p.online) return tr("🟢 نشط الآن", "🟢 Online")
        if (p.lastSeen <= 0) return ""
        val m = (System.currentTimeMillis() - p.lastSeen) / 60000
        return when {
            m < 60 -> tr("نشط منذ $m دقيقة", "Active ${m}m ago")
            m < 1440 -> tr("نشط منذ ${m / 60} ساعة", "Active ${m / 60}h ago")
            m < 2880 -> tr("نشط أمس", "Active yesterday")
            else -> tr("نشط منذ ${m / 1440} يوم", "Active ${m / 1440}d ago")
        }
    }
}
