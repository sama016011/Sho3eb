@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.content.Intent
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import com.sho3eb.app.islam.IslamPrefs
import com.sho3eb.app.islam.Tts
import com.sho3eb.app.ui.theme.SuccessGreen
import java.util.Locale

private const val SAMPLE = "بسم الله الرحمن الرحيم. سبحان الله وبحمده، سبحان الله العظيم. اللهم صلِّ وسلم على نبينا محمد."

/** اختيار صوت القراءة: المحرك، الصوت (رجل/امرأة)، الطبقة والسرعة مع التجربة */
@Composable
fun VoiceSettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var voices by remember { mutableStateOf(emptyList<Voice>()) }
    var engines by remember { mutableStateOf(emptyList<TextToSpeech.EngineInfo>()) }
    var selected by remember { mutableStateOf(IslamPrefs.ttsVoice) }
    var engine by remember { mutableStateOf(IslamPrefs.ttsEngine) }
    var autoPitch by remember { mutableStateOf(IslamPrefs.ttsPitch <= 0f) }
    var pitch by remember { mutableStateOf(if (IslamPrefs.ttsPitch > 0f) IslamPrefs.ttsPitch else 1.0f) }
    var rate by remember { mutableStateOf(IslamPrefs.ttsRate) }
    var showAll by remember { mutableStateOf(false) }

    LaunchedEffect(reload) {
        ready = false
        Tts.ensure(ctx) { ok ->
            ready = ok
            voices = Tts.arabicVoices()
            engines = Tts.engines()
            if (!ok) toast(ctx, tr("محرك القراءة الصوتية غير متاح", "Text-to-speech is not available"))
        }
    }
    DisposableEffect(Unit) { onDispose { Tts.stop() } }

    val best = remember(voices) { Tts.bestMale() }
    val males = voices.filter { Tts.gender(it) == 1 }
    val shown = if (showAll) voices else voices.filter { Tts.gender(it) != 2 || it.name == selected }

    fun pitchNow(): Float? = if (autoPitch) null else pitch
    fun voiceLabel(v: Voice): String {
        val g = when (Tts.gender(v)) { 1 -> tr("👨 صوت رجل", "👨 Male"); 2 -> tr("👩 صوت امرأة", "👩 Female"); else -> tr("🔈 غير محدد", "🔈 Unknown") }
        val country = v.locale.getDisplayCountry(com.sho3eb.app.core.AppState.locale()).ifBlank { v.locale.toString() }
        return "$g • $country"
    }

    ScreenScaffold(title = tr("صوت القراءة", "Reading voice"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                InfoBanner(
                    tr(
                        "يُستخدم هذا الصوت في قراءة الأذكار والرقية والأحكام والقصص وتصديرها كملف صوتي. الافتراضي: صوت رجل تلقائياً. الأصوات المتاحة تعتمد على محرك تحويل النص إلى كلام في هاتفك؛ إن لم يظهر صوت رجل فنزّل الأصوات العربية من «خدمات الكلام من Google».",
                        "Used for azkar, ruqyah, rulings and stories (and audio export). Default: a male voice automatically. Available voices depend on your phone's TTS engine; if no male voice appears, download Arabic voices in “Speech Services by Google”."
                    )
                )
            }
            if (!ready) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }

            // ---- المحرك ----
            if (engines.size > 1) {
                item { SectionTitle(tr("محرك الصوت", "Speech engine")) }
                item {
                    Card {
                        Column(Modifier.padding(vertical = 4.dp)) {
                            RadioLine(engine == "", tr("الافتراضي في الهاتف", "Phone default"), Tts.currentEngine() ?: "") {
                                engine = ""; IslamPrefs.ttsEngine = ""; IslamPrefs.ttsVoice = ""; selected = ""; Tts.reset(); reload++
                            }
                            engines.forEach { e ->
                                RadioLine(engine == e.name, e.label, e.name) {
                                    engine = e.name; IslamPrefs.ttsEngine = e.name; IslamPrefs.ttsVoice = ""; selected = ""; Tts.reset(); reload++
                                }
                            }
                        }
                    }
                }
            }

            // ---- الأصوات ----
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr("الصوت", "Voice"), Modifier.weight(1f))
                    FilterChip(showAll, { showAll = !showAll }, label = { Text(tr("إظهار أصوات النساء", "Show female voices")) })
                }
            }
            item {
                Card {
                    Column(Modifier.padding(vertical = 4.dp)) {
                        RadioLine(
                            selected == "",
                            tr("تلقائي — صوت رجل (موصى به)", "Auto — male voice (recommended)"),
                            best?.let { tr("سيُستخدم: ", "Will use: ") + it.name } ?: tr("لم يُعثر على صوت رجل؛ سيُستخدم الصوت المتاح بطبقة أخفض ليقترب من صوت الرجل", "No male voice found; the available voice will use a lower pitch"),
                            onPlay = { Tts.preview(ctx, best, SAMPLE, pitchNow() ?: if (best != null) 1.0f else 0.78f, rate) }
                        ) { selected = ""; IslamPrefs.ttsVoice = "" }
                        RadioLine(
                            selected == "default", tr("صوت المحرك الافتراضي", "Engine default voice"), null,
                            onPlay = { Tts.preview(ctx, null, SAMPLE, pitchNow() ?: 1.0f, rate) }
                        ) { selected = "default"; IslamPrefs.ttsVoice = "default" }
                        if (ready && voices.isEmpty()) Text(
                            tr("لا توجد أصوات عربية مثبتة في هذا المحرك.", "No Arabic voices installed in this engine."),
                            Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall
                        )
                        shown.forEach { v ->
                            val sub = buildString {
                                append(voiceLabel(v))
                                append(if (v.isNetworkConnectionRequired) tr(" • يحتاج إنترنت", " • online") else tr(" • بدون إنترنت", " • offline"))
                                if (!Tts.isInstalled(v)) append(tr(" • غير منزّل", " • not downloaded"))
                                if (v.quality >= Voice.QUALITY_HIGH) append(tr(" • جودة عالية", " • high quality"))
                            }
                            RadioLine(selected == v.name, v.name, sub, onPlay = { Tts.preview(ctx, v, SAMPLE, pitchNow() ?: 1.0f, rate) }) {
                                selected = v.name; IslamPrefs.ttsVoice = v.name
                            }
                        }
                    }
                }
            }
            if (ready && males.isEmpty()) item {
                InfoBanner(tr(
                    "لم يتم العثور على صوت رجل عربي في هذا المحرك. للحصول عليه: افتح «إعدادات تحويل النص إلى كلام» ← المحرك المفضل: خدمات الكلام من Google ← الإعدادات ← تثبيت بيانات الصوت ← العربية، ثم نزّل الأصوات وارجع لهذه الشاشة.",
                    "No Arabic male voice found. Open TTS settings → Preferred engine: Speech Services by Google → Settings → Install voice data → Arabic, download voices, then come back."
                ), MaterialTheme.colorScheme.error)
            }

            // ---- الطبقة والسرعة ----
            item { SectionTitle(tr("طبقة الصوت والسرعة", "Pitch & speed")) }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SwitchRow(tr("طبقة تلقائية", "Automatic pitch"), tr("طبيعية مع صوت الرجل، وأخفض عند عدم توفره", "Natural with a male voice, lower otherwise"), autoPitch) {
                            autoPitch = it; IslamPrefs.ttsPitch = if (it) -1f else pitch
                        }
                        if (!autoPitch) {
                            Text(tr("الطبقة: ", "Pitch: ") + String.format(Locale.US, "%.2f", pitch) + tr("  (أقل = أعمق وأقرب لصوت الرجل)", "  (lower = deeper)"))
                            Slider(pitch, { pitch = it }, valueRange = 0.5f..1.5f, onValueChangeFinished = { IslamPrefs.ttsPitch = pitch })
                        }
                        Text(tr("السرعة: ", "Speed: ") + String.format(Locale.US, "%.2f", rate))
                        Slider(rate, { rate = it }, valueRange = 0.5f..1.5f, onValueChangeFinished = { IslamPrefs.ttsRate = rate })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if (Tts.speaking.value) Tts.stop()
                                else Tts.preview(ctx, Tts.selectedVoice(), SAMPLE, pitchNow() ?: Tts.effectivePitch(), rate)
                            }, modifier = Modifier.weight(1f)) {
                                Icon(if (Tts.speaking.value) Icons.Filled.Stop else Icons.Filled.PlayArrow, null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (Tts.speaking.value) tr("إيقاف", "Stop") else tr("تجربة الصوت المختار", "Test selected voice"))
                            }
                            OutlinedButton(onClick = {
                                autoPitch = true; pitch = 1.0f; rate = 0.9f; selected = ""
                                IslamPrefs.ttsPitch = -1f; IslamPrefs.ttsRate = 0.9f; IslamPrefs.ttsVoice = ""
                                toast(ctx, tr("تمت الاستعادة: صوت رجل تلقائي", "Reset to automatic male voice"))
                            }) { Text(tr("استعادة", "Reset")) }
                        }
                    }
                }
            }

            // ---- أدوات ----
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        try { ctx.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (_: Exception) { toast(ctx, tr("غير متاح على هذا الهاتف", "Not available on this phone")) }
                    }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Download, null); Spacer(Modifier.width(4.dp)); Text(tr("تنزيل أصوات", "Get voices"), maxLines = 1)
                    }
                    OutlinedButton(onClick = {
                        try { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (_: Exception) { toast(ctx, tr("افتح إعدادات الهاتف ← تحويل النص إلى كلام", "Open phone settings → Text-to-speech")) }
                    }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Settings, null); Spacer(Modifier.width(4.dp)); Text(tr("إعدادات الهاتف", "Phone settings"), maxLines = 1)
                    }
                }
            }
            item {
                TextButton(onClick = { Tts.reset(); reload++ }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(6.dp)); Text(tr("تحديث قائمة الأصوات (بعد التنزيل)", "Refresh voices (after download)"))
                }
            }
        }
    }
}

@Composable
private fun RadioLine(checked: Boolean, title: String, subtitle: String?, onPlay: (() -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(checked, onClick)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal, color = if (checked) SuccessGreen else MaterialTheme.colorScheme.onSurface)
            if (!subtitle.isNullOrBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (onPlay != null) IconButton(onClick = onPlay) { Icon(Icons.Filled.PlayCircle, tr("تجربة", "Preview"), tint = MaterialTheme.colorScheme.primary) }
    }
}
