@file:OptIn(ExperimentalMaterial3Api::class)
@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.sho3eb.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

fun Context.findActivity(): Activity? { var c = this; while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }; return null }

/** فتح المشغل الداخلي لرابط أو ملف */
fun NavController.openPlayer(url: String, title: String) = navigate("player?u=" + Uri.encode(url) + "&t=" + Uri.encode(title))
fun NavController.openWeb(url: String, title: String) = navigate("web?u=" + Uri.encode(url) + "&t=" + Uri.encode(title))

/** ملء الشاشة: اتجاه أفقي وإخفاء الأشرطة */
fun setFullscreen(act: Activity?, on: Boolean, landscape: Boolean = true) {
    act ?: return
    val ctl = WindowCompat.getInsetsController(act.window, act.window.decorView)
    if (on) {
        ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl.hide(WindowInsetsCompat.Type.systemBars())
        if (landscape) act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    } else {
        ctl.show(WindowInsetsCompat.Type.systemBars())
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
}

// =============================== زر تسجيل الشاشة ===============================
@Composable
fun RecordButton(tint: Color = Color.Unspecified) {
    val ctx = LocalContext.current
    val rec by ScreenRecordService.recording
    var menu by remember { mutableStateOf(false) }
    val projLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) ScreenRecordService.start(ctx, r.resultCode, r.data!!)
        else toast(ctx, tr("تم إلغاء التسجيل", "Recording cancelled"))
    }
    fun begin() {
        val mpm = ctx.getSystemService(MediaProjectionManager::class.java)
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { begin() }
    var elapsed by remember { mutableLongStateOf(0L) }
    LaunchedEffect(rec) { while (rec) { elapsed = (System.currentTimeMillis() - ScreenRecordService.startedAt.value) / 1000; delay(1000) } }
    Box {
        if (rec) TextButton(onClick = { ScreenRecordService.stop(ctx) }) {
            Icon(Icons.Filled.StopCircle, null, tint = DangerRed); Spacer(Modifier.width(4.dp))
            Text(String.format(java.util.Locale.US, "%02d:%02d", elapsed / 60, elapsed % 60), color = DangerRed, fontWeight = FontWeight.Bold)
        } else IconButton(onClick = { menu = true }) { Icon(Icons.Filled.FiberManualRecord, contentDescription = tr("تسجيل الشاشة", "Record screen"), tint = if (tint == Color.Unspecified) DangerRed else tint) }
        DropdownMenu(menu, { menu = false }) {
            Text(tr("تسجيل الشاشة", "Screen recording"), Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontWeight = FontWeight.Bold)
            DropdownMenuItem(text = { Text((if (ScreenRecordService.withAudio) "☑ " else "☐ ") + tr("تسجيل الصوت (الميكروفون)", "Record audio (mic)")) }, onClick = { ScreenRecordService.withAudio = !ScreenRecordService.withAudio; menu = false; menu = true })
            DropdownMenuItem(text = { Text((if (ScreenRecordService.quality == 1) "☑ " else "☐ ") + "1080p") }, onClick = { ScreenRecordService.quality = 1; menu = false })
            DropdownMenuItem(text = { Text((if (ScreenRecordService.quality == 0) "☑ " else "☐ ") + "720p") }, onClick = { ScreenRecordService.quality = 0; menu = false })
            DropdownMenuItem(leadingIcon = { Icon(Icons.Filled.FiberManualRecord, null, tint = DangerRed) }, text = { Text(tr("ابدأ التسجيل", "Start recording")) }, onClick = {
                menu = false
                if (ScreenRecordService.withAudio && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micLauncher.launch(Manifest.permission.RECORD_AUDIO) else begin()
            })
            Text(tr("المحتوى المحمي (نتفليكس، شاهد…) يظهر أسود في التسجيل.", "Protected content (Netflix, Shahid…) records as black."), Modifier.padding(horizontal = 16.dp, vertical = 4.dp).widthIn(max = 260.dp), style = MaterialTheme.typography.labelSmall)
        }
    }
}

// =============================== المشغل ===============================
@Composable
fun VideoPlayerScreen(nav: NavController, url: String, title: String) {
    val ctx = LocalContext.current
    val act = remember { ctx.findActivity() }
    var full by rememberSaveable { mutableStateOf(false) }
    var lockLandscape by remember { mutableStateOf(true) }
    var tracks by remember { mutableStateOf<Tracks?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var speed by remember { mutableFloatStateOf(1f) }
    var resize by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var qualityMenu by remember { mutableStateOf(false) }
    var audioMenu by remember { mutableStateOf(false) }
    var subMenu by remember { mutableStateOf(false) }
    var speedMenu by remember { mutableStateOf(false) }
    var nowTitle by remember { mutableStateOf(title) }
    var queueOpen by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var shuffle by remember { mutableStateOf(false) }
    val player = remember {
        ExoPlayer.Builder(ctx).setSeekBackIncrementMs(10_000).setSeekForwardIncrementMs(10_000).build().apply {
            if (url == "queue" && MediaTools.queue.isNotEmpty()) {
                setMediaItems(MediaTools.queue.map { t -> MediaItem.Builder().setUri(Uri.parse(t.uri)).setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(t.name).build()).build() }, MediaTools.queueStart, 0L)
            } else setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            prepare(); playWhenReady = true
        }
    }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onPlayerError(e: PlaybackException) { err = e.errorCodeName + "\n" + (e.message ?: "") }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { err = null; mediaItem?.mediaMetadata?.title?.let { nowTitle = it.toString() } }
        }
        player.addListener(l)
        act?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { player.removeListener(l); player.release(); setFullscreen(act, false); act?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    LaunchedEffect(full, lockLandscape) { setFullscreen(act, full, lockLandscape) }
    BackHandler(full) { full = false }

    fun groups(type: Int) = tracks?.groups?.filter { it.type == type } ?: emptyList()
    val videoOpts = groups(C.TRACK_TYPE_VIDEO).flatMap { g -> (0 until g.length).filter { g.isTrackSupported(it) }.map { i -> Triple(g, i, g.getTrackFormat(i)) } }.sortedByDescending { it.third.height }
    val audioOpts = groups(C.TRACK_TYPE_AUDIO).flatMap { g -> (0 until g.length).map { i -> Triple(g, i, g.getTrackFormat(i)) } }
    val textOpts = groups(C.TRACK_TYPE_TEXT).flatMap { g -> (0 until g.length).map { i -> Triple(g, i, g.getTrackFormat(i)) } }
    val curHeight = videoOpts.firstOrNull { (g, i, _) -> g.isTrackSelected(i) }?.third?.height

    val playerBox: @Composable (Modifier) -> Unit = { m ->
        Box(m.background(Color.Black)) {
            AndroidView(factory = { c -> PlayerView(c).apply { this.player = player; useController = true; setShowSubtitleButton(true); layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) } },
                update = { v -> v.resizeMode = resize }, modifier = Modifier.fillMaxSize())
            Row(Modifier.align(Alignment.TopEnd).padding(4.dp)) {
                IconButton(onClick = { qualityMenu = true }) { Icon(Icons.Filled.HighQuality, contentDescription = tr("الجودة", "Quality"), tint = Color.White) }
                IconButton(onClick = { audioMenu = true }) { Icon(Icons.Filled.Audiotrack, contentDescription = tr("الصوت", "Audio"), tint = Color.White) }
                IconButton(onClick = { resize = when (resize) { AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM; AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL; else -> AspectRatioFrameLayout.RESIZE_MODE_FIT } }) { Icon(Icons.Filled.AspectRatio, contentDescription = tr("أبعاد الصورة", "Aspect"), tint = Color.White) }
                RecordButton(Color.White)
                IconButton(onClick = { full = !full }) { Icon(if (full) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen, contentDescription = tr("ملء الشاشة", "Fullscreen"), tint = Color.White) }
            }
            DropdownMenu(qualityMenu, { qualityMenu = false }) {
                DropdownMenuItem(text = { Text(tr("تلقائي", "Auto") + if (curHeight != null) " ($curHeight" + "p)" else "") }, onClick = {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO).build(); qualityMenu = false
                })
                videoOpts.distinctBy { it.third.height }.forEach { (g, i, f) ->
                    DropdownMenuItem(text = { Text("${f.height}p" + (if (f.bitrate > 0) " • ${f.bitrate / 1000} kbps" else "") + if (g.isTrackSelected(i)) " ✓" else "") }, onClick = {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build(); qualityMenu = false
                    })
                }
                if (videoOpts.size <= 1) Text(tr("هذا المصدر بجودة واحدة", "Single quality source"), Modifier.padding(12.dp), style = MaterialTheme.typography.labelSmall)
            }
            DropdownMenu(audioMenu, { audioMenu = false }) {
                Text(tr("مسار الصوت / التعليق", "Audio track / commentary"), Modifier.padding(horizontal = 12.dp), fontWeight = FontWeight.Bold)
                audioOpts.forEachIndexed { k, (g, i, f) ->
                    DropdownMenuItem(text = { Text((f.label ?: f.language?.let { java.util.Locale(it).displayLanguage } ?: tr("صوت ${k + 1}", "Audio ${k + 1}")) + (if (f.channelCount > 0) " • ${f.channelCount}ch" else "") + if (g.isTrackSelected(i)) " ✓" else "") }, onClick = {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build(); audioMenu = false
                    })
                }
                if (audioOpts.isEmpty()) Text(tr("لا توجد مسارات إضافية", "No extra tracks"), Modifier.padding(12.dp))
                HorizontalDivider()
                Text(tr("السرعة", "Speed"), Modifier.padding(horizontal = 12.dp), fontWeight = FontWeight.Bold)
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { sp -> DropdownMenuItem(text = { Text("${sp}x" + if (speed == sp) " ✓" else "") }, onClick = { speed = sp; player.setPlaybackSpeed(sp); audioMenu = false }) }
                if (textOpts.isNotEmpty()) {
                    HorizontalDivider()
                    Text(tr("الترجمة", "Subtitles"), Modifier.padding(horizontal = 12.dp), fontWeight = FontWeight.Bold)
                    DropdownMenuItem(text = { Text(tr("إيقاف", "Off")) }, onClick = { player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build(); audioMenu = false })
                    textOpts.forEach { (g, i, f) -> DropdownMenuItem(text = { Text(f.label ?: f.language ?: "Sub") }, onClick = { player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build(); audioMenu = false }) }
                }
            }
        }
    }
    if (full) { playerBox(Modifier.fillMaxSize()); return }
    ScreenScaffold(title = title.ifBlank { tr("المشغل", "Player") }, onBack = { nav.popBackStack() }, actions = {
        if (url.startsWith("http")) IconButton(onClick = { toast(ctx, if (MediaLib.download(ctx, url, nowTitle)) tr("⬇️ بدأ التنزيل إلى Movies/Sho3eb", "⬇️ Downloading to Movies/Sho3eb") else tr("البث المباشر لا يمكن تنزيله؛ استخدم تسجيل الشاشة", "Live streams can't be downloaded; use screen recording")) }) { Icon(Icons.Filled.Download, contentDescription = tr("تنزيل", "Download")) }
        RecordButton()
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            playerBox(Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            Column(Modifier.padding(16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(nowTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (url == "queue") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { player.seekToPreviousMediaItem() }) { Icon(Icons.Filled.SkipPrevious, null) }
                        IconButton(onClick = { player.seekToNextMediaItem() }) { Icon(Icons.Filled.SkipNext, null) }
                        IconButton(onClick = { shuffle = !shuffle; player.shuffleModeEnabled = shuffle }) { Icon(Icons.Filled.Shuffle, null, tint = if (shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline) }
                        IconButton(onClick = { repeat = when (repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }; player.repeatMode = repeat }) {
                            Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, null, tint = if (repeat != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                        }
                        Text(tr("قائمة التشغيل (${MediaTools.queue.size})", "Queue (${MediaTools.queue.size})"), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                        TextButton(onClick = { queueOpen = !queueOpen }) { Text(if (queueOpen) tr("إخفاء", "Hide") else tr("عرض", "Show")) }
                    }
                    if (queueOpen) MediaTools.queue.forEachIndexed { i, t ->
                        Text((if (t.name == nowTitle) "▶ " else "${i + 1}. ") + t.name, Modifier.fillMaxWidth().clickable { player.seekTo(i, 0L) }.padding(vertical = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (t.name == nowTitle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                }
                err?.let { e ->
                    Card(colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.1f))) {
                        Column(Modifier.padding(12.dp)) {
                            Text(tr("تعذر التشغيل", "Playback failed"), fontWeight = FontWeight.Bold, color = DangerRed)
                            Text(e, style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), if (url.contains("audio", true)) "audio/*" else "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }) { Text(tr("فتح بتطبيق آخر", "Open with another app")) }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(lockLandscape, { lockLandscape = !lockLandscape }, label = { Text(tr("ملء الشاشة بالعرض", "Landscape fullscreen")) })
                    AssistChip({ full = true }, label = { Text(tr("ملء الشاشة", "Fullscreen")) }, leadingIcon = { Icon(Icons.Filled.Fullscreen, null) })
                }
                Text(tr("🎛️ الجودة 🎧 الصوت والسرعة والترجمة من الأزرار أعلى الفيديو. ⏺ لتسجيل الشاشة.", "🎛️ Quality 🎧 audio/speed/subtitles from the buttons on the video. ⏺ to record."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// =============================== متصفح المشاهدة (يوتيوب…) ===============================
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebWatchScreen(nav: NavController, url: String, title: String) {
    val ctx = LocalContext.current
    val act = remember { ctx.findActivity() }
    var web by remember { mutableStateOf<WebView?>(null) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customCb by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var pageTitle by remember { mutableStateOf(title) }
    DisposableEffect(Unit) { onDispose { web?.destroy(); setFullscreen(act, false) } }
    BackHandler {
        when { customView != null -> { customCb?.onCustomViewHidden(); customView = null; setFullscreen(act, false) }; web?.canGoBack() == true -> web?.goBack(); else -> nav.popBackStack() }
    }
    val cv = customView
    if (cv != null) {
        AndroidView(factory = { c -> FrameLayout(c).apply { setBackgroundColor(android.graphics.Color.BLACK); (cv.parent as? ViewGroup)?.removeView(cv); addView(cv, FrameLayout.LayoutParams(-1, -1)) } }, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopEnd) { RecordButton(Color.White) }
        return
    }
    ScreenScaffold(title = pageTitle.ifBlank { tr("مشاهدة", "Watch") }, onBack = { nav.popBackStack() }, actions = {
        RecordButton()
        IconButton(onClick = { web?.reload() }) { Icon(Icons.Filled.Refresh, null) }
        IconButton(onClick = { Share.openUrl(ctx, web?.url ?: url) }) { Icon(Icons.Filled.OpenInBrowser, null) }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            AndroidView(factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.mediaPlaybackRequiresUserGesture = false
                    settings.loadWithOverviewMode = true; settings.useWideViewPort = true
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                            val u = req.url.toString()
                            if (u.startsWith("http")) return false
                            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, req.url)) }
                            return true
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, p: Int) { progress = p }
                        override fun onReceivedTitle(view: WebView?, t: String?) { if (!t.isNullOrBlank()) pageTitle = t }
                        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) { customView = view; customCb = callback; setFullscreen(act, true) }
                        override fun onHideCustomView() { customView = null; setFullscreen(act, false) }
                    }
                    loadUrl(url)
                    web = this
                }
            }, modifier = Modifier.fillMaxSize())
        }
    }
}

// =============================== شاشة العرض (الوسائط) ===============================
@Composable
fun MediaHubScreen(nav: NavController) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val pickLocal = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = runCatching { ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: ""
            val recent = (listOf(name + "|" + uri) + Extras.s("media_recent", "").split("\n").filter { it.isNotBlank() && !it.endsWith("|$uri") }).take(15)
            Extras.ps("media_recent", recent.joinToString("\n"))
            MediaTools.queue.clear()
            nav.openPlayer(uri.toString(), name)
        }
    }
    ScreenScaffold(title = tr("شاشة العرض", "Media screen"), onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { nav.navigate("media_tools") }) { Icon(Icons.Filled.ContentCut, contentDescription = tr("أدوات الفيديو", "Video tools")) }
        RecordButton()
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(tab, edgePadding = 8.dp) {
                listOf(tr("ملفاتي", "My files"), tr("القنوات", "Channels"), tr("أفلام ومسلسلات", "Movies & series"), tr("الأطفال", "Kids"), tr("يوتيوب", "YouTube"), tr("أين أشاهده؟", "Where to watch"), tr("روابطي", "My links")).forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> LocalMediaTab(nav, pickLocal = { pickLocal.launch(arrayOf("video/*", "audio/*", "application/x-mpegURL", "application/vnd.apple.mpegurl")) })
                1 -> ChannelsTab(nav)
                2 -> ArchiveTab(nav, kids = false)
                3 -> ArchiveTab(nav, kids = true)
                4 -> SearchLinkTab(tr("ابحث في يوتيوب (أفلام، مسلسلات، إعلانات، ملخصات)", "Search YouTube"), { q -> MediaLib.youtube(q) }) { nav.openWeb(it, tr("يوتيوب", "YouTube")) }
                5 -> SearchLinkTab(tr("اكتب اسم فيلم أو مسلسل لمعرفة المنصات الرسمية التي تعرضه", "Type a title to see official platforms"), { q -> MediaLib.whereToWatch(q, if (AppState.lang.value == "ar") "eg" else "us") }, extra = {
                    Text(tr("يعرض JustWatch المنصات القانونية (نتفليكس، شاهد، واتش إت، OSN+، أمازون…) والسعر.", "JustWatch lists legal platforms and prices."), style = MaterialTheme.typography.bodySmall)
                }) { nav.openWeb(it, tr("أين أشاهده؟", "Where to watch")) }
                else -> MyLinksTab(nav)
            }
        }
    }
}

@Composable
private fun SearchLinkTab(hint: String, build: (String) -> String, extra: @Composable () -> Unit = {}, open: (String) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(hint, style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(q, { q = it }, label = { Text(tr("بحث", "Search")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), trailingIcon = { MicButton { q = it } })
        Button(onClick = { if (q.isNotBlank()) open(build(q.trim())) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Search, null); Spacer(Modifier.width(6.dp)); Text(tr("بحث", "Search")) }
        extra()
    }
}

@Composable
private fun ArchiveTab(nav: NavController, kids: Boolean) {
    var q by rememberSaveable(kids) { mutableStateOf("") }
    var col by rememberSaveable(kids) { mutableStateOf(if (kids) "classic_cartoons" else "feature_films") }
    var res by remember { mutableStateOf<List<MediaLib.Item>?>(null) }
    var trigger by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<MediaLib.Item?>(null) }
    LaunchedEffect(col, trigger) { res = null; res = withContext(Dispatchers.IO) { MediaLib.search(q.trim(), col) } }
    val cats = MediaLib.categories.filter { if (kids) it.key in MediaLib.kidsCollections else true }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(q, { q = it }, label = { Text(tr("ابحث بالاسم (بالإنجليزية غالباً)", "Search by title")) }, singleLine = true, modifier = Modifier.weight(1f), trailingIcon = { MicButton { q = it; trigger++ } })
                IconButton(onClick = { trigger++ }) { Icon(Icons.Filled.Search, null) }
            }
        }
        item { HChips { cats.forEach { c -> FilterChip(col == c.key, { col = c.key }, label = { Text(c.emoji + " " + c.label) }) } } }
        if (kids) item {
            Text(tr("قنوات أطفال على يوتيوب:", "Kids channels on YouTube:"), style = MaterialTheme.typography.labelLarge)
            HChips { MediaLib.kidsChannels.forEach { (n, u) -> AssistChip({ nav.openWeb(u, n) }, label = { Text(n) }) } }
        }
        item { Text(tr("محتوى مجاني قانوني من Internet Archive (ملكية عامة).", "Free, legal content from the Internet Archive (public domain)."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        val list = res
        if (list == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        else if (list.isEmpty()) item { Text(tr("لا نتائج", "No results")) }
        else items(list, key = { it.id }) { m ->
            Card(onClick = { open = m }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    UrlImage(m.thumb, Modifier.size(width = 96.dp, height = 64.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (m.year.isNotBlank()) Text(m.year, style = MaterialTheme.typography.labelSmall)
                        Text(m.desc, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
    open?.let { m ->
        var files by remember(m.id) { mutableStateOf<List<MediaLib.FileOpt>?>(null) }
        LaunchedEffect(m.id) { files = withContext(Dispatchers.IO) { MediaLib.files(m.id) } }
        AlertDialog(onDismissRequest = { open = null }, title = { Text(m.title) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(m.desc, style = MaterialTheme.typography.bodySmall, maxLines = 5, overflow = TextOverflow.Ellipsis)
                val f = files
                if (f == null) CircularProgressIndicator()
                else if (f.isEmpty()) Text(tr("لا توجد ملفات فيديو قابلة للتشغيل", "No playable video files"))
                else f.take(8).forEachIndexed { i, x ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { open = null; nav.openPlayer(x.url, m.title) }, modifier = Modifier.weight(1f)) {
                            Text(tr("▶ مصدر ${i + 1}", "▶ Source ${i + 1}") + " • " + x.label + (if (x.size > 0) " • " + (x.size / 1_048_576) + "MB" else ""), maxLines = 1)
                        }
                        val c2 = LocalContext.current
                        IconButton(onClick = { toast(c2, if (MediaLib.download(c2, x.url, m.title)) tr("⬇️ بدأ التنزيل إلى Movies/Sho3eb", "⬇️ Downloading to Movies/Sho3eb") else tr("لا يمكن تنزيل هذا المصدر", "This source can't be downloaded")) }) { Icon(Icons.Filled.Download, contentDescription = tr("تنزيل", "Download")) }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { open = null }) { Text(tr("إغلاق", "Close")) } })
    }
}

@Composable
fun MyLinksTab(nav: NavController) {
    var list by remember { mutableStateOf(Football.userStreams()) }
    var add by remember { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(tr("أضف روابط بث قانونية تملكها (اشتراكك أو قناة مجانية مرخصة) بصيغة m3u8 أو mpd أو mp4 لتشغيلها في المشغل الداخلي.", "Add legal stream links you own (m3u8, mpd, mp4)."), style = MaterialTheme.typography.bodySmall) }
        item { Button(onClick = { add = true }) { Icon(Icons.Filled.AddLink, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة رابط", "Add link")) } }
        items(list.size) { i ->
            val s = list[i]
            Card(onClick = { nav.openPlayer(s.url, s.name) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("رابط ${i + 1}", "Link ${i + 1}"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(s.name, Modifier.weight(1f), maxLines = 1)
                    IconButton(onClick = { list = list.filterIndexed { k, _ -> k != i }; Football.saveUserStreams(list) }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                }
            }
        }
    }
    if (add) {
        var n by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { add = false }, title = { Text(tr("رابط بث", "Stream link")) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true)
                OutlinedTextField(u, { u = it.trim() }, label = { Text("URL") }, singleLine = true)
            }
        }, confirmButton = { TextButton(onClick = { if (u.startsWith("http")) { list = list + Football.UserStream(n.ifBlank { u.take(30) }, u); Football.saveUserStreams(list); add = false } }) { Text(tr("حفظ", "Save")) } },
            dismissButton = { TextButton(onClick = { add = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
}

/** صورة من رابط مع تخزين مؤقت (للشعارات والصور المصغرة) */
@Composable
fun UrlImage(url: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, url) {
        value = if (url.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val f = java.io.File(java.io.File(ctx.cacheDir, "img2").apply { mkdirs() }, url.hashCode().toString())
                if (!f.exists() || f.length() == 0L) {
                    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 10000; c.readTimeout = 15000; c.setRequestProperty("User-Agent", "Mozilla/5.0")
                    c.inputStream.use { i -> f.outputStream().use { i.copyTo(it) } }
                }
                android.graphics.BitmapFactory.decodeFile(f.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = if (f.length() > 300_000) 2 else 1 })
            }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) androidx.compose.foundation.Image(b.asImageBitmap(), null, modifier, contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    else Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.small))
}


@Composable
private fun LocalMediaTab(nav: NavController, pickLocal: () -> Unit) {
    val ctx = LocalContext.current
    var folders by remember { mutableStateOf(MediaTools.folders) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var files by remember { mutableStateOf<List<MediaTools.Track>>(emptyList()) }
    var pls by remember { mutableStateOf(MediaTools.playlists()) }
    var newPl by remember { mutableStateOf(false) }
    var addTo by remember { mutableStateOf<MediaTools.Track?>(null) }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            folders = (listOf(uri.toString()) + folders.filter { it != uri.toString() }).take(10); MediaTools.folders = folders
            openFolder = uri.toString()
        }
    }
    LaunchedEffect(openFolder) { files = openFolder?.let { f -> withContext(Dispatchers.IO) { MediaTools.folder(ctx, Uri.parse(f)) } } ?: emptyList() }
    fun playQueue(list: List<MediaTools.Track>, start: Int) { MediaTools.queue.clear(); MediaTools.queue.addAll(list); MediaTools.queueStart = start; nav.openPlayer("queue", list.getOrNull(start)?.name ?: "") }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = pickLocal, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.VideoFile, null); Spacer(Modifier.width(4.dp)); Text(tr("فتح ملف", "Open file")) }
                OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text(tr("فتح مجلد", "Open folder")) }
            }
        }
        item { Text(tr("فتح مجلد يشغّل ملفاته كقائمة تشغيل وينتقل للملف التالي تلقائياً. يدعم: MP4، MKV، WEBM، AVI، MOV، 3GP، TS، FLV، MP3، AAC، M4A، FLAC، OGG، OPUS، WAV، AMR، وبث HLS/DASH.", "Opening a folder plays its files as a playlist with auto-next. Supports MP4, MKV, WEBM, AVI, MOV, 3GP, TS, FLV, MP3, AAC, M4A, FLAC, OGG, OPUS, WAV, AMR, HLS/DASH."), style = MaterialTheme.typography.bodySmall) }
        val of = openFolder
        if (of != null) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("📂 " + (Uri.parse(of).lastPathSegment?.substringAfterLast(':') ?: ""), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    if (files.isNotEmpty()) Button(onClick = { playQueue(files, 0) }) { Icon(Icons.Filled.PlayArrow, null); Text(tr("تشغيل الكل", "Play all")) }
                    IconButton(onClick = { openFolder = null }) { Icon(Icons.Filled.Close, null) }
                }
            }
            if (files.isEmpty()) item { Text(tr("لا توجد ملفات وسائط في هذا المجلد", "No media files in this folder")) }
            items(files.size) { i ->
                val t = files[i]
                Card(onClick = { playQueue(files, i) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (MediaTools.isMedia(t.name, null) && t.name.substringAfterLast('.').lowercase() in setOf("mp3", "aac", "m4a", "flac", "ogg", "opus", "wav", "amr", "wma")) Icons.Filled.MusicNote else Icons.Filled.Movie, null, tint = MaterialTheme.colorScheme.primary)
                        Text(t.name, Modifier.weight(1f).padding(horizontal = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = { addTo = t }) { Icon(Icons.Filled.PlaylistAdd, null) }
                    }
                }
            }
        }
        if (folders.isNotEmpty() && of == null) {
            item { SectionTitle(tr("مجلداتي", "My folders")) }
            items(folders) { f ->
                Card(onClick = { openFolder = f }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary)
                        Text(Uri.parse(f).lastPathSegment?.substringAfterLast(':')?.ifBlank { "/" } ?: f, Modifier.weight(1f).padding(horizontal = 8.dp), maxLines = 1)
                        IconButton(onClick = { folders = folders - f; MediaTools.folders = folders }) { Icon(Icons.Filled.Close, null) }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(tr("قوائم التشغيل", "Playlists"), Modifier.weight(1f))
                TextButton(onClick = { newPl = true }) { Icon(Icons.Filled.Add, null); Text(tr("قائمة جديدة", "New playlist")) }
            }
        }
        if (pls.isEmpty()) item { Text(tr("أنشئ قائمة ثم أضف إليها الملفات بزر ➕ بجانب كل ملف.", "Create a playlist, then add files with ➕."), style = MaterialTheme.typography.bodySmall) }
        items(pls.size) { i ->
            val p = pls[i]
            Card(onClick = { if (p.items.isNotEmpty()) playQueue(p.items, 0) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.QueueMusic, null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) { Text(p.name, fontWeight = FontWeight.Bold); Text(tr("${p.items.size} ملف", "${p.items.size} files"), style = MaterialTheme.typography.labelSmall) }
                    IconButton(onClick = { pls = pls.filterIndexed { k, _ -> k != i }; MediaTools.savePlaylists(pls) }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                }
            }
        }
        val recent = Extras.s("media_recent", "").split("\n").filter { it.contains("|") }
        if (recent.isNotEmpty()) item { SectionTitle(tr("فُتحت مؤخراً", "Recently opened")) }
        items(recent) { r ->
            val (n, u) = r.substringBefore("|") to r.substringAfter("|")
            Card(onClick = { MediaTools.queue.clear(); nav.openPlayer(u, n) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.PlayCircle, null, tint = MaterialTheme.colorScheme.primary)
                    Text(n.ifBlank { u }, Modifier.weight(1f).padding(horizontal = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    IconButton(onClick = { addTo = MediaTools.Track(n, u) }) { Icon(Icons.Filled.PlaylistAdd, null) }
                }
            }
        }
    }
    if (newPl) {
        var n by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { newPl = false }, title = { Text(tr("قائمة تشغيل جديدة", "New playlist")) }, text = { OutlinedTextField(n, { n = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (n.isNotBlank()) { pls = pls + MediaTools.Playlist(n.trim(), emptyList()); MediaTools.savePlaylists(pls); newPl = false } }) { Text(tr("إنشاء", "Create")) } },
            dismissButton = { TextButton(onClick = { newPl = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
    addTo?.let { t ->
        AlertDialog(onDismissRequest = { addTo = null }, title = { Text(tr("إضافة إلى قائمة", "Add to playlist")) }, text = {
            Column {
                if (pls.isEmpty()) Text(tr("أنشئ قائمة أولاً", "Create a playlist first"))
                pls.forEachIndexed { i, p -> TextButton(onClick = { pls = pls.mapIndexed { k, x -> if (k == i) x.copy(items = x.items + t) else x }; MediaTools.savePlaylists(pls); addTo = null; toast(ctx, tr("أُضيف ✅", "Added ✅")) }) { Text(p.name) } }
            }
        }, confirmButton = { TextButton(onClick = { addTo = null }) { Text(tr("إغلاق", "Close")) } })
    }
}
