package com.sho3eb.app.core

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.LivEntry
import com.sho3eb.app.data.LivPeriod
import java.time.LocalDate
import java.util.concurrent.TimeUnit
import kotlin.math.min

/** الميزانيات والتنبيه عند تجاوزها، والإضافة التلقائية للمصروفات المتكررة */
object LivingAuto {

    data class BudgetState(val category: String, val budget: Double, val spent: Double) {
        val ratio get() = if (budget > 0) spent / budget else 0.0
        val left get() = budget - spent
    }

    fun monthRange(d: LocalDate = LocalDate.now()) = d.withDayOfMonth(1).toEpochDay()..d.withDayOfMonth(d.lengthOfMonth()).toEpochDay()

    fun budgetStates(entries: List<LivEntry>, d: LocalDate = LocalDate.now()): List<BudgetState> {
        val r = monthRange(d)
        val spent = entries.filter { it.kind == Living.EXPENSE && it.date in r }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
        return Extras.budgets.map { (c, b) -> BudgetState(c, b, spent[c] ?: 0.0) }.sortedByDescending { it.ratio }
    }

    /** يُستدعى بعد إضافة مصروف: تنبيه عند 80% وعند التجاوز */
    suspend fun checkBudget(ctx: Context, category: String) {
        if (!Extras.budgetAlerts) return
        val budget = Extras.budgets[category] ?: return
        val dao = appDao()
        val now = LocalDate.now()
        val r = monthRange(now)
        val spent = dao.allLivEntries().filter { it.kind == Living.EXPENSE && it.category == category && it.date in r }.sumOf { it.amount }
        val key = "budAl_${category}_${now.year * 100 + now.monthValue}"
        val prev = Extras.i(key, 0)
        val level = when { spent > budget -> 100; spent >= budget * 0.8 -> 80; else -> 0 }
        if (level > prev) {
            Extras.pi(key, level)
            val c = Living.cat(Living.EXPENSE, category)
            if (level == 100) Notifier.show(
                ctx, 5100 + category.hashCode() % 500, tr("⚠️ تجاوزت ميزانية ${c.label}", "⚠️ ${c.label} budget exceeded"),
                tr("صرفت ${Fmt.money(spent)} من ميزانية ${Fmt.money(budget)} هذا الشهر (زيادة ${Fmt.money(spent - budget)}).", "Spent ${Fmt.money(spent)} of ${Fmt.money(budget)} this month.")
            ) else Notifier.show(
                ctx, 5100 + category.hashCode() % 500, tr("${c.emoji} اقتربت من حد ميزانية ${c.label}", "${c.emoji} Near ${c.label} budget"),
                tr("صرفت ${(spent / budget * 100).toInt()}% من ميزانية الشهر. المتبقي ${Fmt.money(budget - spent)}.", "Used ${(spent / budget * 100).toInt()}% of the monthly budget. Left ${Fmt.money(budget - spent)}.")
            )
        }
    }

    /** الإضافة التلقائية للمصروفات/الدخل المتكرر + التذكير قبلها بيوم */
    suspend fun runRecurring(ctx: Context) {
        val dao = appDao()
        val items = dao.allLivItems().filter { it.autoDay > 0 }
        if (items.isEmpty()) return
        val today = LocalDate.now()
        val ym = today.year * 100 + today.monthValue
        val dom = today.dayOfMonth
        var periods = dao.allLivPeriods()
        val added = mutableListOf<String>()
        for (item in items) {
            val day = min(item.autoDay, today.lengthOfMonth())
            // تذكير قبل الموعد بيوم
            if (dom == day - 1 && Extras.recurringNotify) {
                val rk = "recRem_${item.id}_$ym"
                if (!Extras.b(rk, false)) {
                    Extras.pb(rk, true)
                    Notifier.show(ctx, 5600 + (item.id % 300).toInt(), tr("⏰ غداً موعد: ${item.name}", "⏰ Due tomorrow: ${item.name}"),
                        tr("سيُسجَّل تلقائياً ${Fmt.money(item.amount)} في مصاريف المعيشة.", "${Fmt.money(item.amount)} will be recorded automatically."))
                }
            }
            if (dom < day) continue
            val dueDay = today.withDayOfMonth(day).toEpochDay()
            var period: LivPeriod? = periods.firstOrNull { dueDay in it.startDate..it.endDate }
            if (period == null) {
                if (!Extras.autoCreateMonth) continue
                val p = LivPeriod(name = Living.monthTitle(today), startDate = today.withDayOfMonth(1).toEpochDay(), endDate = today.withDayOfMonth(today.lengthOfMonth()).toEpochDay())
                val id = dao.insertLivPeriod(p)
                period = p.copy(id = id)
                periods = periods + period
            }
            val existing = dao.livEntriesOnce(period.id).any { it.itemId == item.id && it.date in monthRange(today) }
            if (existing) continue
            val amount = if (item.freq == "MONTH") item.amount else Living.forDays(item.amount, item.freq, Living.days(period))
            dao.insertLivEntry(
                LivEntry(
                    periodId = period.id, kind = item.kind, itemId = item.id, name = item.name, category = item.category,
                    priority = item.priority, amount = amount, date = dueDay, note = tr("إضافة تلقائية", "Auto-added")
                )
            )
            added += item.name + " (" + Fmt.money(amount) + ")"
            if (item.kind == Living.EXPENSE) checkBudget(ctx, item.category)
        }
        if (added.isNotEmpty() && Extras.recurringNotify) Notifier.show(
            ctx, 5599, tr("✅ تمت إضافة بنود متكررة", "✅ Recurring items added"),
            tr("أُضيف تلقائياً إلى مصاريف المعيشة:\n", "Automatically added:\n") + added.joinToString("\n")
        )
    }
}

class LivingWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        AppState.lang.value = Sho3ebApp.instance.prefs.lang
        try { LivingAuto.runRecurring(applicationContext) } catch (_: Exception) {}
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val wm = WorkManager.getInstance(ctx)
            wm.enqueueUniquePeriodicWork("sho3eb_living", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<LivingWorker>(6, TimeUnit.HOURS).build())
            wm.enqueueUniqueWork("sho3eb_living_now", ExistingWorkPolicy.REPLACE, OneTimeWorkRequestBuilder<LivingWorker>().build())
        }
    }
}
