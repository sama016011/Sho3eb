package com.sho3eb.app.core.chat

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.sho3eb.app.R
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.core.tr
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

/** إشارات المكالمات الصوتية والمرئية عبر الإنترنت (WebRTC) */
object CallBus {
    const val CH = "sho3eb_calls_ring"
    /** قناة الإشعار حسب النغمة المختارة (قنوات أندرويد لا يتغير صوتها بعد إنشائها) */
    fun channel(ctx: Context): String {
        val tone = Chat.callRingtone
        val vib = Chat.callVibrate
        val id = if (tone.isBlank() && vib) CH else CH + "_" + Integer.toHexString((tone + vib).hashCode())
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(android.app.NotificationManager::class.java)
            if (nm.getNotificationChannel(id) == null) {
                nm.notificationChannels.filter { it.id.startsWith(CH + "_") && it.id != id }.forEach { runCatching { nm.deleteNotificationChannel(it.id) } }
                val uri = tone.takeIf { it.isNotBlank() }?.let { android.net.Uri.parse(it) } ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE)
                nm.createNotificationChannel(android.app.NotificationChannel(id, tr("المكالمات الواردة", "Incoming calls"), android.app.NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(uri, android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    enableVibration(vib); if (vib) vibrationPattern = longArrayOf(0, 800, 600, 800, 600, 800)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                })
            }
        }
        return id
    }
    private val handledCalls = java.util.Collections.synchronizedSet(HashSet<String>())
    data class Sig(val type: String, val callId: String, val sender: String, val payload: String, val id: Long)

    val flow = MutableSharedFlow<Sig>(extraBufferCapacity = 128)
    @Volatile var activeCall: String? = null
    private val seen = java.util.Collections.synchronizedSet(HashSet<Long>())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun newCallId() = UUID.randomUUID().toString()

    @Volatile var lastSendError = ""
    fun send(to: String, callId: String, type: String, payload: String = "", onResult: ((String?) -> Unit)? = null) {
        scope.launch {
            val r = runCatching { sendNow(to, callId, type, payload) }
            lastSendError = r.exceptionOrNull()?.message ?: ""
            onResult?.invoke(r.exceptionOrNull()?.message)
        }
    }
    fun sendNow(to: String, callId: String, type: String, payload: String = "") =
        Supa.insert("signals", JSONObject().put("sender", Supa.uid).put("recipient", to).put("call_id", callId).put("type", type).put("payload", payload))

    /** إشارة قادمة من الاتصال اللحظي أو الاستطلاع */
    fun onSignal(r: JSONObject) {
        val id = r.optLong("id")
        if (!seen.add(id)) return
        val s = Sig(r.optString("type"), r.optString("call_id"), r.optString("sender"), r.optString("payload").takeIf { it != "null" } ?: "", id)
        if (s.type == "ring") {
            val age = System.currentTimeMillis() - Chat.ts(r.optString("created_at"))
            if (age > 90_000) return
            if (s.sender == Supa.uid) { if (s.callId.startsWith("test-")) flow.tryEmit(s); return }
            if (!handledCalls.add(s.callId)) return          // الرنين يُعاد إرساله؛ نعرضه مرة واحدة
            if (!Chat.canCall(s.sender)) { send(s.sender, s.callId, "reject", "blocked"); return }
            val cur = activeCall
            if (cur != null && cur != s.callId) { send(s.sender, s.callId, "busy"); return }
            incoming(Sho3ebApp.instance, s)
        } else flow.tryEmit(s)
    }

    /** استطلاع احتياطي أثناء المكالمة */
    fun poll(callId: String, after: Long): Long {
        var last = after
        runCatching {
            val a = Supa.select("signals?select=*&recipient=eq.${Supa.uid}&call_id=eq.$callId&id=gt.$after&order=id.asc")
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); last = maxOf(last, o.optLong("id")); onSignal(o) }
        }
        return last
    }

    private fun incoming(ctx: Context, s: Sig) {
        val video = runCatching { JSONObject(s.payload).optBoolean("video") }.getOrDefault(false)
        val i = Intent(ctx, com.sho3eb.app.ui.CallActivity::class.java)
            .putExtra("peer", s.sender).putExtra("call", s.callId).putExtra("video", video).putExtra("incoming", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        val pi = PendingIntent.getActivity(ctx, s.callId.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val name = Chat.nameOf(s.sender)
        val n = NotificationCompat.Builder(ctx, channel(ctx)).setSmallIcon(R.drawable.ic_notification)
            .setContentTitle((if (video) "📹 " else "📞 ") + name).setContentText(if (video) tr("مكالمة فيديو واردة", "Incoming video call") else tr("مكالمة صوتية واردة", "Incoming voice call"))
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_CALL).setFullScreenIntent(pi, true).setContentIntent(pi)
            .setOngoing(true).setAutoCancel(true).setTimeoutAfter(45_000).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, tr("رد", "Answer"), pi).build()
        runCatching { NotificationManagerCompat.from(ctx).notify(s.callId.hashCode(), n) }
        runCatching { ctx.startActivity(i) }  // يعمل في المقدمة أو مع إذن الظهور فوق التطبيقات؛ وإلا يبقى الإشعار بملء الشاشة
    }

    fun cancelNotification(ctx: Context, callId: String) = runCatching { NotificationManagerCompat.from(ctx).cancel(callId.hashCode()) }

    /** بدء مكالمة صادرة */
    fun call(ctx: Context, peer: String, video: Boolean) {
        ctx.startActivity(Intent(ctx, com.sho3eb.app.ui.CallActivity::class.java).putExtra("peer", peer).putExtra("call", newCallId()).putExtra("video", video).putExtra("incoming", false).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun iceServers(): String = org.json.JSONArray()
        .put(JSONObject().put("urls", org.json.JSONArray().put("stun:stun.l.google.com:19302").put("stun:stun1.l.google.com:19302")))
        .apply {
            if (Chat.turnUrl.isNotBlank()) {
                val urls = org.json.JSONArray(); Chat.turnUrl.split(",", " ", "\n").filter { it.isNotBlank() }.forEach { urls.put(it.trim()) }
                if (Chat.turnUrl.contains("openrelay")) urls.put("turn:openrelay.metered.ca:80").put("turn:openrelay.metered.ca:443")
                put(JSONObject().put("urls", urls).put("username", Chat.turnUser).put("credential", Chat.turnPass))
            }
        }.toString()
}
