@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.delay

private fun fmtMs(ms: Long): String { val s = ms / 1000; return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60) else String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60) }

@Composable
fun MediaToolsScreen(nav: NavController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    ScreenScaffold(title = tr("أدوات الفيديو والصوت", "Video & audio tools"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("قص / استخراج صوت", "Trim / extract audio")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("🎬 محرر الفيديو", "🎬 Video editor")) })
            }
            when (tab) { 0 -> TrimTab(nav); else -> EditorLauncher(nav) }
        }
    }
}

/** حالة التصدير المشتركة */
@Composable
private fun ExportBar(job: MediaTools.Job?, result: Pair<Uri?, String?>?, nav: NavController, audio: Boolean, onClear: () -> Unit) {
    var prog by remember(job) { mutableIntStateOf(0) }
    LaunchedEffect(job, result) { while (job != null && result == null) { prog = MediaTools.progress(job).coerceAtLeast(0); delay(400) } }
    if (job != null && result == null) Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(tr("⏳ جارٍ التصدير… $prog%", "⏳ Exporting… $prog%"), fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = { prog / 100f }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
            TextButton(onClick = { runCatching { job.transformer.cancel() }; onClear() }) { Text(tr("إلغاء", "Cancel"), color = DangerRed) }
        }
    }
    result?.let { (uri, err) ->
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = (if (uri != null) SuccessGreen else DangerRed).copy(alpha = 0.12f))) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (uri != null) {
                    Text(tr("✅ تم الحفظ في المعرض: ", "✅ Saved to gallery: ") + (if (audio) "Music/Sho3eb" else "Movies/Sho3eb"), fontWeight = FontWeight.Bold, color = SuccessGreen)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { MediaTools.queue.clear(); nav.openPlayer(uri.toString(), tr("الناتج", "Output")) }) { Icon(Icons.Filled.PlayArrow, null); Text(tr("تشغيل", "Play")) }
                        val ctx = LocalContext.current
                        OutlinedButton(onClick = { runCatching { ctx.startActivity(android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_SEND).setType(if (audio) "audio/*" else "video/*").putExtra(android.content.Intent.EXTRA_STREAM, uri).addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION), null)) } }) { Icon(Icons.Filled.Share, null); Text(tr("مشاركة", "Share")) }
                    }
                } else Text(tr("❌ فشل التصدير: ", "❌ Export failed: ") + (err ?: ""), color = DangerRed)
                TextButton(onClick = onClear) { Text(tr("حسناً", "OK")) }
            }
        }
    }
}

@Composable
private fun FxPicker(fx: MediaTools.Fx, showMotion: Boolean, onFx: (MediaTools.Fx) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tr("✨ المؤثرات", "✨ Effects"), fontWeight = FontWeight.Bold)
            Text(tr("فلتر الألوان", "Color filter"), style = MaterialTheme.typography.labelLarge)
            HChips { MediaTools.filters.forEach { f -> FilterChip(fx.filter == f.key, { onFx(fx.copy(filter = f.key)) }, label = { Text(f.emoji + " " + f.label) }) } }
            if (showMotion) {
                Text(tr("الحركة", "Motion"), style = MaterialTheme.typography.labelLarge)
                HChips { MediaTools.motions.forEach { f -> FilterChip(fx.motion == f.key, { onFx(fx.copy(motion = f.key)) }, label = { Text(f.emoji + " " + f.label) }) } }
            }
            SwitchRow(tr("ظهور واختفاء تدريجي (Fade)", "Fade in/out"), null, fx.fade) { onFx(fx.copy(fade = it)) }
            Text(tr("السطوع ", "Brightness ") + "${(fx.brightness * 100).toInt()}", style = MaterialTheme.typography.labelLarge)
            Slider(fx.brightness, { onFx(fx.copy(brightness = it)) }, valueRange = -0.5f..0.5f)
            Text(tr("التباين ", "Contrast ") + "${(fx.contrast * 100).toInt()}", style = MaterialTheme.typography.labelLarge)
            Slider(fx.contrast, { onFx(fx.copy(contrast = it)) }, valueRange = -0.5f..0.5f)
            OutlinedTextField(fx.title, { onFx(fx.copy(title = it)) }, label = { Text(tr("نص / عنوان على الفيديو (اختياري)", "Text / title overlay (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun TrimTab(nav: NavController) {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var dur by remember { mutableLongStateOf(0L) }
    var range by remember { mutableStateOf(0f..1f) }
    var audioOnly by remember { mutableStateOf(false) }
    var fx by remember { mutableStateOf(MediaTools.Fx(fade = false)) }
    var job by remember { mutableStateOf<MediaTools.Job?>(null) }
    var result by remember { mutableStateOf<Pair<Uri?, String?>?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u; name = MediaTools.nameOf(ctx, u); range = 0f..1f; result = null
            dur = runCatching { val r = MediaMetadataRetriever(); try { r.setDataSource(ctx, u); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L } finally { r.release() } }.getOrDefault(0L)
        }
    }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { pick.launch(arrayOf("video/*", "audio/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.VideoFile, null); Spacer(Modifier.width(6.dp)); Text(if (uri == null) tr("اختر فيديو أو ملف صوت", "Choose a video or audio") else name) }
        val u = uri
        if (u != null) {
            if (dur > 0) {
                Text(tr("المدة: ", "Duration: ") + fmtMs(dur), style = MaterialTheme.typography.bodySmall)
                RangeSlider(range, { range = it }, valueRange = 0f..1f)
                Row { Text(tr("من ", "From ") + fmtMs((range.start * dur).toLong()), Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(tr("إلى ", "To ") + fmtMs((range.endInclusive * dur).toLong()), fontWeight = FontWeight.Bold) }
                Text(tr("طول الجزء: ", "Clip length: ") + fmtMs(((range.endInclusive - range.start) * dur).toLong()), style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = { MediaTools.queue.clear(); nav.openPlayer(u.toString(), name) }) { Icon(Icons.Filled.PlayArrow, null); Text(tr("معاينة الأصل", "Preview original")) }
            SwitchRow(tr("🎵 استخراج الصوت فقط (M4A)", "🎵 Extract audio only (M4A)"), tr("يحذف الصورة ويحفظ الصوت في Music/Sho3eb", "Drops video, saves audio to Music/Sho3eb"), audioOnly) { audioOnly = it }
            if (!audioOnly) FxPicker(fx, showMotion = false) { fx = it }
            Button(enabled = job == null || result != null, onClick = {
                result = null
                val start = (range.start * dur).toLong(); val end = if (dur > 0 && range.endInclusive < 0.999f) (range.endInclusive * dur).toLong() else -1L
                job = MediaTools.export(ctx, MediaTools.trimComposition(u, start, end, audioOnly, fx), audioOnly) { r, e -> result = r to e }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.ContentCut, null); Spacer(Modifier.width(6.dp)); Text(if (audioOnly) tr("استخراج الصوت", "Extract audio") else tr("قص وتصدير", "Trim & export")) }
            ExportBar(job, result, nav, audioOnly) { job = null; result = null }
        }
        Text(tr("التصدير يتم على الجهاز ويُحفظ الناتج في المعرض. الصيغ: MP4 (H.264/AAC) للفيديو و M4A للصوت.", "Processing is on-device; output saved to gallery as MP4 (H.264/AAC) or M4A."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SlideshowTab(nav: NavController) {
    val ctx = LocalContext.current
    val images = remember { mutableStateListOf<Uri>() }
    var audio by remember { mutableStateOf<Uri?>(null) }
    var secs by remember { mutableIntStateOf(4) }
    var loop by remember { mutableStateOf(false) }
    var landscape by remember { mutableStateOf(true) }
    var fx by remember { mutableStateOf(MediaTools.Fx(motion = "ZOOM_IN", fade = true)) }
    var job by remember { mutableStateOf<MediaTools.Job?>(null) }
    var result by remember { mutableStateOf<Pair<Uri?, String?>?>(null) }
    val pickImgs = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l -> images.addAll(l); result = null }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) audio = u }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { pickImgs.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة صور (${images.size})", "Add photos (${images.size})")) }
        images.forEachIndexed { i, u ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                UrlFileThumb(u, Modifier.size(56.dp))
                Text("  ${i + 1}. " + MediaTools.nameOf(ctx, u), Modifier.weight(1f), maxLines = 1)
                IconButton(onClick = { if (i > 0) images.add(i - 1, images.removeAt(i)) }, enabled = i > 0) { Icon(Icons.Filled.KeyboardArrowUp, null) }
                IconButton(onClick = { if (i < images.size - 1) images.add(i + 1, images.removeAt(i)) }, enabled = i < images.size - 1) { Icon(Icons.Filled.KeyboardArrowDown, null) }
                IconButton(onClick = { images.removeAt(i) }) { Icon(Icons.Filled.Close, null, tint = DangerRed) }
            }
        }
        OutlinedButton(onClick = { pickAudio.launch(arrayOf("audio/*", "video/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.MusicNote, null); Spacer(Modifier.width(6.dp)); Text(audio?.let { MediaTools.nameOf(ctx, it) } ?: tr("إضافة صوت أو موسيقى (اختياري)", "Add audio/music (optional)"), maxLines = 1) }
        if (audio != null) Row { SwitchRow(tr("تكرار الصوت حتى نهاية الصور", "Loop audio to the end"), null, loop) { loop = it } }
        Text(tr("مدة كل صورة: $secs ثانية", "Each photo: $secs s"), style = MaterialTheme.typography.labelLarge)
        Slider(secs.toFloat(), { secs = it.toInt() }, valueRange = 1f..15f, steps = 13)
        HChips {
            FilterChip(landscape, { landscape = true }, label = { Text(tr("🖥️ أفقي 16:9", "🖥️ Landscape 16:9")) })
            FilterChip(!landscape, { landscape = false }, label = { Text(tr("📱 طولي 9:16 (ريلز/ستوري)", "📱 Portrait 9:16 (reels)")) })
        }
        FxPicker(fx, showMotion = true) { fx = it }
        Text(tr("المدة الكلية: ", "Total: ") + fmtMs(images.size * secs * 1000L), style = MaterialTheme.typography.bodySmall)
        Button(enabled = images.isNotEmpty() && (job == null || result != null), onClick = {
            result = null
            job = MediaTools.export(ctx, MediaTools.slideshow(images.toList(), secs, audio, loop, landscape, fx), false) { r, e -> result = r to e }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Movie, null); Spacer(Modifier.width(6.dp)); Text(tr("إنشاء الفيديو", "Create video")) }
        ExportBar(job, result, nav, false) { job = null; result = null }
    }
}

@Composable
private fun UrlFileThumb(u: Uri, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, u) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = 8 }) } }.getOrNull() }
    }
    bmp?.let { androidx.compose.foundation.Image(it.asImageBitmap(), null, modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop) } ?: Box(modifier)
}

@Composable
private fun EditorLauncher(nav: NavController) {
    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("🎬", fontSize = androidx.compose.ui.unit.TextUnit(56f, androidx.compose.ui.unit.TextUnitType.Sp))
        Text(tr("محرر فيديو احترافي: نافذة معاينة، مساطر زمنية للصور والصوت والنصوص، قوالب مناسبات، مؤثرات وإطارات.", "Pro editor: live preview, timelines for media, audio and text, occasion templates, effects and frames."))
        Button(onClick = { nav.navigate("video_editor") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Movie, null); Spacer(Modifier.width(6.dp)); Text(tr("فتح محرر الفيديو", "Open video editor")) }
    }
}
