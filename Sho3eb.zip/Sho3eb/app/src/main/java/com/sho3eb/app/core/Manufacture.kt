package com.sho3eb.app.core

import com.sho3eb.app.data.*

/** التصنيع: وحدات القياس والتحويل، تكلفة المنتج، احتياج المواد، وتقارير الإنتاج */
object Manufacture {
    /** تصنيف الخامات الخاصة بالتصنيع (لا تظهر في أصناف المحل) */
    const val RAW_CAT = "__mfg_raw__"
    fun isRaw(p: Product) = p.category == RAW_CAT
    /** وحدة: الاسم، العائلة، المعامل بالنسبة لوحدة العائلة الأساسية */
    data class Unit(val key: String, val ar: String, val en: String, val family: String, val toBase: Double) { val label get() = tr(ar, en) }

    val units = listOf(
        Unit("kg", "كيلوجرام", "kg", "w", 1.0), Unit("g", "جرام", "g", "w", 0.001), Unit("mg", "مليجرام", "mg", "w", 0.000001),
        Unit("ton", "طن", "ton", "w", 1000.0), Unit("lb", "رطل", "lb", "w", 0.45359237), Unit("oz", "أوقية", "oz", "w", 0.028349523),
        Unit("l", "لتر", "L", "v", 1.0), Unit("ml", "مليلتر", "ml", "v", 0.001), Unit("gal", "جالون", "gal", "v", 3.785411784),
        Unit("m", "متر", "m", "len", 1.0), Unit("cm", "سنتيمتر", "cm", "len", 0.01), Unit("mm", "مليمتر", "mm", "len", 0.001),
        Unit("m2", "متر مربع", "m²", "area", 1.0), Unit("cm2", "سم مربع", "cm²", "area", 0.0001),
        Unit("pc", "قطعة", "piece", "n", 1.0), Unit("dozen", "دستة", "dozen", "n", 12.0), Unit("pair", "زوج", "pair", "n", 2.0),
        Unit("carton", "كرتونة", "carton", "pack", 0.0), Unit("pack", "عبوة", "pack", "pack", 0.0), Unit("box", "علبة", "box", "pack", 0.0),
        Unit("bag", "شوال/كيس", "bag", "pack", 0.0)
    )

    /** محاولة فهم وحدة المكوّن المكتوبة نصاً */
    fun parse(text: String): Unit? {
        val t = text.trim().lowercase()
        if (t.isBlank()) return null
        return units.firstOrNull { it.key == t || it.ar == t || it.en.lowercase() == t } ?: when {
            t.contains("كيلو") || t == "كجم" || t == "كغ" -> units.first { it.key == "kg" }
            t.contains("جرام") || t.contains("غرام") || t == "جم" || t == "غ" -> units.first { it.key == "g" }
            t.contains("طن") -> units.first { it.key == "ton" }
            t.contains("مل") && !t.contains("ملي متر") -> units.first { it.key == "ml" }
            t.contains("لتر") || t == "لت" -> units.first { it.key == "l" }
            t.contains("متر") -> units.first { it.key == "m" }
            t.contains("قطع") || t.contains("حبة") || t.contains("حبه") || t == "pcs" -> units.first { it.key == "pc" }
            t.contains("دست") -> units.first { it.key == "dozen" }
            t.contains("كرتون") -> units.first { it.key == "carton" }
            t.contains("عبو") -> units.first { it.key == "pack" }
            t.contains("علب") -> units.first { it.key == "box" }
            t.contains("شوال") || t.contains("كيس") -> units.first { it.key == "bag" }
            else -> null
        }
    }

    /** معامل التحويل التلقائي من وحدة السطر إلى وحدة المكوّن (إن كانا من نفس العائلة) */
    fun autoFactor(lineUnit: String, baseUnitText: String): Double? {
        val a = units.firstOrNull { it.key == lineUnit } ?: return null
        val b = parse(baseUnitText) ?: return if (baseUnitText.isBlank() && a.family != "pack") 1.0 else null
        if (a.key == b.key) return 1.0
        if (a.family != b.family || a.toBase == 0.0 || b.toBase == 0.0) return null
        return a.toBase / b.toBase
    }

    fun unitLabel(key: String) = units.firstOrNull { it.key == key }?.label ?: key

    /** الكمية المطلوبة من المكوّن بوحدته الأساسية لإنتاج qty من المنتج */
    fun need(l: BomLine, qty: Double) = l.qty * l.factor * (1 + l.wastePct / 100.0) * qty

    /** تكلفة المواد لوحدة واحدة من المنتج */
    fun unitCost(bom: List<BomLine>, products: Map<Long, Product>): Double = bom.sumOf { l -> need(l, 1.0) * (products[l.componentId]?.cost ?: 0.0) }

    data class Req(val line: BomLine, val component: Product?, val need: Double, val have: Double) {
        val short get() = (need - have).coerceAtLeast(0.0)
    }

    fun requirements(bom: List<BomLine>, qty: Double, products: Map<Long, Product>, stock: Map<Long, Double>): List<Req> =
        bom.map { l -> Req(l, products[l.componentId], round2x(need(l, qty)), stock[l.componentId] ?: 0.0) }

    /** أقصى كمية يمكن إنتاجها من المخزون الحالي */
    fun maxProducible(bom: List<BomLine>, stock: Map<Long, Double>, products: Map<Long, Product>): Double {
        val lim = bom.filter { products[it.componentId]?.trackStock != false }.mapNotNull { l -> val n = need(l, 1.0); if (n <= 0) null else (stock[l.componentId] ?: 0.0) / n }
        return if (lim.isEmpty()) 0.0 else kotlin.math.floor(lim.min().coerceAtLeast(0.0))
    }

    fun round2x(v: Double) = Math.round(v * 10000.0) / 10000.0
    fun q(v: Double): String = if (v == Math.floor(v)) String.format(java.util.Locale.US, "%,.0f", v) else String.format(java.util.Locale.US, "%,.3f", v).trimEnd('0').trimEnd('.')

    // ---------- التقارير ----------
    fun bomDoc(p: Product, bom: List<BomLine>, products: Map<Long, Product>): ReportDoc {
        val rows = bom.map { l ->
            val c = products[l.componentId]
            val n = need(l, 1.0)
            listOf(c?.name ?: "?", q(l.qty) + " " + unitLabel(l.unit), q(n) + " " + (c?.unit ?: ""), (if (l.wastePct > 0) q(l.wastePct) + "%" else "-"),
                Fmt.money(c?.cost ?: 0.0), Fmt.money(n * (c?.cost ?: 0.0)))
        }
        val uc = unitCost(bom, products)
        return ReportDoc(
            tr("بطاقة تصنيع: ", "Bill of materials: ") + p.name, tr("المكونات وتكلفة الوحدة", "Components & unit cost"),
            listOf(tr("المنتج", "Product") to p.name, tr("الوحدة", "Unit") to p.unit.ifBlank { "-" }, tr("سعر البيع", "Price") to Fmt.money(p.price), tr("عدد المكونات", "Components") to "${bom.size}"),
            listOf(RTable(tr("المكونات لكل وحدة", "Components per unit"), listOf(tr("المكوّن", "Component"), tr("الكمية", "Qty"), tr("بالوحدة الأساسية", "Base qty"), tr("هالك", "Waste"), tr("سعر الوحدة", "Unit cost"), tr("التكلفة", "Cost")), rows)),
            listOf(tr("تكلفة مواد الوحدة", "Material cost / unit") to Fmt.money(uc), tr("هامش الربح", "Margin") to Fmt.money(p.price - uc) + if (p.price > 0) " (" + String.format(java.util.Locale.US, "%.1f", (p.price - uc) / p.price * 100) + "%)" else ""),
            fileName = "bom_" + p.name
        )
    }

    fun productionDoc(pr: Production, lines: List<ProductionLine>, product: Product?): ReportDoc {
        val total = pr.materialsCost + pr.extraCost
        return ReportDoc(
            tr("أمر إنتاج رقم ", "Production order #") + pr.number, product?.name ?: "",
            listOf(tr("المنتج", "Product") to (product?.name ?: "-"), tr("الكمية المنتجة", "Quantity") to q(pr.qty) + " " + (product?.unit ?: ""),
                tr("التاريخ", "Date") to Fmt.date(pr.date), tr("ملاحظات", "Notes") to pr.note.ifBlank { "-" }),
            listOf(RTable(tr("المواد المستهلكة", "Materials consumed"), listOf(tr("المادة", "Material"), tr("الكمية", "Qty"), tr("سعر الوحدة", "Unit cost"), tr("الإجمالي", "Total")),
                lines.map { listOf(it.name, q(it.qty) + " " + it.unit, Fmt.money(it.unitCost), Fmt.money(it.qty * it.unitCost)) })),
            listOf(tr("تكلفة المواد", "Materials") to Fmt.money(pr.materialsCost), tr("تكاليف إضافية (عمالة، تشغيل...)", "Extra costs (labor, overhead...)") to Fmt.money(pr.extraCost),
                tr("إجمالي التكلفة", "Total cost") to Fmt.money(total), tr("تكلفة الوحدة", "Cost per unit") to Fmt.money(if (pr.qty > 0) total / pr.qty else 0.0)),
            fileName = "production_${pr.number}"
        )
    }

    fun summaryDoc(list: List<Production>, lines: List<ProductionLine>, products: Map<Long, Product>, from: Long?, to: Long?): ReportDoc {
        val f = list.filter { (from == null || it.date >= from) && (to == null || it.date <= to) }.sortedBy { it.date }
        val ids = f.map { it.id }.toSet()
        val byProduct = f.groupBy { it.productId }.map { (pid, l) ->
            val p = products[pid]
            val qty = l.sumOf { it.qty }; val cost = l.sumOf { it.materialsCost + it.extraCost }
            listOf(p?.name ?: "?", q(qty) + " " + (p?.unit ?: ""), "${l.size}", Fmt.money(cost), Fmt.money(if (qty > 0) cost / qty else 0.0), Fmt.money(qty * (p?.price ?: 0.0)))
        }
        val consumed = lines.filter { it.productionId in ids }.groupBy { it.componentId }.map { (_, l) ->
            listOf(l.first().name, q(l.sumOf { it.qty }) + " " + l.first().unit, Fmt.money(l.sumOf { it.qty * it.unitCost }))
        }.sortedBy { it[0] }
        val orders = f.map { pr ->
            val p = products[pr.productId]
            listOf("#${pr.number}", Fmt.date(pr.date), p?.name ?: "?", q(pr.qty), Fmt.money(pr.materialsCost + pr.extraCost))
        }
        val totalCost = f.sumOf { it.materialsCost + it.extraCost }
        val salesValue = f.sumOf { it.qty * (products[it.productId]?.price ?: 0.0) }
        return ReportDoc(
            tr("تقرير الإنتاج", "Production report"),
            (if (from != null || to != null) (from?.let { Fmt.date(it) } ?: "…") + " ← " + (to?.let { Fmt.date(it) } ?: "…") else tr("كل الفترات", "All periods")),
            listOf(tr("عدد أوامر الإنتاج", "Orders") to "${f.size}", tr("أصناف منتجة", "Products made") to "${f.map { it.productId }.distinct().size}",
                tr("إجمالي التكلفة", "Total cost") to Fmt.money(totalCost), tr("القيمة البيعية للمنتج", "Sales value") to Fmt.money(salesValue)),
            listOf(
                RTable(tr("ملخص حسب المنتج", "By product"), listOf(tr("المنتج", "Product"), tr("الكمية", "Qty"), tr("أوامر", "Orders"), tr("التكلفة", "Cost"), tr("تكلفة الوحدة", "Unit cost"), tr("القيمة البيعية", "Sales value")), byProduct),
                RTable(tr("المواد الخام المستهلكة", "Raw materials consumed"), listOf(tr("المادة", "Material"), tr("الكمية", "Qty"), tr("التكلفة", "Cost")), consumed),
                RTable(tr("تفاصيل الأوامر", "Order details"), listOf(tr("رقم", "No."), tr("التاريخ", "Date"), tr("المنتج", "Product"), tr("الكمية", "Qty"), tr("التكلفة", "Cost")), orders)
            ),
            listOf(tr("إجمالي التكلفة", "Total cost") to Fmt.money(totalCost), tr("الربح المتوقع", "Expected profit") to Fmt.money(salesValue - totalCost)),
            fileName = "production_report"
        )
    }
}
