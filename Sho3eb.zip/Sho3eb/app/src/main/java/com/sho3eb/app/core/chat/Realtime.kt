package com.sho3eb.app.core.chat

import android.os.Handler
import android.os.Looper
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

/** اتصال لحظي بـ Supabase Realtime (بروتوكول Phoenix) لاستقبال الرسائل والمكالمات فوراً */
object Realtime {
    private var ws: WebSocket? = null
    private val ref = AtomicInteger(1)
    private val main = Handler(Looper.getMainLooper())
    @Volatile var connected = false; private set
    private var wanted = false
    private var retry = 2000L
    private val topic get() = "realtime:sho3eb-" + Supa.uid

    var onMessage: ((JSONObject) -> Unit)? = null
    var onSignal: ((JSONObject) -> Unit)? = null

    fun start() {
        wanted = true
        if (ws != null || !Supa.configured) return
        Thread {
            runCatching { Supa.ensureSession() }.onFailure { scheduleReconnect(); return@Thread }
            val wsUrl = Supa.url.replaceFirst("https://", "wss://") + "/realtime/v1/websocket?apikey=" + Supa.key + "&vsn=1.0.0"
            ws = Supa.http.newWebSocket(Request.Builder().url(wsUrl).build(), listener)
        }.start()
    }

    fun stop() { wanted = false; ws?.close(1000, "bye"); ws = null; connected = false; main.removeCallbacksAndMessages(null) }

    private fun send(topic: String, event: String, payload: JSONObject) {
        ws?.send(JSONObject().put("topic", topic).put("event", event).put("payload", payload).put("ref", ref.getAndIncrement().toString()).put("join_ref", "1").toString())
    }

    private val heartbeat = object : Runnable {
        override fun run() {
            if (ws == null) return
            send("phoenix", "heartbeat", JSONObject())
            // تحديث رمز الدخول قبل انتهائه
            runCatching { Thread { runCatching { Supa.ensureSession(); send(topic, "access_token", JSONObject().put("access_token", Supa.access)) } }.start() }
            main.postDelayed(this, 25_000)
        }
    }

    private fun join() {
        val uid = Supa.uid
        val changes = JSONArray()
            .put(JSONObject().put("event", "*").put("schema", "public").put("table", "messages").put("filter", "recipient=eq.$uid"))
            .put(JSONObject().put("event", "UPDATE").put("schema", "public").put("table", "messages").put("filter", "sender=eq.$uid"))
            .put(JSONObject().put("event", "INSERT").put("schema", "public").put("table", "signals").put("filter", "recipient=eq.$uid"))
        val cfg = JSONObject().put("broadcast", JSONObject().put("self", false)).put("presence", JSONObject().put("key", "")).put("postgres_changes", changes)
        send(topic, "phx_join", JSONObject().put("config", cfg).put("access_token", Supa.access))
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            connected = true; retry = 2000L
            join(); main.removeCallbacks(heartbeat); main.postDelayed(heartbeat, 25_000)
            Chat.onRealtimeConnected()
        }
        override fun onMessage(webSocket: WebSocket, text: String) {
            val o = runCatching { JSONObject(text) }.getOrNull() ?: return
            if (o.optString("event") != "postgres_changes") return
            val data = o.optJSONObject("payload")?.optJSONObject("data") ?: return
            val rec = data.optJSONObject("record") ?: return
            when (data.optString("table")) {
                "messages" -> onMessage?.invoke(rec)
                "signals" -> onSignal?.invoke(rec)
            }
        }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { connected = false; ws = null; scheduleReconnect() }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { connected = false; ws = null; scheduleReconnect() }
    }

    private fun scheduleReconnect() {
        if (!wanted) return
        main.postDelayed({ if (wanted && ws == null) start() }, retry)
        retry = (retry * 2).coerceAtMost(60_000L)
    }
}
