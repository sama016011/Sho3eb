package com.sho3eb.app.core

import android.content.Context
import android.util.Base64
import com.sho3eb.app.data.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** كاتب ملفات Excel (xlsx) بسيط بدون مكتبات خارجية */
object Xlsx {
    /** خلية: نص أو رقم؛ bold للعناوين */
    data class Cell(val v: Any?, val style: Int = 0)   // 0 عادي، 1 عنوان رأس، 2 عنوان كبير، 3 مدفوع، 4 متأخر، 5 إجمالي
    class Sheet(val name: String, val rows: List<List<Cell>>, val widths: List<Int> = emptyList())

    const val MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    private fun esc(s: String) = buildString {
        s.forEach { c ->
            when (c) {
                '&' -> append("&amp;"); '<' -> append("&lt;"); '>' -> append("&gt;"); '"' -> append("&quot;")
                else -> if (c.code >= 0x20 || c == '\n' || c == '\t') append(c)
            }
        }
    }

    private fun col(i: Int): String {
        var n = i + 1
        val sb = StringBuilder()
        while (n > 0) { val r = (n - 1) % 26; sb.insert(0, ('A' + r)); n = (n - 1) / 26 }
        return sb.toString()
    }

    private fun safeName(n: String, used: MutableSet<String>): String {
        var s = n.replace(Regex("[\\[\\]:*?/\\\\]"), " ").trim().ifBlank { "Sheet" }.take(28)
        var k = 2
        val base = s
        while (!used.add(s.lowercase())) { s = "$base $k".take(31); k++ }
        return s
    }

    /** تحويل نص رقمي منسق (1,234.50) إلى رقم */
    fun num(s: String): Double? {
        val t = s.trim().replace(",", "").replace("٬", "").map { c -> if (c in '٠'..'٩') ('0' + (c - '٠')) else c }.joinToString("")
        if (t.isEmpty() || !Regex("^-?\\d+(\\.\\d+)?$").matches(t)) return null
        return t.toDoubleOrNull()
    }

    fun write(file: File, sheets: List<Sheet>, rtl: Boolean = AppState.isAr) {
        file.parentFile?.mkdirs()
        val used = mutableSetOf<String>()
        val names = sheets.map { safeName(it.name, used) }
        ZipOutputStream(FileOutputStream(file)).use { z ->
            fun put(path: String, content: String) {
                z.putNextEntry(ZipEntry(path)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            put("[Content_Types].xml", buildString {
                append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
                sheets.indices.forEach { append("""<Override PartName="/xl/worksheets/sheet${it + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""") }
                append("</Types>")
            })
            put("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            put("xl/workbook.xml", buildString {
                append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>""")
                names.forEachIndexed { i, n -> append("""<sheet name="${esc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>""") }
                append("</sheets></workbook>")
            })
            put("xl/_rels/workbook.xml.rels", buildString {
                append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                sheets.indices.forEach { append("""<Relationship Id="rId${it + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${it + 1}.xml"/>""") }
                append("""<Relationship Id="rId${sheets.size + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>""")
            })
            // الأنماط: 0 عادي، 1 رأس جدول، 2 عنوان، 3 مدفوع، 4 متأخر، 5 إجمالي، 6 رقم عادي، 7 رقم إجمالي
            put("xl/styles.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts><fonts count="4"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font><font><b/><sz val="14"/><color rgb="FF0F766E"/><name val="Arial"/></font><font><b/><sz val="11"/><name val="Arial"/></font></fonts><fills count="6"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0F766E"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDCFCE7"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFEE2E2"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF1F5F9"/></patternFill></fill></fills><borders count="2"><border/><border><left style="thin"><color rgb="FFCBD5E1"/></left><right style="thin"><color rgb="FFCBD5E1"/></right><top style="thin"><color rgb="FFCBD5E1"/></top><bottom style="thin"><color rgb="FFCBD5E1"/></bottom></border></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="8"><xf/><xf fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf fontId="2" applyFont="1"/><xf fillId="3" borderId="1" applyFill="1" applyBorder="1"/><xf fillId="4" borderId="1" applyFill="1" applyBorder="1"/><xf fontId="3" fillId="5" borderId="1" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="164" borderId="1" applyNumberFormat="1" applyBorder="1"/><xf numFmtId="164" fontId="3" fillId="5" borderId="1" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/></cellXfs></styleSheet>""")
            sheets.forEachIndexed { si, sh ->
                put("xl/worksheets/sheet${si + 1}.xml", buildString {
                    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"""")
                    if (rtl) append(""" rightToLeft="1"""")
                    append("/></sheetViews>")
                    val maxCols = sh.rows.maxOfOrNull { it.size } ?: 0
                    if (maxCols > 0) {
                        append("<cols>")
                        for (c in 0 until maxCols) {
                            val w = sh.widths.getOrNull(c) ?: run {
                                val longest = sh.rows.maxOfOrNull { r -> (r.getOrNull(c)?.v?.toString()?.length ?: 0) } ?: 10
                                longest.coerceIn(8, 45) + 2
                            }
                            append("""<col min="${c + 1}" max="${c + 1}" width="$w" customWidth="1"/>""")
                        }
                        append("</cols>")
                    }
                    append("<sheetData>")
                    sh.rows.forEachIndexed { ri, row ->
                        append("""<row r="${ri + 1}">""")
                        row.forEachIndexed { ci, cell ->
                            val ref = col(ci) + (ri + 1)
                            when (val v = cell.v) {
                                null -> {}
                                is Number -> {
                                    val st = when (cell.style) { 5 -> 7; 3, 4 -> cell.style; else -> 6 }
                                    append("""<c r="$ref" s="$st"><v>${v.toDouble()}</v></c>""")
                                }
                                else -> {
                                    val str = v.toString()
                                    if (str.isNotEmpty()) append("""<c r="$ref" s="${cell.style}" t="inlineStr"><is><t xml:space="preserve">${esc(str)}</t></is></c>""")
                                }
                            }
                        }
                        append("</row>")
                    }
                    append("</sheetData></worksheet>")
                })
            }
        }
    }

    /** ورقة من كشف موحّد */
    fun sheetOf(doc: ReportDoc): Sheet {
        val rows = mutableListOf<List<Cell>>()
        rows += listOf(Cell(doc.title, 2))
        if (doc.subtitle.isNotBlank()) rows += listOf(Cell(doc.subtitle, 2))
        rows += emptyList<Cell>()
        doc.info.forEach { (k, v) -> rows += listOf(Cell(k, 5), cellOf(v)) }
        doc.tables.forEach { t ->
            rows += emptyList<Cell>()
            rows += listOf(Cell(t.title, 2))
            rows += t.headers.map { Cell(it, 1) }
            t.rows.forEachIndexed { i, r ->
                val st = when (t.status?.getOrNull(i)) { 1 -> 3; 2 -> 4; 9 -> 5; else -> 0 }
                rows += r.map { cellOf(it, st) }
            }
        }
        if (doc.totals.isNotEmpty()) {
            rows += emptyList<Cell>()
            doc.totals.forEach { (k, v) -> rows += listOf(Cell(k, 5), cellOf(v, 5)) }
        }
        if (doc.notes.isNotBlank()) { rows += emptyList<Cell>(); rows += listOf(Cell(tr("ملاحظات", "Notes"), 5), Cell(doc.notes)) }
        rows += emptyList<Cell>()
        rows += listOf(Cell(tr("صادر من تطبيق شعيب • ", "Generated by Sho3eb • ") + Fmt.date(Fmt.today())))
        return Sheet(doc.subtitle.ifBlank { doc.title }, rows)
    }

    /** خلية رقمية إن كان النص رقماً، مع حذف رمز العملة */
    fun cellOf(s: String, style: Int = 0): Cell {
        val cur = AppState.currency.value.trim()
        val raw = if (cur.isNotEmpty()) s.replace(cur, "").trim() else s
        return num(raw)?.let { Cell(it, style) } ?: Cell(s, style)
    }

    fun export(ctx: Context, doc: ReportDoc): File {
        val f = File(File(ctx.cacheDir, "reports").apply { mkdirs() }, doc.fileName.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").take(60) + ".xlsx")
        write(f, listOf(sheetOf(doc)))
        return f
    }

    /** تصدير كل بيانات التطبيق في ملف واحد متعدد الأوراق */
    suspend fun exportAll(ctx: Context, dao: AppDao): File {
        val people = dao.allPeople()
        val pm = people.associateBy { it.id }
        val assocs = dao.allAssociations()
        val members = dao.allMembers()
        val aPays = dao.allAssocPayments()
        val payouts = dao.allPayouts()
        val loans = dao.allLoanTx()
        val sales = dao.allSales()
        val sPays = dao.allSalePayments()
        val accounts = dao.allAccounts()
        val accTx = dao.allAccountTx()
        val livP = dao.allLivPeriods()
        val livE = dao.allLivEntries()
        val livI = dao.allLivItems()
        fun h(vararg s: String) = s.map { Cell(it, 1) }
        fun r(vararg v: Any?) = v.map { Cell(it) }
        val sheets = mutableListOf<Sheet>()

        // ملخص
        val loanBal = loanSummaries(loans).sumOf { it.balance.coerceAtLeast(0.0) }
        val saleRem = sales.sumOf { s -> saleRemaining(s, sPays.filter { it.saleId == s.id }) }
        val accBal = accounts.sumOf { a -> accountBalance(accTx.filter { it.accountId == a.id }) }
        sheets += Sheet(tr("الملخص", "Summary"), listOf(
            listOf(Cell(tr("ملخص بيانات شعيب", "Sho3eb data summary"), 2)), emptyList(),
            listOf(Cell(tr("تاريخ التصدير", "Exported"), 5), Cell(Fmt.date(Fmt.today()))),
            listOf(Cell(tr("عدد الأشخاص", "People"), 5), Cell(people.size)),
            listOf(Cell(tr("عدد الجمعيات", "Associations"), 5), Cell(assocs.size)),
            listOf(Cell(tr("إجمالي السلف المستحقة", "Loans outstanding"), 5), Cell(loanBal, 5)),
            listOf(Cell(tr("المتبقي من التقسيط", "Installments remaining"), 5), Cell(saleRem, 5)),
            listOf(Cell(tr("إجمالي أرصدة الحسابات", "Accounts balance"), 5), Cell(accBal, 5))
        ))
        sheets += Sheet(tr("الأشخاص", "People"), listOf(h(tr("الاسم", "Name"), tr("الجوال", "Phone"), tr("ملاحظات", "Notes"))) +
            people.map { r(it.name, it.phone, it.notes) })
        sheets += Sheet(tr("الجمعيات", "Associations"), listOf(h(tr("الجمعية", "Association"), tr("السهم", "Share"), tr("المدة", "Period"), tr("البداية", "Start"), tr("الأعضاء", "Members"), tr("المحصّل", "Collected"), tr("ملاحظات", "Notes"))) +
            assocs.map { a -> r(a.name, a.shareAmount, Fmt.periodLabel(a.periodType, a.periodCount), Fmt.date(a.startDate), members.count { it.associationId == a.id }, aPays.filter { it.associationId == a.id }.sumOf { it.amount }, a.notes) })
        val am = assocs.associateBy { it.id }
        val mm = members.associateBy { it.id }
        sheets += Sheet(tr("دفعات الجمعيات", "Association payments"), listOf(h(tr("الجمعية", "Association"), tr("العضو", "Member"), tr("الدورة", "Round"), tr("المبلغ", "Amount"), tr("التاريخ", "Date"), tr("ملاحظات", "Notes"))) +
            aPays.sortedBy { it.date }.map { p -> r(am[p.associationId]?.name, pm[mm[p.memberId]?.personId]?.name, p.round + 1, p.amount, Fmt.date(p.date), p.note) })
        sheets += Sheet(tr("تسليم القبضات", "Payouts"), listOf(h(tr("الجمعية", "Association"), tr("المستلم", "Recipient"), tr("الدورة", "Round"), tr("المبلغ", "Amount"), tr("التاريخ", "Date"))) +
            payouts.sortedBy { it.date }.map { p -> r(am[p.associationId]?.name, pm[mm[p.memberId]?.personId]?.name, p.round + 1, p.amount, Fmt.date(p.date)) })
        sheets += Sheet(tr("السلف", "Loans"), listOf(h(tr("الاسم", "Name"), tr("النوع", "Type"), tr("المبلغ", "Amount"), tr("التاريخ", "Date"), tr("الاستحقاق", "Due"), tr("ملاحظات", "Notes"))) +
            loans.sortedBy { it.date }.map { t -> r(pm[t.personId]?.name, if (t.type == LoanTx.LOAN) tr("سلفة", "Loan") else tr("سداد", "Repayment"), t.amount, Fmt.date(t.date), t.dueDate?.let { Fmt.date(it) }, t.note) })
        sheets += Sheet(tr("أرصدة السلف", "Loan balances"), listOf(h(tr("الاسم", "Name"), tr("المأخوذ", "Taken"), tr("المسدد", "Paid"), tr("المتبقي", "Balance"))) +
            loanSummaries(loans).map { s -> r(pm[s.personId]?.name, s.taken, s.paid, s.balance) })
        sheets += Sheet(tr("التقسيط", "Installment sales"), listOf(h(tr("العميل", "Customer"), tr("المنتج", "Product"), tr("السعر", "Price"), tr("التكلفة", "Cost"), tr("المقدم", "Down"), tr("الأقساط", "Count"), tr("القسط", "Installment"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"))) +
            sales.map { s -> val ps = sPays.filter { it.saleId == s.id }; r(pm[s.personId]?.name, s.product, s.totalPrice, s.costPrice, s.downPayment, s.installmentsCount, installmentAmount(s), ps.sumOf { it.amount }, saleRemaining(s, ps)) })
        val sm = sales.associateBy { it.id }
        sheets += Sheet(tr("دفعات التقسيط", "Installment payments"), listOf(h(tr("العميل", "Customer"), tr("المنتج", "Product"), tr("المبلغ", "Amount"), tr("التاريخ", "Date"), tr("ملاحظات", "Notes"))) +
            sPays.sortedBy { it.date }.map { p -> val s = sm[p.saleId]; r(pm[s?.personId]?.name, s?.product, p.amount, Fmt.date(p.date), p.note) })
        val acm = accounts.associateBy { it.id }
        sheets += Sheet(tr("الحسابات", "Accounts"), listOf(h(tr("الحساب", "Account"), tr("المالك", "Owner"), tr("الرصيد", "Balance"))) +
            accounts.map { a -> r(a.name, a.personId?.let { pm[it]?.name }, accountBalance(accTx.filter { it.accountId == a.id })) })
        sheets += Sheet(tr("حركات الحسابات", "Account transactions"), listOf(h(tr("الحساب", "Account"), tr("التاريخ", "Date"), tr("إضافة", "In"), tr("صرف", "Out"), tr("ملاحظات", "Notes"))) +
            accTx.sortedWith(compareBy({ it.accountId }, { it.date })).map { t -> r(acm[t.accountId]?.name, Fmt.date(t.date), if (t.type == AccountTx.IN) t.amount else null, if (t.type == AccountTx.OUT) t.amount else null, t.note) })
        sheets += Sheet(tr("ديباجة المعيشة", "Living template"), listOf(h(tr("النوع", "Kind"), tr("البند", "Item"), tr("الفئة", "Category"), tr("المبلغ", "Amount"), tr("التكرار", "Frequency"), tr("شهرياً", "Monthly"), tr("الأولوية", "Priority"))) +
            livI.map { i -> r(if (i.kind == Living.INCOME) tr("دخل", "Income") else tr("مصروف", "Expense"), i.name, Living.cat(i.kind, i.category).label, i.amount, Living.freqName(i.freq), Living.monthly(i.amount, i.freq), Living.priorityName(i.priority)) })
        val lpm = livP.associateBy { it.id }
        sheets += Sheet(tr("حركات المعيشة", "Living entries"), listOf(h(tr("البند", "Period"), tr("التاريخ", "Date"), tr("النوع", "Kind"), tr("البيان", "Item"), tr("الفئة", "Category"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes"))) +
            livE.sortedBy { it.date }.map { e -> r(lpm[e.periodId]?.name, Fmt.date(e.date), if (e.kind == Living.INCOME) tr("دخل", "Income") else tr("مصروف", "Expense"), e.name, Living.cat(e.kind, e.category).label, e.amount, e.note) })

        // العقارات والإيجارات
        val props = dao.allProperties(); val units = dao.allUnits(); val leases = dao.allLeases(); val lPays = dao.allLeasePayments(); val pExps = dao.allPropExpenses()
        val prm = props.associateBy { it.id }; val unm = units.associateBy { it.id }; val lem = leases.associateBy { it.id }
        sheets += Sheet(tr("العقارات", "Properties"), listOf(h(tr("العقار", "Property"), tr("النوع", "Type"), tr("العنوان", "Address"), tr("الوحدات", "Units"), tr("المؤجّر", "Occupied"), tr("الإيجار الشهري", "Monthly rent"), tr("المحصّل", "Collected"), tr("المصروفات", "Expenses"), tr("الصافي", "Net"), tr("المتأخر", "Overdue"))) +
            props.map { p -> val st = Rent.stats(p.id, units, leases, lPays, pExps); r(p.name, Rent.propType(p.type).label, p.address, st.units, st.occupied, st.monthlyRent, st.collected, st.expenses, st.net, st.overdue) })
        sheets += Sheet(tr("عقود الإيجار", "Leases"), listOf(h(tr("العقار", "Property"), tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("الجوال", "Phone"), tr("البداية", "Start"), tr("النهاية", "End"), tr("الدفعة", "Payment"), tr("الدورية", "Frequency"), tr("التأمين", "Deposit"), tr("المدفوع", "Paid"), tr("المتأخر", "Overdue"), tr("الحالة", "Status"))) +
            leases.map { l -> val u = unm[l.unitId]; val t = pm[l.tenantId]; r(prm[u?.propertyId]?.name, u?.name, t?.name, t?.phone, Fmt.date(l.startDate), Fmt.date(l.endDate), l.rentAmount, Rent.periodName(l.periodMonths), l.deposit, Rent.paid(l, lPays), Rent.overdue(l, lPays).sumOf { it.remaining }, if (Rent.isCurrent(l)) tr("ساري", "Active") else tr("منتهي", "Ended")) })
        sheets += Sheet(tr("دفعات الإيجار", "Rent payments"), listOf(h(tr("التاريخ", "Date"), tr("العقار", "Property"), tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes"))) +
            lPays.sortedBy { it.date }.map { x -> val l = lem[x.leaseId]; val u = unm[l?.unitId]; r(Fmt.date(x.date), prm[u?.propertyId]?.name, u?.name, pm[l?.tenantId]?.name, x.amount, x.note) })
        sheets += Sheet(tr("مصروفات العقارات", "Property expenses"), listOf(h(tr("التاريخ", "Date"), tr("العقار", "Property"), tr("الوحدة", "Unit"), tr("النوع", "Type"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes"))) +
            pExps.sortedBy { it.date }.map { e -> r(Fmt.date(e.date), prm[e.propertyId]?.name, e.unitId?.let { unm[it]?.name }, Rent.expCat(e.category).label, e.amount, e.note) })
        // ديوني
        val debts = dao.allDebts(); val dTx = dao.allDebtTx(); val dm = debts.associateBy { it.id }
        sheets += Sheet(tr("ديوني", "My debts"), listOf(h(tr("الدائن", "Creditor"), tr("النوع", "Type"), tr("الإجمالي", "Total"), tr("المسدد", "Paid"), tr("المتبقي", "Remaining"), tr("القسط", "Installment"), tr("الاستحقاق القادم", "Next due"), tr("الأولوية", "Priority"), tr("الحالة", "Status"))) +
            debts.map { d -> r(d.creditor, Debts.type(d.type).label, Debts.borrowed(d, dTx), Debts.paid(d, dTx), Debts.balance(d, dTx), if (d.installment > 0) d.installment else null, Debts.nextDue(d, dTx)?.let { Fmt.date(it) }, Debts.priorityName(d.priority), if (d.closed) tr("مسدد", "Settled") else tr("قائم", "Open")) })
        sheets += Sheet(tr("حركات الديون", "Debt transactions"), listOf(h(tr("التاريخ", "Date"), tr("الدائن", "Creditor"), tr("النوع", "Type"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes"))) +
            dTx.sortedBy { it.date }.map { t -> r(Fmt.date(t.date), dm[t.debtId]?.creditor, if (t.type == DebtTx.PAY) tr("سداد", "Payment") else tr("استدانة", "Borrow"), t.amount, t.note) })

        // العمال واليوميات
        val workers = dao.allWorkers(); val wEnt = dao.allWorkerEntrys(); val wm = workers.associateBy { it.id }
        sheets += Sheet(tr("العمال", "Workers"), listOf(h(tr("العامل", "Worker"), tr("المهنة", "Job"), tr("الجوال", "Phone"), tr("نوع الأجر", "Wage type"), tr("الأجر", "Wage"), tr("الأيام", "Days"), tr("المستحق", "Earned"), tr("السلف", "Advances"), tr("المدفوع", "Paid"), tr("الرصيد", "Balance"))) +
            workers.map { w -> val sm2 = Workers.sum(w, wEnt.filter { it.workerId == w.id }); r(w.name, w.job, w.phone, Workers.wageType(w.wageType).label, w.wage, sm2.days, sm2.due, sm2.advances, sm2.paid, sm2.balance) })
        sheets += Sheet(tr("اليوميات", "Daily log"), listOf(h(tr("التاريخ", "Date"), tr("العامل", "Worker"), tr("النوع", "Type"), tr("الكمية", "Qty"), tr("القيمة", "Value"), tr("المشروع", "Project"), tr("ملاحظات", "Notes"))) +
            wEnt.sortedBy { it.date }.map { e -> val w = wm[e.workerId]; r(Fmt.date(e.date), w?.name, Workers.entryType(e.type).label, e.qty, w?.let { Workers.value(it, e) }, e.project, e.note) })
        // الأصول
        val assets = dao.allAssets()
        sheets += Sheet(tr("الأصول والاستثمارات", "Assets"), listOf(h(tr("الأصل", "Asset"), tr("النوع", "Type"), tr("الكمية", "Qty"), tr("الوحدة", "Unit"), tr("العيار", "Karat"), tr("التكلفة", "Cost"), tr("القيمة الحالية", "Value"), tr("الربح", "Profit"), tr("زكوي", "Zakatable"), tr("الحالة", "Status"))) +
            assets.map { a -> r(a.name, Assets.type(a.type).label, a.qty, a.unit, if (a.karat > 0) a.karat else null, a.buyPrice, if (a.sold) a.sellPrice else Assets.value(a), Assets.profit(a), if (a.zakatable) "✓" else "", if (a.sold) tr("مُباع", "Sold") else tr("قائم", "Held")) })
        // تقسيم المصاريف
        val sGroups = dao.allSplitGroups(); val sMem = dao.allSplitMembers(); val sExp = dao.allSplitExpenses(); val sSet = dao.allSplitSettles()
        val sgm = sGroups.associateBy { it.id }; val smm = sMem.associateBy { it.id }
        sheets += Sheet(tr("تقسيم المصاريف", "Split expenses"), listOf(h(tr("المجموعة", "Group"), tr("التاريخ", "Date"), tr("البيان", "Item"), tr("الدافع", "Paid by"), tr("المبلغ", "Amount"), tr("الحصص", "Shares"))) +
            sExp.sortedBy { it.date }.map { e -> r(sgm[e.groupId]?.name, Fmt.date(e.date), e.title, smm[e.payerId]?.name, e.amount, Split.parse(e.shares).entries.joinToString("، ") { (smm[it.key]?.name ?: "-") + ": " + Fmt.num(it.value) }) })
        sheets += Sheet(tr("أرصدة التقسيم", "Split balances"), listOf(h(tr("المجموعة", "Group"), tr("العضو", "Member"), tr("دفع", "Paid"), tr("نصيبه", "Share"), tr("الرصيد", "Balance"))) +
            sGroups.flatMap { g -> val ms = sMem.filter { it.groupId == g.id }; val es = sExp.filter { it.groupId == g.id }; val b = Split.balances(ms, es, sSet.filter { it.groupId == g.id }); ms.map { m -> r(g.name, m.name, Split.spentBy(m.id, es), Split.shareOf(m.id, es), b[m.id] ?: 0.0) } })
        // السيارات
        val vehicles = dao.allVehicles(); val cExp = dao.allCarExpenses(); val vm = vehicles.associateBy { it.id }
        sheets += Sheet(tr("السيارات", "Cars"), listOf(h(tr("السيارة", "Car"), tr("اللوحة", "Plate"), tr("الموديل", "Model"), tr("العداد", "Odometer"), tr("إجمالي المصاريف", "Total spent"), tr("الوقود", "Fuel"))) +
            vehicles.map { v -> val st = Cars.stats(cExp.filter { it.vehicleId == v.id }); r(v.name, v.plate, v.model, v.odometer, st.total, st.fuel) })
        sheets += Sheet(tr("مصاريف السيارات", "Car expenses"), listOf(h(tr("التاريخ", "Date"), tr("السيارة", "Car"), tr("النوع", "Type"), tr("المبلغ", "Amount"), tr("العداد", "Odometer"), tr("لترات", "Liters"), tr("ملاحظات", "Notes"))) +
            cExp.sortedBy { it.date }.map { e -> r(Fmt.date(e.date), vm[e.vehicleId]?.name, Cars.type(e.type).label, e.amount, if (e.odometer > 0) e.odometer else null, if (e.liters > 0) e.liters else null, e.note) })
        // الاشتراكات
        val subsL = dao.allSubscriptions(); val subP = dao.allSubPayments(); val subm = subsL.associateBy { it.id }
        sheets += Sheet(tr("الاشتراكات", "Subscriptions"), listOf(h(tr("الاشتراك", "Subscription"), tr("الفئة", "Category"), tr("المبلغ", "Amount"), tr("الدورية", "Period"), tr("شهرياً", "Monthly"), tr("الموعد القادم", "Next due"), tr("الحالة", "Status"))) +
            subsL.map { x -> r(x.name, Subs.cat(x.category).label, x.amount, Rent.periodName(x.periodMonths), Subs.monthly(x), Fmt.date(x.nextDate), if (x.active) tr("نشط", "Active") else tr("موقوف", "Paused")) })
        sheets += Sheet(tr("مدفوعات الاشتراكات", "Subscription payments"), listOf(h(tr("التاريخ", "Date"), tr("الاشتراك", "Subscription"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes"))) +
            subP.sortedBy { it.date }.map { x -> r(Fmt.date(x.date), subm[x.subId]?.name, x.amount, x.note) })

        val f = File(File(ctx.cacheDir, "reports").apply { mkdirs() }, "Sho3eb_" + Fmt.date(Fmt.today()).replace("/", "-") + ".xlsx")
        write(f, sheets)
        return f
    }
}

/** رابط مشاركة الكشف: البيانات مضغوطة داخل الرابط نفسه (بعد #) ولا تُرفع لأي خادم */
object ShareLink {
    fun build(doc: ReportDoc): String {
        val o = JSONObject()
        o.put("v", 1)
        o.put("t", doc.title); o.put("s", doc.subtitle)
        o.put("c", AppState.currency.value)
        o.put("d", Fmt.date(Fmt.today()))
        o.put("l", if (AppState.isAr) "ar" else "en")
        o.put("by", AppState.displayName.value)
        o.put("i", JSONArray().apply { doc.info.forEach { (k, v) -> put(JSONArray().put(k).put(v)) } })
        o.put("tb", JSONArray().apply {
            doc.tables.forEach { t ->
                put(JSONObject().put("n", t.title).put("h", JSONArray(t.headers))
                    .put("r", JSONArray().apply { t.rows.forEach { put(JSONArray(it)) } })
                    .put("st", JSONArray().apply { (t.status ?: emptyList()).forEach { put(it ?: 0) } }))
            }
        })
        o.put("to", JSONArray().apply { doc.totals.forEach { (k, v) -> put(JSONArray().put(k).put(v)) } })
        if (doc.notes.isNotBlank()) o.put("n", doc.notes)
        val raw = o.toString().toByteArray(Charsets.UTF_8)
        val bos = ByteArrayOutputStream()
        DeflaterOutputStream(bos, Deflater(Deflater.BEST_COMPRESSION, true)).use { it.write(raw) }
        val data = Base64.encodeToString(bos.toByteArray(), Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        val base = Extras.shareBaseUrl.let { if (it.endsWith("/") || it.endsWith(".html")) it else "$it/" }
        return "$base#$data"
    }

    fun message(doc: ReportDoc, link: String) = tr(
        "السلام عليكم ورحمة الله\nهذا ${doc.title}: ${doc.subtitle}\nيمكنك الاطلاع على التفاصيل كاملة من الرابط:\n$link",
        "Hello,\nHere is your ${doc.title}: ${doc.subtitle}\nView full details:\n$link"
    )
}
