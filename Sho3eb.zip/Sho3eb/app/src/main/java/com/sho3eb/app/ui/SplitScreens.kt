@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch

// =====================================================================
//                       تقسيم المصاريف مع الآخرين
// =====================================================================
@Composable
fun SplitGroupsScreen(nav: NavController) {
    val dao = remember { appDao() }
    val groups by flowState(emptyList<SplitGroup>()) { dao.splitGroupsFlow() }
    val members by flowState(emptyList<SplitMember>()) { dao.splitMembersFlow() }
    val exps by flowState(emptyList<SplitExpense>()) { dao.splitExpensesFlow() }
    val settles by flowState(emptyList<SplitSettle>()) { dao.splitSettlesFlow() }
    var add by remember { mutableStateOf(false) }

    ScreenScaffold(
        title = tr("تقسيم المصاريف", "Split expenses"), onBack = { nav.popBackStack() },
        fab = { ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.GroupAdd, null) }, text = { Text(tr("مجموعة", "Group")) }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { InfoBanner(tr("أنشئ مجموعة لرحلة أو سكن مشترك أو عزومة، سجّل من دفع ماذا، وسيحسب التطبيق من يدين لمن بأقل عدد من التحويلات.", "Create a group for a trip, shared flat or dinner; log who paid and see who owes whom.")) }
            if (groups.isEmpty()) item { EmptyState(Icons.Filled.Groups, tr("لا توجد مجموعات بعد", "No groups yet")) }
            items(groups, key = { it.id }) { g ->
                val ms = members.filter { it.groupId == g.id }
                val es = exps.filter { it.groupId == g.id }
                val bal = Split.balances(ms, es, settles.filter { it.groupId == g.id })
                val me = ms.firstOrNull { it.isMe }
                val myBal = me?.let { bal[it.id] } ?: 0.0
                Card(onClick = { nav.navigate("split/${g.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🍽️", fontSize = 26.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(g.name, fontWeight = FontWeight.Bold)
                            Text(tr("${ms.size} أعضاء • ", "${ms.size} members • ") + Fmt.money(es.sumOf { it.amount }), style = MaterialTheme.typography.bodySmall)
                        }
                        if (g.closed) StatusChip(tr("مُسوّاة", "Settled"), SuccessGreen)
                        else if (me != null) Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.money(kotlin.math.abs(myBal)), fontWeight = FontWeight.Bold, color = if (myBal > 0.005) SuccessGreen else if (myBal < -0.005) DangerRed else MaterialTheme.colorScheme.onSurface)
                            Text(if (myBal > 0.005) tr("لك", "owed to you") else if (myBal < -0.005) tr("عليك", "you owe") else tr("متساوٍ", "even"), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    if (add) SplitGroupDialog(null, onDismiss = { add = false }) { id -> add = false; nav.navigate("split/$id") }
}

@Composable
private fun SplitGroupDialog(existing: SplitGroup?, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    val picked = remember { mutableStateListOf<Person>() }
    var extra by remember { mutableStateOf("") }
    var includeMe by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("مجموعة جديدة", "New group") else tr("تعديل المجموعة", "Edit group")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم المجموعة (مثل: رحلة العمرة، سكن الشباب)", "Group name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (existing == null) {
                    SwitchRow(tr("أنا عضو في المجموعة", "I'm a member"), null, includeMe) { includeMe = it }
                    PersonSelector(null, tr("إضافة عضو من جهات الاتصال", "Add member from contacts")) { p -> if (picked.none { it.id == p.id }) picked += p }
                    picked.forEach { p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("• " + p.name, Modifier.weight(1f))
                            IconButton(onClick = { picked.remove(p) }) { Icon(Icons.Filled.Close, null) }
                        }
                    }
                    OutlinedTextField(extra, { extra = it }, label = { Text(tr("أو اكتب أسماء أعضاء آخرين مفصولة بفاصلة", "Or type other names, comma separated")) }, modifier = Modifier.fillMaxWidth())
                }
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل اسم المجموعة", "Enter a name")); return@TextButton }
                scope.launch {
                    if (existing != null) { dao.updateSplitGroup(existing.copy(name = name.trim(), notes = notes.trim())); onSaved(existing.id); return@launch }
                    val id = dao.insertSplitGroup(SplitGroup(name = name.trim(), notes = notes.trim()))
                    if (includeMe) dao.insertSplitMember(SplitMember(groupId = id, name = tr("أنا", "Me"), isMe = true))
                    picked.forEach { p -> dao.insertSplitMember(SplitMember(groupId = id, name = p.name, phone = p.phone, personId = p.id)) }
                    extra.split(",", "،").map { it.trim() }.filter { it.isNotBlank() }.forEach { n -> dao.insertSplitMember(SplitMember(groupId = id, name = n)) }
                    onSaved(id)
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
fun SplitGroupScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val group by flowState<SplitGroup?>(null, id) { dao.splitGroupFlow(id) }
    val allM by flowState(emptyList<SplitMember>()) { dao.splitMembersFlow() }
    val allE by flowState(emptyList<SplitExpense>()) { dao.splitExpensesFlow() }
    val allS by flowState(emptyList<SplitSettle>()) { dao.splitSettlesFlow() }
    val linked = rememberLinkedIds(AccountTx.SRC_SPLIT)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var addExp by remember { mutableStateOf(false) }
    var editExp by remember { mutableStateOf<SplitExpense?>(null) }
    var addMember by remember { mutableStateOf(false) }
    var settle by remember { mutableStateOf<Split.Transfer?>(null) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var postE by remember { mutableStateOf<SplitExpense?>(null) }

    val g = group
    if (g == null) { ScreenScaffold(tr("المجموعة", "Group"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val ms = allM.filter { it.groupId == g.id }
    val es = allE.filter { it.groupId == g.id }
    val ss = allS.filter { it.groupId == g.id }
    val mm = ms.associateBy { it.id }
    val bal = Split.balances(ms, es, ss)
    val transfers = Split.settlements(bal)
    val total = es.sumOf { it.amount }

    fun msgFor(m: SplitMember): String {
        val b = bal[m.id] ?: 0.0
        val lines = transfers.filter { it.from == m.id || it.to == m.id }.joinToString("\n") { t ->
            if (t.from == m.id) tr("• تدفع إلى ${mm[t.to]?.name}: ${Fmt.money(t.amount)}", "• Pay ${mm[t.to]?.name}: ${Fmt.money(t.amount)}")
            else tr("• تستلم من ${mm[t.from]?.name}: ${Fmt.money(t.amount)}", "• Receive from ${mm[t.from]?.name}: ${Fmt.money(t.amount)}")
        }
        return tr(
            "السلام عليكم ${m.name}\nمصاريف «${g.name}»: الإجمالي ${Fmt.money(total)}\nدفعت: ${Fmt.money(Split.spentBy(m.id, es))} • نصيبك: ${Fmt.money(Split.shareOf(m.id, es))}\n" +
                (if (b > 0.005) "لك: ${Fmt.money(b)}" else if (b < -0.005) "عليك: ${Fmt.money(-b)}" else "حسابك متساوٍ ✅") + (if (lines.isNotBlank()) "\n$lines" else ""),
            "Hello ${m.name}\n“${g.name}” total ${Fmt.money(total)}\nYou paid ${Fmt.money(Split.spentBy(m.id, es))} • your share ${Fmt.money(Split.shareOf(m.id, es))}\n" +
                (if (b > 0.005) "You get back ${Fmt.money(b)}" else if (b < -0.005) "You owe ${Fmt.money(-b)}" else "You're even ✅") + (if (lines.isNotBlank()) "\n$lines" else "")
        )
    }

    ScreenScaffold(
        title = g.name, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(null, doc = { Docs.split(g, ms, es, ss) }) { c -> Reports.doc(c, Docs.split(g, ms, es, ss)) }
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null) }
        },
        fab = { if (tab == 0) ExtendedFloatingActionButton(onClick = { if (ms.isEmpty()) addMember = true else addExp = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("مصروف", "Expense")) }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("المصاريف", "Expenses")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("الأرصدة والتسوية", "Balances")) })
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard(tr("الإجمالي", "Total"), Fmt.money(total), Icons.Filled.Receipt, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        StatCard(tr("للفرد", "Per person"), Fmt.money(if (ms.isNotEmpty()) total / ms.size else 0.0), Icons.Filled.Person, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                    }
                }
                if (tab == 0) {
                    if (es.isEmpty()) item { EmptyState(Icons.Filled.Receipt, tr("سجّل أول مصروف: من دفع، وكم، وعلى من يُقسّم", "Add the first expense")) }
                    items(es, key = { it.id }) { e ->
                        val shares = Split.parse(e.shares)
                        Card(onClick = { editExp = e }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(e.title, fontWeight = FontWeight.SemiBold)
                                    Text(tr("دفعها ", "Paid by ") + (mm[e.payerId]?.name ?: "-") + " • " + Fmt.date(e.date), style = MaterialTheme.typography.bodySmall)
                                    Text(tr("على ", "Split among ") + (if (shares.size == ms.size) tr("الجميع", "everyone") else shares.keys.mapNotNull { mm[it]?.name }.joinToString("، ")), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(Fmt.money(e.amount), fontWeight = FontWeight.Bold)
                                if (mm[e.payerId]?.isMe == true) PostButton(e.id in linked) { postE = e }
                            }
                        }
                    }
                } else {
                    item { SectionTitle(tr("الأرصدة", "Balances")) }
                    items(ms, key = { "m${it.id}" }) { m ->
                        val b = bal[m.id] ?: 0.0
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(m.name, fontWeight = FontWeight.SemiBold)
                                    Text(tr("دفع ", "Paid ") + Fmt.num(Split.spentBy(m.id, es)) + tr(" • نصيبه ", " • share ") + Fmt.num(Split.shareOf(m.id, es)), style = MaterialTheme.typography.bodySmall)
                                }
                                Text((if (b > 0.005) "+" else "") + Fmt.num(b), fontWeight = FontWeight.Bold, color = if (b > 0.005) SuccessGreen else if (b < -0.005) DangerRed else MaterialTheme.colorScheme.onSurface)
                                if (m.phone.isNotBlank()) IconButton(onClick = { Share.whatsappMessage(ctx, m.phone, msgFor(m)) }) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                                else IconButton(onClick = { shareText(ctx, msgFor(m)) }) { Icon(Icons.Filled.Share, null) }
                            }
                        }
                    }
                    item { OutlinedButton(onClick = { addMember = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.PersonAdd, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة عضو", "Add member")) } }
                    item { SectionTitle(tr("التسوية المقترحة", "How to settle")) }
                    if (transfers.isEmpty()) item { Text(tr("الحسابات متساوية ✅ لا يوجد ما يُسوّى", "All settled ✅"), color = SuccessGreen, fontWeight = FontWeight.SemiBold) }
                    items(transfers) { t ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text((mm[t.from]?.name ?: "-") + "  ←  " + (mm[t.to]?.name ?: "-"), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Text(Fmt.money(t.amount), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                TextButton(onClick = { settle = t }) { Text(tr("تم الدفع", "Paid")) }
                            }
                        }
                    }
                    if (ss.isNotEmpty()) {
                        item { SectionTitle(tr("تسويات مدفوعة", "Settlements")) }
                        items(ss, key = { "s${it.id}" }) { s ->
                            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text((mm[s.fromId]?.name ?: "-") + " ← " + (mm[s.toId]?.name ?: "-") + " • " + Fmt.date(s.date), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                Text(Fmt.money(s.amount), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                IconButton(onClick = { scope.launch { dao.deleteSplitSettle(s.id) } }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                            }
                        }
                    }
                    if (transfers.isEmpty() && es.isNotEmpty() && !g.closed) item {
                        Button(onClick = { scope.launch { dao.updateSplitGroup(g.copy(closed = true)) } }, modifier = Modifier.fillMaxWidth()) { Text(tr("إغلاق المجموعة كمُسوّاة", "Mark group as settled")) }
                    }
                }
            }
        }
    }

    if (addExp) SplitExpenseDialog(g, ms, null) { addExp = false }
    editExp?.let { e -> SplitExpenseDialog(g, ms, e) { editExp = null } }
    if (addMember) {
        var n by remember { mutableStateOf("") }
        var picked by remember { mutableStateOf<Person?>(null) }
        AlertDialog(
            onDismissRequest = { addMember = false },
            title = { Text(tr("إضافة عضو", "Add member")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PersonSelector(picked, tr("من جهات الاتصال", "From contacts")) { picked = it; n = it.name }
                    OutlinedTextField(n, { n = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = { TextButton(onClick = { if (n.isNotBlank()) scope.launch { dao.insertSplitMember(SplitMember(groupId = g.id, name = n.trim(), phone = picked?.phone ?: "", personId = picked?.id)) }; addMember = false }) { Text(tr("إضافة", "Add")) } },
            dismissButton = { TextButton(onClick = { addMember = false }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
    settle?.let { t ->
        ConfirmDialog(tr("تسجيل التسوية", "Record settlement"), tr("${mm[t.from]?.name} دفع ${Fmt.money(t.amount)} إلى ${mm[t.to]?.name}؟", "${mm[t.from]?.name} paid ${Fmt.money(t.amount)} to ${mm[t.to]?.name}?"), danger = false, onDismiss = { settle = null }) {
            settle = null
            scope.launch { dao.insertSplitSettle(SplitSettle(groupId = g.id, fromId = t.from, toId = t.to, amount = t.amount, date = Fmt.today())) }
        }
    }
    if (edit) SplitGroupDialog(g, onDismiss = { edit = false }) { edit = false }
    if (del) ConfirmDialog(tr("حذف المجموعة", "Delete group"), tr("حذف «${g.name}» بكل مصاريفها وأعضائها؟", "Delete group with all expenses?"), onDismiss = { del = false }) {
        del = false
        scope.launch { dao.deleteSplitGroupFull(g.id); nav.popBackStack() }
    }
    postE?.let { e ->
        PostToAccountDialog(tr("خصم من حساب", "Withdraw"), false, onDismiss = { postE = null }) { acc ->
            postE = null
            scope.launch { Posting.post(acc, AccountTx.SRC_SPLIT, e.id, false, e.amount, e.date, g.name + " - " + e.title); toast(ctx, tr("تم الترحيل", "Posted")) }
        }
    }
}

@Composable
private fun SplitExpenseDialog(g: SplitGroup, ms: List<SplitMember>, existing: SplitExpense?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var amount by remember { mutableStateOf(existing?.amount?.let { Fmt.plain(it) } ?: "") }
    var payer by remember { mutableStateOf(existing?.payerId ?: (ms.firstOrNull { it.isMe } ?: ms.first()).id) }
    var date by remember { mutableStateOf(existing?.date ?: Fmt.today()) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    val existingShares = existing?.let { Split.parse(it.shares) }
    val selected = remember { mutableStateMapOf<Long, Boolean>().apply { ms.forEach { put(it.id, existingShares?.containsKey(it.id) ?: true) } } }
    var custom by remember { mutableStateOf(existingShares != null && existingShares.values.distinct().size > 1) }
    val customVals = remember { mutableStateMapOf<Long, String>().apply { existingShares?.forEach { (k, v) -> put(k, Fmt.plain(v)) } } }
    var confirmDel by remember { mutableStateOf(false) }
    var scanFile by remember { mutableStateOf<java.io.File?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("مصروف جديد", "New expense") else tr("تعديل المصروف", "Edit expense")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SmartInputRow(onVoice = { r ->
                    if (r.title.isNotBlank()) title = r.title
                    r.amount?.let { amount = Fmt.plain(it) }
                    date = r.date
                    // «دفع أحمد ٣٠٠ على العشاء» → اختيار الدافع بالاسم
                    ms.firstOrNull { m -> VoiceParse.norm(r.text).contains(VoiceParse.norm(m.name)) }?.let { payer = it.id }
                }, onScan = { r, f ->
                    r.total?.let { amount = Fmt.plain(it) }
                    r.date?.let { date = it }
                    if (title.isBlank()) title = r.store.ifBlank { tr("فاتورة", "Receipt") }
                    if (note.isBlank()) note = r.lines.take(10).joinToString("، ") { it.name }
                    scanFile = f
                })
                OutlinedTextField(title, { title = it }, label = { Text(tr("البيان (عشاء، بنزين، فندق...)", "What for")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                Text(tr("من دفع؟", "Who paid?"), style = MaterialTheme.typography.labelLarge)
                HChips { ms.forEach { m -> FilterChip(payer == m.id, { payer = m.id }, label = { Text(m.name) }) } }
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("يُقسّم على:", "Split among:"), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                    FilterChip(!custom, { custom = false }, label = { Text(tr("بالتساوي", "Equally")) })
                    Spacer(Modifier.width(6.dp))
                    FilterChip(custom, { custom = true }, label = { Text(tr("مبالغ مختلفة", "Custom")) })
                }
                val total = Fmt.parse(amount) ?: 0.0
                val ids = ms.filter { selected[it.id] == true }.map { it.id }
                val eq = Split.equal(total, ids)
                ms.forEach { m ->
                    Row(Modifier.fillMaxWidth().clickable { selected[m.id] = !(selected[m.id] ?: false) }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(selected[m.id] ?: false, { selected[m.id] = it })
                        Text(m.name, Modifier.weight(1f))
                        if (custom && selected[m.id] == true) OutlinedTextField(customVals[m.id] ?: "", { customVals[m.id] = it }, singleLine = true, modifier = Modifier.width(110.dp),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal))
                        else if (selected[m.id] == true) Text(Fmt.num(eq[m.id] ?: 0.0), style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (custom) {
                    val sum = ids.sumOf { Fmt.parse(customVals[it] ?: "") ?: 0.0 }
                    Text(tr("المجموع: ", "Sum: ") + Fmt.num(sum) + " / " + Fmt.num(total), color = if (kotlin.math.abs(sum - total) < 0.01) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
                if (existing != null) TextButton(onClick = { confirmDel = true }) { Text(tr("حذف المصروف", "Delete expense"), color = DangerRed) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Fmt.parse(amount)
                val ids = ms.filter { selected[it.id] == true }.map { it.id }
                if (a == null || a <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                if (ids.isEmpty()) { toast(ctx, tr("اختر من يُقسّم عليهم", "Choose members")); return@TextButton }
                val shares = if (custom) ids.associateWith { Fmt.parse(customVals[it] ?: "") ?: 0.0 } else Split.equal(a, ids)
                if (custom && kotlin.math.abs(shares.values.sum() - a) > 0.01) { toast(ctx, tr("مجموع المبالغ لا يساوي الإجمالي", "Shares must add up to the total")); return@TextButton }
                val x = SplitExpense(groupId = g.id, title = title.trim().ifBlank { tr("مصروف", "Expense") }, amount = a, payerId = payer, date = date, shares = Split.encode(shares), note = note.trim())
                scope.launch {
                    val sid = if (existing == null) dao.insertSplitExpense(x) else { dao.updateSplitExpense(x.copy(id = existing.id)); existing.id }
                    scanFile?.let { f -> runCatching { Attachments.registerFile(Attachments.SPLIT_EXP, sid, f) } }
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
    if (confirmDel && existing != null) ConfirmDialog(tr("حذف المصروف", "Delete"), existing.title, onDismiss = { confirmDel = false }) {
        scope.launch { dao.deleteLinkedTx(AccountTx.SRC_SPLIT, existing.id); dao.deleteSplitExpense(existing.id); confirmDel = false; onDismiss() }
    }
}
