package com.sho3eb.app.core

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat

/** فهرسة فيديوهات وصوتيات الجهاز حسب المجلد، لتشغيل الملف التالي في نفس المجلد تلقائياً */
object MediaScan {
    data class DevFolder(val id: String, val name: String, val items: List<MediaTools.Track>, val videos: Int, val audios: Int)

    val permissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun granted(ctx: Context) = permissions.any { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

    private data class Row(val id: Long, val name: String, val bucket: String, val bucketName: String, val video: Boolean)

    private fun query(ctx: Context, sel: String? = null, args: Array<String>? = null): List<Row> {
        val out = mutableListOf<Row>()
        val uri = MediaStore.Files.getContentUri("external")
        val proj = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, "bucket_id", "bucket_display_name", MediaStore.Files.FileColumns.MEDIA_TYPE)
        val base = "(${MediaStore.Files.FileColumns.MEDIA_TYPE}=${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO} OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO})"
        runCatching {
            ctx.contentResolver.query(uri, proj, if (sel != null) "$base AND ($sel)" else base, args, null)?.use { c ->
                while (c.moveToNext()) out += Row(c.getLong(0), c.getString(1) ?: "media", c.getString(2) ?: "", c.getString(3) ?: "", c.getInt(4) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO)
            }
        }
        return out
    }

    private fun track(r: Row) = MediaTools.Track(r.name, ContentUris.withAppendedId(if (r.video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, r.id).toString())

    /** كل مجلدات الجهاز التي بها وسائط */
    fun folders(ctx: Context): List<DevFolder> = query(ctx).groupBy { it.bucket }.map { (b, l) ->
        DevFolder(b, l.first().bucketName.ifBlank { "/" }, l.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }).map { track(it) }, l.count { it.video }, l.count { !it.video })
    }.sortedBy { it.name.lowercase() }

    /** يحدد ملفات نفس المجلد للملف المختار؛ يعيد (القائمة، موضع الملف) */
    fun siblings(ctx: Context, uri: Uri, name: String): Pair<List<MediaTools.Track>, Int>? {
        if (!granted(ctx)) return null
        val row = findRow(ctx, uri, name) ?: return null
        val all = query(ctx, "bucket_id=?", arrayOf(row.bucket)).sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        if (all.size < 2) return null
        val idx = all.indexOfFirst { it.id == row.id }.coerceAtLeast(0)
        return all.map { track(it) } to idx
    }

    private fun findRow(ctx: Context, uri: Uri, name: String): Row? {
        val auth = uri.authority ?: ""
        val id: Long? = runCatching {
            when {
                auth == "media" -> uri.lastPathSegment?.toLongOrNull()
                auth == "com.android.providers.media.documents" -> DocumentsContract.getDocumentId(uri).substringAfter(':').toLongOrNull()
                auth == "com.android.providers.downloads.documents" -> DocumentsContract.getDocumentId(uri).let { d -> if (d.startsWith("msf:")) d.substringAfter(':').toLongOrNull() else null }
                else -> null
            }
        }.getOrNull()
        if (id != null) query(ctx, "${MediaStore.Files.FileColumns._ID}=?", arrayOf(id.toString())).firstOrNull()?.let { return it }
        // مسار التخزين الخارجي: primary:Movies/a.mp4
        if (auth == "com.android.externalstorage.documents" && Build.VERSION.SDK_INT >= 29) runCatching {
            val docId = DocumentsContract.getDocumentId(uri)
            val rel = docId.substringAfter(':').substringBeforeLast('/', "") + "/"
            query(ctx, "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.Files.FileColumns.DISPLAY_NAME}=?", arrayOf(rel, name)).firstOrNull()?.let { return it }
        }
        // البحث بالاسم
        return query(ctx, "${MediaStore.Files.FileColumns.DISPLAY_NAME}=?", arrayOf(name)).singleOrNull()
    }
}
