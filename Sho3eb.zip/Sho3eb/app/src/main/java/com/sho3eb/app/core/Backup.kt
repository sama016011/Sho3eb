package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.AppDatabase
import java.io.File

object Backup {
    fun export(ctx: Context, target: Uri): Boolean = try {
        val app = Sho3ebApp.instance
        app.db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        val src = ctx.getDatabasePath(AppDatabase.NAME)
        ctx.contentResolver.openOutputStream(target)?.use { out -> src.inputStream().use { it.copyTo(out) } }
        true
    } catch (e: Exception) {
        false
    }

    /** استعادة نسخة احتياطية ثم إعادة تشغيل التطبيق */
    fun import(ctx: Context, source: Uri): Boolean {
        return try {
            val tmp = File(ctx.cacheDir, "restore.db")
            ctx.contentResolver.openInputStream(source)?.use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
            val header = tmp.inputStream().use { s -> ByteArray(15).also { s.read(it) } }
            if (String(header, Charsets.US_ASCII) != "SQLite format 3") {
                tmp.delete(); return false
            }
            Sho3ebApp.instance.db.close()
            val dst = ctx.getDatabasePath(AppDatabase.NAME)
            File(dst.path + "-journal").delete()
            File(dst.path + "-wal").delete()
            File(dst.path + "-shm").delete()
            tmp.copyTo(dst, overwrite = true)
            tmp.delete()
            restart(ctx)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun restart(ctx: Context) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        if (intent != null) ctx.startActivity(intent)
        Runtime.getRuntime().exit(0)
    }
}
