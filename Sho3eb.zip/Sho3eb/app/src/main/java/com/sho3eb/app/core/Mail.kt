package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.AppDatabase
import java.io.File

/** ربط الحساب بالبريد: رمز الاستعادة، وإرسال النسخ الاحتياطية والتقارير إلى البريد */
object Mail {
    fun valid(email: String) = android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()

    /** يفتح تطبيق البريد برسالة جاهزة (مع مرفق اختياري) */
    fun compose(ctx: Context, to: String, subject: String, body: String, attachment: File? = null, mime: String = "application/octet-stream") {
        try {
            val i = if (attachment == null) {
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(to)); putExtra(Intent.EXTRA_SUBJECT, subject); putExtra(Intent.EXTRA_TEXT, body)
                }
            } else {
                Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(to)); putExtra(Intent.EXTRA_SUBJECT, subject); putExtra(Intent.EXTRA_TEXT, body)
                    putExtra(Intent.EXTRA_STREAM, Share.uriFor(ctx, attachment))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            ctx.startActivity(Intent.createChooser(i, tr("إرسال عبر البريد", "Send via email")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast(ctx, tr("لا يوجد تطبيق بريد على الهاتف", "No email app found"))
        }
    }

    /** إنشاء رمز استعادة جديد وإرساله إلى بريد المستخدم */
    fun sendRecovery(ctx: Context, prefs: Prefs) {
        if (!valid(prefs.email)) { toast(ctx, tr("أضف بريداً إلكترونياً صحيحاً أولاً", "Add a valid email first")); return }
        val code = prefs.newRecoveryCode()
        compose(
            ctx, prefs.email, tr("رمز استعادة حساب شعيب", "Sho3eb recovery code"),
            tr(
                "السلام عليكم ${prefs.displayName}\n\nهذا رمز استعادة حسابك في تطبيق شعيب:\n\n$code\n\nاسم المستخدم: ${prefs.username}\n\nإذا نسيت كلمة المرور: افتح التطبيق ← «نسيت كلمة المرور؟» ← أدخل هذا الرمز ثم اختر كلمة مرور جديدة.\nاحتفظ بهذه الرسالة ولا تشاركها مع أحد. أي رمز سابق لم يعد صالحاً.",
                "Hello ${prefs.displayName}\n\nYour Sho3eb recovery code:\n\n$code\n\nUsername: ${prefs.username}\n\nIf you forget your password: open the app → “Forgot password?” → enter this code and choose a new password.\nKeep this email private. Any previous code is no longer valid."
            )
        )
    }

    /** نسخة احتياطية كاملة إلى البريد */
    fun sendBackup(ctx: Context, prefs: Prefs) {
        try {
            val app = Sho3ebApp.instance
            app.db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
            val src = ctx.getDatabasePath(AppDatabase.NAME)
            val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
            val f = File(dir, "Sho3eb_backup_" + Fmt.date(Fmt.today()).replace("/", "-") + ".db")
            src.copyTo(f, overwrite = true)
            compose(
                ctx, prefs.email, tr("نسخة احتياطية - شعيب ", "Sho3eb backup ") + Fmt.date(Fmt.today()),
                tr("نسخة احتياطية من بيانات تطبيق شعيب.\nللاستعادة: الإعدادات ← استعادة نسخة احتياطية ← اختر هذا الملف.", "Sho3eb data backup.\nTo restore: Settings → Restore backup → pick this file."),
                f
            )
        } catch (e: Exception) {
            toast(ctx, tr("تعذر تجهيز النسخة الاحتياطية", "Could not prepare backup"))
        }
    }
}
