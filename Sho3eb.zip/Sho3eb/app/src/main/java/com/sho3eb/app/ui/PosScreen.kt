@file:OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.Product
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class CartLine(val p: Product?, val name: String, qty: Double, price: Double) {
    var qty by mutableDoubleStateOf(qty)
    var price by mutableDoubleStateOf(price)
    val total get() = qty * price
}

/** نقطة البيع: شاشة بيع سريعة احترافية */
@Composable
fun PosScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val d = rememberShopData()
    val products = remember(d.products) { d.products.filter { it.active } }
    val stock = remember(d) { Shop.stockMap(d.products, d.invs, d.items, d.adjs) }
    val cats = remember(products) { products.map { it.category.trim() }.filter { it.isNotBlank() }.distinct().sorted() }
    var q by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<String?>(null) }
    val cart = remember { mutableStateListOf<CartLine>() }
    var partyId by remember { mutableStateOf<Long?>(null) }
    var walkName by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var paidEdited by remember { mutableStateOf(false) }
    var method by remember { mutableStateOf("CASH") }
    var isReturn by remember { mutableStateOf(false) }
    var pickParty by remember { mutableStateOf(false) }
    var showCart by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var lastId by remember { mutableStateOf<Long?>(null) }
    var editLine by remember { mutableStateOf<CartLine?>(null) }

    val customers = d.parties.filter { it.type == Parties.CUSTOMER && it.active }
    val party = customers.firstOrNull { it.id == partyId }
    val sub = cart.sumOf { it.total }
    val disc = Fmt.parse(discount) ?: 0.0
    val total = (sub - disc).coerceAtLeast(0.0)
    val paidV = if (paidEdited) Fmt.parse(paid) ?: 0.0 else total
    val change = paidV - total

    fun add(p: Product) {
        val ex = cart.firstOrNull { it.p?.id == p.id }
        if (ex != null) ex.qty += 1.0 else cart.add(CartLine(p, p.name, 1.0, p.price))
        lastId = null
    }
    fun addCode() {
        val c = code.trim(); if (c.isBlank()) return
        val p = products.firstOrNull { it.sku.equals(c, true) } ?: products.firstOrNull { it.name.equals(c, true) }
        if (p != null) { add(p); code = "" } else toast(ctx, tr("لا يوجد صنف بهذا الكود", "No item with this code"))
    }
    fun save(share: Boolean) {
        if (cart.isEmpty()) return
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    Pos.save(dao, if (isReturn) Shop.SRETURN else Shop.SALE, cart.map { Pos.Line(it.p?.id, it.name, it.qty, it.price) }, partyId,
                        if (partyId == null) walkName.ifBlank { tr("عميل نقدي", "Walk-in customer") } else "", "", disc, 0.0, minOf(paidV, total), method, tr("نقطة البيع", "POS"))
                }
            }
            busy = false
            r.onSuccess { id ->
                toast(ctx, if (isReturn) tr("✅ تم حفظ المرتجع", "✅ Return saved") else tr("✅ تم حفظ الفاتورة", "✅ Sale saved"))
                if (change > 0.009 && !isReturn) toast(ctx, tr("الباقي للعميل: ", "Change: ") + Fmt.money(change))
                cart.clear(); discount = ""; paid = ""; paidEdited = false; walkName = ""; partyId = null; lastId = id
                if (share) scope.launch {
                    val f = withContext(Dispatchers.IO) {
                        runCatching {
                            val inv = dao.allInvoices().first { it.id == id }
                            val its = dao.allInvoiceItems().filter { it.invoiceId == id }; val ps = dao.allInvoicePayments().filter { it.invoiceId == id }
                            Reports.doc(ctx, Docs.invoice(Shop.rows(listOf(inv), its, ps).first(), its, ps))
                        }.getOrNull()
                    }
                    f?.let { Share.sharePdf(ctx, it, party?.phone, false) }
                }
            }.onFailure { toast(ctx, tr("تعذر الحفظ: ", "Couldn't save: ") + (it.message ?: "")) }
        }
    }

    val shown = products.filter { p -> (cat == null || p.category.trim() == cat) && (q.isBlank() || p.name.contains(q, true) || p.sku.contains(q, true)) }

    ScreenScaffold(title = tr("🧾 نقطة البيع", "🧾 Point of sale"), onBack = { nav.popBackStack() }, actions = {
        FilterChip(isReturn, { isReturn = !isReturn }, label = { Text(tr("مرتجع", "Return")) }, modifier = Modifier.padding(end = 6.dp))
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(q, { q = it }, placeholder = { Text(tr("🔍 بحث", "🔍 Search")) }, singleLine = true, modifier = Modifier.weight(1.3f))
                OutlinedTextField(code, { code = it }, placeholder = { Text(tr("الكود/الباركود", "Code/barcode")) }, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { addCode() }),
                    trailingIcon = { IconButton(onClick = { addCode() }) { Icon(Icons.Filled.AddCircle, null) } })
            }
            if (cats.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(cat == null, { cat = null }, label = { Text(tr("الكل", "All")) })
                cats.forEach { c -> FilterChip(cat == c, { cat = if (cat == c) null else c }, label = { Text(c) }) }
            }
            // ===== الأصناف =====
            LazyVerticalGrid(GridCells.Adaptive(104.dp), Modifier.weight(1f).padding(horizontal = 8.dp), contentPadding = PaddingValues(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { p ->
                    val inCart = cart.firstOrNull { it.p?.id == p.id }?.qty
                    val st = stock[p.id] ?: 0.0
                    Card(Modifier.fillMaxWidth().clickable { add(p) }, colors = CardDefaults.cardColors(containerColor = if (inCart != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box { ProductThumb(p.id, p.name, 72.dp)
                                if (inCart != null) Text(Fmt.num(inCart), Modifier.align(Alignment.TopEnd).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary).padding(horizontal = 6.dp), color = MaterialTheme.colorScheme.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            Text(p.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            Text(Fmt.money(p.price), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            if (p.trackStock) Text(tr("متاح ", "Stock ") + Fmt.num(st), style = MaterialTheme.typography.labelSmall, color = if (st <= 0) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            // ===== السلة =====
            Surface(tonalElevation = 6.dp, shadowElevation = 8.dp) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { showCart = !showCart }) {
                        Icon(Icons.Filled.ShoppingCart, null); Spacer(Modifier.width(6.dp))
                        Text(tr("السلة (${cart.size})", "Cart (${cart.size})"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(Fmt.money(total), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = if (isReturn) DangerRed else MaterialTheme.colorScheme.primary)
                        Icon(if (showCart) Icons.Filled.ExpandMore else Icons.Filled.ExpandLess, null)
                    }
                    if (showCart) {
                        LazyColumn(Modifier.heightIn(max = 170.dp)) {
                            itemsIndexed(cart, key = { i, l -> (l.p?.id ?: -i.toLong()) }) { _, l ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.combinedClickable(onClick = { editLine = l }, onLongClick = { cart.remove(l) })) {
                                    Text(l.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    IconButton(onClick = { if (l.qty > 1) l.qty -= 1.0 else cart.remove(l) }, Modifier.size(32.dp)) { Icon(Icons.Filled.Remove, null) }
                                    Text(Fmt.num(l.qty), fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { l.qty += 1.0 }, Modifier.size(32.dp)) { Icon(Icons.Filled.Add, null) }
                                    Text(Fmt.money(l.total), Modifier.widthIn(min = 76.dp), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        if (cart.isNotEmpty()) Text(tr("اضغط على السطر لتعديل السعر، واضغط مطولاً للحذف", "Tap a line to edit price; long-press to remove"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            AssistChip({ pickParty = true }, label = { Text(party?.let { it.code + " • " + it.name } ?: tr("👤 عميل نقدي", "👤 Walk-in"), maxLines = 1) }, modifier = Modifier.weight(1f))
                            if (party != null) IconButton(onClick = { partyId = null }) { Icon(Icons.Filled.Close, null) }
                            OutlinedTextField(discount, { discount = it }, label = { Text(tr("خصم", "Discount")) }, singleLine = true, modifier = Modifier.width(96.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Shop.methods.take(3).forEach { m -> FilterChip(method == m.key, { method = m.key }, label = { Text(m.emoji + " " + m.label, maxLines = 1) }) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(if (paidEdited) paid else Fmt.plain(total), { paid = it; paidEdited = true }, label = { Text(tr("المدفوع", "Paid")) }, singleLine = true, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                            Column(Modifier.weight(1f)) {
                                Text(if (change >= 0) tr("الباقي للعميل", "Change") else tr("آجل (دين)", "On credit"), style = MaterialTheme.typography.labelSmall)
                                Text(Fmt.money(kotlin.math.abs(change)), fontWeight = FontWeight.Bold, color = if (change >= 0) SuccessGreen else DangerRed)
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { cart.clear(); discount = ""; paidEdited = false }, enabled = cart.isNotEmpty() && !busy) { Icon(Icons.Filled.DeleteSweep, null) }
                        OutlinedButton(onClick = { save(true) }, enabled = cart.isNotEmpty() && !busy, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Print, null); Spacer(Modifier.width(4.dp)); Text(tr("حفظ وإيصال", "Save & receipt"), maxLines = 1) }
                        Button(onClick = { save(false) }, enabled = cart.isNotEmpty() && !busy, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Check, null); Spacer(Modifier.width(4.dp)); Text(if (isReturn) tr("حفظ المرتجع", "Save return") else tr("دفع وحفظ", "Pay & save"), maxLines = 1) }
                    }
                    lastId?.let { id -> TextButton(onClick = { nav.navigate("invoice/$id") }) { Text(tr("📄 عرض آخر فاتورة", "📄 View last invoice")) } }
                }
            }
        }
    }
    if (pickParty) PickerDialog(tr("اختر العميل", "Choose customer"), customers.map { it.id to (it.code + " • " + it.name + if (it.phone.isNotBlank()) " • " + it.phone else "") }, { pickParty = false }) { partyId = it; pickParty = false }
    editLine?.let { l ->
        var pr by remember(l) { mutableStateOf(Fmt.plain(l.price)) }
        var qt by remember(l) { mutableStateOf(Fmt.plain(l.qty)) }
        AlertDialog(onDismissRequest = { editLine = null }, title = { Text(l.name) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(qt, { qt = it }, label = { Text(tr("الكمية", "Qty")) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(pr, { pr = it }, label = { Text(tr("السعر", "Price")) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            } },
            confirmButton = { TextButton(onClick = { l.qty = Fmt.parse(qt) ?: l.qty; l.price = Fmt.parse(pr) ?: l.price; editLine = null }) { Text(tr("تم", "Done")) } },
            dismissButton = { TextButton(onClick = { cart.remove(l); editLine = null }) { Text(tr("حذف", "Remove"), color = DangerRed) } })
    }
}
