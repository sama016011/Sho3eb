package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate

// =====================================================================
//          حسابات العملاء والموردين (كشف حساب، تحصيل، أعمار ديون، تقارير)
// =====================================================================
object Parties {
    const val CUSTOMER = "CUSTOMER"
    const val SUPPLIER = "SUPPLIER"

    /** SETTLE = تحصيل من عميل أو سداد لمورد (يُنقص الرصيد) ، CHARGE = إشعار مدين (يزيد الرصيد) */
    const val SETTLE = "SETTLE"
    const val CHARGE = "CHARGE"

    fun isCustomer(p: Party) = p.type == CUSTOMER
    fun typeOf(invType: String) = if (Shop.isCustomerSide(invType)) CUSTOMER else SUPPLIER
    fun prefix(type: String) = if (type == CUSTOMER) "C" else "S"
    fun sideLabel(type: String) = if (type == CUSTOMER) tr("عميل", "Customer") else tr("مورد", "Supplier")
    fun settleLabel(type: String) = if (type == CUSTOMER) tr("تحصيل من العميل", "Receive from customer") else tr("سداد للمورد", "Pay supplier")

    /** الفواتير التي تؤثر على حساب الطرف */
    fun mainType(type: String) = if (type == CUSTOMER) Shop.SALE else Shop.PURCHASE
    fun returnType(type: String) = if (type == CUSTOMER) Shop.SRETURN else Shop.PRETURN

    suspend fun nextCode(dao: AppDao, type: String): String {
        val used = dao.allPartys().filter { it.type == type }.mapNotNull { it.code.substringAfter("-").toIntOrNull() }
        return prefix(type) + "-" + ((used.maxOrNull() ?: 0) + 1).toString().padStart(4, '0')
    }

    private fun digits(s: String) = s.filter { it.isDigit() }.takeLast(9)

    /** ربط الفواتير القديمة بالعملاء/الموردين وإنشاء بطاقة لكل طرف غير مسجّل */
    suspend fun sync(dao: AppDao) {
        val invs = dao.allInvoices().filter { it.partyId == null && it.partyName.isNotBlank() }
        if (invs.isEmpty()) return
        val parties = dao.allPartys().toMutableList()
        for (i in invs) {
            val type = typeOf(i.type)
            val ph = digits(i.partyPhone)
            var p = parties.firstOrNull { it.type == type && i.personId != null && it.personId == i.personId }
                ?: parties.firstOrNull { it.type == type && ph.length >= 7 && digits(it.phone) == ph }
                ?: parties.firstOrNull { it.type == type && it.name.trim().equals(i.partyName.trim(), true) }
            if (p == null) {
                val np = Party(code = nextCode(dao, type), name = i.partyName.trim(), type = type, phone = i.partyPhone, personId = i.personId)
                p = np.copy(id = dao.insertParty(np))
                parties += p
            }
            dao.setInvoiceParty(i.id, p.id)
        }
    }

    // ---------------- كشف الحساب ----------------
    data class Line(val date: Long, val kind: String, val ref: String, val debit: Double, val credit: Double, val invoiceId: Long? = null, val txId: Long? = null) {
        var balance: Double = 0.0
    }

    data class Statement(
        val p: Party, val lines: List<Line>, val rows: List<Shop.InvRow>, val txs: List<PartyTx>,
        val opening: Double, val balance: Double, val sales: Double, val returns: Double, val paid: Double
    ) {
        val inst get() = rows.filter { it.hasInst && !it.isPaid }
        val lateInst get() = round2(inst.sumOf { it.lateAmount })
        val nextInst get() = inst.mapNotNull { r -> r.nextInst?.let { r to it } }.minByOrNull { it.second.due }
        val overLimit get() = p.creditLimit > 0 && balance > p.creditLimit
    }

    /**
     * يبني كشف الحساب. الرصيد الموجب = العميل مدين لي / أنا مدين للمورد.
     * @param range إن وُجد يُحسب رصيد ما قبل الفترة كرصيد افتتاحي.
     */
    fun account(p: Party, invs: List<Invoice>, items: List<InvoiceItem>, pays: List<InvoicePayment>, txs: List<PartyTx>, range: LongRange? = null): Statement {
        val mine = invs.filter { it.partyId == p.id && Shop.isMoney(it.type) }
        val rows = Shop.rows(mine, items, pays)
        val main = mainType(p.type)
        val all = mutableListOf<Line>()
        rows.forEach { r ->
            val isRet = r.inv.type != main
            val label = Shop.type(r.inv.type).label + " " + Shop.numberText(r.inv)
            if (isRet) all += Line(r.inv.date, "RET", label, 0.0, r.t.total, invoiceId = r.inv.id)
            else all += Line(r.inv.date, "INV", label, r.t.total, 0.0, invoiceId = r.inv.id)
            pays.filter { it.invoiceId == r.inv.id }.forEach { pay ->
                val l = (if (isRet) tr("رد مبلغ مرتجع ", "Refund of ") else tr("دفعة ", "Payment ")) + Shop.numberText(r.inv) + " • " + Shop.method(pay.method).label
                if (isRet) all += Line(pay.date, "REFUND", l, pay.amount, 0.0, invoiceId = r.inv.id)
                else all += Line(pay.date, "PAY", l, 0.0, pay.amount, invoiceId = r.inv.id)
            }
        }
        val myTx = txs.filter { it.partyId == p.id }
        myTx.forEach { t ->
            if (t.type == CHARGE) all += Line(t.date, "CHARGE", tr("إشعار مدين", "Debit note") + (if (t.note.isNotBlank()) " • " + t.note else ""), t.amount, 0.0, txId = t.id)
            else all += Line(t.date, "SETTLE", settleLabel(p.type) + " • " + Shop.method(t.method).label + (if (t.note.isNotBlank()) " • " + t.note else ""), 0.0, t.amount, txId = t.id)
        }
        all.sortWith(compareBy({ it.date }, { if (it.debit > 0) 0 else 1 }))
        var opening = p.opening
        val shown = mutableListOf<Line>()
        all.forEach { l -> if (range != null && l.date < range.first) opening += l.debit - l.credit else if (range == null || l.date <= range.last) shown += l }
        var bal = opening
        shown.forEach { l -> bal += l.debit - l.credit; l.balance = round2(bal) }
        val total = round2(p.opening + all.sumOf { it.debit - it.credit })
        return Statement(
            p, shown, rows, myTx, round2(opening), total,
            round2(rows.filter { it.inv.type == main }.sumOf { it.t.total }),
            round2(rows.filter { it.inv.type != main }.sumOf { it.t.total }),
            round2(all.filter { it.kind == "PAY" || it.kind == "SETTLE" }.sumOf { it.credit })
        )
    }

    // ---------------- أعمار الديون ----------------
    data class Aging(val current: Double, val d30: Double, val d60: Double, val d90: Double, val over90: Double) {
        val total get() = round2(current + d30 + d60 + d90 + over90)
    }

    fun aging(a: Statement): Aging {
        val today = Fmt.today()
        val b = DoubleArray(5)
        a.rows.filter { it.inv.type == mainType(a.p.type) && !it.isPaid }.forEach { r ->
            if (r.hasInst) r.schedule.filter { !it.isPaid }.forEach { x -> b[bucket(today - x.due)] += x.remaining }
            else b[bucket(today - (r.inv.dueDate ?: r.inv.date))] += r.remaining
        }
        // الرصيد الافتتاحي وإشعارات المدين تُحتسب في الأقدم، والسندات غير الموزعة تُخصم من الأقدم
        var extra = a.p.opening + a.txs.filter { it.type == CHARGE }.sumOf { it.amount } - a.txs.filter { it.type == SETTLE }.sumOf { it.amount } -
            a.rows.filter { it.inv.type != mainType(a.p.type) }.sumOf { it.remaining }
        if (extra > 0) b[4] += extra
        else {
            var i = 4
            while (extra < -0.005 && i >= 0) { val take = minOf(b[i], -extra); b[i] -= take; extra += take; i-- }
        }
        return Aging(round2(b[0]), round2(b[1]), round2(b[2]), round2(b[3]), round2(b[4]))
    }

    private fun bucket(daysLate: Long) = when { daysLate <= 0 -> 0; daysLate <= 30 -> 1; daysLate <= 60 -> 2; daysLate <= 90 -> 3; else -> 4 }

    /**
     * تحصيل/سداد يُوزَّع تلقائياً على الفواتير المفتوحة الأقدم فالأحدث (والأقساط بالترتيب)،
     * وما يزيد يُسجل كدفعة مقدمة على الحساب.
     */
    suspend fun settle(dao: AppDao, p: Party, amount: Double, date: Long, method: String, accountId: Long?, note: String): Long? {
        val invs = dao.allInvoices().filter { it.partyId == p.id && it.type == mainType(p.type) }
        val rows = Shop.rows(invs, dao.allInvoiceItems(), dao.allInvoicePayments()).filter { !it.isPaid }
            .sortedWith(compareBy({ it.nextInst?.due ?: it.inv.dueDate ?: it.inv.date }, { it.inv.date }))
        var left = round2(amount)
        val isIn = p.type == CUSTOMER
        for (r in rows) {
            if (left < 0.01) break
            val take = minOf(left, r.remaining)
            val pid = dao.insertInvoicePayment(InvoicePayment(invoiceId = r.inv.id, amount = take, date = date, method = method, note = note.ifBlank { settleLabel(p.type) }))
            Posting.post(accountId, AccountTx.SRC_INV, pid, isIn, take, date, Shop.numberText(r.inv) + " • " + p.name)
            left = round2(left - take)
        }
        if (left >= 0.01) {
            val tid = dao.insertPartyTx(PartyTx(partyId = p.id, type = SETTLE, amount = left, date = date, method = method, note = note.ifBlank { tr("دفعة مقدمة على الحساب", "Advance on account") }))
            Posting.post(accountId, AccountTx.SRC_PARTY, tid, isIn, left, date, settleLabel(p.type) + " • " + p.name)
            return tid
        }
        return null
    }

    fun whatsappStatement(a: Statement): String {
        val sb = StringBuilder()
        val shop = Extras.shopName
        sb.append(tr("السلام عليكم ", "Hello ")).append(a.p.name).append('\n')
        if (shop.isNotBlank()) sb.append(tr("كشف حسابكم لدى ", "Your statement at ")).append(shop).append('\n')
        sb.append(tr("رقم الحساب: ", "Account no.: ")).append(a.p.code).append('\n')
        sb.append(tr("إجمالي الفواتير: ", "Total invoices: ")).append(Fmt.money(a.sales)).append('\n')
        if (a.returns > 0) sb.append(tr("المرتجعات: ", "Returns: ")).append(Fmt.money(a.returns)).append('\n')
        sb.append(tr("المدفوع: ", "Paid: ")).append(Fmt.money(a.paid)).append('\n')
        sb.append(if (a.balance >= 0) tr("الرصيد المستحق: ", "Balance due: ") else tr("رصيد دائن لكم: ", "Credit balance: ")).append(Fmt.money(kotlin.math.abs(a.balance))).append('\n')
        if (a.lateInst > 0) sb.append(tr("أقساط متأخرة: ", "Overdue installments: ")).append(Fmt.money(a.lateInst)).append('\n')
        a.nextInst?.let { (r, x) -> sb.append(tr("القسط القادم: ", "Next installment: ")).append(Fmt.money(x.remaining)).append(" • ").append(Fmt.date(x.due)).append(" (").append(Shop.numberText(r.inv)).append(")\n") }
        sb.append(tr("شاكرين تعاملكم 🌹", "Thank you 🌹"))
        return sb.toString()
    }
}

// =====================================================================
//                    حركات الصنف وتقارير المبيعات والمشتريات
// =====================================================================
object StockReports {
    data class Move(
        val date: Long, val kind: String, val ref: String, val party: String,
        val qtyIn: Double, val qtyOut: Double, val price: Double, val invoiceId: Long? = null
    ) {
        var balance: Double = 0.0
    }

    fun kindLabel(k: String) = when (k) {
        "OPEN" -> tr("رصيد افتتاحي", "Opening balance")
        "ADJ_IN" -> tr("تسوية بالزيادة", "Adjustment +")
        "ADJ_OUT" -> tr("تسوية بالنقص", "Adjustment −")
        else -> Shop.type(k).label
    }

    data class Ledger(val p: Product, val opening: Double, val moves: List<Move>, val closing: Double) {
        val inQty get() = round2(moves.sumOf { it.qtyIn })
        val outQty get() = round2(moves.sumOf { it.qtyOut })
        fun qty(kind: String) = round2(moves.filter { it.kind == kind }.sumOf { it.qtyIn + it.qtyOut })
        fun amount(kind: String) = round2(moves.filter { it.kind == kind }.sumOf { (it.qtyIn + it.qtyOut) * it.price })
    }

    fun ledger(p: Product, invs: List<Invoice>, items: List<InvoiceItem>, adjs: List<StockAdj>, range: LongRange?): Ledger {
        val im = invs.associateBy { it.id }
        val all = mutableListOf<Move>()
        items.filter { it.productId == p.id }.forEach { x ->
            val i = im[x.invoiceId] ?: return@forEach
            val sign = Shop.stockSign(i.type)
            if (sign == 0.0) return@forEach
            all += Move(i.date, i.type, Shop.numberText(i), i.partyName, if (sign > 0) x.qty else 0.0, if (sign < 0) x.qty else 0.0, x.price, i.id)
        }
        adjs.filter { it.productId == p.id }.forEach { a ->
            all += Move(a.date, if (a.qty >= 0) "ADJ_IN" else "ADJ_OUT", a.note, "", if (a.qty > 0) a.qty else 0.0, if (a.qty < 0) -a.qty else 0.0, p.cost)
        }
        all.sortWith(compareBy({ it.date }, { if (it.qtyIn > 0) 0 else 1 }))
        var opening = p.openingQty
        val shown = mutableListOf<Move>()
        all.forEach { m -> if (range != null && m.date < range.first) opening += m.qtyIn - m.qtyOut else if (range == null || m.date <= range.last) shown += m }
        var bal = opening
        shown.forEach { m -> bal += m.qtyIn - m.qtyOut; m.balance = round2(bal) }
        return Ledger(p, round2(opening), shown, round2(bal))
    }

    data class ItemSum(val key: String, val name: String, val qty: Double, val retQty: Double, val amount: Double, val retAmount: Double, val cost: Double, val count: Int) {
        val netQty get() = round2(qty - retQty)
        val net get() = round2(amount - retAmount)
        val profit get() = round2(net - cost)
        val avgPrice get() = if (qty > 0) round2(amount / qty) else 0.0
    }

    /**
     * تقرير المبيعات أو المشتريات خلال فترة، مجمّع حسب الصنف.
     * @param side CUSTOMER للمبيعات، SUPPLIER للمشتريات
     */
    fun bySide(side: String, invs: List<Invoice>, items: List<InvoiceItem>, range: LongRange?, productId: Long? = null, partyId: Long? = null): List<ItemSum> {
        val main = Parties.mainType(side); val ret = Parties.returnType(side)
        val ok = invs.filter { (it.type == main || it.type == ret) && (range == null || it.date in range) && (partyId == null || it.partyId == partyId) }.associateBy { it.id }
        return items.filter { it.invoiceId in ok && (productId == null || it.productId == productId) }
            .groupBy { it.productId?.toString() ?: it.name.trim() }
            .map { (k, l) ->
                val sales = l.filter { ok[it.invoiceId]?.type == main }
                val rets = l.filter { ok[it.invoiceId]?.type == ret }
                ItemSum(k, l.first().name, round2(sales.sumOf { it.qty }), round2(rets.sumOf { it.qty }),
                    round2(sales.sumOf { it.qty * it.price }), round2(rets.sumOf { it.qty * it.price }),
                    round2(sales.sumOf { it.qty * it.cost } - rets.sumOf { it.qty * it.cost }), sales.map { it.invoiceId }.distinct().size)
            }.sortedByDescending { it.net }
    }

    /** المبيعات/المشتريات اليومية أو الشهرية للفترة */
    fun byMonth(side: String, rows: List<Shop.InvRow>, range: LongRange?): List<Triple<String, Double, Int>> {
        val main = Parties.mainType(side); val ret = Parties.returnType(side)
        return rows.filter { (it.inv.type == main || it.inv.type == ret) && (range == null || it.inv.date in range) }
            .groupBy { LocalDate.ofEpochDay(it.inv.date).let { d -> "%04d-%02d".format(d.year, d.monthValue) } }
            .toSortedMap()
            .map { (m, l) -> Triple(m, round2(l.sumOf { if (it.inv.type == main) it.t.total else -it.t.total }), l.count { it.inv.type == main }) }
    }
}
