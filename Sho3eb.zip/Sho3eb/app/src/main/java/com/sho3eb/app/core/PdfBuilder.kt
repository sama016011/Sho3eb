package com.sho3eb.app.core

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** مولد تقارير PDF يدعم العربية (من اليمين لليسار) والإنجليزية */
class PdfBuilder(private val rtl: Boolean) {
    private val pageW = 595
    private val pageH = 842
    private val margin = 32f
    private val contentW = pageW - 2 * margin
    private val bottomLimit = pageH - 44f

    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var canvas: Canvas? = null
    private var y = 0f
    private var pageNo = 0

    private val brand = if (Brand.enabled) Brand.color else Color.rgb(15, 118, 110)
    private val app = com.sho3eb.app.Sho3ebApp.instance
    private val logoBmp by lazy { if (Brand.enabled) Brand.bmp(Brand.logo(app)) else null }
    private val headerH by lazy { if (Brand.enabled) 62f + Brand.headerLines().size * 13f else 58f }
    private val brandLight = Color.rgb(204, 251, 241)
    private val stripe = Color.rgb(244, 247, 247)
    private val border = Color.rgb(210, 220, 218)
    private val gray = Color.rgb(90, 100, 100)

    private fun paint(size: Float, bold: Boolean = false, color: Int = Color.BLACK) =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun layout(text: String, p: TextPaint, width: Float, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width.toInt().coerceAtLeast(10))
            .setAlignment(align)
            .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
            .setIncludePad(false)
            .build()

    private fun draw(l: StaticLayout, x: Float, yy: Float) {
        val c = canvas ?: return
        c.save()
        c.translate(x, yy)
        l.draw(c)
        c.restore()
    }

    private fun newPage() {
        finishPage()
        pageNo++
        val info = PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create()
        val pg = doc.startPage(info)
        page = pg
        canvas = pg.canvas
        drawHeader()
    }

    private fun drawHeader() {
        val c = canvas ?: return
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy  HH:mm", Locale.US))
        if (!Brand.enabled) {
            c.drawRect(0f, 0f, pageW.toFloat(), 58f, Paint().apply { color = brand })
            draw(layout("Sho3eb", paint(22f, true, Color.WHITE), contentW), margin, 16f)
            draw(layout(tr("تاريخ التقرير: ", "Report date: ") + stamp, paint(10f, false, Color.WHITE), contentW, Layout.Alignment.ALIGN_OPPOSITE), margin, 24f)
            y = 58f + 22f
            return
        }
        val h = headerH
        c.drawRect(0f, 0f, pageW.toFloat(), 6f, Paint().apply { color = brand })
        val logoW = 56f
        val lb = logoBmp
        var textX = margin
        var textW = contentW - 120f
        if (lb != null) {
            val k = logoW / maxOf(lb.width, lb.height)
            val w = lb.width * k; val hh = lb.height * k
            val lx = if (rtl) pageW - margin - w else margin
            c.drawBitmap(lb, null, android.graphics.RectF(lx, 14f, lx + w, 14f + hh), Paint(Paint.FILTER_BITMAP_FLAG))
            textW -= logoW + 10f
            if (!rtl) textX += logoW + 10f
        }
        if (rtl) textX = pageW - margin - textW - (if (lb != null) logoW + 10f else 0f)
        var yy = 14f
        val nm = layout(Brand.name.ifBlank { "Sho3eb" }, paint(18f, true, brand), textW)
        draw(nm, textX, yy); yy += nm.height + 2f
        if (Brand.subtitle.isNotBlank()) { val l = layout(Brand.subtitle, paint(10f, true, gray), textW); draw(l, textX, yy); yy += l.height + 2f }
        for (line in Brand.headerLines()) { val l = layout(line, paint(9f, false, Color.DKGRAY), textW); draw(l, textX, yy); yy += l.height + 1f }
        val dx = if (rtl) margin else pageW - margin - 115f
        draw(layout(tr("تاريخ التقرير", "Report date") + "\n" + stamp, paint(9f, false, gray), 115f, Layout.Alignment.ALIGN_OPPOSITE), dx, 16f)
        val bottom = maxOf(yy, h) + 4f
        c.drawLine(margin, bottom, pageW - margin, bottom, Paint().apply { color = brand; strokeWidth = 2f })
        c.drawLine(margin, bottom + 3f, pageW - margin, bottom + 3f, Paint().apply { color = brand; strokeWidth = 0.6f })
        y = bottom + 18f
    }

    private fun drawFooter() {
        val c = canvas
        val ft = if (Brand.enabled) (Brand.footer.ifBlank { Brand.name.ifBlank { "Sho3eb" } }) else "Sho3eb"
        if (Brand.enabled && c != null) c.drawLine(margin, pageH - 34f, pageW - margin, pageH - 34f, Paint().apply { color = border; strokeWidth = 0.6f })
        val l = layout(tr("صفحة $pageNo", "Page $pageNo") + "  •  " + ft, paint(9f, false, gray), contentW, Layout.Alignment.ALIGN_CENTER)
        draw(l, margin, pageH - 28f)
    }

    /** خانة التوقيع والختم في نهاية المستند */
    fun signatureBlock() {
        if (!Brand.enabled || (!Brand.showSignature && !Brand.showStamp)) return
        val sig = if (Brand.showSignature) Brand.bmp(Brand.signature(app)) else null
        val stp = if (Brand.showStamp) Brand.bmp(Brand.stamp(app)) else null
        ensure(130f)
        val c = canvas ?: return
        y += 10f
        val boxW = 180f
        val sx = if (rtl) margin else pageW - margin - boxW
        val tx = if (rtl) pageW - margin - boxW else margin
        if (Brand.showSignature) {
            draw(layout(tr("التوقيع", "Signature"), paint(10f, true, brand), boxW, Layout.Alignment.ALIGN_CENTER), sx, y)
            if (sig != null) {
                val k = minOf(boxW / sig.width, 70f / sig.height)
                val w = sig.width * k; val h = sig.height * k
                c.drawBitmap(sig, null, android.graphics.RectF(sx + (boxW - w) / 2, y + 16f, sx + (boxW + w) / 2, y + 16f + h), Paint(Paint.FILTER_BITMAP_FLAG))
            }
            c.drawLine(sx + 10f, y + 90f, sx + boxW - 10f, y + 90f, Paint().apply { color = gray; strokeWidth = 0.7f })
            val who = listOf(Brand.signerName, Brand.signerTitle).filter { it.isNotBlank() }.joinToString(" - ")
            if (who.isNotBlank()) draw(layout(who, paint(9f, false, Color.DKGRAY), boxW, Layout.Alignment.ALIGN_CENTER), sx, y + 94f)
        }
        if (stp != null) {
            val s = 105f
            val k = s / maxOf(stp.width, stp.height)
            val w = stp.width * k; val h = stp.height * k
            val cx = if (Brand.showSignature) tx + boxW / 2 else pageW / 2f
            c.save(); c.rotate(-12f, cx, y + 55f)
            c.drawBitmap(stp, null, android.graphics.RectF(cx - w / 2, y + 55f - h / 2, cx + w / 2, y + 55f + h / 2), Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 215 })
            c.restore()
        }
        y += 120f
    }

    private fun finishPage() {
        val pg = page ?: return
        drawFooter()
        doc.finishPage(pg)
        page = null
        canvas = null
    }

    private fun ensure(h: Float) {
        if (page == null || y + h > bottomLimit) newPage()
    }

    fun title(t: String) {
        val l = layout(t, paint(18f, true, brand), contentW)
        ensure(l.height + 8f)
        draw(l, margin, y)
        y += l.height + 8f
    }

    fun section(t: String) {
        val l = layout(t, paint(13f, true, brand), contentW)
        ensure(l.height + 30f)
        y += 6f
        draw(l, margin, y)
        y += l.height + 4f
        canvas?.drawLine(margin, y, pageW - margin, y, Paint().apply { color = brand; strokeWidth = 1.2f })
        y += 8f
    }

    fun text(t: String, size: Float = 11f, bold: Boolean = false) {
        if (t.isBlank()) return
        val l = layout(t, paint(size, bold, Color.DKGRAY), contentW)
        ensure(l.height + 4f)
        draw(l, margin, y)
        y += l.height + 4f
    }

    /** مربع معلومات: أزواج (عنوان، قيمة) في عمودين */
    fun infoBox(pairs: List<Pair<String, String>>) {
        val colW = contentW / 2
        val rows = pairs.chunked(2)
        val heights = rows.map { row ->
            row.maxOf { (k, v) -> layout("$k: $v", paint(11f), colW - 16f).height.toFloat() } + 8f
        }
        val total = heights.sum() + 12f
        ensure(total.coerceAtMost(bottomLimit - 80f))
        val c = canvas ?: return
        c.drawRoundRect(margin, y, pageW - margin, y + total, 8f, 8f, Paint().apply { color = brandLight })
        var yy = y + 6f
        rows.forEachIndexed { i, row ->
            row.forEachIndexed { j, (k, v) ->
                val x = if (rtl) pageW - margin - colW * (j + 1) + 8f else margin + colW * j + 8f
                val p = paint(11f)
                val l = layout("$k: $v", p, colW - 16f)
                draw(l, x, yy + 4f)
            }
            yy += heights[i]
        }
        y += total + 10f
    }

    fun table(headers: List<String>, rows: List<List<String>>, weights: List<Float>, rowColors: List<Int?>? = null) {
        val sum = weights.sum()
        val widths = weights.map { it / sum * contentW }
        val pad = 5f
        val xs = FloatArray(widths.size)
        var acc = 0f
        for (i in widths.indices) {
            xs[i] = if (rtl) pageW - margin - acc - widths[i] else margin + acc
            acc += widths[i]
        }
        val linePaint = Paint().apply { color = border; strokeWidth = 0.7f }

        fun drawRow(cells: List<String>, header: Boolean, bgColor: Int?) {
            val p = if (header) paint(10f, true, Color.WHITE) else paint(10f)
            val ls = cells.mapIndexed { i, c -> layout(c, p, widths[i] - 2 * pad) }
            val h = (ls.maxOfOrNull { it.height } ?: 10).toFloat() + 2 * pad
            if (page == null || y + h > bottomLimit) {
                newPage()
                if (!header) drawRow(headers, true, null)
            }
            val c = canvas ?: return
            val bg = when {
                header -> brand
                else -> bgColor
            }
            if (bg != null) c.drawRect(margin, y, pageW - margin, y + h, Paint().apply { color = bg })
            ls.forEachIndexed { i, l -> draw(l, xs[i] + pad, y + pad) }
            c.drawLine(margin, y + h, pageW - margin, y + h, linePaint)
            y += h
        }

        ensure(60f)
        drawRow(headers, true, null)
        rows.forEachIndexed { i, r ->
            val color = rowColors?.getOrNull(i) ?: if (i % 2 == 1) stripe else null
            drawRow(r, false, color)
        }
        y += 10f
    }

    fun totals(pairs: List<Pair<String, String>>) {
        for ((k, v) in pairs) {
            val l = layout("$k:  $v", paint(12f, true, Color.BLACK), contentW)
            ensure(l.height + 6f)
            draw(l, margin, y)
            y += l.height + 6f
        }
    }

    fun spacer(h: Float = 10f) {
        y += h
    }

    fun save(file: File): File {
        if (page == null && pageNo == 0) newPage()
        runCatching { signatureBlock() }
        finishPage()
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    companion object {
        val PAID = Color.rgb(220, 252, 231)
        val LATE = Color.rgb(254, 226, 226)
        val PARTIAL = Color.rgb(254, 243, 199)
        val TOTAL = Color.rgb(226, 232, 240)
    }
}
