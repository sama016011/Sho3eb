package com.sho3eb.app.core

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.text.TextPaint
import android.text.TextUtils
import com.sho3eb.app.data.Product
import com.sho3eb.app.ui.ProductImages
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * قائمة الأسعار الاحترافية للأصناف المعروضة للبيع:
 * أشكال متعددة (قائمة / مربعات بعدد أعمدة / مقسمة حسب التصنيف) وأنماط ألوان، مع شعار المحل والصور، وتصدير PDF.
 */
object PriceList {
    data class Opts(
        val layout: String = "GRID",        // LIST | GRID
        val cols: Int = 3,
        val group: Boolean = true,          // تقسيم حسب التصنيف
        val images: Boolean = true,
        val style: String = "CLASSIC",      // CLASSIC | ELEGANT | MODERN | FRESH
        val title: String = tr("قائمة الأسعار", "Price list"),
        val note: String = "",
        val showUnit: Boolean = true,
        val showSku: Boolean = false,
        val showDesc: Boolean = false,
        val sort: String = "NAME",          // NAME | PRICE_UP | PRICE_DOWN | CATEGORY
        val cats: Set<String>? = null
    )

    data class Item(val id: Long, val name: String, val price: Double, val unit: String, val cat: String, val sku: String, val desc: String)

    private sealed class Block(val h: Float) {
        class Cat(val name: String, val count: Int) : Block(34f)
        class Row(val it: Item, h: Float) : Block(h)
        class Grid(val items: List<Item>, h: Float) : Block(h)
    }

    private const val W = 595f
    private const val H = 842f
    private const val M = 28f

    fun noCat() = tr("أصناف أخرى", "Other items")

    /** الأصناف المعروضة للبيع فقط (غير الخامات، المفعّلة، ولها سعر بيع) */
    fun items(products: List<Product>, o: Opts): List<Item> {
        val l = products.filter { !Manufacture.isRaw(it) && it.active && it.price > 0 }
            .map { Item(it.id, it.name, it.price, it.unit, it.category.trim().ifBlank { noCat() }, it.sku, it.notes) }
            .filter { o.cats == null || it.cat in o.cats }
        return when (o.sort) {
            "PRICE_UP" -> l.sortedBy { it.price }
            "PRICE_DOWN" -> l.sortedByDescending { it.price }
            "CATEGORY" -> l.sortedWith(compareBy({ it.cat }, { it.name }))
            else -> l.sortedBy { it.name }
        }
    }

    private class Theme(val pageBg: Int, val headBg: Int, val headText: Int, val accent: Int, val cardBg: Int, val cardBorder: Int, val text: Int, val sub: Int, val price: Int, val priceBg: Int, val catBg: Int, val catText: Int)
    private fun theme(style: String): Theme {
        val b = if (Brand.enabled) Brand.color else Color.rgb(15, 118, 110)
        return when (style) {
            "ELEGANT" -> Theme(Color.rgb(250, 248, 243), Color.rgb(28, 32, 48), Color.rgb(242, 216, 140), Color.rgb(212, 175, 55), Color.WHITE, Color.rgb(222, 200, 140), Color.rgb(30, 30, 30), Color.rgb(120, 110, 90), Color.rgb(28, 32, 48), Color.rgb(246, 236, 205), Color.rgb(28, 32, 48), Color.rgb(242, 216, 140))
            "MODERN" -> Theme(Color.rgb(242, 244, 247), b, Color.WHITE, b, Color.WHITE, Color.rgb(226, 230, 235), Color.rgb(25, 30, 40), Color.rgb(110, 118, 130), Color.WHITE, b, Color.WHITE, b)
            "FRESH" -> Theme(Color.WHITE, Color.rgb(255, 112, 67), Color.WHITE, Color.rgb(255, 112, 67), Color.rgb(255, 248, 240), Color.rgb(255, 204, 188), Color.rgb(40, 40, 40), Color.rgb(120, 120, 120), Color.rgb(216, 67, 21), Color.rgb(255, 236, 224), Color.rgb(255, 236, 224), Color.rgb(191, 54, 12))
            else -> Theme(Color.WHITE, b, Color.WHITE, b, Color.WHITE, Color.rgb(220, 226, 226), Color.rgb(25, 25, 25), Color.rgb(110, 115, 115), b, Color.argb(28, Color.red(b), Color.green(b), Color.blue(b)), Color.argb(30, Color.red(b), Color.green(b), Color.blue(b)), b)
        }
    }

    private fun gridCardH(o: Opts): Float {
        val cw = (W - 2 * M - (o.cols - 1) * 10f) / o.cols
        return (if (o.images) cw * 0.72f else 0f) + (if (o.showDesc) 64f else 50f) + (if (o.showSku) 10f else 0f)
    }
    private fun rowH(o: Opts) = (if (o.images) 58f else 34f) + if (o.showDesc) 12f else 0f

    private fun paginate(items: List<Item>, o: Opts): List<List<Block>> {
        val blocks = mutableListOf<Block>()
        val groups: List<Pair<String?, List<Item>>> = if (o.group) items.groupBy { it.cat }.toList().sortedBy { if (it.first == noCat()) "￿" else it.first } else listOf(null to items)
        for ((cat, list) in groups) {
            if (cat != null) blocks += Block.Cat(cat, list.size)
            if (o.layout == "GRID") list.chunked(o.cols.coerceIn(1, 5)).forEach { blocks += Block.Grid(it, gridCardH(o) + 10f) }
            else list.forEach { blocks += Block.Row(it, rowH(o)) }
        }
        val pages = mutableListOf<MutableList<Block>>()
        var y = 0f; var cur = mutableListOf<Block>()
        fun avail(first: Boolean) = H - 40f - (if (first) 150f else 70f)
        for ((i, b) in blocks.withIndex()) {
            val keepWithNext = b is Block.Cat && i + 1 < blocks.size
            val need = b.h + if (keepWithNext) blocks[i + 1].h else 0f
            if (cur.isNotEmpty() && y + need > avail(pages.isEmpty())) { pages += cur; cur = mutableListOf(); y = 0f }
            cur += b; y += b.h
        }
        if (cur.isNotEmpty() || pages.isEmpty()) pages += cur
        return pages
    }

    private val imgCache = HashMap<Long, Bitmap?>()
    private fun img(id: Long): Bitmap? = imgCache.getOrPut(id) {
        ProductImages.get(id)?.let { p ->
            runCatching {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(p, o)
                var s = 1; while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= 360) s *= 2
                BitmapFactory.decodeFile(p, BitmapFactory.Options().apply { inSampleSize = s })
            }.getOrNull()
        }
    }

    private fun tp(size: Float, color: Int, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }

    /** نص في صندوق [x, x+w] بمحاذاة البداية/الوسط/النهاية مع اختصار النص الطويل */
    private fun txt(c: Canvas, s: String, x: Float, y: Float, w: Float, p: TextPaint, align: Int, rtl: Boolean) {
        val t = TextUtils.ellipsize(s, p, w, TextUtils.TruncateAt.END).toString()
        val tw = p.measureText(t)
        val a = if (rtl && align != 0) -align else align   // -1 بداية ، 0 وسط ، 1 نهاية (بالنسبة للغة)
        val xx = when (a) { -1 -> x; 0 -> x + (w - tw) / 2; else -> x + w - tw }
        c.drawText(t, xx, y, p)
    }

    private fun placeholder(c: Canvas, r: RectF, name: String, th: Theme) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.priceBg }
        c.drawRoundRect(r, 8f, 8f, p)
        txt(c, name.trim().take(1).uppercase(), r.left, r.centerY() + r.height() * 0.15f, r.width(), tp(r.height() * 0.42f, th.accent, true), 0, false)
    }

    private fun drawImage(c: Canvas, b: Bitmap, r: RectF, radius: Float) {
        val k = maxOf(r.width() / b.width, r.height() / b.height); val sw = (r.width() / k).toInt(); val sh = (r.height() / k).toInt()
        val src = Rect((b.width - sw) / 2, (b.height - sh) / 2, (b.width + sw) / 2, (b.height + sh) / 2)
        c.save(); c.clipPath(Path().apply { addRoundRect(r, radius, radius, Path.Direction.CW) })
        c.drawBitmap(b, src, r, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)); c.restore()
    }

    private fun drawPage(ctx: Context, c: Canvas, blocks: List<Block>, pageNo: Int, total: Int, o: Opts, count: Int) {
        val rtl = AppState.isRtl
        val th = theme(o.style)
        c.drawColor(th.pageBg)
        var y: Float
        val name = Brand.name.ifBlank { Edition.appName }
        if (pageNo == 1) {
            val hh = 128f
            c.drawRect(0f, 0f, W, hh, Paint().apply { color = th.headBg })
            if (o.style == "ELEGANT") { val g = Paint().apply { color = th.accent; strokeWidth = 2f }; c.drawLine(M, hh - 8f, W - M, hh - 8f, g) }
            val logo = Brand.bmp(Brand.logo(ctx))
            var tx = M; var tw = W - 2 * M
            if (logo != null) {
                val s = 76f; val k = s / maxOf(logo.width, logo.height); val lw = logo.width * k; val lh = logo.height * k
                val lx = if (rtl) W - M - lw else M
                val bgR = RectF(lx - 6f, 20f, lx + lw + 6f, 20f + lh + 12f)
                c.drawRoundRect(bgR, 10f, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
                c.drawBitmap(logo, null, RectF(lx, 26f, lx + lw, 26f + lh), Paint(Paint.FILTER_BITMAP_FLAG))
                tw -= lw + 22f; if (!rtl) tx += lw + 22f
            }
            txt(c, name, tx, 46f, tw, tp(22f, th.headText, true), -1, rtl)
            txt(c, o.title, tx, 72f, tw, tp(15f, th.headText.let { if (o.style == "ELEGANT") th.accent else it }, true), -1, rtl)
            val contact = listOf(Brand.phone, Brand.address, Brand.website).filter { it.isNotBlank() }.joinToString("  •  ")
            if (contact.isNotBlank()) txt(c, contact, tx, 94f, tw, tp(9.5f, Color.argb(220, Color.red(th.headText), Color.green(th.headText), Color.blue(th.headText))), -1, rtl)
            val date = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())
            txt(c, tr("تاريخ القائمة: ", "Date: ") + date + "   •   " + tr("عدد الأصناف: ", "Items: ") + count, tx, 114f, tw, tp(9f, Color.argb(200, Color.red(th.headText), Color.green(th.headText), Color.blue(th.headText))), -1, rtl)
            y = hh + 18f
            if (o.note.isNotBlank()) { txt(c, o.note, M, y + 4f, W - 2 * M, tp(10f, th.sub), 0, rtl); y += 18f }
        } else {
            c.drawRect(0f, 0f, W, 44f, Paint().apply { color = th.headBg })
            txt(c, name + "  —  " + o.title, M, 28f, W - 2 * M, tp(12f, th.headText, true), -1, rtl)
            y = 62f
        }
        val cw = W - 2 * M
        for (b in blocks) {
            when (b) {
                is Block.Cat -> {
                    val r = RectF(M, y + 4f, W - M, y + 28f)
                    c.drawRoundRect(r, 6f, 6f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.catBg })
                    val bar = if (rtl) RectF(W - M - 5f, r.top, W - M, r.bottom) else RectF(M, r.top, M + 5f, r.bottom)
                    c.drawRect(bar, Paint().apply { color = th.accent })
                    txt(c, b.name + "  (" + b.count + ")", M + 14f, y + 21f, cw - 28f, tp(12.5f, th.catText, true), -1, rtl)
                }
                is Block.Row -> {
                    val it = b.it
                    val r = RectF(M, y + 2f, W - M, y + b.h - 2f)
                    c.drawRoundRect(r, 8f, 8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.cardBg })
                    c.drawRoundRect(r, 8f, 8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.cardBorder; style = Paint.Style.STROKE; strokeWidth = 0.8f })
                    var left = r.left + 8f; var right = r.right - 8f
                    if (o.images) {
                        val s = b.h - 12f
                        val ir = if (rtl) RectF(right - s, r.top + 4f, right, r.top + 4f + s) else RectF(left, r.top + 4f, left + s, r.top + 4f + s)
                        img(it.id)?.let { bm -> drawImage(c, bm, ir, 6f) } ?: placeholder(c, ir, it.name, th)
                        if (rtl) right -= s + 10f else left += s + 10f
                    }
                    val priceW = 110f
                    val pr = if (rtl) RectF(left, r.centerY() - 12f, left + priceW, r.centerY() + 12f) else RectF(right - priceW, r.centerY() - 12f, right, r.centerY() + 12f)
                    c.drawRoundRect(pr, 12f, 12f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.priceBg })
                    txt(c, Fmt.money(it.price), pr.left, pr.centerY() + 4.5f, pr.width(), tp(12.5f, th.price, true), 0, false)
                    if (rtl) left += priceW + 10f else right -= priceW + 10f
                    val nameY = if (o.showDesc || o.showUnit || o.showSku) r.centerY() - 2f else r.centerY() + 5f
                    txt(c, it.name, left, nameY, right - left, tp(12.5f, th.text, true), -1, rtl)
                    val sub = listOfNotNull(it.unit.takeIf { o.showUnit && it.isNotBlank() }?.let { u -> tr("الوحدة: ", "Unit: ") + u }, it.sku.takeIf { o.showSku && it.isNotBlank() }?.let { s -> "#$s" }, it.desc.takeIf { o.showDesc && it.isNotBlank() }).joinToString("  •  ")
                    if (sub.isNotBlank()) txt(c, sub, left, nameY + 15f, right - left, tp(9.5f, th.sub), -1, rtl)
                }
                is Block.Grid -> {
                    val gap = 10f; val n = o.cols.coerceIn(1, 5)
                    val cardW = (cw - (n - 1) * gap) / n; val cardH = b.h - 10f
                    b.items.forEachIndexed { k, it ->
                        val idx = if (rtl) n - 1 - k else k
                        val x = M + idx * (cardW + gap)
                        val r = RectF(x, y, x + cardW, y + cardH)
                        val sh = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.cardBg; setShadowLayer(4f, 0f, 1.5f, Color.argb(40, 0, 0, 0)) }
                        c.drawRoundRect(r, 10f, 10f, sh)
                        c.drawRoundRect(r, 10f, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.cardBorder; style = Paint.Style.STROKE; strokeWidth = 0.8f })
                        var ty = r.top
                        if (o.images) {
                            val ir = RectF(r.left + 6f, r.top + 6f, r.right - 6f, r.top + 6f + cardW * 0.72f - 6f)
                            img(it.id)?.let { bm -> drawImage(c, bm, ir, 8f) } ?: placeholder(c, ir, it.name, th)
                            ty = ir.bottom
                        }
                        val fs = if (n >= 4) 10f else 11.5f
                        txt(c, it.name, r.left + 6f, ty + 17f, cardW - 12f, tp(fs, th.text, true), 0, rtl)
                        var yy = ty + 17f
                        val sub = listOfNotNull(it.unit.takeIf { o.showUnit && it.isNotBlank() }, it.sku.takeIf { o.showSku && it.isNotBlank() }?.let { s -> "#$s" }).joinToString(" • ")
                        if (sub.isNotBlank()) { yy += 12f; txt(c, sub, r.left + 6f, yy, cardW - 12f, tp(8.5f, th.sub), 0, rtl) }
                        if (o.showDesc && it.desc.isNotBlank()) { yy += 12f; txt(c, it.desc, r.left + 6f, yy, cardW - 12f, tp(8.5f, th.sub), 0, rtl) }
                        val pw = minOf(cardW - 16f, 96f)
                        val pr = RectF(r.centerX() - pw / 2, r.bottom - 26f, r.centerX() + pw / 2, r.bottom - 7f)
                        c.drawRoundRect(pr, 10f, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = th.priceBg })
                        txt(c, Fmt.money(it.price), pr.left, pr.centerY() + 4f, pr.width(), tp(if (n >= 4) 10f else 11.5f, th.price, true), 0, false)
                    }
                }
            }
            y += b.h
        }
        // التذييل
        c.drawLine(M, H - 30f, W - M, H - 30f, Paint().apply { color = th.cardBorder; strokeWidth = 0.6f })
        val ft = (if (Brand.footer.isNotBlank()) Brand.footer + "   •   " else "") + tr("صفحة $pageNo من $total", "Page $pageNo of $total")
        txt(c, ft, M, H - 15f, W - 2 * M, tp(9f, th.sub), 0, rtl)
    }

    fun pageCount(items: List<Item>, o: Opts) = paginate(items, o).size

    /** صورة صفحة للمعاينة داخل التطبيق */
    fun preview(ctx: Context, items: List<Item>, o: Opts, page: Int, scale: Float = 1.4f): Bitmap {
        val pages = paginate(items, o)
        val i = page.coerceIn(0, pages.lastIndex)
        val b = Bitmap.createBitmap((W * scale).toInt(), (H * scale).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(b); c.scale(scale, scale)
        drawPage(ctx, c, pages[i], i + 1, pages.size, o, items.size)
        return b
    }

    fun pdf(ctx: Context, items: List<Item>, o: Opts): File {
        imgCache.clear()
        val pages = paginate(items, o)
        val doc = PdfDocument()
        pages.forEachIndexed { i, bl ->
            val pg = doc.startPage(PdfDocument.PageInfo.Builder(W.toInt(), H.toInt(), i + 1).create())
            drawPage(ctx, pg.canvas, bl, i + 1, pages.size, o, items.size)
            doc.finishPage(pg)
        }
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, (Brand.name.ifBlank { "Sho3eb" }.filter { it.isLetterOrDigit() || it == ' ' }.trim().replace(' ', '_').ifBlank { "Sho3eb" }) + "_price_list.pdf")
        f.outputStream().use { doc.writeTo(it) }; doc.close()
        return f
    }
    fun clearImages() = imgCache.clear()
}
