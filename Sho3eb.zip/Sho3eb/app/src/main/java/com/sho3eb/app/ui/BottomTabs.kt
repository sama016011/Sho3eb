package com.sho3eb.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.*

/** الشريط السفلي: ترتيب الأيقونات واختيارها (للنسخة الأصلية فقط؛ النسخ المصدّرة تأخذ الترتيب الحالي ولا يمكن تعديله) */
object BottomTabs {
    data class Tab(val route: String, val ar: String, val en: String, val icon: ImageVector) { val label get() = tr(ar, en) }
    val all = listOf(
        Tab("home", "الرئيسية", "Home", Icons.Filled.Home),
        Tab("assocs", "الجمعيات", "Associations", Icons.Filled.Groups),
        Tab("loans", "السلف", "Loans", Icons.Filled.Payments),
        Tab("sales", "الأقساط", "Installments", Icons.Filled.ShoppingCart),
        Tab("islam", "إسلاميات", "Islamic", Icons.Filled.Brightness3),
        Tab("chat", "التواصل", "Chat", Icons.Filled.Chat),
        Tab("football", "الكرة", "Football", Icons.Filled.SportsSoccer),
        Tab("media", "الوسائط", "Media", Icons.Filled.LiveTv),
        Tab("shop", "المحل", "Shop", Icons.Filled.Storefront),
        Tab("quran", "المصحف", "Quran", Icons.Filled.MenuBook),
        Tab("dashboard", "لوحة المؤشرات", "Dashboard", Icons.Filled.Insights),
        Tab("more", "المزيد", "More", Icons.Filled.MoreHoriz)
    )
    private val default = listOf("home", "assocs", "loans", "sales", "islam", "more")
    /** يمكن التعديل فقط في النسخة الأصلية */
    val editable get() = !Edition.isShared
    val version = mutableIntStateOf(0)
    var order: List<String>
        get() {
            val emb = if (Edition.isShared) Edition.embeddedString("bottom_tabs") else ""
            val s = emb.ifBlank { Extras.s("bottom_tabs", "") }
            val l = s.split(",").filter { r -> all.any { it.route == r } }.distinct()
            return (l.ifEmpty { default }).let { if ("more" in it) it else it + "more" }
        }
        set(v) { Extras.ps("bottom_tabs", (v.distinct().filter { it != "more" } + "more").joinToString(",")); version.intValue++ }
    fun tabs(): List<Tab> = order.mapNotNull { r -> all.firstOrNull { it.route == r } }.filter { Edition.allowsRoute(it.route) }
}

@Composable
fun BottomTabsScreen(nav: NavController) {
    var list by remember { mutableStateOf(BottomTabs.order) }
    ScreenScaffold(title = tr("ترتيب الشريط السفلي", "Bottom bar order"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                Text(tr("رتّب الأيقونات بالأسهم واختر ما يظهر (حتى 5 أيقونات + المزيد). النسخ التي تصدّرها تأخذ هذا الترتيب ولا يمكن تعديله فيها.", "Reorder with the arrows and choose what shows (up to 5 + More). Exported copies use this order and can't change it."), style = MaterialTheme.typography.bodySmall)
            }
            item { Text(tr("الظاهر في الشريط", "Shown in the bar"), fontWeight = FontWeight.Bold) }
            itemsIndexed(list, key = { _, r -> "on$r" }) { i, r ->
                val t = BottomTabs.all.first { it.route == r }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(t.icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp))
                        Text(t.label, Modifier.weight(1f))
                        if (r != "more") {
                            IconButton(enabled = i > 0, onClick = { list = list.toMutableList().apply { add(i - 1, removeAt(i)) } }) { Icon(Icons.Filled.KeyboardArrowUp, null) }
                            IconButton(enabled = i < list.size - 2, onClick = { list = list.toMutableList().apply { add(i + 1, removeAt(i)) } }) { Icon(Icons.Filled.KeyboardArrowDown, null) }
                            IconButton(enabled = list.size > 2, onClick = { list = list - r }) { Icon(Icons.Filled.RemoveCircleOutline, null, tint = MaterialTheme.colorScheme.error) }
                        } else Text(tr("ثابت", "Fixed"), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            item { Text(tr("أيقونات يمكن إضافتها", "Available icons"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
            BottomTabs.all.filter { it.route !in list && Edition.allowsRoute(it.route) }.forEach { t ->
                item(key = "off" + t.route) {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(t.icon, null); Spacer(Modifier.width(10.dp)); Text(t.label, Modifier.weight(1f))
                            IconButton(enabled = list.size < 6, onClick = { list = list.filter { it != "more" } + t.route + "more" }) { Icon(Icons.Filled.AddCircleOutline, null, tint = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { BottomTabs.order = list; nav.popBackStack() }, modifier = Modifier.weight(1f)) { Text(tr("حفظ", "Save")) }
                    OutlinedButton(onClick = { list = listOf("home", "assocs", "loans", "sales", "islam", "more") }, modifier = Modifier.weight(1f)) { Text(tr("الافتراضي", "Default")) }
                }
            }
        }
    }
}
