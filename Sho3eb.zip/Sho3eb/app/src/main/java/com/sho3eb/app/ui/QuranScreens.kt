@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.navigation.NavController
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import com.sho3eb.app.islam.*
import kotlinx.coroutines.launch

private data class MushafColors(val bg: Color, val text: Color, val accent: Color, val highlight: Color)

private fun mushafColors(theme: String) = when (theme) {
    "night" -> MushafColors(Color(0xFF101413), Color(0xFFE8E1D3), Color(0xFFFBBF24), Color(0x553B82F6))
    "white" -> MushafColors(Color.White, Color(0xFF111111), Color(0xFF0F766E), Color(0x40FBBF24))
    else -> MushafColors(Color(0xFFFBF6E9), Color(0xFF2B2117), Color(0xFF8A5A14), Color(0x50F59E0B))
}

// ============================ فهرس المصحف ============================
@Composable
fun QuranIndexScreen(nav: NavController) {
    val ready = rememberQuranReady()
    var tab by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    var bookmarks by remember { mutableStateOf(IslamPrefs.bookmarks) }
    var dlSurah by remember { mutableStateOf<Surah?>(null) }

    ScreenScaffold(
        title = tr("المصحف الشريف", "The Holy Quran"),
        onBack = { nav.popBackStack() },
        actions = {
            IconButton(onClick = { nav.navigate("reciters") }) { Icon(Icons.Filled.RecordVoiceOver, null) }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!ready) {
                Column(Modifier.padding(16.dp)) { QuranDownloadCard() }
                return@Column
            }
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(
                    onClick = { nav.navigate("mushaf/${IslamPrefs.lastPage}") },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MenuBook, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tr("متابعة القراءة", "Continue reading"), fontWeight = FontWeight.Bold)
                            val a = QuranRepo.page(IslamPrefs.lastPage).firstOrNull()
                            Text(
                                tr("صفحة ", "Page ") + IslamPrefs.lastPage + (a?.let { " • " + (QuranRepo.surah(it.surah)?.let { s -> QuranRepo.surahNameClean(s) } ?: "") + tr(" • الجزء ", " • Juz ") + it.juz } ?: ""),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Icon(Icons.Filled.ChevronLeft, null)
                    }
                }
                SearchField(q) { q = it }
                if (q.length < 2) TabRow(selectedTabIndex = tab) {
                    Tab(tab == 0, { tab = 0 }, text = { Text(tr("السور", "Surahs")) })
                    Tab(tab == 1, { tab = 1 }, text = { Text(tr("الأجزاء", "Juz")) })
                    Tab(tab == 2, { tab = 2; bookmarks = IslamPrefs.bookmarks }, text = { Text(tr("العلامات", "Bookmarks")) })
                }
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 80.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (q.length >= 2) {
                    val res = QuranRepo.search(q)
                    item { Text(tr("${res.size} نتيجة", "${res.size} results"), color = MaterialTheme.colorScheme.primary) }
                    items(res, key = { "s${it.global}" }) { a ->
                        Card(onClick = { nav.navigate("mushaf/${a.page}?hl=${a.global}") }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    (QuranRepo.surah(a.surah)?.let { QuranRepo.surahNameClean(it) } ?: "") + " • " + tr("آية ", "Ayah ") + a.num + tr(" • صفحة ", " • Page ") + a.page,
                                    color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall
                                )
                                Text(a.text, fontSize = 18.sp, lineHeight = 32.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                } else when (tab) {
                    0 -> items(QuranRepo.surahs, key = { "q${it.num}" }) { s ->
                        Card(onClick = { nav.navigate("mushaf/${s.startPage}") }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                                    Text("${s.num}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(QuranRepo.surahNameClean(s), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Text(
                                        (if (s.type == "Meccan") tr("مكية", "Meccan") else tr("مدنية", "Medinan")) + " • " + tr("${s.count} آية", "${s.count} ayat") + tr(" • ص ", " • p. ") + s.startPage,
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { dlSurah = s }) { Icon(Icons.Filled.DownloadForOffline, null, tint = MaterialTheme.colorScheme.primary) }
                            }
                        }
                    }
                    1 -> items((1..30).toList(), key = { "j$it" }) { j ->
                        val p = QuranRepo.juzStartPage(j)
                        val a = QuranRepo.page(p).firstOrNull { it.juz == j }
                        Card(onClick = { nav.navigate("mushaf/$p") }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(tr("الجزء ", "Juz ") + j, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(
                                    (a?.let { (QuranRepo.surah(it.surah)?.let { s -> QuranRepo.surahNameClean(s) } ?: "") + " " + it.num } ?: "") + tr(" • ص ", " • p. ") + p,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                    else -> {
                        if (bookmarks.isEmpty()) item { EmptyState(Icons.Filled.Bookmark, tr("لا توجد علامات. اضغط على أي آية واختر \"علامة توقف\".", "No bookmarks. Tap any ayah and choose \"Bookmark\".")) }
                        items(bookmarks.sortedByDescending { it.time }, key = { "b${it.global}_${it.time}" }) { b ->
                            val a = QuranRepo.ayah(b.global)
                            Card(onClick = { nav.navigate("mushaf/${b.page}?hl=${b.global}") }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Bookmark, null, tint = MaterialTheme.colorScheme.secondary)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            (a?.let { QuranRepo.surah(it.surah)?.let { s -> QuranRepo.surahNameClean(s) } } ?: "") + tr(" • آية ", " • Ayah ") + (a?.num ?: "") + tr(" • ص ", " • p. ") + b.page,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(com.sho3eb.app.core.Fmt.date(java.time.Instant.ofEpochMilli(b.time).atZone(java.time.ZoneId.systemDefault()).toLocalDate()), style = MaterialTheme.typography.bodySmall)
                                    }
                                    IconButton(onClick = {
                                        IslamPrefs.bookmarks = IslamPrefs.bookmarks.filterNot { it.time == b.time && it.global == b.global }
                                        bookmarks = IslamPrefs.bookmarks
                                    }) { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    dlSurah?.let { s -> DownloadAyatDialog(tr("تنزيل سورة ", "Download surah ") + QuranRepo.surahNameClean(s), QuranRepo.refs("${s.num}").map { it.global }) { dlSurah = null } }
}

/** نافذة تنزيل صوت مجموعة آيات للقارئ الحالي */
@Composable
fun DownloadAyatDialog(title: String, globals: List<Int>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var done by remember { mutableIntStateOf(-1) }
    var ok by remember { mutableIntStateOf(0) }
    val reciter = remember { QuranRepo.reciterById(IslamPrefs.reciter) }
    val already = remember { globals.count { QuranRepo.isAudioDownloaded(ctx, reciter.id, it) } }
    AlertDialog(
        onDismissRequest = { if (done < 0 || done >= globals.size) onDismiss() },
        icon = { Icon(Icons.Filled.DownloadForOffline, null) },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("القارئ: ", "Reciter: ") + IslamPrefs.reciterName)
                Text(tr("عدد الآيات: ${globals.size} • منزّل مسبقاً: $already", "Ayat: ${globals.size} • already downloaded: $already"), style = MaterialTheme.typography.bodySmall)
                if (done >= 0) {
                    LinearProgressIndicator(progress = { done.toFloat() / globals.size.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth())
                    Text("$done / ${globals.size}")
                    if (done >= globals.size) Text(tr("اكتمل: $ok آية متاحة بدون إنترنت ✅", "Done: $ok ayat available offline ✅"), color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        confirmButton = {
            if (done < 0) TextButton(onClick = {
                done = 0
                scope.launch { ok = QuranRepo.downloadMany(ctx, reciter, globals) { d, _ -> done = d } }
            }) { Text(tr("تنزيل", "Download")) }
            else if (done >= globals.size) TextButton(onClick = onDismiss) { Text(tr("تم", "Done")) }
        },
        dismissButton = { if (done < 0) TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// ============================ صفحات المصحف ============================
@Composable
fun MushafScreen(nav: NavController, startPage: Int, highlight: Int) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val ready = rememberQuranReady()
    var chrome by remember { mutableStateOf(true) }
    var theme by remember { mutableStateOf(IslamPrefs.mushafTheme) }
    var mode by remember { mutableStateOf(IslamPrefs.mushafMode) }
    var font by remember { mutableIntStateOf(IslamPrefs.fontSize) }
    var selected by remember { mutableStateOf<Int?>(if (highlight > 0) highlight else null) }
    var sheetAyah by remember { mutableStateOf<Ayah?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var bookmarks by remember { mutableStateOf(IslamPrefs.bookmarks.map { it.global }.toSet()) }
    val colors = mushafColors(theme)
    val pager = rememberPagerState(initialPage = (startPage - 1).coerceIn(0, QuranRepo.PAGES - 1)) { QuranRepo.PAGES }
    // التكبير والتصغير: في وضع النص يُغيَّر حجم الخط، وفي وضع الصور تُكبَّر الصفحة مع السحب
    var liveFont by remember { mutableFloatStateOf(IslamPrefs.fontSize.toFloat()) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var boxSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    LaunchedEffect(pager.currentPage) { zoom = 1f; pan = androidx.compose.ui.geometry.Offset.Zero }
    fun clampPan(p: androidx.compose.ui.geometry.Offset, z: Float): androidx.compose.ui.geometry.Offset {
        val mx = (z - 1f) * boxSize.width / 2f
        val my = (z - 1f) * boxSize.height / 2f
        return androidx.compose.ui.geometry.Offset(p.x.coerceIn(-mx, mx), p.y.coerceIn(-my, my))
    }
    fun applyZoom(f: Float, d: androidx.compose.ui.geometry.Offset) {
        if (mode == "image") {
            zoom = (zoom * f).coerceIn(1f, 4f)
            pan = if (zoom <= 1.01f) androidx.compose.ui.geometry.Offset.Zero else clampPan(pan + d, zoom)
        } else {
            liveFont = (liveFont * f).coerceIn(14f, 64f)
            font = liveFont.toInt()
        }
    }

    // إبقاء الشاشة مضاءة + ملء الشاشة
    DisposableEffect(Unit) {
        view.keepScreenOn = IslamPrefs.keepScreenOn
        onDispose {
            view.keepScreenOn = false
            (view.context as? Activity)?.window?.let { WindowCompat.getInsetsController(it, view).show(WindowInsetsCompat.Type.systemBars()) }
        }
    }
    LaunchedEffect(chrome) {
        val w = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val c = WindowCompat.getInsetsController(w, view)
        if (chrome) c.show(WindowInsetsCompat.Type.systemBars())
        else {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
    LaunchedEffect(pager.currentPage) { IslamPrefs.lastPage = pager.currentPage + 1 }
    // متابعة الصفحة أثناء التلاوة
    val playing = SeqPlayer.playingAyah.value
    LaunchedEffect(playing) {
        val g = playing ?: return@LaunchedEffect
        val p = QuranRepo.pageOf(g)
        if (p - 1 != pager.currentPage) pager.animateScrollToPage(p - 1)
    }

    if (!ready) {
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) { QuranDownloadCard() }
        return
    }

    val curPage = pager.currentPage + 1
    val first = QuranRepo.page(curPage).firstOrNull()
    Box(
        Modifier.fillMaxSize().background(colors.bg)
            .onSizeChanged { boxSize = it }
            .mushafZoom(
                panEnabled = { mode == "image" && zoom > 1.01f },
                onZoom = { f, d -> applyZoom(f, d) },
                onEnd = { if (mode != "image") IslamPrefs.fontSize = font }
            )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), beyondBoundsPageCount = 1, userScrollEnabled = zoom <= 1.01f) { index ->
                val isCur = index == pager.currentPage
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        if (isCur && zoom > 1f) { scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y }
                    }
                ) {
                    MushafPage(
                        page = index + 1, mode = mode, colors = colors, font = font,
                        selected = selected, playing = playing, bookmarks = bookmarks,
                        topPad = if (chrome) 64 else 16,
                        onAyah = { a -> selected = a.global; sheetAyah = a },
                        onBlank = { chrome = !chrome }
                    )
                }
            }
        }
        if (mode == "image" && zoom > 1.01f) {
            AssistChip(
                onClick = { zoom = 1f; pan = androidx.compose.ui.geometry.Offset.Zero },
                label = { Text("${(zoom * 100).toInt()}% • " + tr("إعادة", "Reset")) },
                modifier = Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 80.dp)
            )
        }
        if (chrome) {
            Surface(color = colors.bg.copy(alpha = 0.96f), shadowElevation = 4.dp, modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)) {
                Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = colors.text) }
                    Column(Modifier.weight(1f)) {
                        Text(first?.let { QuranRepo.surah(it.surah)?.let { s -> QuranRepo.surahNameClean(s) } } ?: "", color = colors.text, fontWeight = FontWeight.Bold)
                        Text(tr("الجزء ", "Juz ") + (first?.juz ?: "") + tr(" • صفحة ", " • Page ") + curPage, color = colors.text.copy(alpha = 0.7f), fontSize = 12.sp)
                    }
                    IconButton(onClick = {
                        val list = QuranRepo.page(curPage)
                        if (SeqPlayer.active.value) SeqPlayer.stop()
                        else SeqPlayer.play(ctx, list.map { Seg.AyahSeg(it.global) }, QuranRepo.reciterById(IslamPrefs.reciter), tr("صفحة $curPage", "Page $curPage"), IslamPrefs.repeatAyah)
                    }) { Icon(if (SeqPlayer.active.value) Icons.Filled.Stop else Icons.Filled.PlayArrow, null, tint = colors.accent) }
                    IconButton(onClick = {
                        first?.let { a ->
                            IslamPrefs.bookmarks = IslamPrefs.bookmarks + Bookmark(a.global, curPage, System.currentTimeMillis())
                            bookmarks = IslamPrefs.bookmarks.map { it.global }.toSet()
                            toast(ctx, tr("تم حفظ علامة التوقف 🔖", "Bookmark saved 🔖"))
                        }
                    }) { Icon(Icons.Filled.BookmarkBorder, null, tint = colors.text) }
                    IconButton(onClick = { applyZoom(1.15f, androidx.compose.ui.geometry.Offset.Zero); if (mode != "image") IslamPrefs.fontSize = font }) { Icon(Icons.Filled.ZoomIn, tr("تكبير", "Zoom in"), tint = colors.text) }
                    IconButton(onClick = { applyZoom(1f / 1.15f, androidx.compose.ui.geometry.Offset.Zero); if (mode != "image") IslamPrefs.fontSize = font }) { Icon(Icons.Filled.ZoomOut, tr("تصغير", "Zoom out"), tint = colors.text) }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Filled.Tune, null, tint = colors.text) }
                }
            }
        }
        Box(Modifier.align(Alignment.BottomCenter)) { MiniPlayerBar() }
    }

    sheetAyah?.let { a ->
        AyahSheet(a, onDismiss = { sheetAyah = null }, onBookmark = {
            IslamPrefs.bookmarks = IslamPrefs.bookmarks.filterNot { it.global == a.global } + Bookmark(a.global, a.page, System.currentTimeMillis())
            bookmarks = IslamPrefs.bookmarks.map { it.global }.toSet()
            toast(ctx, tr("تم وضع علامة التوقف 🔖", "Bookmark saved 🔖"))
        })
    }
    if (showSettings) MushafSettingsDialog(
        theme, mode, font,
        onTheme = { theme = it; IslamPrefs.mushafTheme = it },
        onMode = { mode = it; IslamPrefs.mushafMode = it },
        onFont = { font = it; liveFont = it.toFloat(); IslamPrefs.fontSize = it },
        onReciters = { showSettings = false; nav.navigate("reciters") },
        onDismiss = { showSettings = false }
    )
}

@Composable
private fun MushafPage(
    page: Int, mode: String, colors: MushafColors, font: Int, selected: Int?, playing: Int?,
    bookmarks: Set<Int>, topPad: Int, onAyah: (Ayah) -> Unit, onBlank: () -> Unit
) {
    val ayat = QuranRepo.page(page)
    // تقسيم الصفحة إلى مقاطع حسب السور
    val blocks = remember(page) {
        val out = mutableListOf<MutableList<Ayah>>()
        ayat.forEach { a -> if (out.isEmpty() || a.num == 1) out += mutableListOf(a) else out.last() += a }
        out
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null) { onBlank() }
            .padding(start = 14.dp, end = 14.dp, top = topPad.dp, bottom = 90.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        blocks.forEach { block ->
            val head = block.first()
            if (head.num == 1) {
                val s = QuranRepo.surah(head.surah)
                Box(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(12.dp))
                        .background(colors.accent.copy(alpha = 0.12f)).padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("۞ " + (s?.let { QuranRepo.surahNameClean(it) } ?: "") + " ۞", color = colors.accent, fontWeight = FontWeight.Bold, fontSize = (font + 2).sp)
                }
                if (head.surah != 1 && head.surah != 9) {
                    Text("بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", color = colors.text, fontSize = font.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(bottom = 6.dp))
                }
            }
            if (mode == "image") {
                block.forEach { a ->
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                            .background(if (a.global == playing || a.global == selected) colors.highlight else Color.Transparent)
                            .clickable { onAyah(a) }.padding(vertical = 2.dp)
                    ) {
                        NetImage(QuranRepo.ayahImageUrl(a), "${a.surah}_${a.num}.png", invert = colors.bg.red < 0.3f)
                    }
                }
            } else {
                val text = buildAnnotatedString {
                    block.forEach { a ->
                        val bg = when (a.global) { playing -> colors.highlight; selected -> colors.highlight.copy(alpha = 0.6f); else -> Color.Transparent }
                        pushStringAnnotation("a", a.global.toString())
                        withStyle(SpanStyle(background = bg)) { append(a.text) }
                        withStyle(SpanStyle(color = colors.accent, fontWeight = FontWeight.Bold)) {
                            append(" ﴿" + QuranRepo.arabicNum(a.num) + "﴾")
                            if (a.global in bookmarks) append("🔖")
                            if (a.sajda) append("۩")
                        }
                        pop()
                        append(" ")
                    }
                }
                ClickableText(
                    text = text,
                    style = TextStyle(color = colors.text, fontSize = font.sp, lineHeight = (font * 1.9).sp, textAlign = TextAlign.Justify, textDirection = androidx.compose.ui.text.style.TextDirection.Rtl),
                    modifier = Modifier.fillMaxWidth()
                ) { off ->
                    val ann = text.getStringAnnotations("a", off, off).firstOrNull()
                    val a = ann?.item?.toIntOrNull()?.let { QuranRepo.ayah(it) }
                    if (a != null) onAyah(a) else onBlank()
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(QuranRepo.arabicNum(page), color = colors.text.copy(alpha = 0.6f), fontSize = 14.sp)
    }
}

// ============================ خيارات الآية ============================
@Composable
fun AyahSheet(a: Ayah, onDismiss: () -> Unit, onBookmark: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = QuranRepo.surah(a.surah)
    var panel by remember { mutableStateOf("") }          // tafsir / translation
    var panelText by remember { mutableStateOf<String?>(null) }
    var pickEdition by remember { mutableStateOf<String?>(null) }
    var repeat by remember { mutableIntStateOf(IslamPrefs.repeatAyah) }
    var downloading by remember { mutableStateOf(false) }
    val reciter = QuranRepo.reciterById(IslamPrefs.reciter)

    fun load(kind: String) {
        panel = kind; panelText = null
        scope.launch {
            panelText = try {
                QuranRepo.editionText(ctx, a.global, if (kind == "tafsir") IslamPrefs.tafsir else IslamPrefs.translation)
            } catch (e: Exception) {
                tr("تعذر التحميل. تحقق من الاتصال بالإنترنت أو نزّل التفسير للعمل بدون إنترنت.", "Could not load. Check your connection or download it for offline use.")
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                (s?.let { QuranRepo.surahNameClean(it) } ?: "") + tr(" • الآية ", " • Ayah ") + a.num + tr(" • صفحة ", " • Page ") + a.page,
                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
            )
            Text(a.text + " ﴿" + QuranRepo.arabicNum(a.num) + "﴾", fontSize = 21.sp, lineHeight = 38.sp)
            HorizontalDivider()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { onBookmark() }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Bookmark, null); Spacer(Modifier.width(4.dp)); Text(tr("علامة توقف", "Bookmark"), maxLines = 1) }
                FilledTonalButton(onClick = {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ayah", "${a.text} [${s?.let { QuranRepo.surahNameClean(it) }}: ${a.num}]"))
                    toast(ctx, tr("تم النسخ", "Copied"))
                }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.ContentCopy, null); Spacer(Modifier.width(4.dp)); Text(tr("نسخ", "Copy")) }
                FilledTonalButton(onClick = {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "﴿${a.text}﴾\n[${s?.let { QuranRepo.surahNameClean(it) }}: ${a.num}]")
                    ctx.startActivity(Intent.createChooser(i, null))
                }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(4.dp)); Text(tr("مشاركة", "Share")) }
            }

            SectionTitle(tr("الاستماع", "Listen"))
            Text(tr("القارئ: ", "Reciter: ") + IslamPrefs.reciterName, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { SeqPlayer.play(ctx, listOf(Seg.AyahSeg(a.global)), reciter, tr("الآية ", "Ayah ") + a.num, repeat) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.PlayArrow, null); Text(tr("الآية", "Ayah"))
                }
                Button(onClick = {
                    val rest = QuranRepo.refs("${a.surah}:${a.num}-${s?.count ?: a.num}").map { Seg.AyahSeg(it.global) }
                    SeqPlayer.play(ctx, rest, reciter, s?.let { QuranRepo.surahNameClean(it) } ?: "", repeat); onDismiss()
                }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.PlaylistPlay, null); Text(tr("من هنا", "From here")) }
                OutlinedButton(onClick = {
                    downloading = true
                    scope.launch {
                        val ok = QuranRepo.downloadAyahAudio(ctx, reciter, a.global)
                        downloading = false
                        toast(ctx, if (ok) tr("تم تنزيل صوت الآية ✅", "Ayah audio downloaded ✅") else tr("فشل التنزيل", "Download failed"))
                    }
                }, enabled = !downloading) {
                    if (downloading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Icon(if (QuranRepo.isAudioDownloaded(ctx, reciter.id, a.global)) Icons.Filled.DownloadDone else Icons.Filled.Download, null)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Filled.Repeat, null, tint = MaterialTheme.colorScheme.primary)
                Text(tr("التكرار:", "Repeat:"))
                listOf(1, 3, 5, 10).forEach { n ->
                    FilterChip(selected = repeat == n, onClick = { repeat = n; IslamPrefs.repeatAyah = n }, label = { Text("$n") })
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { load("tafsir") }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.MenuBook, null); Spacer(Modifier.width(4.dp)); Text(tr("التفسير", "Tafsir")) }
                OutlinedButton(onClick = { load("translation") }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Translate, null); Spacer(Modifier.width(4.dp)); Text(tr("الترجمة", "Translation")) }
            }
            if (panel.isNotEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (panel == "tafsir") IslamPrefs.tafsirName else IslamPrefs.translationName,
                                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { pickEdition = if (panel == "tafsir") "tafsir" else "translation" }) { Text(tr("تغيير", "Change")) }
                        }
                        val t = panelText
                        if (t == null) CircularProgressIndicator(Modifier.size(24.dp))
                        else Text(t, fontSize = 16.sp, lineHeight = 28.sp)
                    }
                }
            }
        }
    }
    pickEdition?.let { type ->
        EditionPickerDialog(type, onDismiss = { pickEdition = null }) { ed ->
            if (type == "tafsir") { IslamPrefs.tafsir = ed.id; IslamPrefs.tafsirName = ed.name } else { IslamPrefs.translation = ed.id; IslamPrefs.translationName = ed.name }
            pickEdition = null
            load(type)
        }
    }
}

@Composable
fun EditionPickerDialog(type: String, onDismiss: () -> Unit, onPick: (Edition) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by produceState<List<Edition>?>(null) { value = QuranRepo.editions(ctx, type) }
    var dl by remember { mutableStateOf<String?>(null) }
    var prog by remember { mutableStateOf(0f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == "tafsir") tr("اختيار التفسير", "Choose tafsir") else tr("اختيار الترجمة", "Choose translation")) },
        text = {
            val l = list
            if (l == null) CircularProgressIndicator()
            else LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(l, key = { it.id }) { e ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(e) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, fontWeight = FontWeight.SemiBold)
                            Text(e.lang.uppercase() + " • " + e.id, style = MaterialTheme.typography.bodySmall)
                        }
                        if (dl == e.id) CircularProgressIndicator(progress = { prog }, modifier = Modifier.size(24.dp))
                        else if (QuranRepo.isEditionDownloaded(ctx, e.id)) Icon(Icons.Filled.OfflinePin, null, tint = MaterialTheme.colorScheme.primary)
                        else IconButton(onClick = {
                            dl = e.id
                            scope.launch {
                                val ok = QuranRepo.downloadEdition(ctx, e.id) { prog = it }
                                dl = null
                                toast(ctx, if (ok) tr("تم التنزيل للعمل بدون إنترنت", "Downloaded for offline use") else tr("فشل التنزيل", "Download failed"))
                            }
                        }) { Icon(Icons.Filled.Download, null) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
}

@Composable
private fun MushafSettingsDialog(
    theme: String, mode: String, font: Int,
    onTheme: (String) -> Unit, onMode: (String) -> Unit, onFont: (Int) -> Unit, onReciters: () -> Unit, onDismiss: () -> Unit
) {
    var keepOn by remember { mutableStateOf(IslamPrefs.keepScreenOn) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("إعدادات المصحف", "Mushaf settings")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tr("طريقة العرض", "Display"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(mode == "text", { onMode("text") }, label = { Text(tr("نص", "Text")) }, leadingIcon = { Icon(Icons.Filled.TextFields, null, Modifier.size(18.dp)) })
                    FilterChip(mode == "image", { onMode("image") }, label = { Text(tr("صور المصحف", "Mushaf images")) }, leadingIcon = { Icon(Icons.Filled.Image, null, Modifier.size(18.dp)) })
                }
                Text(tr("لون الصفحة", "Page color"), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(theme == "cream", { onTheme("cream") }, label = { Text(tr("كريمي", "Cream")) })
                    FilterChip(theme == "white", { onTheme("white") }, label = { Text(tr("أبيض", "White")) })
                    FilterChip(theme == "night", { onTheme("night") }, label = { Text(tr("ليلي", "Night")) })
                }
                if (mode == "text") {
                    Text(tr("حجم الخط: $font", "Font size: $font"), fontWeight = FontWeight.Bold)
                    Slider(value = font.toFloat(), onValueChange = { onFont(it.toInt()) }, valueRange = 16f..40f)
                }
                SwitchRow(tr("إبقاء الشاشة مضاءة", "Keep screen on"), null, keepOn, Icons.Filled.LightMode) { keepOn = it; IslamPrefs.keepScreenOn = it }
                Text(tr("اضغط على أي مكان فارغ لملء الشاشة، وعلى الآية لخياراتها.", "Tap empty space for full screen, tap an ayah for options."), style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onReciters, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.RecordVoiceOver, null); Spacer(Modifier.width(6.dp)); Text(tr("القراء والتنزيلات", "Reciters & downloads"))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("تم", "Done")) } }
    )
}

// ============================ القراء ============================
@Composable
fun RecitersScreen(nav: NavController) {
    val ctx = LocalContext.current
    var reload by remember { mutableIntStateOf(0) }
    val list by produceState<List<Reciter>?>(null, reload) { value = QuranRepo.reciters(ctx) }
    var current by remember { mutableStateOf(IslamPrefs.reciter) }
    var showAdd by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf<Reciter?>(null) }

    ScreenScaffold(
        title = tr("القراء والتلاوات", "Reciters"),
        onBack = { nav.popBackStack() },
        fab = { ExtendedFloatingActionButton(onClick = { showAdd = true }, icon = { Icon(Icons.Filled.PersonAdd, null) }, text = { Text(tr("إضافة شيخ", "Add reciter")) }) }
    ) { pad ->
        val l = list
        if (l == null) { Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return@ScreenScaffold }
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                InfoBanner(tr(
                    "اختر الشيخ للاستماع. يمكنك تنزيل التلاوات من فهرس السور (زر التنزيل بجانب كل سورة) أو من خيارات الآية للاستماع بدون إنترنت.",
                    "Choose a reciter. Download recitations from the surah list or ayah options for offline listening."
                ), MaterialTheme.colorScheme.primary)
            }
            items(l, key = { it.id }) { r ->
                val count = remember(r.id, reload) { QuranRepo.downloadedCount(ctx, r.id) }
                Card(onClick = {
                    current = r.id; IslamPrefs.reciter = r.id; IslamPrefs.reciterName = r.name
                    toast(ctx, tr("تم اختيار ", "Selected ") + r.name)
                }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = current == r.id, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                (if (r.template != null) tr("مضاف يدوياً • ", "Custom • ") else "") + tr("منزّل: $count آية", "Downloaded: $count ayat"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (count > 0 || r.template != null) IconButton(onClick = { confirmDel = r }) { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
    if (showAdd) AddReciterDialog(onDismiss = { showAdd = false }) { showAdd = false; reload++ }
    confirmDel?.let { r ->
        ConfirmDialog(
            title = tr("حذف", "Delete"),
            text = if (r.template != null) tr("حذف الشيخ ${r.name} وملفاته المنزّلة؟", "Delete ${r.name} and its downloads?") else tr("حذف التلاوات المنزّلة للشيخ ${r.name}؟", "Delete downloaded audio of ${r.name}?"),
            confirmText = tr("حذف", "Delete"),
            onDismiss = { confirmDel = null }
        ) {
            QuranRepo.deleteReciterAudio(ctx, r.id)
            if (r.template != null) IslamPrefs.customReciters = IslamPrefs.customReciters.filterNot { it.id == r.id }
            reload++
        }
    }
}

@Composable
private fun AddReciterDialog(onDismiss: () -> Unit, onAdded: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var tpl by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("إضافة شيخ / تلاوة", "Add reciter")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم الشيخ", "Reciter name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(tpl, { tpl = it.trim() }, label = { Text(tr("رابط ملفات الآيات", "Ayah files URL template")) }, modifier = Modifier.fillMaxWidth())
                Text(
                    tr(
                        "استخدم في الرابط: {sss} رقم السورة بثلاث خانات، {aaa} رقم الآية بثلاث خانات، {s} و {a} بدون أصفار، {n} رقم الآية في المصحف كاملاً.",
                        "Use: {sss} 3-digit surah, {aaa} 3-digit ayah, {s} and {a} without zeros, {n} global ayah number."
                    ), style = MaterialTheme.typography.bodySmall
                )
                Text(tr("أمثلة جاهزة:", "Examples:"), fontWeight = FontWeight.Bold)
                QuranRepo.templateExamples.forEach { (n, t) ->
                    AssistChip(onClick = { name = n; tpl = t }, label = { Text(n) })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank() || !tpl.startsWith("http") || !(tpl.contains("{n}") || (tpl.contains("{a") && tpl.contains("{s")))) {
                    toast(ctx, tr("أدخل اسماً ورابطاً صحيحاً يحتوي على رقم السورة والآية", "Enter a name and a valid URL template"))
                    return@TextButton
                }
                IslamPrefs.customReciters = IslamPrefs.customReciters + CustomReciter("custom_" + System.currentTimeMillis(), name.trim(), tpl)
                onAdded()
            }) { Text(tr("إضافة", "Add")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/**
 * تكبير بإصبعين لصفحة المصحف: يلتقط الإيماءة قبل الصفحات (المرحلة الأولى) حتى لا تتقلب الصفحة أثناء التكبير.
 * عند التكبير في وضع الصور يمكن تحريك الصفحة بإصبع واحد.
 */
fun Modifier.mushafZoom(panEnabled: () -> Boolean, onZoom: (Float, androidx.compose.ui.geometry.Offset) -> Unit, onEnd: () -> Unit): Modifier =
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            var pinched = false
            var moved = 0f
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val pressed = event.changes.count { it.pressed }
                if (pressed >= 2) {
                    val z = event.calculateZoom()
                    val p = event.calculatePan()
                    if (z != 1f || p != androidx.compose.ui.geometry.Offset.Zero) onZoom(z, p)
                    pinched = true
                    event.changes.forEach { it.consume() }
                } else if (pressed == 1 && panEnabled()) {
                    val p = event.calculatePan()
                    moved += p.getDistance()
                    if (moved > viewConfiguration.touchSlop) {
                        onZoom(1f, p)
                        event.changes.forEach { it.consume() }
                    }
                } else if (pinched) {
                    event.changes.forEach { it.consume() }
                }
            } while (event.changes.any { it.pressed })
            if (pinched) onEnd()
        }
    }
