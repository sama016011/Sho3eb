package com.sho3eb.app.core

import android.content.Context
import android.content.SharedPreferences
import com.sho3eb.app.Sho3ebApp
import org.json.JSONObject

/** إعدادات الميزات الإضافية (ميزانيات، زكاة، مشاركة، سبحة، ختمة، متابعة الصلوات، المناسبات، الأذان) */
object Extras {
    private val sp: SharedPreferences
        get() = Sho3ebApp.instance.getSharedPreferences("extras_prefs", Context.MODE_PRIVATE)

    fun s(k: String, d: String) = sp.getString(k, d) ?: d
    fun ps(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun i(k: String, d: Int) = sp.getInt(k, d)
    fun pi(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun l(k: String, d: Long) = sp.getLong(k, d)
    fun pl(k: String, v: Long) = sp.edit().putLong(k, v).apply()
    fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun pb(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    fun f(k: String, d: Float) = sp.getFloat(k, d)
    fun pf(k: String, v: Float) = sp.edit().putFloat(k, v).apply()
    fun d(k: String, def: Double) = java.lang.Double.longBitsToDouble(sp.getLong(k, java.lang.Double.doubleToLongBits(def)))
    fun pd(k: String, v: Double) = sp.edit().putLong(k, java.lang.Double.doubleToLongBits(v)).apply()
    fun keys(prefix: String): List<String> = sp.all.keys.filter { it.startsWith(prefix) }

    // ---------------- رابط المشاركة ----------------
    var shareBaseUrl: String
        get() = s("shareBase", "https://sama016011.github.io/Sho3eb/")
        set(v) = ps("shareBase", v.trim())

    // ---------------- الميزانيات الشهرية لكل فئة ----------------
    var budgets: Map<String, Double>
        get() = try {
            val o = JSONObject(s("budgets", "{}"))
            o.keys().asSequence().associateWith { o.getDouble(it) }.filterValues { it > 0 }
        } catch (_: Exception) { emptyMap() }
        set(v) {
            val o = JSONObject()
            v.filterValues { it > 0 }.forEach { (k, x) -> o.put(k, x) }
            ps("budgets", o.toString())
        }
    var budgetAlerts: Boolean get() = b("budAlerts", true); set(v) = pb("budAlerts", v)
    var recurringNotify: Boolean get() = b("recNotify", true); set(v) = pb("recNotify", v)
    var autoCreateMonth: Boolean get() = b("autoMonth", true); set(v) = pb("autoMonth", v)

    // ---------------- الزكاة ----------------
    var goldPrice24: Double get() = d("gold24", 0.0); set(v) = pd("gold24", v)
    var silverPrice: Double get() = d("silverG", 0.0); set(v) = pd("silverG", v)
    var zakatHawl: Long get() = l("hawl", -1L); set(v) = pl("hawl", v)          // epochDay لبداية الحول
    var zakatRemind: Boolean get() = b("zakRem", true); set(v) = pb("zakRem", v)

    // ---------------- المناسبات ----------------
    var occasionsRemind: Boolean get() = b("occRem", true); set(v) = pb("occRem", v)
    var occasionsDaysBefore: Int get() = i("occDays", 1); set(v) = pi("occDays", v)
    var whiteDaysRemind: Boolean get() = b("whiteRem", true); set(v) = pb("whiteRem", v)
    var monThuRemind: Boolean get() = b("monThu", false); set(v) = pb("monThu", v)
    var hijriAdjust: Int get() = i("hijAdj", 0); set(v) = pi("hijAdj", v)              // تعديل يوم ±

    // ---------------- رمضان ----------------
    var suhoorRemind: Boolean get() = b("suhoor", true); set(v) = pb("suhoor", v)
    var suhoorMinutes: Int get() = i("suhoorMin", 45); set(v) = pi("suhoorMin", v)
    var imsakMinutes: Int get() = i("imsakMin", 10); set(v) = pi("imsakMin", v)
    var iftarDua: Boolean get() = b("iftarDua", true); set(v) = pb("iftarDua", v)

    // ---------------- الأذان ----------------
    /** مسار أذان صلاة معينة ("" = الافتراضي العام، "none" = إشعار فقط) */
    fun azanFor(p: Int): String = s("azanP_$p", "")
    fun setAzanFor(p: Int, v: String) = ps("azanP_$p", v)
    var azanVolume: Int get() = i("azVol", 100); set(v) = pi("azVol", v)
    var azanFadeIn: Boolean get() = b("azFade", false); set(v) = pb("azFade", v)
    var azanShortSec: Int get() = i("azShort", 0); set(v) = pi("azShort", v)          // 0 = كامل
    var azanDuaAfter: Boolean get() = b("azDua", true); set(v) = pb("azDua", v)
    var azanSilentInPocket: Boolean get() = b("azRinger", true); set(v) = pb("azRinger", v)  // احترام الوضع الصامت

    // ---------------- الختمة ----------------
    var khatmaDays: Int get() = i("kDays", 30); set(v) = pi("kDays", v)
    var khatmaStart: Long get() = l("kStart", -1L); set(v) = pl("kStart", v)
    var khatmaStartPage: Int get() = i("kStartPage", 1); set(v) = pi("kStartPage", v)
    var khatmaDone: Int get() = i("kDone", 0); set(v) = pi("kDone", v)                 // آخر صفحة أتمها
    var khatmaCount: Int get() = i("kCount", 0); set(v) = pi("kCount", v)              // عدد الختمات
    var wirdRemind: Boolean get() = b("wirdRem", true); set(v) = pb("wirdRem", v)
    var wirdMinute: Int get() = i("wirdMin", 20 * 60 + 30); set(v) = pi("wirdMin", v)

    // ---------------- السبحة ----------------
    var tasbeehIndex: Int get() = i("tsIdx", 0); set(v) = pi("tsIdx", v)
    var tasbeehTarget: Int get() = i("tsTarget", 33); set(v) = pi("tsTarget", v)
    var tasbeehCount: Int get() = i("tsCount", 0); set(v) = pi("tsCount", v)
    var tasbeehVibrate: Boolean get() = b("tsVib", true); set(v) = pb("tsVib", v)
    var tasbeehCustom: String get() = s("tsCustom", ""); set(v) = ps("tsCustom", v)
    fun tasbeehDay(day: Long): Int = i("tsDay_$day", 0)
    fun addTasbeehDay(day: Long, n: Int) = pi("tsDay_$day", tasbeehDay(day) + n)
    fun tasbeehTotal(key: String): Int = i("tsTot_$key", 0)
    fun addTasbeehTotal(key: String, n: Int) = pi("tsTot_$key", tasbeehTotal(key) + n)

    // ---------------- متابعة الصلوات ----------------
    /** 5 أحرف لكل يوم: 0 لم يُسجل، 1 في الوقت، 2 جماعة، 3 متأخرة، 4 قضاء، 5 لم أصلّ */
    fun prayerDay(day: Long): String = s("pt_$day", "00000")
    fun setPrayer(day: Long, k: Int, status: Int) {
        val c = prayerDay(day).toCharArray()
        if (k in 0..4) { c[k] = ('0' + status); ps("pt_$day", String(c)) }
    }
    /** السنن الرواتب: بت لكل سنة (قبل الفجر، قبل الظهر، بعد الظهر، بعد المغرب، بعد العشاء) + الوتر + الضحى */
    fun sunnahDay(day: Long): Int = i("ps_$day", 0)
    fun setSunnah(day: Long, v: Int) = pi("ps_$day", v)
    var prayerTrackNotify: Boolean get() = b("ptAction", true); set(v) = pb("ptAction", v)
}
