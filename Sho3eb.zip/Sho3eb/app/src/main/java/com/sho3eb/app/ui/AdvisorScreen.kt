@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun AdvisorScreen(nav: NavController) {
    var r by remember { mutableStateOf<Advisor.Report?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) { r = withContext(Dispatchers.IO) { runCatching { Advisor.analyze() }.getOrNull() } }
    var tab by remember { mutableIntStateOf(0) }
    ScreenScaffold(
        title = tr("المستشار المالي", "Financial advisor"), onBack = { nav.popBackStack() },
        actions = { IconButton(onClick = { r = null; reload++ }) { Icon(Icons.Filled.Refresh, null) } }
    ) { pad ->
        val rep = r
        if (rep == null) { Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return@ScreenScaffold }
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("التحليل", "Analysis")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("النصائح", "Tips")) })
                Tab(tab == 2, { tab = 2 }, text = { Text(tr("الأدوات", "Tools")) })
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        item { ScoreCard(rep) }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(tr("مكونات الدرجة", "Score breakdown"), fontWeight = FontWeight.Bold)
                                    rep.parts.forEach { p ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(p.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                            Text(p.note + "  ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("${p.score.coerceAtLeast(0)}/${p.max}", fontWeight = FontWeight.Bold)
                                        }
                                        val f = (p.score.coerceAtLeast(0).toFloat() / p.max).coerceIn(0f, 1f)
                                        LinearProgressIndicator(progress = { f }, modifier = Modifier.fillMaxWidth().height(6.dp), color = if (f >= 0.7f) SuccessGreen else if (f >= 0.4f) WarnAmber else DangerRed)
                                    }
                                }
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(tr("متوسط شهري", "Monthly average") + " (" + tr("${rep.months} شهر", "${rep.months} mo") + ")", fontWeight = FontWeight.Bold)
                                    KeyValue(tr("الدخل", "Income"), Fmt.money(rep.income), SuccessGreen)
                                    KeyValue(tr("المصروفات", "Expenses"), Fmt.money(rep.expense), DangerRed)
                                    KeyValue(tr("  • أساسية", "  • Needs"), Fmt.money(rep.essential))
                                    KeyValue(tr("  • مهمة وكماليات", "  • Wants"), Fmt.money(rep.wants))
                                    KeyValue(tr("  • ادخار مسجل", "  • Recorded savings"), Fmt.money(rep.savings))
                                    KeyValue(tr("الفائض", "Surplus"), Fmt.money(rep.income - rep.expense), if (rep.income >= rep.expense) SuccessGreen else DangerRed)
                                    HorizontalDivider()
                                    KeyValue(tr("السيولة في الحسابات", "Cash in accounts"), Fmt.money(rep.cash))
                                    KeyValue(tr("الاستثمارات والأصول", "Investments & assets"), Fmt.money(rep.investments))
                                    KeyValue(tr("مستحقات لي", "Owed to me"), Fmt.money(rep.receivables))
                                    KeyValue(tr("الديون", "Debts"), Fmt.money(rep.debts), if (rep.debts > 0) DangerRed else SuccessGreen)
                                    KeyValue(tr("الأقساط الشهرية", "Monthly installments"), Fmt.money(rep.monthlyDebt))
                                    KeyValue(tr("الاشتراكات الشهرية", "Monthly subscriptions"), Fmt.money(rep.subsMonthly))
                                    HorizontalDivider()
                                    KeyValue(tr("صافي الثروة", "Net worth"), Fmt.money(rep.netWorth), if (rep.netWorth >= 0) MaterialTheme.colorScheme.primary else DangerRed)
                                }
                            }
                        }
                        if (rep.topCats.isNotEmpty()) item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(tr("أين يذهب مالك؟", "Where your money goes"), fontWeight = FontWeight.Bold)
                                    val mx = rep.topCats.maxOf { it.second }.coerceAtLeast(1.0)
                                    rep.topCats.forEach { (c, v) ->
                                        val cat = Living.cat(Living.EXPENSE, c)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(cat.emoji + " " + cat.label, Modifier.width(130.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                                            LinearProgressIndicator(progress = { (v / mx).toFloat() }, modifier = Modifier.weight(1f).height(8.dp))
                                            Text(" " + Fmt.num(v), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(tr("المصروفات آخر 6 أشهر", "Spending, last 6 months"), fontWeight = FontWeight.Bold)
                                    val mx = rep.trend.maxOf { it.second }.coerceAtLeast(1.0)
                                    Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                                        rep.trend.forEach { (m, v) ->
                                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.fillMaxHeight()) {
                                                Text(if (v >= 1000) Fmt.num(v / 1000) + "k" else Fmt.num(v), style = MaterialTheme.typography.labelSmall)
                                                Box(Modifier.width(22.dp).height((80 * (v / mx)).dp.coerceAtLeast(2.dp)).padding(top = 0.dp)) {
                                                    Surface(color = MaterialTheme.colorScheme.primary, shape = MaterialTheme.shapes.extraSmall, modifier = Modifier.fillMaxSize()) {}
                                                }
                                                Text(m.take(3), style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        if (rep.tips.isEmpty()) item { EmptyState(Icons.Filled.Lightbulb, tr("لا توجد ملاحظات حالياً، استمر!", "Nothing to flag right now, keep going!")) }
                        items(rep.tips) { t ->
                            val c = when (t.level) { 0 -> SuccessGreen; 1 -> MaterialTheme.colorScheme.primary; 2 -> WarnAmber; else -> DangerRed }
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = c.copy(alpha = 0.10f))) {
                                Row(Modifier.padding(14.dp)) {
                                    Text(t.emoji, fontSize = 26.sp)
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(t.title, fontWeight = FontWeight.Bold, color = c)
                                        Text(t.text, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { nav.navigate("living") }, modifier = Modifier.weight(1f)) { Text(tr("مصاريف المعيشة", "Living expenses")) }
                                OutlinedButton(onClick = { nav.navigate("debts") }, modifier = Modifier.weight(1f)) { Text(tr("ديوني", "My debts")) }
                            }
                        }
                        item { Text(tr("ℹ️ نصائح عامة مبنية على بياناتك، وليست استشارة مالية أو استثمارية متخصصة.", "ℹ️ General guidance based on your data, not professional financial advice."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    else -> {
                        item { GoalTool(rep) }
                        item { AffordTool(rep) }
                        item { Rule503020(rep) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScoreCard(r: Advisor.Report) {
    val color = when { r.score >= 70 -> SuccessGreen; r.score >= 45 -> WarnAmber; else -> DangerRed }
    val track = MaterialTheme.colorScheme.surfaceVariant
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(120.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 14.dp.toPx()
                    val s = Size(size.width - sw, size.height - sw)
                    val tl = androidx.compose.ui.geometry.Offset(sw / 2, sw / 2)
                    drawArc(track, 135f, 270f, false, topLeft = tl, size = s, style = Stroke(sw, cap = StrokeCap.Round))
                    drawArc(color, 135f, 270f * r.score / 100f, false, topLeft = tl, size = s, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${r.score}", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = color)
                    Text("/100", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(tr("صحتك المالية", "Financial health"), style = MaterialTheme.typography.labelLarge)
                Text(r.grade, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = color)
                Text(tr("الادخار ", "Saving ") + "${(r.savingRate * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
                Text(tr("الطوارئ ", "Emergency ") + Fmt.num(r.emergencyMonths) + tr(" شهر", " mo"), style = MaterialTheme.typography.bodySmall)
                Text(tr("الأقساط/الدخل ", "Debt/income ") + "${(r.dti * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun GoalTool(r: Advisor.Report) {
    var target by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("") }
    var months by remember { mutableStateOf("12") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("🎯 خطة هدف ادخاري", "🎯 Savings goal plan"), fontWeight = FontWeight.Bold)
            Text(tr("سيارة، زواج، عمرة، دفعة شقة…", "Car, wedding, Umrah, down payment…"), style = MaterialTheme.typography.bodySmall)
            MoneyField(target, { target = it }, tr("المبلغ المطلوب", "Target amount"))
            MoneyField(saved, { saved = it }, tr("المدخر حالياً", "Already saved"))
            NumberField(months, { months = it.filter { c -> c.isDigit() }.take(3) }, tr("خلال كم شهر؟", "In how many months?"))
            val t = Fmt.parse(target) ?: 0.0
            if (t > 0) {
                val g = Advisor.goal(t, Fmt.parse(saved) ?: 0.0, months.toIntOrNull() ?: 12, r.income, r.expense)
                Surface(color = (if (g.feasible) SuccessGreen else WarnAmber).copy(alpha = 0.12f), shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                        Text(tr("ادخر شهرياً: ", "Save monthly: ") + Fmt.money(g.monthly), fontWeight = FontWeight.Bold)
                        if (r.income > 0) Text(tr("= ${(g.pctOfIncome * 100).roundToInt()}% من دخلك", "= ${(g.pctOfIncome * 100).roundToInt()}% of income"), style = MaterialTheme.typography.bodySmall)
                        Text(if (g.feasible) tr("✅ ممكن بفائضك الحالي", "✅ Achievable with your surplus") else tr("⚠️ أكبر من فائضك (${Fmt.money(r.income - r.expense)}). مدّد المدة أو قلّل الكماليات.", "⚠️ Above your surplus. Extend the period or cut wants."), style = MaterialTheme.typography.bodySmall)
                        val surplus = r.income - r.expense
                        if (surplus > 0) Text(tr("بفائضك الحالي تحتاج ≈ ", "With your surplus you need ≈ ") + ((t - (Fmt.parse(saved) ?: 0.0)).coerceAtLeast(0.0) / surplus).let { Fmt.num(kotlin.math.ceil(it)) } + tr(" شهر", " months"), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun AffordTool(r: Advisor.Report) {
    var price by remember { mutableStateOf("") }
    var inst by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("🛒 هل أستطيع شراءه؟", "🛒 Can I afford it?"), fontWeight = FontWeight.Bold)
            MoneyField(price, { price = it }, tr("السعر كاش", "Cash price"))
            MoneyField(inst, { inst = it }, tr("أو القسط الشهري (اختياري)", "Or monthly installment (optional)"))
            val p = Fmt.parse(price) ?: 0.0
            val i = Fmt.parse(inst) ?: 0.0
            if (p > 0 || i > 0) {
                val surplus = r.income - r.expense
                val (ok, msg) = when {
                    i > 0 && r.income > 0 -> {
                        val newDti = (r.monthlyDebt + i) / r.income
                        (newDti <= 0.35 && i <= surplus) to tr("الأقساط ستصبح ${(newDti * 100).roundToInt()}% من دخلك (الآمن ≤ 35%)، والقسط ${if (i <= surplus) "ضمن" else "أكبر من"} فائضك الشهري.", "Installments would be ${(newDti * 100).roundToInt()}% of income (safe ≤ 35%).")
                    }
                    p > 0 -> {
                        val afterCash = r.cash - p
                        val emAfter = if (r.expense > 0) afterCash / r.expense else 0.0
                        (emAfter >= 3) to tr("بعد الشراء يبقى معك ${Fmt.money(afterCash)} = ${Fmt.num(emAfter)} شهر طوارئ. ${if (emAfter >= 3) "مناسب" else "يُفضل الانتظار أو الادخار له ${if (surplus > 0) Fmt.num(kotlin.math.ceil(p / surplus)) + " شهر" else ""}"}", "After buying you keep ${Fmt.money(afterCash)} = ${Fmt.num(emAfter)} months of expenses.")
                    }
                    else -> false to ""
                }
                Surface(color = (if (ok) SuccessGreen else DangerRed).copy(alpha = 0.12f), shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                        Text(if (ok) tr("✅ مناسب لوضعك", "✅ Fits your situation") else tr("⚠️ غير مناسب الآن", "⚠️ Not advisable now"), fontWeight = FontWeight.Bold, color = if (ok) SuccessGreen else DangerRed)
                        Text(msg, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun Rule503020(r: Advisor.Report) {
    var inc by remember { mutableStateOf(if (r.income > 0) Fmt.plain(r.income) else "") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tr("📊 قاعدة 50/30/20", "📊 50/30/20 rule"), fontWeight = FontWeight.Bold)
            MoneyField(inc, { inc = it }, tr("الدخل الشهري", "Monthly income"))
            val v = Fmt.parse(inc) ?: 0.0
            if (v > 0) {
                val actual = listOf(r.essential, r.wants, r.income - r.essential - r.wants)
                Advisor.plan503020(v).forEachIndexed { i, (l, x) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(l, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.money(x), fontWeight = FontWeight.Bold)
                            if (r.income > 0) Text(tr("فعلياً ", "Actual ") + Fmt.num(actual[i]), style = MaterialTheme.typography.labelSmall,
                                color = if ((i < 2 && actual[i] > x) || (i == 2 && actual[i] < x)) DangerRed else SuccessGreen)
                        }
                    }
                }
            }
        }
    }
}
