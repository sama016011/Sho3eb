@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.sho3eb.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.core.chat.CallBus
import com.sho3eb.app.core.chat.Chat
import com.sho3eb.app.core.chat.ChatService
import com.sho3eb.app.core.chat.Supa
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val avatarColors = listOf(0xFF0F766E, 0xFF1976D2, 0xFF7B1FA2, 0xFFC2185B, 0xFFE65100, 0xFF2E7D32, 0xFF5D4037, 0xFF455A64)
private fun time(t: Long) = SimpleDateFormat("HH:mm", Locale.US).format(Date(t))
private fun dayLabel(t: Long): String {
    val d = java.time.Instant.ofEpochMilli(t).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
    val n = java.time.LocalDate.now()
    return when (d) { n -> tr("اليوم", "Today"); n.minusDays(1) -> tr("أمس", "Yesterday"); else -> Fmt.date(d.toEpochDay()) }
}
private fun shortTime(t: Long): String = if (t == 0L) "" else if (dayLabel(t) == tr("اليوم", "Today")) time(t) else dayLabel(t)

/** صورة الصديق من ملفه الشخصي (أو الحرف الأول) مع مؤشر النشاط */
@Composable
fun ChatAvatar(id: String, size: Int = 48, showOnline: Boolean = false) {
    val ctx = LocalContext.current
    val ver = Chat.version.intValue
    val p = remember(id, ver) { Chat.profile(id) }
    val isMe = id == Supa.uid
    val bmp by produceState<android.graphics.Bitmap?>(null, p?.avatar, isMe) {
        value = withContext(Dispatchers.IO) {
            if (isMe) ctx.let { com.sho3eb.app.Sho3ebApp.instance.prefs.photoPath?.let { android.graphics.BitmapFactory.decodeFile(it) } }
            else p?.avatar?.takeIf { it.isNotBlank() }?.let { path ->
                runCatching {
                    val f = File(File(ctx.cacheDir, "avatars").apply { mkdirs() }, path.replace('/', '_'))
                    if (!f.exists()) f.writeBytes(Supa.download(path))
                    android.graphics.BitmapFactory.decodeFile(f.path)
                }.getOrNull()
            }
        }
    }
    Box {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.size(size.dp).clip(CircleShape), contentScale = ContentScale.Crop)
        else Box(Modifier.size(size.dp).clip(CircleShape).background(Color(avatarColors[(id.hashCode() and 0x7fffffff) % avatarColors.size])), contentAlignment = Alignment.Center) {
            Text(Chat.nameOf(id).trim().firstOrNull()?.uppercase() ?: "?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size * 0.42).sp)
        }
        if (showOnline && p?.online == true) Box(Modifier.align(Alignment.BottomEnd).size((size * 0.28).dp).clip(CircleShape).background(SuccessGreen).border(2.dp, MaterialTheme.colorScheme.surface, CircleShape))
    }
}

@Composable
private fun Ticks(m: Chat.Msg) {
    val (t, c) = when {
        m.status == 0 -> "🕓" to Color.Gray
        m.status == -1 -> "⚠️" to DangerRed
        m.readAt > 0 -> "✓✓" to Color(0xFF34B7F1)
        m.deliveredAt > 0 -> "✓✓" to Color.Gray
        else -> "✓" to Color.Gray
    }
    Text(t, color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

// =====================================================================
//                         الشاشة الرئيسية للتواصل
// =====================================================================
@Composable
fun ChatHomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val ver = Chat.version.intValue
    var filter by rememberSaveable { mutableStateOf("all") }
    var q by rememberSaveable { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<Chat.Conv?>(null) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Supa.configured) { Chat.start(); withContext(Dispatchers.IO) { Chat.sync() } }
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.canNotify(ctx)) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { while (true) { delay(30_000); if (Supa.configured) withContext(Dispatchers.IO) { Chat.sync() } } }
    if (!Supa.configured) { ChatSetupScreen(nav, first = true); return }
    val convs = remember(ver) { Chat.conversations() }
    val groups = remember(ver) { Chat.groups() }
    val online = remember(ver) { (convs.map { it.peer } + Chat.friends().map { it.uid }).filter { it.isNotBlank() }.distinct().mapNotNull { Chat.profile(it) }.filter { it.online && it.id != Supa.uid } }
    val unread = convs.filter { !it.hidden }.sumOf { it.unread }

    ScreenScaffold(title = tr("💬 التواصل", "💬 Chat"), onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { nav.navigate("chat_friends") }) { Icon(Icons.Filled.PersonAdd, null) }
        IconButton(onClick = { nav.navigate("chat_setup") }) { Icon(Icons.Filled.Settings, null) }
    }, fab = { FloatingActionButton(onClick = { nav.navigate("chat_friends") }) { Icon(Icons.Filled.Chat, null) } }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(bottom = 96.dp)) {
            item {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    SearchField(q) { q = it }
                    HChips {
                        FilterChip(filter == "all", { filter = "all" }, label = { Text(tr("الكل", "All")) })
                        FilterChip(filter == "unread", { filter = "unread" }, label = { Text(tr("غير المقروءة", "Unread") + if (unread > 0) " ($unread)" else "") })
                        FilterChip(filter == "online", { filter = "online" }, label = { Text(tr("🟢 النشطون", "🟢 Online") + " (${online.size})") })
                        FilterChip(filter == "groups", { filter = "groups" }, label = { Text(tr("👥 المجموعات", "👥 Groups") + " (${groups.size})") })
                        FilterChip(filter == "hidden", { filter = "hidden" }, label = { Text(tr("🙈 المخفية", "🙈 Hidden")) })
                    }
                    if (Chat.status.value.isNotBlank()) Text("⚠️ " + Chat.status.value.take(120), style = MaterialTheme.typography.labelSmall, color = DangerRed)
                }
            }
            if (online.isNotEmpty() && filter == "all") item {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(online, key = { it.id }) { pr ->
                        Column(Modifier.width(62.dp).clickable { nav.navigate("chat/${pr.id}") }, horizontalAlignment = Alignment.CenterHorizontally) {
                            ChatAvatar(pr.id, 54, showOnline = true)
                            Text(Chat.nameOf(pr.id), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            when (filter) {
                "groups" -> {
                    item { TextButton(onClick = { nav.navigate("chat_group_edit/new") }, modifier = Modifier.padding(horizontal = 8.dp)) { Icon(Icons.Filled.GroupAdd, null); Spacer(Modifier.width(6.dp)); Text(tr("مجموعة جديدة (رسالة مجمعة)", "New group (broadcast)")) } }
                    items(groups, key = { "g" + it.id }) { g ->
                        ListItem(modifier = Modifier.clickable { nav.navigate("chat_group/${g.id}") },
                            leadingContent = { Box(Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) { Text(g.emoji, fontSize = 22.sp) } },
                            headlineContent = { Text(g.name, fontWeight = FontWeight.Bold) },
                            supportingContent = { Text(g.members.joinToString("، ") { Chat.nameOf(it) }, maxLines = 1, overflow = TextOverflow.Ellipsis) })
                    }
                }
                "online" -> items(online, key = { "o" + it.id }) { pr ->
                    ListItem(modifier = Modifier.clickable { nav.navigate("chat/${pr.id}") }, leadingContent = { ChatAvatar(pr.id, 48, true) },
                        headlineContent = { Text(Chat.nameOf(pr.id), fontWeight = FontWeight.Bold) }, supportingContent = { Text(Chat.lastSeenText(pr.id), color = SuccessGreen) })
                }
                else -> {
                    val list = convs.filter { c ->
                        (if (filter == "hidden") c.hidden else !c.hidden) && (filter != "unread" || c.unread > 0) &&
                            (q.isBlank() || Chat.nameOf(c.peer).contains(q, true) || (Chat.profile(c.peer)?.phone ?: "").contains(q) || (c.last?.content?.preview ?: "").contains(q, true))
                    }
                    if (list.isEmpty()) item {
                        EmptyState(Icons.Filled.Forum, if (filter == "hidden") tr("لا توجد محادثات مخفية", "No hidden chats") else tr("ابدأ محادثة: اضغط 👤+ لإضافة أصدقاء برقم الهاتف أو من جهات الاتصال.", "Start a chat: tap 👤+ to add friends by phone or from contacts."))
                    }
                    items(list, key = { "c" + it.peer }) { c -> ConvRow(c, onClick = { nav.navigate("chat/${c.peer}") }, onLong = { menuFor = c }) }
                }
            }
        }
    }
    menuFor?.let { c ->
        AlertDialog(onDismissRequest = { menuFor = null }, title = { Text(Chat.nameOf(c.peer)) }, text = {
            Column {
                TextButton(onClick = { Chat.togglePin(c.peer); menuFor = null }) { Text(if (c.pinned) tr("📌 إلغاء التثبيت", "📌 Unpin") else tr("📌 تثبيت أعلى المحادثات", "📌 Pin to top")) }
                TextButton(onClick = { Chat.toggleHide(c.peer); menuFor = null }) { Text(if (c.hidden) tr("👁️ إظهار المحادثة", "👁️ Unhide") else tr("🙈 إخفاء المحادثة", "🙈 Hide chat")) }
                TextButton(onClick = { Chat.toggleMute(c.peer); menuFor = null }) { Text(if (c.muted) tr("🔔 تشغيل الإشعارات", "🔔 Unmute") else tr("🔕 كتم الإشعارات", "🔕 Mute")) }
                TextButton(onClick = { Chat.markRead(c.peer); menuFor = null }) { Text(tr("✓✓ تعليم كمقروءة", "✓✓ Mark as read")) }
                TextButton(onClick = { Chat.clearChat(c.peer); menuFor = null }) { Text(tr("🗑️ مسح المحادثة من هاتفي", "🗑️ Clear chat on my phone"), color = DangerRed) }
            }
        }, confirmButton = { TextButton(onClick = { menuFor = null }) { Text(tr("إغلاق", "Close")) } })
    }
}

@Composable
private fun ConvRow(c: Chat.Conv, onClick: () -> Unit, onLong: () -> Unit) {
    val m = c.last
    Row(Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        ChatAvatar(c.peer, 52, showOnline = true)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Chat.nameOf(c.peer), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(shortTime(m?.createdAt ?: 0), style = MaterialTheme.typography.labelSmall, color = if (c.unread > 0) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (m?.mine == true) { Ticks(m); Spacer(Modifier.width(4.dp)) }
                Text(if (m?.deleted == true) tr("🚫 تم حذف هذه الرسالة", "🚫 Message deleted") else m?.content?.preview ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                if (c.muted) Icon(Icons.Filled.NotificationsOff, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
                if (c.pinned) Icon(Icons.Filled.PushPin, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.outline)
                if (c.unread > 0) Box(Modifier.padding(start = 4.dp).clip(CircleShape).background(SuccessGreen).padding(horizontal = 7.dp, vertical = 2.dp)) { Text("${c.unread}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
            val ls = Chat.lastSeenText(c.peer)
            if (ls.isNotBlank()) Text(ls, style = MaterialTheme.typography.labelSmall, color = if (ls.startsWith("🟢")) SuccessGreen else MaterialTheme.colorScheme.outline)
        }
    }
}

// =====================================================================
//                                 الإعداد
// =====================================================================
@Composable
fun ChatSetupScreen(nav: NavController, first: Boolean = false) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { appPrefs() }
    var url by remember { mutableStateOf(Supa.url) }
    var key by remember { mutableStateOf(Supa.key) }
    var phone by remember { mutableStateOf(prefs.phone) }
    var name by remember { mutableStateOf(prefs.displayName) }
    var about by remember { mutableStateOf(Extras.s("chat_about", "")) }
    var keep by remember { mutableStateOf(Chat.keepConnected) }
    var notify by remember { mutableStateOf(Chat.notifyOn) }
    var turn by remember { mutableStateOf(Chat.turnUrl) }
    var tu by remember { mutableStateOf(Chat.turnUser) }
    var tp by remember { mutableStateOf(Chat.turnPass) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    ScreenScaffold(title = tr("إعداد التواصل", "Chat setup"), onBack = { nav.popBackStack() }) { p ->
        Column(Modifier.padding(p).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (first) InfoBanner(tr("التواصل يحتاج خادماً مجانياً (Supabase) مرة واحدة: أنشئ مشروعاً، شغّل ملف supabase/schema.sql من المستودع في SQL Editor، فعّل «Anonymous sign-ins»، ثم الصق الرابط والمفتاح هنا. نسخ المشاركة تحمل الإعداد تلقائياً.",
                "Chat needs a free Supabase server once: create a project, run supabase/schema.sql from the repo in the SQL Editor, enable «Anonymous sign-ins», then paste the URL and key here. Shared editions carry the setup automatically."))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("👤 ملفي في التواصل", "👤 My chat profile"))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ChatAvatar(Supa.uid.ifBlank { "me" }, 56); Spacer(Modifier.width(10.dp))
                        Text(tr("الاسم والصورة من ملفك الشخصي في التطبيق", "Name & photo come from your app profile"), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { nav.navigate("profile") }) { Text(tr("تعديل", "Edit")) }
                    }
                    OutlinedTextField(name, { name = it }, label = { Text(tr("اسمك الظاهر للأصدقاء", "Your display name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(phone, { phone = it }, label = { Text(tr("رقم هاتفك (يبحث به أصدقاؤك عنك)", "Your phone (friends find you by it)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(about, { about = it }, label = { Text(tr("نبذة / حالة", "About / status")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("🖧 الخادم", "🖧 Server"))
                    OutlinedTextField(url, { url = it.trim() }, label = { Text("Project URL (https://xxxx.supabase.co)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(key, { key = it.trim() }, label = { Text("anon public key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { nav.openWeb("https://supabase.com/dashboard/projects", "Supabase") }) { Text(tr("فتح لوحة Supabase", "Open Supabase dashboard")) }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    SwitchRow(tr("البقاء متصلاً (رسائل ومكالمات فورية والتطبيق مغلق)", "Stay connected (instant messages & calls when closed)"), tr("يظهر إشعار صغير دائم", "Shows a small persistent notification"), keep, Icons.Filled.Wifi) { keep = it }
                    SwitchRow(tr("إشعارات الرسائل", "Message notifications"), null, notify, Icons.Filled.Notifications) { notify = it }
                }
            }
            var adv by remember { mutableStateOf(false) }
            TextButton(onClick = { adv = !adv }) { Text(tr("⚙️ إعدادات المكالمات المتقدمة (TURN)", "⚙️ Advanced call settings (TURN)")) }
            if (adv) Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("خادم TURN يضمن نجاح المكالمات عبر شبكات المحمول. الافتراضي مجاني عام؛ ويمكنك وضع خادمك الخاص (مثل Metered أو Twilio) لجودة أعلى.", "A TURN server ensures calls work over mobile networks. Default is a free public one; use your own (Metered, Twilio) for better quality."), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(turn, { turn = it }, label = { Text("TURN URL(s)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(tu, { tu = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(tp, { tp = it }, label = { Text("Credential") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
            if (msg.isNotBlank()) Text(msg, color = if (msg.startsWith("✅")) SuccessGreen else DangerRed)
            Button(enabled = !busy, onClick = {
                if (phone.filter { it.isDigit() }.length < 8) { msg = tr("أدخل رقم هاتفك", "Enter your phone number"); return@Button }
                Supa.url = url; Supa.key = key; prefs.phone = phone.trim(); prefs.displayName = name.trim(); Extras.ps("chat_about", about.trim())
                Chat.keepConnected = keep; Chat.notifyOn = notify; Chat.turnUrl = turn.trim(); Chat.turnUser = tu.trim(); Chat.turnPass = tp.trim()
                busy = true; msg = ""
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { Supa.ensureSession(); Chat.publishProfile() } }
                    busy = false
                    r.onSuccess { msg = tr("✅ تم الاتصال بنجاح", "✅ Connected"); Chat.start(); ChatService.apply(ctx); if (first) { nav.popBackStack(); nav.navigate("chat") } }
                     .onFailure { e ->
                         msg = when {
                             e.message == "anonymous_disabled" -> tr("فعّل Anonymous sign-ins من Authentication في Supabase", "Enable Anonymous sign-ins in Supabase Authentication")
                             e.message?.contains("duplicate", true) == true || e.message?.contains("phone", true) == true -> tr("هذا الرقم مسجل بحساب آخر", "This phone is already registered")
                             e.message?.contains("relation", true) == true || e.message?.contains("404") == true -> tr("شغّل ملف schema.sql في Supabase أولاً", "Run schema.sql in Supabase first")
                             else -> tr("تعذر الاتصال: ", "Connection failed: ") + (e.message ?: "")
                         }
                     }
                }
            }, modifier = Modifier.fillMaxWidth()) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text(tr("حفظ والاتصال", "Save & connect")) }
            Text("🔒 " + tr("الرسائل والملفات مشفرة من طرف لطرف على هاتفك قبل الإرسال؛ لا يستطيع أحد قراءتها غير المرسل والمستقبل، حتى صاحب الخادم.", "Messages and files are end-to-end encrypted on your phone; only sender and recipient can read them, not even the server owner."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// =====================================================================
//                                 الأصدقاء
// =====================================================================
@Composable
fun ChatFriendsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ver = Chat.version.intValue
    val friends = remember(ver) { Chat.friends() }
    var addDlg by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    val contactsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { busy = true; scope.launch { val n = withContext(Dispatchers.IO) { Chat.addFriends(Chat.deviceContacts(ctx)).size }; busy = false; toast(ctx, tr("$n من جهات اتصالك يستخدمون التطبيق", "$n of your contacts use the app")) } }
    }
    fun invite(phone: String) {
        val text = Chat.inviteText()
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone?text=" + Uri.encode(text)))
        runCatching { ctx.startActivity(i) }.onFailure { runCatching { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+$phone")).putExtra("sms_body", text)) } }
    }
    ScreenScaffold(title = tr("الأصدقاء", "Friends"), onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { scope.launch { busy = true; withContext(Dispatchers.IO) { Chat.addFriends(Chat.friends().map { it.localName to it.phone }) }; busy = false } }) { Icon(Icons.Filled.Refresh, null) }
    }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 80.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { addDlg = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Dialpad, null); Spacer(Modifier.width(4.dp)); Text(tr("برقم الهاتف", "By phone")) }
                    OutlinedButton(onClick = {
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) contactsPerm.launch(Manifest.permission.READ_CONTACTS) else contactsPerm.launch(Manifest.permission.READ_CONTACTS)
                    }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Contacts, null); Spacer(Modifier.width(4.dp)); Text(tr("من جهات الاتصال", "From contacts")) }
                }
                OutlinedButton(onClick = { nav.navigate("chat_group_edit/new") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.GroupAdd, null); Spacer(Modifier.width(4.dp)); Text(tr("مجموعة أصدقاء (رسالة مجمعة)", "Friends group (broadcast)")) }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                SearchField(q) { q = it }
            }
            val l = friends.filter { q.isBlank() || it.localName.contains(q, true) || it.phone.contains(q) || Chat.nameOf(it.uid).contains(q, true) }
            val on = l.filter { it.uid.isNotBlank() }.sortedBy { Chat.nameOf(it.uid) }
            val off = l.filter { it.uid.isBlank() }.sortedBy { it.localName }
            item { SectionTitle(tr("✅ يستخدمون التطبيق (${on.size})", "✅ On the app (${on.size})")) }
            items(on, key = { "on" + it.phone }) { f ->
                ListItem(modifier = Modifier.clickable { nav.navigate("chat/${f.uid}") }, leadingContent = { ChatAvatar(f.uid, 46, true) },
                    headlineContent = { Text(Chat.nameOf(f.uid), fontWeight = FontWeight.Bold) },
                    supportingContent = { Text("+" + f.phone + (if (f.localName.isNotBlank() && f.localName != Chat.nameOf(f.uid)) " • " + f.localName else "") + "\n" + Chat.lastSeenText(f.uid), style = MaterialTheme.typography.bodySmall) },
                    trailingContent = {
                        Row {
                            IconButton(onClick = { CallBus.call(ctx, f.uid, false) }) { Icon(Icons.Filled.Call, null) }
                            IconButton(onClick = { CallBus.call(ctx, f.uid, true) }) { Icon(Icons.Filled.Videocam, null) }
                        }
                    })
            }
            item { SectionTitle(tr("✉️ ادعُهم للتطبيق (${off.size})", "✉️ Invite to the app (${off.size})")) }
            items(off.take(300), key = { "off" + it.phone }) { f ->
                ListItem(leadingContent = { Box(Modifier.size(46.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text(f.localName.firstOrNull()?.toString() ?: "?") } },
                    headlineContent = { Text(f.localName.ifBlank { "+" + f.phone }) }, supportingContent = { Text("+" + f.phone + tr(" • لا يستخدم التطبيق بعد", " • not on the app yet"), style = MaterialTheme.typography.bodySmall) },
                    trailingContent = { TextButton(onClick = { invite(f.phone) }) { Text(tr("دعوة", "Invite")) } })
            }
        }
    }
    if (addDlg) {
        var ph by remember { mutableStateOf("") }; var nm by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { addDlg = false }, title = { Text(tr("إضافة صديق", "Add friend")) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(ph, { ph = it }, label = { Text(tr("رقم الهاتف", "Phone number")) }, singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone))
                OutlinedTextField(nm, { nm = it }, label = { Text(tr("الاسم (اختياري)", "Name (optional)")) }, singleLine = true)
            }
        }, confirmButton = { TextButton(onClick = {
            addDlg = false
            scope.launch {
                busy = true
                val r = withContext(Dispatchers.IO) { runCatching { Chat.addFriends(listOf(nm to ph)) }.getOrDefault(emptyList()) }
                busy = false
                if (r.isNotEmpty()) nav.navigate("chat/${r.first().uid}") else toast(ctx, tr("هذا الرقم لا يستخدم التطبيق بعد؛ أرسل له دعوة", "This number isn't on the app yet; send an invite"))
            }
        }) { Text(tr("إضافة", "Add")) } }, dismissButton = { TextButton(onClick = { addDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
}

@Composable
fun ChatGroupEditScreen(nav: NavController, id: String) {
    val g0 = remember { Chat.groups().firstOrNull { it.id == id } }
    var name by remember { mutableStateOf(g0?.name ?: "") }
    var emoji by remember { mutableStateOf(g0?.emoji ?: "👥") }
    var members by remember { mutableStateOf(g0?.members?.toSet() ?: emptySet()) }
    val friends = remember { Chat.friends().filter { it.uid.isNotBlank() } }
    ScreenScaffold(title = if (g0 == null) tr("مجموعة جديدة", "New group") else tr("تعديل المجموعة", "Edit group"), onBack = { nav.popBackStack() }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم المجموعة", "Group name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                HChips { listOf("👥", "👨‍👩‍👧", "💼", "⚽", "🎓", "🕌", "🛒", "❤️").forEach { e -> FilterChip(emoji == e, { emoji = e }, label = { Text(e) }) } }
                Text(tr("الرسالة المرسلة للمجموعة تصل لكل عضو في محادثته الخاصة (مشفرة لكل شخص).", "A group message reaches each member in their private chat (encrypted per person)."), style = MaterialTheme.typography.bodySmall)
                SectionTitle(tr("الأعضاء (${members.size})", "Members (${members.size})"))
            }
            items(friends, key = { it.uid }) { f ->
                Row(Modifier.fillMaxWidth().clickable { members = if (f.uid in members) members - f.uid else members + f.uid }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(f.uid in members, { members = if (it) members + f.uid else members - f.uid })
                    ChatAvatar(f.uid, 36); Spacer(Modifier.width(8.dp)); Text(Chat.nameOf(f.uid))
                }
            }
            item {
                Button(enabled = name.isNotBlank() && members.isNotEmpty(), onClick = {
                    val g = Chat.Group(g0?.id ?: java.util.UUID.randomUUID().toString(), name.trim(), members.toList(), emoji); Chat.saveGroup(g)
                    nav.popBackStack(); nav.navigate("chat_group/${g.id}")
                }, modifier = Modifier.fillMaxWidth()) { Text(tr("حفظ", "Save")) }
                if (g0 != null) TextButton(onClick = { Chat.deleteGroup(g0.id); nav.popBackStack() }) { Text(tr("حذف المجموعة", "Delete group"), color = DangerRed) }
            }
        }
    }
}

// =====================================================================
//                                المحادثة
// =====================================================================
private val quickReactions = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")
private val emojis = ("😀😃😄😁😆😅😂🤣😊😇🙂🙃😉😌😍🥰😘😗😋😛😜🤪😝🤗🤭🤫🤔🤐😐😑😶😏😒🙄😬😮‍💨🤥😔😪🤤😴😷🤒🤕🤢🥵🥶😵🤯🤠🥳😎🤓🧐😕😟🙁😮😯😲😳🥺😦😧😨😰😥😢😭😱😖😣😞😓😩😫🥱😤😡😠🤬" +
    "👍👎👌✌️🤞🤟🤘👏🙌🤲🤝🙏💪👋✋🖐️👊✊❤️🧡💛💚💙💜🖤🤍💔💕💞💓💗💖💘💝🌹🌸🌺🌻🌷🎉🎊🎁🎂☕🍵🍰🍕🍔🍟⚽🏆🥇🔥⭐🌟✨💯✅❌⚠️📌📎📷🎥🎵📞💬🕌🤲🌙☀️🌧️").let { s ->
    val out = mutableListOf<String>(); val it = java.text.BreakIterator.getCharacterInstance(); it.setText(s); var st = it.first(); var en = it.next()
    while (en != java.text.BreakIterator.DONE) { out += s.substring(st, en); st = en; en = it.next() }; out.filter { it.isNotBlank() }
}

/** محادثة مع صديق (peer) أو مجموعة (groupId) */
@Composable
fun ChatRoomScreen(nav: NavController, peer: String = "", groupId: String = "") {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ver = Chat.version.intValue
    val group = remember(ver) { if (groupId.isNotBlank()) Chat.groups().firstOrNull { it.id == groupId } else null }
    val isGroup = groupId.isNotBlank()
    val targets = if (isGroup) group?.members ?: emptyList() else listOf(peer)
    val msgs = remember(ver, peer, groupId) {
        if (isGroup) targets.flatMap { Chat.messages(it) }.filter { it.groupId == groupId || (!it.mine && it.groupId == groupId) }.sortedBy { it.createdAt }
            .let { l -> l.filter { !it.mine } + l.filter { it.mine }.distinctBy { (it.content?.json()?.toString() ?: "") + (it.createdAt / 5000) } }.sortedBy { it.createdAt }
        else Chat.messages(peer)
    }
    var text by rememberSaveable { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<Chat.Msg?>(null) }
    var editing by remember { mutableStateOf<Chat.Msg?>(null) }
    var menuFor by remember { mutableStateOf<Chat.Msg?>(null) }
    var info by remember { mutableStateOf<Chat.Msg?>(null) }
    var forward by remember { mutableStateOf<Chat.Msg?>(null) }
    var showEmoji by remember { mutableStateOf(false) }
    var attach by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<File?>(null) }
    var search by remember { mutableStateOf<String?>(null) }
    var translated by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var trDlg by remember { mutableStateOf(false) }
    var mentionMenu by remember { mutableStateOf(false) }
    var mentions by remember { mutableStateOf<List<String>>(emptyList()) }
    var uploading by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf<Pair<MediaRecorder, File>?>(null) }
    var recStart by remember { mutableLongStateOf(0L) }
    val listState = rememberLazyListState()

    DisposableEffect(peer) {
        Chat.openPeer = if (isGroup) null else peer
        if (!isGroup) Chat.markRead(peer)
        onDispose { Chat.openPeer = null }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size); if (!isGroup) Chat.markRead(peer) }
    LaunchedEffect(peer) { if (!isGroup) withContext(Dispatchers.IO) { Chat.refreshProfiles(listOf(peer)) } }

    fun sendContent(c: Chat.Content) {
        val rt = replyTo?.id ?: ""; replyTo = null
        scope.launch(Dispatchers.IO) { Chat.send(targets, c, rt, groupId) }
    }
    fun sendUris(uris: List<Uri>, kind: String? = null) {
        if (uris.isEmpty()) return
        uploading = true
        scope.launch(Dispatchers.IO) { uris.forEach { Chat.sendFile(targets, it, kind) }; uploading = false }
    }
    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { sendUris(it) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { sendUris(it, "file") }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) camUri?.let { sendUris(listOf(it), "image") } }
    val takeVideo = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok -> if (ok) camUri?.let { sendUris(listOf(it), "video") } }
    fun camFile(ext: String): Uri { val f = File(File(ctx.cacheDir, "camera").apply { mkdirs() }, "cap_" + System.currentTimeMillis() + ext); return FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f).also { camUri = it } }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) takePhoto.launch(camFile(".jpg")) }
    val vidPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) takeVideo.launch(camFile(".mp4")) }
    val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.PickContact()) { uri ->
        if (uri != null) runCatching {
            val id = ctx.contentResolver.query(uri, arrayOf(android.provider.ContactsContract.Contacts._ID, android.provider.ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) to c.getString(1) else null } ?: return@runCatching
            val num = ctx.contentResolver.query(android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER),
                android.provider.ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?", arrayOf(id.first), null)?.use { c -> if (c.moveToFirst()) c.getString(0) else "" } ?: ""
            sendContent(Chat.Content("contact", cname = id.second ?: "", cphone = num))
        }
    }
    val contactPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) pickContact.launch(null) }
    fun sendLocation() {
        val lm = ctx.getSystemService(android.location.LocationManager::class.java)
        val loc = runCatching { listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER, android.location.LocationManager.PASSIVE_PROVIDER).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } }.getOrNull()
        if (loc == null) toast(ctx, tr("فعّل الموقع وحاول مرة أخرى", "Turn on location and try again"))
        else sendContent(Chat.Content("location", lat = loc.latitude, lng = loc.longitude))
    }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) sendLocation() }
    fun startRec() {
        val f = File(ctx.cacheDir, "voice_" + System.currentTimeMillis() + ".m4a")
        val r0: MediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        val r = r0.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(64000); setAudioSamplingRate(44100); setOutputFile(f.path); prepare(); start()
        }
        recording = r to f; recStart = System.currentTimeMillis()
    }
    fun stopRec(send: Boolean) {
        val (r, f) = recording ?: return
        recording = null
        runCatching { r.stop() }; r.release()
        val dur = (System.currentTimeMillis() - recStart) / 1000
        if (send && dur >= 1) { uploading = true; scope.launch(Dispatchers.IO) { Chat.sendFile(targets, Uri.fromFile(f), "audio", dur = dur); uploading = false } }
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) runCatching { startRec() } }

    val title = if (isGroup) (group?.emoji ?: "👥") + " " + (group?.name ?: "") else Chat.nameOf(peer)
    Scaffold(topBar = {
        TopAppBar(navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }, title = {
            if (search != null) OutlinedTextField(search!!, { search = it }, singleLine = true, placeholder = { Text(tr("بحث في المحادثة", "Search chat")) }, modifier = Modifier.fillMaxWidth())
            else Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { if (isGroup) nav.navigate("chat_group_edit/$groupId") }) {
                if (!isGroup) ChatAvatar(peer, 38, true) else Text(group?.emoji ?: "👥", fontSize = 26.sp)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(if (isGroup) tr("${targets.size} أعضاء", "${targets.size} members") else Chat.lastSeenText(peer).ifBlank { Chat.profile(peer)?.phone?.let { "+$it" } ?: "" }, style = MaterialTheme.typography.labelSmall)
                }
            }
        }, actions = {
            if (search != null) IconButton(onClick = { search = null }) { Icon(Icons.Filled.Close, null) }
            else {
                if (!isGroup) {
                    IconButton(onClick = { CallBus.call(ctx, peer, false) }) { Icon(Icons.Filled.Call, null) }
                    IconButton(onClick = { CallBus.call(ctx, peer, true) }) { Icon(Icons.Filled.Videocam, null) }
                }
                IconButton(onClick = { search = "" }) { Icon(Icons.Filled.Search, null) }
            }
        })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))) {
            val shown = msgs.filter { search.isNullOrBlank() || (it.content?.text ?: "").contains(search!!, true) || (it.content?.name ?: "").contains(search!!, true) }
            LazyColumn(Modifier.weight(1f), state = listState, contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item { Text("🔒 " + tr("الرسائل والمكالمات مشفرة من طرف لطرف.", "Messages and calls are end-to-end encrypted."), Modifier.fillMaxWidth().padding(8.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
                items(shown.size, key = { shown[it].id }) { i ->
                    val m = shown[i]
                    if (i == 0 || dayLabel(shown[i - 1].createdAt) != dayLabel(m.createdAt)) DayChip(dayLabel(m.createdAt))
                    Bubble(m, isGroup, msgs, translated[m.id], onLong = { menuFor = m }, onOpenImage = { f -> viewer = f }, nav = nav,
                        onReact = { e -> scope.launch(Dispatchers.IO) { Chat.react(m, e) } }, onRetry = { scope.launch(Dispatchers.IO) { Chat.retry(m) } })
                }
            }
            if (uploading) LinearProgressIndicator(Modifier.fillMaxWidth())
            // ----- الرد / التعديل -----
            (replyTo ?: editing)?.let { r ->
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(4.dp).height(36.dp).background(MaterialTheme.colorScheme.primary))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (editing != null) tr("✏️ تعديل الرسالة", "✏️ Editing") else tr("↩️ رد على ", "↩️ Reply to ") + Chat.nameOf(r.sender), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                        Text(r.content?.preview ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { replyTo = null; if (editing != null) { editing = null; text = "" } }) { Icon(Icons.Filled.Close, null) }
                }
            }
            if (showEmoji) LazyRow(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
                items(emojis.chunked(4)) { col -> Column { col.forEach { e -> Text(e, fontSize = 26.sp, modifier = Modifier.clickable { text += e }.padding(6.dp)) } } }
            }
            // ----- شريط الكتابة -----
            val rec = recording
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(6.dp), verticalAlignment = Alignment.Bottom) {
                if (rec != null) {
                    var secs by remember { mutableLongStateOf(0) }
                    LaunchedEffect(rec) { while (true) { secs = (System.currentTimeMillis() - recStart) / 1000; delay(300) } }
                    IconButton(onClick = { stopRec(false) }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
                    Text("🔴 " + String.format(Locale.US, "%02d:%02d", secs / 60, secs % 60) + tr("  جارٍ التسجيل…", "  Recording…"), Modifier.weight(1f).padding(12.dp))
                    FilledIconButton(onClick = { stopRec(true) }) { Icon(Icons.AutoMirrored.Filled.Send, null) }
                } else {
                    IconButton(onClick = { showEmoji = !showEmoji }) { Icon(Icons.Filled.EmojiEmotions, null) }
                    Box {
                        IconButton(onClick = { attach = true }) { Icon(Icons.Filled.AttachFile, null) }
                        DropdownMenu(attach, { attach = false }) {
                            DropdownMenuItem(text = { Text(tr("🖼️ صور وفيديو", "🖼️ Photos & videos")) }, onClick = { attach = false; pickMedia.launch("*/*") })
                            DropdownMenuItem(text = { Text(tr("📷 التقاط صورة", "📷 Take photo")) }, onClick = { attach = false; if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) takePhoto.launch(camFile(".jpg")) else camPerm.launch(Manifest.permission.CAMERA) })
                            DropdownMenuItem(text = { Text(tr("🎥 تصوير فيديو", "🎥 Record video")) }, onClick = { attach = false; if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) takeVideo.launch(camFile(".mp4")) else vidPerm.launch(Manifest.permission.CAMERA) })
                            DropdownMenuItem(text = { Text(tr("📎 ملف", "📎 File")) }, onClick = { attach = false; pickFile.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text(tr("📍 موقعي", "📍 My location")) }, onClick = { attach = false; if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) sendLocation() else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION) })
                            DropdownMenuItem(text = { Text(tr("👤 جهة اتصال", "👤 Contact")) }, onClick = { attach = false; if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) pickContact.launch(null) else contactPerm.launch(Manifest.permission.READ_CONTACTS) })
                            DropdownMenuItem(text = { Text(tr("🌐 ترجمة الرسالة قبل الإرسال", "🌐 Translate before sending")) }, onClick = { attach = false; trDlg = true })
                            if (isGroup) DropdownMenuItem(text = { Text(tr("@ منشن عضو", "@ Mention member")) }, onClick = { attach = false; mentionMenu = true })
                        }
                    }
                    OutlinedTextField(text, { text = it; if (isGroup && it.endsWith("@")) mentionMenu = true }, Modifier.weight(1f), placeholder = { Text(tr("اكتب رسالة", "Message")) }, maxLines = 5, shape = RoundedCornerShape(24.dp))
                    if (text.isBlank() && editing == null) FilledIconButton(onClick = { if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) runCatching { startRec() } else micPerm.launch(Manifest.permission.RECORD_AUDIO) }) { Icon(Icons.Filled.Mic, null) }
                    else FilledIconButton(onClick = {
                        val t = text.trim(); if (t.isEmpty()) return@FilledIconButton
                        val e = editing
                        if (e != null) { editing = null; scope.launch(Dispatchers.IO) { Chat.edit(e, t) } }
                        else sendContent(Chat.Content("text", t, mentions = mentions.filter { m -> t.contains("@" + Chat.nameOf(m)) }))
                        text = ""; mentions = emptyList()
                    }) { Icon(if (editing != null) Icons.Filled.Check else Icons.AutoMirrored.Filled.Send, null) }
                }
            }
        }
    }

    // ---------- قائمة الرسالة ----------
    menuFor?.let { m ->
        AlertDialog(onDismissRequest = { menuFor = null }, title = {
            Row { quickReactions.forEach { e -> Text(e, fontSize = 26.sp, modifier = Modifier.clickable { menuFor = null; scope.launch(Dispatchers.IO) { Chat.react(m, e) } }.padding(4.dp)) } }
        }, text = {
            Column {
                if (!m.deleted) {
                    TextButton(onClick = { replyTo = m; menuFor = null }) { Text(tr("↩️ رد", "↩️ Reply")) }
                    if (m.content?.text?.isNotBlank() == true) TextButton(onClick = {
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("msg", m.content?.text ?: "")); menuFor = null; toast(ctx, tr("تم النسخ", "Copied"))
                    }) { Text(tr("📋 نسخ", "📋 Copy")) }
                    TextButton(onClick = { forward = m; menuFor = null }) { Text(tr("➡️ إعادة توجيه", "➡️ Forward")) }
                    if (m.content?.text?.isNotBlank() == true) TextButton(onClick = {
                        menuFor = null
                        scope.launch { val t = withContext(Dispatchers.IO) { runCatching { val tx = m.content?.text ?: ""; val src = Translate.detect(tx) ?: "en"; Translate.translate(tx, src, if (AppState.lang.value == "ar") "ar" else AppState.lang.value) }.getOrNull() }; if (t != null) translated = translated + (m.id to t) else toast(ctx, tr("تعذرت الترجمة", "Translation failed")) }
                    }) { Text(tr("🌐 ترجمة", "🌐 Translate")) }
                    if (m.mine && m.content?.kind == "text") TextButton(onClick = { editing = m; text = m.content?.text ?: ""; menuFor = null }) { Text(tr("✏️ تعديل", "✏️ Edit")) }
                }
                TextButton(onClick = { info = m; menuFor = null }) { Text(tr("ℹ️ معلومات الرسالة", "ℹ️ Message info")) }
                TextButton(onClick = { Chat.deleteForMe(m); menuFor = null }) { Text(tr("🗑️ حذف لدي", "🗑️ Delete for me"), color = DangerRed) }
                if (m.mine && !m.deleted) TextButton(onClick = { menuFor = null; scope.launch(Dispatchers.IO) { Chat.deleteForAll(m) } }) { Text(tr("🗑️ حذف لدى الجميع", "🗑️ Delete for everyone"), color = DangerRed) }
            }
        }, confirmButton = { TextButton(onClick = { menuFor = null }) { Text(tr("إغلاق", "Close")) } })
    }
    info?.let { m ->
        val f = { t: Long -> if (t > 0) SimpleDateFormat("yyyy/MM/dd  HH:mm:ss", Locale.US).format(Date(t)) else "—" }
        AlertDialog(onDismissRequest = { info = null }, title = { Text(tr("معلومات الرسالة", "Message info")) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                KeyValue(tr("🕓 أُرسلت", "🕓 Sent"), f(m.createdAt))
                KeyValue(tr("✓✓ وصلت", "✓✓ Delivered"), f(m.deliveredAt))
                KeyValue(tr("👁️ قُرئت", "👁️ Read"), f(m.readAt))
                if (m.editedAt > 0) KeyValue(tr("✏️ عُدلت", "✏️ Edited"), f(m.editedAt))
            }
        }, confirmButton = { TextButton(onClick = { info = null }) { Text(tr("إغلاق", "Close")) } })
    }
    forward?.let { m ->
        val friends = remember { Chat.friends().filter { it.uid.isNotBlank() } }
        var sel by remember { mutableStateOf(emptySet<String>()) }
        AlertDialog(onDismissRequest = { forward = null }, title = { Text(tr("إعادة توجيه إلى", "Forward to")) }, text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(friends, key = { it.uid }) { fr ->
                    Row(Modifier.fillMaxWidth().clickable { sel = if (fr.uid in sel) sel - fr.uid else sel + fr.uid }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(fr.uid in sel, { sel = if (it) sel + fr.uid else sel - fr.uid }); ChatAvatar(fr.uid, 32); Spacer(Modifier.width(8.dp)); Text(Chat.nameOf(fr.uid))
                    }
                }
            }
        }, confirmButton = { TextButton(enabled = sel.isNotEmpty(), onClick = { val c = m.content; forward = null; if (c != null) scope.launch(Dispatchers.IO) { Chat.send(sel.toList(), c.copy(fwd = true)) }; toast(ctx, tr("تم الإرسال ✅", "Sent ✅")) }) { Text(tr("إرسال", "Send")) } },
            dismissButton = { TextButton(onClick = { forward = null }) { Text(tr("إلغاء", "Cancel")) } })
    }
    if (trDlg) {
        var target by remember { mutableStateOf(Extras.s("chat_tr_to", "en")) }
        var busy by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest = { trDlg = false }, title = { Text(tr("ترجمة الرسالة إلى", "Translate message to")) }, text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Translate.langs.forEach { l -> Row(Modifier.fillMaxWidth().clickable { target = l.code }, verticalAlignment = Alignment.CenterVertically) { RadioButton(target == l.code, { target = l.code }); Text(l.flag + " " + l.label) } }
            }
        }, confirmButton = { TextButton(enabled = text.isNotBlank() && !busy, onClick = {
            busy = true; Extras.ps("chat_tr_to", target)
            scope.launch {
                val orig = text
                val t = withContext(Dispatchers.IO) { runCatching { Translate.translate(orig, Translate.detect(orig) ?: "ar", target) }.getOrNull() }
                busy = false; trDlg = false
                if (t != null) { text = ""; sendContent(Chat.Content("text", t, lang = target, orig = orig)) } else toast(ctx, tr("تعذرت الترجمة (حمّل حزمة اللغة أول مرة بالإنترنت)", "Translation failed (download the language pack once)"))
            }
        }) { Text(tr("ترجمة وإرسال", "Translate & send")) } }, dismissButton = { TextButton(onClick = { trDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
    if (mentionMenu && isGroup) AlertDialog(onDismissRequest = { mentionMenu = false }, title = { Text(tr("منشن عضو", "Mention")) }, text = {
        Column { targets.forEach { u -> TextButton(onClick = { text = text.removeSuffix("@") + "@" + Chat.nameOf(u) + " "; mentions = mentions + u; mentionMenu = false }) { Text("@" + Chat.nameOf(u)) } } }
    }, confirmButton = { TextButton(onClick = { mentionMenu = false }) { Text(tr("إغلاق", "Close")) } })
    viewer?.let { f -> ImageViewer(f) { viewer = null } }
}

@Composable
private fun DayChip(s: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
        Text(s, Modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 10.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun Bubble(m: Chat.Msg, isGroup: Boolean, all: List<Chat.Msg>, translatedText: String?, onLong: () -> Unit, onOpenImage: (File) -> Unit, nav: NavController, onReact: (String) -> Unit, onRetry: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val mine = m.mine
    val c = m.content
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
            Surface(shape = RoundedCornerShape(16.dp, 16.dp, if (mine) 4.dp else 16.dp, if (mine) 16.dp else 4.dp),
                color = if (mine) Color(0xFFDCF8C6).copy(alpha = if (androidx.compose.foundation.isSystemInDarkTheme()) 0.25f else 1f) else MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp, modifier = Modifier.widthIn(max = 300.dp).combinedClickable(onClick = { if (m.status == -1) onRetry() }, onLongClick = onLong)) {
                Column(Modifier.padding(8.dp)) {
                    if (isGroup && !mine) Text(Chat.nameOf(m.sender), color = Color(avatarColors[(m.sender.hashCode() and 0x7fffffff) % avatarColors.size]), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    if (c?.fwd == true) Text(tr("➡️ تمت إعادة توجيهها", "➡️ Forwarded"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    if (m.replyTo.isNotBlank()) all.firstOrNull { it.id == m.replyTo }?.let { r ->
                        Row(Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)).padding(6.dp)) {
                            Box(Modifier.width(3.dp).height(30.dp).background(MaterialTheme.colorScheme.primary)); Spacer(Modifier.width(6.dp))
                            Column { Text(Chat.nameOf(r.sender), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text(r.content?.preview ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                    if (m.deleted || c == null) Text(tr("🚫 تم حذف هذه الرسالة", "🚫 This message was deleted"), color = MaterialTheme.colorScheme.outline, style = MaterialTheme.typography.bodyMedium)
                    else when (c.kind) {
                        "image", "video" -> {
                            val thumb = remember(c.thumb) { runCatching { val b = android.util.Base64.decode(c.thumb, android.util.Base64.NO_WRAP); android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size) }.getOrNull() }
                            var loading by remember { mutableStateOf(false) }
                            Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                                loading = true
                                scope.launch { val f = withContext(Dispatchers.IO) { Chat.fetchFile(c) }; loading = false
                                    if (f == null) toast(ctx, tr("تعذر التنزيل", "Download failed")) else if (c.kind == "image") onOpenImage(f) else nav.openPlayer(Uri.fromFile(f).toString(), c.name) }
                            }, contentAlignment = Alignment.Center) {
                                if (thumb != null) Image(thumb.asImageBitmap(), null, Modifier.widthIn(max = 260.dp).heightIn(max = 300.dp), contentScale = ContentScale.Fit)
                                else Box(Modifier.size(200.dp, 140.dp).background(Color.DarkGray))
                                if (c.kind == "video") Icon(Icons.Filled.PlayCircle, null, Modifier.size(52.dp), tint = Color.White)
                                if (loading) CircularProgressIndicator()
                            }
                            if (c.text.isNotBlank()) Text(c.text)
                        }
                        "audio" -> VoiceBubble(c)
                        "file" -> {
                            var loading by remember { mutableStateOf(false) }
                            Row(Modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)).clickable {
                                loading = true
                                scope.launch { val f = withContext(Dispatchers.IO) { Chat.fetchFile(c) }; loading = false; if (f == null) toast(ctx, tr("تعذر التنزيل", "Download failed")) else openChatFile(ctx, nav, f, c) }
                            }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.InsertDriveFile, null, Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp))
                                Column(Modifier.widthIn(max = 180.dp)) { Text(c.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold); Text(String.format(Locale.US, "%.1f MB", c.size / 1048576.0) + " • " + c.name.substringAfterLast('.', "").uppercase(), style = MaterialTheme.typography.labelSmall) }
                                if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.Download, null)
                            }
                        }
                        "location" -> Column(Modifier.clickable { nav.openWeb("https://www.openstreetmap.org/?mlat=${c.lat}&mlon=${c.lng}#map=17/${c.lat}/${c.lng}", tr("الموقع", "Location")) }) {
                            Box(Modifier.size(220.dp, 110.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFB3E5FC)), contentAlignment = Alignment.Center) { Text("📍", fontSize = 40.sp) }
                            Text(tr("📍 موقع مشترك", "📍 Shared location"), fontWeight = FontWeight.SemiBold)
                            Text(String.format(Locale.US, "%.5f, %.5f", c.lat, c.lng), style = MaterialTheme.typography.labelSmall)
                        }
                        "contact" -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AccountCircle, null, Modifier.size(40.dp)); Spacer(Modifier.width(8.dp))
                            Column { Text(c.cname, fontWeight = FontWeight.Bold); Text(c.cphone, style = MaterialTheme.typography.bodySmall) }
                            IconButton(onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + c.cphone))) } }) { Icon(Icons.Filled.Call, null) }
                            IconButton(onClick = { nav.navigate("chat_friends") ; runCatching { Thread { Chat.addFriends(listOf(c.cname to c.cphone)) }.start() } }) { Icon(Icons.Filled.PersonAdd, null) }
                        }
                        "call" -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (c.video) Icons.Filled.Videocam else Icons.Filled.Call, null, tint = if (c.missed) DangerRed else SuccessGreen); Spacer(Modifier.width(6.dp))
                            Text((if (c.missed) tr("مكالمة فائتة", "Missed call") else tr("مكالمة", "Call")) + if (c.dur > 0) " • " + String.format(Locale.US, "%d:%02d", c.dur / 60, c.dur % 60) else "")
                        }
                        else -> LinkText(c.text, nav, isMention = c.mentions.contains(Supa.uid))
                    }
                    if (c?.orig?.isNotBlank() == true) Text("🌐 " + c.orig, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    if (translatedText != null) Text("🌐 " + translatedText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                        if (m.editedAt > 0 && !m.deleted) Text(tr("معدلة • ", "edited • "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Text(time(m.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        if (mine) { Spacer(Modifier.width(4.dp)); Ticks(m) }
                    }
                    if (m.status == -1) Text(tr("فشل الإرسال • اضغط لإعادة المحاولة", "Failed • tap to retry"), color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (m.reactions.isNotEmpty()) Row(Modifier.offset(y = (-6).dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)).clickable { m.reactions[Supa.uid]?.let(onReact) }.padding(horizontal = 6.dp, vertical = 2.dp)) {
                Text(m.reactions.values.groupBy { it }.entries.joinToString(" ") { it.key + if (it.value.size > 1) "${it.value.size}" else "" }, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun LinkText(t: String, nav: NavController, isMention: Boolean) {
    val urlRx = Regex("(https?://[^\\s]+)")
    val s = buildAnnotatedString {
        var last = 0
        urlRx.findAll(t).forEach { m ->
            append(t.substring(last, m.range.first))
            pushStringAnnotation("url", m.value); withStyle(SpanStyle(color = Color(0xFF1E88E5), textDecoration = TextDecoration.Underline)) { append(m.value) }; pop()
            last = m.range.last + 1
        }
        append(t.substring(last))
    }
    if (isMention) Text("@", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    ClickableText(s, style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface)) { off ->
        s.getStringAnnotations("url", off, off).firstOrNull()?.let { nav.openWeb(it.item, it.item) }
    }
}

@Composable
private fun VoiceBubble(c: Chat.Content) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableFloatStateOf(0f) }
    DisposableEffect(Unit) { onDispose { player?.release() } }
    LaunchedEffect(playing) { while (playing) { player?.let { if (it.duration > 0) pos = it.currentPosition.toFloat() / it.duration }; delay(200) } }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.width(230.dp)) {
        IconButton(onClick = {
            val p = player
            if (p != null) { if (p.isPlaying) { p.pause(); playing = false } else { p.start(); playing = true } }
            else scope.launch {
                val f = withContext(Dispatchers.IO) { Chat.fetchFile(c) } ?: run { toast(ctx, tr("تعذر التنزيل", "Download failed")); return@launch }
                player = MediaPlayer().apply { setDataSource(f.path); prepare(); setOnCompletionListener { playing = false; pos = 0f }; start() }; playing = true
            }
        }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null) }
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(progress = { pos }, modifier = Modifier.fillMaxWidth())
            Text("🎤 " + String.format(Locale.US, "%d:%02d", c.dur / 60, c.dur % 60), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ImageViewer(f: File, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val bmp = remember(f) { android.graphics.BitmapFactory.decodeFile(f.path) }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize().pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ -> scale = (scale * zoom).coerceIn(1f, 6f); off += pan }
            }.graphicsLayer(scaleX = scale, scaleY = scale, translationX = off.x, translationY = off.y), contentScale = ContentScale.Fit)
            Row(Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                IconButton(onClick = { shareChatFile(ctx, f) }) { Icon(Icons.Filled.Share, null, tint = Color.White) }
                IconButton(onClick = { saveToGallery(ctx, f) }) { Icon(Icons.Filled.Download, null, tint = Color.White) }
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, null, tint = Color.White) }
            }
        }
    }
}

private fun shareChatFile(ctx: Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(ctx.contentResolver.getType(uri) ?: "*/*").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
}

/** حفظ الملف في مجلد التنزيلات/الصور */
private fun saveToGallery(ctx: Context, f: File) {
    runCatching {
        val name = f.name.substringAfter('_')
        val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = android.content.ContentValues().apply { put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name); put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime); put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, (if (mime.startsWith("image")) "Pictures" else "Download") + "/Sho3eb") }
            val col = if (mime.startsWith("image")) android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI else android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI
            ctx.contentResolver.insert(col, cv)?.let { u -> ctx.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } } }
        } else {
            val d = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "Sho3eb").apply { mkdirs() }
            f.copyTo(File(d, name), true)
        }
        toast(ctx, tr("✅ تم الحفظ في الجهاز", "✅ Saved to device"))
    }.onFailure { toast(ctx, tr("تعذر الحفظ", "Couldn't save")) }
}

private fun openChatFile(ctx: Context, nav: NavController, f: File, c: Chat.Content) {
    val mime = c.mime.ifBlank { "*/*" }
    if (mime.startsWith("video") || mime.startsWith("audio")) { nav.openPlayer(Uri.fromFile(f).toString(), c.name); return }
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        .onFailure { saveToGallery(ctx, f) }
}

// =====================================================================
//              المشاركة من أقسام التطبيق الأخرى إلى التواصل
// =====================================================================
@Composable
fun ChatShareScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uris = Chat.pendingShare.value
    val text = Chat.pendingText.value
    val friends = remember { Chat.friends().filter { it.uid.isNotBlank() } }
    val groups = remember { Chat.groups() }
    var sel by remember { mutableStateOf(emptySet<String>()) }
    var selG by remember { mutableStateOf(emptySet<String>()) }
    var caption by remember { mutableStateOf(text) }
    var busy by remember { mutableStateOf(false) }
    if (!Supa.configured) { ChatSetupScreen(nav, first = true); return }
    ScreenScaffold(title = tr("إرسال عبر التواصل", "Send via chat"), onBack = { nav.popBackStack() }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                Text(tr("${uris.size} ملف", "${uris.size} files") + if (text.isNotBlank()) tr(" + نص", " + text") else "", fontWeight = FontWeight.Bold)
                OutlinedTextField(caption, { caption = it }, label = { Text(tr("رسالة مرافقة (اختياري)", "Message (optional)")) }, modifier = Modifier.fillMaxWidth())
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (groups.isNotEmpty()) item { SectionTitle(tr("المجموعات", "Groups")) }
            items(groups, key = { "g" + it.id }) { g ->
                Row(Modifier.fillMaxWidth().clickable { selG = if (g.id in selG) selG - g.id else selG + g.id }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(g.id in selG, { selG = if (it) selG + g.id else selG - g.id }); Text(g.emoji + " " + g.name)
                }
            }
            item { SectionTitle(tr("الأصدقاء", "Friends")) }
            items(friends, key = { it.uid }) { f ->
                Row(Modifier.fillMaxWidth().clickable { sel = if (f.uid in sel) sel - f.uid else sel + f.uid }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(f.uid in sel, { sel = if (it) sel + f.uid else sel - f.uid }); ChatAvatar(f.uid, 34); Spacer(Modifier.width(8.dp)); Text(Chat.nameOf(f.uid))
                }
            }
            item {
                Button(enabled = !busy && (sel.isNotEmpty() || selG.isNotEmpty()), onClick = {
                    busy = true
                    scope.launch(Dispatchers.IO) {
                        val gl = groups.filter { it.id in selG }
                        suspend fun to(peers: List<String>, gid: String) {
                            uris.forEachIndexed { i, u -> Chat.sendFile(peers, u, caption = if (i == 0 && uris.size == 1) caption else "") }
                            if (caption.isNotBlank() && uris.size != 1) Chat.send(peers, Chat.Content("text", caption), groupId = gid)
                            if (uris.isEmpty() && caption.isNotBlank()) Chat.send(peers, Chat.Content("text", caption), groupId = gid)
                        }
                        if (sel.isNotEmpty()) to(sel.toList(), "")
                        gl.forEach { to(it.members, it.id) }
                        Chat.pendingShare.value = emptyList(); Chat.pendingText.value = ""
                        withContext(Dispatchers.Main) { busy = false; toast(ctx, tr("تم الإرسال ✅", "Sent ✅")); nav.popBackStack() }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.AutoMirrored.Filled.Send, null); Spacer(Modifier.width(6.dp)); Text(tr("إرسال", "Send")) }
            }
        }
    }
}
