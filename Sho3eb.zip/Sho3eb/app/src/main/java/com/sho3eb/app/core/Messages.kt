package com.sho3eb.app.core

/** رسائل التذكير الجاهزة لواتساب */
object Messages {
    private fun sign() = appPrefs().displayName.let { if (it.isBlank()) "" else "\n— $it" }

    fun due(item: DueItem): String = when (item.kind) {
        DueKind.ASSOC -> tr(
            "السلام عليكم، تذكير بخصوص جمعية \"${item.title}\": ${item.subtitle}، المبلغ ${Fmt.money(item.amount)}، بتاريخ ${Fmt.date(item.due)}.",
            "Hello, a reminder about the \"${item.title}\" association: ${item.subtitle}, amount ${Fmt.money(item.amount)}, on ${Fmt.date(item.due)}."
        ) + sign()
        DueKind.LOAN -> loan(item.title, item.amount, Fmt.date(item.due))
        DueKind.RENT -> tr(
            "السلام عليكم ${item.title}، نذكركم بموعد ${item.subtitle} بمبلغ ${Fmt.money(item.amount)} المستحق بتاريخ ${Fmt.date(item.due)}. شاكرين تعاونكم.",
            "Hello ${item.title}, a reminder of ${item.subtitle} of ${Fmt.money(item.amount)} due on ${Fmt.date(item.due)}. Thank you."
        ) + sign()
        DueKind.CAR -> tr("تذكير السيارة ${item.title}: ${item.subtitle} بتاريخ ${Fmt.date(item.due)}.", "Car ${item.title}: ${item.subtitle} on ${Fmt.date(item.due)}.")
        DueKind.SUB -> tr("تذكير: دفع ${item.title} بمبلغ ${Fmt.money(item.amount)} بتاريخ ${Fmt.date(item.due)}.", "Reminder: pay ${item.title} ${Fmt.money(item.amount)} on ${Fmt.date(item.due)}.")
        DueKind.DEBT -> tr("تذكير: سداد ${Fmt.money(item.amount)} إلى ${item.title} بتاريخ ${Fmt.date(item.due)}.", "Reminder: pay ${Fmt.money(item.amount)} to ${item.title} on ${Fmt.date(item.due)}.")
        DueKind.SALE -> tr(
            "السلام عليكم ${item.title}، نذكركم بموعد ${item.subtitle} بمبلغ ${Fmt.money(item.amount)} المستحق بتاريخ ${Fmt.date(item.due)}. شاكرين تعاونكم.",
            "Hello ${item.title}, a reminder of your ${item.subtitle} of ${Fmt.money(item.amount)} due on ${Fmt.date(item.due)}. Thank you."
        ) + sign()
    }

    fun assocShare(name: String, assoc: String, round: Int, amount: Double, due: String) = tr(
        "السلام عليكم $name، تذكير بقسط جمعية \"$assoc\" للدورة رقم $round بمبلغ ${Fmt.money(amount)} المستحق بتاريخ $due. شاكرين لك.",
        "Hello $name, a reminder of your \"$assoc\" share for round $round: ${Fmt.money(amount)} due on $due. Thanks."
    ) + sign()

    fun assocTurn(name: String, assoc: String, round: Int, amount: Double, due: String) = tr(
        "السلام عليكم $name، دورك في استلام جمعية \"$assoc\" هو الدورة رقم $round بتاريخ $due بمبلغ ${Fmt.money(amount)}.",
        "Hello $name, your turn to receive the \"$assoc\" payout is round $round on $due, amount ${Fmt.money(amount)}."
    ) + sign()

    fun loan(name: String, balance: Double, due: String?) = tr(
        "السلام عليكم $name، تذكير بأن الرصيد المتبقي من السلفة هو ${Fmt.money(balance)}" + (if (due != null) " وموعد السداد $due" else "") + ". شاكرين لك.",
        "Hello $name, a reminder that your remaining loan balance is ${Fmt.money(balance)}" + (if (due != null) ", due on $due" else "") + ". Thank you."
    ) + sign()

    fun installment(name: String, product: String, amount: Double, due: String, remaining: Double) = tr(
        "السلام عليكم $name، نذكركم بقسط \"$product\" بمبلغ ${Fmt.money(amount)} المستحق بتاريخ $due. إجمالي المتبقي: ${Fmt.money(remaining)}.",
        "Hello $name, a reminder of your \"$product\" installment of ${Fmt.money(amount)} due on $due. Total remaining: ${Fmt.money(remaining)}."
    ) + sign()

    fun accountTx(account: String, isIn: Boolean, amount: Double, date: String, note: String, balance: Double) = tr(
        "حساب \"$account\"\n" + (if (isIn) "إضافة" else "صرف") + ": ${Fmt.money(amount)}\nالتاريخ: $date" +
            (if (note.isNotBlank()) "\nملاحظة: $note" else "") + "\nالرصيد بعد الحركة: ${Fmt.money(balance)}",
        "Account \"$account\"\n" + (if (isIn) "Deposit" else "Withdrawal") + ": ${Fmt.money(amount)}\nDate: $date" +
            (if (note.isNotBlank()) "\nNote: $note" else "") + "\nBalance after: ${Fmt.money(balance)}"
    ) + sign()

    fun accountBalance(account: String, balance: Double) = tr(
        "السلام عليكم، رصيد حساب \"$account\" حتى تاريخه: ${Fmt.money(balance)}",
        "Hello, the balance of account \"$account\" to date is ${Fmt.money(balance)}"
    ) + sign()
}
