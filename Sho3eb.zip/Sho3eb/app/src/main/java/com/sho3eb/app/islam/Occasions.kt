package com.sho3eb.app.islam

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.core.AppState
import com.sho3eb.app.core.Extras
import com.sho3eb.app.core.Fmt
import com.sho3eb.app.core.tr
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.chrono.HijrahChronology
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.util.concurrent.TimeUnit

/** التاريخ الهجري (تقويم أم القرى) والمناسبات الإسلامية */
object Occ {
    data class H(val y: Int, val m: Int, val d: Int)

    val hijriMonths get() = listOf(
        tr("محرم", "Muharram"), tr("صفر", "Safar"), tr("ربيع الأول", "Rabi' I"), tr("ربيع الآخر", "Rabi' II"),
        tr("جمادى الأولى", "Jumada I"), tr("جمادى الآخرة", "Jumada II"), tr("رجب", "Rajab"), tr("شعبان", "Sha'ban"),
        tr("رمضان", "Ramadan"), tr("شوال", "Shawwal"), tr("ذو القعدة", "Dhu al-Qa'dah"), tr("ذو الحجة", "Dhu al-Hijjah")
    )

    /** تحويل ميلادي ← هجري مع تعديل المستخدم (±أيام حسب رؤية الهلال) */
    fun hijri(date: LocalDate = LocalDate.now()): H = try {
        val h = HijrahDate.from(date.plusDays(Extras.hijriAdjust.toLong()))
        H(h.get(ChronoField.YEAR), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.DAY_OF_MONTH))
    } catch (e: Exception) { H(1448, 1, 1) }

    fun toGregorian(y: Int, m: Int, d: Int): LocalDate? = try {
        LocalDate.from(HijrahChronology.INSTANCE.date(y, m, d)).minusDays(Extras.hijriAdjust.toLong())
    } catch (e: Exception) { null }

    fun monthLength(y: Int, m: Int): Int = try { HijrahChronology.INSTANCE.date(y, m, 1).lengthOfMonth() } catch (e: Exception) { 30 }

    fun format(h: H) = "${h.d} ${hijriMonths[h.m - 1]} ${h.y}" + tr(" هـ", " AH")
    fun format(date: LocalDate) = format(hijri(date))

    data class Def(val m: Int, val d: Int, val days: Int, val ar: String, val en: String, val emoji: String, val fasting: Boolean, val descAr: String, val descEn: String) {
        val name get() = tr(ar, en)
        val desc get() = tr(descAr, descEn)
    }

    val defs = listOf(
        Def(1, 1, 1, "رأس السنة الهجرية", "Islamic New Year", "🌙", false,
            "بداية عام هجري جديد وشهر الله المحرم، أحد الأشهر الحرم. قال ﷺ: «أفضل الصيام بعد رمضان شهر الله المحرم» (مسلم).", "Start of the Hijri year and the sacred month of Muharram."),
        Def(1, 9, 1, "يوم تاسوعاء", "Tasu'a", "🤲", true,
            "يُستحب صيامه مع عاشوراء مخالفةً لأهل الكتاب؛ قال ﷺ: «لئن بقيت إلى قابل لأصومن التاسع» (مسلم).", "Recommended fast alongside Ashura."),
        Def(1, 10, 1, "يوم عاشوراء", "Ashura", "🌊", true,
            "اليوم الذي نجّى الله فيه موسى وقومه. قال ﷺ: «صيام يوم عاشوراء أحتسب على الله أن يكفّر السنة التي قبله» (مسلم).", "The day Allah saved Musa; fasting expiates the previous year."),
        Def(8, 1, 1, "شهر شعبان", "Sha'ban", "🌱", false,
            "شهر تُرفع فيه الأعمال، وكان النبي ﷺ يكثر فيه الصيام (البخاري ومسلم). استعد لرمضان بالصيام والقرآن.", "The Prophet ﷺ fasted much of Sha'ban; prepare for Ramadan."),
        Def(9, 1, 30, "شهر رمضان المبارك", "Ramadan", "🌙", true,
            "«من صام رمضان إيماناً واحتساباً غُفر له ما تقدم من ذنبه» (متفق عليه). أكثر من القرآن والقيام والصدقة.", "Whoever fasts Ramadan with faith and hope of reward, his past sins are forgiven."),
        Def(9, 21, 10, "العشر الأواخر من رمضان", "Last ten nights", "✨", true,
            "فيها ليلة القدر خير من ألف شهر؛ تحرَّها في الليالي الوتر. كان ﷺ إذا دخل العشر أحيا الليل وأيقظ أهله وشدّ المئزر (متفق عليه). دعاؤها: «اللهم إنك عفو تحب العفو فاعفُ عني».", "Seek Laylat al-Qadr in the odd nights."),
        Def(10, 1, 1, "عيد الفطر", "Eid al-Fitr", "🎉", false,
            "يحرم صومه. أخرج زكاة الفطر قبل صلاة العيد، وكبّر من غروب ليلة العيد حتى الصلاة، والبس أحسن الثياب، وكُل تمرات وتراً قبل الخروج.", "No fasting. Pay Zakat al-Fitr before the prayer."),
        Def(10, 2, 1, "صيام الست من شوال", "Six days of Shawwal", "🗓️", true,
            "«من صام رمضان ثم أتبعه ستاً من شوال كان كصيام الدهر» (مسلم). تجوز متتابعة أو متفرقة خلال شوال.", "Fasting six days of Shawwal after Ramadan is like fasting a lifetime."),
        Def(12, 1, 10, "عشر ذي الحجة", "First ten of Dhul-Hijjah", "🕋", true,
            "«ما من أيام العمل الصالح فيهن أحب إلى الله من هذه الأيام العشر» (البخاري). أكثر من التكبير والتهليل والتحميد والصيام. ومن أراد الأضحية فلا يأخذ من شعره وأظفاره شيئاً.", "The best days of the year; increase dhikr and good deeds."),
        Def(12, 8, 1, "يوم التروية", "Day of Tarwiyah", "⛺", true,
            "يتوجه الحجاج إلى منى، ويُستحب لغير الحاج الصيام ضمن العشر.", "Pilgrims head to Mina."),
        Def(12, 9, 1, "يوم عرفة", "Day of Arafah", "⛰️", true,
            "«صيام يوم عرفة أحتسب على الله أن يكفّر السنة التي قبله والسنة التي بعده» (مسلم). وخير الدعاء دعاء يوم عرفة.", "Fasting expiates two years; the best day for du'a."),
        Def(12, 10, 1, "عيد الأضحى", "Eid al-Adha", "🐑", false,
            "يوم النحر، أعظم الأيام عند الله. صلِّ العيد ثم اذبح أضحيتك، ويحرم صومه.", "Pray Eid, then sacrifice. Fasting is forbidden."),
        Def(12, 11, 3, "أيام التشريق", "Days of Tashriq", "📿", false,
            "«أيام التشريق أيام أكل وشرب وذكر لله» (مسلم). يستمر التكبير المقيد بعد الصلوات حتى عصر يوم 13، ويحرم صومها.", "Days of eating, drinking and remembering Allah.")
    )

    data class Upcoming(val def: Def, val date: LocalDate, val hijriYear: Int) {
        val daysLeft get() = (date.toEpochDay() - LocalDate.now().toEpochDay()).toInt()
        val end get() = date.plusDays((def.days - 1).toLong())
        val isNow get() = !LocalDate.now().isBefore(date) && !LocalDate.now().isAfter(end)
    }

    /** المناسبات القادمة (والجارية الآن) خلال سنة */
    fun upcoming(from: LocalDate = LocalDate.now()): List<Upcoming> {
        val hy = hijri(from).y
        val out = mutableListOf<Upcoming>()
        for (y in hy..hy + 1) for (d in defs) {
            val days = if (d.m == 9 && d.d == 1) monthLength(y, 9) else if (d.m == 9 && d.d == 21) monthLength(y, 9) - 20 else d.days
            val g = toGregorian(y, d.m, d.d) ?: continue
            val u = Upcoming(d.copy(days = days), g, y)
            if (!u.end.isBefore(from)) out += u
        }
        return out.sortedBy { it.date }.filter { it.date.isBefore(from.plusDays(390)) }
    }

    /** الأيام البيض القادمة (13 و14 و15) */
    fun nextWhiteDays(from: LocalDate = LocalDate.now()): LocalDate? {
        var h = hijri(from)
        repeat(3) {
            val g = toGregorian(h.y, h.m, 13)
            if (g != null && !g.plusDays(2).isBefore(from)) return g
            h = if (h.m == 12) H(h.y + 1, 1, 1) else H(h.y, h.m + 1, 1)
        }
        return null
    }

    /** رمضان الحالي أو القادم: (السنة الهجرية، أول يوم، عدد الأيام) */
    fun ramadan(from: LocalDate = LocalDate.now()): Triple<Int, LocalDate, Int>? {
        val h = hijri(from)
        for (y in listOf(h.y, h.y + 1)) {
            val start = toGregorian(y, 9, 1) ?: continue
            val len = monthLength(y, 9)
            if (!start.plusDays((len - 1).toLong()).isBefore(from)) return Triple(y, start, len)
        }
        return null
    }

    fun isRamadan(date: LocalDate = LocalDate.now()) = hijri(date).m == 9

    /** الحول القادم: نفس التاريخ الهجري بعد سنة هجرية */
    fun nextHawl(start: Long): Long {
        val today = LocalDate.now()
        val h = hijri(LocalDate.ofEpochDay(start))
        var y = h.y + 1
        while (y < h.y + 100) {
            val g = toGregorian(y, h.m, h.d.coerceAtMost(monthLength(y, h.m))) ?: break
            if (!g.isBefore(today)) return g.toEpochDay()
            y++
        }
        return today.toEpochDay()
    }
}

/** فحص يومي مساءً للتذكير بالمناسبات والأيام البيض والاثنين والخميس والزكاة */
class OccasionWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        AppState.lang.value = Sho3ebApp.instance.prefs.lang
        val ctx = applicationContext
        val today = LocalDate.now()
        val tomorrow = today.plusDays(1)
        fun once(key: String, block: () -> Unit) { if (!Extras.b(key, false)) { Extras.pb(key, true); block() } }
        try {
            if (Extras.occasionsRemind) {
                val before = Extras.occasionsDaysBefore.coerceAtLeast(1)
                Occ.upcoming(today).forEach { u ->
                    if (u.daysLeft in 1..before) once("occ_${u.def.m}_${u.def.d}_${u.hijriYear}_${u.daysLeft}") {
                        IslamNotify.show(
                            ctx, IslamNotify.CH_AZKAR, 3500 + u.def.m * 40 + u.def.d,
                            u.def.emoji + " " + (if (u.daysLeft == 1) tr("غداً: ", "Tomorrow: ") else tr("بعد ${u.daysLeft} أيام: ", "In ${u.daysLeft} days: ")) + u.def.name,
                            u.def.desc + if (u.def.fasting) tr("\n\n🍽️ لا تنسَ نية الصيام والسحور.", "\n\n🍽️ Don't forget the fasting intention and suhoor.") else "",
                            "occasions"
                        )
                    }
                }
            }
            // الأيام البيض: تذكير مساء اليوم الثاني عشر
            if (Extras.whiteDaysRemind) {
                val h = Occ.hijri(tomorrow)
                if (h.d == 13 && h.m != 9) once("white_${h.y}_${h.m}") {
                    IslamNotify.show(ctx, IslamNotify.CH_AZKAR, 3480, tr("🌕 غداً أول الأيام البيض", "🌕 White days start tomorrow"),
                        tr("صيام ثلاثة أيام من كل شهر (13 و14 و15) كصيام الدهر كله (متفق عليه). تسحّر فإن في السحور بركة.", "Fasting the 13th–15th is like fasting a lifetime."), "occasions")
                }
            }
            // الاثنين والخميس: تذكير مساء الأحد والأربعاء
            if (Extras.monThuRemind && (tomorrow.dayOfWeek == DayOfWeek.MONDAY || tomorrow.dayOfWeek == DayOfWeek.THURSDAY) && !Occ.isRamadan(tomorrow)) once("mt_${tomorrow.toEpochDay()}") {
                IslamNotify.show(ctx, IslamNotify.CH_AZKAR, 3481,
                    tr("🤲 غداً ", "🤲 Tomorrow is ") + (if (tomorrow.dayOfWeek == DayOfWeek.MONDAY) tr("الاثنين", "Monday") else tr("الخميس", "Thursday")),
                    tr("«تُعرض الأعمال يوم الاثنين والخميس، فأحب أن يُعرض عملي وأنا صائم» (الترمذي وحسّنه).", "Deeds are presented on Mondays and Thursdays."), "occasions")
            }
            // الزكاة
            if (Extras.zakatRemind && Extras.zakatHawl > 0) {
                val due = LocalDate.ofEpochDay(Occ.nextHawl(Extras.zakatHawl))
                val left = (due.toEpochDay() - today.toEpochDay()).toInt()
                if (left == 7 || left == 1 || left == 0) once("zak_${due.toEpochDay()}_$left") {
                    IslamNotify.show(ctx, IslamNotify.CH_AZKAR, 3482, tr("💰 موعد زكاة مالك", "💰 Zakat is due"),
                        (if (left == 0) tr("اليوم يحول الحول على مالك. ", "Your lunar year completes today. ") else tr("بعد $left يوم يحول الحول. ", "$left days left. ")) + tr("افتح حاسبة الزكاة لحسابها بدقة.", "Open the zakat calculator."), "zakat")
                }
            }
        } catch (_: Exception) {}
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val now = LocalDateTime.now()
            var next = now.toLocalDate().atTime(20, 15)
            if (!next.isAfter(now)) next = next.plusDays(1)
            val delay = Duration.between(now, next).toMinutes()
            val req = PeriodicWorkRequestBuilder<OccasionWorker>(1, TimeUnit.DAYS).setInitialDelay(delay, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("sho3eb_occasions", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}

/** كتالوج أصوات الأذان الجاهزة للتنزيل */
object AzanCatalog {
    data class Item(val id: String, val ar: String, val en: String, val url: String, val fajr: Boolean = false) {
        val name get() = tr(ar, en)
    }

    val items = listOf(
        Item("alafasy1", "مشاري راشد العفاسي (1)", "Mishary Alafasy (1)", "https://cdn.aladhan.com/audio/adhans/a9.mp3"),
        Item("alafasy2", "مشاري راشد العفاسي (2)", "Mishary Alafasy (2)", "https://cdn.aladhan.com/audio/adhans/a7.mp3"),
        Item("alafasy_dubai", "مشاري العفاسي — دبي", "Mishary Alafasy — Dubai", "https://cdn.aladhan.com/audio/adhans/a4.mp3"),
        Item("zahrani", "منصور الزهراني", "Mansour Al-Zahrani", "https://cdn.aladhan.com/audio/adhans/a11-mansour-al-zahrani.mp3"),
        Item("nafees", "أحمد النفيس", "Ahmad al-Nafees", "https://cdn.aladhan.com/audio/adhans/a1.mp3"),
        Item("ozcan", "حافظ مصطفى أوزجان (تركيا)", "Hafiz Mustafa Özcan (Turkey)", "https://cdn.aladhan.com/audio/adhans/a2.mp3"),
        Item("bilal", "بلال عبد العزيز (مقام جهاركاه)", "Bilal Abdulaziz", "https://cdn.jsdelivr.net/gh/yousef-nasser-daaboul/alkannani-audio@v1.0.0/audio/adhan/bilal-abdulaziz/regular-jiharkah.mp3"),
        Item("bilal_fajr", "بلال عبد العزيز — أذان الفجر", "Bilal Abdulaziz — Fajr", "https://cdn.jsdelivr.net/gh/yousef-nasser-daaboul/alkannani-audio@v1.0.0/audio/adhan/bilal-abdulaziz/fajr.mp3", fajr = true)
    )

    fun fileFor(ctx: Context, it: Item) = java.io.File(java.io.File(ctx.filesDir, "azan").apply { mkdirs() }, "cat_${it.id}.mp3")
}

/** متابعة الصلوات */
object PrayerLog {
    /** فهرس المتابعة (0..4) من فهرس أوقات الصلاة (0..5) */
    fun idx(k: Int): Int = when (k) { Prayer.FAJR -> 0; Prayer.DHUHR -> 1; Prayer.ASR -> 2; Prayer.MAGHRIB -> 3; Prayer.ISHA -> 4; else -> -1 }
    val names get() = listOf(tr("الفجر", "Fajr"), tr("الظهر", "Dhuhr"), tr("العصر", "Asr"), tr("المغرب", "Maghrib"), tr("العشاء", "Isha"))
    val statusNames get() = listOf("—", tr("في وقتها", "On time"), tr("جماعة", "Congregation"), tr("متأخرة", "Late"), tr("قضاء", "Made up"), tr("فاتتني", "Missed"))
    val sunnahNames get() = listOf(tr("سنة الفجر", "Fajr sunnah"), tr("قبل الظهر", "Before Dhuhr"), tr("بعد الظهر", "After Dhuhr"), tr("بعد المغرب", "After Maghrib"), tr("بعد العشاء", "After Isha"), tr("الوتر", "Witr"), tr("الضحى", "Duha"))

    fun get(day: Long): IntArray = Extras.prayerDay(day).map { (it - '0').coerceIn(0, 5) }.toIntArray()
    fun set(day: Long, i: Int, s: Int) = Extras.setPrayer(day, i, s)
    fun done(s: Int) = s in 1..4

    /** نسبة الصلوات المؤداة خلال آخر n يوماً */
    fun percent(n: Int): Int {
        val t = Fmt.today()
        var ok = 0
        for (d in 0 until n) ok += get(t - d).count { done(it) }
        return ok * 100 / (n * 5)
    }

    /** أيام متتالية بكل الصلوات */
    fun streak(): Int {
        var t = Fmt.today()
        if (get(t).count { done(it) } < 5) t -= 1
        var n = 0
        while (n < 3650 && get(t).all { done(it) }) { n++; t -= 1 }
        return n
    }
}
