package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate
import kotlin.math.ceil
import kotlin.math.min

// ======================= العقارات والإيجارات =======================
object Rent {
    data class T(val key: String, val ar: String, val en: String, val emoji: String) { val label get() = tr(ar, en) }

    val propTypes = listOf(
        T("BUILDING", "عمارة", "Building", "🏢"), T("APARTMENT", "شقة", "Apartment", "🏠"), T("VILLA", "فيلا", "Villa", "🏡"),
        T("SHOP", "محل تجاري", "Shop", "🏪"), T("OFFICE", "مكتب", "Office", "🏬"), T("WAREHOUSE", "مستودع", "Warehouse", "🏭"),
        T("LAND", "أرض", "Land", "🌍"), T("ROOM", "غرفة", "Room", "🚪"), T("OTHER", "أخرى", "Other", "📦")
    )
    val expenseCats = listOf(
        T("MAINT", "صيانة وإصلاح", "Maintenance", "🛠️"), T("ELECTRIC", "كهرباء", "Electricity", "💡"), T("WATER", "مياه", "Water", "🚰"),
        T("CLEANING", "نظافة وحراسة", "Cleaning & security", "🧹"), T("TAX", "رسوم وضرائب", "Fees & taxes", "🧾"),
        T("INSURANCE", "تأمين", "Insurance", "🛡️"), T("COMMISSION", "عمولة سمسرة", "Brokerage", "🤝"),
        T("FURNISH", "أثاث وتجهيز", "Furnishing", "🛋️"), T("OTHER", "أخرى", "Other", "📦")
    )
    val periods = listOf(1, 2, 3, 6, 12)
    fun periodName(m: Int) = when (m) {
        1 -> tr("شهري", "Monthly"); 2 -> tr("كل شهرين", "Every 2 months"); 3 -> tr("ربع سنوي", "Quarterly")
        6 -> tr("نصف سنوي", "Semi-annual"); 12 -> tr("سنوي", "Yearly"); else -> tr("كل $m أشهر", "Every $m months")
    }
    fun propType(k: String) = propTypes.firstOrNull { it.key == k } ?: propTypes.last()
    fun expCat(k: String) = expenseCats.firstOrNull { it.key == k } ?: expenseCats.last()

    /** دفعة مستحقة في جدول العقد */
    data class Due(val index: Int, val due: LocalDate, val amount: Double, val paid: Double) {
        val remaining get() = round2((amount - paid).coerceAtLeast(0.0))
        val isPaid get() = remaining < 0.005
    }

    /** جدول دفعات العقد من البداية إلى النهاية، مع توزيع المدفوعات بالترتيب */
    fun schedule(l: Lease, payments: List<LeasePayment>): List<Due> {
        val start = LocalDate.ofEpochDay(l.startDate)
        val end = LocalDate.ofEpochDay(l.endDate)
        val dues = mutableListOf<LocalDate>()
        var k = 0
        while (true) {
            val d = start.plusMonths((k * l.periodMonths.coerceAtLeast(1)).toLong())
            if (d.isAfter(end) || k > 600) break
            dues += d; k++
        }
        if (dues.isEmpty()) dues += start
        var pool = payments.filter { it.leaseId == l.id }.sumOf { it.amount }
        return dues.mapIndexed { i, d ->
            val p = min(pool, l.rentAmount).coerceAtLeast(0.0)
            pool -= p
            Due(i, d, l.rentAmount, round2(p))
        }
    }

    fun total(l: Lease, n: Int) = l.rentAmount * n
    fun paid(l: Lease, payments: List<LeasePayment>) = payments.filter { it.leaseId == l.id }.sumOf { it.amount }
    fun overdue(l: Lease, payments: List<LeasePayment>, today: LocalDate = LocalDate.now()) =
        schedule(l, payments).filter { !it.isPaid && !it.due.isAfter(today) }
    fun nextDue(l: Lease, payments: List<LeasePayment>) = schedule(l, payments).firstOrNull { !it.isPaid }
    fun monthlyRent(l: Lease) = l.rentAmount / l.periodMonths.coerceAtLeast(1)
    fun isCurrent(l: Lease, today: Long = Fmt.today()) = l.active && today in l.startDate..l.endDate
    fun daysLeft(l: Lease) = (l.endDate - Fmt.today()).toInt()

    data class PropStats(val units: Int, val occupied: Int, val monthlyRent: Double, val collected: Double, val overdue: Double, val expenses: Double) {
        val occupancy get() = if (units > 0) occupied * 100 / units else 0
        val net get() = collected - expenses
    }

    fun stats(propId: Long?, units: List<PropUnit>, leases: List<Lease>, payments: List<LeasePayment>, expenses: List<PropExpense>, range: LongRange? = null): PropStats {
        val us = units.filter { propId == null || it.propertyId == propId }
        val uids = us.map { it.id }.toSet()
        val ls = leases.filter { it.unitId in uids }
        val cur = ls.filter { isCurrent(it) }
        val lids = ls.map { it.id }.toSet()
        val pays = payments.filter { it.leaseId in lids && (range == null || it.date in range) }
        val exps = expenses.filter { (propId == null || it.propertyId == propId) && (range == null || it.date in range) }
        return PropStats(
            us.size, cur.map { it.unitId }.distinct().size, cur.sumOf { monthlyRent(it) },
            pays.sumOf { it.amount }, ls.filter { it.active }.sumOf { l -> overdue(l, payments).sumOf { it.remaining } }, exps.sumOf { it.amount }
        )
    }
}

// ======================= ديوني =======================
object Debts {
    data class T(val key: String, val ar: String, val en: String, val emoji: String) { val label get() = tr(ar, en) }
    val types = listOf(
        T("PERSON", "شخص", "Person", "👤"), T("BANK", "بنك / تمويل", "Bank / finance", "🏦"), T("CARD", "بطاقة ائتمان", "Credit card", "💳"),
        T("STORE", "محل / مورّد", "Store / supplier", "🏪"), T("COMPANY", "شركة", "Company", "🏢"), T("ASSOC", "جمعية", "Association", "🤝"),
        T("OTHER", "أخرى", "Other", "📦")
    )
    fun type(k: String) = types.firstOrNull { it.key == k } ?: types.last()
    fun priorityName(p: Int) = when (p) { 1 -> tr("عالية", "High"); 3 -> tr("منخفضة", "Low"); else -> tr("متوسطة", "Medium") }

    fun borrowed(d: Debt, txs: List<DebtTx>) = txs.filter { it.debtId == d.id && it.type == DebtTx.BORROW }.sumOf { it.amount }
    fun paid(d: Debt, txs: List<DebtTx>) = txs.filter { it.debtId == d.id && it.type == DebtTx.PAY }.sumOf { it.amount }
    fun balance(d: Debt, txs: List<DebtTx>) = round2(borrowed(d, txs) - paid(d, txs))

    /** موعد القسط القادم بناءً على ما سُدد */
    fun nextDue(d: Debt, txs: List<DebtTx>): LocalDate? {
        val bal = balance(d, txs)
        if (bal <= 0.005 || d.closed) return null
        if (d.installment > 0 && d.firstDue != null) {
            val paidCount = (paid(d, txs) / d.installment + 1e-6).toInt()
            return LocalDate.ofEpochDay(d.firstDue).plusMonths((paidCount * d.periodMonths.coerceAtLeast(1)).toLong())
        }
        return d.dueDate?.let { LocalDate.ofEpochDay(it) }
    }

    fun nextAmount(d: Debt, txs: List<DebtTx>): Double {
        val bal = balance(d, txs)
        if (d.installment <= 0) return bal
        val paidNow = paid(d, txs)
        val inCurrent = paidNow - ((paidNow / d.installment + 1e-6).toInt() * d.installment)
        return min(bal, round2(d.installment - inCurrent))
    }

    fun remainingInstallments(d: Debt, txs: List<DebtTx>): Int =
        if (d.installment > 0) ceil(balance(d, txs) / d.installment - 1e-9).toInt().coerceAtLeast(0) else 0

    /** خطة سداد مقترحة: كرة الثلج (الأصغر أولاً) أو الأولوية */
    data class PlanLine(val debt: Debt, val balance: Double, val monthlyPay: Double, val months: Int, val finishDate: LocalDate)

    fun payoffPlan(debts: List<Debt>, txs: List<DebtTx>, monthlyBudget: Double, snowball: Boolean): List<PlanLine> {
        val open = debts.filter { !it.closed && balance(it, txs) > 0.005 }
        if (open.isEmpty() || monthlyBudget <= 0) return emptyList()
        val order = if (snowball) open.sortedBy { balance(it, txs) } else open.sortedWith(compareBy({ it.priority }, { balance(it, txs) }))
        val bal = order.associate { it.id to balance(it, txs) }.toMutableMap()
        val minPay = order.associate { it.id to if (it.installment > 0) it.installment / it.periodMonths.coerceAtLeast(1) else 0.0 }
        val finish = mutableMapOf<Long, Int>()
        var month = 0
        while (bal.values.any { it > 0.005 } && month < 600) {
            month++
            var budget = monthlyBudget
            // الحد الأدنى لكل دين أولاً
            order.forEach { d ->
                val b = bal[d.id] ?: 0.0
                if (b > 0.005) { val p = min(b, min(minPay[d.id] ?: 0.0, budget)); bal[d.id] = b - p; budget -= p }
            }
            // الباقي للدين الأول في الترتيب
            for (d in order) {
                if (budget <= 0.005) break
                val b = bal[d.id] ?: 0.0
                if (b > 0.005) { val p = min(b, budget); bal[d.id] = b - p; budget -= p }
            }
            order.forEach { d -> if ((bal[d.id] ?: 0.0) <= 0.005 && d.id !in finish) finish[d.id] = month }
        }
        val now = LocalDate.now()
        return order.map { d ->
            val m = finish[d.id] ?: 600
            PlanLine(d, balance(d, txs), if (m > 0) balance(d, txs) / m else 0.0, m, now.plusMonths(m.toLong()))
        }
    }
}
