package com.sho3eb.app.core

import android.content.Context
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.Invoice
import com.sho3eb.app.data.InvoiceItem
import com.sho3eb.app.data.InvoicePayment
import com.sho3eb.app.data.Product
import com.sho3eb.app.ui.ProductImages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.Executors

/**
 * لوحة الويب: تشغيل البرنامج من متصفح Chrome على الكمبيوتر أو اللاب توب عبر شبكة الواي فاي نفسها.
 * الهاتف يعمل كخادم صغير والبيانات تبقى على الهاتف (لا تُرفع لأي مكان).
 */
object WebPanel {
    const val PORT = 8765
    @Volatile private var server: ServerSocket? = null
    private val pool = Executors.newFixedThreadPool(4)
    val running get() = server != null

    var enabled: Boolean get() = Extras.b("web_on", false); set(v) = Extras.pb("web_on", v)
    val token: String get() = Extras.s("web_tok", "").ifBlank { (1..10).map { "abcdefghjkmnpqrstuvwxyz23456789".random() }.joinToString("").also { Extras.ps("web_tok", it) } }
    fun newToken() { Extras.ps("web_tok", ""); token }

    fun ip(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan") || it.name.startsWith("ap") || it.name.startsWith("swlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }.firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
    }.getOrNull()

    fun url(): String? = ip()?.let { "http://$it:$PORT/?k=$token" }

    fun startIfEnabled(ctx: Context) { if (enabled) start(ctx) }

    @Synchronized fun start(ctx: Context) {
        if (server != null) return
        val ss = runCatching { ServerSocket(PORT) }.getOrNull() ?: return
        server = ss
        Thread {
            while (!ss.isClosed) {
                val s = runCatching { ss.accept() }.getOrNull() ?: break
                pool.execute { runCatching { handle(ctx.applicationContext, s) }; runCatching { s.close() } }
            }
        }.apply { isDaemon = true; name = "WebPanel" }.start()
    }
    @Synchronized fun stop() { runCatching { server?.close() }; server = null }

    // ======================= HTTP =======================
    private class Req(val method: String, val path: String, val query: Map<String, String>, val headers: Map<String, String>, val body: ByteArray)

    private fun readReq(s: Socket): Req? {
        s.soTimeout = 20000
        val inp = BufferedInputStream(s.getInputStream())
        val head = ByteArrayOutputStream()
        var last4 = 0
        while (true) { val b = inp.read(); if (b < 0) return null; head.write(b); last4 = (last4 shl 8) or b; if (last4 == 0x0d0a0d0a) break; if (head.size() > 64 * 1024) return null }
        val lines = head.toString("UTF-8").split("\r\n")
        val (m, full) = lines[0].split(" ").let { it[0] to it.getOrElse(1) { "/" } }
        val headers = lines.drop(1).filter { it.contains(":") }.associate { it.substringBefore(":").trim().lowercase() to it.substringAfter(":").trim() }
        val len = headers["content-length"]?.toIntOrNull() ?: 0
        val body = ByteArray(len.coerceAtMost(25 * 1024 * 1024)); var n = 0
        while (n < body.size) { val k = inp.read(body, n, body.size - n); if (k <= 0) break; n += k }
        val path = full.substringBefore("?")
        val q = full.substringAfter("?", "").split("&").filter { it.contains("=") }.associate { URLDecoder.decode(it.substringBefore("="), "UTF-8") to URLDecoder.decode(it.substringAfter("="), "UTF-8") }
        return Req(m, path, q, headers, body)
    }

    private fun send(o: OutputStream, code: Int, type: String, data: ByteArray, extra: String = "") {
        val status = when (code) { 200 -> "OK"; 401 -> "Unauthorized"; 404 -> "Not Found"; else -> "Error" }
        o.write(("HTTP/1.1 $code $status\r\nContent-Type: $type\r\nContent-Length: ${data.size}\r\nCache-Control: no-store\r\nConnection: close\r\n$extra\r\n").toByteArray())
        o.write(data); o.flush()
    }
    private fun json(o: OutputStream, v: Any) = send(o, 200, "application/json; charset=utf-8", v.toString().toByteArray())

    private fun handle(ctx: Context, s: Socket) {
        val r = readReq(s) ?: return
        val out = s.getOutputStream()
        if (r.path == "/" || r.path == "/index.html") { send(out, 200, "text/html; charset=utf-8", ctx.assets.open("web/index.html").use { it.readBytes() }); return }
        val k = r.headers["x-k"] ?: r.query["k"]
        if (k != token) { send(out, 401, "application/json", "{\"error\":\"unauthorized\"}".toByteArray()); return }
        val dao = Sho3ebApp.instance.db.dao()
        runBlocking(Dispatchers.IO) {
            when (r.path) {
                "/api/summary" -> {
                    val invs = dao.allInvoices(); val items = dao.allInvoiceItems(); val pays = dao.allInvoicePayments()
                    val rows = Shop.rows(invs, items, pays)
                    val today = Fmt.today()
                    val monthStart = java.time.LocalDate.now().withDayOfMonth(1).toEpochDay()
                    val prods = dao.allProducts()
                    val stock = Shop.stockMap(prods, invs, items, dao.allStockAdjs())
                    val st = Shop.stats(rows, items, monthStart..Long.MAX_VALUE)
                    val sd = Shop.stats(rows, items, today..Long.MAX_VALUE)
                    json(out, JSONObject().put("name", Brand.name.ifBlank { Edition.appName }).put("monthSales", st.net).put("monthProfit", st.profit).put("todaySales", sd.net)
                        .put("customersOwe", Shop.parties(rows, true).sumOf { it.remaining.coerceAtLeast(0.0) }).put("oweSuppliers", Shop.parties(rows, false).sumOf { it.remaining.coerceAtLeast(0.0) })
                        .put("products", prods.count { !Manufacture.isRaw(it) }).put("low", prods.count { Shop.isLow(it, stock[it.id] ?: 0.0) })
                        .put("stockValue", prods.filter { it.trackStock }.sumOf { (stock[it.id] ?: 0.0).coerceAtLeast(0.0) * it.cost }).put("currency", Fmt.money(0.0).replace(Regex("[0-9.,٠-٩\\s]"), "")))
                }
                "/api/products" -> {
                    val prods = dao.allProducts(); val invs = dao.allInvoices(); val items = dao.allInvoiceItems()
                    val stock = Shop.stockMap(prods, invs, items, dao.allStockAdjs())
                    json(out, JSONArray(prods.map { p ->
                        JSONObject().put("id", p.id).put("name", p.name).put("sku", p.sku).put("category", if (Manufacture.isRaw(p)) "" else p.category).put("raw", Manufacture.isRaw(p))
                            .put("unit", p.unit).put("cost", p.cost).put("price", p.price).put("stock", stock[p.id] ?: 0.0).put("min", p.minQty).put("track", p.trackStock)
                            .put("active", p.active).put("notes", p.notes).put("img", ProductImages.get(p.id) != null)
                    }))
                }
                "/api/product" -> {
                    val j = JSONObject(String(r.body, Charsets.UTF_8))
                    val id = j.optLong("id", 0)
                    val old = if (id > 0) dao.allProducts().firstOrNull { it.id == id } else null
                    val p = (old ?: Product(name = "")).copy(name = j.optString("name").trim(), sku = j.optString("sku"), unit = j.optString("unit"),
                        category = if (j.optBoolean("raw")) Manufacture.RAW_CAT else j.optString("category"), cost = j.optDouble("cost", 0.0), price = j.optDouble("price", 0.0),
                        minQty = j.optDouble("min", 0.0), trackStock = j.optBoolean("track", true), active = j.optBoolean("active", true), notes = j.optString("notes"),
                        openingQty = if (old == null) j.optDouble("qty", 0.0) else old.openingQty)
                    if (p.name.isBlank()) { send(out, 400, "application/json", "{\"error\":\"name\"}".toByteArray()); return@runBlocking }
                    val nid = if (old == null) dao.insertProduct(p) else { dao.updateProduct(p); old.id }
                    json(out, JSONObject().put("id", nid))
                }
                "/api/product/delete" -> { val id = JSONObject(String(r.body)).optLong("id"); ProductImages.set(id, null); dao.deleteProductFull(id); json(out, JSONObject().put("ok", true)) }
                "/api/img" -> {
                    val id = r.query["id"]?.toLongOrNull() ?: 0
                    if (r.method == "POST" && r.body.isNotEmpty()) {
                        val dir = File(ctx.filesDir, "photos").apply { mkdirs() }
                        val f = File(dir, "prod_${id}_${System.currentTimeMillis()}.jpg")
                        val b = android.graphics.BitmapFactory.decodeByteArray(r.body, 0, r.body.size)
                        if (b == null) { send(out, 400, "application/json", "{}".toByteArray()); return@runBlocking }
                        val k2 = minOf(1f, 720f / maxOf(b.width, b.height))
                        val sb = android.graphics.Bitmap.createScaledBitmap(b, (b.width * k2).toInt().coerceAtLeast(1), (b.height * k2).toInt().coerceAtLeast(1), true)
                        f.outputStream().use { sb.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }
                        ProductImages.set(id, f.absolutePath)
                        json(out, JSONObject().put("ok", true))
                    } else {
                        val p = ProductImages.get(id)
                        if (p == null) send(out, 404, "text/plain", ByteArray(0)) else send(out, 200, "image/jpeg", File(p).readBytes(), "Cache-Control: max-age=60\r\n")
                    }
                }
                "/api/invoices" -> {
                    val invs = dao.allInvoices(); val items = dao.allInvoiceItems(); val pays = dao.allInvoicePayments()
                    val byInv = items.groupBy { it.invoiceId }
                    json(out, JSONArray(Shop.rows(invs, items, pays).take(500).map { row ->
                        JSONObject().put("id", row.inv.id).put("no", Shop.numberText(row.inv)).put("type", row.inv.type).put("typeName", Shop.type(row.inv.type).label)
                            .put("date", row.inv.date).put("party", row.inv.partyName).put("phone", row.inv.partyPhone).put("total", row.t.total).put("paid", row.paid).put("remaining", row.remaining)
                            .put("items", JSONArray(byInv[row.inv.id].orEmpty().map { JSONObject().put("name", it.name).put("qty", it.qty).put("price", it.price) }))
                    }))
                }
                "/api/invoice" -> {
                    val j = JSONObject(String(r.body, Charsets.UTF_8))
                    val type = j.optString("type", Shop.SALE)
                    val prods = dao.allProducts().associateBy { it.id }
                    val arr = j.optJSONArray("items") ?: JSONArray()
                    val lines = (0 until arr.length()).map { arr.getJSONObject(it) }.map { x ->
                        val pid = x.optLong("productId", 0).takeIf { it > 0 }
                        InvoiceItem(invoiceId = 0, productId = pid, name = x.optString("name").ifBlank { prods[pid]?.name ?: "" }, qty = x.optDouble("qty", 1.0), price = x.optDouble("price", 0.0), cost = prods[pid]?.cost ?: 0.0)
                    }.filter { it.name.isNotBlank() && it.qty > 0 }
                    if (lines.isEmpty()) { send(out, 400, "application/json", "{\"error\":\"items\"}".toByteArray()); return@runBlocking }
                    val inv = Invoice(type = type, number = Shop.nextNumber(dao, type), partyName = j.optString("party"), partyPhone = j.optString("phone"), date = Fmt.today(),
                        discount = j.optDouble("discount", 0.0), notes = j.optString("notes"))
                    val id = dao.saveInvoice(inv, lines)
                    val paid = j.optDouble("paid", 0.0)
                    if (paid > 0) dao.insertInvoicePayment(InvoicePayment(invoiceId = id, amount = paid, date = Fmt.today()))
                    json(out, JSONObject().put("id", id))
                }
                "/api/parties" -> {
                    val rows = Shop.rows(dao.allInvoices(), dao.allInvoiceItems(), dao.allInvoicePayments())
                    json(out, JSONArray(Shop.parties(rows, r.query["c"] != "0").map { JSONObject().put("name", it.name).put("phone", it.phone).put("count", it.count).put("total", it.total).put("paid", it.paid).put("remaining", it.remaining).put("last", it.last) }))
                }
                "/api/brand" -> json(out, JSONObject().put("name", Brand.name.ifBlank { Edition.appName }).put("phone", Brand.phone).put("address", Brand.address).put("logo", Brand.logo(ctx).exists()).put("rtl", AppState.isRtl))
                "/logo" -> { val f = Brand.logo(ctx); if (f.exists()) send(out, 200, "image/png", f.readBytes()) else send(out, 404, "text/plain", ByteArray(0)) }
                "/api/pricelist.pdf" -> {
                    val opts = PriceList.Opts()
                    val f = PriceList.pdf(ctx, PriceList.items(dao.allProducts(), opts), opts)
                    send(out, 200, "application/pdf", f.readBytes(), "Content-Disposition: inline; filename=\"price_list.pdf\"\r\n")
                }
                else -> send(out, 404, "text/plain", "not found".toByteArray())
            }
        }
    }
}
