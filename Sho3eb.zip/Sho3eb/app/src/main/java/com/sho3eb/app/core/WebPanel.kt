package com.sho3eb.app.core

import android.content.Context
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.Invoice
import com.sho3eb.app.data.InvoiceItem
import com.sho3eb.app.data.InvoicePayment
import com.sho3eb.app.data.Product
import com.sho3eb.app.ui.ProductImages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.Executors

/**
 * لوحة الويب: تشغيل البرنامج من متصفح Chrome على الكمبيوتر أو اللاب توب عبر شبكة الواي فاي نفسها.
 * الهاتف يعمل كخادم صغير والبيانات تبقى على الهاتف (لا تُرفع لأي مكان).
 */
object WebPanel {
    const val PORT = 8765
    @Volatile private var server: ServerSocket? = null
    private val pool = Executors.newFixedThreadPool(8)
    val running get() = server != null

    var enabled: Boolean get() = Extras.b("web_on", false); set(v) = Extras.pb("web_on", v)
    val token: String get() = Extras.s("web_tok", "").ifBlank { (1..10).map { "abcdefghjkmnpqrstuvwxyz23456789".random() }.joinToString("").also { Extras.ps("web_tok", it) } }
    fun newToken() { Extras.ps("web_tok", ""); token }

    fun ip(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan") || it.name.startsWith("ap") || it.name.startsWith("swlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }.firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
    }.getOrNull()

    fun url(): String? = ip()?.let { "http://$it:$PORT/?k=$token" }

    fun startIfEnabled(ctx: Context) { if (enabled) start(ctx) }

    @Synchronized fun start(ctx: Context) {
        if (server != null) return
        val ss = runCatching { ServerSocket(PORT) }.getOrNull() ?: return
        server = ss
        Thread {
            while (!ss.isClosed) {
                val s = runCatching { ss.accept() }.getOrNull() ?: break
                pool.execute { runCatching { handle(ctx.applicationContext, s) }; runCatching { s.close() } }
            }
        }.apply { isDaemon = true; name = "WebPanel" }.start()
    }
    @Synchronized fun stop() { runCatching { server?.close() }; server = null }

    // ======================= HTTP =======================
    private class Req(val method: String, val path: String, val query: Map<String, String>, val headers: Map<String, String>, val body: ByteArray)

    private fun readReq(s: Socket): Req? {
        s.soTimeout = 20000
        val inp = BufferedInputStream(s.getInputStream())
        val head = ByteArrayOutputStream()
        var last4 = 0
        while (true) { val b = inp.read(); if (b < 0) return null; head.write(b); last4 = (last4 shl 8) or b; if (last4 == 0x0d0a0d0a) break; if (head.size() > 64 * 1024) return null }
        val lines = head.toString("UTF-8").split("\r\n")
        val (m, full) = lines[0].split(" ").let { it[0] to it.getOrElse(1) { "/" } }
        val headers = lines.drop(1).filter { it.contains(":") }.associate { it.substringBefore(":").trim().lowercase() to it.substringAfter(":").trim() }
        val len = headers["content-length"]?.toIntOrNull() ?: 0
        val body = ByteArray(len.coerceAtMost(25 * 1024 * 1024)); var n = 0
        while (n < body.size) { val k = inp.read(body, n, body.size - n); if (k <= 0) break; n += k }
        val path = full.substringBefore("?")
        val q = full.substringAfter("?", "").split("&").filter { it.contains("=") }.associate { URLDecoder.decode(it.substringBefore("="), "UTF-8") to URLDecoder.decode(it.substringAfter("="), "UTF-8") }
        return Req(m, path, q, headers, body)
    }

    @Volatile private var gzipOk = false
    private fun gz(b: ByteArray): ByteArray = ByteArrayOutputStream().also { bo -> java.util.zip.GZIPOutputStream(bo).use { it.write(b) } }.toByteArray()
    private fun send(o: OutputStream, code: Int, type: String, data0: ByteArray, extra: String = "") {
        val status = when (code) { 200 -> "OK"; 401 -> "Unauthorized"; 404 -> "Not Found"; else -> "Error" }
        val zip = gzipOk && data0.size > 1024 && (type.startsWith("text") || type.contains("json"))
        val data = if (zip) gz(data0) else data0
        val cache = if (extra.contains("Cache-Control")) "" else "Cache-Control: no-store\r\n"
        o.write(("HTTP/1.1 $code $status\r\nContent-Type: $type\r\nContent-Length: ${data.size}\r\n$cache" + (if (zip) "Content-Encoding: gzip\r\n" else "") + "Connection: close\r\n$extra\r\n").toByteArray())
        o.write(data); o.flush()
    }
    private fun json(o: OutputStream, v: Any) = send(o, 200, "application/json; charset=utf-8", v.toString().toByteArray())
    private var htmlCache: ByteArray? = null
    private fun xlsxOut(o: OutputStream, f: File, name: String) = send(o, 200, Xlsx.MIME, f.readBytes(), "Content-Disposition: attachment; filename=\"$name\"\r\n")

    private fun handle(ctx: Context, s: Socket) {
        val r = readReq(s) ?: return
        val out = java.io.BufferedOutputStream(s.getOutputStream(), 1 shl 16)
        gzipOk = r.headers["accept-encoding"]?.contains("gzip") == true
        if (r.path == "/" || r.path == "/index.html") {
            val h = htmlCache ?: ctx.assets.open("web/index.html").use { it.readBytes() }.also { htmlCache = it }
            send(out, 200, "text/html; charset=utf-8", h); return
        }
        if (r.path == "/favicon.ico") { send(out, 404, "text/plain", ByteArray(0)); return }
        val k = r.headers["x-k"] ?: r.query["k"]
        if (k != token) { send(out, 401, "application/json", "{\"error\":\"unauthorized\"}".toByteArray()); return }
        val dao = Sho3ebApp.instance.db.dao()
        runBlocking(Dispatchers.IO) {
            when (r.path) {
                "/api/summary" -> {
                    val invs = dao.allInvoices(); val items = dao.allInvoiceItems(); val pays = dao.allInvoicePayments()
                    val rows = Shop.rows(invs, items, pays)
                    val today = Fmt.today()
                    val monthStart = java.time.LocalDate.now().withDayOfMonth(1).toEpochDay()
                    val prods = dao.allProducts()
                    val stock = Shop.stockMap(prods, invs, items, dao.allStockAdjs())
                    val st = Shop.stats(rows, items, monthStart..Long.MAX_VALUE)
                    val sd = Shop.stats(rows, items, today..Long.MAX_VALUE)
                    json(out, JSONObject().put("name", Brand.name.ifBlank { Edition.appName }).put("monthSales", st.net).put("monthProfit", st.profit).put("todaySales", sd.net)
                        .put("customersOwe", Shop.parties(rows, true).sumOf { it.remaining.coerceAtLeast(0.0) }).put("oweSuppliers", Shop.parties(rows, false).sumOf { it.remaining.coerceAtLeast(0.0) })
                        .put("products", prods.count { !Manufacture.isRaw(it) }).put("low", prods.count { Shop.isLow(it, stock[it.id] ?: 0.0) })
                        .put("stockValue", prods.filter { it.trackStock }.sumOf { (stock[it.id] ?: 0.0).coerceAtLeast(0.0) * it.cost }).put("currency", Fmt.money(0.0).replace(Regex("[0-9.,٠-٩\\s]"), "")))
                }
                "/api/analytics" -> {
                    val invs = dao.allInvoices(); val items = dao.allInvoiceItems(); val pays = dao.allInvoicePayments()
                    val rows = Shop.rows(invs, items, pays)
                    val from = r.query["from"]?.toLongOrNull(); val to = r.query["to"]?.toLongOrNull()
                    val range = if (from != null || to != null) (from ?: 0L)..(to ?: Long.MAX_VALUE) else null
                    val st = Shop.stats(rows, items, range)
                    // آخر 12 شهراً
                    val now = java.time.LocalDate.now()
                    val months = (11 downTo 0).map { now.minusMonths(it.toLong()).withDayOfMonth(1) }
                    val mArr = JSONArray(months.map { m ->
                        val a = m.toEpochDay(); val b = m.plusMonths(1).toEpochDay() - 1
                        val ms = Shop.stats(rows, items, a..b)
                        JSONObject().put("m", "%02d/%d".format(m.monthValue, m.year)).put("sales", ms.net).put("purchases", ms.purchases).put("profit", ms.profit)
                    })
                    val top = Shop.topItems(rows, items, range).take(10)
                    val parties = dao.allPartys(); val txs = dao.allPartyTxs()
                    val custs = parties.filter { it.type == Parties.CUSTOMER }.map { Parties.account(it, invs, items, pays, txs, range) }
                    val prods = dao.allProducts(); val stock = Shop.stockMap(prods, invs, items, dao.allStockAdjs())
                    val methods = pays.filter { p -> invs.firstOrNull { it.id == p.invoiceId }?.let { Shop.isIncoming(it.type) && (range == null || it.date in range) } == true }.groupBy { it.method }
                    json(out, JSONObject().put("sales", st.sales).put("returns", st.returns).put("net", st.net).put("profit", st.profit).put("cost", st.cost).put("tax", st.tax)
                        .put("purchases", st.purchases).put("collected", st.collected).put("count", st.count).put("avg", if (st.count > 0) st.net / st.count else 0.0)
                        .put("customersOwe", custs.sumOf { it.balance.coerceAtLeast(0.0) })
                        .put("oweSuppliers", parties.filter { it.type == Parties.SUPPLIER }.sumOf { Parties.account(it, invs, items, pays, txs).balance.coerceAtLeast(0.0) })
                        .put("stockValue", prods.filter { it.trackStock }.sumOf { (stock[it.id] ?: 0.0).coerceAtLeast(0.0) * it.cost })
                        .put("months", mArr)
                        .put("top", JSONArray(top.map { JSONObject().put("name", it.name).put("qty", it.qty).put("amount", it.amount).put("profit", it.profit) }))
                        .put("topCustomers", JSONArray(custs.sortedByDescending { it.sales }.take(8).map { JSONObject().put("name", it.p.name).put("sales", it.sales).put("balance", it.balance) }))
                        .put("low", JSONArray(prods.filter { !Manufacture.isRaw(it) && Shop.isLow(it, stock[it.id] ?: 0.0) }.take(30).map { JSONObject().put("name", it.name).put("stock", stock[it.id] ?: 0.0).put("min", it.minQty) }))
                        .put("methods", JSONArray(methods.map { (k, l) -> JSONObject().put("m", Shop.method(k).label).put("amount", l.sumOf { it.amount }) })))
                }
                "/api/report.xlsx" -> {
                    val invs = dao.allInvoices(); val items = dao.allInvoiceItems(); val pays = dao.allInvoicePayments()
                    val rows = Shop.rows(invs, items, pays)
                    val now = java.time.LocalDate.now()
                    val f = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "report.xlsx")
                    fun c(v: Any?, st: Int = 0) = Xlsx.Cell(v, st)
                    val monthRows = mutableListOf(listOf(c(tr("الشهر", "Month"), 1), c(tr("صافي المبيعات", "Net sales"), 1), c(tr("المشتريات", "Purchases"), 1), c(tr("مجمل الربح", "Gross profit"), 1)))
                    (11 downTo 0).forEach { k -> val m = now.minusMonths(k.toLong()).withDayOfMonth(1); val ms = Shop.stats(rows, items, m.toEpochDay()..(m.plusMonths(1).toEpochDay() - 1))
                        monthRows += listOf(c("%02d/%d".format(m.monthValue, m.year)), c(ms.net), c(ms.purchases), c(ms.profit)) }
                    val invRows = mutableListOf(listOf(c(tr("الرقم", "No."), 1), c(tr("النوع", "Type"), 1), c(tr("التاريخ", "Date"), 1), c(tr("الطرف", "Party"), 1), c(tr("الإجمالي", "Total"), 1), c(tr("المدفوع", "Paid"), 1), c(tr("المتبقي", "Remaining"), 1)))
                    rows.forEach { x -> invRows += listOf(c(Shop.numberText(x.inv)), c(Shop.type(x.inv.type).label), c(java.time.LocalDate.ofEpochDay(x.inv.date).toString()), c(x.inv.partyName), c(x.t.total), c(x.paid), c(x.remaining)) }
                    val topRows = mutableListOf(listOf(c(tr("الصنف", "Item"), 1), c(tr("الكمية", "Qty"), 1), c(tr("المبيعات", "Sales"), 1), c(tr("الربح", "Profit"), 1)))
                    Shop.topItems(rows, items, null).take(50).forEach { t -> topRows += listOf(c(t.name), c(t.qty), c(t.amount), c(t.profit)) }
                    Xlsx.write(f, listOf(Xlsx.Sheet(tr("شهري", "Monthly"), monthRows), Xlsx.Sheet(tr("الفواتير", "Invoices"), invRows), Xlsx.Sheet(tr("الأكثر مبيعاً", "Top items"), topRows)))
                    xlsxOut(out, f, "report.xlsx")
                }
                "/api/parties" -> {
                    val type = r.query["type"] ?: (if (r.query["c"] == "0") Parties.SUPPLIER else Parties.CUSTOMER)
                    val invs = dao.allInvoices(); val items = dao.allInvoiceItems(); val pays = dao.allInvoicePayments(); val txs = dao.allPartyTxs()
                    json(out, JSONArray(dao.allPartys().filter { it.type == type }.map { p ->
                        val a = Parties.account(p, invs, items, pays, txs)
                        JSONObject().put("id", p.id).put("code", p.code).put("name", p.name).put("phone", p.phone).put("address", p.address).put("taxNo", p.taxNo)
                            .put("opening", p.opening).put("limit", p.creditLimit).put("active", p.active).put("notes", p.notes)
                            .put("sales", a.sales).put("paid", a.paid).put("balance", a.balance).put("count", a.rows.size)
                    }))
                }
                "/api/party" -> {
                    val j = JSONObject(String(r.body, Charsets.UTF_8))
                    val type = j.optString("type", Parties.CUSTOMER)
                    val id = j.optLong("id", 0)
                    val old = if (id > 0) dao.allPartys().firstOrNull { it.id == id } else null
                    val p = (old ?: com.sho3eb.app.data.Party(name = "", type = type, code = Parties.nextCode(dao, type))).copy(name = j.optString("name").trim(), phone = j.optString("phone").trim(),
                        address = j.optString("address"), taxNo = j.optString("taxNo"), opening = j.optDouble("opening", old?.opening ?: 0.0), creditLimit = j.optDouble("limit", 0.0),
                        active = j.optBoolean("active", true), notes = j.optString("notes"))
                    if (p.name.isBlank()) { send(out, 400, "application/json", "{\"error\":\"name\"}".toByteArray()); return@runBlocking }
                    val nid = if (old == null) dao.insertParty(p) else { dao.updateParty(p); old.id }
                    json(out, JSONObject().put("id", nid))
                }
                "/api/import" -> {
                    val what = r.query["what"] ?: "items"
                    val rows = ItemImport.parse(r.query["name"] ?: "file.xlsx", r.body)
                    if (rows.isEmpty()) { send(out, 400, "application/json", "{\"error\":\"empty\"}".toByteArray()); return@runBlocking }
                    val update = r.query["update"] != "0"
                    val res = if (what == "items") {
                        var map: Map<String, Int> = ItemImport.autoMap(rows.first()); var header = true
                        if (map["name"] == null) { map = mapOf("name" to 0, "price" to 1); header = false }
                        ItemImport.import(dao, rows, map, header, r.query["kind"] ?: "SALE", r.query["source"] ?: "FILE", r.query["party"] ?: "", update, r.query["cat"] ?: "")
                    } else {
                        var map: Map<String, Int> = ItemImport.autoMapParty(rows.first()); var header = true
                        if (map["name"] == null) { map = mapOf("name" to 0, "phone" to 1); header = false }
                        ItemImport.importParties(dao, rows, map, header, if (what == "suppliers") Parties.SUPPLIER else Parties.CUSTOMER, update)
                    }
                    json(out, JSONObject().put("added", res.added).put("updated", res.updated).put("skipped", res.skipped))
                }
                "/api/template" -> {
                    val what = r.query["what"] ?: "items"
                    val f = if (what == "items") ItemImport.template(ctx) else ItemImport.partyTemplate(ctx, if (what == "suppliers") Parties.SUPPLIER else Parties.CUSTOMER)
                    xlsxOut(out, f, f.name)
                }
                "/api/pricelist.xlsx" -> {
                    val o = PriceList.savedOpts()
                    xlsxOut(out, PriceList.excel(ctx, PriceList.items(dao.allProducts(), o), o), "price_list.xlsx")
                }
                "/api/products" -> {
                    val prods = dao.allProducts(); val invs = dao.allInvoices(); val items = dao.allInvoiceItems()
                    val stock = Shop.stockMap(prods, invs, items, dao.allStockAdjs())
                    json(out, JSONArray(prods.map { p ->
                        JSONObject().put("id", p.id).put("name", p.name).put("sku", p.sku).put("category", if (Manufacture.isRaw(p)) "" else p.category).put("raw", Manufacture.isRaw(p))
                            .put("unit", p.unit).put("cost", p.cost).put("price", p.price).put("stock", stock[p.id] ?: 0.0).put("min", p.minQty).put("track", p.trackStock)
                            .put("active", p.active).put("notes", p.notes).put("img", ProductImages.get(p.id) != null)
                    }))
                }
                "/api/product" -> {
                    val j = JSONObject(String(r.body, Charsets.UTF_8))
                    val id = j.optLong("id", 0)
                    val old = if (id > 0) dao.allProducts().firstOrNull { it.id == id } else null
                    val p = (old ?: Product(name = "")).copy(name = j.optString("name").trim(), sku = j.optString("sku"), unit = j.optString("unit"),
                        category = if (j.optBoolean("raw")) Manufacture.RAW_CAT else j.optString("category"), cost = j.optDouble("cost", 0.0), price = j.optDouble("price", 0.0),
                        minQty = j.optDouble("min", 0.0), trackStock = j.optBoolean("track", true), active = j.optBoolean("active", true), notes = j.optString("notes"),
                        openingQty = if (old == null) j.optDouble("qty", 0.0) else old.openingQty)
                    if (p.name.isBlank()) { send(out, 400, "application/json", "{\"error\":\"name\"}".toByteArray()); return@runBlocking }
                    val nid = if (old == null) dao.insertProduct(p) else { dao.updateProduct(p); old.id }
                    json(out, JSONObject().put("id", nid))
                }
                "/api/product/delete" -> { val id = JSONObject(String(r.body)).optLong("id"); ProductImages.set(id, null); dao.deleteProductFull(id); json(out, JSONObject().put("ok", true)) }
                "/api/img" -> {
                    val id = r.query["id"]?.toLongOrNull() ?: 0
                    if (r.method == "POST" && r.body.isNotEmpty()) {
                        val dir = File(ctx.filesDir, "photos").apply { mkdirs() }
                        val f = File(dir, "prod_${id}_${System.currentTimeMillis()}.jpg")
                        val b = android.graphics.BitmapFactory.decodeByteArray(r.body, 0, r.body.size)
                        if (b == null) { send(out, 400, "application/json", "{}".toByteArray()); return@runBlocking }
                        val k2 = minOf(1f, 720f / maxOf(b.width, b.height))
                        val sb = android.graphics.Bitmap.createScaledBitmap(b, (b.width * k2).toInt().coerceAtLeast(1), (b.height * k2).toInt().coerceAtLeast(1), true)
                        f.outputStream().use { sb.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }
                        ProductImages.set(id, f.absolutePath)
                        json(out, JSONObject().put("ok", true))
                    } else {
                        val p = ProductImages.get(id)
                        if (p == null) send(out, 404, "text/plain", ByteArray(0)) else send(out, 200, "image/jpeg", File(p).readBytes(), "Cache-Control: max-age=3600\r\n")
                    }
                }
                "/api/invoices" -> {
                    val invs = dao.allInvoices(); val items = dao.allInvoiceItems(); val pays = dao.allInvoicePayments()
                    val byInv = items.groupBy { it.invoiceId }
                    json(out, JSONArray(Shop.rows(invs, items, pays).take(r.query["limit"]?.toIntOrNull() ?: 1000).map { row ->
                        JSONObject().put("id", row.inv.id).put("no", Shop.numberText(row.inv)).put("type", row.inv.type).put("typeName", Shop.type(row.inv.type).label)
                            .put("date", row.inv.date).put("party", row.inv.partyName).put("phone", row.inv.partyPhone).put("total", row.t.total).put("paid", row.paid).put("remaining", row.remaining)
                            .put("partyId", row.inv.partyId ?: 0).put("discount", row.inv.discount)
                            .put("items", JSONArray(byInv[row.inv.id].orEmpty().map { JSONObject().put("name", it.name).put("qty", it.qty).put("price", it.price) }))
                    }))
                }
                "/api/invoice" -> {
                    val j = JSONObject(String(r.body, Charsets.UTF_8))
                    val arr = j.optJSONArray("items") ?: JSONArray()
                    val lines = (0 until arr.length()).map { arr.getJSONObject(it) }.map { x -> Pos.Line(x.optLong("productId", 0).takeIf { it > 0 }, x.optString("name"), x.optDouble("qty", 1.0), x.optDouble("price", 0.0)) }
                    val names = dao.allProducts().associateBy { it.id }
                    val fixed = lines.map { l -> if (l.name.isBlank() && l.productId != null) l.copy(name = names[l.productId]?.name ?: "") else l }
                    val id = runCatching { Pos.save(dao, j.optString("type", Shop.SALE), fixed, j.optLong("partyId", 0).takeIf { it > 0 }, j.optString("party"), j.optString("phone"),
                        j.optDouble("discount", 0.0), j.optDouble("taxPct", 0.0), j.optDouble("paid", 0.0), j.optString("method", "CASH"), j.optString("notes"),
                        j.optLong("date", 0).takeIf { it > 0 } ?: Fmt.today()) }.getOrNull()
                    if (id == null) send(out, 400, "application/json", "{\"error\":\"items\"}".toByteArray()) else json(out, JSONObject().put("id", id))
                }
                "/api/brand" -> json(out, JSONObject().put("name", Brand.name.ifBlank { Edition.appName }).put("subtitle", Brand.subtitle).put("phone", Brand.phone).put("address", Brand.address)
                    .put("email", Brand.email).put("website", Brand.website).put("taxNo", Brand.taxNo).put("logo", Brand.logo(ctx).exists()).put("rtl", AppState.isRtl)
                    .put("currency", Fmt.money(0.0).replace(Regex("[0-9.,٠-٩\\s]"), "")).put("today", Fmt.today()))
                "/logo" -> { val f = Brand.logo(ctx); if (f.exists()) send(out, 200, "image/png", f.readBytes(), "Cache-Control: max-age=600\r\n") else send(out, 404, "text/plain", ByteArray(0)) }
                "/api/pricelist.pdf" -> {
                    val opts = PriceList.savedOpts()
                    val f = PriceList.pdf(ctx, PriceList.items(dao.allProducts(), opts), opts)
                    send(out, 200, "application/pdf", f.readBytes(), "Content-Disposition: inline; filename=\"price_list.pdf\"\r\n")
                }
                else -> send(out, 404, "text/plain", "not found".toByteArray())
            }
        }
    }
}
