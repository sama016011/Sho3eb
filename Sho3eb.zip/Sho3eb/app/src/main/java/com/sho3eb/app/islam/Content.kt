package com.sho3eb.app.islam

import android.content.Context

/** عنصر محتوى (ذكر / حديث / حكم / قصة / غزوة / رقية) */
data class CItem(val title: String, val meta: Map<String, String>, val body: String) {
    fun m(k: String): String? = meta[k]?.takeIf { it.isNotBlank() }
    val count: Int get() = m("count")?.toIntOrNull() ?: 1
}

data class CGroup(val title: String, val icon: String, val items: List<CItem>)

/**
 * قارئ ملفات المحتوى في assets/islam بالصيغة:
 * ## عنوان مجموعة | أيقونة
 * ### عنوان عنصر
 * @مفتاح: قيمة
 * نص...
 */
object Content {
    const val AZKAR = "azkar"
    const val HADITH = "hadith"
    const val RULINGS = "rulings"
    const val PROPHETS = "prophets"
    const val BATTLES = "battles"
    const val RUQYAH = "ruqyah"

    private val cache = HashMap<String, List<CGroup>>()

    fun load(ctx: Context, name: String): List<CGroup> {
        cache[name]?.let { return it }
        val text = try {
            ctx.assets.open("islam/$name.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            ""
        }
        val groups = parse(text)
        cache[name] = groups
        return groups
    }

    fun parse(text: String): List<CGroup> {
        val groups = mutableListOf<CGroup>()
        var gTitle: String? = null
        var gIcon = ""
        var items = mutableListOf<CItem>()
        var iTitle: String? = null
        var meta = LinkedHashMap<String, String>()
        val body = StringBuilder()

        fun flushItem() {
            val t = iTitle ?: return
            items += CItem(t, meta, body.toString().trim())
            iTitle = null
            meta = LinkedHashMap()
            body.clear()
        }

        fun flushGroup() {
            flushItem()
            if (gTitle != null || items.isNotEmpty()) groups += CGroup(gTitle ?: "", gIcon, items)
            items = mutableListOf()
        }

        text.lines().forEach { raw ->
            val line = raw.trimEnd()
            when {
                line.startsWith("## ") -> {
                    flushGroup()
                    val p = line.removePrefix("## ").split("|")
                    gTitle = p[0].trim()
                    gIcon = p.getOrNull(1)?.trim() ?: ""
                }
                line.startsWith("### ") -> {
                    flushItem(); iTitle = line.removePrefix("### ").trim()
                }
                line.startsWith("@") && line.contains(":") && iTitle != null && body.isEmpty() -> {
                    val k = line.substring(1, line.indexOf(':')).trim()
                    meta[k] = line.substring(line.indexOf(':') + 1).trim()
                }
                line.startsWith("//") -> {}
                else -> if (iTitle != null) body.append(raw).append('\n')
            }
        }
        flushGroup()
        return groups.filter { it.items.isNotEmpty() }
    }

    fun allItems(ctx: Context, name: String): List<Pair<CGroup, CItem>> =
        load(ctx, name).flatMap { g -> g.items.map { g to it } }

    fun randomHadith(ctx: Context): Pair<String, String>? {
        val all = allItems(ctx, HADITH)
        if (all.isEmpty()) return null
        val item = all.random().second
        return item.body to (item.m("src") ?: "")
    }
}
