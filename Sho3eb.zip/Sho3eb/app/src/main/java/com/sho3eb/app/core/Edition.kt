package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.sho3eb.app.Sho3ebApp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * نسخة المالك ونسخة المشاركة.
 * - نسخة المالك (الافتراضية): كل الأقسام + تعديل بيانات التواصل + استوديو النسخة.
 * - نسخة المشاركة: تُبنى بملف edition/edition.json، تعرض الأقسام المختارة فقط
 *   مع الاسم والأيقونة والوصف، وبيانات التواصل للعرض فقط.
 */
object Edition {
    data class Contact(
        val name: String = "", val phone: String = "", val whatsapp: String = "", val email: String = "", val website: String = "",
        val facebook: String = "", val telegram: String = "", val address: String = "", val buyUrl: String = "", val buyNote: String = "",
        val storeUrl: String = "", val price: String = ""
    ) {
        fun toJson() = JSONObject().put("name", name).put("phone", phone).put("whatsapp", whatsapp).put("email", email).put("website", website)
            .put("facebook", facebook).put("telegram", telegram).put("address", address).put("buyUrl", buyUrl).put("buyNote", buyNote)
            .put("storeUrl", storeUrl).put("price", price)
        companion object {
            fun from(o: JSONObject?) = if (o == null) Contact() else Contact(
                o.optString("name"), o.optString("phone"), o.optString("whatsapp"), o.optString("email"), o.optString("website"),
                o.optString("facebook"), o.optString("telegram"), o.optString("address"), o.optString("buyUrl"), o.optString("buyNote"),
                o.optString("storeUrl"), o.optString("price")
            )
        }
    }

    /** الأقسام القابلة للاختيار في نسخة المشاركة: (المعرف، الاسم، المسار) */
    data class Feature(val id: String, val ar: String, val en: String, val emoji: String, val routes: List<String>) { val label get() = tr(ar, en) }

    val features: List<Feature> by lazy {
        HomeLayout.shortcuts.filter { it.id != "settings" }.map { Feature(it.id, it.ar, it.en, it.emoji, listOf(it.route) + extraRoutes(it.id)) } +
            listOf(Feature("islam", "إسلاميات", "Islamic", "🕌", listOf("islam", "quran", "azkar", "prayer", "qibla", "tasbeeh")))
    }

    private fun extraRoutes(id: String): List<String> = when (id) {
        "football" -> listOf("match", "team")
        "media" -> listOf("player", "web")
        "assocs" -> listOf("assoc", "assoc_new")
        "loans" -> listOf("loans_new", "loan")
        "sales" -> listOf("sale", "sale_new")
        "shop" -> listOf("shop_inv", "shop_party", "shop_side", "shop_accounts", "manufacture", "manufacture_bom")
        "recipes" -> listOf("recipe")
        "design" -> listOf("design")
        "grocery" -> listOf("credit")
        "learn" -> listOf("translate", "course", "lesson", "roleplay")
        "alarms" -> listOf("alarm_edit")
        "chat" -> listOf("chat_setup", "chat_friends", "chat_share", "chat_group", "chat_group_edit")
        else -> emptyList()
    }

    // ---------- بيانات النسخة المضمنة ----------
    /** من ملف assets (نسخة GitHub) أو من داخل ملف APK نفسه (النسخة المباشرة) */
    private val embedded: JSONObject? by lazy {
        runCatching { Sho3ebApp.instance.assets.open("edition.json").use { JSONObject(it.readBytes().toString(Charsets.UTF_8)) } }.getOrNull()
            ?: runCatching { ApkEdition.read(File(Sho3ebApp.instance.applicationInfo.sourceDir))?.let { JSONObject(it) } }.getOrNull()
    }
    fun embeddedString(k: String): String = embedded?.optString(k).orEmpty()

    /** نسخة مباشرة (داخل APK) وليست مبنية عبر GitHub */
    val isDirect: Boolean get() = embedded != null && runCatching { Sho3ebApp.instance.assets.open("edition.json").close(); false }.getOrDefault(true)
    private val unlocked: Boolean get() = Extras.b("ed_unlocked", false)
    val isShared: Boolean get() = embedded?.optBoolean("shared", true) == true && !unlocked
    val isOwner: Boolean get() = !isShared
    /** يمكن فتح وضع المالك على هذا الجهاز بكلمة مرور المالك المضمنة */
    val canUnlock: Boolean get() = isShared && embedded?.optString("pw").orEmpty().isNotBlank()
    fun unlock(p: String): Boolean {
        val h = embedded?.optString("pw").orEmpty()
        if (h.isBlank() || hash(p) != h) return false
        Extras.pb("ed_unlocked", true); return true
    }
    fun relock() = Extras.pb("ed_unlocked", false)
    val isUnlockedCopy: Boolean get() = embedded != null && unlocked

    /** أيقونة النسخة داخل التطبيق */
    val iconBitmap: Bitmap? by lazy {
        if (!isShared) null
        else runCatching { Sho3ebApp.instance.assets.open("icon.png").use { BitmapFactory.decodeStream(it) } }.getOrNull()
            ?: embedded?.optString("icon")?.takeIf { it.isNotBlank() }?.let { runCatching { val b = android.util.Base64.decode(it, android.util.Base64.DEFAULT); BitmapFactory.decodeByteArray(b, 0, b.size) }.getOrNull() }
    }

    val appName: String get() = if (isShared) embedded?.optString("name")?.takeIf { it.isNotBlank() } ?: "Sho3eb" else "Sho3eb"
    val description: String get() = if (isShared) embedded?.optString("description").orEmpty() else Extras.s("ed_desc", "")
    val packageForStore: String get() = Sho3ebApp.instance.packageName

    private val allowed: Set<String>? by lazy {
        if (!isShared) null else embedded?.optJSONArray("sections")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() }?.takeIf { it.isNotEmpty() }
    }

    fun allows(featureId: String): Boolean = allowed?.contains(featureId) ?: true

    /** هل المسار مسموح في هذه النسخة؟ */
    fun allowsRoute(route: String?): Boolean {
        val a = allowed ?: return true
        if (route == null) return true
        val base = route.substringBefore("/").substringBefore("?")
        val f = features.firstOrNull { base in it.routes } ?: return true
        return f.id in a
    }

    // ---------- بيانات التواصل ----------
    var ownerContact: Contact
        get() = Contact.from(runCatching { JSONObject(Extras.s("ed_contact", "{}")) }.getOrNull())
        set(v) = Extras.ps("ed_contact", v.toJson().toString())

    val contact: Contact get() = if (isShared) Contact.from(embedded?.optJSONObject("contact")) else ownerContact
    val canEditContact: Boolean get() = isOwner

    // ---------- كلمة مرور المالك ----------
    private fun hash(s: String) = MessageDigest.getInstance("SHA-256").digest(("sho3eb#" + s).toByteArray()).joinToString("") { "%02x".format(it) }
    val hasOwnerPassword: Boolean get() = Extras.s("ed_pw", "").isNotBlank()
    fun setOwnerPassword(p: String) = Extras.ps("ed_pw", if (p.isBlank()) "" else hash(p))
    fun checkOwnerPassword(p: String) = !hasOwnerPassword || hash(p) == Extras.s("ed_pw", "")

    // ---------- إعداد نسخة المشاركة (عند المالك) ----------
    var edName: String get() = Extras.s("ed_name", ""); set(v) = Extras.ps("ed_name", v)
    var edDesc: String get() = Extras.s("ed_desc", ""); set(v) = Extras.ps("ed_desc", v)
    var edSuffix: String get() = Extras.s("ed_suffix", "shared"); set(v) = Extras.ps("ed_suffix", v)
    var edSections: Set<String>
        get() = Extras.s("ed_secs", "").split(",").filter { it.isNotBlank() }.toSet()
        set(v) = Extras.ps("ed_secs", v.joinToString(","))
    fun edIcon(ctx: Context) = File(ctx.filesDir, "edition_icon.png")

    fun saveIcon(ctx: Context, uri: Uri): Boolean = runCatching {
        val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return false
        val s = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
        val b = Bitmap.createScaledBitmap(sq, 512, 512, true)
        edIcon(ctx).outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    }.getOrDefault(false)

    /** إنشاء نسخة مشاركة مباشرة: نسخة من ملف التطبيق تحمل إعدادات النسخة داخلها */
    fun buildDirect(ctx: Context, onProgress: (Int) -> Unit): File {
        val j = editionJson()
        j.put("pw", Extras.s("ed_pw", ""))
        val ic = edIcon(ctx)
        if (ic.exists()) runCatching {
            val b = BitmapFactory.decodeFile(ic.path)
            val small = Bitmap.createScaledBitmap(b, 256, 256, true)
            val bos = java.io.ByteArrayOutputStream(); small.compress(Bitmap.CompressFormat.PNG, 100, bos)
            j.put("icon", android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP))
        }
        val dir = File(ctx.cacheDir, "apk").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val name = edName.ifBlank { "Sho3eb" }.filter { it.isLetterOrDigit() || it == ' ' }.trim().replace(' ', '_').ifBlank { "Sho3eb" }
        val out = File(dir, "$name.apk")
        ApkEdition.write(File(ctx.applicationInfo.sourceDir), out, j.toString(), onProgress)
        // تحقق: قراءة الإعدادات من الملف الناتج
        require(ApkEdition.read(out) != null) { "verify failed" }
        return out
    }

    fun shareFile(ctx: Context, f: File) {
        val uri = Share.uriFor(ctx, f)
        val i = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive").putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_TEXT, appName + (if (edDesc.isNotBlank()) "\n" + edDesc else ""))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, tr("إرسال نسخة المشاركة", "Send shared edition")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun editionJson(): JSONObject = JSONObject()
        .put("shared", true)
        .put("name", edName.ifBlank { "Sho3eb" })
        .put("description", edDesc)
        .put("idSuffix", edSuffix.lowercase().filter { it.isLetterOrDigit() }.ifBlank { "shared" }.let { if (it.first().isDigit()) "e$it" else it })
        .put("sections", JSONArray(edSections.toList()))
        .put("contact", ownerContact.toJson())
        .put("bottom_tabs", com.sho3eb.app.ui.BottomTabs.order.joinToString(","))
        .put("supa_url", com.sho3eb.app.core.chat.Supa.url).put("supa_key", com.sho3eb.app.core.chat.Supa.key)
        .put("supa_bucket", com.sho3eb.app.core.chat.Supa.bucket).put("supa_backup_bucket", com.sho3eb.app.core.chat.Supa.backupBucket)
        .put("supa_verify_phone", if (com.sho3eb.app.core.chat.Supa.verifyPhone) "1" else "0").put("supa_otp_channel", com.sho3eb.app.core.chat.Supa.otpChannel)
        .put("chat_turn", com.sho3eb.app.core.chat.Chat.turnUrl).put("chat_turn_u", com.sho3eb.app.core.chat.Chat.turnUser).put("chat_turn_p", com.sho3eb.app.core.chat.Chat.turnPass)

    /** تصدير حزمة النسخة: ملف zip يحوي edition/edition.json و edition/icon.png */
    fun exportPack(ctx: Context): File {
        val out = File(ctx.cacheDir, "edition_pack.zip")
        ZipOutputStream(out.outputStream()).use { z ->
            z.putNextEntry(ZipEntry("edition/edition.json")); z.write(editionJson().toString(2).toByteArray()); z.closeEntry()
            val ic = edIcon(ctx)
            if (ic.exists()) { z.putNextEntry(ZipEntry("edition/icon.png")); ic.inputStream().use { it.copyTo(z) }; z.closeEntry() }
            z.putNextEntry(ZipEntry("edition/README.txt"))
            z.write(("ضع مجلد edition كما هو في جذر المستودع (بجوار مجلد app) ثم ارفع التغييرات.\n" +
                "سيبني GitHub Actions نسختين: Sho3eb-owner.apk (نسختك الكاملة) و Sho3eb-shared.apk (نسخة المشاركة).\n\n" +
                "Put the edition folder in the repository root (next to app/) and push.\n" +
                "GitHub Actions will build Sho3eb-owner.apk and Sho3eb-shared.apk.").toByteArray())
            z.closeEntry()
        }
        return out
    }

    // ---------- إجراءات ----------
    fun storeLink(): String = contact.storeUrl.ifBlank { "https://play.google.com/store/apps/details?id=$packageForStore" }

    fun rate(ctx: Context) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageForStore")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { if (contact.storeUrl.isNotBlank()) error("custom") else ctx.startActivity(market) }
            .onFailure { open(ctx, storeLink()) }
        Extras.pb("ed_rated", true)
    }

    fun open(ctx: Context, url: String) {
        if (url.isBlank()) return
        val u = if (url.startsWith("http") || url.contains(":")) url else "https://$url"
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast(ctx, tr("لا يوجد تطبيق لفتح الرابط", "No app to open the link")) }
    }

    fun call(ctx: Context, phone: String) = runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun whatsapp(ctx: Context, phone: String, msg: String = "") = open(ctx, "https://wa.me/" + Share.waNumber(phone) + if (msg.isNotBlank()) "?text=" + Uri.encode(msg) else "")
    fun mail(ctx: Context, email: String, subject: String) = runCatching {
        ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).putExtra(Intent.EXTRA_SUBJECT, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** مشاركة رابط التطبيق نصاً */
    fun shareLink(ctx: Context) {
        val text = tr("جرّب تطبيق ", "Try ") + appName + (if (description.isNotBlank()) "\n$description" else "") + "\n" + storeLink()
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(i, tr("مشاركة التطبيق", "Share app")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** مشاركة ملف التطبيق APK نفسه (بلوتوث، واتساب، ...) */
    fun shareApk(ctx: Context): Boolean = runCatching {
        val src = File(ctx.applicationInfo.sourceDir)
        val dir = File(ctx.cacheDir, "apk").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val dst = File(dir, appName.filter { it.isLetterOrDigit() || it == ' ' }.trim().ifBlank { "Sho3eb" }.replace(' ', '_') + ".apk")
        src.copyTo(dst, overwrite = true)
        val uri = Share.uriFor(ctx, dst)
        val i = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, tr("إرسال ملف التطبيق", "Send app file")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    }.getOrDefault(false)

    /** طلب التقييم بعد عدد من مرات الفتح */
    fun shouldAskRating(): Boolean {
        if (Extras.b("ed_rated", false) || Extras.b("ed_rate_never", false)) return false
        val n = Extras.i("ed_opens", 0) + 1
        Extras.pi("ed_opens", n)
        return n == 8 || n == 25 || n == 60
    }
}
