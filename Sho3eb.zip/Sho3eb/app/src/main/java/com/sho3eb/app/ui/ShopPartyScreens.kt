@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import kotlinx.coroutines.flow.map
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

// =====================================================================
//                     أداة اختيار الفترة (مشتركة)
// =====================================================================
@Composable
fun PeriodPicker(state: MutableState<Int>, from: MutableState<Long>, to: MutableState<Long>) {
    HChips {
        listOf(tr("اليوم", "Today"), tr("هذا الشهر", "This month"), tr("الشهر الماضي", "Last month"), tr("هذه السنة", "This year"), tr("الكل", "All"), tr("فترة مخصصة", "Custom")).forEachIndexed { i, t ->
            FilterChip(state.value == i, { state.value = i }, label = { Text(t) })
        }
    }
    if (state.value == 5) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DateField(tr("من", "From"), from.value, { d -> if (d != null) from.value = d }, modifier = Modifier.weight(1f))
        DateField(tr("إلى", "To"), to.value, { d -> if (d != null) to.value = d }, modifier = Modifier.weight(1f))
    }
}

fun periodRange(i: Int, from: Long, to: Long): LongRange? {
    val now = LocalDate.now()
    return when (i) {
        0 -> Fmt.today()..Fmt.today()
        1 -> LivingAuto.monthRange()
        2 -> now.minusMonths(1).withDayOfMonth(1).let { it.toEpochDay()..it.withDayOfMonth(it.lengthOfMonth()).toEpochDay() }
        3 -> now.withDayOfYear(1).toEpochDay()..now.withDayOfYear(now.lengthOfYear()).toEpochDay()
        5 -> minOf(from, to)..maxOf(from, to)
        else -> null
    }
}

@Composable
fun rememberPeriod(default: Int = 1): Triple<MutableState<Int>, MutableState<Long>, MutableState<Long>> {
    val s = rememberSaveable { mutableStateOf(default) }
    val f = rememberSaveable { mutableStateOf(LocalDate.now().withDayOfMonth(1).toEpochDay()) }
    val t = rememberSaveable { mutableStateOf(Fmt.today()) }
    return Triple(s, f, t)
}

/** كل بيانات المحل في مكان واحد */
class ShopData(
    val invs: List<Invoice>, val items: List<InvoiceItem>, val pays: List<InvoicePayment>,
    val parties: List<Party>, val txs: List<PartyTx>, val products: List<Product>, val adjs: List<StockAdj>
) {
    val rows by lazy { Shop.rows(invs, items, pays) }
    fun statement(p: Party, range: LongRange? = null) = Parties.account(p, invs, items, pays, txs, range)
}

@Composable
fun rememberShopData(): ShopData {
    val dao = remember { appDao() }
    val invs by flowState(emptyList<Invoice>()) { dao.invoicesFlow() }
    val items by flowState(emptyList<InvoiceItem>()) { dao.invoiceItemsFlow() }
    val pays by flowState(emptyList<InvoicePayment>()) { dao.invoicePaymentsFlow() }
    val parties by flowState(emptyList<Party>()) { dao.partysFlow() }
    val txs by flowState(emptyList<PartyTx>()) { dao.partyTxsFlow() }
    val products by flowState(emptyList<Product>()) { dao.productsFlow().map { l -> l.filter { !Manufacture.isRaw(it) } } }
    val adjs by flowState(emptyList<StockAdj>()) { dao.stockAdjsFlow() }
    LaunchedEffect(invs.size) { if (invs.any { it.partyId == null && it.partyName.isNotBlank() }) Parties.sync(dao) }
    return remember(invs, items, pays, parties, txs, products, adjs) { ShopData(invs, items, pays, parties, txs, products, adjs) }
}

// =====================================================================
//              قسم المبيعات / قسم المشتريات
// =====================================================================
@Composable
fun ShopSideScreen(nav: NavController, side: String) {
    val d = rememberShopData()
    val sales = side == Parties.CUSTOMER
    val main = Parties.mainType(side); val ret = Parties.returnType(side)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var q by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("ALL") }
    var newMenu by remember { mutableStateOf(false) }
    var addParty by remember { mutableStateOf(false) }
    val (ps, pf, pt) = rememberPeriod(1)
    val range = periodRange(ps.value, pf.value, pt.value)
    var prodFilter by rememberSaveable { mutableStateOf<Long?>(null) }
    var partyFilter by rememberSaveable { mutableStateOf<Long?>(null) }
    var pickProd by remember { mutableStateOf(false) }
    var pickParty by remember { mutableStateOf(false) }

    val myParties = d.parties.filter { it.type == side }
    val statements = remember(d) { myParties.map { d.statement(it) } }
    val sideRows = d.rows.filter { it.inv.type == main || it.inv.type == ret }
    val sums = remember(d, range, prodFilter, partyFilter) { StockReports.bySide(side, d.invs, d.items, range, prodFilter, partyFilter) }
    val months = remember(d, range) { StockReports.byMonth(side, sideRows, range) }
    val reportDoc = { Docs.sideReport(side, sums, months, range, prodFilter?.let { id -> d.products.firstOrNull { it.id == id }?.name }, partyFilter?.let { id -> d.parties.firstOrNull { it.id == id }?.name }) }

    ScreenScaffold(
        title = if (sales) tr("المبيعات", "Sales") else tr("المشتريات", "Purchases"), onBack = { nav.popBackStack() },
        actions = {
            when (tab) {
                1 -> PdfShareButton(null, doc = { Docs.partiesAging(side, statements) }) { c -> Reports.doc(c, Docs.partiesAging(side, statements)) }
                2 -> PdfShareButton(null, doc = reportDoc) { c -> Reports.doc(c, reportDoc()) }
                else -> {}
            }
        },
        fab = {
            when (tab) {
                0 -> Box {
                    ExtendedFloatingActionButton(onClick = { newMenu = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("فاتورة", "Invoice")) })
                    DropdownMenu(newMenu, { newMenu = false }) {
                        DropdownMenuItem(text = { Text(Shop.type(main).emoji + "  " + Shop.type(main).label) }, onClick = { newMenu = false; nav.navigate("invoice_edit/$main/0") })
                        DropdownMenuItem(text = { Text(Shop.type(ret).emoji + "  " + Shop.type(ret).label) }, onClick = { newMenu = false; nav.navigate("invoice_edit/$ret/0") })
                        if (sales) DropdownMenuItem(text = { Text(Shop.type(Shop.QUOTE).emoji + "  " + Shop.type(Shop.QUOTE).label) }, onClick = { newMenu = false; nav.navigate("invoice_edit/${Shop.QUOTE}/0") })
                    }
                }
                1 -> ExtendedFloatingActionButton(onClick = { addParty = true }, icon = { Icon(Icons.Filled.PersonAdd, null) }, text = { Text(if (sales) tr("عميل", "Customer") else tr("مورد", "Supplier")) })
                else -> {}
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("الفواتير", "Invoices")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(if (sales) tr("العملاء", "Customers") else tr("الموردون", "Suppliers")) })
                Tab(tab == 2, { tab = 2 }, text = { Text(tr("التقارير", "Reports")) })
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        val inRange = sideRows.filter { range == null || it.inv.date in range }
                        item { PeriodPicker(ps, pf, pt) }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard(if (sales) tr("المبيعات", "Sales") else tr("المشتريات", "Purchases"), Fmt.money(inRange.filter { it.inv.type == main }.sumOf { it.t.total }), Icons.Filled.Receipt, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                                StatCard(tr("المرتجعات", "Returns"), Fmt.money(inRange.filter { it.inv.type == ret }.sumOf { it.t.total }), Icons.Filled.AssignmentReturn, WarnAmber, Modifier.weight(1f))
                                StatCard(if (sales) tr("المحصّل", "Collected") else tr("المدفوع", "Paid"), Fmt.money(inRange.filter { it.inv.type == main }.sumOf { it.paid }), Icons.Filled.Payments, SuccessGreen, Modifier.weight(1f))
                            }
                        }
                        item { SearchField(q) { q = it } }
                        item {
                            HChips {
                                listOf("ALL" to tr("الكل", "All"), main to Shop.type(main).label, ret to tr("المرتجعات", "Returns"), "DUE" to tr("غير مسددة", "Unpaid"), "INST" to tr("بالتقسيط", "Installments"), "LATE" to tr("متأخرة", "Overdue")).forEach { (k, l) ->
                                    FilterChip(filter == k, { filter = k }, label = { Text(l) })
                                }
                            }
                        }
                        val list = inRange.filter { r ->
                            when (filter) { "ALL" -> true; "DUE" -> !r.isPaid && r.inv.type == main; "INST" -> r.hasInst; "LATE" -> r.overdue; else -> r.inv.type == filter } &&
                                (q.isBlank() || r.inv.partyName.contains(q, true) || Shop.numberText(r.inv).contains(q, true) || r.inv.partyPhone.contains(q) ||
                                    (r.inv.partyId?.let { id -> d.parties.firstOrNull { it.id == id }?.code?.contains(q, true) } == true))
                        }
                        if (list.isEmpty()) item { EmptyState(Icons.Filled.Receipt, tr("لا توجد فواتير في هذه الفترة", "No invoices in this period")) }
                        items(list, key = { it.inv.id }) { r -> SideInvoiceRow(r, d.parties.firstOrNull { it.id == r.inv.partyId }) { nav.navigate("invoice/${r.inv.id}") } }
                    }
                    1 -> {
                        val totalBal = statements.sumOf { it.balance.coerceAtLeast(0.0) }
                        val late = statements.sumOf { it.lateInst }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard(if (sales) tr("مستحق على العملاء", "Owed by customers") else tr("مستحق للموردين", "Owed to suppliers"), Fmt.money(totalBal), Icons.Filled.AccountBalanceWallet, if (sales) WarnAmber else DangerRed, Modifier.weight(1f))
                                StatCard(tr("أقساط متأخرة", "Overdue inst."), Fmt.money(late), Icons.Filled.Warning, DangerRed, Modifier.weight(1f))
                            }
                        }
                        item { SearchField(q) { q = it } }
                        val list = statements.filter { a -> q.isBlank() || a.p.name.contains(q, true) || a.p.code.contains(q, true) || a.p.phone.contains(q) }
                            .sortedByDescending { it.balance }
                        if (list.isEmpty()) item { EmptyState(Icons.Filled.People, if (sales) tr("أضف عملاءك بكود لكل عميل، أو سيُضافون تلقائياً من الفواتير", "Add customers with a code, or they're added from invoices") else tr("أضف الموردين بكود لكل مورد", "Add suppliers with a code")) }
                        items(list, key = { it.p.id }) { a -> PartyRow(a) { nav.navigate("party/${a.p.id}") } }
                    }
                    else -> {
                        item { PeriodPicker(ps, pf, pt) }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AssistChip({ pickProd = true }, label = { Text(prodFilter?.let { id -> d.products.firstOrNull { it.id == id }?.name } ?: tr("كل الأصناف", "All items"), maxLines = 1) }, leadingIcon = { Icon(Icons.Filled.Inventory2, null) },
                                    trailingIcon = { if (prodFilter != null) Icon(Icons.Filled.Close, null, Modifier.clickable { prodFilter = null }) })
                                AssistChip({ pickParty = true }, label = { Text(partyFilter?.let { id -> d.parties.firstOrNull { it.id == id }?.name } ?: if (sales) tr("كل العملاء", "All customers") else tr("كل الموردين", "All suppliers"), maxLines = 1) }, leadingIcon = { Icon(Icons.Filled.Person, null) },
                                    trailingIcon = { if (partyFilter != null) Icon(Icons.Filled.Close, null, Modifier.clickable { partyFilter = null }) })
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(if (sales) tr("صافي المبيعات", "Net sales") else tr("صافي المشتريات", "Net purchases"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                                    Text(Fmt.money(sums.sumOf { it.net }), color = MaterialTheme.colorScheme.onPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                    Text(tr("الكمية: ", "Qty: ") + Fmt.num(sums.sumOf { it.netQty }) + tr(" • المرتجعات: ", " • returns: ") + Fmt.money(sums.sumOf { it.retAmount }) +
                                        if (sales) tr(" • الربح: ", " • profit: ") + Fmt.money(sums.sumOf { it.profit }) else "", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        if (months.size > 1) {
                            item { SectionTitle(tr("حسب الشهر", "By month")) }
                            val mx = months.maxOf { kotlin.math.abs(it.second) }.coerceAtLeast(1.0)
                            items(months, key = { "m" + it.first }) { (m, v, n) ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(m, Modifier.width(70.dp), style = MaterialTheme.typography.bodySmall)
                                    LinearProgressIndicator(progress = { (kotlin.math.abs(v) / mx).toFloat() }, modifier = Modifier.weight(1f).height(8.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(Fmt.num(v) + " ($n)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        item { SectionTitle(if (sales) tr("المبيعات حسب الصنف", "Sales by item") else tr("المشتريات حسب الصنف", "Purchases by item")) }
                        if (sums.isEmpty()) item { Text(tr("لا توجد حركات في هذه الفترة", "No activity in this period"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        items(sums) { x ->
                            Card(Modifier.fillMaxWidth().clickable { x.key.toLongOrNull()?.let { nav.navigate("product/$it") } }) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row { Text(x.name, Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(Fmt.money(x.net), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                                    Text(tr("الكمية ", "Qty ") + Fmt.num(x.qty) + (if (x.retQty > 0) tr(" • مرتجع ", " • returned ") + Fmt.num(x.retQty) else "") + tr(" • متوسط السعر ", " • avg ") + Fmt.num(x.avgPrice) + tr(" • في ", " • in ") + x.count + tr(" فاتورة", " invoices"), style = MaterialTheme.typography.bodySmall)
                                    if (sales && x.cost > 0) Text(tr("الربح: ", "Profit: ") + Fmt.money(x.profit), style = MaterialTheme.typography.bodySmall, color = if (x.profit >= 0) SuccessGreen else DangerRed)
                                }
                            }
                        }
                        item { Text(tr("📄 زر المشاركة أعلاه يصدّر التقرير PDF أو Excel أو رابط.", "📄 Share above exports PDF, Excel or link."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
        }
    }
    if (addParty) PartyDialog(null, side) { id -> addParty = false; if (id != null) nav.navigate("party/$id") }
    if (pickProd) PickerDialog(tr("اختر الصنف", "Choose item"), d.products.map { it.id to (it.name + if (it.sku.isNotBlank()) " • " + it.sku else "") }, { pickProd = false }) { prodFilter = it; pickProd = false }
    if (pickParty) PickerDialog(if (sales) tr("اختر العميل", "Choose customer") else tr("اختر المورد", "Choose supplier"), myParties.map { it.id to (it.code + " • " + it.name) }, { pickParty = false }) { partyFilter = it; pickParty = false }
}

@Composable
fun PickerDialog(title: String, options: List<Pair<Long, String>>, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SearchField(q) { q = it }
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(options.filter { q.isBlank() || it.second.contains(q, true) }, key = { it.first }) { (id, label) ->
                        Text(label, Modifier.fillMaxWidth().clickable { onPick(id) }.padding(vertical = 12.dp))
                        HorizontalDivider()
                    }
                }
                if (options.isEmpty()) Text(tr("لا توجد عناصر", "Nothing to choose"), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
}

@Composable
private fun SideInvoiceRow(r: Shop.InvRow, p: Party?, onClick: () -> Unit) {
    val t = Shop.type(r.inv.type)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(t.emoji, fontSize = 22.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(Shop.numberText(r.inv) + " • " + (p?.name ?: r.inv.partyName.ifBlank { tr("نقدي", "Cash") }), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text((p?.code?.let { "$it • " } ?: "") + Fmt.date(r.inv.date) + (if (r.hasInst) tr(" • 💳 أقساط", " • 💳 inst.") else ""), style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.money(r.t.total), fontWeight = FontWeight.Bold)
                when {
                    !Shop.isMoney(r.inv.type) -> Text(tr("عرض سعر", "Quote"), style = MaterialTheme.typography.bodySmall)
                    r.isPaid -> Text(tr("مسددة", "Paid"), color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                    r.overdue -> Text(tr("متأخر ", "Late ") + Fmt.num(if (r.hasInst) r.lateAmount else r.remaining), color = DangerRed, style = MaterialTheme.typography.bodySmall)
                    else -> Text(tr("متبقي ", "Due ") + Fmt.num(r.remaining), color = WarnAmber, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun PartyRow(a: Parties.Statement, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) { Avatar(null, a.p.name, 44.dp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(a.p.name + if (!a.p.active) tr(" (موقوف)", " (inactive)") else "", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(a.p.code + (if (a.p.phone.isNotBlank()) " • " + a.p.phone else ""), style = MaterialTheme.typography.bodySmall)
                val ni = a.nextInst
                if (a.lateInst > 0) Text(tr("⚠️ أقساط متأخرة ", "⚠️ Overdue ") + Fmt.money(a.lateInst), style = MaterialTheme.typography.bodySmall, color = DangerRed)
                else if (ni != null) Text(tr("💳 القسط القادم ", "💳 Next ") + Fmt.money(ni.second.remaining) + " • " + Fmt.date(ni.second.due), style = MaterialTheme.typography.bodySmall, color = WarnAmber)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.money(kotlin.math.abs(a.balance)), fontWeight = FontWeight.Bold, color = when { a.balance > 0.01 -> if (a.overLimit) DangerRed else WarnAmber; a.balance < -0.01 -> SuccessGreen; else -> MaterialTheme.colorScheme.outline })
                Text(when { a.balance > 0.01 -> if (a.p.type == Parties.CUSTOMER) tr("مستحق عليه", "owes") else tr("مستحق له", "owed"); a.balance < -0.01 -> tr("رصيد دائن", "credit"); else -> tr("مسدد", "settled") }, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

// =====================================================================
//                     بطاقة العميل / المورد وكشف حسابه
// =====================================================================
@Composable
fun PartyScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val d = rememberShopData()
    val p = d.parties.firstOrNull { it.id == id }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val (ps, pf, pt) = rememberPeriod(4)
    val range = periodRange(ps.value, pf.value, pt.value)
    var edit by remember { mutableStateOf(false) }
    var settle by remember { mutableStateOf(false) }
    var charge by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var delTx by remember { mutableStateOf<PartyTx?>(null) }
    if (p == null) { ScreenScaffold(tr("الحساب", "Account"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val a = remember(d, range) { d.statement(p, range) }
    val full = remember(d) { d.statement(p) }
    val ag = remember(full) { Parties.aging(full) }
    val cust = p.type == Parties.CUSTOMER
    val doc = { Docs.partyStatement(a, range) }

    ScreenScaffold(
        title = p.name, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(p.phone.ifBlank { null }, doc = doc) { c -> Reports.doc(c, doc()) }
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (full.overLimit) DangerRed else MaterialTheme.colorScheme.primary)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(p.code + " • " + Parties.sideLabel(p.type), color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
                            Text(if (full.balance >= 0) (if (cust) tr("المستحق على العميل", "Customer owes") else tr("المستحق للمورد", "Owed to supplier")) else tr("رصيد دائن", "Credit balance"), color = Color.White.copy(alpha = 0.85f))
                            Text(Fmt.money(kotlin.math.abs(full.balance)), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            if (p.creditLimit > 0) Text(tr("حد الائتمان: ", "Credit limit: ") + Fmt.money(p.creditLimit) + if (full.overLimit) tr(" ⚠️ تم تجاوزه", " ⚠️ exceeded") else "", color = Color.White, style = MaterialTheme.typography.bodySmall)
                            if (p.phone.isNotBlank()) Text("📞 " + p.phone, color = Color.White, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { settle = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Payments, null); Spacer(Modifier.width(4.dp)); Text(if (cust) tr("تحصيل", "Receive") else tr("سداد", "Pay")) }
                        OutlinedButton(onClick = { nav.navigate("invoice_edit/${Parties.mainType(p.type)}/0?party=${p.id}") }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Receipt, null); Spacer(Modifier.width(4.dp)); Text(tr("فاتورة", "Invoice")) }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { nav.navigate("invoice_edit/${Parties.returnType(p.type)}/0?party=${p.id}") }, modifier = Modifier.weight(1f)) { Text(tr("مرتجع", "Return")) }
                        OutlinedButton(onClick = { charge = true }, modifier = Modifier.weight(1f)) { Text(tr("إشعار مدين", "Debit note")) }
                        if (p.phone.isNotBlank()) OutlinedButton(onClick = { Share.whatsappMessage(ctx, p.phone, Parties.whatsappStatement(full)) }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(tr("أعمار الدين", "Aging"), fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(tr("غير مستحق", "Current") to ag.current, "1-30" to ag.d30, "31-60" to ag.d60, "61-90" to ag.d90, "+90" to ag.over90).forEachIndexed { i, (l, v) ->
                                    Surface(color = if (i == 0) SuccessGreen.copy(alpha = 0.12f) else if (v > 0) DangerRed.copy(alpha = 0.06f + i * 0.04f) else MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.small, modifier = Modifier.weight(1f)) {
                                        Column(Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(l, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                            Text(Fmt.num(v), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, maxLines = 1)
                                        }
                                    }
                                }
                            }
                            KeyValue(if (cust) tr("إجمالي المبيعات", "Total sales") else tr("إجمالي المشتريات", "Total purchases"), Fmt.money(full.sales))
                            if (full.returns > 0) KeyValue(tr("المرتجعات", "Returns"), Fmt.money(full.returns))
                            KeyValue(tr("المدفوع", "Paid"), Fmt.money(full.paid), SuccessGreen)
                            if (full.lateInst > 0) KeyValue(tr("أقساط متأخرة", "Overdue installments"), Fmt.money(full.lateInst), DangerRed)
                            full.nextInst?.let { (r, x) -> KeyValue(tr("القسط القادم", "Next installment"), Fmt.money(x.remaining) + " • " + Fmt.date(x.due) + " • " + Shop.numberText(r.inv), WarnAmber) }
                        }
                    }
                }
                item {
                    ScrollableTabRow(tab, edgePadding = 0.dp) {
                        listOf(tr("كشف الحساب", "Statement"), tr("الفواتير", "Invoices"), tr("الأقساط", "Installments"), tr("السندات", "Vouchers")).forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
                    }
                }
                when (tab) {
                    0 -> {
                        item { PeriodPicker(ps, pf, pt) }
                        item {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                                Text(tr("رصيد أول المدة", "Opening balance"), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Text(Fmt.num(a.opening), fontWeight = FontWeight.Bold)
                            }
                        }
                        if (a.lines.isEmpty()) item { Text(tr("لا توجد حركات في هذه الفترة", "No activity in this period"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        items(a.lines.reversed()) { l ->
                            OutlinedCard(Modifier.fillMaxWidth().clickable(enabled = l.invoiceId != null) { l.invoiceId?.let { nav.navigate("invoice/$it") } }) {
                                Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(l.ref, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                        Text(Fmt.date(l.date) + tr(" • الرصيد ", " • balance ") + Fmt.num(l.balance), style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (l.debit > 0) Text("+" + Fmt.num(l.debit), color = WarnAmber, fontWeight = FontWeight.Bold)
                                    if (l.credit > 0) Text("−" + Fmt.num(l.credit), color = SuccessGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    1 -> {
                        if (full.rows.isEmpty()) item { Text(tr("لا توجد فواتير", "No invoices"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        items(full.rows.sortedByDescending { it.inv.date }, key = { "i" + it.inv.id }) { r -> SideInvoiceRow(r, p) { nav.navigate("invoice/${r.inv.id}") } }
                    }
                    2 -> {
                        val ins = full.rows.filter { it.hasInst }
                        if (ins.isEmpty()) item { Text(tr("لا توجد فواتير بالتقسيط", "No installment invoices"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        ins.forEach { r ->
                            item(key = "h" + r.inv.id) { Text(Shop.numberText(r.inv) + " • " + Fmt.money(r.t.total) + tr(" • متبقي ", " • due ") + Fmt.money(r.remaining), fontWeight = FontWeight.Bold, modifier = Modifier.clickable { nav.navigate("invoice/${r.inv.id}") }) }
                            items(r.schedule, key = { "x" + r.inv.id + "_" + it.no }) { x ->
                                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(if (x.isPaid) Icons.Filled.CheckCircle else if (x.isLate) Icons.Filled.ErrorOutline else Icons.Filled.Schedule, null,
                                        tint = if (x.isPaid) SuccessGreen else if (x.isLate) DangerRed else MaterialTheme.colorScheme.outline, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(Shop.instLabel(x, r.inv.instCount) + " • " + Fmt.date(x.due), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                    Text(Fmt.num(if (x.isPaid) x.amount else x.remaining), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    else -> {
                        val vouchers = full.txs.sortedByDescending { it.date }
                        if (vouchers.isEmpty()) item { Text(tr("السندات غير المرتبطة بفاتورة (الدفعات المقدمة والإشعارات) تظهر هنا. التحصيل يوزَّع تلقائياً على الفواتير الأقدم.", "Vouchers not tied to an invoice appear here. Receipts are allocated to the oldest invoices automatically."), style = MaterialTheme.typography.bodySmall) }
                        items(vouchers, key = { "v" + it.id }) { t ->
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(if (t.type == Parties.CHARGE) tr("إشعار مدين", "Debit note") else Parties.settleLabel(p.type), fontWeight = FontWeight.SemiBold)
                                        Text(Fmt.date(t.date) + " • " + Shop.method(t.method).label + if (t.note.isNotBlank()) " • " + t.note else "", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(Fmt.money(t.amount), fontWeight = FontWeight.Bold)
                                    AttachmentButton(Attachments.PARTY_TX, t.id)
                                    IconButton(onClick = { delTx = t }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                                }
                            }
                        }
                    }
                }
                item { TextButton(onClick = { del = true }) { Text(if (cust) tr("حذف العميل", "Delete customer") else tr("حذف المورد", "Delete supplier"), color = DangerRed) } }
            }
        }
    }
    if (edit) PartyDialog(p, p.type) { edit = false }
    if (settle) PartySettleDialog(p, full) { settle = false }
    if (charge) PartyChargeDialog(p) { charge = false }
    delTx?.let { t ->
        ConfirmDialog(tr("حذف السند", "Delete voucher"), Fmt.money(t.amount), onDismiss = { delTx = null }) {
            delTx = null
            scope.launch { Attachments.deleteFor(Attachments.PARTY_TX, t.id); dao.deleteLinkedTx(AccountTx.SRC_PARTY, t.id); dao.deletePartyTx(t.id) }
        }
    }
    if (del) ConfirmDialog(tr("حذف الحساب", "Delete account"), tr("سيُحذف «${p.name}» وسنداته، وتبقى فواتيره بدون ربط. متابعة؟", "Delete this account and its vouchers? Invoices stay unlinked."), onDismiss = { del = false }) {
        del = false
        scope.launch { dao.deletePartyFull(p.id); nav.popBackStack() }
    }
}

@Composable
fun PartyDialog(existing: Party?, type: String, onDone: (Long?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var code by remember { mutableStateOf(existing?.code ?: "") }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var personId by remember { mutableStateOf(existing?.personId) }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var taxNo by remember { mutableStateOf(existing?.taxNo ?: "") }
    var opening by remember { mutableStateOf(existing?.opening?.takeIf { it != 0.0 }?.let { Fmt.plain(it) } ?: "") }
    var limit by remember { mutableStateOf(existing?.creditLimit?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    LaunchedEffect(Unit) { if (existing == null) code = Parties.nextCode(dao, type) }
    val cust = type == Parties.CUSTOMER
    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text(if (existing != null) existing.name else if (cust) tr("عميل جديد", "New customer") else tr("مورد جديد", "New supplier")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(code, { code = it }, label = { Text(tr("الكود", "Code")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                PersonSelector(null, tr("من جهات الاتصال", "From contacts")) { pp -> name = pp.name; phone = pp.phone; personId = pp.id }
                OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text(tr("الجوال", "Phone")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(address, { address = it }, label = { Text(tr("العنوان (اختياري)", "Address (optional)")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(taxNo, { taxNo = it }, label = { Text(tr("الرقم الضريبي / السجل (اختياري)", "Tax / reg. no. (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                MoneyField(opening, { opening = it }, if (cust) tr("رصيد افتتاحي مستحق عليه", "Opening balance he owes") else tr("رصيد افتتاحي مستحق له", "Opening balance I owe"))
                MoneyField(limit, { limit = it }, tr("حد الائتمان (اختياري)", "Credit limit (optional)"))
                if (existing != null) SwitchRow(tr("نشط", "Active"), null, active) { active = it }
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل الاسم", "Enter the name")); return@TextButton }
                val x = Party(code = code.trim(), name = name.trim(), type = type, phone = phone.trim(), personId = personId, address = address.trim(), taxNo = taxNo.trim(),
                    opening = Fmt.parse(opening) ?: 0.0, creditLimit = Fmt.parse(limit) ?: 0.0, active = active, notes = notes.trim())
                scope.launch {
                    if (existing == null) onDone(dao.insertParty(x))
                    else { dao.updateParty(x.copy(id = existing.id, createdAt = existing.createdAt)); onDone(existing.id) }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun PartySettleDialog(p: Party, a: Parties.Statement, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val suggest = if (a.lateInst > 0) a.lateInst else a.nextInst?.second?.remaining ?: a.balance.coerceAtLeast(0.0)
    var amount by remember { mutableStateOf(if (suggest > 0) Fmt.plain(suggest) else "") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var method by remember { mutableStateOf("CASH") }
    var note by remember { mutableStateOf("") }
    val acc = remember { mutableStateOf(Extras.shopAccount.takeIf { it > 0 }) }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Parties.settleLabel(p.type)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("الرصيد الحالي: ", "Current balance: ") + Fmt.money(a.balance), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                HChips {
                    if (a.lateInst > 0) AssistChip({ amount = Fmt.plain(a.lateInst) }, label = { Text(tr("المتأخر ", "Overdue ") + Fmt.num(a.lateInst)) })
                    a.nextInst?.let { (_, x) -> AssistChip({ amount = Fmt.plain(x.remaining) }, label = { Text(tr("القسط ", "Inst. ") + Fmt.num(x.remaining)) }) }
                    if (a.balance > 0) AssistChip({ amount = Fmt.plain(a.balance) }, label = { Text(tr("الرصيد كاملاً", "Full balance")) })
                }
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                HChips { Shop.methods.forEach { m -> FilterChip(method == m.key, { method = m.key }, label = { Text(m.emoji + " " + m.label) }) } }
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة / رقم السند", "Note / voucher no.")) }, modifier = Modifier.fillMaxWidth())
                AccountPickRow(acc, if (p.type == Parties.CUSTOMER) tr("إيداع في حساب (اختياري)", "Deposit to account (optional)") else tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
                Text(tr("يُوزَّع المبلغ تلقائياً على الفواتير والأقساط الأقدم، والزيادة تُسجَّل دفعة مقدمة.", "The amount is allocated to the oldest invoices/installments; any excess is kept as an advance."), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val v = Fmt.parse(amount)
                if (v == null || v <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                busy = true
                scope.launch { Parties.settle(dao, p, v, date, method, acc.value, note.trim()); toast(ctx, tr("تم التسجيل ✅", "Recorded ✅")); onDismiss() }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun PartyChargeDialog(p: Party, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var note by remember { mutableStateOf("") }
    val pending = remember { mutableStateListOf<Uri>() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("إشعار مدين", "Debit note")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("يزيد رصيد الحساب بمبلغ خارج الفواتير (مثل رسوم أو فرق سعر).", "Increases the balance outside invoices (e.g. fees or price difference)."), style = MaterialTheme.typography.bodySmall)
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                OutlinedTextField(note, { note = it }, label = { Text(tr("البيان", "Description")) }, modifier = Modifier.fillMaxWidth())
                PendingAttachRow(pending)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(amount)
                if (v == null || v <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                scope.launch {
                    val id = dao.insertPartyTx(PartyTx(partyId = p.id, type = Parties.CHARGE, amount = v, date = date, note = note.trim()))
                    Attachments.addAll(ctx, Attachments.PARTY_TX, id, pending.toList())
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// =====================================================================
//                حسابات العملاء والموردين (أعمار الديون)
// =====================================================================
@Composable
fun ShopAccountsScreen(nav: NavController) {
    val d = rememberShopData()
    var side by rememberSaveable { mutableStateOf(Parties.CUSTOMER) }
    var onlyOpen by rememberSaveable { mutableStateOf(true) }
    val list = remember(d, side) { d.parties.filter { it.type == side }.map { d.statement(it) } }
    val shown = list.filter { !onlyOpen || kotlin.math.abs(it.balance) > 0.01 }.sortedByDescending { it.balance }
    val ags = shown.map { Parties.aging(it) }
    ScreenScaffold(
        title = tr("حسابات العملاء والموردين", "Customer & supplier accounts"), onBack = { nav.popBackStack() },
        actions = { PdfShareButton(null, doc = { Docs.partiesAging(side, shown) }) { c -> Reports.doc(c, Docs.partiesAging(side, shown)) } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                HChips {
                    FilterChip(side == Parties.CUSTOMER, { side = Parties.CUSTOMER }, label = { Text(tr("العملاء", "Customers")) })
                    FilterChip(side == Parties.SUPPLIER, { side = Parties.SUPPLIER }, label = { Text(tr("الموردون", "Suppliers")) })
                    FilterChip(onlyOpen, { onlyOpen = !onlyOpen }, label = { Text(tr("الأرصدة المفتوحة فقط", "Open balances only")) })
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        KeyValue(if (side == Parties.CUSTOMER) tr("إجمالي المستحق على العملاء", "Total owed by customers") else tr("إجمالي المستحق للموردين", "Total owed to suppliers"), Fmt.money(list.sumOf { it.balance.coerceAtLeast(0.0) }), MaterialTheme.colorScheme.primary)
                        KeyValue(tr("غير مستحق بعد", "Not yet due"), Fmt.money(ags.sumOf { it.current }), SuccessGreen)
                        KeyValue(tr("متأخر 1-30 يوم", "1-30 days late"), Fmt.money(ags.sumOf { it.d30 }), WarnAmber)
                        KeyValue(tr("متأخر 31-60 يوم", "31-60 days late"), Fmt.money(ags.sumOf { it.d60 }), WarnAmber)
                        KeyValue(tr("متأخر 61-90 يوم", "61-90 days late"), Fmt.money(ags.sumOf { it.d90 }), DangerRed)
                        KeyValue(tr("متأخر أكثر من 90 يوماً", "Over 90 days late"), Fmt.money(ags.sumOf { it.over90 }), DangerRed)
                    }
                }
            }
            if (shown.isEmpty()) item { EmptyState(Icons.Filled.AccountBalance, tr("لا توجد أرصدة مفتوحة", "No open balances")) }
            items(shown, key = { it.p.id }) { a -> PartyRow(a) { nav.navigate("party/${a.p.id}") } }
        }
    }
}

// =====================================================================
//                          حركة الصنف
// =====================================================================
@Composable
fun ProductLedgerScreen(nav: NavController, id: Long) {
    val d = rememberShopData()
    val p = d.products.firstOrNull { it.id == id }
    val (ps, pf, pt) = rememberPeriod(4)
    val range = periodRange(ps.value, pf.value, pt.value)
    var kind by rememberSaveable { mutableStateOf("ALL") }
    if (p == null) { ScreenScaffold(tr("الصنف", "Item"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val l = remember(d, range) { StockReports.ledger(p, d.invs, d.items, d.adjs, range) }
    val doc = { Docs.itemLedger(l, range) }
    val moves = l.moves.filter { kind == "ALL" || (kind == "IN" && it.qtyIn > 0) || (kind == "OUT" && it.qtyOut > 0) || (kind == "ADJ" && (it.kind.startsWith("ADJ") || it.kind == "OPEN")) || it.kind == kind }
    ScreenScaffold(
        title = p.name, onBack = { nav.popBackStack() },
        actions = { PdfShareButton(null, doc = doc) { c -> Reports.doc(c, doc()) } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PeriodPicker(ps, pf, pt) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(tr("أول المدة", "Opening"), Fmt.num(l.opening), Icons.Filled.Inventory2, MaterialTheme.colorScheme.outline, Modifier.weight(1f))
                    StatCard(tr("وارد", "In"), Fmt.num(l.inQty), Icons.Filled.ArrowDownward, SuccessGreen, Modifier.weight(1f))
                    StatCard(tr("منصرف", "Out"), Fmt.num(l.outQty), Icons.Filled.ArrowUpward, DangerRed, Modifier.weight(1f))
                    StatCard(tr("آخر المدة", "Closing"), Fmt.num(l.closing), Icons.Filled.Inventory, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        KeyValue(tr("المشتريات", "Purchased"), Fmt.num(l.qty(Shop.PURCHASE)) + " • " + Fmt.money(l.amount(Shop.PURCHASE)))
                        KeyValue(tr("المبيعات", "Sold"), Fmt.num(l.qty(Shop.SALE)) + " • " + Fmt.money(l.amount(Shop.SALE)))
                        if (l.qty(Shop.SRETURN) > 0) KeyValue(tr("مرتجع مبيعات", "Sales returns"), Fmt.num(l.qty(Shop.SRETURN)))
                        if (l.qty(Shop.PRETURN) > 0) KeyValue(tr("مرتجع مشتريات", "Purchase returns"), Fmt.num(l.qty(Shop.PRETURN)))
                        KeyValue(tr("سعر الشراء / البيع الحالي", "Current cost / price"), Fmt.num(p.cost) + " / " + Fmt.num(p.price))
                    }
                }
            }
            item {
                HChips {
                    listOf("ALL" to tr("الكل", "All"), "IN" to tr("الوارد", "In"), "OUT" to tr("المنصرف", "Out"), Shop.SALE to tr("بيع", "Sale"), Shop.PURCHASE to tr("شراء", "Purchase"), Shop.SRETURN to tr("مرتجع بيع", "Sales return"), Shop.PRETURN to tr("مرتجع شراء", "Purchase return"), "ADJ" to tr("تسويات وافتتاحي", "Adjustments")).forEach { (k, t) ->
                        FilterChip(kind == k, { kind = k }, label = { Text(t) })
                    }
                }
            }
            if (moves.isEmpty()) item { Text(tr("لا توجد حركات في هذه الفترة", "No movements in this period"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(moves.reversed()) { m ->
                OutlinedCard(Modifier.fillMaxWidth().clickable(enabled = m.invoiceId != null) { m.invoiceId?.let { nav.navigate("invoice/$it") } }) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (m.qtyIn > 0) Icons.Filled.ArrowDownward else Icons.Filled.ArrowUpward, null, tint = if (m.qtyIn > 0) SuccessGreen else DangerRed)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(StockReports.kindLabel(m.kind) + (if (m.ref.isNotBlank()) " • " + m.ref else ""), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Fmt.date(m.date) + (if (m.party.isNotBlank()) " • " + m.party else "") + tr(" • السعر ", " • price ") + Fmt.num(m.price), style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text((if (m.qtyIn > 0) "+" + Fmt.num(m.qtyIn) else "−" + Fmt.num(m.qtyOut)), fontWeight = FontWeight.Bold, color = if (m.qtyIn > 0) SuccessGreen else DangerRed)
                            Text(tr("الرصيد ", "Bal. ") + Fmt.num(m.balance), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
