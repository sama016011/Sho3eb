package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.sho3eb.app.R
import org.json.JSONObject
import java.io.File

/** نسخ إضافية مستقلة من التطبيق على نفس الهاتف (لأرقام هواتف وبريد مختلفة) */
object Copies {
    val ids = listOf(1, 2)

    /** رقم هذه النسخة (0 = النسخة الأساسية) */
    val copyNo: Int get() = Edition.embeddedString("copy").toIntOrNull() ?: 0
    val isCopy: Boolean get() = copyNo > 0

    /** تظهر الأزرار في النسخة الأساسية فقط، أو في نسخة مشاركة سُمح لها بذلك */
    val enabled: Boolean get() = !isCopy && (!Edition.hasEmbedded || Edition.embeddedString("allowCopies") == "true")

    fun pkg(ctx: Context, n: Int) = ApkCopy.copyPackage(ctx.packageName, n)

    @Suppress("DEPRECATION")
    fun installed(ctx: Context, n: Int): Boolean = runCatching {
        if (Build.VERSION.SDK_INT >= 33) ctx.packageManager.getPackageInfo(pkg(ctx, n), PackageManager.PackageInfoFlags.of(0))
        else ctx.packageManager.getPackageInfo(pkg(ctx, n), 0)
        true
    }.getOrDefault(false)

    private fun json(n: Int): String {
        val o = Edition.embeddedCopy() ?: JSONObject().put("shared", false)
        o.put("copy", n).put("allowCopies", false)
        if (!o.has("shared")) o.put("shared", false)
        // نفس خادم التواصل
        o.put("supa_url", com.sho3eb.app.core.chat.Supa.url).put("supa_key", com.sho3eb.app.core.chat.Supa.key)
        return o.toString()
    }

    /** بناء ملف النسخة (يُستدعى في الخلفية) */
    fun build(ctx: Context, n: Int, onProgress: (Int) -> Unit): File {
        val src = File(ctx.applicationInfo.sourceDir)
        if (!ctx.applicationInfo.splitSourceDirs.isNullOrEmpty()) throw ApkCopy.CopyError("split")
        val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("copy") }?.forEach { it.delete() }
        val out = File(dir, "copy$n.apk")
        val label = if (n == 1) R.string.app_name_c1 else R.string.app_name_c2
        ApkCopy.build(src, out, ctx.packageName, pkg(ctx, n), R.string.app_name, label, json(n),
            ctx.assets.open("copykey/key.pk8").use { it.readBytes() }, ctx.assets.open("copykey/cert.der").use { it.readBytes() }, onProgress)
        return out
    }

    fun canInstall(ctx: Context): Boolean = Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()
    fun askInstallPermission(ctx: Context) {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    fun install(ctx: Context, f: File) {
        val uri = Share.uriFor(ctx, f)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun open(ctx: Context, n: Int) {
        ctx.packageManager.getLaunchIntentForPackage(pkg(ctx, n))?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    fun uninstall(ctx: Context, n: Int) {
        runCatching { ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg(ctx, n))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
