package com.sho3eb.app.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.sho3eb.app.R
import com.sho3eb.app.ui.MainActivity
import java.util.concurrent.TimeUnit

/**
 * إشعارات المباريات: تذكير قبل البداية، انطلاق المباراة، كل هدف (مع اسم اللاعب إن توفر)، بين الشوطين، والنهاية.
 * عامل دوري كل 15 دقيقة يكتشف المباريات القريبة، وأثناء المباريات الجارية يعيد جدولة نفسه كل دقيقة تقريباً.
 */
object FootballAlerts {
    const val CHANNEL = "sho3eb_football"
    private const val PERIODIC = "fb_periodic"
    private const val LIVE = "fb_live"

    fun channel(ctx: Context) {
        val ch = NotificationChannel(CHANNEL, tr("مباريات كرة القدم", "Football matches"), NotificationManager.IMPORTANCE_HIGH)
        ch.description = tr("الأهداف والنتائج ومواعيد المباريات", "Goals, results and kick-offs")
        ctx.getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
    }

    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        if (!Football.notify) { wm.cancelUniqueWork(PERIODIC); wm.cancelUniqueWork(LIVE); return }
        val req = PeriodicWorkRequestBuilder<FootballWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun scheduleLive(ctx: Context, delaySec: Long) {
        val req = OneTimeWorkRequestBuilder<FootballWorker>().setInitialDelay(delaySec, TimeUnit.SECONDS)
            .setInputData(workDataOf("live" to true))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(LIVE, ExistingWorkPolicy.REPLACE, req)
    }

    fun show(ctx: Context, id: Int, title: String, text: String, matchId: String) {
        if (!Notifier.canNotify(ctx)) return
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("route", "match/$matchId")
        val pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL).setSmallIcon(R.drawable.ic_notification).setColor(0xFF2E7D32.toInt())
            .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_EVENT).build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (_: SecurityException) {}
    }

    /** هل يتابع المستخدم هذه المباراة؟ */
    fun watched(m: Football.Match): Boolean {
        val fav = Football.favTeamId
        return (fav.isNotBlank() && (m.homeId == fav || m.awayId == fav)) || m.id in Football.followedMatches() ||
            (Football.notifyAllFavLeague && m.leagueId == Football.favLeague)
    }

    /** يفحص المباريات ويرسل الإشعارات؛ يعيد true إذا كانت هناك مباراة جارية أو وشيكة */
    fun check(ctx: Context): Boolean {
        if (!Football.notify) return false
        val now = System.currentTimeMillis()
        var active = false
        val fav = Football.favTeamId
        if (fav.isBlank() && Football.followedMatches().isEmpty() && !Football.notifyAllFavLeague) return false
        val wanted = buildSet {
            if (Football.notifyAllFavLeague) add(Football.favLeague)
            if (fav.isNotBlank()) { if (Football.favTeamLeague.isNotBlank()) add(Football.favTeamLeague) else addAll(Football.leagues().map { it.id }) }
            addAll(Football.followLeagues())
        }
        for (l in Football.leagues().filter { it.id in wanted }) {
            val list = runCatching { Football.around(l, live = true) }.getOrDefault(emptyList()).filter { watched(it) }
            for (m in list) {
                val nid = 7000 + (m.id.hashCode() and 0xFFFF) % 2000
                val title = m.home + " × " + m.away
                // تذكير قبل 30 دقيقة
                val until = m.time - now
                if (m.notStarted && until in 0..35 * 60_000L) {
                    active = true
                    if (Football.notifyStart && !Extras.b("fbn_pre_${m.id}", false)) {
                        Extras.pb("fbn_pre_${m.id}", true)
                        show(ctx, nid, "⏰ " + title, tr("تبدأ المباراة الساعة ", "Kick-off at ") + Football.localTime(m.time) + " • " + (Football.leagueOf(m.leagueId)?.title ?: m.leagueName), m.id)
                    }
                }
                if (m.live) active = true
                val prev = Extras.s("fbn_st_${m.id}", "")
                val cur = m.status + "|" + (m.hs ?: -1) + "|" + (m.aws ?: -1)
                if (prev == cur) continue
                Extras.ps("fbn_st_${m.id}", cur)
                if (prev.isBlank() && !m.live) continue
                val (pst, phs, pas) = prev.split("|").let { Triple(it.getOrElse(0) { "" }, it.getOrElse(1) { "-1" }.toIntOrNull() ?: -1, it.getOrElse(2) { "-1" }.toIntOrNull() ?: -1) }
                val score = "${m.home} ${m.hs ?: 0} - ${m.aws ?: 0} ${m.away}"
                if (m.live && pst !in Football.liveCodes && Football.notifyStart && m.status == "1H") show(ctx, nid, "🟢 " + tr("انطلقت المباراة", "Kick-off"), title, m.id)
                if ((m.hs ?: 0) > phs.coerceAtLeast(0) || (m.aws ?: 0) > pas.coerceAtLeast(0)) {
                    if (Football.notifyGoals && (phs >= 0 || pas >= 0 || m.live)) {
                        val scorer = runCatching {
                            val l2 = Football.leagueOf(m.leagueId)
                            val ev = (if (Football.apiKey.isNotBlank()) Football.apifEvents(m).first else emptyList()).ifEmpty { if (l2 != null) Football.espnEvents(l2, m) else emptyList() }
                            ev.lastOrNull { it.type.contains("Goal", true) }?.let { e -> " • " + e.player + " " + e.minute }
                        }.getOrNull() ?: ""
                        val team = if ((m.hs ?: 0) > phs.coerceAtLeast(0)) m.home else m.away
                        show(ctx, nid + 1, "⚽ " + tr("هدف لـ ", "Goal for ") + team + "!", score + scorer, m.id)
                    }
                }
                if (m.status == "HT" && pst != "HT" && Football.notifyEnd) show(ctx, nid + 2, "⏸️ " + tr("نهاية الشوط الأول", "Half-time"), score, m.id)
                if (m.finished && pst !in Football.doneCodes && Football.notifyEnd) show(ctx, nid + 3, "🏁 " + tr("نهاية المباراة", "Full-time"), score + tr("\nشاهد الملخص داخل التطبيق", "\nWatch highlights in the app"), m.id)
            }
        }
        return active
    }
}

class FootballWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val active = runCatching { FootballAlerts.check(applicationContext) }.getOrDefault(false)
        if (active) FootballAlerts.scheduleLive(applicationContext, 75)
        return Result.success()
    }
}
