package com.sho3eb.app.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.sho3eb.app.R
import com.sho3eb.app.ui.MainActivity
import java.util.concurrent.TimeUnit

/**
 * إشعارات المباريات: تذكير قبل البداية، انطلاق المباراة، كل هدف (مع اسم اللاعب إن توفر)، بين الشوطين، والنهاية.
 * عامل دوري كل 15 دقيقة يكتشف المباريات القريبة، وأثناء المباريات الجارية يعيد جدولة نفسه كل دقيقة تقريباً.
 */
object FootballAlerts {
    const val CHANNEL = "sho3eb_football"
    private const val PERIODIC = "fb_periodic"
    private const val LIVE = "fb_live"

    fun channel(ctx: Context) {
        val ch = NotificationChannel(CHANNEL, tr("مباريات كرة القدم", "Football matches"), NotificationManager.IMPORTANCE_HIGH)
        ch.description = tr("الأهداف والنتائج ومواعيد المباريات", "Goals, results and kick-offs")
        ctx.getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
    }

    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        if (!Football.notify) { wm.cancelUniqueWork(PERIODIC); wm.cancelUniqueWork(LIVE); return }
        val req = PeriodicWorkRequestBuilder<FootballWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun scheduleLive(ctx: Context, delaySec: Long) {
        val req = OneTimeWorkRequestBuilder<FootballWorker>().setInitialDelay(delaySec, TimeUnit.SECONDS)
            .setInputData(workDataOf("live" to true))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(LIVE, ExistingWorkPolicy.REPLACE, req)
    }

    fun show(ctx: Context, id: Int, title: String, text: String, matchId: String) {
        if (!Notifier.canNotify(ctx)) return
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("route", "match/$matchId")
        val pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL).setSmallIcon(R.drawable.ic_notification).setColor(0xFF2E7D32.toInt())
            .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_EVENT).build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (_: SecurityException) {}
    }

    /** هل يتابع المستخدم هذه المباراة؟ */
    fun watched(m: Football.Match): Boolean {
        val fav = Football.favTeamId
        return (fav.isNotBlank() && (m.homeId == fav || m.awayId == fav)) || m.id in Football.followedMatches() ||
            (Football.notifyAllFavLeague && m.leagueId == Football.favLeague)
    }

    private fun nidOf(m: Football.Match) = 7000 + (m.id.hashCode() and 0xFFFF) % 2000
    private var counter = 0
    private fun uniq(m: Football.Match) = 20000 + ((m.id.hashCode() and 0xFFF) * 16) + (counter++ % 16)

    /** يعالج مباراة واحدة؛ يعيد true إن كانت جارية أو قريبة */
    private fun checkMatch(ctx: Context, m: Football.Match, now: Long): Boolean {
        var active = false
        val nid = nidOf(m)
        val title = m.homeAr + " × " + m.awayAr
        val lg = Football.leagueOf(m.leagueId)?.title ?: m.leagueName
        val until = m.time - now
        // تذكير قبل 30 دقيقة
        if (m.notStarted && until in 0..35 * 60_000L && Football.notifyStart && !Extras.b("fbn_pre_${m.id}", false)) {
            Extras.pb("fbn_pre_${m.id}", true)
            show(ctx, nid, "⏰ " + title, tr("تبدأ المباراة الساعة ", "Kick-off at ") + Football.localTime(m.time) + " • " + lg, m.id)
        }
        val near = m.notStarted && until in -15 * 60_000L..100 * 60_000L
        if (near || m.live) active = true
        val recentEnd = m.finished && now - m.time < 4 * 3600_000L
        if (!near && !m.live && !recentEnd && Extras.s("fbn_st_${m.id}", "").isNotBlank() && Extras.s("fbn_st_${m.id}", "").startsWith(m.status)) return active

        // التفاصيل (الأحداث والتشكيل) من المصادر المجانية
        val det = if (near || m.live || recentEnd) runCatching { FootballLive.details(m) }.getOrNull() else null
        val hs = det?.hs?.takeIf { m.live || recentEnd } ?: m.hs
        val aws = det?.aws?.takeIf { m.live || recentEnd } ?: m.aws
        val score = "${m.homeAr} ${hs ?: 0} - ${aws ?: 0} ${m.awayAr}"

        // التشكيل فور إعلانه
        if (det != null && det.lineups.size >= 2 && Football.notifyLineups && !Extras.b("fbn_lu_${m.id}", false) && !m.finished) {
            Extras.pb("fbn_lu_${m.id}", true)
            val text = det.lineups.take(2).joinToString("\n\n") { lu ->
                "🔹 " + TeamAr.name(lu.team) + (if (lu.formation.isNotBlank()) " (" + lu.formation + ")" else "") + ":\n" + lu.starters.joinToString("، ") { it.name.substringAfterLast(' ').ifBlank { it.name } }
            }
            show(ctx, nid + 5, "👥 " + tr("التشكيل الرسمي: ", "Lineups: ") + title, text, m.id)
        }

        // الحالة والنتيجة
        val prev = Extras.s("fbn_st_${m.id}", "")
        val cur = m.status + "|" + (hs ?: -1) + "|" + (aws ?: -1)
        val first = prev.isBlank()
        if (prev != cur) Extras.ps("fbn_st_${m.id}", cur)
        val (pst, phs, pas) = prev.split("|").let { Triple(it.getOrElse(0) { "" }, it.getOrElse(1) { "-1" }.toIntOrNull() ?: -1, it.getOrElse(2) { "-1" }.toIntOrNull() ?: -1) }
        if (!first && m.live && pst !in Football.liveCodes && Football.notifyStart) show(ctx, nid + 6, "🟢 " + tr("انطلقت المباراة", "Kick-off") + " • " + lg, title, m.id)
        else if (first && m.live && Football.notifyStart && m.status == "1H") show(ctx, nid + 6, "🟢 " + tr("انطلقت المباراة", "Kick-off") + " • " + lg, title, m.id)

        // الأحداث التفصيلية
        var goalNotified = false
        if (det != null && det.events.isNotEmpty()) {
            val seenKey = "fbn_ev_${m.id}"
            val seen = Extras.s(seenKey, "").split("\u0001").filter { it.isNotBlank() }.toSet()
            val firstEv = !Extras.b("fbn_evinit_${m.id}", false)
            val keys = det.events.map { it.key }.toSet()
            if (!firstEv) {
                for (e in det.events.filter { it.key !in seen }) {
                    val team = TeamAr.name(e.team).ifBlank { if (e.home == true) m.homeAr else if (e.home == false) m.awayAr else "" }
                    when {
                        e.isGoal && Football.notifyGoals -> {
                            goalNotified = true
                            show(ctx, uniq(m), "⚽ " + tr("هدف لـ ", "GOAL for ") + team + "! " + e.minute,
                                score + "\n" + tr("⚽ المسجل: ", "⚽ Scorer: ") + e.player + (if (e.detail.isNotBlank()) " (" + e.detail + ")" else "") +
                                    (if (e.assist.isNotBlank()) "\n" + tr("🎯 صناعة: ", "🎯 Assist: ") + e.assist else "") + "\n⏱️ " + tr("الدقيقة ", "Minute ") + e.minute, m.id)
                        }
                        e.kind == "sub" && Football.notifySubs -> show(ctx, uniq(m), "🔄 " + tr("تبديل في ", "Substitution: ") + team + " " + e.minute,
                            "⬆️ " + tr("دخول: ", "In: ") + e.player + (if (e.playerOut.isNotBlank()) "\n⬇️ " + tr("خروج: ", "Out: ") + e.playerOut else "") + "\n" + score, m.id)
                        e.kind == "red" && Football.notifyCards -> show(ctx, uniq(m), "🟥 " + tr("طرد! ", "Red card! ") + e.player + " " + e.minute, team + "\n" + score, m.id)
                        e.kind == "var" && Football.notifyCards -> show(ctx, uniq(m), "📺 VAR " + e.minute, e.detail + (if (team.isNotBlank()) " • $team" else "") + "\n" + score, m.id)
                        e.kind == "penmiss" && Football.notifyGoals -> show(ctx, uniq(m), "❌ " + tr("ركلة جزاء ضائعة ", "Penalty missed ") + e.minute, e.player + " • " + team + "\n" + score, m.id)
                    }
                }
                // أهداف أُلغيت (اختفت من الأحداث)
                if (Football.notifyGoals) seen.filter { it.startsWith("goal|") || it.startsWith("pen|") || it.startsWith("owngoal|") }.filter { it !in keys }.forEach { k ->
                    val parts = k.split("|")
                    show(ctx, uniq(m), "❌ " + tr("إلغاء هدف", "Goal disallowed"), tr("أُلغي هدف ", "Disallowed goal by ") + parts.getOrElse(2) { "" } + " " + parts.getOrElse(1) { "" } + "\n" + score, m.id)
                    goalNotified = true
                }
            }
            Extras.pb("fbn_evinit_${m.id}", true)
            Extras.ps(seenKey, keys.joinToString("\u0001"))
        }

        if (!first && prev != cur) {
            val h = hs ?: 0; val a = aws ?: 0
            if (!goalNotified && Football.notifyGoals && (h > phs.coerceAtLeast(0) || a > pas.coerceAtLeast(0)) && (phs >= 0 || pas >= 0 || m.live)) {
                val team = if (h > phs.coerceAtLeast(0)) m.homeAr else m.awayAr
                show(ctx, uniq(m), "⚽ " + tr("هدف لـ ", "GOAL for ") + team + "!", score, m.id)
            }
            if (!goalNotified && Football.notifyGoals && phs >= 0 && pas >= 0 && (h < phs || a < pas)) show(ctx, uniq(m), "❌ " + tr("إلغاء هدف - تعديل النتيجة", "Goal disallowed - score corrected"), score, m.id)
            if (m.status == "HT" && pst != "HT" && Football.notifyEnd) show(ctx, nid + 2, "⏸️ " + tr("نهاية الشوط الأول", "Half-time"), score, m.id)
            if (m.status == "2H" && pst == "HT" && Football.notifyStart) show(ctx, nid + 7, "▶️ " + tr("بداية الشوط الثاني", "Second half"), score, m.id)
            if (m.finished && pst !in Football.doneCodes && Football.notifyEnd) {
                val res = when { h > a -> tr("🏆 فوز ", "🏆 Win for ") + m.homeAr; a > h -> tr("🏆 فوز ", "🏆 Win for ") + m.awayAr; else -> tr("🤝 تعادل", "🤝 Draw") }
                val scorers = det?.events?.filter { it.isGoal }?.joinToString("\n") { "⚽ " + it.player + " " + it.minute + " (" + (TeamAr.name(it.team).ifBlank { if (it.home == true) m.homeAr else m.awayAr }) + ")" }.orEmpty()
                show(ctx, nid + 3, "🏁 " + tr("نهاية المباراة: ", "Full-time: ") + score, res + (if (scorers.isNotBlank()) "\n$scorers" else "") + tr("\nشاهد الملخص داخل التطبيق", "\nWatch highlights in the app"), m.id)
            }
        }
        return active
    }

    /** يفحص المباريات ويرسل الإشعارات؛ يعيد true إذا كانت هناك مباراة جارية أو وشيكة */
    fun check(ctx: Context): Boolean {
        if (!Football.notify) return false
        val now = System.currentTimeMillis()
        var active = false
        val fav = Football.favTeamId
        if (fav.isBlank() && Football.followedMatches().isEmpty() && !Football.notifyAllFavLeague) return false
        val wanted = buildSet {
            if (Football.notifyAllFavLeague) add(Football.favLeague)
            if (fav.isNotBlank()) { if (Football.favTeamLeague.isNotBlank()) add(Football.favTeamLeague) else addAll(Football.leagues().map { it.id }) }
            addAll(Football.followLeagues())
        }
        for (l in Football.leagues().filter { it.id in wanted }) {
            val list = runCatching { Football.around(l, live = true) }.getOrDefault(emptyList()).filter { watched(it) }
                .filter { kotlin.math.abs(it.time - now) < 2 * 24 * 3600_000L }
            for (m in list) runCatching { checkMatch(ctx, m, now) }.getOrNull()?.let { if (it) active = true }
        }
        return active
    }
}

class FootballWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val active = runCatching { FootballAlerts.check(applicationContext) }.getOrDefault(false)
        if (active) FootballAlerts.scheduleLive(applicationContext, 75)
        return Result.success()
    }
}
