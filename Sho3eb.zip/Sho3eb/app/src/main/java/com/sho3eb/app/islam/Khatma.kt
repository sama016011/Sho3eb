package com.sho3eb.app.islam

import com.sho3eb.app.core.Extras
import com.sho3eb.app.core.Fmt
import kotlin.math.ceil

/** خطة ختم القرآن والورد اليومي (604 صفحة) */
object Khatma {
    const val PAGES = 604
    val active get() = Extras.khatmaStart >= 0

    fun start(days: Int, fromPage: Int = 1) {
        Extras.khatmaDays = days.coerceIn(1, 3650)
        Extras.khatmaStart = Fmt.today()
        Extras.khatmaStartPage = fromPage.coerceIn(1, PAGES)
        Extras.khatmaDone = fromPage.coerceIn(1, PAGES) - 1
    }

    fun stop() { Extras.khatmaStart = -1L }

    val perDay get() = ceil((PAGES - Extras.khatmaStartPage + 1).toDouble() / Extras.khatmaDays).toInt().coerceAtLeast(1)

    /** رقم اليوم في الخطة (يبدأ من 1) */
    val dayNo get() = ((Fmt.today() - Extras.khatmaStart).toInt() + 1).coerceAtLeast(1)

    /** صفحات ورد اليوم حسب الخطة */
    fun todayTarget(): IntRange {
        val s = Extras.khatmaStartPage
        val end = (s - 1 + perDay * dayNo).coerceAtMost(PAGES)
        val begin = (s + perDay * (dayNo - 1)).coerceAtMost(PAGES)
        return begin..end
    }

    val progress get() = ((Extras.khatmaDone - Extras.khatmaStartPage + 1).toFloat() / (PAGES - Extras.khatmaStartPage + 1)).coerceIn(0f, 1f)

    /** الفرق بين ما قُرئ والمطلوب حتى اليوم (سالب = متأخر) */
    val ahead get() = Extras.khatmaDone - todayTarget().last

    fun markRead(upToPage: Int) {
        Extras.khatmaDone = upToPage.coerceIn(0, PAGES)
        if (Extras.khatmaDone >= PAGES) {
            Extras.khatmaCount = Extras.khatmaCount + 1
        }
    }

    val finished get() = Extras.khatmaDone >= PAGES
}
