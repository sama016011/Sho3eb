@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

// =====================================================================
//                    المحل والمخزون والفواتير
// =====================================================================
@Composable
fun ShopScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val invs by flowState(emptyList<Invoice>()) { dao.invoicesFlow() }
    val items by flowState(emptyList<InvoiceItem>()) { dao.invoiceItemsFlow() }
    val pays by flowState(emptyList<InvoicePayment>()) { dao.invoicePaymentsFlow() }
    val products by flowState(emptyList<Product>()) { dao.productsFlow() }
    val adjs by flowState(emptyList<StockAdj>()) { dao.stockAdjsFlow() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var range by rememberSaveable { mutableIntStateOf(1) }
    var typeFilter by rememberSaveable { mutableStateOf("ALL") }
    var q by rememberSaveable { mutableStateOf("") }
    var settings by remember { mutableStateOf(false) }
    var newMenu by remember { mutableStateOf(false) }
    var editProduct by remember { mutableStateOf<Product?>(null) }
    var newProduct by remember { mutableStateOf(false) }
    var adjFor by remember { mutableStateOf<Product?>(null) }
    var party by remember { mutableStateOf<Shop.Party?>(null) }
    var partyCustomers by rememberSaveable { mutableStateOf(true) }

    val rows = remember(invs, items, pays) { Shop.rows(invs, items, pays) }
    val stock = remember(products, invs, items, adjs) { Shop.stockMap(products, invs, items, adjs) }
    val now = LocalDate.now()
    val rng: LongRange? = when (range) {
        0 -> Fmt.today()..Fmt.today()
        1 -> LivingAuto.monthRange()
        2 -> now.withDayOfYear(1).toEpochDay()..now.withDayOfYear(now.lengthOfYear()).toEpochDay()
        else -> null
    }
    val st = Shop.stats(rows, items, rng)
    val low = products.filter { Shop.isLow(it, stock[it.id] ?: 0.0) }
    val customers = remember(rows) { Shop.parties(rows, true) }
    val suppliers = remember(rows) { Shop.parties(rows, false) }

    ScreenScaffold(
        title = Extras.shopName.ifBlank { tr("المحل والفواتير", "Shop & invoices") }, onBack = { nav.popBackStack() },
        actions = {
            IconButton(onClick = { nav.navigate("manufacture") }) { Icon(Icons.Filled.PrecisionManufacturing, null) }
            PdfShareButton(null, doc = { Docs.shop(rows, items, products, stock, rng) }) { c -> Reports.doc(c, Docs.shop(rows, items, products, stock, rng)) }
            IconButton(onClick = { settings = true }) { Icon(Icons.Filled.Settings, null) }
        },
        fab = {
            when (tab) {
                2 -> ExtendedFloatingActionButton(onClick = { newProduct = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("صنف", "Item")) })
                else -> Box {
                    ExtendedFloatingActionButton(onClick = { newMenu = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("فاتورة", "Invoice")) })
                    DropdownMenu(newMenu, { newMenu = false }) {
                        Shop.types.forEach { t -> DropdownMenuItem(text = { Text(t.emoji + "  " + t.label) }, onClick = { newMenu = false; nav.navigate("invoice_edit/${t.key}/0") }) }
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(tab, edgePadding = 8.dp) {
                listOf(tr("الملخص", "Overview"), tr("الفواتير", "Invoices"), tr("الأصناف والمخزون", "Items & stock"), tr("العملاء والموردون", "Customers")).forEachIndexed { i, t ->
                    Tab(tab == i, { tab = i }, text = { Text(t) })
                }
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ShopNavTile("🧾", tr("المبيعات", "Sales"), Modifier.weight(1f)) { nav.navigate("shop_side/CUSTOMER") }
                                ShopNavTile("📦", tr("المشتريات", "Purchases"), Modifier.weight(1f)) { nav.navigate("shop_side/SUPPLIER") }
                                ShopNavTile("📒", tr("الحسابات", "Accounts"), Modifier.weight(1f)) { nav.navigate("shop_accounts") }
                            }
                        }
                        item {
                            HChips {
                                listOf(tr("اليوم", "Today"), tr("هذا الشهر", "This month"), tr("هذه السنة", "This year"), tr("الكل", "All")).forEachIndexed { i, t -> FilterChip(range == i, { range = i }, label = { Text(t) }) }
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text(tr("صافي المبيعات", "Net sales"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                                    Text(Fmt.money(st.net), color = MaterialTheme.colorScheme.onPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                    Text(tr("${st.count} فاتورة • مجمل الربح ", "${st.count} invoices • gross profit ") + Fmt.money(st.profit), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard(tr("المحصّل", "Collected"), Fmt.money(st.collected), Icons.Filled.Payments, SuccessGreen, Modifier.weight(1f))
                                StatCard(tr("المشتريات", "Purchases"), Fmt.money(st.purchases), Icons.Filled.LocalShipping, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard(tr("ديون العملاء", "Customers owe"), Fmt.money(customers.sumOf { it.remaining.coerceAtLeast(0.0) }), Icons.Filled.CallReceived, WarnAmber, Modifier.weight(1f))
                                StatCard(tr("عليّ للموردين", "I owe suppliers"), Fmt.money(suppliers.sumOf { it.remaining.coerceAtLeast(0.0) }), Icons.Filled.CallMade, DangerRed, Modifier.weight(1f))
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard(tr("قيمة المخزون", "Stock value"), Fmt.money(products.filter { it.trackStock }.sumOf { (stock[it.id] ?: 0.0).coerceAtLeast(0.0) * it.cost }), Icons.Filled.Inventory, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f))
                                StatCard(tr("الضريبة", "Tax"), Fmt.money(st.tax), Icons.Filled.Percent, MaterialTheme.colorScheme.outline, Modifier.weight(1f))
                            }
                        }
                        if (low.isNotEmpty()) {
                            item { SectionTitle(tr("⚠️ أصناف قاربت على النفاد", "⚠️ Low stock")) }
                            items(low.take(10), key = { "low${it.id}" }) { p ->
                                Card(onClick = { adjFor = p }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.08f))) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(p.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                        Text(Fmt.num(stock[p.id] ?: 0.0) + " " + p.unit, color = DangerRed, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        val top = Shop.topItems(rows, items, rng).take(5)
                        if (top.isNotEmpty()) {
                            item { SectionTitle(tr("الأكثر مبيعاً", "Top sellers")) }
                            items(top) { t ->
                                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(t.name, Modifier.weight(1f))
                                    Text(Fmt.num(t.qty) + " • " + Fmt.money(t.amount), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        val late = rows.filter { it.overdue }
                        if (late.isNotEmpty()) {
                            item { SectionTitle(tr("فواتير متأخرة السداد", "Overdue invoices")) }
                            items(late.take(10), key = { "late${it.inv.id}" }) { r -> InvoiceCard(r) { nav.navigate("invoice/${r.inv.id}") } }
                        }
                        if (invs.isEmpty()) item {
                            InfoBanner(tr("ابدأ بإضافة أصنافك (اختياري) ثم أنشئ فاتورة بيع أو شراء أو عرض سعر. المخزون يُحدَّث تلقائياً مع كل فاتورة، وتُحسب الأرباح وديون العملاء والموردين.",
                                "Add your items (optional), then create sales, purchase or quotation invoices. Stock, profit and balances update automatically."))
                        }
                    }
                    1 -> {
                        item { SearchField(q) { q = it } }
                        item {
                            HChips {
                                FilterChip(typeFilter == "ALL", { typeFilter = "ALL" }, label = { Text(tr("الكل", "All")) })
                                FilterChip(typeFilter == "DUE", { typeFilter = "DUE" }, label = { Text(tr("غير مسددة", "Unpaid")) })
                                FilterChip(typeFilter == "INST", { typeFilter = "INST" }, label = { Text(tr("بالتقسيط", "Installments")) })
                                Shop.types.forEach { t -> FilterChip(typeFilter == t.key, { typeFilter = t.key }, label = { Text(t.label) }) }
                            }
                        }
                        val list = rows.filter { r ->
                            (typeFilter == "ALL" || (typeFilter == "DUE" && Shop.isMoney(r.inv.type) && !r.isPaid) || (typeFilter == "INST" && r.hasInst) || r.inv.type == typeFilter) &&
                                (q.isBlank() || r.inv.partyName.contains(q, true) || Shop.numberText(r.inv).contains(q, true) || r.inv.partyPhone.contains(q) || r.inv.notes.contains(q, true))
                        }
                        if (list.isEmpty()) item { EmptyState(Icons.Filled.Receipt, tr("لا توجد فواتير", "No invoices")) }
                        items(list, key = { it.inv.id }) { r -> InvoiceCard(r) { nav.navigate("invoice/${r.inv.id}") } }
                    }
                    2 -> {
                        item { SearchField(q) { q = it } }
                        val list = products.filter { q.isBlank() || it.name.contains(q, true) || it.sku.contains(q, true) || it.category.contains(q, true) }
                        if (list.isEmpty()) item { EmptyState(Icons.Filled.Inventory2, tr("أضف أصنافك بأسعار الشراء والبيع لمتابعة المخزون والأرباح", "Add items with cost and price to track stock and profit")) }
                        items(list, key = { it.id }) { p ->
                            val qty = stock[p.id] ?: 0.0
                            Card(onClick = { nav.navigate("product/${p.id}") }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(p.name + if (!p.active) tr(" (موقوف)", " (inactive)") else "", fontWeight = FontWeight.SemiBold)
                                        Text(listOf(p.sku, p.category).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { tr("بدون كود", "No SKU") }, style = MaterialTheme.typography.bodySmall)
                                        Text(tr("الشراء ", "Cost ") + Fmt.num(p.cost) + tr(" • البيع ", " • Price ") + Fmt.num(p.price), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (p.trackStock) Column(horizontalAlignment = Alignment.End) {
                                        Text(Fmt.num(qty), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (Shop.isLow(p, qty)) DangerRed else MaterialTheme.colorScheme.onSurface)
                                        Text(p.unit.ifBlank { tr("قطعة", "pcs") }, style = MaterialTheme.typography.bodySmall)
                                    }
                                    IconButton(onClick = { editProduct = p }) { Icon(Icons.Filled.Edit, null) }
                                    IconButton(onClick = { adjFor = p }) { Icon(Icons.Filled.Tune, null) }
                                }
                            }
                        }
                    }
                    else -> {
                        item {
                            HChips {
                                FilterChip(partyCustomers, { partyCustomers = true }, label = { Text(tr("العملاء (${customers.size})", "Customers (${customers.size})")) })
                                FilterChip(!partyCustomers, { partyCustomers = false }, label = { Text(tr("الموردون (${suppliers.size})", "Suppliers (${suppliers.size})")) })
                            }
                        }
                        val list = if (partyCustomers) customers else suppliers
                        if (list.isEmpty()) item { EmptyState(Icons.Filled.People, tr("يظهر هنا كل من تعاملت معه في الفواتير مع رصيده", "Everyone you invoiced appears here with a balance")) }
                        items(list, key = { it.key }) { p ->
                            Card(onClick = {
                                val pid = rows.firstOrNull { Shop.isMoney(it.inv.type) && Shop.isCustomerSide(it.inv.type) == p.customer && Shop.partyKey(it.inv) == p.key && it.inv.partyId != null }?.inv?.partyId
                                if (pid != null) nav.navigate("party/$pid") else party = p
                            }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Avatar(null, p.name, 40.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(p.name, fontWeight = FontWeight.SemiBold)
                                        Text(tr("${p.count} فاتورة • ", "${p.count} invoices • ") + Fmt.money(p.total), style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (p.remaining > 0.01) Column(horizontalAlignment = Alignment.End) {
                                        Text(Fmt.money(p.remaining), fontWeight = FontWeight.Bold, color = if (p.customer) WarnAmber else DangerRed)
                                        Text(if (p.customer) tr("له دين", "owes") else tr("عليّ", "I owe"), style = MaterialTheme.typography.bodySmall)
                                    } else Icon(Icons.Filled.CheckCircle, null, tint = SuccessGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (settings) ShopSettingsDialog { settings = false }
    if (newProduct) ProductDialog(null) { newProduct = false }
    editProduct?.let { p -> ProductDialog(p) { editProduct = null } }
    adjFor?.let { p -> StockAdjDialog(p, stock[p.id] ?: 0.0, adjs.filter { it.productId == p.id }) { adjFor = null } }
    party?.let { p ->
        val doc = { Docs.party(p, rows) }
        AlertDialog(
            onDismissRequest = { party = null },
            title = { Text(p.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    KeyValue(tr("الإجمالي", "Total"), Fmt.money(p.total))
                    KeyValue(tr("المدفوع", "Paid"), Fmt.money(p.paid), SuccessGreen)
                    KeyValue(tr("المتبقي", "Balance"), Fmt.money(p.remaining), if (p.remaining > 0.01) DangerRed else SuccessGreen)
                    HorizontalDivider()
                    rows.filter { Shop.isMoney(it.inv.type) && Shop.isCustomerSide(it.inv.type) == p.customer && Shop.partyKey(it.inv) == p.key }.forEach { r ->
                        Row(Modifier.fillMaxWidth().clickable { party = null; nav.navigate("invoice/${r.inv.id}") }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(Shop.numberText(r.inv) + " • " + Fmt.date(r.inv.date), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            Text(Fmt.num(r.t.total), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = if (r.isPaid) SuccessGreen else if (r.overdue) DangerRed else WarnAmber)
                        }
                    }
                }
            },
            confirmButton = {
                Row {
                    PdfShareButton(p.phone.ifBlank { null }, doc = doc) { c -> Reports.doc(c, doc()) }
                    if (p.phone.isNotBlank() && p.remaining > 0.01 && p.customer) IconButton(onClick = {
                        Share.whatsappMessage(ctx, p.phone, tr("السلام عليكم ${p.name}، نذكركم بالرصيد المتبقي ${Fmt.money(p.remaining)}. شاكرين تعاملكم.", "Hello ${p.name}, a reminder of your balance ${Fmt.money(p.remaining)}. Thank you."))
                    }) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                    TextButton(onClick = { party = null }) { Text(tr("إغلاق", "Close")) }
                }
            }
        )
    }
}

@Composable
private fun ShopNavTile(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 24.sp)
            Text(label, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun InvoiceCard(r: Shop.InvRow, onClick: () -> Unit) {
    val t = Shop.type(r.inv.type)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(t.emoji, fontSize = 24.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(Shop.numberText(r.inv) + (if (r.inv.partyName.isNotBlank()) " • " + r.inv.partyName else ""), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.label + " • " + Fmt.date(r.inv.date), style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.money(r.t.total), fontWeight = FontWeight.Bold)
                when {
                    !Shop.isMoney(r.inv.type) -> Text(if (r.inv.status == "CONVERTED") tr("تم تحويله", "Converted") else tr("عرض", "Quote"), style = MaterialTheme.typography.bodySmall)
                    r.isPaid -> Text(tr("مدفوعة", "Paid"), color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                    r.hasInst -> Text(tr("💳 أقساط ", "💳 Inst. ") + "${r.schedule.count { it.isPaid }}/${r.schedule.size}", color = if (r.overdue) DangerRed else WarnAmber, style = MaterialTheme.typography.bodySmall)
                    r.overdue -> Text(tr("متأخر ", "Late ") + Fmt.num(r.remaining), color = DangerRed, style = MaterialTheme.typography.bodySmall)
                    else -> Text(tr("متبقي ", "Due ") + Fmt.num(r.remaining), color = WarnAmber, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun ShopSettingsDialog(onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(Extras.shopName) }
    var phone by remember { mutableStateOf(Extras.shopPhone) }
    var address by remember { mutableStateOf(Extras.shopAddress) }
    var taxNo by remember { mutableStateOf(Extras.shopTaxNo) }
    var tax by remember { mutableStateOf(if (Extras.shopTax > 0) Fmt.plain(Extras.shopTax) else "") }
    var footer by remember { mutableStateOf(Extras.shopFooter) }
    val acc = remember { mutableStateOf(Extras.shopAccount.takeIf { it > 0 }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("بيانات المحل", "Shop details")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("تظهر في رأس الفواتير وملفات PDF", "Shown on invoices and PDFs"), style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم المحل", "Shop name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text(tr("الهاتف", "Phone")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(address, { address = it }, label = { Text(tr("العنوان", "Address")) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(taxNo, { taxNo = it }, label = { Text(tr("الرقم الضريبي / السجل (اختياري)", "Tax / registration no. (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                NumberField(tax, { tax = it }, tr("نسبة الضريبة الافتراضية % (مثل 15)", "Default tax % (e.g. 15)"))
                OutlinedTextField(footer, { footer = it }, label = { Text(tr("تذييل الفاتورة (شكراً لزيارتكم...)", "Invoice footer")) }, modifier = Modifier.fillMaxWidth())
                AccountPickRow(acc, tr("الحساب الافتراضي للصندوق", "Default cash account"))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Extras.shopName = name; Extras.shopPhone = phone; Extras.shopAddress = address; Extras.shopTaxNo = taxNo
                Extras.shopTax = Fmt.parse(tax) ?: 0.0; Extras.shopFooter = footer; Extras.shopAccount = acc.value ?: -1L
                onDismiss()
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun ProductDialog(existing: Product?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var sku by remember { mutableStateOf(existing?.sku ?: "") }
    var cat by remember { mutableStateOf(existing?.category ?: "") }
    var unit by remember { mutableStateOf(existing?.unit ?: "") }
    var cost by remember { mutableStateOf(existing?.cost?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var price by remember { mutableStateOf(existing?.price?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var opening by remember { mutableStateOf(existing?.openingQty?.takeIf { it != 0.0 }?.let { Fmt.plain(it) } ?: "") }
    var minQ by remember { mutableStateOf(existing?.minQty?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var track by remember { mutableStateOf(existing?.trackStock ?: true) }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var del by remember { mutableStateOf(false) }
    val c = Fmt.parse(cost) ?: 0.0; val pr = Fmt.parse(price) ?: 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("صنف جديد", "New item") else existing.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم الصنف", "Item name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(sku, { sku = it }, label = { Text(tr("الكود / الباركود", "SKU / barcode")) }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(unit, { unit = it }, label = { Text(tr("الوحدة", "Unit")) }, placeholder = { Text(tr("قطعة", "pcs")) }, singleLine = true, modifier = Modifier.weight(0.7f))
                }
                OutlinedTextField(cat, { cat = it }, label = { Text(tr("التصنيف (اختياري)", "Category (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyField(cost, { cost = it }, tr("سعر الشراء", "Cost"), Modifier.weight(1f))
                    MoneyField(price, { price = it }, tr("سعر البيع", "Price"), Modifier.weight(1f))
                }
                if (pr > 0 && c > 0) Text(tr("ربح الوحدة: ", "Unit profit: ") + Fmt.money(pr - c) + " (" + Fmt.num((pr - c) / c * 100) + "%)", color = if (pr >= c) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                SwitchRow(tr("متابعة المخزون", "Track stock"), null, track) { track = it }
                if (track) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField(opening, { opening = it }, tr("الكمية الافتتاحية", "Opening qty"), Modifier.weight(1f))
                    NumberField(minQ, { minQ = it }, tr("تنبيه عند (حد أدنى)", "Alert at (min)"), Modifier.weight(1f))
                }
                if (existing != null) SwitchRow(tr("نشط", "Active"), null, active) { active = it }
                NotesField(notes) { notes = it }
                if (existing != null) {
                    AttachmentButton(Attachments.PRODUCT, existing.id)
                    TextButton(onClick = { del = true }) { Text(tr("حذف الصنف", "Delete item"), color = DangerRed) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل اسم الصنف", "Enter a name")); return@TextButton }
                val p = Product(name = name.trim(), sku = sku.trim(), category = cat.trim(), unit = unit.trim(), cost = c, price = pr,
                    openingQty = Fmt.parse(opening) ?: 0.0, minQty = Fmt.parse(minQ) ?: 0.0, trackStock = track, active = active, notes = notes.trim())
                scope.launch { if (existing == null) dao.insertProduct(p) else dao.updateProduct(p.copy(id = existing.id, createdAt = existing.createdAt)); onDismiss() }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
    if (del && existing != null) ConfirmDialog(tr("حذف الصنف", "Delete item"), tr("سيبقى الصنف ظاهراً في الفواتير القديمة كنص.", "It stays in old invoices as text."), onDismiss = { del = false }) {
        scope.launch { Attachments.deleteFor(Attachments.PRODUCT, existing.id); dao.deleteProductFull(existing.id); del = false; onDismiss() }
    }
}

@Composable
private fun StockAdjDialog(p: Product, qty: Double, history: List<StockAdj>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var mode by remember { mutableIntStateOf(0) } // 0 إضافة، 1 خصم، 2 جرد (تعيين الكمية)
    var v by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("تسوية مخزون: ", "Stock: ") + p.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("الكمية الحالية: ", "Current qty: ") + Fmt.num(qty) + " " + p.unit, fontWeight = FontWeight.Bold)
                HChips {
                    listOf(tr("إضافة", "Add"), tr("خصم (تالف/فاقد)", "Remove (damaged)"), tr("جرد فعلي", "Stocktake")).forEachIndexed { i, t -> FilterChip(mode == i, { mode = i }, label = { Text(t) }) }
                }
                NumberField(v, { v = it }, if (mode == 2) tr("الكمية الفعلية بعد الجرد", "Actual counted qty") else tr("الكمية", "Quantity"))
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
                if (history.isNotEmpty()) {
                    HorizontalDivider()
                    Text(tr("سجل التسويات", "Adjustments"), style = MaterialTheme.typography.labelLarge)
                    history.sortedByDescending { it.date }.take(15).forEach { a ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Fmt.date(a.date) + (if (a.note.isNotBlank()) " • " + a.note else ""), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            Text((if (a.qty > 0) "+" else "") + Fmt.num(a.qty), color = if (a.qty > 0) SuccessGreen else DangerRed, fontWeight = FontWeight.SemiBold)
                            IconButton(onClick = { scope.launch { dao.deleteStockAdj(a.id) } }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val x = Fmt.parse(v) ?: run { toast(ctx, tr("أدخل الكمية", "Enter quantity")); return@TextButton }
                val delta = when (mode) { 0 -> x; 1 -> -x; else -> x - qty }
                if (kotlin.math.abs(delta) < 0.0001) { onDismiss(); return@TextButton }
                val n = note.trim().ifBlank { when (mode) { 0 -> tr("إضافة", "Added"); 1 -> tr("تالف / فاقد", "Damaged / lost"); else -> tr("جرد", "Stocktake") } }
                scope.launch { dao.insertStockAdj(StockAdj(productId = p.id, qty = delta, date = Fmt.today(), note = n)); onDismiss() }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
}

// =====================================================================
//                      إنشاء / تعديل فاتورة
// =====================================================================
private data class Line(val productId: Long?, val name: String, val qty: String, val price: String, val cost: Double)

@Composable
fun InvoiceEditScreen(nav: NavController, type0: String, id: Long, party0: Long = 0L) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val products by flowState(emptyList<Product>()) { dao.productsFlow() }
    val allInv by flowState(emptyList<Invoice>()) { dao.invoicesFlow() }
    var loaded by remember { mutableStateOf(id == 0L) }
    var existing by remember { mutableStateOf<Invoice?>(null) }
    var type by rememberSaveable { mutableStateOf(type0) }
    var partyName by rememberSaveable { mutableStateOf("") }
    var partyPhone by rememberSaveable { mutableStateOf("") }
    var personId by remember { mutableStateOf<Long?>(null) }
    var partyId by rememberSaveable { mutableStateOf<Long?>(party0.takeIf { it > 0 }) }
    val regParties by flowState(emptyList<Party>()) { dao.partysFlow() }
    var pickParty by remember { mutableStateOf(false) }
    var addParty by remember { mutableStateOf(false) }
    var scanPhoto by remember { mutableStateOf<java.io.File?>(null) }
    LaunchedEffect(regParties.size, partyId) {
        val pp = regParties.firstOrNull { it.id == partyId }
        if (pp != null && partyName.isBlank()) { partyName = pp.name; partyPhone = pp.phone; personId = pp.personId }
    }
    var date by rememberSaveable { mutableStateOf(Fmt.today()) }
    var credit by rememberSaveable { mutableStateOf(false) }
    var due by rememberSaveable { mutableStateOf(LocalDate.now().plusDays(30).toEpochDay()) }
    var discount by rememberSaveable { mutableStateOf("") }
    var taxPct by rememberSaveable { mutableStateOf(if (Extras.shopTax > 0) Fmt.plain(Extras.shopTax) else "") }
    var notes by rememberSaveable { mutableStateOf("") }
    val lines = remember { mutableStateListOf<Line>() }
    var pickProduct by remember { mutableStateOf(false) }
    var paidNow by rememberSaveable { mutableStateOf<String?>(null) }
    var inst by rememberSaveable { mutableStateOf(false) }
    var instN by rememberSaveable { mutableStateOf("6") }
    var instMonths by rememberSaveable { mutableIntStateOf(1) }
    var instStart by rememberSaveable { mutableStateOf(LocalDate.now().plusMonths(1).toEpochDay()) }
    var instDown by rememberSaveable { mutableStateOf("") }
    var method by rememberSaveable { mutableStateOf("CASH") }
    val acc = remember { mutableStateOf(Extras.shopAccount.takeIf { it > 0 }) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (id != 0L) {
            val inv = dao.allInvoices().firstOrNull { it.id == id }
            if (inv != null) {
                existing = inv; type = inv.type; partyId = inv.partyId; partyName = inv.partyName; partyPhone = inv.partyPhone; personId = inv.personId
                date = inv.date; credit = inv.dueDate != null && inv.instCount == 0; inv.dueDate?.let { due = it }
                inst = inv.instCount > 0
                if (inst) { instN = inv.instCount.toString(); instMonths = inv.instMonths; inv.instStart?.let { instStart = it }; instDown = if (inv.instDown > 0) Fmt.plain(inv.instDown) else "" }
                discount = if (inv.discount > 0) Fmt.plain(inv.discount) else ""; taxPct = if (inv.taxPct > 0) Fmt.plain(inv.taxPct) else ""; notes = inv.notes
                lines.clear(); dao.itemsOfInvoice(id).forEach { lines += Line(it.productId, it.name, Fmt.plain(it.qty), Fmt.plain(it.price), it.cost) }
            }
            loaded = true
        }
    }

    val isSaleSide = Shop.isCustomerSide(type)
    fun priceFor(p: Product) = if (type == Shop.PURCHASE || type == Shop.PRETURN) p.cost else p.price
    val draftInv = Invoice(type = type, date = date, discount = Fmt.parse(discount) ?: 0.0, taxPct = Fmt.parse(taxPct) ?: 0.0)
    val draftItems = lines.map { InvoiceItem(invoiceId = 0, productId = it.productId, name = it.name, qty = Fmt.parse(it.qty) ?: 0.0, price = Fmt.parse(it.price) ?: 0.0, cost = it.cost) }
    val tot = Shop.totals(draftInv, draftItems)
    val pastParties = remember(allInv, type) {
        allInv.filter { Shop.isCustomerSide(it.type) == Shop.isCustomerSide(type) && it.partyName.isNotBlank() }.distinctBy { it.partyName.trim() }.take(30)
    }

    fun save() {
        if (lines.isEmpty()) { toast(ctx, tr("أضف صنفاً واحداً على الأقل", "Add at least one item")); return }
        if (draftItems.any { it.name.isBlank() || it.qty <= 0 }) { toast(ctx, tr("تأكد من اسم وكمية كل صنف", "Check item names and quantities")); return }
        busy = true
        scope.launch {
            val number = existing?.takeIf { it.type == type }?.number ?: Shop.nextNumber(dao, type)
            val useInst = inst && (type == Shop.SALE || type == Shop.PURCHASE) && (Fmt.parseInt(instN) ?: 0) > 0
            val nInst = if (useInst) (Fmt.parseInt(instN) ?: 1).coerceIn(1, 120) else 0
            val lastDue = if (useInst) LocalDate.ofEpochDay(instStart).plusMonths((nInst - 1).toLong() * instMonths).toEpochDay() else null
            val inv0 = Invoice(
                id = existing?.id ?: 0, type = type, number = number, partyName = partyName.trim(), partyPhone = partyPhone.trim(), personId = personId,
                date = date, dueDate = if (credit && Shop.isMoney(type)) due else null, discount = tot.discount, taxPct = Fmt.parse(taxPct) ?: 0.0,
                status = existing?.status ?: "", notes = notes.trim(), createdAt = existing?.createdAt ?: System.currentTimeMillis()
            )
            val inv = if (useInst) inv0.copy(instCount = nInst, instMonths = instMonths, instStart = instStart, instDown = (Fmt.parse(instDown) ?: 0.0).coerceIn(0.0, tot.total), dueDate = lastDue)
                else inv0.copy(instCount = 0, instStart = null, instDown = 0.0)
            var pid0 = partyId?.takeIf { id0 -> regParties.any { it.id == id0 && it.type == Parties.typeOf(type) } }
            if (pid0 == null && partyName.isNotBlank()) {
                val side = Parties.typeOf(type)
                val match = regParties.firstOrNull { it.type == side && (it.name.trim().equals(partyName.trim(), true) || (partyPhone.isNotBlank() && it.phone.filter { c -> c.isDigit() }.takeLast(9) == partyPhone.filter { c -> c.isDigit() }.takeLast(9))) }
                pid0 = match?.id ?: dao.insertParty(Party(code = Parties.nextCode(dao, side), name = partyName.trim(), type = side, phone = partyPhone.trim(), personId = personId))
            }
            val newId = dao.saveInvoice(inv.copy(partyId = pid0), draftItems)
            scanPhoto?.let { f -> runCatching { Attachments.registerFile(Attachments.INVOICE, newId, f) } }
            if (existing == null && Shop.isMoney(type)) {
                val pay = Fmt.parse(paidNow ?: Fmt.plain(if (useInst) (Fmt.parse(instDown) ?: 0.0) else if (credit) 0.0 else tot.total)) ?: 0.0
                if (pay > 0) {
                    val pid = dao.insertInvoicePayment(InvoicePayment(invoiceId = newId, amount = minOf(pay, tot.total), date = date, method = method))
                    Posting.post(acc.value, AccountTx.SRC_INV, pid, Shop.isIncoming(type), minOf(pay, tot.total), date, Shop.type(type).label + " " + Shop.prefix(type) + "-" + number + (if (partyName.isNotBlank()) " • " + partyName.trim() else ""))
                }
            }
            busy = false
            toast(ctx, tr("تم الحفظ ✅", "Saved ✅"))
            nav.popBackStack()
            if (existing == null) nav.navigate("invoice/$newId")
        }
    }

    ScreenScaffold(
        title = if (existing == null) Shop.type(type).label + tr(" جديدة", " (new)") else tr("تعديل ", "Edit ") + Shop.numberText(existing!!),
        onBack = { nav.popBackStack() },
        actions = { TextButton(onClick = { save() }, enabled = !busy && loaded) { Text(tr("حفظ", "Save"), fontWeight = FontWeight.Bold) } }
    ) { pad ->
        if (!loaded) { Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return@ScreenScaffold }
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 60.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (existing == null) item { HChips { Shop.types.forEach { t -> FilterChip(type == t.key, { type = t.key }, label = { Text(t.emoji + " " + t.label) }) } } }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (isSaleSide) tr("العميل (اختياري)", "Customer (optional)") else tr("المورد", "Supplier"), style = MaterialTheme.typography.labelLarge)
                        val curParty = regParties.firstOrNull { it.id == partyId }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = { pickParty = true }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Filled.Badge, null); Spacer(Modifier.width(4.dp))
                                Text(curParty?.let { it.code + " • " + it.name } ?: if (isSaleSide) tr("عميل مسجّل", "Registered customer") else tr("مورد مسجّل", "Registered supplier"), maxLines = 1)
                            }
                            OutlinedButton(onClick = { addParty = true }) { Icon(Icons.Filled.PersonAdd, null) }
                        }
                        PersonSelector(null, tr("اختيار من جهات الاتصال", "Pick from contacts")) { p -> partyName = p.name; partyPhone = p.phone; personId = p.id; partyId = null }
                        OutlinedTextField(partyName, { partyName = it; personId = null; partyId = null }, label = { Text(tr("الاسم", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(partyPhone, { partyPhone = it }, label = { Text(tr("الجوال", "Phone")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                        if (pastParties.isNotEmpty() && partyName.isBlank()) HChips {
                            pastParties.forEach { i -> AssistChip({ partyName = i.partyName; partyPhone = i.partyPhone; personId = i.personId; partyId = i.partyId }, label = { Text(i.partyName) }) }
                        }
                        DateField(tr("تاريخ الفاتورة", "Invoice date"), date, { d -> if (d != null) date = d })
                        if (Shop.isMoney(type) && !inst) {
                            SwitchRow(tr("بيع/شراء آجل (بموعد سداد)", "On credit (with due date)"), null, credit) { credit = it }
                            if (credit) DateField(tr("تاريخ الاستحقاق", "Due date"), due, { d -> if (d != null) due = d })
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr("الأصناف", "Items") + " (${lines.size})", Modifier.weight(1f))
                    ScanButton { r, f ->
                        var added = 0
                        r.lines.forEach { x ->
                            val pr = products.firstOrNull { pp -> VoiceParse.norm(pp.name) == VoiceParse.norm(x.name) || (pp.sku.isNotBlank() && x.name.contains(pp.sku, true)) }
                            lines += Line(pr?.id, pr?.name ?: x.name, Fmt.plain(x.qty), Fmt.plain(x.price), pr?.cost ?: 0.0); added++
                        }
                        if (added == 0 && r.total != null) lines += Line(null, r.store.ifBlank { tr("مشتريات", "Purchases") }, "1", Fmt.plain(r.total), 0.0)
                        if (partyName.isBlank() && r.store.isNotBlank() && !isSaleSide) partyName = r.store
                        r.date?.let { date = it }
                        scanPhoto = f
                        toast(ctx, tr("أُضيف $added بند من الفاتورة — راجع الأسعار", "Added $added lines — check prices"))
                    }
                    TextButton(onClick = { lines += Line(null, "", "1", "", 0.0) }) { Icon(Icons.Filled.Add, null); Text(tr("بند حر", "Free line")) }
                    FilledTonalButton(onClick = { pickProduct = true }) { Icon(Icons.Filled.Inventory2, null); Spacer(Modifier.width(4.dp)); Text(tr("من الأصناف", "From items")) }
                }
            }
            if (lines.isEmpty()) item { Text(tr("أضف أصنافاً من قائمة الأصناف أو اكتب بنداً حراً", "Add items from your list or a free line"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            itemsIndexed(lines) { idx, l ->
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(l.name, { lines[idx] = l.copy(name = it) }, label = { Text(tr("الصنف", "Item")) }, singleLine = true, modifier = Modifier.weight(1f))
                            IconButton(onClick = { lines.removeAt(idx) }) { Icon(Icons.Filled.Close, null, tint = DangerRed) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { val q = (Fmt.parse(l.qty) ?: 1.0) - 1; if (q > 0) lines[idx] = l.copy(qty = Fmt.plain(q)) }) { Icon(Icons.Filled.Remove, null) }
                            OutlinedTextField(l.qty, { lines[idx] = l.copy(qty = it) }, label = { Text(tr("الكمية", "Qty")) }, singleLine = true, modifier = Modifier.width(84.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                            IconButton(onClick = { lines[idx] = l.copy(qty = Fmt.plain((Fmt.parse(l.qty) ?: 0.0) + 1)) }) { Icon(Icons.Filled.Add, null) }
                            OutlinedTextField(l.price, { lines[idx] = l.copy(price = it) }, label = { Text(tr("السعر", "Price")) }, singleLine = true, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        }
                        Text(tr("الإجمالي: ", "Line total: ") + Fmt.money((Fmt.parse(l.qty) ?: 0.0) * (Fmt.parse(l.price) ?: 0.0)), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MoneyField(discount, { discount = it }, tr("خصم", "Discount"), Modifier.weight(1f))
                            NumberField(taxPct, { taxPct = it }, tr("ضريبة %", "Tax %"), Modifier.weight(1f))
                        }
                        KeyValue(tr("المجموع", "Subtotal"), Fmt.money(tot.subtotal))
                        if (tot.discount > 0) KeyValue(tr("الخصم", "Discount"), "− " + Fmt.money(tot.discount), DangerRed)
                        if (tot.tax > 0) KeyValue(tr("الضريبة", "Tax"), Fmt.money(tot.tax))
                        HorizontalDivider()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("الإجمالي النهائي", "Grand total"), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            Text(Fmt.money(tot.total), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        if (type == Shop.SALE && tot.cost > 0) Text(tr("الربح المتوقع: ", "Expected profit: ") + Fmt.money(tot.profit), color = if (tot.profit >= 0) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (type == Shop.SALE || type == Shop.PURCHASE) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SwitchRow(tr("💳 بيع/شراء بالتقسيط", "💳 Pay in installments"), tr("جدول أقساط بمواعيد وتذكير لكل قسط", "Schedule with a reminder for each installment"), inst) { inst = it; if (it) credit = false }
                        if (inst) {
                            MoneyField(instDown, { instDown = it }, tr("الدفعة المقدمة (اختياري)", "Down payment (optional)"))
                            HChips { listOf(2, 3, 4, 6, 10, 12, 18, 24).forEach { n -> FilterChip(instN == n.toString(), { instN = n.toString() }, label = { Text("$n") }) } }
                            NumberField(instN, { instN = it.filter { c -> c.isDigit() }.take(3) }, tr("عدد الأقساط", "Number of installments"))
                            Text(tr("كل:", "Every:"), style = MaterialTheme.typography.labelLarge)
                            HChips { listOf(1, 2, 3, 6, 12).forEach { m -> FilterChip(instMonths == m, { instMonths = m }, label = { Text(Rent.periodName(m)) }) } }
                            DateField(tr("تاريخ أول قسط", "First installment date"), instStart, { d -> if (d != null) instStart = d })
                            val n = (Fmt.parseInt(instN) ?: 0).coerceAtLeast(0)
                            val down = (Fmt.parse(instDown) ?: 0.0).coerceIn(0.0, tot.total)
                            if (n > 0 && tot.total > 0) {
                                val each = (tot.total - down) / n
                                val last = LocalDate.ofEpochDay(instStart).plusMonths((n - 1).toLong() * instMonths).toEpochDay()
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                                        Text(tr("القسط: ", "Installment: ") + Fmt.money(each) + " × $n", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        if (down > 0) Text(tr("الدفعة المقدمة: ", "Down payment: ") + Fmt.money(down), style = MaterialTheme.typography.bodySmall)
                                        Text(tr("من ", "From ") + Fmt.date(instStart) + tr(" إلى ", " to ") + Fmt.date(last), style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (existing == null && Shop.isMoney(type)) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("الدفع الآن", "Payment now"), style = MaterialTheme.typography.labelLarge)
                        val shown = paidNow ?: Fmt.plain(if (inst) (Fmt.parse(instDown) ?: 0.0) else if (credit) 0.0 else tot.total)
                        MoneyField(shown, { paidNow = it }, if (Shop.isIncoming(type)) tr("المبلغ المستلم", "Amount received") else tr("المبلغ المدفوع", "Amount paid"))
                        HChips {
                            AssistChip({ paidNow = Fmt.plain(tot.total) }, label = { Text(tr("كامل المبلغ", "Full")) })
                            AssistChip({ paidNow = "0" }, label = { Text(tr("لا شيء (آجل)", "Nothing (credit)")) })
                        }
                        HChips { Shop.methods.forEach { m -> FilterChip(method == m.key, { method = m.key }, label = { Text(m.emoji + " " + m.label) }) } }
                        AccountPickRow(acc, tr("ترحيل إلى حساب (اختياري)", "Post to account (optional)"))
                    }
                }
            }
            item { OutlinedTextField(notes, { notes = it }, label = { Text(tr("ملاحظات تظهر في الفاتورة", "Notes on invoice")) }, modifier = Modifier.fillMaxWidth()) }
            item { Button(onClick = { save() }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(tr("حفظ الفاتورة", "Save invoice"), fontWeight = FontWeight.Bold) } }
        }
    }

    if (pickParty) {
        val side = Parties.typeOf(type)
        PickerDialog(if (isSaleSide) tr("اختر العميل", "Choose customer") else tr("اختر المورد", "Choose supplier"), regParties.filter { it.type == side && it.active }.map { it.id to (it.code + " • " + it.name + if (it.phone.isNotBlank()) " • " + it.phone else "") }, { pickParty = false }) { pid ->
            pickParty = false
            regParties.firstOrNull { it.id == pid }?.let { pp -> partyId = pp.id; partyName = pp.name; partyPhone = pp.phone; personId = pp.personId }
        }
    }
    if (addParty) PartyDialog(null, Parties.typeOf(type)) { nid -> addParty = false; if (nid != null) { partyId = nid; partyName = "" } }
    if (pickProduct) {
        var pq by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pickProduct = false },
            title = { Text(tr("اختر الأصناف", "Pick items")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SearchField(pq) { pq = it }
                    Text(tr("اضغط على الصنف لإضافته، والضغط مرة أخرى يزيد الكمية", "Tap to add; tap again to increase qty"), style = MaterialTheme.typography.bodySmall)
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(products.filter { it.active && (pq.isBlank() || it.name.contains(pq, true) || it.sku.contains(pq, true)) }, key = { it.id }) { p ->
                            val inCart = lines.indexOfFirst { it.productId == p.id }
                            Row(Modifier.fillMaxWidth().clickable {
                                if (inCart >= 0) { val l = lines[inCart]; lines[inCart] = l.copy(qty = Fmt.plain((Fmt.parse(l.qty) ?: 0.0) + 1)) }
                                else lines += Line(p.id, p.name, "1", Fmt.plain(priceFor(p)), p.cost)
                            }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    Text(Fmt.money(priceFor(p)) + if (p.sku.isNotBlank()) " • " + p.sku else "", style = MaterialTheme.typography.bodySmall)
                                }
                                if (inCart >= 0) Badge { Text(lines[inCart].qty) }
                            }
                        }
                    }
                    if (products.isEmpty()) Text(tr("لا توجد أصناف بعد. أضفها من تبويب الأصناف، أو استخدم البند الحر.", "No items yet. Add them in the Items tab or use a free line."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { pickProduct = false }) { Text(tr("تم", "Done")) } }
        )
    }
}

// =====================================================================
//                        عرض الفاتورة
// =====================================================================
@Composable
fun InvoiceScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val inv by flowState<Invoice?>(null, id) { dao.invoiceFlow(id) }
    val allItems by flowState(emptyList<InvoiceItem>()) { dao.invoiceItemsFlow() }
    val allPays by flowState(emptyList<InvoicePayment>()) { dao.invoicePaymentsFlow() }
    val linked = rememberLinkedIds(AccountTx.SRC_INV)
    var pay by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<InvoicePayment?>(null) }
    var postPay by remember { mutableStateOf<InvoicePayment?>(null) }

    val i = inv
    if (i == null) { ScreenScaffold(tr("الفاتورة", "Invoice"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val items = allItems.filter { it.invoiceId == i.id }
    val pays = allPays.filter { it.invoiceId == i.id }
    val r = Shop.InvRow(i, Shop.totals(i, items), round2(pays.sumOf { it.amount }))
    val doc = { Docs.invoice(r, items, pays) }

    ScreenScaffold(
        title = Shop.numberText(i), onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(i.partyPhone.ifBlank { null }, doc = doc) { c -> Reports.doc(c, doc()) }
            IconButton(onClick = { nav.navigate("invoice_edit/${i.type}/${i.id}") }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 60.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Shop.type(i.type).emoji + " " + Shop.type(i.type).label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            when {
                                !Shop.isMoney(i.type) -> StatusChip(if (i.status == "CONVERTED") tr("تم تحويله لفاتورة", "Converted") else tr("عرض سعر", "Quotation"), MaterialTheme.colorScheme.secondary)
                                r.isPaid -> StatusChip(tr("مدفوعة", "Paid"), SuccessGreen)
                                r.overdue -> StatusChip(tr("متأخرة", "Overdue"), DangerRed)
                                r.paid > 0 -> StatusChip(tr("مدفوعة جزئياً", "Partly paid"), WarnAmber)
                                else -> StatusChip(tr("غير مدفوعة", "Unpaid"), WarnAmber)
                            }
                        }
                        KeyValue(tr("التاريخ", "Date"), Fmt.date(i.date))
                        i.dueDate?.let { KeyValue(tr("الاستحقاق", "Due"), Fmt.date(it), if (r.overdue) DangerRed else androidx.compose.ui.graphics.Color.Unspecified) }
                        if (i.partyName.isNotBlank()) KeyValue(if (Shop.isCustomerSide(i.type)) tr("العميل", "Customer") else tr("المورد", "Supplier"), i.partyName)
                        if (i.partyPhone.isNotBlank()) KeyValue(tr("الجوال", "Phone"), i.partyPhone)
                    }
                }
            }
            item { SectionTitle(tr("الأصناف", "Items")) }
            items(items, key = { it.id }) { x ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(x.name, fontWeight = FontWeight.SemiBold)
                        Text(Fmt.num(x.qty) + " × " + Fmt.num(x.price), style = MaterialTheme.typography.bodySmall)
                    }
                    Text(Fmt.money(x.qty * x.price), fontWeight = FontWeight.SemiBold)
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        KeyValue(tr("المجموع", "Subtotal"), Fmt.money(r.t.subtotal))
                        if (r.t.discount > 0) KeyValue(tr("الخصم", "Discount"), "− " + Fmt.money(r.t.discount), DangerRed)
                        if (r.t.tax > 0) KeyValue(tr("الضريبة ", "Tax ") + Fmt.num(i.taxPct) + "%", Fmt.money(r.t.tax))
                        HorizontalDivider()
                        KeyValue(tr("الإجمالي النهائي", "Grand total"), Fmt.money(r.t.total))
                        if (Shop.isMoney(i.type)) {
                            KeyValue(tr("المدفوع", "Paid"), Fmt.money(r.paid), SuccessGreen)
                            KeyValue(tr("المتبقي", "Balance due"), Fmt.money(r.remaining), if (r.remaining > 0.01) DangerRed else SuccessGreen)
                        }
                        if (i.type == Shop.SALE && r.t.cost > 0) KeyValue(tr("ربح الفاتورة", "Invoice profit"), Fmt.money(r.t.profit), if (r.t.profit >= 0) SuccessGreen else DangerRed)
                    }
                }
            }
            if (r.hasInst) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionTitle(tr("جدول الأقساط", "Installment schedule"), Modifier.weight(1f))
                        Text(tr("${r.schedule.count { it.isPaid }} من ${r.schedule.size} مدفوع", "${r.schedule.count { it.isPaid }} of ${r.schedule.size} paid"), style = MaterialTheme.typography.bodySmall)
                    }
                }
                item { LinearProgressIndicator(progress = { if (r.t.total > 0) (r.paid / r.t.total).toFloat().coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth()) }
                if (r.lateAmount > 0) item {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.1f))) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, null, tint = DangerRed); Spacer(Modifier.width(8.dp))
                            Text(tr("أقساط متأخرة: ", "Overdue installments: ") + Fmt.money(r.lateAmount), Modifier.weight(1f), color = DangerRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                items(r.schedule, key = { "inst${it.no}" }) { x ->
                    val color = when { x.isPaid -> SuccessGreen; x.isLate -> DangerRed; x.paid > 0 -> WarnAmber; else -> MaterialTheme.colorScheme.outline }
                    OutlinedCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (x.isPaid) Icons.Filled.CheckCircle else if (x.isLate) Icons.Filled.ErrorOutline else Icons.Filled.Schedule, null, tint = color)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(Shop.instLabel(x, i.instCount), fontWeight = FontWeight.SemiBold)
                                Text(Fmt.date(x.due) + if (!x.isPaid && x.paid > 0) tr(" • مدفوع ", " • paid ") + Fmt.num(x.paid) else "", style = MaterialTheme.typography.bodySmall, color = color)
                            }
                            Text(Fmt.money(if (x.isPaid) x.amount else x.remaining), fontWeight = FontWeight.Bold, color = color)
                        }
                    }
                }
                if (!r.isPaid && i.partyPhone.isNotBlank() && Shop.isIncoming(i.type)) item {
                    val ni = r.nextInst
                    OutlinedButton(onClick = {
                        val amt = if (r.lateAmount > 0) r.lateAmount else ni?.remaining ?: r.remaining
                        Share.whatsappMessage(ctx, i.partyPhone, tr(
                            "السلام عليكم ${i.partyName}، نذكركم بـ${if (r.lateAmount > 0) "الأقساط المتأخرة" else ni?.let { Shop.instLabel(it, i.instCount) } ?: "القسط"} من ${Shop.numberText(i)} بمبلغ ${Fmt.money(amt)}${ni?.let { " المستحق بتاريخ " + Fmt.date(it.due) } ?: ""}. المتبقي الكلي: ${Fmt.money(r.remaining)}. شاكرين تعاملكم.",
                            "Hello ${i.partyName}, a reminder of ${if (r.lateAmount > 0) "your overdue installments" else ni?.let { Shop.instLabel(it, i.instCount) } ?: "your installment"} on ${Shop.numberText(i)}: ${Fmt.money(amt)}${ni?.let { " due " + Fmt.date(it.due) } ?: ""}. Total remaining: ${Fmt.money(r.remaining)}. Thank you."
                        ))
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen); Spacer(Modifier.width(6.dp)); Text(tr("تذكير العميل بالقسط", "Remind customer of installment")) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (Shop.isMoney(i.type) && !r.isPaid) Button(onClick = { pay = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Payments, null); Spacer(Modifier.width(4.dp)); Text(if (r.hasInst) tr("دفع قسط", "Pay installment") else tr("تسجيل دفعة", "Add payment")) }
                    OutlinedButton(onClick = {
                        val txt = Shop.shareText(r, items)
                        if (i.partyPhone.isNotBlank()) Share.whatsappMessage(ctx, i.partyPhone, txt) else shareText(ctx, txt)
                    }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen); Spacer(Modifier.width(4.dp)); Text(tr("إرسال نصي", "Send text")) }
                }
            }
            if (i.type == Shop.QUOTE && i.status != "CONVERTED") item {
                Button(onClick = {
                    scope.launch {
                        val n = Shop.nextNumber(dao, Shop.SALE)
                        val nid = dao.saveInvoice(i.copy(id = 0, type = Shop.SALE, number = n, date = Fmt.today(), status = "", createdAt = System.currentTimeMillis()), items)
                        dao.updateInvoice(i.copy(status = "CONVERTED"))
                        toast(ctx, tr("تم إنشاء فاتورة البيع", "Sales invoice created"))
                        nav.navigate("invoice/$nid")
                    }
                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Transform, null); Spacer(Modifier.width(6.dp)); Text(tr("تحويل العرض إلى فاتورة بيع", "Convert to sales invoice")) }
            }
            if (i.type == Shop.SALE || i.type == Shop.PURCHASE) item {
                OutlinedButton(onClick = {
                    scope.launch {
                        val t = if (i.type == Shop.SALE) Shop.SRETURN else Shop.PRETURN
                        val nid = dao.saveInvoice(i.copy(id = 0, type = t, number = Shop.nextNumber(dao, t), date = Fmt.today(), dueDate = null, status = "", notes = tr("مرتجع من ", "Return of ") + Shop.numberText(i), createdAt = System.currentTimeMillis()), items)
                        nav.navigate("invoice_edit/$t/$nid")
                    }
                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.AssignmentReturn, null); Spacer(Modifier.width(6.dp)); Text(tr("إنشاء مرتجع من هذه الفاتورة", "Create a return from this invoice")) }
            }
            if (pays.isNotEmpty()) {
                item { SectionTitle(tr("الدفعات", "Payments")) }
                items(pays, key = { "p${it.id}" }) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(Fmt.money(p.amount), fontWeight = FontWeight.SemiBold)
                                Text(Fmt.date(p.date) + " • " + Shop.method(p.method).label + if (p.note.isNotBlank()) " • " + p.note else "", style = MaterialTheme.typography.bodySmall)
                            }
                            PostButton(p.id in linked) { postPay = p }
                            AttachmentButton(Attachments.INV_PAY, p.id)
                            IconButton(onClick = { delPay = p }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                        }
                    }
                }
            }
            item { AttachmentButton(Attachments.INVOICE, i.id, i.partyPhone.ifBlank { null }) }
            if (i.notes.isNotBlank()) item { Text(i.notes, style = MaterialTheme.typography.bodySmall) }
        }
    }

    if (pay) InvoicePayDialog(i, r.remaining, if (r.hasInst) (if (r.lateAmount > 0) r.lateAmount else r.nextInst?.remaining ?: r.remaining) else r.remaining) { pay = false }
    if (del) ConfirmDialog(tr("حذف الفاتورة", "Delete invoice"), tr("حذف ${Shop.numberText(i)} بأصنافها ودفعاتها؟ سيتم تعديل المخزون تلقائياً.", "Delete with items and payments? Stock will be adjusted."), onDismiss = { del = false }) {
        del = false
        scope.launch {
            pays.forEach { Attachments.deleteFor(Attachments.INV_PAY, it.id) }
            Attachments.deleteFor(Attachments.INVOICE, i.id)
            dao.deleteInvoiceFull(i.id); nav.popBackStack()
        }
    }
    delPay?.let { p ->
        ConfirmDialog(tr("حذف الدفعة", "Delete payment"), Fmt.money(p.amount), onDismiss = { delPay = null }) {
            delPay = null
            scope.launch { Attachments.deleteFor(Attachments.INV_PAY, p.id); dao.deleteLinkedTx(AccountTx.SRC_INV, p.id); dao.deleteInvoicePayment(p.id) }
        }
    }
    postPay?.let { p ->
        PostToAccountDialog(if (Shop.isIncoming(i.type)) tr("إيداع في حساب", "Deposit to account") else tr("خصم من حساب", "Withdraw from account"), Shop.isIncoming(i.type), onDismiss = { postPay = null }) { acc ->
            postPay = null
            scope.launch { Posting.post(acc, AccountTx.SRC_INV, p.id, Shop.isIncoming(i.type), p.amount, p.date, Shop.numberText(i) + " " + i.partyName); toast(ctx, tr("تم الترحيل", "Posted")) }
        }
    }
}

@Composable
private fun InvoicePayDialog(i: Invoice, remaining: Double, suggested: Double = remaining, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var amount by remember { mutableStateOf(Fmt.plain(suggested)) }
    var date by remember { mutableStateOf(Fmt.today()) }
    var method by remember { mutableStateOf("CASH") }
    var note by remember { mutableStateOf("") }
    val acc = remember { mutableStateOf(Extras.shopAccount.takeIf { it > 0 }) }
    val pending = remember { mutableStateListOf<Uri>() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("تسجيل دفعة", "Add payment")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("المتبقي: ", "Remaining: ") + Fmt.money(remaining), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                HChips { Shop.methods.forEach { m -> FilterChip(method == m.key, { method = m.key }, label = { Text(m.emoji + " " + m.label) }) } }
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
                AccountPickRow(acc, tr("ترحيل إلى حساب (اختياري)", "Post to account (optional)"))
                PendingAttachRow(pending)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Fmt.parse(amount)
                if (a == null || a <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                scope.launch {
                    val pid = dao.insertInvoicePayment(InvoicePayment(invoiceId = i.id, amount = a, date = date, method = method, note = note.trim()))
                    Attachments.addAll(ctx, Attachments.INV_PAY, pid, pending.toList())
                    Posting.post(acc.value, AccountTx.SRC_INV, pid, Shop.isIncoming(i.type), a, date, Shop.numberText(i) + (if (i.partyName.isNotBlank()) " • " + i.partyName else ""))
                    toast(ctx, tr("تم التسجيل ✅", "Recorded ✅"))
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
