package com.sho3eb.app.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import java.io.File

/** ترويسة التقارير والتوقيع والختم */
object Brand {
    var enabled: Boolean get() = Extras.b("lh_on", false); set(v) = Extras.pb("lh_on", v)
    var name: String get() = Extras.s("lh_name", ""); set(v) = Extras.ps("lh_name", v)
    var subtitle: String get() = Extras.s("lh_sub", ""); set(v) = Extras.ps("lh_sub", v)
    var address: String get() = Extras.s("lh_addr", ""); set(v) = Extras.ps("lh_addr", v)
    var phone: String get() = Extras.s("lh_phone", ""); set(v) = Extras.ps("lh_phone", v)
    var email: String get() = Extras.s("lh_email", ""); set(v) = Extras.ps("lh_email", v)
    var website: String get() = Extras.s("lh_web", ""); set(v) = Extras.ps("lh_web", v)
    var taxNo: String get() = Extras.s("lh_tax", ""); set(v) = Extras.ps("lh_tax", v)
    var crNo: String get() = Extras.s("lh_cr", ""); set(v) = Extras.ps("lh_cr", v)
    var extra: String get() = Extras.s("lh_extra", ""); set(v) = Extras.ps("lh_extra", v)
    var footer: String get() = Extras.s("lh_footer", ""); set(v) = Extras.ps("lh_footer", v)
    var color: Int get() = Extras.i("lh_color", Color.rgb(15, 118, 110)); set(v) = Extras.pi("lh_color", v)
    var signerName: String get() = Extras.s("lh_signer", ""); set(v) = Extras.ps("lh_signer", v)
    var signerTitle: String get() = Extras.s("lh_signer_t", ""); set(v) = Extras.ps("lh_signer_t", v)
    var showSignature: Boolean get() = Extras.b("lh_sig_on", false); set(v) = Extras.pb("lh_sig_on", v)
    var showStamp: Boolean get() = Extras.b("lh_stamp_on", false); set(v) = Extras.pb("lh_stamp_on", v)

    fun dir(ctx: Context) = File(ctx.filesDir, "brand").apply { mkdirs() }
    fun logo(ctx: Context) = File(dir(ctx), "logo.png")
    fun signature(ctx: Context) = File(dir(ctx), "signature.png")
    fun stamp(ctx: Context) = File(dir(ctx), "stamp.png")
    fun bmp(f: File): Bitmap? = if (f.exists() && f.length() > 0) runCatching { BitmapFactory.decodeFile(f.path) }.getOrNull() else null

    val colors = listOf(Color.rgb(15, 118, 110), Color.rgb(25, 118, 210), Color.rgb(46, 125, 50), Color.rgb(123, 31, 162), Color.rgb(183, 28, 28), Color.rgb(230, 81, 0), Color.rgb(55, 71, 79), Color.rgb(141, 110, 99), Color.rgb(184, 134, 11))

    /** حفظ صورة مختارة (مع تصغيرها) */
    fun saveImage(ctx: Context, uri: android.net.Uri, dst: File, max: Int = 800, removeWhite: Boolean = false): Boolean = runCatching {
        val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return false
        val k = minOf(1f, max.toFloat() / maxOf(src.width, src.height))
        var b = if (k < 1f) Bitmap.createScaledBitmap(src, (src.width * k).toInt(), (src.height * k).toInt(), true) else src
        if (removeWhite) {
            b = b.copy(Bitmap.Config.ARGB_8888, true)
            val px = IntArray(b.width * b.height)
            b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
            for (i in px.indices) {
                val c = px[i]
                val l = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
                if (l > 200) px[i] = Color.TRANSPARENT
                else if (l > 150) px[i] = Color.argb((255 * (200 - l) / 50), Color.red(c), Color.green(c), Color.blue(c))
            }
            b.setPixels(px, 0, b.width, 0, 0, b.width, b.height)
        }
        dst.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    }.getOrDefault(false)

    fun saveBitmap(b: Bitmap, dst: File) { dst.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }

    /** توليد ختم دائري احترافي من الاسم */
    fun generateStamp(ctx: Context, top: String, center: String, bottom: String, colorInt: Int): Bitmap {
        val s = 600
        val bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        val col = Color.argb(225, Color.red(colorInt), Color.green(colorInt), Color.blue(colorInt))
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = col }
        stroke.strokeWidth = 14f; c.drawCircle(s / 2f, s / 2f, s / 2f - 12, stroke)
        stroke.strokeWidth = 5f; c.drawCircle(s / 2f, s / 2f, s / 2f - 40, stroke)
        stroke.strokeWidth = 4f; c.drawCircle(s / 2f, s / 2f, s / 2f - 150, stroke)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; textSize = 46f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
        val r = s / 2f - 95
        val oval = RectF(s / 2f - r, s / 2f - r, s / 2f + r, s / 2f + r)
        if (top.isNotBlank()) c.drawTextOnPath(top.take(34), Path().apply { addArc(oval, 180f, 180f) }, 0f, 16f, tp)
        if (bottom.isNotBlank()) {
            val r2 = r + 30
            val ov2 = RectF(s / 2f - r2, s / 2f - r2, s / 2f + r2, s / 2f + r2)
            c.drawTextOnPath(bottom.take(34), Path().apply { addArc(ov2, 160f, -140f) }, 0f, 0f, tp.apply { textSize = 38f })
        }
        val cp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; textSize = 64f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
        val lines = center.split("\n").filter { it.isNotBlank() }.take(3)
        lines.forEachIndexed { i, l -> c.drawText(l.take(14), s / 2f, s / 2f + (i - (lines.size - 1) / 2f) * 70f + 22f, cp) }
        c.drawText("★", s / 2f - 170, s / 2f + 18, cp.apply { textSize = 40f }); c.drawText("★", s / 2f + 170, s / 2f + 18, cp)
        return bm
    }

    fun headerLines(): List<String> = listOfNotNull(
        address.takeIf { it.isNotBlank() }?.let { "📍 $it" },
        listOfNotNull(phone.takeIf { it.isNotBlank() }?.let { "☎ $it" }, email.takeIf { it.isNotBlank() }?.let { "✉ $it" }, website.takeIf { it.isNotBlank() }).joinToString("   ").takeIf { it.isNotBlank() },
        listOfNotNull(taxNo.takeIf { it.isNotBlank() }?.let { tr("الرقم الضريبي: ", "Tax No: ") + it }, crNo.takeIf { it.isNotBlank() }?.let { tr("السجل التجاري: ", "CR No: ") + it }).joinToString("   ").takeIf { it.isNotBlank() },
        extra.takeIf { it.isNotBlank() }
    )
}
