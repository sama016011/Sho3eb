@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun HChips(content: @Composable RowScope.() -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), content = content)

// =====================================================================
//                         العمال واليوميات
// =====================================================================
@Composable
fun WorkersScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val workers by flowState(emptyList<Worker>()) { dao.workersFlow() }
    val entries by flowState(emptyList<WorkerEntry>()) { dao.workerEntrysFlow() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var add by remember { mutableStateOf(false) }
    var day by remember { mutableStateOf(Fmt.today()) }
    val active = workers.filter { it.active }
    val totalOwed = workers.sumOf { Workers.sum(it, entries).balance.coerceAtLeast(0.0) }
    val month = LivingAuto.monthRange()
    val monthCost = workers.sumOf { w -> Workers.sum(w, entries, month).due }

    ScreenScaffold(
        title = tr("العمال واليوميات", "Workers & wages"), onBack = { nav.popBackStack() },
        fab = { if (tab == 0) ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.PersonAdd, null) }, text = { Text(tr("عامل", "Worker")) }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("العمال", "Workers")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("تحضير اليوم", "Attendance")) })
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (tab == 0) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard(tr("مستحق للعمال", "Owed to workers"), Fmt.money(totalOwed), Icons.Filled.Payments, DangerRed, Modifier.weight(1f))
                            StatCard(tr("أجور هذا الشهر", "Wages this month"), Fmt.money(monthCost), Icons.Filled.CalendarMonth, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        }
                    }
                    if (workers.isEmpty()) item { EmptyState(Icons.Filled.Engineering, tr("أضف عمالك ثم سجّل حضورهم يومياً، وستُحسب الأجور والسلف تلقائياً.", "Add workers, log attendance daily; wages are computed automatically.")) }
                    items(workers, key = { it.id }) { w ->
                        val sm = Workers.sum(w, entries)
                        Card(onClick = { nav.navigate("worker/${w.id}") }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Avatar(null, w.name, 44.dp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(w.name, fontWeight = FontWeight.Bold)
                                    Text((w.job.ifBlank { "" }.let { if (it.isNotBlank()) "$it • " else "" }) + Fmt.money(w.wage) + " " + Workers.wageType(w.wageType).label, style = MaterialTheme.typography.bodySmall)
                                    if (!w.active) Text(tr("موقوف", "Inactive"), color = WarnAmber, style = MaterialTheme.typography.bodySmall)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(Fmt.money(kotlin.math.abs(sm.balance)), fontWeight = FontWeight.Bold, color = if (sm.balance > 0.005) DangerRed else if (sm.balance < -0.005) SuccessGreen else MaterialTheme.colorScheme.onSurface)
                                    Text(if (sm.balance > 0.005) tr("له", "owed") else if (sm.balance < -0.005) tr("عليه", "owes") else tr("مسدد", "settled"), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { day -= 1 }) { Icon(Icons.Filled.ChevronRight, null) }
                            Text(if (day == Fmt.today()) tr("اليوم", "Today") + " • " + Fmt.date(day) else Fmt.date(day), Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            IconButton(onClick = { if (day < Fmt.today()) day += 1 }, enabled = day < Fmt.today()) { Icon(Icons.Filled.ChevronLeft, null) }
                        }
                    }
                    if (active.isEmpty()) item { EmptyState(Icons.Filled.Engineering, tr("لا يوجد عمال نشطون", "No active workers")) }
                    item {
                        if (active.isNotEmpty()) OutlinedButton(onClick = {
                            scope.launch { active.filter { Workers.attOf(entries, it.id, day) == null }.forEach { w -> dao.insertWorkerEntry(WorkerEntry(workerId = w.id, date = day, type = Workers.ATT, qty = 1.0)) } }
                        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.DoneAll, null); Spacer(Modifier.width(6.dp)); Text(tr("تحضير الكل (يوم كامل)", "Mark all present")) }
                    }
                    items(active, key = { "a${it.id}" }) { w ->
                        val att = Workers.attOf(entries, w.id, day)
                        val q = att?.qty
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(w.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    Text(if (q != null && q > 0) Fmt.money(q * Workers.dailyRate(w)) else "", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                                }
                                HChips {
                                    listOf(1.0 to tr("حاضر", "Present"), 0.5 to tr("نصف يوم", "Half day"), 0.0 to tr("غائب", "Absent")).forEach { (v, l) ->
                                        FilterChip(q == v, {
                                            scope.launch {
                                                if (att != null) { if (q == v) dao.deleteWorkerEntry(att.id) else dao.updateWorkerEntry(att.copy(qty = v)) }
                                                else dao.insertWorkerEntry(WorkerEntry(workerId = w.id, date = day, type = Workers.ATT, qty = v))
                                            }
                                        }, label = { Text(l) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (add) WorkerDialog(null, onDismiss = { add = false }) { id -> add = false; nav.navigate("worker/$id") }
}

@Composable
private fun WorkerDialog(existing: Worker?, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var personId by remember { mutableStateOf(existing?.personId) }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var job by remember { mutableStateOf(existing?.job ?: "") }
    var wageType by remember { mutableStateOf(existing?.wageType ?: "DAY") }
    var wage by remember { mutableStateOf(existing?.wage?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var ot by remember { mutableStateOf(existing?.otRate?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var start by remember { mutableStateOf(existing?.startDate ?: Fmt.today()) }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("إضافة عامل", "Add worker") else tr("تعديل العامل", "Edit worker")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PersonSelector(people.firstOrNull { it.id == personId }, tr("من جهات الاتصال (اختياري)", "From contacts (optional)")) { personId = it.id; name = it.name; phone = it.phone }
                OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text(tr("الجوال (لواتساب)", "Phone")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(job, { job = it }, label = { Text(tr("المهنة / العمل", "Job")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                HChips { Workers.wageTypes.forEach { t -> FilterChip(wageType == t.key, { wageType = t.key }, label = { Text(t.label) }) } }
                MoneyField(wage, { wage = it }, tr("قيمة الأجر (", "Wage (") + Workers.wageType(wageType).label + ")")
                MoneyField(ot, { ot = it }, tr("أجر ساعة العمل الإضافي (اختياري)", "Overtime per hour (optional)"))
                DateField(tr("تاريخ بدء العمل", "Start date"), start, { d -> if (d != null) start = d })
                if (existing != null) SwitchRow(tr("عامل نشط", "Active"), null, active) { active = it }
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل الاسم", "Enter name")); return@TextButton }
                val w = Fmt.parse(wage) ?: 0.0
                val o = Fmt.parse(ot) ?: 0.0
                scope.launch {
                    if (existing != null) { dao.updateWorker(existing.copy(name = name.trim(), personId = personId, phone = phone.trim(), job = job.trim(), wageType = wageType, wage = w, otRate = o, startDate = start, active = active, notes = notes.trim())); onSaved(existing.id) }
                    else onSaved(dao.insertWorker(Worker(name = name.trim(), personId = personId, phone = phone.trim(), job = job.trim(), wageType = wageType, wage = w, otRate = o, startDate = start, notes = notes.trim())))
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
fun WorkerDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val worker by flowState<Worker?>(null, id) { dao.workerFlow(id) }
    val all by flowState(emptyList<WorkerEntry>()) { dao.workerEntrysFlow() }
    val linked = rememberLinkedIds(AccountTx.SRC_WORKER)
    var range by rememberSaveable { mutableIntStateOf(2) }
    var addType by remember { mutableStateOf<String?>(null) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var delE by remember { mutableStateOf<WorkerEntry?>(null) }
    var postE by remember { mutableStateOf<WorkerEntry?>(null) }

    val w = worker
    if (w == null) { ScreenScaffold(tr("العامل", "Worker"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val now = LocalDate.now()
    val rng: LongRange? = when (range) { 0 -> now.minusDays(6).toEpochDay()..now.toEpochDay(); 1 -> LivingAuto.monthRange(); else -> null }
    val sm = Workers.sum(w, all, rng)
    val total = Workers.sum(w, all)
    val list = all.filter { it.workerId == w.id && (rng == null || it.date in rng) }.sortedWith(compareByDescending<WorkerEntry> { it.date }.thenByDescending { it.id })

    ScreenScaffold(
        title = w.name, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(w.phone.ifBlank { null }, doc = { Docs.worker(w, all, rng) }) { c -> Reports.doc(c, Docs.worker(w, all, rng)) }
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text((w.job.ifBlank { tr("عامل", "Worker") }) + " • " + Fmt.money(w.wage) + " " + Workers.wageType(w.wageType).label + tr(" • أجر اليوم ", " • day ") + Fmt.money(Workers.dailyRate(w)), style = MaterialTheme.typography.bodySmall)
                        Text(if (total.balance >= 0) tr("المتبقي له", "Owed to worker") else tr("عليه (سلف زائدة)", "Worker owes"), style = MaterialTheme.typography.bodySmall)
                        Text(Fmt.money(kotlin.math.abs(total.balance)), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium, color = if (total.balance > 0.005) DangerRed else SuccessGreen)
                    }
                }
            }
            item {
                HChips { listOf(tr("آخر 7 أيام", "7 days"), tr("هذا الشهر", "This month"), tr("الكل", "All")).forEachIndexed { i, s -> FilterChip(range == i, { range = i }, label = { Text(s) }) } }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        KeyValue(tr("أيام الحضور", "Days"), Fmt.num(sm.days).removeSuffix(".00"))
                        if (sm.otHours > 0) KeyValue(tr("ساعات إضافية", "OT hours"), Fmt.num(sm.otHours).removeSuffix(".00"))
                        KeyValue(tr("الأجر المستحق", "Earned"), Fmt.money(sm.earned), SuccessGreen)
                        if (sm.bonus > 0) KeyValue(tr("مكافآت", "Bonuses"), Fmt.money(sm.bonus))
                        if (sm.deduct > 0) KeyValue(tr("خصومات", "Deductions"), Fmt.money(sm.deduct), DangerRed)
                        KeyValue(tr("سلف", "Advances"), Fmt.money(sm.advances))
                        KeyValue(tr("مدفوع", "Paid"), Fmt.money(sm.paid))
                    }
                }
            }
            item {
                HChips {
                    Workers.entryTypes.forEach { t -> AssistChip(onClick = { addType = t.key }, label = { Text(t.emoji + " " + t.label) }) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (total.balance > 0.005) Button(onClick = { addType = Workers.PAY }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Payments, null); Spacer(Modifier.width(4.dp)); Text(tr("تصفية المستحق", "Settle"), maxLines = 1) }
                    if (w.phone.isNotBlank()) OutlinedButton(onClick = {
                        Share.whatsappMessage(ctx, w.phone, tr("السلام عليكم ${w.name}\nأيام العمل: ${Fmt.num(total.days).removeSuffix(".00")}\nالمستحق: ${Fmt.money(total.due)}\nالسلف والمدفوع: ${Fmt.money(total.advances + total.paid)}\nالمتبقي لك: ${Fmt.money(total.balance)}",
                            "Hello ${w.name}\nDays: ${Fmt.num(total.days)}\nEarned: ${Fmt.money(total.due)}\nPaid: ${Fmt.money(total.advances + total.paid)}\nBalance: ${Fmt.money(total.balance)}"))
                    }, colors = ButtonDefaults.outlinedButtonColors(contentColor = WhatsGreen)) { Icon(Icons.Filled.Chat, null) }
                }
            }
            item { SectionTitle(tr("الحركات", "Entries")) }
            if (list.isEmpty()) item { Text(tr("لا توجد حركات في هذه الفترة", "No entries in this period"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(list, key = { it.id }) { e ->
                val t = Workers.entryType(e.type)
                val v = Workers.value(w, e)
                val pay = Workers.isPayment(e.type)
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.emoji)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.label + when (e.type) {
                                Workers.ATT -> if (e.qty == 0.0) tr(" (غائب)", " (absent)") else if (e.qty == 0.5) tr(" (نصف يوم)", " (half)") else if (e.qty != 1.0) " × ${Fmt.num(e.qty)}" else ""
                                Workers.OT -> tr(" ${Fmt.num(e.qty)} ساعة", " ${Fmt.num(e.qty)} h")
                                else -> ""
                            }, fontWeight = FontWeight.SemiBold)
                            Text(Fmt.date(e.date) + (if (e.project.isNotBlank()) " • " + e.project else "") + (if (e.note.isNotBlank()) " • " + e.note else ""), style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        if (v > 0) Text((if (pay || e.type == Workers.DEDUCT) "-" else "+") + Fmt.num(v), color = if (pay) DangerRed else SuccessGreen, fontWeight = FontWeight.Bold)
                        if (pay) {
                            AttachmentButton(Attachments.WORKER_TX, e.id, w.phone.ifBlank { null })
                            PostButton(e.id in linked) { postE = e }
                        }
                        IconButton(onClick = { delE = e }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                    }
                }
            }
        }
    }

    addType?.let { t -> WorkerEntryDialog(w, t, if (t == Workers.PAY) total.balance.coerceAtLeast(0.0) else null) { addType = null } }
    if (edit) WorkerDialog(w, onDismiss = { edit = false }) { edit = false }
    if (del) ConfirmDialog(tr("حذف العامل", "Delete worker"), tr("حذف «${w.name}» مع كل حركاته والحركات المرحّلة منه؟", "Delete with all entries and posted transactions?"), onDismiss = { del = false }) {
        del = false
        scope.launch { all.filter { it.workerId == w.id }.forEach { Attachments.deleteFor(Attachments.WORKER_TX, it.id) }; dao.deleteWorkerFull(w.id); nav.popBackStack() }
    }
    delE?.let { e ->
        ConfirmDialog(tr("حذف الحركة", "Delete entry"), tr("حذف هذه الحركة؟", "Delete this entry?"), onDismiss = { delE = null }) {
            delE = null
            scope.launch {
                Attachments.deleteFor(Attachments.WORKER_TX, e.id); dao.deleteLinkedTx(AccountTx.SRC_WORKER, e.id)
                LivingLink.remove(LivingLink.WORKER, e.id); dao.deleteWorkerEntry(e.id)
            }
        }
    }
    postE?.let { e ->
        PostToAccountDialog(tr("خصم من حساب", "Withdraw from account"), false, onDismiss = { postE = null }) { acc ->
            postE = null
            scope.launch { Posting.post(acc, AccountTx.SRC_WORKER, e.id, false, e.amount, e.date, Workers.entryType(e.type).label + " - " + w.name); toast(ctx, tr("تم الترحيل", "Posted")) }
        }
    }
}

@Composable
private fun WorkerEntryDialog(w: Worker, type: String, suggested: Double?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val t = Workers.entryType(type)
    val isQty = type == Workers.ATT || type == Workers.OT
    val pay = Workers.isPayment(type)
    var qty by remember { mutableStateOf(if (type == Workers.ATT) "1" else "") }
    var amount by remember { mutableStateOf(suggested?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var days by remember { mutableIntStateOf(1) }
    var project by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var toLiving by remember { mutableStateOf(false) }
    val pending = remember { mutableStateListOf<Uri>() }
    val post = remember { mutableStateOf(if (pay) Posting.lastAccount("worker") else null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(t.emoji + " " + t.label + " • " + w.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (type == Workers.ATT) {
                    HChips { listOf("1" to tr("يوم كامل", "Full"), "0.5" to tr("نصف يوم", "Half"), "0" to tr("غائب", "Absent")).forEach { (v, l) -> FilterChip(qty == v, { qty = v }, label = { Text(l) }) } }
                    Text(tr("عدد الأيام المتتالية من التاريخ:", "Consecutive days from date:"), style = MaterialTheme.typography.labelLarge)
                    HChips { listOf(1, 2, 3, 5, 6, 7, 14, 30).forEach { d -> FilterChip(days == d, { days = d }, label = { Text("$d") }) } }
                }
                if (type == Workers.OT) NumberField(qty, { qty = it }, tr("عدد الساعات", "Hours"))
                if (!isQty) MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                else if (type == Workers.OT && w.otRate <= 0) MoneyField(amount, { amount = it }, tr("المبلغ (لا يوجد أجر ساعة محدد)", "Amount (no hourly rate set)"))
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                OutlinedTextField(project, { project = it }, label = { Text(tr("المشروع / الموقع (اختياري)", "Project / site (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
                if (pay) {
                    AccountPickRow(post, tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
                    SwitchRow(tr("تسجيل في مصاريف المعيشة", "Record in living expenses"), null, toLiving) { toLiving = it }
                    PendingAttachRow(pending)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val q = Fmt.parse(qty) ?: 0.0
                val a = Fmt.parse(amount) ?: 0.0
                if (!isQty && a <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                if (type == Workers.OT && q <= 0) { toast(ctx, tr("أدخل الساعات", "Enter hours")); return@TextButton }
                scope.launch {
                    if (type == Workers.ATT) {
                        for (k in 0 until days) dao.insertWorkerEntry(WorkerEntry(workerId = w.id, date = date + k, type = type, qty = q, project = project.trim(), note = note.trim()))
                    } else {
                        val eid = dao.insertWorkerEntry(WorkerEntry(workerId = w.id, date = date, type = type, qty = q, amount = if (type == Workers.OT && w.otRate > 0) 0.0 else a, project = project.trim(), note = note.trim()))
                        if (pay) {
                            Attachments.addAll(ctx, Attachments.WORKER_TX, eid, pending.toList())
                            Posting.setLastAccount("worker", post.value)
                            Posting.post(post.value, AccountTx.SRC_WORKER, eid, false, a, date, t.label + " - " + w.name)
                            if (toLiving) LivingLink.addExpense(ctx, LivingLink.WORKER, eid, t.label + " - " + w.name, "HOUSEHOLD", a, date, note.trim())
                        }
                    }
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
