@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BrandScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ver by remember { mutableIntStateOf(0) }
    var on by remember { mutableStateOf(Brand.enabled) }
    var name by remember { mutableStateOf(Brand.name.ifBlank { Extras.shopName }) }
    var sub by remember { mutableStateOf(Brand.subtitle) }
    var addr by remember { mutableStateOf(Brand.address.ifBlank { Extras.shopAddress }) }
    var phone by remember { mutableStateOf(Brand.phone.ifBlank { Extras.shopPhone }) }
    var email by remember { mutableStateOf(Brand.email) }
    var web by remember { mutableStateOf(Brand.website) }
    var tax by remember { mutableStateOf(Brand.taxNo) }
    var cr by remember { mutableStateOf(Brand.crNo) }
    var extra by remember { mutableStateOf(Brand.extra) }
    var footer by remember { mutableStateOf(Brand.footer) }
    var color by remember { mutableIntStateOf(Brand.color) }
    var signer by remember { mutableStateOf(Brand.signerName) }
    var signerT by remember { mutableStateOf(Brand.signerTitle) }
    var showSig by remember { mutableStateOf(Brand.showSignature) }
    var showStamp by remember { mutableStateOf(Brand.showStamp) }
    var pad by remember { mutableStateOf(false) }
    var stampGen by remember { mutableStateOf(false) }

    fun save() {
        Brand.enabled = on; Brand.name = name.trim(); Brand.subtitle = sub.trim(); Brand.address = addr.trim(); Brand.phone = phone.trim()
        Brand.email = email.trim(); Brand.website = web.trim(); Brand.taxNo = tax.trim(); Brand.crNo = cr.trim(); Brand.extra = extra.trim()
        Brand.footer = footer.trim(); Brand.color = color; Brand.signerName = signer.trim(); Brand.signerTitle = signerT.trim()
        Brand.showSignature = showSig; Brand.showStamp = showStamp
    }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { Brand.saveImage(ctx, u, Brand.logo(ctx), 500); ver++ } }
    val pickSig = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { Brand.saveImage(ctx, u, Brand.signature(ctx), removeWhite = true); showSig = true; ver++ } }
    val pickStamp = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { Brand.saveImage(ctx, u, Brand.stamp(ctx), removeWhite = true); showStamp = true; ver++ } }

    ScreenScaffold(title = tr("الترويسة والتوقيع والختم", "Letterhead, signature & stamp"), onBack = { save(); nav.popBackStack() }, actions = {
        IconButton(onClick = { save(); toast(ctx, tr("تم الحفظ ✅", "Saved ✅")) }) { Icon(Icons.Filled.Save, null) }
    }) { p ->
        Column(Modifier.padding(p).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SwitchRow(tr("تفعيل الترويسة في كل التقارير والسندات", "Use letterhead on all reports & vouchers"), tr("تظهر أعلى كل صفحة PDF", "Shown at the top of every PDF page"), on, Icons.Filled.Badge) { on = it }
                    SectionTitle(tr("بيانات الترويسة", "Letterhead details"))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        val logo = remember(ver) { Brand.bmp(Brand.logo(ctx)) }
                        Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)).clickable { pickLogo.launch("image/*") }, contentAlignment = Alignment.Center) {
                            if (logo != null) Image(logo.asImageBitmap(), null, Modifier.fillMaxSize().padding(4.dp)) else Icon(Icons.Filled.AddPhotoAlternate, null)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(tr("الشعار (اللوجو)", "Logo"), fontWeight = FontWeight.Bold)
                            Text(tr("اضغط لاختيار صورة", "Tap to choose an image"), style = MaterialTheme.typography.bodySmall)
                            if (logo != null) TextButton(onClick = { Brand.logo(ctx).delete(); ver++ }) { Text(tr("حذف الشعار", "Remove logo")) }
                        }
                    }
                    OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم / اسم المنشأة", "Name / business")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(sub, { sub = it }, label = { Text(tr("وصف مختصر (النشاط)", "Tagline / activity")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(addr, { addr = it }, label = { Text(tr("العنوان", "Address")) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(phone, { phone = it }, label = { Text(tr("رقم الهاتف", "Phone")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(email, { email = it }, label = { Text(tr("البريد الإلكتروني", "Email")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(web, { web = it }, label = { Text(tr("الموقع الإلكتروني", "Website")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(tax, { tax = it }, label = { Text(tr("الرقم الضريبي", "Tax No.")) }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(cr, { cr = it }, label = { Text(tr("السجل التجاري", "CR No.")) }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(extra, { extra = it }, label = { Text(tr("سطر إضافي (اختياري)", "Extra line (optional)")) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(footer, { footer = it }, label = { Text(tr("نص التذييل أسفل الصفحة", "Footer text")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text(tr("لون الترويسة", "Header color"), style = MaterialTheme.typography.labelLarge)
                    HChips {
                        Brand.colors.forEach { c ->
                            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).border(if (c == color) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape).clickable { color = c })
                        }
                    }
                }
            }
            // معاينة
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp)) {
                    Box(Modifier.fillMaxWidth().height(4.dp).background(Color(color)))
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val logo = remember(ver) { Brand.bmp(Brand.logo(ctx)) }
                        if (logo != null) { Image(logo.asImageBitmap(), null, Modifier.size(44.dp)); Spacer(Modifier.width(8.dp)) }
                        Column(Modifier.weight(1f)) {
                            Text(name.ifBlank { "Sho3eb" }, color = Color(color), fontWeight = FontWeight.Bold)
                            if (sub.isNotBlank()) Text(sub, color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                            listOf(addr, listOf(phone, email, web).filter { it.isNotBlank() }.joinToString("  ")).filter { it.isNotBlank() }.forEach {
                                Text(it, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth().height(2.dp).background(Color(color)))
                }
            }
            // التوقيع
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("✍️ التوقيع", "✍️ Signature"))
                    SwitchRow(tr("إظهار التوقيع في السندات والتقارير", "Show signature on documents"), null, showSig) { showSig = it }
                    val sig = remember(ver) { Brand.bmp(Brand.signature(ctx)) }
                    if (sig != null) Image(sig.asImageBitmap(), null, Modifier.fillMaxWidth().height(110.dp).background(Color.White, RoundedCornerShape(8.dp)).padding(6.dp))
                    OutlinedTextField(signer, { signer = it }, label = { Text(tr("اسم الموقّع", "Signer name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(signerT, { signerT = it }, label = { Text(tr("الصفة (المدير، المحاسب...)", "Title (Manager, Accountant...)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { pad = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Draw, null); Spacer(Modifier.width(4.dp)); Text(tr("ارسم توقيعك", "Draw")) }
                        OutlinedButton(onClick = { pickSig.launch("image/*") }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Image, null); Spacer(Modifier.width(4.dp)); Text(tr("من صورة", "From image")) }
                    }
                    if (sig != null) TextButton(onClick = { Brand.signature(ctx).delete(); ver++ }) { Text(tr("حذف التوقيع", "Delete signature")) }
                }
            }
            // الختم
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("🔵 الختم", "🔵 Stamp"))
                    SwitchRow(tr("إظهار الختم في السندات والتقارير", "Show stamp on documents"), null, showStamp) { showStamp = it }
                    val st = remember(ver) { Brand.bmp(Brand.stamp(ctx)) }
                    if (st != null) Image(st.asImageBitmap(), null, Modifier.size(140.dp).align(Alignment.CenterHorizontally))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { stampGen = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Verified, null); Spacer(Modifier.width(4.dp)); Text(tr("صمّم ختماً", "Design")) }
                        OutlinedButton(onClick = { pickStamp.launch("image/*") }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Image, null); Spacer(Modifier.width(4.dp)); Text(tr("صورة ختم", "Stamp image")) }
                    }
                    Text(tr("💡 صوّر ختمك الحقيقي على ورقة بيضاء لأفضل نتيجة؛ تتم إزالة الخلفية البيضاء تلقائياً.", "💡 Photograph your real stamp on white paper; the white background is removed automatically."), style = MaterialTheme.typography.bodySmall)
                    if (st != null) TextButton(onClick = { Brand.stamp(ctx).delete(); ver++ }) { Text(tr("حذف الختم", "Delete stamp")) }
                }
            }
            Button(onClick = {
                save()
                scope.launch {
                    val f = withContext(Dispatchers.IO) {
                        Reports.doc(ctx, ReportDoc(tr("سند تجريبي", "Sample voucher"), tr("معاينة الترويسة والتوقيع", "Letterhead preview"),
                            listOf(tr("المبلغ", "Amount") to Fmt.money(1500.0), tr("البيان", "Description") to tr("تجربة", "Test")), emptyList()))
                    }
                    Share.shareFile(ctx, f, "application/pdf", null, false)
                }
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.PictureAsPdf, null); Spacer(Modifier.width(6.dp)); Text(tr("معاينة PDF تجريبي", "Preview a sample PDF")) }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (pad) SignaturePadDialog(onDismiss = { pad = false }) { bmp -> Brand.saveBitmap(bmp, Brand.signature(ctx)); showSig = true; ver++; pad = false }
    if (stampGen) {
        var top by remember { mutableStateOf(name) }
        var center by remember { mutableStateOf(tr("ختم", "STAMP")) }
        var bottom by remember { mutableStateOf(addr.take(30)) }
        val preview = remember(top, center, bottom, color) { Brand.generateStamp(ctx, top, center, bottom, color) }
        AlertDialog(onDismissRequest = { stampGen = false }, title = { Text(tr("تصميم الختم", "Design stamp")) }, text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Image(preview.asImageBitmap(), null, Modifier.size(170.dp).align(Alignment.CenterHorizontally))
                OutlinedTextField(top, { top = it }, label = { Text(tr("النص العلوي (الاسم)", "Top text (name)")) }, singleLine = true)
                OutlinedTextField(center, { center = it }, label = { Text(tr("النص الأوسط", "Center text")) })
                OutlinedTextField(bottom, { bottom = it }, label = { Text(tr("النص السفلي", "Bottom text")) }, singleLine = true)
            }
        }, confirmButton = { TextButton(onClick = { Brand.saveBitmap(preview, Brand.stamp(ctx)); showStamp = true; ver++; stampGen = false }) { Text(tr("اعتماد", "Use")) } },
            dismissButton = { TextButton(onClick = { stampGen = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
}

/** لوحة رسم التوقيع */
@Composable
fun SignaturePadDialog(onDismiss: () -> Unit, onDone: (Bitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<MutableList<Offset>>() }
    var tick by remember { mutableIntStateOf(0) }
    var size by remember { mutableStateOf(androidx.compose.ui.unit.IntSize(1, 1)) }
    var penW by remember { mutableFloatStateOf(6f) }
    var ink by remember { mutableStateOf(Color(0xFF0D2B8C)) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("ارسم توقيعك", "Draw your signature")) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.fillMaxWidth().height(200.dp).background(Color.White, RoundedCornerShape(10.dp)).border(1.dp, Color.LightGray, RoundedCornerShape(10.dp))) {
                Canvas(Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectDragGestures(onDragStart = { o -> strokes.add(mutableListOf(o)); tick++ }, onDrag = { ch, _ -> strokes.lastOrNull()?.add(ch.position); tick++ })
                    }) {
                    size = androidx.compose.ui.unit.IntSize(this.size.width.toInt(), this.size.height.toInt())
                    if (tick < 0) return@Canvas
                    strokes.forEach { s ->
                        val path = androidx.compose.ui.graphics.Path()
                        s.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                        drawPath(path, ink, style = Stroke(width = penW, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                    drawLine(Color.LightGray, Offset(20f, this.size.height * 0.78f), Offset(this.size.width - 20f, this.size.height * 0.78f), 1.5f)
                }
            }
            HChips {
                listOf(Color(0xFF0D2B8C), Color.Black, Color(0xFF1B5E20)).forEach { c ->
                    Box(Modifier.size(28.dp).clip(CircleShape).background(c).border(if (c == ink) 3.dp else 0.dp, Color.Gray, CircleShape).clickable { ink = c })
                }
                listOf(4f to tr("رفيع", "Thin"), 6f to tr("متوسط", "Medium"), 9f to tr("عريض", "Bold")).forEach { (w, l) -> FilterChip(penW == w, { penW = w }, label = { Text(l) }) }
            }
            TextButton(onClick = { strokes.clear(); tick++ }) { Icon(Icons.Filled.Delete, null); Text(tr("مسح", "Clear")) }
        }
    }, confirmButton = {
        TextButton(enabled = strokes.isNotEmpty(), onClick = {
            val pts = strokes.flatten()
            val minX = (pts.minOf { it.x } - 12).coerceAtLeast(0f); val minY = (pts.minOf { it.y } - 12).coerceAtLeast(0f)
            val maxX = (pts.maxOf { it.x } + 12).coerceAtMost(size.width.toFloat()); val maxY = (pts.maxOf { it.y } + 12).coerceAtMost(size.height.toFloat())
            val w = (maxX - minX).toInt().coerceAtLeast(10); val h = (maxY - minY).toInt().coerceAtLeast(10)
            val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(bm)
            val pnt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.STROKE; strokeWidth = penW; strokeCap = android.graphics.Paint.Cap.ROUND; strokeJoin = android.graphics.Paint.Join.ROUND
                this.color = android.graphics.Color.argb(255, (ink.red * 255).toInt(), (ink.green * 255).toInt(), (ink.blue * 255).toInt())
            }
            strokes.forEach { s ->
                val path = android.graphics.Path()
                s.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x - minX, o.y - minY) else path.lineTo(o.x - minX, o.y - minY) }
                c.drawPath(path, pnt)
            }
            onDone(bm)
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } })
}
