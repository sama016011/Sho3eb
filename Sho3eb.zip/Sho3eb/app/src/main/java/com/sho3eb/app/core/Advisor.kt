package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** المستشار المالي: يحلل بيانات التطبيق ويعطي درجة صحة مالية ونصائح مخصصة */
object Advisor {

    data class Tip(val level: Int, val emoji: String, val title: String, val text: String)   // level: 0 ممتاز، 1 معلومة، 2 تنبيه، 3 خطر
    data class Part(val label: String, val score: Int, val max: Int, val note: String)
    data class Report(
        val income: Double, val expense: Double, val essential: Double, val wants: Double, val savings: Double,
        val months: Int, val cash: Double, val investments: Double, val debts: Double, val monthlyDebt: Double,
        val receivables: Double, val subsMonthly: Double, val emergencyMonths: Double,
        val score: Int, val parts: List<Part>, val tips: List<Tip>, val topCats: List<Pair<String, Double>>, val trend: List<Pair<String, Double>>
    ) {
        val savingRate get() = if (income > 0) (income - expense) / income else 0.0
        val dti get() = if (income > 0) monthlyDebt / income else 0.0
        val netWorth get() = cash + investments + receivables - debts
        val grade get() = when { score >= 85 -> tr("ممتاز", "Excellent"); score >= 70 -> tr("جيد جداً", "Very good"); score >= 55 -> tr("جيد", "Good"); score >= 40 -> tr("يحتاج تحسين", "Needs work"); else -> tr("حرج", "Critical") }
    }

    suspend fun analyze(): Report {
        val dao = appDao()
        val entries = dao.allLivEntries()
        val today = LocalDate.now()
        // متوسط آخر 3 أشهر مكتملة + الشهر الحالي إذا لم يتوفر غيره
        val monthsBack = (1..3).map { today.minusMonths(it.toLong()) }
        val ranges = monthsBack.map { LivingAuto.monthRange(it) }.filter { r -> entries.any { it.date in r } }
        val useRanges = ranges.ifEmpty { listOf(LivingAuto.monthRange(today)) }
        val n = useRanges.size
        fun inR(e: LivEntry) = useRanges.any { e.date in it }
        val inc = entries.filter { it.kind == Living.INCOME && inR(it) }.sumOf { it.amount } / n
        val exps = entries.filter { it.kind == Living.EXPENSE && inR(it) }
        val exp = exps.sumOf { it.amount } / n
        val saving = exps.filter { it.category == "SAVING" }.sumOf { it.amount } / n
        val essential = exps.filter { it.priority == Living.ESSENTIAL && it.category != "SAVING" }.sumOf { it.amount } / n
        val wants = exps.filter { it.priority != Living.ESSENTIAL && it.category != "SAVING" }.sumOf { it.amount } / n
        val topCats = exps.filter { it.category != "SAVING" }.groupBy { it.category }.map { (c, l) -> c to l.sumOf { it.amount } / n }.sortedByDescending { it.second }.take(6)
        val trend = (5 downTo 0).map { today.minusMonths(it.toLong()) }.map { d -> val r = LivingAuto.monthRange(d); Living.monthName(d.monthValue) to entries.filter { it.kind == Living.EXPENSE && it.date in r }.sumOf { it.amount } }

        // الحسابات والأصول
        val txs = dao.allAccountTx()
        val accounts = dao.allAccounts()
        val cash = accounts.filter { it.kind != "CARD" }.sumOf { a -> accountBalance(txs.filter { it.accountId == a.id }) }.coerceAtLeast(0.0)
        val cardDebt = accounts.filter { it.kind == "CARD" }.sumOf { a -> (-accountBalance(txs.filter { it.accountId == a.id })).coerceAtLeast(0.0) }
        val assets = dao.allAssets().filter { !it.sold }
        val investments = assets.sumOf { Assets.value(it) }
        // الديون
        val debts = dao.allDebts().filter { !it.closed }
        val dtx = dao.allDebtTx()
        val debtBal = debts.sumOf { Debts.balance(it, dtx).coerceAtLeast(0.0) } + cardDebt
        val monthlyDebt = debts.sumOf { d -> if (d.installment > 0) d.installment / d.periodMonths.coerceAtLeast(1) else 0.0 }
        val lateDebts = debts.count { d -> Debts.nextDue(d, dtx)?.isBefore(today) == true }
        // المستحق لي
        val loans = dao.allLoanTx().groupBy { it.personId }.values.sumOf { l -> (l.filter { it.type == LoanTx.LOAN }.sumOf { it.amount } - l.filter { it.type == LoanTx.PAY }.sumOf { it.amount }).coerceAtLeast(0.0) }
        val credit = Grocery.books(dao.allCreditBooks().filter { it.mode == Grocery.OWE_ME }, dao.allCreditEntries()).sumOf { it.balance.coerceAtLeast(0.0) }
        val receivables = loans + credit
        // الاشتراكات
        val subs = dao.allSubscriptions().filter { it.active }
        val subsMonthly = subs.sumOf { it.amount / it.periodMonths.coerceAtLeast(1) }
        val emergency = if (exp > 0) cash / exp else 0.0

        // ---------- الدرجة ----------
        val parts = mutableListOf<Part>()
        val sr = if (inc > 0) (inc - exp) / inc else 0.0
        parts += Part(tr("نسبة الادخار", "Saving rate"), when { inc <= 0 -> 0; sr >= 0.2 -> 25; sr >= 0.1 -> 18; sr >= 0.05 -> 12; sr > 0 -> 6; else -> 0 }, 25, "${(sr * 100).roundToInt()}%")
        val dti = if (inc > 0) monthlyDebt / inc else 0.0
        parts += Part(tr("عبء الديون", "Debt burden"), when { debtBal <= 0 -> 25; dti <= 0.2 -> 20; dti <= 0.35 -> 13; dti <= 0.5 -> 6; else -> 0 } - min(lateDebts * 4, 8), 25, "${(dti * 100).roundToInt()}%")
        parts += Part(tr("صندوق الطوارئ", "Emergency fund"), when { emergency >= 6 -> 25; emergency >= 3 -> 19; emergency >= 1 -> 10; emergency > 0 -> 4; else -> 0 }, 25, tr("${Fmt.num(emergency)} شهر", "${Fmt.num(emergency)} months"))
        val wantsR = if (inc > 0) wants / inc else 1.0
        parts += Part(tr("ضبط الكماليات", "Spending control"), when { inc <= 0 -> 0; wantsR <= 0.3 -> 15; wantsR <= 0.4 -> 10; wantsR <= 0.5 -> 5; else -> 0 }, 15, "${(wantsR * 100).roundToInt()}%")
        parts += Part(tr("الاستثمار والأصول", "Investing"), when { investments >= inc * 12 && inc > 0 -> 10; investments >= inc * 3 && inc > 0 -> 7; investments > 0 -> 4; else -> 0 }, 10, Fmt.money(investments))
        val score = parts.sumOf { max(0, it.score) }.coerceIn(0, 100)

        // ---------- النصائح ----------
        val tips = mutableListOf<Tip>()
        if (inc <= 0) tips += Tip(1, "📝", tr("سجّل دخلك ومصروفاتك", "Record your income and expenses"), tr("المستشار يعتمد على قسم مصاريف المعيشة. سجّل دخلك الشهري ومصروفاتك (يمكنك بالصوت أو بتصوير الفاتورة) لتحصل على تحليل دقيق.", "The advisor relies on living expenses. Record income and spending (by voice or receipt photo) for an accurate analysis."))
        if (inc > 0 && exp > inc) tips += Tip(3, "🚨", tr("مصروفاتك أكبر من دخلك", "You spend more than you earn"), tr("العجز الشهري ${Fmt.money(exp - inc)}. ابدأ بتقليل الكماليات وراجع الاشتراكات، وتجنب أي دين جديد.", "Monthly deficit ${Fmt.money(exp - inc)}. Cut wants, review subscriptions and avoid new debt."))
        else if (inc > 0 && sr < 0.1) tips += Tip(2, "💡", tr("ارفع نسبة ادخارك إلى 10% على الأقل", "Raise savings to at least 10%"), tr("ادخارك الحالي ${(sr * 100).roundToInt()}%. خصص ${Fmt.money(inc * 0.1)} شهرياً أول ما يصلك الراتب (ادفع لنفسك أولاً).", "Current ${(sr * 100).roundToInt()}%. Set aside ${Fmt.money(inc * 0.1)} as soon as you're paid."))
        else if (inc > 0 && sr >= 0.2) tips += Tip(0, "🌟", tr("ادخار ممتاز", "Great saving rate"), tr("تدخر ${(sr * 100).roundToInt()}% من دخلك. فكّر في استثمار الفائض في أصول متنوعة (ذهب، صناديق، عقار).", "You save ${(sr * 100).roundToInt()}%. Consider investing the surplus in diversified assets."))
        if (exp > 0 && emergency < 3) tips += Tip(if (emergency < 1) 3 else 2, "🛟", tr("كوّن صندوق طوارئ", "Build an emergency fund"), tr("لديك ما يكفي ${Fmt.num(emergency)} شهر. الهدف 3-6 أشهر = ${Fmt.money(exp * 3)} إلى ${Fmt.money(exp * 6)} في حساب منفصل سهل السحب.", "You have ${Fmt.num(emergency)} months. Aim for 3-6 months = ${Fmt.money(exp * 3)}-${Fmt.money(exp * 6)} in a separate account."))
        if (dti > 0.35) tips += Tip(3, "⚖️", tr("أقساطك مرتفعة", "Your installments are high"), tr("الأقساط ${(dti * 100).roundToInt()}% من الدخل (الحد الآمن 35%). لا تأخذ ديوناً جديدة، واستخدم خطة كرة الثلج في قسم ديوني.", "Installments are ${(dti * 100).roundToInt()}% of income (safe limit 35%). Avoid new debt and use the snowball plan in My debts."))
        if (lateDebts > 0) tips += Tip(3, "⏰", tr("لديك $lateDebts دين متأخر", "$lateDebts overdue debt(s)"), tr("التأخير يضر بسمعتك وقد يضيف غرامات. ابدأ بالأعلى أولوية وتواصل مع الدائن لجدولة المتأخر.", "Late payments hurt and may add fees. Start with the highest priority and talk to the creditor."))
        if (cardDebt > 0) tips += Tip(2, "💳", tr("رصيد مستحق على البطاقات", "Card balance outstanding"), tr("عليك ${Fmt.money(cardDebt)} في البطاقات. سدّد كامل المبلغ قبل موعد الاستحقاق لتجنب الفوائد العالية.", "You owe ${Fmt.money(cardDebt)} on cards. Pay in full before the due date to avoid high interest."))
        if (inc > 0 && wantsR > 0.35) tips += Tip(2, "🛍️", tr("الكماليات أعلى من المعتاد", "Wants are above normal"), tr("الكماليات والمهمة ${(wantsR * 100).roundToInt()}% من الدخل. قاعدة 50/30/20: احتياجات 50% • رغبات 30% • ادخار 20%.", "Wants are ${(wantsR * 100).roundToInt()}% of income. 50/30/20 rule: needs 50% • wants 30% • savings 20%."))
        topCats.firstOrNull()?.let { (c, v) -> if (exp > 0 && v / exp > 0.35) tips += Tip(1, Living.cat(Living.EXPENSE, c).emoji, tr("أكبر بند: ${Living.cat(Living.EXPENSE, c).label}", "Biggest: ${Living.cat(Living.EXPENSE, c).label}"), tr("يمثل ${(v / exp * 100).roundToInt()}% من مصروفاتك (${Fmt.money(v)} شهرياً). تقليله 10% يوفر ${Fmt.money(v * 0.1 * 12)} سنوياً.", "It's ${(v / exp * 100).roundToInt()}% of spending (${Fmt.money(v)}/mo). Cutting 10% saves ${Fmt.money(v * 0.1 * 12)} a year.")) }
        if (subsMonthly > 0 && inc > 0 && subsMonthly / inc > 0.05) tips += Tip(2, "🔁", tr("راجع اشتراكاتك", "Review subscriptions"), tr("${subs.size} اشتراك بتكلفة ${Fmt.money(subsMonthly)} شهرياً (${Fmt.money(subsMonthly * 12)} سنوياً). ألغِ ما لا تستخدمه.", "${subs.size} subscriptions cost ${Fmt.money(subsMonthly)}/mo (${Fmt.money(subsMonthly * 12)}/yr). Cancel unused ones."))
        if (receivables > 0 && inc > 0 && receivables > inc) tips += Tip(2, "📥", tr("أموالك عند الآخرين", "Money owed to you"), tr("لك ${Fmt.money(receivables)} عند الآخرين (سلف وآجل). تابع التحصيل بالتذكير عبر واتساب وضع حداً للدين لكل شخص.", "Others owe you ${Fmt.money(receivables)}. Follow up with WhatsApp reminders and set limits."))
        if (investments <= 0 && sr > 0.1 && emergency >= 3) tips += Tip(1, "📈", tr("ابدأ الاستثمار", "Start investing"), tr("بعد صندوق الطوارئ، استثمر جزءاً شهرياً ثابتاً (مثل ${Fmt.money(inc * 0.1)}) في ذهب أو صناديق مؤشرات حلال، وتابعها في قسم الذهب والاستثمارات.", "With an emergency fund in place, invest a fixed monthly amount (e.g. ${Fmt.money(inc * 0.1)})."))
        val zakatBase = cash + investments
        val nisab = Extras.goldPrice24 * 85
        if (nisab > 0 && zakatBase >= nisab) tips += Tip(1, "🤲", tr("قد تجب عليك الزكاة", "Zakat may be due"), tr("أموالك وأصولك ${Fmt.money(zakatBase)} تتجاوز النصاب (${Fmt.money(nisab)}). إن حال عليها الحول فالزكاة 2.5% ≈ ${Fmt.money(zakatBase * 0.025)}.", "Your wealth ${Fmt.money(zakatBase)} exceeds nisab (${Fmt.money(nisab)}). If a lunar year passed, zakat 2.5% ≈ ${Fmt.money(zakatBase * 0.025)}."))
        val budgets = LivingAuto.budgetStates(entries).filter { it.ratio >= 0.8 }
        budgets.take(3).forEach { b -> tips += Tip(if (b.ratio > 1) 3 else 2, Living.cat(Living.EXPENSE, b.category).emoji, tr("ميزانية ${Living.cat(Living.EXPENSE, b.category).label}", "${Living.cat(Living.EXPENSE, b.category).label} budget"), tr("استهلكت ${(b.ratio * 100).roundToInt()}% من ميزانية هذا الشهر.", "Used ${(b.ratio * 100).roundToInt()}% of this month's budget.")) }
        if (Extras.budgets.isEmpty() && inc > 0) tips += Tip(1, "🎯", tr("حدد ميزانيات شهرية", "Set monthly budgets"), tr("حدد ميزانية لكل بند (طعام، مطاعم، مواصلات) في مصاريف المعيشة وستصلك تنبيهات عند 80% وعند التجاوز.", "Set per-category budgets in living expenses to get alerts at 80% and when exceeded."))
        if (debtBal <= 0 && sr >= 0.2 && emergency >= 6) tips += Tip(0, "🏆", tr("وضعك المالي قوي", "Strong finances"), tr("بلا ديون، وادخار ممتاز، وصندوق طوارئ كامل. حافظ على ذلك ونوّع استثماراتك.", "No debt, great savings and a full emergency fund. Keep diversifying."))

        return Report(inc, exp, essential, wants, saving, n, cash, investments, debtBal, monthlyDebt, receivables, subsMonthly, emergency, score, parts, tips.sortedByDescending { it.level }, topCats, trend)
    }

    /** خطة الوصول لهدف ادخاري */
    data class Goal(val monthly: Double, val months: Int, val feasible: Boolean, val pctOfIncome: Double)
    fun goal(target: Double, saved: Double, months: Int, income: Double, expense: Double): Goal {
        val m = months.coerceAtLeast(1)
        val need = ((target - saved).coerceAtLeast(0.0)) / m
        val free = income - expense
        return Goal(need, m, need <= max(free, 0.0) || income <= 0, if (income > 0) need / income else 0.0)
    }

    /** خطة 50/30/20 لدخل معين */
    fun plan503020(income: Double) = listOf(
        tr("احتياجات أساسية 50%", "Needs 50%") to income * 0.5,
        tr("رغبات وكماليات 30%", "Wants 30%") to income * 0.3,
        tr("ادخار وسداد ديون 20%", "Savings & debt 20%") to income * 0.2
    )
}
