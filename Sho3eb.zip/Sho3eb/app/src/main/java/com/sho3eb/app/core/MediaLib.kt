package com.sho3eb.app.core

import org.json.JSONObject
import java.net.URLEncoder

/** مكتبة أفلام ومسلسلات قانونية: Internet Archive (ملكية عامة/مجانية)، بحث يوتيوب، وأين أشاهده (JustWatch) */
object MediaLib {
    data class Item(val id: String, val title: String, val year: String, val desc: String, val thumb: String)
    data class FileOpt(val name: String, val url: String, val label: String, val size: Long)

    val categories = listOf(
        Opt("feature_films", "أفلام كلاسيكية", "Classic films", "🎬"),
        Opt("classic_tv", "مسلسلات كلاسيكية", "Classic TV", "📺"),
        Opt("classic_cartoons", "كرتون الأطفال", "Kids cartoons", "🧸"),
        Opt("animationandcartoons", "رسوم متحركة", "Animation", "🎨"),
        Opt("sci-fi_horror", "خيال علمي", "Sci-fi", "🚀"),
        Opt("film_noir", "أفلام نوار", "Film noir", "🕵️"),
        Opt("comedy_films", "كوميدي", "Comedy", "😂"),
        Opt("documentaries", "وثائقي", "Documentaries", "🌍")
    )
    val kidsCollections = setOf("classic_cartoons", "animationandcartoons")

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** openOnly: أعمال مفتوحة الترخيص فقط (ملكية عامة أو المشاع الإبداعي) — قانونية للمشاهدة والتنزيل */
    fun search(query: String, collection: String, page: Int = 1, openOnly: Boolean = false): List<Item> = runCatching {
        val q = buildString {
            append("mediatype:(movies)")
            if (openOnly) append(" AND (licenseurl:*creativecommons* OR licenseurl:*publicdomain* OR collection:(publicdomainmovies))")
            if (collection.isNotBlank()) append(" AND collection:($collection)")
            if (query.isNotBlank()) append(" AND (title:(").append(query).append(") OR subject:(").append(query).append("))")
        }
        val url = "https://archive.org/advancedsearch.php?q=" + enc(q) + "&fl[]=identifier&fl[]=title&fl[]=year&fl[]=description&sort[]=downloads+desc&rows=40&page=$page&output=json"
        val j = Football.cached("ia_" + (q + page).hashCode(), 6 * 3600, url) ?: return emptyList()
        val docs = JSONObject(j).getJSONObject("response").getJSONArray("docs")
        (0 until docs.length()).map { docs.getJSONObject(it) }.map { o ->
            val id = o.optString("identifier")
            val d = o.opt("description").let { if (it is org.json.JSONArray) it.optString(0) else it?.toString() ?: "" }.replace(Regex("<[^>]+>"), "").take(300)
            Item(id, o.optString("title").let { if (it.startsWith("[")) it.trim('[', ']', '"') else it }, o.optString("year"), d, "https://archive.org/services/img/$id")
        }
    }.getOrDefault(emptyList())

    /** ملفات الفيديو المتاحة للعنصر (جودات مختلفة) */
    fun files(id: String): List<FileOpt> = runCatching {
        val j = Football.cached("iam_$id", 24 * 3600, "https://archive.org/metadata/$id") ?: return emptyList()
        val a = JSONObject(j).getJSONArray("files")
        (0 until a.length()).map { a.getJSONObject(it) }.filter { f ->
            val n = f.optString("name").lowercase()
            (n.endsWith(".mp4") || n.endsWith(".m4v") || n.endsWith(".webm") || n.endsWith(".ogv")) && f.optString("source") != "metadata"
        }.map { f ->
            val n = f.optString("name"); val fmt = f.optString("format")
            val h = f.optString("height").toIntOrNull()
            FileOpt(n, "https://archive.org/download/$id/" + n.split("/").joinToString("/") { enc(it).replace("+", "%20") },
                (if (h != null && h > 0) "${h}p • " else "") + fmt.ifBlank { n.substringAfterLast('.') }, f.optString("size").toLongOrNull() ?: 0L)
        }.sortedWith(compareBy({ if (it.name.endsWith(".mp4", true)) 0 else 1 }, { -it.size }))
    }.getOrDefault(emptyList())

    /** تنزيل ملف قانوني مباشر (مثل أفلام Internet Archive أو روابطك) إلى Movies/Sho3eb بمدير التنزيلات */
    fun download(ctx: android.content.Context, url: String, title: String): Boolean = runCatching {
        if (url.contains(".m3u8", true) || url.contains(".mpd", true) || url.contains("youtube.com") || url.contains("youtu.be")) return false
        val ext = url.substringBefore('?').substringAfterLast('.', "mp4").take(5).ifBlank { "mp4" }
        val safe = title.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(80).ifBlank { "video" }
        val req = android.app.DownloadManager.Request(android.net.Uri.parse(url))
            .setTitle(title).setDescription(tr("تنزيل من Sho3eb", "Downloading from Sho3eb"))
            .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_MOVIES, "Sho3eb/$safe.$ext")
            .setAllowedOverMetered(true)
        (ctx.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(req)
        true
    }.getOrDefault(false)

    fun youtube(q: String, kids: Boolean = false) = "https://m.youtube.com/results?search_query=" + enc(q + if (kids) " " + tr("للأطفال", "for kids") else "")
    fun whereToWatch(q: String, country: String = "eg") = "https://www.justwatch.com/$country/search?q=" + enc(q)
    /** حلقات/أجزاء قانونية مجانية على يوتيوب الأطفال */
    val kidsChannels = listOf(
        "سبيستون Spacetoon" to "https://m.youtube.com/results?search_query=Spacetoon",
        "Baby Shark Arabic" to "https://m.youtube.com/results?search_query=Pinkfong+Arabic",
        "Cocomelon Arabic" to "https://m.youtube.com/results?search_query=Cocomelon+Arabic",
        "قناة طيور الجنة" to "https://m.youtube.com/results?search_query=" + enc("طيور الجنة الرسمية"),
        "مدرسة الحروف" to "https://m.youtube.com/results?search_query=" + enc("تعليم الحروف للأطفال")
    )
}
