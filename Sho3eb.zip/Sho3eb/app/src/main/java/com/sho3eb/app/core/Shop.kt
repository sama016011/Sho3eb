package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate

// =====================================================================
//                    المحل والمخزون والفواتير
// =====================================================================
object Shop {
    const val SALE = "SALE"          // فاتورة بيع
    const val PURCHASE = "PURCHASE"  // فاتورة شراء من مورد
    const val QUOTE = "QUOTE"        // عرض سعر
    const val SRETURN = "SRETURN"    // مرتجع مبيعات
    const val PRETURN = "PRETURN"    // مرتجع مشتريات

    val types = listOf(
        Opt(SALE, "فاتورة بيع", "Sales invoice", "🧾"),
        Opt(PURCHASE, "فاتورة شراء", "Purchase invoice", "📦"),
        Opt(QUOTE, "عرض سعر", "Quotation", "📝"),
        Opt(SRETURN, "مرتجع مبيعات", "Sales return", "↩️"),
        Opt(PRETURN, "مرتجع مشتريات", "Purchase return", "↪️")
    )
    fun type(k: String) = types.firstOrNull { it.key == k } ?: types.first()
    fun prefix(k: String) = when (k) { PURCHASE -> "P"; QUOTE -> "Q"; SRETURN -> "SR"; PRETURN -> "PR"; else -> "S" }
    fun numberText(i: Invoice) = prefix(i.type) + "-" + i.number.toString().padStart(4, '0')

    /** هل الفاتورة تدخل في حساب الأموال (عروض الأسعار لا تدخل) */
    fun isMoney(t: String) = t != QUOTE
    /** الأموال الداخلة لي: البيع ومرتجع المشتريات */
    fun isIncoming(t: String) = t == SALE || t == PRETURN
    /** الطرف: عميل أم مورد */
    fun isCustomerSide(t: String) = t == SALE || t == QUOTE || t == SRETURN

    /** أثر الفاتورة على المخزون لكل وحدة */
    fun stockSign(t: String) = when (t) { SALE -> -1.0; PRETURN -> -1.0; PURCHASE -> 1.0; SRETURN -> 1.0; else -> 0.0 }

    val methods = listOf(
        Opt("CASH", "نقداً", "Cash", "💵"), Opt("CARD", "شبكة / بطاقة", "Card", "💳"),
        Opt("TRANSFER", "تحويل بنكي", "Bank transfer", "🏦"), Opt("OTHER", "أخرى", "Other", "📦")
    )
    fun method(k: String) = methods.firstOrNull { it.key == k } ?: methods.first()

    data class Totals(val subtotal: Double, val discount: Double, val tax: Double, val total: Double, val cost: Double) {
        val profit get() = round2(total - tax - cost)
    }

    fun totals(inv: Invoice, items: List<InvoiceItem>): Totals {
        val sub = round2(items.sumOf { it.qty * it.price })
        val disc = inv.discount.coerceIn(0.0, sub)
        val taxable = sub - disc
        val tax = round2(taxable * inv.taxPct / 100.0)
        val cost = round2(items.sumOf { it.qty * it.cost })
        return Totals(sub, disc, tax, round2(taxable + tax), cost)
    }

    fun paid(invId: Long, pays: List<InvoicePayment>) = round2(pays.filter { it.invoiceId == invId }.sumOf { it.amount })

    data class InvRow(val inv: Invoice, val t: Totals, val paid: Double) {
        val remaining get() = round2((t.total - paid).coerceAtLeast(0.0))
        val isPaid get() = remaining < 0.01
        val overdue get() = !isPaid && inv.dueDate != null && inv.dueDate < Fmt.today()
    }

    fun rows(invs: List<Invoice>, items: List<InvoiceItem>, pays: List<InvoicePayment>): List<InvRow> {
        val byInv = items.groupBy { it.invoiceId }
        val byPay = pays.groupBy { it.invoiceId }
        return invs.map { i -> InvRow(i, totals(i, byInv[i.id].orEmpty()), round2(byPay[i.id].orEmpty().sumOf { it.amount })) }
    }

    /** الكمية الحالية = الافتتاحي + المشتريات + مرتجع البيع − المبيعات − مرتجع الشراء ± التسويات */
    fun stock(p: Product, invs: Map<Long, Invoice>, items: List<InvoiceItem>, adjs: List<StockAdj>): Double {
        var q = p.openingQty
        items.forEach { it0 -> if (it0.productId == p.id) invs[it0.invoiceId]?.let { q += stockSign(it.type) * it0.qty } }
        adjs.forEach { if (it.productId == p.id) q += it.qty }
        return round2(q)
    }

    fun stockMap(products: List<Product>, invs: List<Invoice>, items: List<InvoiceItem>, adjs: List<StockAdj>): Map<Long, Double> {
        val im = invs.associateBy { it.id }
        val acc = HashMap<Long, Double>()
        products.forEach { acc[it.id] = it.openingQty }
        items.forEach { x -> val pid = x.productId ?: return@forEach; val i = im[x.invoiceId] ?: return@forEach; if (acc.containsKey(pid)) acc[pid] = acc[pid]!! + stockSign(i.type) * x.qty }
        adjs.forEach { a -> if (acc.containsKey(a.productId)) acc[a.productId] = acc[a.productId]!! + a.qty }
        return acc.mapValues { round2(it.value) }
    }

    fun isLow(p: Product, qty: Double) = p.trackStock && p.active && qty <= p.minQty

    // ---------- الأطراف (عملاء وموردون) تُستخرج من الفواتير ----------
    data class Party(val key: String, val name: String, val phone: String, val personId: Long?, val customer: Boolean,
                     val count: Int, val total: Double, val paid: Double, val remaining: Double, val last: Long)

    fun partyKey(i: Invoice) = i.personId?.let { "p$it" } ?: (i.partyPhone.filter { it.isDigit() }.takeLast(9).ifBlank { i.partyName.trim().lowercase() })

    fun parties(rows: List<InvRow>, customers: Boolean): List<Party> =
        rows.filter { isMoney(it.inv.type) && isCustomerSide(it.inv.type) == customers && it.inv.partyName.isNotBlank() }
            .groupBy { partyKey(it.inv) }
            .map { (k, l) ->
                val sign = { r: InvRow -> if (r.inv.type == SRETURN || r.inv.type == PRETURN) -1.0 else 1.0 }
                val last = l.maxBy { it.inv.date }
                Party(k, last.inv.partyName, l.firstOrNull { it.inv.partyPhone.isNotBlank() }?.inv?.partyPhone ?: "", last.inv.personId, customers,
                    l.size, round2(l.sumOf { sign(it) * it.t.total }), round2(l.sumOf { sign(it) * it.paid }), round2(l.sumOf { sign(it) * it.remaining }), last.inv.date)
            }.sortedByDescending { it.remaining }

    // ---------- الإحصاءات ----------
    data class Stats(val sales: Double, val returns: Double, val purchases: Double, val cost: Double, val tax: Double, val collected: Double, val count: Int) {
        val net get() = round2(sales - returns)
        val profit get() = round2(net - cost)
    }

    fun stats(rows: List<InvRow>, items: List<InvoiceItem>, range: LongRange?): Stats {
        val r = rows.filter { range == null || it.inv.date in range }
        val sales = r.filter { it.inv.type == SALE }
        val ret = r.filter { it.inv.type == SRETURN }
        return Stats(
            round2(sales.sumOf { it.t.total - it.t.tax }), round2(ret.sumOf { it.t.total - it.t.tax }),
            round2(r.filter { it.inv.type == PURCHASE }.sumOf { it.t.total }),
            round2(sales.sumOf { it.t.cost } - ret.sumOf { it.t.cost }),
            round2(sales.sumOf { it.t.tax } - ret.sumOf { it.t.tax }),
            round2(sales.sumOf { it.paid }), sales.size
        )
    }

    data class TopItem(val name: String, val qty: Double, val amount: Double, val profit: Double)

    fun topItems(rows: List<InvRow>, items: List<InvoiceItem>, range: LongRange?): List<TopItem> {
        val ids = rows.filter { it.inv.type == SALE && (range == null || it.inv.date in range) }.map { it.inv.id }.toSet()
        return items.filter { it.invoiceId in ids }.groupBy { it.productId?.toString() ?: it.name }
            .map { (_, l) -> TopItem(l.first().name, round2(l.sumOf { it.qty }), round2(l.sumOf { it.qty * it.price }), round2(l.sumOf { it.qty * (it.price - it.cost) })) }
            .sortedByDescending { it.amount }
    }

    suspend fun nextNumber(dao: AppDao, type: String) = dao.maxInvoiceNumber(type) + 1

    /** نص الفاتورة للمشاركة عبر واتساب */
    fun shareText(r: InvRow, items: List<InvoiceItem>): String {
        val sb = StringBuilder()
        val shop = Extras.shopName.ifBlank { AppState.displayName.value }
        if (shop.isNotBlank()) sb.append("🏪 ").append(shop).append('\n')
        sb.append(type(r.inv.type).label).append(" ").append(numberText(r.inv)).append(" • ").append(Fmt.date(r.inv.date)).append('\n')
        if (r.inv.partyName.isNotBlank()) sb.append(tr("السيد/ة: ", "To: ")).append(r.inv.partyName).append('\n')
        sb.append("—————————\n")
        items.forEach { sb.append("• ").append(it.name).append("  ").append(Fmt.num(it.qty)).append(" × ").append(Fmt.num(it.price)).append(" = ").append(Fmt.num(it.qty * it.price)).append('\n') }
        sb.append("—————————\n")
        if (r.t.discount > 0) sb.append(tr("الخصم: ", "Discount: ")).append(Fmt.money(r.t.discount)).append('\n')
        if (r.t.tax > 0) sb.append(tr("الضريبة ", "Tax ")).append(Fmt.num(r.inv.taxPct)).append("%: ").append(Fmt.money(r.t.tax)).append('\n')
        sb.append(tr("الإجمالي: ", "Total: ")).append(Fmt.money(r.t.total)).append('\n')
        if (isMoney(r.inv.type)) {
            sb.append(tr("المدفوع: ", "Paid: ")).append(Fmt.money(r.paid)).append('\n')
            if (!r.isPaid) sb.append(tr("المتبقي: ", "Balance due: ")).append(Fmt.money(r.remaining)).append('\n')
        }
        if (Extras.shopFooter.isNotBlank()) sb.append('\n').append(Extras.shopFooter)
        return sb.toString()
    }

}

// =====================================================================
//                         خزنة المستندات
// =====================================================================
object Vault {
    val types = listOf(
        Opt("ID", "هوية وطنية", "National ID", "🪪"), Opt("PASSPORT", "جواز سفر", "Passport", "🛂"),
        Opt("IQAMA", "إقامة", "Residence permit", "📇"), Opt("LICENSE", "رخصة قيادة", "Driving license", "🚘"),
        Opt("CAR_REG", "استمارة سيارة", "Vehicle registration", "📄"), Opt("INSURANCE", "تأمين", "Insurance", "🛡️"),
        Opt("WARRANTY", "ضمان جهاز", "Warranty", "🧾"), Opt("CONTRACT", "عقد", "Contract", "📑"),
        Opt("CERT", "شهادة", "Certificate", "🎓"), Opt("MEDICAL", "تقرير طبي", "Medical report", "🩺"),
        Opt("VISA", "تأشيرة", "Visa", "✈️"), Opt("CR", "سجل تجاري / رخصة محل", "Business license", "🏪"),
        Opt("OTHER", "أخرى", "Other", "📁")
    )
    fun type(k: String) = types.firstOrNull { it.key == k } ?: types.last()

    fun daysLeft(d: VaultDoc): Int? = d.expiryDate?.let { (it - Fmt.today()).toInt() }
    fun isExpired(d: VaultDoc) = (daysLeft(d) ?: 1) < 0
    fun isSoon(d: VaultDoc) = daysLeft(d)?.let { it in 0..d.remindDays } == true

    fun status(d: VaultDoc): String {
        val left = daysLeft(d) ?: return tr("بدون تاريخ انتهاء", "No expiry")
        return when {
            left < 0 -> tr("منتهي منذ ${-left} يوم", "Expired ${-left} d ago")
            left == 0 -> tr("ينتهي اليوم", "Expires today")
            left < 60 -> tr("ينتهي بعد $left يوم", "Expires in $left d")
            else -> tr("ساري حتى ", "Valid until ") + Fmt.date(d.expiryDate!!)
        }
    }

    /** اقتراح مدة التجديد الافتراضية بالسنوات */
    fun defaultYears(k: String) = when (k) { "PASSPORT" -> 5; "ID" -> 10; "LICENSE" -> 10; "IQAMA", "CAR_REG", "INSURANCE", "CR" -> 1; "WARRANTY" -> 2; else -> 1 }

    fun renew(d: VaultDoc, years: Int): VaultDoc {
        val base = d.expiryDate?.let { LocalDate.ofEpochDay(it) }?.takeIf { !it.isBefore(LocalDate.now()) } ?: LocalDate.now()
        return d.copy(issueDate = Fmt.today(), expiryDate = base.plusYears(years.toLong()).toEpochDay())
    }
}
