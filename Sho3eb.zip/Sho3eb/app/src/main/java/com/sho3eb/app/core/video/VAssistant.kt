package com.sho3eb.app.core.video

import com.sho3eb.app.core.tr

/**
 * المساعد الذكي للمحرر: يفهم أمراً مكتوباً (عربي أو إنجليزي) ويحوّله إلى إعدادات فيديو جاهزة:
 * المناسبة/القالب، المدة، المقاس، الجودة، المؤثرات، الانتقالات، الخلفية، الفلتر، العنوان والبداية والنهاية.
 * يعمل على الهاتف بالكامل بدون إنترنت.
 */
object VAssistant {
    val examples = listOf(
        "فيديو عيد ميلاد لأحمد مدته 30 ثانية بالطول مع بالونات وانتقالات 3D وعنوان «عيد ميلاد سعيد يا أحمد»",
        "فيديو زفاف بجودة عالية مع ورد وإطار ذهبي وخلفية مشرقة ونهاية شكراً للمشاهدة",
        "فيديو رمضان مربع مع فوانيس ونجوم وفلتر دافئ",
        "فيديو أطفال مع قطة تجري وفراشة وفقاعات وانتقال مكعب",
        "فيديو سفر سينمائي أبيض وأسود مدته دقيقة مع نهاية اشترك في القناة"
    )

    private fun any(t: String, vararg w: String) = w.any { t.contains(it) }

    fun apply(cmd: String): String {
        val t = " " + cmd.lowercase().replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي').map { ch -> if (ch in '٠'..'٩') ('0' + (ch - '٠')) else if (ch in '۰'..'۹') ('0' + (ch - '۰')) else ch }.joinToString("") + " "
        val done = mutableListOf<String>()
        val p0 = VEditor.project.value
        if (p0.clips.none { !it.isCard }) return tr("أضف الصور أو الفيديوهات أولاً من زر «صور/فيديو»، ثم اكتب الأمر من جديد.", "Add photos/videos first, then send the command again.")

        // ===== المناسبة =====
        val tpl = when {
            any(t, "ميلاد", "birthday") && !any(t, "كريسماس", "christmas", "المجيد") -> "BIRTHDAY"
            any(t, "زفاف", "فرح", "عرس", "زواج", "خطوبه", "wedding") -> "WEDDING"
            any(t, "حب", "فالنتين", "حبيب", "love", "valentine") -> "LOVE"
            any(t, "رمضان", "ramadan") -> "RAMADAN"
            any(t, "عيد الفطر", "عيد الاضحي", "عيد مبارك", " عيد ", "eid") -> "EID"
            any(t, "كريسماس", "christmas", "الكريسماس") -> "XMAS"
            any(t, "تخرج", "graduat") -> "GRAD"
            any(t, "مولود", "بيبي", "baby", "سبوع") -> "BABY"
            any(t, "عيد الام", "امي", "ماما", "mother") -> "MOTHER"
            any(t, "راس السنه", "سنه جديده", "new year") -> "NEWYEAR"
            any(t, "حيوان", "animal") -> "ANIMALS"
            any(t, "اطفال", "طفل", "kids", "child") -> "KIDS"
            any(t, "سفر", "رحله", "ذكريات", "travel", "trip") -> "TRAVEL"
            any(t, "سينما", "فيلم", "cinema", "movie") -> "CINEMA"
            else -> ""
        }
        // ===== المدة =====
        var totalSec = 0
        Regex("(\\d+)\\s*(ثانيه|ثواني|ثوان|ث(?=\\s)|sec|second|s(?=\\s))").find(t)?.let { totalSec = it.groupValues[1].toInt() }
        Regex("(\\d+)\\s*(دقيقه|دقائق|min)").find(t)?.let { totalSec = it.groupValues[1].toInt() * 60 }
        if (totalSec == 0 && any(t, "دقيقه", "minute")) totalSec = 60
        if (totalSec == 0 && any(t, "نصف دقيقه")) totalSec = 30
        val media = p0.clips.count { !it.isCard }
        val cards = (if (any(t, "بدايه", "مقدمه", "intro") || tpl.isNotEmpty()) 4 else 0) + (if (any(t, "نهايه", "خاتمه", "اشترك", "شكرا", "outro") || tpl.isNotEmpty()) 4 else 0)
        val secsEach = if (totalSec > 0) ((totalSec - cards).coerceAtLeast(media * 2) / media).coerceIn(2, 10) else 4

        if (tpl.isNotEmpty()) {
            VEditor.templates.firstOrNull { it.key == tpl }?.let { VEditor.applyTemplate(it, secsEach); done += tr("قالب ", "Template ") + it.label }
        } else VEditor.update { p -> p.copy(clips = p.clips.map { if (it.isCard || it.video) it else it.copy(durMs = secsEach * 1000L) }) }
        if (totalSec > 0) done += tr("المدة ≈ $totalSec ث", "Length ≈ ${totalSec}s")

        // ===== المقاس والجودة =====
        val aspect = when {
            any(t, "بالطول", "طولي", "ستوري", "ريلز", "تيك توك", "تيكتوك", "9:16", "reels", "tiktok", "story", "vertical") -> "9:16"
            any(t, "مربع", "1:1", "square") -> "1:1"
            any(t, "4:5", "بوست انستجرام") -> "4:5"
            any(t, "بالعرض", "عرضي", "يوتيوب", "16:9", "youtube", "landscape") -> "16:9"
            else -> null
        }
        val quality = when { any(t, "1080", "عاليه", "فل اتش دي", "full hd", "high") -> 1080; any(t, "480", "منخفضه", "حجم صغير", "low") -> 480; any(t, "720") -> 720; else -> null }
        VEditor.update { p -> p.copy(aspect = aspect ?: p.aspect, quality = quality ?: p.quality) }
        aspect?.let { done += tr("المقاس ", "Aspect ") + it }; quality?.let { done += "${it}p" }

        // ===== المؤثرات =====
        val fxMap = listOf(
            "SNOW" to listOf("ثلج", "snow"), "RAIN" to listOf("مطر", "rain"), "FIREWORKS" to listOf("العاب ناريه", "صواريخ", "firework"),
            "HEARTS" to listOf("قلوب", "hearts"), "BALLOONS" to listOf("بالون", "balloon"), "STARS" to listOf("نجوم", "stars"),
            "BUBBLES" to listOf("فقاعات", "bubble"), "PETALS" to listOf("ورد", "بتلات", "petal", "flower"), "CONFETTI" to listOf("قصاصات", "كونفيتي", "confetti"),
            "LANTERNS" to listOf("فوانيس", "فانوس", "lantern"), "SPARKLES" to listOf("بريق", "لمعه", "sparkle"), "LEAVES" to listOf("اوراق", "خريف", "leaves"),
            "C_BUTTERFLY" to listOf("فراشه", "فراش", "butterfl"), "C_CAT" to listOf("قطه", "قط ", "cat"), "C_DOG" to listOf("كلب", "dog"),
            "C_HORSE" to listOf("حصان", "horse"), "C_UNICORN" to listOf("يونيكورن", "unicorn"), "C_BIRDS" to listOf("طيور", "birds"),
            "C_FISH" to listOf("سمك", "fish"), "C_BEE" to listOf("نحله", "bee"), "C_SANTA" to listOf("سانتا", "santa"), "C_CAR" to listOf("سياره", "car"),
            "C_PLANE" to listOf("طائره", "plane"), "C_DUCKS" to listOf("بطه", "بطط", "duck")
        )
        val total = VEditor.project.value.totalMs
        val introDur = VEditor.project.value.clips.firstOrNull { it.kind == "intro" }?.durMs ?: 0L
        fxMap.filter { (_, ws) -> ws.any { t.contains(it) } }.forEach { (k, _) ->
            if (VEditor.project.value.overlays.none { it.kind == "FX" && it.key == k }) {
                VEditor.update { p -> p.copy(overlays = p.overlays + VOverlay(kind = "FX", key = k, startMs = introDur, durMs = (total - introDur).coerceAtLeast(1000))) }
                done += VEditor.fxKinds.firstOrNull { it.key == k }?.let { it.emoji + " " + it.label } ?: k
            }
        }
        // ===== الإطار =====
        val frame = when { any(t, "اطار ذهبي", "ذهبي", "gold") -> "GOLD"; any(t, "اطار ورد", "frame flower") -> "FLOWERS"; any(t, "نيون", "neon") -> "NEON"; any(t, "اطار سينما") -> "FILM"; any(t, "اطار قديم", "vintage") -> "VINTAGE"; else -> null }
        frame?.let { f -> VEditor.update { p -> p.copy(overlays = p.overlays.filter { it.kind != "FRAME" } + VOverlay(kind = "FRAME", key = f, startMs = introDur, durMs = (total - introDur).coerceAtLeast(1000))) }; done += tr("إطار ", "Frame ") + (VEditor.frames.firstOrNull { it.key == f }?.label ?: f) }

        // ===== الانتقالات =====
        val trans = when {
            any(t, "مكعب", "cube") -> "CUBE"; any(t, "7d", "سباعي", "نفق", "tunnel") -> "TUNNEL"; any(t, "دوامه", "vortex") -> "VORTEX"
            any(t, "صفحه", "page") -> "PAGE"; any(t, "ابواب", "باب", "door") -> "DOOR"; any(t, "تفتت", "shatter") -> "SHATTER"
            any(t, "3d", "ثلاثي", "ثري دي") -> "FLIP"; any(t, "انتقال قلب", "heart transition") -> "HEART"; any(t, "تلاشي", "fade") -> "FADE"
            any(t, "انزلاق", "slide") -> "SLIDE_L"; any(t, "دوران", "spin") -> "SPIN"; else -> null
        }
        trans?.let { k -> VEditor.update { p -> p.copy(clips = p.clips.map { it.copy(transition = k) }) }; done += tr("انتقال ", "Transition ") + (VEditor.transitions.firstOrNull { it.key == k }?.label ?: k) }

        // ===== الخلفية =====
        val bg = when {
            any(t, "خلفيه مشرق", "مشرقه", "sunburst") -> "SUNBURST"; any(t, "خلفيه ثلج", "رقائق") -> "SNOWFLAKES"; any(t, "خلفيه هدايا", "هدايا") -> "GIFTS"
            any(t, "خلفيه قلوب") -> "HEARTS"; any(t, "خلفيه نجوم") -> "STARS"; any(t, "خلفيه بالونات") -> "BALLOONS"; any(t, "لمعان", "جليتر", "glitter") -> "GLITTER"
            any(t, "بوكيه", "bokeh") -> "BOKEH"; any(t, "غروب", "sunset") -> "SUNSET"; any(t, "محيط", "بحر", "ocean") -> "OCEAN"; any(t, "ضبابي", "blur") -> "BLUR"
            else -> null
        }
        bg?.let { b -> VEditor.update { it.copy(bg = b) }; done += tr("خلفية ", "Background ") + (VEditor.backgrounds.firstOrNull { it.key == b }?.label ?: b) }

        // ===== الفلتر والتحسين =====
        val filter = when { any(t, "ابيض واسود", "black and white", "b&w") -> "BW"; any(t, "قديم", "sepia", "فينتاج") -> "SEPIA"; any(t, "دافئ", "warm") -> "WARM"; any(t, "بارد", "cool") -> "COOL"; any(t, "زاهي", "vivid", "الوان قويه") -> "VIVID"; any(t, "ناعم", "soft") -> "FADED"; else -> null }
        filter?.let { f -> VEditor.update { it.copy(filter = f) }; done += tr("فلتر ", "Filter ") + (VEditor.filters.firstOrNull { it.key == f }?.label ?: f) }
        val enh = buildList {
            if (any(t, "حسن", "تحسين", "enhance", "نقي", "واضح")) add("AUTO")
            if (any(t, "جمل", "تجميل", "بشره", "beauty")) add("BEAUTY")
            if (any(t, "مظلم", "اضاءه", "نور", "bright")) add("BRIGHT")
            if (any(t, "تشويش", "noise", "تنقيه")) add("DENOISE")
            if (any(t, "بورتريه", "portrait", "خلفيه مغبشه")) add("PORTRAIT")
        }
        if (enh.isNotEmpty()) { VEditor.update { p -> p.copy(clips = p.clips.map { if (it.isCard) it else it.copy(enh = enh.joinToString(",")) }) }; done += tr("تحسين الصور: ", "Enhance: ") + enh.joinToString("، ") { k -> VEditor.enhances.firstOrNull { it.key == k }?.label ?: k } }

        // ===== العنوان والبداية والنهاية =====
        val quoted = Regex("[«\"“](.+?)[»\"”]").find(cmd)?.groupValues?.get(1)
        val named = Regex("(?:بعنوان|عنوانه|عنوان|title)\\s*[:：]?\\s*([^،,.\\n]+)").find(cmd)?.groupValues?.get(1)?.trim()
        val forName = Regex("(?:ميلاد|زفاف|تخرج)\\s+(?:ل|لـ)\\s*([^\\s،,.]+)").find(cmd)?.groupValues?.get(1)
        val title = quoted ?: named ?: forName?.let { n -> when (tpl) { "BIRTHDAY" -> tr("عيد ميلاد سعيد يا $n 🎂", "Happy Birthday $n 🎂"); "WEDDING" -> tr("زفاف $n 💍", "$n's Wedding 💍"); "GRAD" -> tr("مبروك التخرج يا $n 🎓", "Congrats $n 🎓"); else -> n } }
        if (title != null || any(t, "بدايه", "مقدمه", "intro")) {
            val style = VEditor.project.value.clips.firstOrNull { it.kind == "intro" }?.style ?: "I_GOLD"
            VEditor.setCard("intro", style, title ?: VEditor.defaultTitle(style).first); done += tr("بداية: ", "Intro: ") + (title ?: "")
        }
        val outro = when { any(t, "اشترك", "subscribe") -> "O_SUBSCRIBE"; any(t, "شكرا", "thanks") -> "O_THANKS"; any(t, "النهايه", "the end") -> "O_END"; any(t, "شعار", "logo") -> "O_LOGO"; else -> null }
        outro?.let { VEditor.setCard("outro", it); done += tr("نهاية: ", "Outro: ") + (VEditor.outros.firstOrNull { o -> o.key == it }?.label ?: it) }

        if (any(t, "موسيقي", "اغنيه", "music", "song") && VEditor.project.value.audios.isEmpty())
            done += tr("🎵 أضف الموسيقى من زر «موسيقى/صوت»", "🎵 Add music with the Music button")
        return if (done.isEmpty()) tr("لم أفهم الأمر. جرّب ذكر المناسبة والمدة والمؤثرات، مثل الأمثلة بالأسفل.", "I didn't understand. Mention the occasion, length and effects like the examples.")
        else tr("✅ تم: ", "✅ Done: ") + done.joinToString(" • ")
    }
}
