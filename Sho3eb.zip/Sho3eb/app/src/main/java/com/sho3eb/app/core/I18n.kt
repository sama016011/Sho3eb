package com.sho3eb.app.core

import com.sho3eb.app.Sho3ebApp
import java.util.Locale

/**
 * طبقة ترجمة إضافية فوق tr(ar, en):
 * النص الإنجليزي هو المفتاح، والترجمات محفوظة في assets/i18n/<lang>.tsv
 * يدعم النصوص المتغيرة (التي تحتوي ${...}) بمطابقة القالب واستبدال القيم.
 */
object I18n {
    data class Lang(val code: String, val name: String, val rtl: Boolean)

    val languages = listOf(
        Lang("ar", "العربية", true),
        Lang("en", "English", false),
        Lang("ur", "اردو", true),
        Lang("id", "Bahasa Indonesia", false),
        Lang("tr", "Türkçe", false),
        Lang("fr", "Français", false)
    )

    fun isRtl(code: String) = languages.firstOrNull { it.code == code }?.rtl ?: false
    fun name(code: String) = languages.firstOrNull { it.code == code }?.name ?: code

    private class Tpl(val regex: Regex, val tokens: List<String>, val value: String, val prefix: String, val suffix: String, val litLen: Int)

    @Volatile private var loaded = ""
    private var exact: Map<String, String> = emptyMap()
    private var templates: List<Tpl> = emptyList()
    private val cache = HashMap<String, String>()
    private val lock = Any()

    private fun unescape(s: String): String {
        if (!s.contains('\\')) return s
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) { 'n' -> sb.append('\n'); 't' -> sb.append('\t'); '\\' -> sb.append('\\'); else -> { sb.append(c); sb.append(s[i + 1]) } }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    /** تقسيم القالب إلى نصوص ثابتة وتعبيرات ${...} أو $name */
    private fun split(key: String): Pair<List<String>, List<String>> {
        val lits = mutableListOf<String>(); val toks = mutableListOf<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < key.length) {
            val c = key[i]
            if (c == '$' && i + 1 < key.length && key[i + 1] == '{') {
                var depth = 0; var j = i + 1
                while (j < key.length) { if (key[j] == '{') depth++ else if (key[j] == '}') { depth--; if (depth == 0) break }; j++ }
                lits += cur.toString(); cur.clear(); toks += key.substring(i, minOf(j + 1, key.length)); i = j + 1
            } else if (c == '$' && i + 1 < key.length && (key[i + 1].isLetter() || key[i + 1] == '_')) {
                var j = i + 1
                while (j < key.length && (key[j].isLetterOrDigit() || key[j] == '_')) j++
                lits += cur.toString(); cur.clear(); toks += key.substring(i, j); i = j
            } else { cur.append(c); i++ }
        }
        lits += cur.toString()
        return lits to toks
    }

    private fun load(code: String) {
        val ex = HashMap<String, String>(4096)
        val tp = mutableListOf<Tpl>()
        try {
            Sho3ebApp.instance.assets.open("i18n/$code.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { line ->
                    val t = line.indexOf('\t')
                    if (t <= 0) return@forEach
                    val k = unescape(line.substring(0, t)); val v = unescape(line.substring(t + 1))
                    if (v.isBlank()) return@forEach
                    if (k.contains('$')) {
                        val (lits, toks) = split(k)
                        if (toks.isEmpty()) { ex[k] = v; return@forEach }
                        val sb = StringBuilder("^")
                        lits.forEachIndexed { n, l -> sb.append(Regex.escape(l)); if (n < toks.size) sb.append(if (n == toks.size - 1) "(.*)" else "(.*?)") }
                        sb.append('$')
                        tp += Tpl(Regex(sb.toString(), RegexOption.DOT_MATCHES_ALL), toks, v, lits.first(), lits.last(), lits.sumOf { it.length })
                    } else ex[k] = v
                }
            }
        } catch (_: Exception) { }
        exact = ex; templates = tp.sortedByDescending { it.litLen }; cache.clear(); loaded = code
    }

    fun t(code: String, en: String): String {
        synchronized(lock) {
            if (loaded != code) load(code)
            exact[en]?.let { return it }
            cache[en]?.let { return it }
            var out = en
            for (tp in templates) {
                if (!en.startsWith(tp.prefix) || !en.endsWith(tp.suffix)) continue
                val m = tp.regex.matchEntire(en) ?: continue
                var v = tp.value
                // أطول التعبيرات أولاً لتجنب الاستبدال الجزئي
                tp.tokens.withIndex().sortedByDescending { it.value.length }.forEach { (idx, tok) -> v = v.replace(tok, m.groupValues[idx + 1]) }
                out = v; break
            }
            if (cache.size > 4000) cache.clear()
            cache[en] = out
            return out
        }
    }

    fun locale(code: String): Locale = when (code) { "id" -> Locale("in", "ID"); else -> Locale(code) }
}
