package com.sho3eb.app.ui

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.tr
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** ملف تسجيل مكالمة محفوظ في Music|Movies/Sho3eb/Calls */
data class CallRec(val uri: Uri, val name: String, val date: Long, val size: Long, val video: Boolean, val mime: String)

object CallRecordings {
    const val SUB = "Sho3eb/Calls"

    fun list(ctx: Context): List<CallRec> {
        val out = ArrayList<CallRec>()
        val sources = listOf(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to false,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI to true
        )
        for ((base, isVid) in sources) runCatching {
            val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE)
            @Suppress("DEPRECATION")
            val (sel, args) = if (Build.VERSION.SDK_INT >= 29) "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?" to arrayOf("%$SUB%")
                              else "${MediaStore.MediaColumns.DATA} LIKE ?" to arrayOf("%$SUB%")
            ctx.contentResolver.query(base, proj, sel, args, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out += CallRec(ContentUris.withAppendedId(base, id), c.getString(1) ?: "", c.getLong(2) * 1000L, c.getLong(3), isVid, c.getString(4) ?: if (isVid) "video/*" else "audio/*")
                }
            }
        }
        return out.sortedByDescending { it.date }
    }

    fun play(ctx: Context, r: CallRec) {
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(r.uri, r.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { Toast.makeText(ctx, tr("لا يوجد تطبيق لتشغيل الملف", "No app can play this file"), Toast.LENGTH_SHORT).show() }
    }

    fun share(ctx: Context, r: CallRec) {
        runCatching {
            val i = Intent(Intent.ACTION_SEND).setType(r.mime).putExtra(Intent.EXTRA_STREAM, r.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, tr("مشاركة التسجيل", "Share recording")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun delete(ctx: Context, r: CallRec): Boolean = runCatching { ctx.contentResolver.delete(r.uri, null, null) > 0 }.getOrDefault(false)

    /** فتح مجلد التسجيلات في مدير الملفات */
    fun openFolder(ctx: Context, video: Boolean) {
        val rel = (if (video) "Movies/" else "Music/") + SUB
        val doc = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:$rel")
        val tries = listOf(
            Intent(Intent.ACTION_VIEW).setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR),
            Intent(Intent.ACTION_VIEW).setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR).setPackage("com.google.android.documentsui"),
            Intent(Intent.ACTION_VIEW).setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR).setPackage("com.android.documentsui"),
            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("file:///storage/emulated/0/$rel"), "resource/folder"),
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply { if (Build.VERSION.SDK_INT >= 26) putExtra(DocumentsContract.EXTRA_INITIAL_URI, doc) }
        )
        for (i in tries) {
            val ok = runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)); true }.getOrDefault(false)
            if (ok) return
        }
        Toast.makeText(ctx, tr("افتح مدير الملفات ثم المجلد: ", "Open your file manager at: ") + rel, Toast.LENGTH_LONG).show()
    }
}

/** بطاقة في إعدادات المكالمات: فتح مجلد التسجيلات وعرضها */
@Composable
fun CallRecordingsCard() {
    val ctx = LocalContext.current
    var show by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SectionTitle(tr("🎙️ تسجيلات المكالمات", "🎙️ Call recordings"))
            Text(tr("تُحفظ في: Music/Sho3eb/Calls (الصوت) و Movies/Sho3eb/Calls (الفيديو)", "Saved in Music/Sho3eb/Calls (audio) and Movies/Sho3eb/Calls (video)"),
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.LibraryMusic, null); Spacer(Modifier.width(8.dp)); Text(tr("عرض التسجيلات", "View recordings"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { CallRecordings.openFolder(ctx, false) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text(tr("مجلد الصوت", "Audio folder"), maxLines = 1)
                }
                OutlinedButton(onClick = { CallRecordings.openFolder(ctx, true) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text(tr("مجلد الفيديو", "Video folder"), maxLines = 1)
                }
            }
        }
    }
    if (show) CallRecordingsDialog { show = false }
}

@Composable
private fun CallRecordingsDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var ver by remember { mutableIntStateOf(0) }
    val items = remember(ver) { CallRecordings.list(ctx) }
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd  hh:mm a", Locale.getDefault()) }
    var confirm by remember { mutableStateOf<CallRec?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } },
        title = { Text(tr("🎙️ تسجيلات المكالمات", "🎙️ Call recordings")) },
        text = {
            if (items.isEmpty()) Text(tr("لا توجد تسجيلات بعد. يمكنك أيضاً فتح المجلد من مدير الملفات.", "No recordings yet. You can also open the folder in your file manager."))
            else LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(items, key = { it.uri.toString() }) { r ->
                    Row(Modifier.fillMaxWidth().clickable { CallRecordings.play(ctx, r) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (r.video) Icons.Filled.Videocam else Icons.Filled.Mic, null)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(fmt.format(Date(r.date)) + "  •  " + String.format(Locale.US, "%.1f MB", r.size / 1048576.0),
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { CallRecordings.share(ctx, r) }) { Icon(Icons.Filled.Share, tr("مشاركة", "Share")) }
                        IconButton(onClick = { confirm = r }) { Icon(Icons.Filled.Delete, tr("حذف", "Delete")) }
                    }
                    HorizontalDivider()
                }
            }
        }
    )
    confirm?.let { r ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            confirmButton = { TextButton(onClick = {
                if (!CallRecordings.delete(ctx, r)) Toast.makeText(ctx, tr("تعذر الحذف؛ احذفه من مدير الملفات", "Couldn't delete; use your file manager"), Toast.LENGTH_SHORT).show()
                confirm = null; ver++
            }) { Text(tr("حذف", "Delete")) } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text(tr("إلغاء", "Cancel")) } },
            title = { Text(tr("حذف التسجيل؟", "Delete recording?")) },
            text = { Text(r.name) }
        )
    }
}
