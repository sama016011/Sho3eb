package com.sho3eb.app.core

import org.json.JSONArray
import org.json.JSONObject
import java.time.format.DateTimeFormatter

/**
 * تفاصيل المباريات المباشرة بدون مفتاح:
 * - ESPN للدوريات الأوروبية والسعودية ودوري الأبطال (الأحداث، التشكيل، الهدافون، الترتيب الرسمي).
 * - SofaScore (أفضل محاولة) للدوري المصري وغيره.
 * - API-Football اختيارياً.
 */
object FootballLive {
    data class LP(val name: String, val number: String, val pos: String, val starter: Boolean, val subIn: String = "", val subOut: String = "")
    data class Lineup(val team: String, val home: Boolean, val formation: String, val players: List<LP>, val confirmed: Boolean = true) {
        val starters get() = players.filter { it.starter }
        val bench get() = players.filter { !it.starter }
    }
    data class Details(
        val events: List<Football.Event> = emptyList(), val lineups: List<Lineup> = emptyList(),
        val hs: Int? = null, val aws: Int? = null, val state: String = "", val clock: String = "", val source: String = ""
    )

    /** معرف البطولة في SofaScore */
    private val sofaIds = mapOf("4829" to 808, "4668" to 955, "4328" to 17, "4335" to 8, "4332" to 23, "4331" to 35, "4334" to 34, "4480" to 7, "4481" to 679)
    fun sofaId(leagueId: String): Int? = sofaIds[leagueId] ?: Extras.i("sofa_ut_$leagueId", 0).takeIf { it > 0 }

    private val sofaHeaders = mapOf(
        "User-Agent" to "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
        "Accept" to "application/json, text/plain, */*", "Referer" to "https://www.sofascore.com/", "Origin" to "https://www.sofascore.com", "Cache-Control" to "no-cache"
    )
    private fun sofa(path: String, ttl: Long): JSONObject? =
        runCatching { JSONObject(Football.cached("sf_" + path, ttl, "https://www.sofascore.com/api/v1/$path", sofaHeaders) ?: return null) }.getOrNull()
            ?: runCatching { JSONObject(Football.cached("sf2_" + path, ttl, "https://api.sofascore.com/api/v1/$path", sofaHeaders) ?: return null) }.getOrNull()

    private fun norm(n: String) = n.lowercase().replace(Regex("\\b(fc|cf|ac|sc|afc|ssc|as|club|de|cd|rc|sv|vfb|tsg|al|el|sporting)\\b"), "").replace(Regex("[^a-z]"), "")
    fun same(a: String, b: String): Boolean { val x = norm(a); val y = norm(b); return x.isNotEmpty() && y.isNotEmpty() && (x.contains(y) || y.contains(x) || x.take(5) == y.take(5)) }

    // =============================== ESPN ===============================
    private fun espn(url: String, key: String, ttl: Long): JSONObject? = runCatching { JSONObject(Football.cached(key, ttl, url) ?: return null) }.getOrNull()

    /** معرف المباراة في ESPN */
    private fun espnId(l: Football.League, m: Football.Match): String? {
        Extras.s("espn_id_${m.id}", "").takeIf { it.isNotBlank() }?.let { return it }
        for (d in listOf(m.date, m.date.minusDays(1), m.date.plusDays(1))) {
            val ds = d.format(DateTimeFormatter.BASIC_ISO_DATE)
            val j = espn("https://site.api.espn.com/apis/site/v2/sports/soccer/${l.espn}/scoreboard?dates=$ds", "es_${l.espn}_$ds", if (m.live) 60 else 1800) ?: continue
            val evs = j.optJSONArray("events") ?: continue
            for (k in 0 until evs.length()) {
                val ev = evs.getJSONObject(k)
                val cs = ev.optJSONArray("competitions")?.optJSONObject(0)?.optJSONArray("competitors") ?: continue
                val names = (0 until cs.length()).associate { cs.getJSONObject(it).let { c -> c.optString("homeAway") to (c.optJSONObject("team")?.optString("displayName") ?: "") } }
                if (same(names["home"] ?: "", m.home) && same(names["away"] ?: "", m.away)) {
                    val id = ev.optString("id"); Extras.ps("espn_id_${m.id}", id); return id
                }
            }
        }
        return null
    }

    private fun espnDetails(l: Football.League, m: Football.Match): Details? {
        val id = espnId(l, m) ?: return null
        val j = espn("https://site.api.espn.com/apis/site/v2/sports/soccer/${l.espn}/summary?event=$id", "esum_$id", if (m.live || m.notStarted) 45 else 1800) ?: return null
        val comp = j.optJSONObject("header")?.optJSONArray("competitions")?.optJSONObject(0)
        var homeTeam = m.home; var awayTeam = m.away; var hs: Int? = null; var aws: Int? = null
        comp?.optJSONArray("competitors")?.let { cs ->
            for (k in 0 until cs.length()) {
                val c = cs.getJSONObject(k); val nm = c.optJSONObject("team")?.optString("displayName") ?: ""
                val sc = c.optString("score").toIntOrNull()
                if (c.optString("homeAway") == "home") { homeTeam = nm.ifBlank { homeTeam }; hs = sc } else { awayTeam = nm.ifBlank { awayTeam }; aws = sc }
            }
        }
        val st = comp?.optJSONObject("status")
        val state = st?.optJSONObject("type")?.optString("state") ?: ""
        val clock = st?.optString("displayClock") ?: ""
        val events = mutableListOf<Football.Event>()
        val ke = j.optJSONArray("keyEvents") ?: JSONArray()
        for (k in 0 until ke.length()) {
            val e = ke.getJSONObject(k)
            val tType = e.optJSONObject("type")?.optString("type")?.lowercase() ?: ""
            val tText = e.optJSONObject("type")?.optString("text") ?: ""
            val team = e.optJSONObject("team")?.optString("displayName") ?: ""
            val min = e.optJSONObject("clock")?.optString("displayValue") ?: ""
            val parts = e.optJSONArray("participants")?.let { a -> (0 until a.length()).map { a.getJSONObject(it).optJSONObject("athlete")?.optString("displayName") ?: "" } } ?: emptyList()
            val text = e.optString("shortText").ifBlank { e.optString("text") }
            val isHome = if (team.isBlank()) null else same(team, homeTeam) || team == homeTeam
            val kind = when {
                tType.contains("own") -> "owngoal"
                tType.contains("penalty") && (tType.contains("miss") || tType.contains("saved")) -> "penmiss"
                tType.contains("goal") || e.optBoolean("scoringPlay") -> if (tType.contains("penalty")) "pen" else "goal"
                tType.contains("substitution") -> "sub"
                tType.contains("red") -> "red"
                tType.contains("yellow") -> "yellow"
                tType.contains("var") || tText.contains("VAR", true) -> "var"
                tType.contains("halftime") || tType.contains("half-time") -> "ht"
                tType.contains("kickoff") || tType.contains("start") -> "start"
                tType.contains("end") || tType.contains("full") -> "end"
                else -> ""
            }
            if (kind.isBlank() || kind in setOf("start", "end", "ht")) continue
            val ev = when (kind) {
                "sub" -> Football.Event(min, "Substitution", parts.getOrElse(0) { "" }, team, "", kind, isHome, playerOut = parts.getOrElse(1) { "" })
                else -> Football.Event(min, tText.ifBlank { kind }, parts.getOrElse(0) { "" }.ifBlank { text }, team,
                    when (kind) { "pen" -> tr("ركلة جزاء", "penalty"); "owngoal" -> tr("هدف عكسي", "own goal"); "penmiss" -> tr("ركلة جزاء ضائعة", "missed penalty"); "var" -> text; else -> "" },
                    kind, isHome, assist = if (kind == "goal") parts.getOrElse(1) { "" } else "")
            }
            events += ev
        }
        val lineups = mutableListOf<Lineup>()
        j.optJSONArray("rosters")?.let { rs ->
            for (k in 0 until rs.length()) {
                val r = rs.getJSONObject(k)
                val ros = r.optJSONArray("roster") ?: continue
                if (ros.length() == 0) continue
                val players = (0 until ros.length()).map { ros.getJSONObject(it) }.map { p ->
                    LP(p.optJSONObject("athlete")?.optString("displayName") ?: "", p.optString("jersey"), p.optJSONObject("position")?.optString("abbreviation") ?: "",
                        p.optBoolean("starter"), subOut = if (p.optBoolean("subbedOut")) (p.optJSONObject("subbedOutFor")?.optJSONObject("athlete")?.optString("displayName") ?: "") else "")
                }
                lineups += Lineup(r.optJSONObject("team")?.optString("displayName") ?: "", r.optString("homeAway") == "home", r.optString("formation"), players)
            }
        }
        return Details(events, lineups.sortedByDescending { it.home }, hs, aws, state, clock, "ESPN")
    }

    // =============================== SofaScore ===============================
    private fun sofaEventId(m: Football.Match): Int? {
        Extras.i("sofa_ev_${m.id}", 0).takeIf { it > 0 }?.let { return it }
        val ut = sofaId(m.leagueId)
        for (d in listOf(m.date, m.date.minusDays(1))) {
            val j = sofa("sport/football/scheduled-events/$d", if (m.live) 120 else 1800) ?: continue
            val evs = j.optJSONArray("events") ?: continue
            for (k in 0 until evs.length()) {
                val e = evs.getJSONObject(k)
                val eut = e.optJSONObject("tournament")?.optJSONObject("uniqueTournament")?.optInt("id") ?: 0
                if (ut != null && eut != ut) continue
                val h = e.optJSONObject("homeTeam")?.optString("name") ?: ""; val a = e.optJSONObject("awayTeam")?.optString("name") ?: ""
                if (same(h, m.home) && same(a, m.away)) { val id = e.optInt("id"); Extras.pi("sofa_ev_${m.id}", id); if (ut == null && eut > 0) Extras.pi("sofa_ut_${m.leagueId}", eut); return id }
            }
        }
        return null
    }

    private fun sofaDetails(m: Football.Match): Details? {
        val id = sofaEventId(m) ?: return null
        val ttl = if (m.live || m.notStarted) 45L else 1800L
        val events = mutableListOf<Football.Event>()
        var hs: Int? = null; var aws: Int? = null
        sofa("event/$id/incidents", ttl)?.optJSONArray("incidents")?.let { a ->
            for (k in a.length() - 1 downTo 0) {
                val e = a.getJSONObject(k)
                val type = e.optString("incidentType"); val cls = e.optString("incidentClass")
                val min = e.optInt("time").toString() + (e.optInt("addedTime").takeIf { it > 0 && it < 50 }?.let { "+$it" } ?: "") + "'"
                val isHome = if (e.has("isHome")) e.optBoolean("isHome") else null
                val team = when (isHome) { true -> m.home; false -> m.away; else -> "" }
                val player = e.optJSONObject("player")?.optString("name") ?: e.optString("playerName")
                when (type) {
                    "goal" -> {
                        if (e.has("homeScore")) { hs = e.optInt("homeScore"); aws = e.optInt("awayScore") }
                        val kind = when (cls) { "ownGoal" -> "owngoal"; "penalty" -> "pen"; else -> "goal" }
                        events += Football.Event(min, "Goal", player, team, when (kind) { "pen" -> tr("ركلة جزاء", "penalty"); "owngoal" -> tr("هدف عكسي", "own goal"); else -> "" }, kind, isHome,
                            assist = e.optJSONObject("assist1")?.optString("name") ?: "")
                    }
                    "substitution" -> events += Football.Event(min, "Substitution", e.optJSONObject("playerIn")?.optString("name") ?: "", team, "", "sub", isHome, playerOut = e.optJSONObject("playerOut")?.optString("name") ?: "")
                    "card" -> events += Football.Event(min, "Card", player, team, "", if (cls.contains("red", true)) "red" else "yellow", isHome)
                    "varDecision" -> events += Football.Event(min, "VAR", player, team, when {
                        cls.contains("goalNotAwarded", true) || cls.contains("Cancel", true) -> tr("إلغاء هدف بعد مراجعة الفيديو", "Goal disallowed by VAR")
                        cls.contains("penaltyNotAwarded", true) -> tr("إلغاء ركلة جزاء", "Penalty overturned")
                        cls.contains("penalty", true) -> tr("احتساب ركلة جزاء", "Penalty awarded")
                        cls.contains("goalAwarded", true) -> tr("احتساب الهدف", "Goal confirmed")
                        else -> tr("مراجعة الفيديو", "VAR review")
                    }, "var", isHome)
                    "inGamePenalty" -> if (cls.contains("miss", true)) events += Football.Event(min, "Penalty", player, team, tr("ركلة جزاء ضائعة", "missed penalty"), "penmiss", isHome)
                }
            }
        }
        val lineups = mutableListOf<Lineup>()
        sofa("event/$id/lineups", if (m.notStarted) 120 else ttl)?.let { j ->
            val confirmed = j.optBoolean("confirmed", true)
            for ((side, home) in listOf("home" to true, "away" to false)) {
                val o = j.optJSONObject(side) ?: continue
                val ps = o.optJSONArray("players") ?: continue
                if (ps.length() == 0) continue
                val players = (0 until ps.length()).map { ps.getJSONObject(it) }.map { p ->
                    LP(p.optJSONObject("player")?.optString("name") ?: "", p.optString("shirtNumber").ifBlank { p.optJSONObject("player")?.optString("jerseyNumber") ?: "" },
                        p.optString("position").ifBlank { p.optJSONObject("player")?.optString("position") ?: "" }, !p.optBoolean("substitute"))
                }
                lineups += Lineup(if (home) m.home else m.away, home, o.optString("formation"), players, confirmed)
            }
        }
        if (events.isEmpty() && lineups.isEmpty()) return null
        return Details(events, lineups, hs, aws, "", "", "SofaScore")
    }

    // =============================== عام ===============================
    /** تفاصيل المباراة من أفضل مصدر متاح */
    fun details(m: Football.Match): Details {
        val l = Football.leagueOf(m.leagueId)
        if (l != null && l.espn.isNotBlank()) runCatching { espnDetails(l, m) }.getOrNull()?.let { if (it.events.isNotEmpty() || it.lineups.isNotEmpty() || m.notStarted) return it }
        runCatching { sofaDetails(m) }.getOrNull()?.let { return it }
        if (Football.apiKey.isNotBlank()) {
            val (e, _) = runCatching { Football.apifEvents(m) }.getOrDefault(emptyList<Football.Event>() to null)
            if (e.isNotEmpty()) return Details(e.map { x ->
                val k = when { x.type.contains("Goal", true) && x.detail.contains("Own", true) -> "owngoal"; x.type.contains("Goal", true) && x.detail.contains("Penalty", true) -> "pen"
                    x.type.contains("Goal", true) -> "goal"; x.type.contains("subst", true) -> "sub"; x.detail.contains("Red", true) -> "red"; x.type.contains("Card", true) -> "yellow"; x.type.contains("Var", true) -> "var"; else -> "" }
                x.copy(kind = k, home = if (x.team.isBlank()) null else same(x.team, m.home))
            }, source = "API-Football")
        }
        return Details()
    }

    /** الهدافون وصناع اللعب */
    fun leaders(l: Football.League): Triple<List<Football.Player>, List<Football.Player>, String>? {
        if (l.espn.isNotBlank()) runCatching {
            val j = espn("https://site.api.espn.com/apis/site/v2/sports/soccer/${l.espn}/statistics", "estat_${l.espn}", 3 * 3600) ?: error("x")
            val stats = j.optJSONArray("stats") ?: error("x")
            var goals = emptyList<Football.Player>(); var assists = emptyList<Football.Player>()
            for (k in 0 until stats.length()) {
                val s = stats.getJSONObject(k)
                val name = s.optString("name").lowercase()
                val arr = s.optJSONArray("leaders") ?: continue
                val list = (0 until arr.length()).map { arr.getJSONObject(it) }.map { e ->
                    val a = e.optJSONObject("athlete") ?: JSONObject()
                    val st = a.optJSONArray("statistics")
                    fun stat(n: String) = st?.let { x -> (0 until x.length()).map { x.getJSONObject(it) }.firstOrNull { it.optString("name") == n }?.optDouble("value")?.toInt() } ?: 0
                    Football.Player(a.optString("displayName"), a.optJSONObject("team")?.optString("name") ?: a.optJSONObject("team")?.optString("displayName") ?: "",
                        a.optJSONObject("headshot")?.optString("href") ?: "", stat("totalGoals").takeIf { it > 0 } ?: if (name.contains("goal")) e.optDouble("value").toInt() else 0,
                        stat("goalAssists").takeIf { it > 0 } ?: if (name.contains("assist")) e.optDouble("value").toInt() else 0, stat("appearances"))
                }
                if (name.contains("assist")) assists = list else if (name.contains("goal")) goals = list
            }
            if (goals.isNotEmpty() || assists.isNotEmpty()) return Triple(goals, assists, "ESPN")
        }
        fotmobLeaders(l)?.let { return it }
        val ut = sofaId(l.id) ?: return null
        return runCatching {
            val seasons = sofa("unique-tournament/$ut/seasons", 24 * 3600)?.optJSONArray("seasons") ?: return null
            val sid = seasons.optJSONObject(0)?.optInt("id") ?: return null
            val tp = sofa("unique-tournament/$ut/season/$sid/top-players/overall", 3 * 3600)?.optJSONObject("topPlayers") ?: return null
            fun parse(key: String, stat: String): List<Football.Player> = tp.optJSONArray(key)?.let { a ->
                (0 until a.length()).map { a.getJSONObject(it) }.map { e ->
                    val st = e.optJSONObject("statistics") ?: JSONObject()
                    Football.Player(e.optJSONObject("player")?.optString("name") ?: "", e.optJSONObject("team")?.optString("name") ?: "", "",
                        if (stat == "goals") st.optInt("goals") else 0, if (stat == "assists") st.optInt("assists") else 0, st.optInt("appearances"))
                }
            } ?: emptyList()
            Triple(parse("goals", "goals"), parse("assists", "assists"), "SofaScore")
        }.getOrNull()
    }

    // =============================== FotMob ===============================
    private val fotmobIds = mapOf("4829" to 519, "4668" to 536, "4328" to 47, "4335" to 87, "4332" to 55, "4331" to 54, "4334" to 53, "4480" to 42, "4481" to 73)
    private val webHeaders = mapOf(
        "User-Agent" to "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
        "Accept" to "application/json, text/plain, */*", "Referer" to "https://www.fotmob.com/", "Accept-Language" to "en"
    )
    /** الهدافون وصناع الأهداف من FotMob (بدون مفتاح) */
    private fun fotmobLeaders(l: Football.League): Triple<List<Football.Player>, List<Football.Player>, String>? = runCatching {
        val fid = fotmobIds[l.id] ?: return null
        val j = JSONObject(Football.cached("fm_league_$fid", 6 * 3600, "https://www.fotmob.com/api/leagues?id=$fid&tab=stats&type=league&timeZone=UTC", webHeaders) ?: return null)
        val players = j.optJSONObject("stats")?.optJSONArray("players") ?: return null
        fun list(statNames: List<String>): List<Football.Player> {
            val st = (0 until players.length()).map { players.getJSONObject(it) }.firstOrNull { it.optString("name") in statNames } ?: return emptyList()
            val isGoals = st.optString("name") == "goals"
            val url = st.optString("fetchAllUrl")
            val full = url.takeIf { it.startsWith("http") }?.let { u ->
                runCatching { JSONObject(Football.cached("fm_" + u.hashCode(), 3 * 3600, u, webHeaders) ?: "{}").optJSONArray("TopLists")?.optJSONObject(0)?.optJSONArray("StatList") }.getOrNull()
            }
            if (full != null && full.length() > 0) return (0 until full.length()).map { full.getJSONObject(it) }.map { e ->
                val v = e.optDouble("StatValue").toInt(); val pid = e.optLong("ParticipantId")
                Football.Player(e.optString("ParticipantName"), e.optString("TeamName"), if (pid > 0) "https://images.fotmob.com/image_resources/playerimages/$pid.png" else "",
                    if (isGoals) v else 0, if (isGoals) 0 else v, e.optInt("MatchesPlayed"))
            }
            val top = st.optJSONArray("topThree") ?: return emptyList()
            return (0 until top.length()).map { top.getJSONObject(it) }.map { e ->
                val v = e.optDouble("value").toInt(); val pid = e.optLong("id")
                Football.Player(e.optString("name"), e.optString("teamName"), if (pid > 0) "https://images.fotmob.com/image_resources/playerimages/$pid.png" else "", if (isGoals) v else 0, if (isGoals) 0 else v, 0)
            }
        }
        val g = list(listOf("goals")); val a = list(listOf("goal_assist", "assists"))
        if (g.isEmpty() && a.isEmpty()) null else Triple(g, a, "FotMob")
    }.getOrNull()

    /** الترتيب الرسمي من ESPN (محدث دائماً) */
    fun standings(l: Football.League, fresh: Boolean): List<Football.Row>? {
        if (l.espn.isBlank()) return null
        return runCatching {
            val j = espn("https://site.api.espn.com/apis/v2/sports/soccer/${l.espn}/standings", "estd_${l.espn}", if (fresh) 0 else 600) ?: return null
            val kids = j.optJSONArray("children") ?: return null
            val out = mutableListOf<Football.Row>()
            for (c in 0 until kids.length()) {
                val ent = kids.getJSONObject(c).optJSONObject("standings")?.optJSONArray("entries") ?: continue
                for (k in 0 until ent.length()) {
                    val e = ent.getJSONObject(k)
                    val t = e.optJSONObject("team") ?: continue
                    val st = e.optJSONArray("stats") ?: JSONArray()
                    fun v(n: String) = (0 until st.length()).map { st.getJSONObject(it) }.firstOrNull { it.optString("name") == n }?.optDouble("value")?.toInt() ?: 0
                    val logo = t.optJSONArray("logos")?.optJSONObject(0)?.optString("href") ?: ""
                    out += Football.Row(t.optString("displayName"), "espn:" + t.optString("id"), logo, v("gamesPlayed"), v("wins"), v("ties"), v("losses"), v("pointsFor"), v("pointsAgainst"))
                }
                if (out.isNotEmpty()) break
            }
            out.sortedWith(compareByDescending<Football.Row> { it.pts }.thenByDescending { it.gd }.thenByDescending { it.gf }).takeIf { it.isNotEmpty() }
        }.getOrNull()
    }
}
