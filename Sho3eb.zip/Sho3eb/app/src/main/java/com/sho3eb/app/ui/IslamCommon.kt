@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import com.sho3eb.app.islam.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** صورة من الإنترنت مع تخزين مؤقت */
@Composable
fun NetImage(url: String, cacheName: String, modifier: Modifier = Modifier, invert: Boolean = false) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, url) {
        value = withContext(Dispatchers.IO) {
            val f = File(ctx.cacheDir, "img/$cacheName")
            if (!f.exists()) try { Net.download(url, f) } catch (_: Exception) {}
            if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        }
    }
    val b = bmp
    if (b == null) {
        Box(modifier.fillMaxWidth().height(56.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
        }
    } else {
        Image(
            bitmap = b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.FillWidth,
            modifier = modifier.fillMaxWidth(),
            colorFilter = if (invert) ColorFilter.colorMatrix(
                ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f))
            ) else null
        )
    }
}

/** بطاقة تنزيل المصحف لأول مرة */
@Composable
fun QuranDownloadCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prog = QuranRepo.progress.value
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("تنزيل المصحف", "Download the Mushaf"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(
                tr(
                    "يُنزَّل نص المصحف (برواية حفص بالرسم العثماني) مرة واحدة فقط، ثم يعمل بدون إنترنت. يحتاج اتصالاً بالإنترنت الآن.",
                    "The Mushaf text (Hafs, Uthmani script) is downloaded once, then works offline. Internet is needed now."
                ),
                style = MaterialTheme.typography.bodySmall
            )
            if (prog != null) {
                LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
                Text(tr("جاري التنزيل... ${(prog * 100).toInt()}%", "Downloading... ${(prog * 100).toInt()}%"), style = MaterialTheme.typography.bodySmall)
            } else {
                Button(onClick = {
                    scope.launch {
                        val ok = QuranRepo.download(ctx)
                        toast(ctx, if (ok) tr("تم تنزيل المصحف ✅", "Mushaf downloaded ✅") else tr("فشل التنزيل، تحقق من الإنترنت", "Download failed, check your connection"))
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Download, null); Spacer(Modifier.width(8.dp)); Text(tr("تنزيل الآن", "Download now"))
                }
                QuranRepo.error.value?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

/** تحميل المصحف عند فتح الشاشة */
@Composable
fun rememberQuranReady(): Boolean {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { QuranRepo.ensureLoaded(ctx) }
    return QuranRepo.ready.value
}

/** نص آيات بمراجعها مع أرقام الآيات */
fun ayatText(list: List<Ayah>): String = list.joinToString(" ") { it.text + " ﴿" + QuranRepo.arabicNum(it.num) + "﴾" }

/** عرض نص منسّق: ■ عنوان فرعي، • نقطة */
@Composable
fun RichBody(text: String, fontSize: Int, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val annotated = remember(text, primary, secondary) {
        buildAnnotatedString {
            text.lines().forEachIndexed { i, line ->
                if (i > 0) append('\n')
                when {
                    line.startsWith("■ ") -> withStyle(SpanStyle(color = primary, fontWeight = FontWeight.Bold, fontSize = (fontSize + 2).sp)) { append(line.removePrefix("■ ")) }
                    line.startsWith("• ") -> { withStyle(SpanStyle(color = secondary, fontWeight = FontWeight.Bold)) { append("◆ ") }; append(line.removePrefix("• ")) }
                    else -> append(line)
                }
            }
        }
    }
    Text(annotated, modifier = modifier, fontSize = fontSize.sp, lineHeight = (fontSize * 1.75).sp)
}

/** أزرار الاستماع وحفظ الصوت لنص (قراءة آلية) */
@Composable
fun TtsControls(text: String, fileName: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val speaking = Tts.speaking.value
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true
            toast(ctx, tr("جاري تجهيز الملف الصوتي...", "Preparing audio file..."))
            val tmp = File(ctx.cacheDir, "tts_export.wav")
            val ok = Tts.exportWav(ctx, text, tmp)
            if (ok) withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)?.use { o -> tmp.inputStream().use { it.copyTo(o) } }; tmp.delete() }
            busy = false
            toast(ctx, if (ok) tr("تم حفظ الملف الصوتي ✅", "Audio saved ✅") else tr("تعذر إنشاء الصوت", "Could not create audio"))
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        FilledTonalButton(onClick = { if (speaking) Tts.stop() else { SeqPlayer.stop(); Tts.speak(ctx, text) } }) {
            Icon(if (speaking) Icons.Filled.Stop else Icons.Filled.VolumeUp, null)
            Spacer(Modifier.width(6.dp))
            Text(if (speaking) tr("إيقاف", "Stop") else tr("استماع", "Listen"))
        }
        OutlinedButton(onClick = { save.launch("$fileName.wav") }, enabled = !busy) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.Download, null)
            Spacer(Modifier.width(6.dp))
            Text(tr("تنزيل الصوت", "Download audio"))
        }
    }
    DisposableEffect(Unit) { onDispose { Tts.stop() } }
}

/** شريط التشغيل العائم للآيات */
@Composable
fun MiniPlayerBar() {
    if (!SeqPlayer.active.value) return
    Surface(tonalElevation = 6.dp, shadowElevation = 6.dp, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (SeqPlayer.loading.value) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            else Icon(Icons.Filled.GraphicEq, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(SeqPlayer.label.value.ifBlank { tr("تشغيل", "Playing") }, fontWeight = FontWeight.SemiBold, maxLines = 1)
                SeqPlayer.playingAyah.value?.let { g ->
                    QuranRepo.ayah(g)?.let { a ->
                        Text(
                            (QuranRepo.surah(a.surah)?.let { QuranRepo.surahNameClean(it) } ?: "") + " • " + tr("آية ", "Ayah ") + a.num,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            IconButton(onClick = { SeqPlayer.stop() }) { Icon(Icons.Filled.Stop, null) }
        }
    }
}
