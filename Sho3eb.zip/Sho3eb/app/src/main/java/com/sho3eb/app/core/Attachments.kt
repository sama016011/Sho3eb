package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.sho3eb.app.data.Attachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** إدارة مرفقات الحركات */
object Attachments {
    const val ASSOC_PAY = "ASSOC_PAY"
    const val ASSOC_PAYOUT = "ASSOC_PAYOUT"
    const val SALE = "SALE"
    const val SALE_PAY = "SALE_PAY"
    const val LOAN_TX = "LOAN_TX"
    const val ACC_TX = "ACC_TX"

    fun dir(ctx: Context) = File(ctx.filesDir, "attachments").apply { mkdirs() }

    /** نسخ الملف المختار إلى التطبيق وربطه بالحركة */
    suspend fun add(ctx: Context, type: String, ownerId: Long, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            var name = "file"
            var size = 0L
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    c.getString(0)?.let { name = it }
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
            var mime = ctx.contentResolver.getType(uri) ?: ""
            if (mime.isBlank()) {
                mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: ""
            }
            if (!name.contains('.')) {
                MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)?.let { name = "$name.$it" }
            }
            val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val f = File(dir(ctx), UUID.randomUUID().toString().take(8) + "_" + safe)
            ctx.contentResolver.openInputStream(uri)?.use { inp -> f.outputStream().use { inp.copyTo(it) } } ?: return@withContext false
            if (size <= 0) size = f.length()
            appDao().insertAttachment(Attachment(ownerType = type, ownerId = ownerId, name = name, path = f.absolutePath, mime = mime, size = size))
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun addAll(ctx: Context, type: String, ownerId: Long, uris: List<Uri>) {
        uris.forEach { add(ctx, type, ownerId, it) }
    }

    suspend fun delete(a: Attachment) = withContext(Dispatchers.IO) {
        File(a.path).delete()
        appDao().deleteAttachment(a.id)
    }

    suspend fun deleteFor(type: String, ownerId: Long) = withContext(Dispatchers.IO) {
        appDao().attachmentsOf(type, ownerId).forEach { delete(it) }
    }

    fun open(ctx: Context, a: Attachment) {
        val f = File(a.path)
        if (!f.exists()) {
            toast(ctx, tr("الملف غير موجود", "File not found")); return
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Share.uriFor(ctx, f), a.mime.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            ctx.startActivity(Intent.createChooser(intent, a.name))
        } catch (e: Exception) {
            toast(ctx, tr("لا يوجد تطبيق لفتح هذا الملف", "No app can open this file"))
        }
    }

    fun share(ctx: Context, a: Attachment, phone: String?, viaWhatsApp: Boolean) {
        val f = File(a.path)
        if (f.exists()) Share.shareFile(ctx, f, a.mime, phone, viaWhatsApp)
    }

    fun sizeText(size: Long): String = when {
        size >= 1_048_576 -> String.format(java.util.Locale.US, "%.1f MB", size / 1_048_576.0)
        size >= 1024 -> "${size / 1024} KB"
        else -> "$size B"
    }

    /** تسجيل ملف موجود داخل مجلد المرفقات (مثل صورة الكاميرا) */
    suspend fun registerFile(type: String, ownerId: Long, f: File) = withContext(Dispatchers.IO) {
        if (f.exists() && f.length() > 0) {
            appDao().insertAttachment(Attachment(ownerType = type, ownerId = ownerId, name = f.name, path = f.absolutePath, mime = "image/jpeg", size = f.length()))
        }
    }

    /** ملف مؤقت لالتقاط صورة بالكاميرا */
    fun newCameraFile(ctx: Context): File = File(dir(ctx), "cam_${System.currentTimeMillis()}.jpg")
}
