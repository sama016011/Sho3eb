package com.sho3eb.app.core

import com.sho3eb.app.data.LivEntry
import com.sho3eb.app.data.LivItem
import com.sho3eb.app.data.LivPeriod
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.roundToInt

/** منطق قسم مصاريف المعيشة: الأنواع، التكرار، المتوسطات، ومحرك النصائح */
object Living {
    const val INCOME = "INCOME"
    const val EXPENSE = "EXPENSE"

    const val ESSENTIAL = "ESSENTIAL"
    const val IMPORTANT = "IMPORTANT"
    const val LUXURY = "LUXURY"

    data class Cat(val key: String, val ar: String, val en: String, val emoji: String, val priority: String = ESSENTIAL) {
        val label: String get() = tr(ar, en)
    }

    val incomeTypes = listOf(
        Cat("SALARY", "راتب", "Salary", "💼"),
        Cat("MANUAL", "عمل يدوي / حرفة", "Manual work", "🛠️"),
        Cat("PRIVATE", "عمل خاص / تجارة", "Own business", "🏪"),
        Cat("FREELANCE", "عمل حر / إضافي", "Freelance / side job", "💻"),
        Cat("RENT", "إيجار عقار", "Rental income", "🏠"),
        Cat("PENSION", "معاش / تقاعد", "Pension", "🧓"),
        Cat("INVEST", "أرباح استثمار", "Investment returns", "📈"),
        Cat("GIFT", "هدايا / مساعدات", "Gifts / support", "🎁"),
        Cat("OTHER", "دخل آخر", "Other income", "💰")
    )

    val expenseCats = listOf(
        Cat("FOOD", "طعام وشراب", "Food & drink", "🍞", ESSENTIAL),
        Cat("HOUSING", "سكن وإيجار", "Housing & rent", "🏠", ESSENTIAL),
        Cat("BILLS", "فواتير (كهرباء/ماء/غاز)", "Utilities", "💡", ESSENTIAL),
        Cat("TELECOM", "اتصالات وإنترنت", "Phone & internet", "📱", IMPORTANT),
        Cat("TRANSPORT", "مواصلات ووقود", "Transport & fuel", "🚗", ESSENTIAL),
        Cat("EDUCATION", "تعليم ومدارس", "Education", "🎓", ESSENTIAL),
        Cat("HEALTH", "صحة وعلاج", "Health", "💊", ESSENTIAL),
        Cat("CLOTHES", "ملابس وأحذية", "Clothing", "👕", IMPORTANT),
        Cat("KIDS", "أطفال", "Children", "🧸", ESSENTIAL),
        Cat("DEBT", "أقساط وديون", "Debts & installments", "🧾", ESSENTIAL),
        Cat("CHARITY", "صدقات وزكاة", "Charity & zakat", "🤲", IMPORTANT),
        Cat("HOUSEHOLD", "مستلزمات المنزل", "Household supplies", "🧺", IMPORTANT),
        Cat("PERSONAL", "عناية شخصية", "Personal care", "🧴", IMPORTANT),
        Cat("RESTAURANTS", "مطاعم ومقاهي", "Restaurants & cafes", "🍔", LUXURY),
        Cat("ENTERTAIN", "ترفيه واشتراكات", "Entertainment & subscriptions", "🎮", LUXURY),
        Cat("GIFTS", "هدايا ومناسبات", "Gifts & occasions", "🎉", LUXURY),
        Cat("TRAVEL", "سفر ورحلات", "Travel", "✈️", LUXURY),
        Cat("SAVING", "ادخار", "Savings", "🏦", IMPORTANT),
        Cat("OTHER", "أخرى", "Other", "📦", IMPORTANT)
    )

    fun cats(kind: String) = if (kind == INCOME) incomeTypes else expenseCats
    fun cat(kind: String, key: String): Cat = cats(kind).firstOrNull { it.key == key } ?: cats(kind).last()

    val freqs = listOf("DAY", "WEEK", "MONTH", "YEAR")
    fun freqName(f: String) = when (f) {
        "DAY" -> tr("يومي", "Daily")
        "WEEK" -> tr("أسبوعي", "Weekly")
        "YEAR" -> tr("سنوي", "Yearly")
        else -> tr("شهري", "Monthly")
    }
    fun perName(f: String) = when (f) {
        "DAY" -> tr("/ يوم", "/ day")
        "WEEK" -> tr("/ أسبوع", "/ week")
        "YEAR" -> tr("/ سنة", "/ year")
        else -> tr("/ شهر", "/ month")
    }

    val priorities = listOf(ESSENTIAL, IMPORTANT, LUXURY)
    fun priorityName(p: String) = when (p) {
        ESSENTIAL -> tr("أساسي", "Essential")
        IMPORTANT -> tr("مهم", "Important")
        else -> tr("كمالي", "Luxury")
    }
    fun priorityHint(p: String) = when (p) {
        ESSENTIAL -> tr("لا يمكن الاستغناء عنه", "Cannot be dropped")
        IMPORTANT -> tr("يمكن تقليله", "Can be reduced")
        else -> tr("يمكن الاستغناء عنه", "Can be dropped")
    }

    // ---------------- التحويل بين الفترات ----------------
    private const val DAYS_YEAR = 365.0
    private const val DAYS_MONTH = 365.0 / 12.0

    fun perDay(amount: Double, freq: String): Double = when (freq) {
        "DAY" -> amount
        "WEEK" -> amount / 7.0
        "YEAR" -> amount / DAYS_YEAR
        else -> amount / DAYS_MONTH
    }

    fun monthly(amount: Double, freq: String) = perDay(amount, freq) * DAYS_MONTH

    /** تحويل مبلغ يومي إلى وحدة العرض */
    fun fromDay(dayAmount: Double, to: String): Double = when (to) {
        "DAY" -> dayAmount
        "WEEK" -> dayAmount * 7.0
        "YEAR" -> dayAmount * DAYS_YEAR
        else -> dayAmount * DAYS_MONTH
    }

    fun convert(amount: Double, from: String, to: String) = fromDay(perDay(amount, from), to)

    /** قيمة البند لفترة بعدد أيام معين (مع مطابقة دقيقة للشهر/الأسبوع/السنة) */
    fun forDays(amount: Double, freq: String, days: Int): Double = when {
        freq == "MONTH" && days in 28..31 -> amount
        freq == "WEEK" && days == 7 -> amount
        freq == "YEAR" && days in 365..366 -> amount
        else -> round2(perDay(amount, freq) * days)
    }

    fun days(p: LivPeriod): Int = max(1, (p.endDate - p.startDate + 1).toInt())

    fun round2(v: Double) = (v * 100).roundToInt() / 100.0

    // ---------------- أسماء الفترات الجاهزة ----------------
    private val monthsAr = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
    private val monthsEn = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    fun monthName(m: Int) = tr(monthsAr[m - 1], monthsEn[m - 1])
    fun monthTitle(d: LocalDate) = tr("شهر ", "") + monthName(d.monthValue) + " " + d.year

    // ---------------- ملخص الديباجة ----------------
    data class Line(val name: String, val category: String, val priority: String, val amount: Double)

    data class Totals(
        val income: Double, val expense: Double,
        val incomeByCat: List<Pair<String, Double>>, val expenseByCat: List<Pair<String, Double>>,
        val byPriority: Map<String, Double>
    ) {
        val balance get() = income - expense
    }

    fun totals(incomes: List<Line>, expenses: List<Line>): Totals = Totals(
        incomes.sumOf { it.amount }, expenses.sumOf { it.amount },
        incomes.groupBy { it.category }.map { it.key to it.value.sumOf { l -> l.amount } }.sortedByDescending { it.second },
        expenses.groupBy { it.category }.map { it.key to it.value.sumOf { l -> l.amount } }.sortedByDescending { it.second },
        priorities.associateWith { p -> expenses.filter { it.priority == p }.sumOf { it.amount } }
    )

    /** بنود الديباجة محوّلة إلى وحدة (شهري افتراضياً) */
    fun templateLines(items: List<LivItem>, kind: String, unit: String = "MONTH") =
        items.filter { it.kind == kind }.map { Line(it.name, it.category, it.priority, convert(it.amount, it.freq, unit)) }

    fun entryLines(entries: List<LivEntry>, kind: String) =
        entries.filter { it.kind == kind }.map { Line(it.name, it.category, it.priority, it.amount) }

    // ---------------- المتوسطات من الحركات الفعلية ----------------
    data class Averages(val days: Int, val totalIncome: Double, val totalExpense: Double, val periods: Int) {
        val incomeDay get() = if (days > 0) totalIncome / days else 0.0
        val expenseDay get() = if (days > 0) totalExpense / days else 0.0
        fun income(unit: String) = fromDay(incomeDay, unit)
        fun expense(unit: String) = fromDay(expenseDay, unit)
    }

    fun averages(periods: List<LivPeriod>, entries: List<LivEntry>): Averages {
        val used = periods.filter { p -> entries.any { it.periodId == p.id } }
        val d = used.sumOf { days(it) }
        val ids = used.map { it.id }.toSet()
        val es = entries.filter { it.periodId in ids }
        return Averages(d, es.filter { it.kind == INCOME }.sumOf { it.amount }, es.filter { it.kind == EXPENSE }.sumOf { it.amount }, used.size)
    }

    /** متوسط كل فئة محوّلاً إلى وحدة */
    fun categoryAverages(periods: List<LivPeriod>, entries: List<LivEntry>, unit: String): List<Line> {
        val used = periods.filter { p -> entries.any { it.periodId == p.id } }
        val d = used.sumOf { days(it) }
        if (d == 0) return emptyList()
        val ids = used.map { it.id }.toSet()
        return entries.filter { it.periodId in ids && it.kind == EXPENSE }
            .groupBy { it.category }
            .map { (c, l) ->
                val pr = l.groupBy { it.priority }.maxByOrNull { it.value.sumOf { e -> e.amount } }?.key ?: cat(EXPENSE, c).priority
                Line(cat(EXPENSE, c).label, c, pr, fromDay(l.sumOf { it.amount } / d, unit))
            }
            .sortedByDescending { it.amount }
    }

    // ---------------- محرك النصائح ----------------
    /** level: 0 ممتاز، 1 معلومة، 2 تنبيه، 3 خطر */
    data class Tip(val level: Int, val title: String, val text: String)

    data class Cut(val name: String, val category: String, val priority: String, val current: Double, val suggested: Double, val action: String) {
        val saving get() = current - suggested
    }

    data class Plan(
        val income: Double, val expense: Double,
        val needs: Double, val wants: Double, val savings: Double,
        val tips: List<Tip>, val cuts: List<Cut>, val keep: List<Cut>
    ) {
        val potentialSaving get() = cuts.sumOf { it.saving }
        val balanceAfter get() = income - expense + potentialSaving
    }

    private fun essentialTip(cat: String): String = when (cat) {
        "FOOD" -> tr("اشترِ بقائمة مسبقة وبالجملة، قارن الأسعار، وقلّل الهدر وبقايا الطعام.", "Shop with a list, buy in bulk, compare prices and reduce waste.")
        "HOUSING" -> tr("لا يُفضّل أن يتجاوز السكن 30–35% من الدخل؛ فاوض على الإيجار أو فكّر في بديل أنسب عند التجديد.", "Keep housing under 30–35% of income; negotiate rent or consider alternatives on renewal.")
        "BILLS" -> tr("رشّد استهلاك الكهرباء والماء: إضاءة موفرة، ضبط المكيف على 24°، وإصلاح التسريبات.", "Save energy and water: LED lights, AC at 24°C, fix leaks.")
        "TRANSPORT" -> tr("خطط مشاويرك معاً، شارك الركوب، وحافظ على صيانة السيارة لتوفير الوقود.", "Combine trips, carpool, and maintain the car to save fuel.")
        "EDUCATION" -> tr("استفد من الكتب المستعملة والمصادر المجانية، وخطط للرسوم مبكراً.", "Use second-hand books and free resources; plan fees early.")
        "HEALTH" -> tr("الوقاية أوفر من العلاج؛ اسأل عن البدائل الدوائية المماثلة الأرخص (بعد استشارة الطبيب أو الصيدلي).", "Prevention is cheaper; ask about cheaper equivalent medicines (with your doctor/pharmacist).")
        "KIDS" -> tr("ركّز على الاحتياجات قبل الرغبات، واستفد من تبادل المستلزمات مع الأقارب.", "Needs before wants; swap items with relatives.")
        "DEBT" -> tr("سدّد الأعلى تكلفة أولاً، وتجنّب أي دين جديد حتى تنخفض الأقساط.", "Pay the costliest debt first and avoid new debt.")
        else -> tr("حافظ عليه مع مراجعة السعر دورياً.", "Keep it but review the price periodically.")
    }

    private fun reduceTip(cat: String): String = when (cat) {
        "TELECOM" -> tr("انتقل لباقة أرخص تناسب استخدامك الفعلي.", "Switch to a cheaper plan that fits your actual use.")
        "CLOTHES" -> tr("اشترِ في مواسم التخفيضات وحسب الحاجة فقط.", "Buy in sales seasons and only when needed.")
        "HOUSEHOLD" -> tr("اشترِ العبوات الكبيرة والعلامات الاقتصادية.", "Buy larger packs and economy brands.")
        "PERSONAL" -> tr("اختر منتجات اقتصادية وقلّل الكماليات.", "Choose economy products and fewer extras.")
        "CHARITY" -> tr("الصدقة لا تُنقص المال؛ اجعلها نسبة ثابتة ولو قليلة، وأخرج الزكاة الواجبة كاملة.", "Charity never decreases wealth; keep a fixed share and pay due zakat fully.")
        "SAVING" -> tr("الادخار مهم؛ لا تقلله إلا عند العجز الشديد.", "Savings matter; cut only in severe deficit.")
        else -> tr("قلّله تدريجياً بنسبة 20–30%.", "Reduce it gradually by 20–30%.")
    }

    private fun luxuryTip(cat: String): String = when (cat) {
        "RESTAURANTS" -> tr("قلّل الأكل خارج المنزل إلى مرة أسبوعياً أو أقل؛ إعداد الطعام في البيت أوفر بكثير.", "Eat out once a week or less; home cooking is far cheaper.")
        "ENTERTAIN" -> tr("ألغِ الاشتراكات غير المستخدمة واكتفِ باشتراك واحد.", "Cancel unused subscriptions; keep just one.")
        "GIFTS" -> tr("حدد ميزانية ثابتة للمناسبات والهدايا.", "Set a fixed budget for occasions and gifts.")
        "TRAVEL" -> tr("أجّل السفر غير الضروري وادّخر له مسبقاً.", "Postpone non-essential travel and save for it in advance.")
        else -> tr("يمكن الاستغناء عنه أو تأجيله.", "Can be dropped or postponed.")
    }

    /**
     * يبني خطة إدارة المصروفات طبقاً للدخل:
     * قاعدة 50/30/20 (احتياجات/رغبات/ادخار)، ما يمكن الاستغناء عنه، ما يمكن تقليله، وما هو أساسي.
     */
    fun plan(incomes: List<Line>, expenses: List<Line>): Plan {
        val income = incomes.sumOf { it.amount }
        val expense = expenses.sumOf { it.amount }
        val needs = expenses.filter { it.priority == ESSENTIAL }.sumOf { it.amount }
        val savingLines = expenses.filter { it.category == "SAVING" }.sumOf { it.amount }
        val wants = expenses.filter { it.priority != ESSENTIAL && it.category != "SAVING" }.sumOf { it.amount }
        val savings = max(0.0, income - expense) + savingLines
        val deficit = expense > income
        val tips = mutableListOf<Tip>()
        fun pct(v: Double) = if (income > 0) "${(v / income * 100).roundToInt()}%" else "-"

        if (income <= 0.0) {
            tips += Tip(1, tr("أضف الدخل", "Add your income"), tr("أضف راتبك أو مصادر دخلك لتحصل على تحليل دقيق ونصائح مناسبة.", "Add your salary or income sources to get an accurate analysis."))
        } else {
            when {
                deficit -> tips += Tip(
                    3, tr("عجز في الميزانية", "Budget deficit"),
                    tr("مصروفاتك تزيد على دخلك بمقدار ${Fmt.money(expense - income)}. ابدأ فوراً بإلغاء الكماليات ثم تقليل البنود المهمة كما في الجدول.",
                        "Expenses exceed income by ${Fmt.money(expense - income)}. Drop luxuries first, then reduce important items.")
                )
                expense > income * 0.9 -> tips += Tip(
                    2, tr("هامش ضيق", "Thin margin"),
                    tr("تنفق ${pct(expense)} من دخلك؛ يتبقى القليل للادخار والطوارئ. استهدف ادخار 10–20% على الأقل.", "You spend ${pct(expense)} of income; aim to save at least 10–20%.")
                )
                else -> tips += Tip(
                    0, tr("ميزانية متوازنة", "Balanced budget"),
                    tr("يتبقى لك ${Fmt.money(income - expense)} (${pct(income - expense)} من الدخل). خصّصه للادخار وصندوق الطوارئ قبل أي إنفاق إضافي.",
                        "You keep ${Fmt.money(income - expense)} (${pct(income - expense)}). Direct it to savings and an emergency fund first.")
                )
            }
            // قاعدة 50/30/20
            tips += Tip(
                if (needs > income * 0.5 || wants > income * 0.3) 2 else 0,
                tr("قاعدة 50/30/20", "The 50/30/20 rule"),
                tr(
                    "المقترح: احتياجات أساسية ≤ 50% (${Fmt.money(income * 0.5)})، رغبات ≤ 30% (${Fmt.money(income * 0.3)})، ادخار ≥ 20% (${Fmt.money(income * 0.2)}).\nوضعك الحالي: أساسي ${pct(needs)}، رغبات ${pct(wants)}، ادخار ${pct(savings)}.",
                    "Target: needs ≤ 50% (${Fmt.money(income * 0.5)}), wants ≤ 30% (${Fmt.money(income * 0.3)}), savings ≥ 20% (${Fmt.money(income * 0.2)}).\nNow: needs ${pct(needs)}, wants ${pct(wants)}, savings ${pct(savings)}."
                )
            )
            // حدود الفئات
            val byCat = expenses.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }
            fun limit(c: String, ratio: Double, title: String, msg: String) {
                val v = byCat[c] ?: 0.0
                if (v > income * ratio) tips += Tip(2, title, msg.replace("%P", pct(v)))
            }
            limit("HOUSING", 0.35, tr("السكن مرتفع", "High housing cost"), tr("السكن يمثل %P من دخلك (المستحسن أقل من 30–35%).", "Housing is %P of income (keep under 30–35%)."))
            limit("FOOD", 0.25, tr("الطعام مرتفع", "High food spending"), tr("الطعام والشراب %P من الدخل؛ التخطيط للوجبات والشراء بالقائمة يوفر كثيراً.", "Food is %P of income; meal planning helps a lot."))
            limit("TRANSPORT", 0.15, tr("المواصلات مرتفعة", "High transport cost"), tr("المواصلات %P من الدخل (المستحسن أقل من 15%).", "Transport is %P of income (keep under 15%)."))
            limit("DEBT", 0.30, tr("الديون مرتفعة", "High debt load"), tr("الأقساط والديون %P من الدخل؛ تجاوز 30% خطر، تجنّب أي التزام جديد.", "Debt is %P of income; above 30% is risky."))
            val fun_ = (byCat["RESTAURANTS"] ?: 0.0) + (byCat["ENTERTAIN"] ?: 0.0) + (byCat["TRAVEL"] ?: 0.0)
            if (fun_ > income * 0.10) tips += Tip(2, tr("الترفيه والمطاعم", "Leisure & dining"), tr("الترفيه والمطاعم والسفر ${pct(fun_)} من الدخل؛ يُفضّل ألا يتجاوز 10%.", "Leisure, dining & travel are ${pct(fun_)}; keep under 10%."))
            // صندوق الطوارئ
            if (needs > 0) tips += Tip(
                1, tr("صندوق الطوارئ", "Emergency fund"),
                tr("كوّن احتياطياً يعادل 3–6 أشهر من المصروفات الأساسية: من ${Fmt.money(needs * 3)} إلى ${Fmt.money(needs * 6)}.", "Build 3–6 months of essentials: ${Fmt.money(needs * 3)} to ${Fmt.money(needs * 6)}.")
            )
            if ((byCat["CHARITY"] ?: 0.0) <= 0.0) tips += Tip(
                1, tr("البركة في الصدقة", "Charity"),
                tr("«ما نقصت صدقة من مال» (رواه مسلم). خصّص ولو مبلغاً يسيراً ثابتاً.", "“Charity does not decrease wealth” (Muslim). Set aside even a small fixed amount.")
            )
        }

        // ما يمكن الاستغناء عنه / تقليله / الأساسي
        val grouped = expenses.groupBy { it.name to it.category }.map { (k, l) -> Line(k.first, k.second, l.first().priority, l.sumOf { it.amount }) }
        val cuts = mutableListOf<Cut>()
        val keep = mutableListOf<Cut>()
        grouped.sortedByDescending { it.amount }.forEach { l ->
            when (l.priority) {
                LUXURY -> {
                    val sug = if (deficit) 0.0 else round2(l.amount * 0.5)
                    cuts += Cut(l.name, l.category, l.priority, l.amount, sug,
                        (if (deficit) tr("استغنِ عنه مؤقتاً. ", "Drop it for now. ") else tr("قلّله للنصف. ", "Halve it. ")) + luxuryTip(l.category))
                }
                IMPORTANT -> {
                    val r = if (l.category == "SAVING" || l.category == "CHARITY") 0.0 else if (deficit) 0.3 else 0.2
                    if (r > 0) cuts += Cut(l.name, l.category, l.priority, l.amount, round2(l.amount * (1 - r)),
                        tr("قلّله ${(r * 100).roundToInt()}%. ", "Reduce ${(r * 100).roundToInt()}%. ") + reduceTip(l.category))
                    else keep += Cut(l.name, l.category, l.priority, l.amount, l.amount, reduceTip(l.category))
                }
                else -> keep += Cut(l.name, l.category, l.priority, l.amount, l.amount, essentialTip(l.category))
            }
        }
        if (cuts.isNotEmpty() && income > 0) {
            val s = cuts.sumOf { it.saving }
            tips += Tip(
                if (deficit && income - expense + s < 0) 3 else 1,
                tr("التوفير المتوقع", "Expected savings"),
                tr("بتطبيق المقترحات توفّر نحو ${Fmt.money(s)}، ويصبح المتبقي ${Fmt.money(income - expense + s)}.", "Applying the suggestions saves about ${Fmt.money(s)}; remaining becomes ${Fmt.money(income - expense + s)}.") +
                    if (deficit && income - expense + s < 0) tr("\nلا يزال هناك عجز: راجع البنود الأساسية الكبيرة (كالسكن والمواصلات) أو ابحث عن دخل إضافي.", "\nStill a deficit: review large essentials or find extra income.") else ""
            )
        }
        return Plan(income, expense, needs, wants, savings, tips, cuts, keep)
    }
}
