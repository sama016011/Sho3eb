@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch
import java.util.Locale

// =====================================================================
//                    الذهب والاستثمارات والأصول
// =====================================================================
@Composable
fun AssetsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val list by flowState(emptyList<Asset>()) { dao.assetsFlow() }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Asset?>(null) }
    var sell by remember { mutableStateOf<Asset?>(null) }
    var prices by remember { mutableStateOf(false) }
    var showSold by rememberSaveable { mutableStateOf(false) }
    var ver by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var pickCur by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var assetTab by rememberSaveable { mutableIntStateOf(if (nav.currentBackStackEntry?.arguments?.getString("tab") == "fx") 1 else 0) }
    fun refresh(force: Boolean) {
        if (loading) return
        loading = true
        scope.launch { val ok = Metals.refresh(force); failed = !ok; loading = false; ver++ }
    }
    // تحديث لحظي: كل دقيقة طالما الشاشة مفتوحة والتحديث التلقائي مفعّل
    LaunchedEffect(Unit) {
        while (true) {
            if (Metals.auto) { val ok = Metals.refresh(false); failed = !ok; ver++ }
            kotlinx.coroutines.delay(60_000)
            tick++
        }
    }
    val active = list.filter { !it.sold }
    val cost = active.sumOf { it.buyPrice }
    val value = remember(list, ver) { active.sumOf { Assets.value(it) } }
    val pl = value - cost
    val gold = active.sumOf { Assets.pureGold(it) }
    val byType = active.groupBy { it.type }.map { it.key to it.value.sumOf { a -> Assets.value(a) } }.sortedByDescending { it.second }

    ScreenScaffold(
        title = tr("الذهب والاستثمارات والأصول", "Gold, investments & assets"), onBack = { nav.popBackStack() },
        actions = { PdfShareButton(null, doc = { Docs.assets(list) }) { c -> Reports.doc(c, Docs.assets(list)) } },
        fab = { if (assetTab == 0) ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("أصل", "Asset")) }) }
    ) { pad ->
      Column(Modifier.padding(pad)) {
        TabRow(selectedTabIndex = assetTab) {
            Tab(assetTab == 0, { assetTab = 0 }, text = { Text(tr("💎 الأصول والذهب", "💎 Assets & gold")) })
            Tab(assetTab == 1, { assetTab = 1 }, text = { Text(tr("💱 العملات الأجنبية", "💱 Foreign currencies")) })
        }
        if (assetTab == 1) FxPane(nav) else
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(18.dp)) {
                        val on = MaterialTheme.colorScheme.onPrimary
                        Text(tr("القيمة الحالية لأصولك", "Your assets are worth"), color = on.copy(alpha = 0.85f))
                        Text(Fmt.money(value), color = on, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(
                            tr("التكلفة ", "Cost ") + Fmt.money(cost) + " • " + (if (pl >= 0) tr("ربح ", "Gain ") else tr("خسارة ", "Loss ")) + Fmt.money(kotlin.math.abs(pl)) +
                                if (cost > 0) " (" + String.format(Locale.US, "%.1f", pl / cost * 100) + "%)" else "",
                            color = on.copy(alpha = 0.9f), style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                key(ver, tick) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🪙", fontSize = 24.sp)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(tr("أسعار الذهب والفضة اليوم", "Today's gold & silver prices"), fontWeight = FontWeight.Bold)
                                    Text(
                                        (if (Metals.auto) "🟢 " + tr("مباشر • ", "Live • ") + Metals.agoText() else "✍️ " + tr("سعر يدوي", "Manual price")) +
                                            (if (failed && Metals.auto) tr(" • تعذّر التحديث", " • update failed") else ""),
                                        style = MaterialTheme.typography.bodySmall, color = if (failed && Metals.auto) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                AssistChip(onClick = { pickCur = true }, label = { Text(Metals.currency) }, trailingIcon = { Icon(Icons.Filled.ArrowDropDown, null) })
                                if (loading) CircularProgressIndicator(Modifier.size(22.dp).padding(2.dp), strokeWidth = 2.dp)
                                else IconButton(onClick = { refresh(true) }) { Icon(Icons.Filled.Refresh, null) }
                                IconButton(onClick = { prices = true }) { Icon(Icons.Filled.Edit, null) }
                            }
                            if (Extras.goldPrice24 > 0) {
                                val tr0 = Metals.trend
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(tr("ذهب عيار 24", "Gold 24k"), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                    if (tr0 != 0) Icon(if (tr0 > 0) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward, null, tint = if (tr0 > 0) SuccessGreen else DangerRed, modifier = Modifier.size(16.dp))
                                    Text(String.format(java.util.Locale.US, "%,.2f", Extras.goldPrice24) + " " + Metals.currency, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(22, 21, 18).forEach { k ->
                                        Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.weight(1f)) {
                                            Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(tr("عيار $k", "${k}k"), style = MaterialTheme.typography.labelSmall)
                                                Text(String.format(java.util.Locale.US, "%,.2f", Metals.goldGram(k)), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                }
                                Row {
                                    Text(tr("الفضة (جرام)", "Silver (gram)"), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                    Text(if (Extras.silverPrice > 0) String.format(java.util.Locale.US, "%,.2f", Extras.silverPrice) + " " + Metals.currency else "-", fontWeight = FontWeight.SemiBold)
                                }
                                if (Metals.goldOzUsd > 0 && Metals.auto) Text(
                                    tr("الأونصة عالمياً: ", "Ounce (spot): ") + String.format(java.util.Locale.US, "%,.2f", Metals.goldOzUsd) + " USD" +
                                        if (Metals.silverOzUsd > 0) tr(" • الفضة ", " • silver ") + String.format(java.util.Locale.US, "%,.2f", Metals.silverOzUsd) + " USD" else "",
                                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (gold > 0) Text(tr("عندك ", "You hold ") + String.format(java.util.Locale.US, "%.2f", gold) + tr(" جم ذهب خالص ≈ ", " g pure gold ≈ ") + Fmt.money(gold * Extras.goldPrice24), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                Text(tr("سعر الخام العالمي دون المصنعية وهامش المحلات.", "Global spot price, excluding workmanship and dealer margin."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else Text(if (loading) tr("جارٍ جلب الأسعار...", "Fetching prices...") else tr("اضغط ↻ لجلب الأسعار من الإنترنت أو ✎ لإدخالها يدوياً", "Tap ↻ to fetch prices or ✎ to enter manually"), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (byType.size > 1) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(tr("توزيع المحفظة", "Portfolio mix"), fontWeight = FontWeight.Bold)
                        byType.forEach { (k, v) ->
                            val t = Assets.type(k)
                            Row { Text(t.emoji + " " + t.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium); Text(Fmt.num(v) + " (" + (if (value > 0) (v / value * 100).toInt() else 0) + "%)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold) }
                            LinearProgressIndicator(progress = { if (value > 0) (v / value).toFloat() else 0f }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr("أصولي", "My assets"), Modifier.weight(1f))
                    FilterChip(showSold, { showSold = !showSold }, label = { Text(tr("المباعة", "Sold")) })
                }
            }
            if (list.isEmpty()) item { EmptyState(Icons.Filled.Diamond, tr("سجّل ذهبك وأسهمك وعقاراتك وسياراتك لتعرف قيمة ثروتك وأرباحك، وتُحسب زكاتها تلقائياً.", "Record gold, stocks, property and vehicles to track your wealth and zakat.")) }
            items(list.filter { showSold || !it.sold }, key = { it.id }) { a ->
                val t = Assets.type(a.type)
                val p = Assets.profit(a)
                Card(onClick = { edit = a }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.emoji, fontSize = 26.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                t.label + (if (a.type == "GOLD") tr(" عيار ${a.karat}", " ${a.karat}k") else "") +
                                    (if (a.qty > 0) " • " + Fmt.num(a.qty).removeSuffix(".00") + " " + a.unit else "") + (if (a.zakatable && !a.sold) tr(" • زكوي", " • zakatable") else ""),
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (a.sold) Text(tr("مباع بـ ", "Sold for ") + Fmt.money(a.sellPrice) + (a.sellDate?.let { " • " + Fmt.date(it) } ?: ""), style = MaterialTheme.typography.bodySmall, color = WarnAmber)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.money(if (a.sold) a.sellPrice else Assets.value(a)), fontWeight = FontWeight.Bold)
                            Text((if (p >= 0) "▲ " else "▼ ") + Fmt.num(kotlin.math.abs(p)) + if (a.buyPrice > 0) " (" + String.format(Locale.US, "%.1f", Assets.pct(a)) + "%)" else "",
                                color = if (p >= 0) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                InfoBanner(tr("الأصول المعلَّمة «زكوية» تُضاف تلقائياً في حاسبة الزكاة. سعر الذهب والفضة واحد هنا وفي الحاسبة.", "Zakatable assets are included in the zakat calculator automatically."))
            }
        }
      }
    }
    if (add) AssetDialog(null) { add = false; ver++ }
    edit?.let { a -> AssetDialog(a, onSell = { edit = null; sell = a }) { edit = null; ver++ } }
    sell?.let { a -> SellAssetDialog(a) { sell = null } }
    if (prices) MetalPricesDialog { prices = false; ver++ }
    if (pickCur) CurrencyPickerDialog(onDismiss = { pickCur = false }) { c ->
        pickCur = false; Metals.currency = c; Metals.auto = true; Metals.updatedAt = 0; Metals.prevGold = 0.0; refresh(true)
    }
}

@Composable
fun MetalPricesDialog(onDismiss: () -> Unit) {
    var g by remember { mutableStateOf(Extras.goldPrice24.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var s by remember { mutableStateOf(Extras.silverPrice.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var auto by remember { mutableStateOf(Metals.auto) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("أسعار اليوم", "Today's prices")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MoneyField(g, { g = it }, tr("سعر جرام الذهب عيار 24", "Gold 24k per gram"))
                Fmt.parse(g)?.let { v -> Text(tr("عيار 22: ", "22k: ") + Fmt.money(v * 22 / 24) + tr(" • 21: ", " • 21k: ") + Fmt.money(v * 21 / 24) + tr(" • 18: ", " • 18k: ") + Fmt.money(v * 18 / 24), style = MaterialTheme.typography.bodySmall) }
                MoneyField(s, { s = it }, tr("سعر جرام الفضة (اختياري)", "Silver per gram (optional)"))
                SwitchRow(tr("تحديث تلقائي من الإنترنت", "Auto-update from the internet"), tr("عند التعديل اليدوي يتوقف التحديث التلقائي حتى تعيد تفعيله", "Editing manually pauses auto-update until you turn it back on"), auto) { auto = it }
                Text(tr("السعر بعملة: ", "Currency: ") + Metals.cur(Metals.currency).label + " (" + Metals.currency + ")", style = MaterialTheme.typography.bodySmall)
                Text(tr("يمكنك إدخال سعر محل الذهب لديك ليشمل المصنعية.", "You can enter your local dealer price."), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val ng = Fmt.parse(g); val ns = Fmt.parse(s)
                val changed = (ng != null && kotlin.math.abs(ng - Extras.goldPrice24) > 0.001) || (ns != null && kotlin.math.abs(ns - Extras.silverPrice) > 0.001)
                ng?.let { Extras.goldPrice24 = it }; ns?.let { Extras.silverPrice = it }
                Metals.auto = if (changed && auto == Metals.auto) false else auto
                if (Metals.auto) Metals.updatedAt = 0
                onDismiss()
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun AssetDialog(existing: Asset?, onSell: () -> Unit = {}, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var type by remember { mutableStateOf(existing?.type ?: "GOLD") }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var qty by remember { mutableStateOf(existing?.qty?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var unit by remember { mutableStateOf(existing?.unit ?: Assets.defaultUnit("GOLD")) }
    var karat by remember { mutableIntStateOf(existing?.karat ?: 21) }
    var buy by remember { mutableStateOf(existing?.buyPrice?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var buyDate by remember { mutableStateOf(existing?.buyDate ?: Fmt.today()) }
    var unitPrice by remember { mutableStateOf(existing?.unitPrice?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var current by remember { mutableStateOf(existing?.currentValue?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var zak by remember { mutableStateOf(existing?.zakatable ?: Assets.defaultZakatable("GOLD")) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var confirmDel by remember { mutableStateOf(false) }
    val post = remember { mutableStateOf<Long?>(null) }
    val pending = remember { mutableStateListOf<Uri>() }
    val metal = type == "GOLD" || type == "SILVER"
    val hasQty = type in listOf("GOLD", "SILVER", "STOCK", "FUND", "CRYPTO", "FX")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("إضافة أصل", "Add asset") else tr("تعديل الأصل", "Edit asset")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HChips {
                    Assets.types.forEach { t -> FilterChip(type == t.key, { type = t.key; unit = Assets.defaultUnit(t.key); zak = Assets.defaultZakatable(t.key) }, label = { Text(t.emoji + " " + t.label) }) }
                }
                OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم (مثل: طقم ذهب، أسهم أرامكو، أرض المخطط)", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (type == "GOLD") HChips { Assets.karats.forEach { k -> FilterChip(karat == k, { karat = k }, label = { Text(tr("عيار $k", "${k}k")) }) } }
                if (hasQty) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField(qty, { qty = it }, tr("الكمية", "Quantity"), Modifier.weight(1f))
                    OutlinedTextField(unit, { unit = it }, label = { Text(tr("الوحدة", "Unit")) }, singleLine = true, modifier = Modifier.weight(0.6f))
                }
                MoneyField(buy, { buy = it }, tr("إجمالي سعر الشراء (التكلفة)", "Total purchase cost"))
                DateField(tr("تاريخ الشراء", "Purchase date"), buyDate, { d -> if (d != null) buyDate = d })
                if (metal) Text(
                    if ((if (type == "GOLD") Extras.goldPrice24 else Extras.silverPrice) > 0) tr("القيمة تُحسب تلقائياً بسعر اليوم.", "Value uses today's price automatically.")
                    else tr("أدخل سعر الجرام من شاشة الأصول لتُحسب القيمة تلقائياً.", "Set today's gram price on the assets screen."),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary
                )
                else if (hasQty) MoneyField(unitPrice, { unitPrice = it }, tr("سعر الوحدة الحالي", "Current unit price"))
                else MoneyField(current, { current = it }, tr("القيمة الحالية التقديرية", "Estimated current value"))
                SwitchRow(tr("مال زكوي", "Zakatable"), tr("يُضاف لحاسبة الزكاة (النقد والذهب والأسهم وعروض التجارة)", "Included in the zakat calculator"), zak) { zak = it }
                NotesField(notes) { notes = it }
                if (existing == null) {
                    AccountPickRow(post, tr("دُفع من حساب (اختياري)", "Paid from account (optional)"))
                    PendingAttachRow(pending)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AttachmentButton(Attachments.ASSET, existing.id)
                        if (!existing.sold) OutlinedButton(onClick = onSell, modifier = Modifier.weight(1f)) { Text(tr("بيع الأصل", "Sell")) }
                        OutlinedButton(onClick = { confirmDel = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed)) { Icon(Icons.Filled.Delete, null) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val nm = name.trim().ifBlank { Assets.type(type).label }
                val a = Asset(
                    name = nm, type = type, qty = Fmt.parse(qty) ?: 0.0, unit = unit.trim(), karat = karat, buyPrice = Fmt.parse(buy) ?: 0.0, buyDate = buyDate,
                    unitPrice = Fmt.parse(unitPrice) ?: 0.0, currentValue = Fmt.parse(current) ?: 0.0, priceDate = Fmt.today(), zakatable = zak, notes = notes.trim()
                )
                scope.launch {
                    if (existing != null) dao.updateAsset(a.copy(id = existing.id, sold = existing.sold, sellPrice = existing.sellPrice, sellDate = existing.sellDate, createdAt = existing.createdAt))
                    else {
                        val id = dao.insertAsset(a)
                        Attachments.addAll(ctx, Attachments.ASSET, id, pending.toList())
                        if (a.buyPrice > 0) Posting.post(post.value, AccountTx.SRC_ASSET, id, false, a.buyPrice, buyDate, tr("شراء ", "Bought ") + nm)
                    }
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
    if (confirmDel && existing != null) ConfirmDialog(tr("حذف الأصل", "Delete asset"), tr("حذف «${existing.name}» والحركات المرحّلة منه؟", "Delete with posted transactions?"), onDismiss = { confirmDel = false }) {
        scope.launch { Attachments.deleteFor(Attachments.ASSET, existing.id); dao.deleteLinkedTx(AccountTx.SRC_ASSET, existing.id); dao.deleteAsset(existing.id); confirmDel = false; onDismiss() }
    }
}

@Composable
private fun SellAssetDialog(a: Asset, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var price by remember { mutableStateOf(Fmt.plain(Assets.value(a))) }
    var date by remember { mutableStateOf(Fmt.today()) }
    val post = remember { mutableStateOf<Long?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("بيع ", "Sell ") + a.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MoneyField(price, { price = it }, tr("سعر البيع", "Sale price"))
                Fmt.parse(price)?.let { v -> val p = v - a.buyPrice; Text((if (p >= 0) tr("ربح ", "Gain ") else tr("خسارة ", "Loss ")) + Fmt.money(kotlin.math.abs(p)), color = if (p >= 0) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold) }
                DateField(tr("تاريخ البيع", "Sale date"), date, { d -> if (d != null) date = d })
                AccountPickRow(post, tr("إيداع الثمن في حساب (اختياري)", "Deposit into account (optional)"))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(price) ?: return@TextButton
                scope.launch {
                    dao.updateAsset(a.copy(sold = true, sellPrice = v, sellDate = date))
                    Posting.post(post.value, AccountTx.SRC_ASSET, a.id, true, v, date, tr("بيع ", "Sold ") + a.name)
                    onDismiss()
                }
            }) { Text(tr("تأكيد البيع", "Confirm")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/** اختيار عملة أسعار الذهب */
@Composable
fun CurrencyPickerDialog(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("عملة الأسعار", "Prices currency")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SearchField(q) { q = it }
                Text(tr("اختر نفس عملة التطبيق ليتم احتساب قيمة أصولك بشكل صحيح.", "Pick the same currency as the app so asset values are correct."), style = MaterialTheme.typography.bodySmall)
                androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(Metals.currencies.filter { q.isBlank() || it.code.contains(q, true) || it.label.contains(q, true) }, key = { it.code }) { c ->
                        Row(Modifier.fillMaxWidth().clickable { onPick(c.code) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(c.code == Metals.currency, { onPick(c.code) })
                            Text(c.label, Modifier.weight(1f))
                            Text(c.code, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
}
