@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.sho3eb.app.core

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateListOf
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.common.Effect
import com.google.common.collect.ImmutableList
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** قوائم التشغيل وأدوات الفيديو: قص، استخراج الصوت، تحويل صور + صوت إلى فيديو */
object MediaTools {
    data class Track(val name: String, val uri: String)
    data class Playlist(val name: String, val items: List<Track>)

    /** قائمة التشغيل الحالية للمشغل */
    val queue = mutableStateListOf<Track>()
    var queueStart = 0

    private val mediaExt = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "ts", "flv", "mpg", "mpeg", "wmv", "mp3", "aac", "m4a", "flac", "ogg", "oga", "opus", "wav", "amr", "wma", "mka", "m3u8")
    fun isMedia(name: String, mime: String?) = mime?.startsWith("video") == true || mime?.startsWith("audio") == true || name.substringAfterLast('.', "").lowercase() in mediaExt

    /** كل ملفات الوسائط في مجلد (مرتبة بالاسم) */
    fun folder(ctx: Context, tree: Uri): List<Track> = runCatching {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val out = mutableListOf<Track>()
        ctx.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                if (isMedia(name, c.getString(2))) out += Track(name, DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)).toString())
            }
        }
        out.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }.getOrDefault(emptyList())

    fun playlists(): List<Playlist> = runCatching {
        JSONArray(Extras.s("media_pls", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            Playlist(o.getString("n"), o.getJSONArray("i").let { x -> (0 until x.length()).map { x.getJSONObject(it).let { t -> Track(t.getString("n"), t.getString("u")) } } })
        } }
    }.getOrDefault(emptyList())
    fun savePlaylists(l: List<Playlist>) = Extras.ps("media_pls", JSONArray(l.map { p -> JSONObject().put("n", p.name).put("i", JSONArray(p.items.map { JSONObject().put("n", it.name).put("u", it.uri) })) }).toString())
    var folders: List<String> get() = Extras.s("media_folders", "").split("\n").filter { it.isNotBlank() }; set(v) = Extras.ps("media_folders", v.joinToString("\n"))

    /** تشغيل ملف مع باقي ملفات مجلده تلقائياً (ينتقل للتالي عند الانتهاء) */
    fun playWithSiblings(ctx: Context, nav: androidx.navigation.NavController, uri: Uri, name: String) {
        val sib = runCatching { MediaScan.siblings(ctx, uri, name) }.getOrNull()
        queue.clear()
        if (sib != null) {
            queue.addAll(sib.first); queueStart = sib.second
            nav.navigate("player?u=" + Uri.encode("queue") + "&t=" + Uri.encode(name))
        } else {
            queue.add(Track(name, uri.toString())); queueStart = 0
            nav.navigate("player?u=" + Uri.encode("queue") + "&t=" + Uri.encode(name))
        }
    }

    fun nameOf(ctx: Context, uri: Uri): String = runCatching { ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: uri.lastPathSegment ?: "media"

    // ---------------- التصدير ----------------
    class Job(val transformer: Transformer, val out: File)

    /** يبدأ التصدير؛ يُستدعى من الخيط الرئيسي */
    fun export(ctx: Context, composition: Composition, audioOnly: Boolean, onDone: (Uri?, String?) -> Unit): Job {
        val out = File(ctx.cacheDir, "export_" + System.currentTimeMillis() + if (audioOnly) ".m4a" else ".mp4")
        val b = Transformer.Builder(ctx).setAudioMimeType(MimeTypes.AUDIO_AAC)
        if (!audioOnly) b.setVideoMimeType(MimeTypes.VIDEO_H264)
        val t = b.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) { onDone(publish(ctx, out, audioOnly), null) }
            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { out.delete(); onDone(null, exportException.errorCodeName + ": " + (exportException.message ?: "")) }
        }).build()
        t.start(composition, out.absolutePath)
        return Job(t, out)
    }
    fun progress(j: Job): Int { val h = ProgressHolder(); return if (j.transformer.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) h.progress else -1 }

    /** حفظ الناتج في المعرض: Movies/Sho3eb أو Music/Sho3eb */
    fun publish(ctx: Context, f: File, audio: Boolean): Uri? = runCatching {
        val name = (if (audio) "Sho3eb_audio_" else "Sho3eb_video_") + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + if (audio) ".m4a" else ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, if (audio) "audio/mp4" else "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music/Sho3eb" else "Movies/Sho3eb"); put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val u = ctx.contentResolver.insert(coll, cv)!!
            ctx.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            f.delete(); u
        } else {
            val dir = ctx.getExternalFilesDir(if (audio) android.os.Environment.DIRECTORY_MUSIC else android.os.Environment.DIRECTORY_MOVIES)
            val dst = File(dir, name); f.copyTo(dst, true); f.delete(); Uri.fromFile(dst)
        }
    }.getOrNull()

    // ---------------- المؤثرات ----------------
    data class Fx(val filter: String = "NONE", val motion: String = "NONE", val fade: Boolean = true, val title: String = "", val brightness: Float = 0f, val contrast: Float = 0f)
    val filters = listOf(Opt("NONE", "بدون", "None", "⬜"), Opt("BW", "أبيض وأسود", "B&W", "⚫"), Opt("SEPIA", "سيبيا قديم", "Sepia", "🟤"), Opt("WARM", "دافئ", "Warm", "🌅"), Opt("COOL", "بارد", "Cool", "❄️"), Opt("VIVID", "ألوان زاهية", "Vivid", "🌈"), Opt("INVERT", "سلبي", "Negative", "🔄"))
    val motions = listOf(Opt("NONE", "ثابت", "Static", "🖼️"), Opt("ZOOM_IN", "تقريب سينمائي", "Ken Burns in", "🔍"), Opt("ZOOM_OUT", "تبعيد سينمائي", "Ken Burns out", "🔭"), Opt("PAN", "تحريك أفقي", "Pan", "↔️"), Opt("ROTATE", "دوران خفيف", "Slight rotate", "🔃"))

    private fun colorMatrix(m: FloatArray) = RgbMatrix { _, _ -> m }
    /** مصفوفة 4×4 (عمودية) من معاملات rgb 3×3 */
    private fun m3(a: FloatArray) = floatArrayOf(a[0], a[3], a[6], 0f, a[1], a[4], a[7], 0f, a[2], a[5], a[8], 0f, 0f, 0f, 0f, 1f)

    /** قائمة المؤثرات لعنصر مدته durMs */
    fun effects(fx: Fx, durMs: Long): List<Effect> {
        val out = mutableListOf<Effect>()
        val durUs = (durMs * 1000).coerceAtLeast(1)
        when (fx.motion) {
            "ZOOM_IN", "ZOOM_OUT", "PAN", "ROTATE" -> out += MatrixTransformation { t ->
                val p = ((t % durUs).toFloat() / durUs).coerceIn(0f, 1f)
                android.graphics.Matrix().apply {
                    when (fx.motion) {
                        "ZOOM_IN" -> (1f + 0.18f * p).let { postScale(it, it) }
                        "ZOOM_OUT" -> (1.18f - 0.18f * p).let { postScale(it, it) }
                        "PAN" -> { postScale(1.15f, 1.15f); postTranslate(-0.12f + 0.24f * p, 0f) }
                        else -> { postScale(1.1f, 1.1f); postRotate(-2f + 4f * p) }
                    }
                }
            }
        }
        when (fx.filter) {
            "BW" -> out += RgbFilter.createGrayscaleFilter()
            "INVERT" -> out += RgbFilter.createInvertedFilter()
            "SEPIA" -> out += colorMatrix(m3(floatArrayOf(0.393f, 0.769f, 0.189f, 0.349f, 0.686f, 0.168f, 0.272f, 0.534f, 0.131f)))
            "WARM" -> out += colorMatrix(m3(floatArrayOf(1.12f, 0f, 0f, 0f, 1.02f, 0f, 0f, 0f, 0.85f)))
            "COOL" -> out += colorMatrix(m3(floatArrayOf(0.88f, 0f, 0f, 0f, 1.0f, 0f, 0f, 0f, 1.15f)))
            "VIVID" -> { out += Contrast(0.25f); out += colorMatrix(m3(floatArrayOf(1.25f, -0.15f, -0.1f, -0.1f, 1.2f, -0.1f, -0.1f, -0.15f, 1.25f))) }
        }
        if (fx.brightness != 0f) out += Brightness(fx.brightness.coerceIn(-1f, 1f))
        if (fx.contrast != 0f) out += Contrast(fx.contrast.coerceIn(-1f, 1f))
        if (fx.fade) out += RgbMatrix { t, _ ->
            val ms = (t % durUs) / 1000f
            val k = minOf(1f, ms / 500f, (durMs - ms) / 500f).coerceIn(0f, 1f)
            floatArrayOf(k, 0f, 0f, 0f, 0f, k, 0f, 0f, 0f, 0f, k, 0f, 0f, 0f, 0f, 1f)
        }
        if (fx.title.isNotBlank()) {
            val sp = android.text.SpannableString(fx.title)
            sp.setSpan(android.text.style.AbsoluteSizeSpan(64), 0, sp.length, 0)
            sp.setSpan(android.text.style.ForegroundColorSpan(android.graphics.Color.WHITE), 0, sp.length, 0)
            sp.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, sp.length, 0)
            sp.setSpan(android.text.style.BackgroundColorSpan(0x88000000.toInt()), 0, sp.length, 0)
            val settings = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.78f).build()
            out += OverlayEffect(ImmutableList.of(TextOverlay.createStaticTextOverlay(sp, settings)))
        }
        return out
    }

    /** قص جزء من فيديو/صوت (بالمللي ثانية)؛ audioOnly = استخراج الصوت فقط */
    fun trimComposition(uri: Uri, startMs: Long, endMs: Long, audioOnly: Boolean, fx: Fx = Fx(fade = false)): Composition {
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs.coerceAtLeast(0)).apply { if (endMs > startMs) setEndPositionMs(endMs) }.build()
        ).build()
        val eb = EditedMediaItem.Builder(item).setRemoveVideo(audioOnly)
        if (!audioOnly) { val fxl = effects(fx, if (endMs > startMs) endMs - startMs else 3_600_000L); if (fxl.isNotEmpty()) eb.setEffects(Effects(emptyList(), fxl)) }
        val edited = eb.build()
        return Composition.Builder(listOf(EditedMediaItemSequence(listOf(edited)))).build()
    }

    /** صور + صوت = فيديو (عرض شرائح) */
    fun slideshow(images: List<Uri>, secondsEach: Int, audio: Uri?, loopAudio: Boolean, landscape: Boolean, fx: Fx = Fx(), titles: List<String> = emptyList()): Composition {
        val w = if (landscape) 1280 else 720; val h = if (landscape) 720 else 1280
        val pres = Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)
        val vids = images.mapIndexed { i, u ->
            val f = fx.copy(title = titles.getOrNull(i)?.takeIf { it.isNotBlank() } ?: if (i == 0) fx.title else "")
            EditedMediaItem.Builder(MediaItem.Builder().setUri(u).setImageDurationMs(secondsEach * 1000L).build())
                .setFrameRate(30).setEffects(Effects(emptyList(), listOf<Effect>(pres) + effects(f, secondsEach * 1000L))).build()
        }
        val seqs = mutableListOf(EditedMediaItemSequence(vids))
        if (audio != null) seqs += EditedMediaItemSequence(listOf(EditedMediaItem.Builder(MediaItem.fromUri(audio)).setRemoveVideo(true).build()), loopAudio)
        return Composition.Builder(seqs).build()
    }
}
