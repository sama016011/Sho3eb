package com.sho3eb.app.core

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.sho3eb.app.R

/** تسجيل الشاشة (فيديو + صوت الميكروفون اختيارياً) ويُحفظ في المعرض: Movies/Sho3eb */
class ScreenRecordService : Service() {
    companion object {
        const val ACTION_START = "start"; const val ACTION_STOP = "stop"
        private const val CH = "sho3eb_rec"
        val recording = mutableStateOf(false)
        val startedAt = mutableStateOf(0L)
        var withAudio: Boolean get() = Extras.b("rec_audio", true); set(v) = Extras.pb("rec_audio", v)
        var quality: Int get() = Extras.i("rec_q", 1); set(v) = Extras.pi("rec_q", v)   // 0: 720p 1: 1080p

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            val i = Intent(ctx, ScreenRecordService::class.java).setAction(ACTION_START).putExtra("code", resultCode).putExtra("data", data)
            ContextCompat.startForegroundService(ctx, i)
        }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, ScreenRecordService::class.java).setAction(ACTION_STOP)) }
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopRec(); stopSelf() }
            ACTION_START -> {
                foreground()
                val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION") val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java) else intent.getParcelableExtra("data")
                if (data == null || !startRec(code, data)) { toast(this, tr("تعذر بدء التسجيل", "Couldn't start recording")); stopSelf() }
            }
        }
        return START_NOT_STICKY
    }

    private fun foreground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, tr("تسجيل الشاشة", "Screen recording"), NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 1, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH).setSmallIcon(R.drawable.ic_notification).setContentTitle(tr("🔴 جارٍ تسجيل الشاشة", "🔴 Recording screen"))
            .setContentText(tr("اضغط إيقاف لحفظ الفيديو في المعرض", "Tap Stop to save to gallery")).setOngoing(true)
            .addAction(0, tr("⏹ إيقاف وحفظ", "⏹ Stop & save"), stopPi).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(9901, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(9901, n)
    }

    private fun startRec(code: Int, data: Intent): Boolean = try {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("no projection")
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopRec(); stopSelf() } }, null)
        val dm = resources.displayMetrics
        val maxSide = if (quality == 0) 1280 else 1920
        val scale = minOf(1.0, maxSide.toDouble() / maxOf(dm.widthPixels, dm.heightPixels))
        val w = ((dm.widthPixels * scale).toInt() / 16) * 16
        val h = ((dm.heightPixels * scale).toInt() / 16) * 16
        val name = "Sho3eb_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + ".mp4"
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) { put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Sho3eb"); put(MediaStore.Video.Media.IS_PENDING, 1) }
        }
        var legacyPath: String? = null
        if (Build.VERSION.SDK_INT >= 29) {
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IllegalStateException("no uri")
            uri = u
            pfd = contentResolver.openFileDescriptor(u, "rw") ?: throw IllegalStateException("no fd")
        } else {
            legacyPath = java.io.File(getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), name).absolutePath
        }
        val audio = withAudio && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        @Suppress("DEPRECATION") val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        rec.apply {
            if (audio) setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            val p0 = pfd; if (p0 != null) setOutputFile(p0.fileDescriptor) else setOutputFile(legacyPath)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (audio) { setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(128_000); setAudioSamplingRate(44_100) }
            setVideoSize(w, h)
            setVideoFrameRate(30)
            setVideoEncodingBitRate(if (quality == 0) 5_000_000 else 9_000_000)
            prepare()
        }
        recorder = rec
        display = proj.createVirtualDisplay("sho3eb_rec", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null)
        rec.start()
        recording.value = true; startedAt.value = System.currentTimeMillis()
        true
    } catch (e: Exception) { cleanup(false); false }

    private fun stopRec() {
        if (!recording.value && recorder == null) return
        val ok = runCatching { recorder?.stop() }.isSuccess
        cleanup(ok)
        if (ok) toast(this, tr("✅ حُفظ الفيديو في المعرض (Movies/Sho3eb)", "✅ Saved to gallery (Movies/Sho3eb)"))
    }

    private fun cleanup(keep: Boolean) {
        runCatching { recorder?.release() }; recorder = null
        runCatching { display?.release() }; display = null
        runCatching { projection?.stop() }; projection = null
        runCatching { pfd?.close() }; pfd = null
        uri?.let { u ->
            if (keep) { if (Build.VERSION.SDK_INT >= 29) { runCatching { contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null) } } }
            else { runCatching { contentResolver.delete(u, null, null) } }
            Unit
        }
        uri = null
        recording.value = false
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
    }

    override fun onDestroy() { if (recording.value) stopRec(); super.onDestroy() }
}
