@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
private fun Chips(content: @Composable RowScope.() -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), content = content)

// =====================================================================
//                     العقارات والإيجارات — الرئيسية
// =====================================================================
@Composable
fun PropertiesScreen(nav: NavController) {
    val dao = remember { appDao() }
    val props by flowState(emptyList<Property>()) { dao.propertiesFlow() }
    val units by flowState(emptyList<PropUnit>()) { dao.unitsFlow() }
    val leases by flowState(emptyList<Lease>()) { dao.leasesFlow() }
    val pays by flowState(emptyList<LeasePayment>()) { dao.leasePaymentsFlow() }
    val exps by flowState(emptyList<PropExpense>()) { dao.propExpensesFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var add by remember { mutableStateOf(false) }
    val pm = people.associateBy { it.id }
    val month = LivingAuto.monthRange()
    val all = Rent.stats(null, units, leases, pays, exps)
    val thisMonth = Rent.stats(null, units, leases, pays, exps, month)
    val overdueLeases = leases.filter { it.active }.mapNotNull { l -> Rent.overdue(l, pays).takeIf { it.isNotEmpty() }?.let { l to it } }
    val ending = leases.filter { Rent.isCurrent(it) && Rent.daysLeft(it) in 0..30 }

    ScreenScaffold(
        title = tr("العقارات والإيجارات", "Properties & rentals"),
        onBack = { nav.popBackStack() },
        actions = { IconButton(onClick = { nav.navigate("props_report") }) { Icon(Icons.Filled.Assessment, tr("تقرير شامل", "Full report")) } },
        fab = { ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("عقار", "Property")) }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("الإيجار الشهري", "Monthly rent"), Fmt.money(all.monthlyRent), Icons.Filled.CalendarMonth, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatCard(tr("المحصّل هذا الشهر", "Collected (month)"), Fmt.money(thisMonth.collected), Icons.Filled.ArrowDownward, SuccessGreen, Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("المتأخرات", "Overdue"), Fmt.money(all.overdue), Icons.Filled.Warning, DangerRed, Modifier.weight(1f))
                    StatCard(tr("نسبة الإشغال", "Occupancy"), "${all.occupancy}% (${all.occupied}/${all.units})", Icons.Filled.Apartment, WarnAmber, Modifier.weight(1f))
                }
            }
            item {
                OutlinedButton(onClick = { nav.navigate("props_report") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Assessment, null); Spacer(Modifier.width(6.dp)); Text(tr("تقرير شامل لكل العقارات والإيجارات مع الإجماليات", "Full report for all properties with totals"))
                }
            }
            if (overdueLeases.isNotEmpty()) {
                item { SectionTitle(tr("إيجارات متأخرة", "Overdue rents")) }
                items(overdueLeases, key = { "o${it.first.id}" }) { (l, list) ->
                    val u = units.firstOrNull { it.id == l.unitId }
                    val t = pm[l.tenantId]
                    Card(onClick = { nav.navigate("lease/${l.id}") }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.08f))) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t?.name ?: "-", fontWeight = FontWeight.SemiBold)
                                Text((props.firstOrNull { it.id == u?.propertyId }?.name ?: "") + " • " + (u?.name ?: "") + " • " + tr("${list.size} دفعة منذ ", "${list.size} since ") + Fmt.date(list.first().due), style = MaterialTheme.typography.bodySmall)
                            }
                            Text(Fmt.money(list.sumOf { it.remaining }), color = DangerRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (ending.isNotEmpty()) {
                item { SectionTitle(tr("عقود تنتهي خلال 30 يوماً", "Leases ending within 30 days")) }
                items(ending, key = { "e${it.id}" }) { l ->
                    val u = units.firstOrNull { it.id == l.unitId }
                    Card(onClick = { nav.navigate("lease/${l.id}") }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = WarnAmber.copy(alpha = 0.1f))) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.EventBusy, null, tint = WarnAmber)
                            Spacer(Modifier.width(8.dp))
                            Text((pm[l.tenantId]?.name ?: "-") + " • " + (u?.name ?: ""), Modifier.weight(1f))
                            Text(tr("بعد ${Rent.daysLeft(l)} يوم", "in ${Rent.daysLeft(l)} d"), color = WarnAmber, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item { SectionTitle(tr("عقاراتي", "My properties")) }
            if (props.isEmpty()) item {
                EmptyState(Icons.Filled.Apartment, tr("أضف عقارك الأول: عمارة أو شقة أو محل، ثم وحداته ومستأجريه.", "Add your first property, then its units and tenants."))
            }
            items(props, key = { it.id }) { p ->
                val st = Rent.stats(p.id, units, leases, pays, exps)
                val t = Rent.propType(p.type)
                Card(onClick = { nav.navigate("prop/${p.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t.emoji, fontSize = 28.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text(t.label + (if (p.address.isNotBlank()) " • " + p.address else ""), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (st.overdue > 0) StatusChip(tr("متأخرات", "Overdue"), DangerRed)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row {
                            KeyMini(tr("الوحدات", "Units"), "${st.occupied}/${st.units}", Modifier.weight(1f))
                            KeyMini(tr("شهرياً", "Monthly"), Fmt.num(st.monthlyRent), Modifier.weight(1f))
                            KeyMini(tr("المتأخر", "Overdue"), Fmt.num(st.overdue), Modifier.weight(1f), if (st.overdue > 0) DangerRed else null)
                        }
                        if (st.units > 0) {
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(progress = { st.occupancy / 100f }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }
    }
    if (add) PropertyDialog(null, onDismiss = { add = false }) { id -> add = false; nav.navigate("prop/$id") }
}

@Composable
fun KeyMini(label: String, value: String, modifier: Modifier = Modifier, color: Color? = null) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold, color = color ?: MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun PropertyDialog(existing: Property?, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: "BUILDING") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var unitsCount by remember { mutableStateOf("1") }
    var unitRent by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("إضافة عقار", "Add property") else tr("تعديل العقار", "Edit property")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Chips { Rent.propTypes.forEach { t -> FilterChip(type == t.key, { type = t.key }, label = { Text(t.emoji + " " + t.label) }) } }
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم العقار", "Property name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(address, { address = it }, label = { Text(tr("العنوان / الموقع", "Address")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (existing == null) {
                    NumberField(unitsCount, { unitsCount = it }, tr("عدد الوحدات (شقق/محلات)", "Number of units"))
                    MoneyField(unitRent, { unitRent = it }, tr("الإيجار الشهري المعتاد للوحدة (اختياري)", "Usual monthly rent per unit (optional)"))
                }
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل اسم العقار", "Enter a name")); return@TextButton }
                scope.launch {
                    if (existing != null) {
                        dao.updateProperty(existing.copy(name = name.trim(), type = type, address = address.trim(), notes = notes.trim())); onSaved(existing.id)
                    } else {
                        val id = dao.insertProperty(Property(name = name.trim(), type = type, address = address.trim(), notes = notes.trim()))
                        val n = (Fmt.parseInt(unitsCount) ?: 1).coerceIn(1, 200)
                        val rent = Fmt.parse(unitRent) ?: 0.0
                        val unitType = if (type in listOf("SHOP", "OFFICE", "WAREHOUSE", "LAND", "ROOM")) type else "APARTMENT"
                        for (k in 1..n) dao.insertUnit(PropUnit(propertyId = id, name = if (n == 1) name.trim() else (Rent.propType(unitType).label + " " + k), type = unitType, rent = rent))
                        onSaved(id)
                    }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// =====================================================================
//                           تفاصيل العقار
// =====================================================================
@Composable
fun PropertyDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val prop by flowState<Property?>(null, id) { dao.propertyFlow(id) }
    val units by flowState(emptyList<PropUnit>()) { dao.unitsFlow() }
    val leases by flowState(emptyList<Lease>()) { dao.leasesFlow() }
    val pays by flowState(emptyList<LeasePayment>()) { dao.leasePaymentsFlow() }
    val exps by flowState(emptyList<PropExpense>()) { dao.propExpensesFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val linkedExp = rememberLinkedIds(AccountTx.SRC_PROP_EXP)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var unitEdit by remember { mutableStateOf<PropUnit?>(null) }
    var newUnit by remember { mutableStateOf(false) }
    var leaseFor by remember { mutableStateOf<PropUnit?>(null) }
    var addExp by remember { mutableStateOf(false) }
    var delExp by remember { mutableStateOf<PropExpense?>(null) }
    var postExp by remember { mutableStateOf<PropExpense?>(null) }
    var range by rememberSaveable { mutableIntStateOf(2) }

    val p = prop
    if (p == null) { ScreenScaffold(tr("العقار", "Property"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val pm = people.associateBy { it.id }
    val us = units.filter { it.propertyId == p.id }
    val now = LocalDate.now()
    val rng: LongRange? = when (range) { 0 -> LivingAuto.monthRange(); 1 -> now.withDayOfYear(1).toEpochDay()..now.withDayOfYear(now.lengthOfYear()).toEpochDay(); else -> null }
    val st = Rent.stats(p.id, units, leases, pays, exps, rng)
    val myExps = exps.filter { it.propertyId == p.id }

    ScreenScaffold(
        title = p.name, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(null, doc = { Docs.property(p, units, leases, pays, exps, pm, rng) }) { c -> Reports.doc(c, Docs.property(p, units, leases, pays, exps, pm, rng)) }
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null) }
        },
        fab = {
            when (tab) {
                0 -> ExtendedFloatingActionButton(onClick = { newUnit = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("وحدة", "Unit")) })
                1 -> ExtendedFloatingActionButton(onClick = { addExp = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("مصروف", "Expense")) })
                else -> {}
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("الوحدات", "Units")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("المصروفات", "Expenses")) })
                Tab(tab == 2, { tab = 2 }, text = { Text(tr("التقرير", "Report")) })
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        if (us.isEmpty()) item { EmptyState(Icons.Filled.MeetingRoom, tr("أضف وحدات العقار (شقق، محلات، غرف)", "Add units (apartments, shops, rooms)")) }
                        items(us, key = { it.id }) { u ->
                            val cur = leases.firstOrNull { it.unitId == u.id && Rent.isCurrent(it) } ?: leases.firstOrNull { it.unitId == u.id && it.active }
                            val od = cur?.let { Rent.overdue(it, pays) } ?: emptyList()
                            val next = cur?.let { Rent.nextDue(it, pays) }
                            Card(onClick = { if (cur != null) nav.navigate("lease/${cur.id}") else leaseFor = u }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(Rent.propType(u.type).emoji, fontSize = 24.sp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(u.name, fontWeight = FontWeight.SemiBold)
                                        if (cur == null) Text(tr("شاغرة • اضغط للتأجير", "Vacant • tap to rent"), color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                                        else {
                                            Text(pm[cur.tenantId]?.name ?: "-", style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                Fmt.money(cur.rentAmount) + " • " + Rent.periodName(cur.periodMonths) +
                                                    (next?.let { tr(" • القادم ", " • next ") + Fmt.date(it.due) } ?: ""),
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                            if (od.isNotEmpty()) Text(tr("متأخر: ", "Overdue: ") + Fmt.money(od.sumOf { it.remaining }), color = DangerRed, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    IconButton(onClick = { unitEdit = u }) { Icon(Icons.Filled.MoreVert, null) }
                                }
                            }
                        }
                        val past = leases.filter { l -> us.any { it.id == l.unitId } && !Rent.isCurrent(l) }
                        if (past.isNotEmpty()) {
                            item { SectionTitle(tr("عقود منتهية / سابقة", "Past leases")) }
                            items(past, key = { "p${it.id}" }) { l ->
                                Card(onClick = { nav.navigate("lease/${l.id}") }, modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(12.dp)) {
                                        Text((pm[l.tenantId]?.name ?: "-") + " • " + (us.firstOrNull { it.id == l.unitId }?.name ?: ""), Modifier.weight(1f))
                                        Text(Fmt.date(l.startDate) + " ← " + Fmt.date(l.endDate), style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        if (myExps.isEmpty()) item { EmptyState(Icons.Filled.Build, tr("لا توجد مصروفات مسجلة لهذا العقار", "No expenses recorded")) }
                        item { if (myExps.isNotEmpty()) KeyValue(tr("الإجمالي", "Total"), Fmt.money(myExps.sumOf { it.amount }), DangerRed) }
                        items(myExps, key = { it.id }) { e ->
                            val c = Rent.expCat(e.category)
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(c.emoji, fontSize = 22.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(c.label + (e.unitId?.let { uid -> " • " + (us.firstOrNull { it.id == uid }?.name ?: "") } ?: ""), fontWeight = FontWeight.SemiBold)
                                        Text(Fmt.date(e.date) + if (e.note.isNotBlank()) " • " + e.note else "", style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                        Text("- " + Fmt.money(e.amount), color = DangerRed, fontWeight = FontWeight.Bold)
                                    }
                                    AttachmentButton(Attachments.PROP_EXP, e.id)
                                    PostButton(e.id in linkedExp) { postExp = e }
                                    IconButton(onClick = { delExp = e }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                                }
                            }
                        }
                    }
                    else -> {
                        item {
                            Chips {
                                listOf(tr("هذا الشهر", "This month"), tr("هذه السنة", "This year"), tr("الكل", "All")).forEachIndexed { i, s0 -> FilterChip(range == i, { range = i }, label = { Text(s0) }) }
                            }
                        }
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    KeyValue(tr("الوحدات", "Units"), "${st.units}")
                                    KeyValue(tr("المؤجّر حالياً", "Occupied"), "${st.occupied} (${st.occupancy}%)")
                                    KeyValue(tr("الإيجار الشهري المتوقع", "Expected monthly rent"), Fmt.money(st.monthlyRent))
                                    KeyValue(tr("الدخل المحصّل", "Collected"), Fmt.money(st.collected), SuccessGreen)
                                    KeyValue(tr("المصروفات", "Expenses"), Fmt.money(st.expenses), DangerRed)
                                    HorizontalDivider()
                                    KeyValue(tr("صافي الربح", "Net profit"), Fmt.money(st.net), if (st.net >= 0) SuccessGreen else DangerRed)
                                    KeyValue(tr("المتأخرات", "Overdue"), Fmt.money(st.overdue), if (st.overdue > 0) DangerRed else Color.Unspecified)
                                    if (st.collected > 0) KeyValue(tr("نسبة المصروفات من الدخل", "Expense ratio"), "${(st.expenses / st.collected * 100).toInt()}%")
                                }
                            }
                        }
                        item { InfoBanner(tr("زر PDF في الأعلى يصدّر تقرير العقار للفترة المختارة كـ PDF أو Excel أو رابط مشاركة.", "Use the PDF button above to export this report as PDF, Excel or a link.")) }
                    }
                }
            }
        }
    }

    if (edit) PropertyDialog(p, onDismiss = { edit = false }) { edit = false }
    if (del) ConfirmDialog(tr("حذف العقار", "Delete property"), tr("سيُحذف «${p.name}» بكل وحداته وعقوده ودفعاته ومصروفاته والحركات المرحّلة منها.", "Deletes “${p.name}” with all units, leases, payments, expenses and posted transactions."), onDismiss = { del = false }) {
        del = false
        scope.launch { dao.deletePropertyFull(p.id); nav.popBackStack() }
    }
    if (newUnit) UnitDialog(p.id, null) { newUnit = false }
    unitEdit?.let { u ->
        UnitActionsDialog(u, onDismiss = { unitEdit = null }, onRent = { unitEdit = null; leaseFor = u })
    }
    leaseFor?.let { u -> LeaseDialog(u, null, onDismiss = { leaseFor = null }) { lid -> leaseFor = null; nav.navigate("lease/$lid") } }
    if (addExp) PropExpenseDialog(p, us) { addExp = false }
    delExp?.let { e ->
        ConfirmDialog(tr("حذف المصروف", "Delete expense"), tr("حذف مصروف بمبلغ ${Fmt.money(e.amount)}؟", "Delete expense of ${Fmt.money(e.amount)}?"), onDismiss = { delExp = null }) {
            delExp = null
            scope.launch { Attachments.deleteFor(Attachments.PROP_EXP, e.id); dao.deleteLinkedTx(AccountTx.SRC_PROP_EXP, e.id); dao.deletePropExpense(e.id) }
        }
    }
    postExp?.let { e ->
        PostToAccountDialog(tr("خصم المصروف من حساب", "Withdraw from account"), false, onDismiss = { postExp = null }) { acc ->
            postExp = null
            scope.launch { Posting.post(acc, AccountTx.SRC_PROP_EXP, e.id, false, e.amount, e.date, p.name + " - " + Rent.expCat(e.category).label + if (e.note.isNotBlank()) " - ${e.note}" else ""); toast(ctx, tr("تم الترحيل", "Posted")) }
        }
    }
}

@Composable
private fun UnitDialog(propertyId: Long, existing: PropUnit?, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: "APARTMENT") }
    var rent by remember { mutableStateOf(existing?.rent?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("إضافة وحدة", "Add unit") else tr("تعديل الوحدة", "Edit unit")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Chips { Rent.propTypes.filter { it.key != "BUILDING" }.forEach { t -> FilterChip(type == t.key, { type = t.key }, label = { Text(t.emoji + " " + t.label) }) } }
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم/رقم الوحدة", "Unit name/number")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                MoneyField(rent, { rent = it }, tr("الإيجار الشهري المعتاد", "Usual monthly rent"))
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val nm = name.trim().ifBlank { Rent.propType(type).label }
                    if (existing == null) dao.insertUnit(PropUnit(propertyId = propertyId, name = nm, type = type, rent = Fmt.parse(rent) ?: 0.0, notes = notes.trim()))
                    else dao.updateUnit(existing.copy(name = nm, type = type, rent = Fmt.parse(rent) ?: 0.0, notes = notes.trim()))
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun UnitActionsDialog(u: PropUnit, onDismiss: () -> Unit, onRent: () -> Unit) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    if (edit) { UnitDialog(u.propertyId, u) { edit = false; onDismiss() }; return }
    if (del) {
        ConfirmDialog(tr("حذف الوحدة", "Delete unit"), tr("حذف «${u.name}» مع عقودها ودفعاتها؟", "Delete “${u.name}” with its leases and payments?"), onDismiss = { del = false; onDismiss() }) {
            scope.launch { dao.deleteUnitFull(u.id); onDismiss() }
        }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(u.name) },
        text = {
            Column {
                ListItem(headlineContent = { Text(tr("عقد إيجار جديد", "New lease")) }, leadingContent = { Icon(Icons.Filled.Key, null) }, modifier = Modifier.clickable { onRent() })
                ListItem(headlineContent = { Text(tr("تعديل الوحدة", "Edit unit")) }, leadingContent = { Icon(Icons.Filled.Edit, null) }, modifier = Modifier.clickable { edit = true })
                ListItem(headlineContent = { Text(tr("حذف الوحدة", "Delete unit"), color = DangerRed) }, leadingContent = { Icon(Icons.Filled.Delete, null, tint = DangerRed) }, modifier = Modifier.clickable { del = true })
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
}

/** إنشاء / تعديل / تجديد عقد إيجار */
@Composable
fun LeaseDialog(unit: PropUnit, existing: Lease?, renewFrom: Lease? = null, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val base = existing ?: renewFrom
    var tenantId by remember { mutableStateOf(base?.tenantId) }
    val startDefault = renewFrom?.let { it.endDate + 1 } ?: existing?.startDate ?: Fmt.today()
    var start by remember { mutableStateOf(startDefault) }
    var end by remember { mutableStateOf(existing?.endDate ?: LocalDate.ofEpochDay(startDefault).plusYears(1).minusDays(1).toEpochDay()) }
    var rent by remember { mutableStateOf(base?.rentAmount?.let { Fmt.plain(it) } ?: unit.rent.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var period by remember { mutableIntStateOf(base?.periodMonths ?: 1) }
    var deposit by remember { mutableStateOf(existing?.deposit?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var remind by remember { mutableStateOf(base?.reminderEnabled ?: true) }
    var notes by remember { mutableStateOf(base?.notes ?: "") }
    val postDep = remember { mutableStateOf(Posting.lastAccount("rent")) }
    val pending = remember { mutableStateListOf<Uri>() }
    val tenant = people.firstOrNull { it.id == tenantId }

    fun setTerm(months: Int) { end = LocalDate.ofEpochDay(start).plusMonths(months.toLong()).minusDays(1).toEpochDay() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(when { renewFrom != null -> tr("تجديد العقد", "Renew lease"); existing != null -> tr("تعديل العقد", "Edit lease"); else -> tr("عقد إيجار جديد", "New lease") } + " • " + unit.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PersonSelector(tenant, tr("اختر المستأجر", "Choose tenant")) { tenantId = it.id }
                DateField(tr("بداية العقد", "Start"), start, { d -> if (d != null) start = d })
                Text(tr("مدة العقد", "Term"), style = MaterialTheme.typography.labelLarge)
                Chips {
                    listOf(3 to tr("3 أشهر", "3 mo"), 6 to tr("6 أشهر", "6 mo"), 12 to tr("سنة", "1 yr"), 24 to tr("سنتان", "2 yr"), 36 to tr("3 سنوات", "3 yr"))
                        .forEach { (m, l) -> AssistChip(onClick = { setTerm(m) }, label = { Text(l) }) }
                }
                DateField(tr("نهاية العقد", "End"), end, { d -> if (d != null) end = d })
                Text(tr("دورية الدفع", "Payment frequency"), style = MaterialTheme.typography.labelLarge)
                Chips { Rent.periods.forEach { m -> FilterChip(period == m, { period = m }, label = { Text(Rent.periodName(m)) }) } }
                MoneyField(rent, { rent = it }, tr("قيمة الدفعة الواحدة (", "Amount per payment (") + Rent.periodName(period) + ")")
                Fmt.parse(rent)?.let { v ->
                    val n = run { var k = 0; while (!LocalDate.ofEpochDay(start).plusMonths((k * period).toLong()).isAfter(LocalDate.ofEpochDay(end)) && k < 600) k++; k.coerceAtLeast(1) }
                    Text(tr("عدد الدفعات: $n • إجمالي العقد: ", "Payments: $n • Lease total: ") + Fmt.money(v * n) + tr(" • شهرياً: ", " • Monthly: ") + Fmt.money(v / period), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
                if (existing == null) {
                    MoneyField(deposit, { deposit = it }, tr("التأمين (اختياري)", "Deposit (optional)"))
                    if ((Fmt.parse(deposit) ?: 0.0) > 0) AccountPickRow(postDep, tr("إيداع التأمين في حساب (اختياري)", "Deposit into account (optional)"))
                    Text(tr("صورة العقد والهوية (اختياري):", "Contract & ID photos (optional):"), style = MaterialTheme.typography.labelLarge)
                    PendingAttachRow(pending)
                }
                SwitchRow(tr("تذكير بمواعيد الدفع وانتهاء العقد", "Payment & expiry reminders"), null, remind, Icons.Filled.NotificationsActive) { remind = it }
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(rent)
                when {
                    tenantId == null -> { toast(ctx, tr("اختر المستأجر", "Choose a tenant")); return@TextButton }
                    v == null || v <= 0 -> { toast(ctx, tr("أدخل قيمة الإيجار", "Enter the rent")); return@TextButton }
                    end < start -> { toast(ctx, tr("تاريخ النهاية قبل البداية", "End is before start")); return@TextButton }
                }
                scope.launch {
                    if (existing != null) {
                        dao.updateLease(existing.copy(tenantId = tenantId!!, startDate = start, endDate = end, rentAmount = v!!, periodMonths = period, reminderEnabled = remind, notes = notes.trim()))
                        onSaved(existing.id)
                    } else {
                        renewFrom?.let { dao.updateLease(it.copy(active = false)) }
                        val dep = Fmt.parse(deposit) ?: 0.0
                        val lid = dao.insertLease(Lease(unitId = unit.id, tenantId = tenantId!!, startDate = start, endDate = end, rentAmount = v!!, periodMonths = period, deposit = dep, reminderEnabled = remind, notes = notes.trim()))
                        Attachments.addAll(ctx, Attachments.LEASE, lid, pending.toList())
                        if (dep > 0) {
                            Posting.setLastAccount("rent", postDep.value)
                            Posting.post(postDep.value, AccountTx.SRC_DEPOSIT, lid, true, dep, start, tr("تأمين عقد ", "Lease deposit ") + unit.name + " - " + (tenant?.name ?: ""))
                        }
                        onSaved(lid)
                    }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun PropExpenseDialog(p: Property, units: List<PropUnit>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var cat by remember { mutableStateOf("MAINT") }
    var unitId by remember { mutableStateOf<Long?>(null) }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var note by remember { mutableStateOf("") }
    val pending = remember { mutableStateListOf<Uri>() }
    val post = remember { mutableStateOf(Posting.lastAccount("propexp")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("مصروف على ", "Expense for ") + p.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Chips { Rent.expenseCats.forEach { c -> FilterChip(cat == c.key, { cat = c.key }, label = { Text(c.emoji + " " + c.label) }) } }
                if (units.size > 1) Chips {
                    FilterChip(unitId == null, { unitId = null }, label = { Text(tr("العقار كله", "Whole property")) })
                    units.forEach { u -> FilterChip(unitId == u.id, { unitId = u.id }, label = { Text(u.name) }) }
                }
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
                AccountPickRow(post, tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
                PendingAttachRow(pending)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(amount)
                if (v == null || v <= 0) { toast(ctx, tr("أدخل مبلغاً صحيحاً", "Enter a valid amount")); return@TextButton }
                scope.launch {
                    val id = dao.insertPropExpense(PropExpense(propertyId = p.id, unitId = unitId, category = cat, amount = v, date = date, note = note.trim()))
                    Attachments.addAll(ctx, Attachments.PROP_EXP, id, pending.toList())
                    Posting.setLastAccount("propexp", post.value)
                    Posting.post(post.value, AccountTx.SRC_PROP_EXP, id, false, v, date, p.name + " - " + Rent.expCat(cat).label + if (note.isNotBlank()) " - ${note.trim()}" else "")
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// =====================================================================
//                           تفاصيل العقد
// =====================================================================
@Composable
fun LeaseDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val lease by flowState<Lease?>(null, id) { dao.leaseFlow(id) }
    val units by flowState(emptyList<PropUnit>()) { dao.unitsFlow() }
    val props by flowState(emptyList<Property>()) { dao.propertiesFlow() }
    val allPays by flowState(emptyList<LeasePayment>()) { dao.leasePaymentsFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val linked = rememberLinkedIds(AccountTx.SRC_RENT)
    var pay by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    var renew by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var endIt by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<LeasePayment?>(null) }
    var postPay by remember { mutableStateOf<LeasePayment?>(null) }
    val pending = remember { mutableStateListOf<Uri>() }
    val postTo = remember { mutableStateOf(Posting.lastAccount("rent")) }

    val l = lease
    if (l == null) { ScreenScaffold(tr("العقد", "Lease"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val u = units.firstOrNull { it.id == l.unitId }
    val p = props.firstOrNull { it.id == u?.propertyId }
    val t = people.firstOrNull { it.id == l.tenantId }
    val pays = allPays.filter { it.leaseId == l.id }.sortedByDescending { it.date }
    val sch = Rent.schedule(l, allPays)
    val total = sch.sumOf { it.amount }
    val paid = pays.sumOf { it.amount }
    val od = sch.filter { !it.isPaid && !it.due.isAfter(LocalDate.now()) }
    val next = sch.firstOrNull { !it.isPaid }
    val place = (p?.name ?: "") + " - " + (u?.name ?: "")

    ScreenScaffold(
        title = t?.name ?: tr("العقد", "Lease"), onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(t?.phone, doc = { Docs.lease(l, u, p, t, allPays) }) { c -> Reports.doc(c, Docs.lease(l, u, p, t, allPays)) }
            AttachmentButton(Attachments.LEASE, l.id, t?.phone)
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(place, fontWeight = FontWeight.Bold)
                        Text(Fmt.date(l.startDate) + " ← " + Fmt.date(l.endDate) + if (!l.active) tr(" • منتهي", " • ended") else if (Rent.daysLeft(l) >= 0) tr(" • متبقٍ ${Rent.daysLeft(l)} يوم", " • ${Rent.daysLeft(l)} days left") else "", style = MaterialTheme.typography.bodySmall)
                        KeyValue(tr("الدفعة", "Payment"), Fmt.money(l.rentAmount) + " • " + Rent.periodName(l.periodMonths))
                        if (l.deposit > 0) KeyValue(tr("التأمين", "Deposit"), Fmt.money(l.deposit))
                        KeyValue(tr("المدفوع", "Paid"), Fmt.money(paid) + " / " + Fmt.money(total), SuccessGreen)
                        LinearProgressIndicator(progress = { if (total > 0) (paid / total).toFloat().coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth())
                        if (od.isNotEmpty()) KeyValue(tr("المتأخر", "Overdue"), Fmt.money(od.sumOf { it.remaining }) + tr(" (${od.size} دفعة)", " (${od.size})"), DangerRed)
                        next?.let { KeyValue(tr("الدفعة القادمة", "Next payment"), Fmt.money(it.remaining) + " • " + Fmt.date(it.due)) }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { pay = true }, modifier = Modifier.weight(1f), enabled = paid < total - 0.005) {
                        Icon(Icons.Filled.Payments, null); Spacer(Modifier.width(4.dp)); Text(tr("تسجيل دفعة", "Record payment"))
                    }
                    if (t != null && t.phone.isNotBlank()) {
                        OutlinedButton(onClick = {
                            val amt = if (od.isNotEmpty()) od.sumOf { it.remaining } else next?.remaining ?: 0.0
                            val due = od.firstOrNull()?.due ?: next?.due
                            Share.whatsappMessage(ctx, t.phone, tr(
                                "السلام عليكم ${t.name}، نذكركم بدفعة إيجار $place بمبلغ ${Fmt.money(amt)}" + (due?.let { " المستحقة بتاريخ ${Fmt.date(it)}" } ?: "") + ". شاكرين تعاونكم.",
                                "Hello ${t.name}, a reminder of the rent for $place: ${Fmt.money(amt)}" + (due?.let { " due on ${Fmt.date(it)}" } ?: "") + ". Thank you."
                            ) + appPrefs().displayName.let { if (it.isBlank()) "" else "\n— $it" })
                        }, colors = ButtonDefaults.outlinedButtonColors(contentColor = WhatsGreen)) { Icon(Icons.Filled.Chat, null) }
                        OutlinedButton(onClick = { Share.dial(ctx, t.phone) }) { Icon(Icons.Filled.Call, null) }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (u != null) OutlinedButton(onClick = { renew = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Autorenew, null); Spacer(Modifier.width(4.dp)); Text(tr("تجديد", "Renew")) }
                    if (l.active) OutlinedButton(onClick = { endIt = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.EventBusy, null); Spacer(Modifier.width(4.dp)); Text(tr("إنهاء", "End")) }
                    OutlinedButton(onClick = { del = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed)) { Icon(Icons.Filled.Delete, null) }
                }
            }
            item { SectionTitle(tr("جدول الدفعات", "Schedule")) }
            items(sch, key = { "s${it.index}" }) { d ->
                val color = when { d.isPaid -> SuccessGreen; d.paid > 0 -> WarnAmber; !d.due.isAfter(LocalDate.now()) -> DangerRed; else -> MaterialTheme.colorScheme.onSurfaceVariant }
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${d.index + 1}", Modifier.width(28.dp), color = color, fontWeight = FontWeight.Bold)
                    Text(Fmt.date(d.due), Modifier.weight(1f))
                    Text(Fmt.num(d.amount), Modifier.weight(1f))
                    StatusChip(when { d.isPaid -> tr("مدفوع", "Paid"); d.paid > 0 -> tr("جزئي", "Partial"); !d.due.isAfter(LocalDate.now()) -> tr("متأخر", "Late"); else -> tr("قادم", "Upcoming") }, color)
                }
            }
            if (pays.isNotEmpty()) {
                item { SectionTitle(tr("الدفعات المستلمة", "Received payments")) }
                items(pays, key = { it.id }) { x ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("+ " + Fmt.money(x.amount), color = SuccessGreen, fontWeight = FontWeight.Bold)
                                Text(Fmt.date(x.date) + if (x.note.isNotBlank()) " • " + x.note else "", style = MaterialTheme.typography.bodySmall)
                            }
                            AttachmentButton(Attachments.RENT_PAY, x.id, t?.phone)
                            PostButton(x.id in linked) { postPay = x }
                            IconButton(onClick = { delPay = x }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                        }
                    }
                }
            }
        }
    }

    if (pay) AmountDialog(
        title = tr("تسجيل دفعة إيجار", "Record rent payment"),
        initial = if (od.isNotEmpty()) od.sumOf { it.remaining } else next?.remaining,
        info = tr("المتبقي من العقد: ", "Remaining: ") + Fmt.money(total - paid),
        maxAmount = total - paid,
        pending = pending, postTo = postTo, postLabel = tr("إيداع في حساب (اختياري)", "Deposit into account (optional)"),
        onDismiss = { pay = false }
    ) { amount, date, _, note ->
        scope.launch {
            val pid = dao.insertLeasePayment(LeasePayment(leaseId = l.id, amount = amount, date = date, note = note))
            Attachments.addAll(ctx, Attachments.RENT_PAY, pid, pending.toList())
            Posting.setLastAccount("rent", postTo.value)
            Posting.post(postTo.value, AccountTx.SRC_RENT, pid, true, amount, date, tr("إيجار ", "Rent ") + place + " - " + (t?.name ?: "") + if (note.isNotBlank()) " - $note" else "")
            pending.clear(); pay = false
            toast(ctx, tr("تم تسجيل الدفعة ✅", "Payment recorded ✅"))
        }
    }
    if (edit && u != null) LeaseDialog(u, l, onDismiss = { edit = false }) { edit = false }
    if (renew && u != null) LeaseDialog(u, null, renewFrom = l, onDismiss = { renew = false }) { nid -> renew = false; nav.navigate("lease/$nid") { popUpTo("lease/{id}") { inclusive = true } } }
    if (endIt) ConfirmDialog(tr("إنهاء العقد", "End lease"), tr("إنهاء العقد وإخلاء الوحدة؟ تبقى الدفعات محفوظة.", "End the lease and free the unit? Payments are kept."), danger = false, onDismiss = { endIt = false }) {
        endIt = false
        scope.launch { dao.updateLease(l.copy(active = false, endDate = minOf(l.endDate, Fmt.today()))) }
    }
    if (del) ConfirmDialog(tr("حذف العقد", "Delete lease"), tr("حذف العقد مع كل دفعاته والحركات المرحّلة منه؟", "Delete the lease with all payments and posted transactions?"), onDismiss = { del = false }) {
        del = false
        scope.launch {
            pays.forEach { Attachments.deleteFor(Attachments.RENT_PAY, it.id) }
            Attachments.deleteFor(Attachments.LEASE, l.id)
            dao.deleteLeaseFull(l.id); nav.popBackStack()
        }
    }
    delPay?.let { x ->
        ConfirmDialog(tr("حذف الدفعة", "Delete payment"), tr("حذف دفعة ${Fmt.money(x.amount)}؟", "Delete payment of ${Fmt.money(x.amount)}?"), onDismiss = { delPay = null }) {
            delPay = null
            scope.launch { Attachments.deleteFor(Attachments.RENT_PAY, x.id); dao.deleteLinkedTx(AccountTx.SRC_RENT, x.id); dao.deleteLeasePayment(x.id) }
        }
    }
    postPay?.let { x ->
        PostToAccountDialog(tr("إيداع في حساب", "Deposit to account"), true, onDismiss = { postPay = null }) { acc ->
            postPay = null
            scope.launch { Posting.post(acc, AccountTx.SRC_RENT, x.id, true, x.amount, x.date, tr("إيجار ", "Rent ") + place + " - " + (t?.name ?: "")); toast(ctx, tr("تم الترحيل", "Posted")) }
        }
    }
}

// =====================================================================
//               تقرير شامل لكل العقارات والإيجارات مع الإجماليات
// =====================================================================
@Composable
fun PropertiesReportScreen(nav: NavController) {
    val dao = remember { appDao() }
    val props by flowState(emptyList<Property>()) { dao.propertiesFlow() }
    val units by flowState(emptyList<PropUnit>()) { dao.unitsFlow() }
    val leases by flowState(emptyList<Lease>()) { dao.leasesFlow() }
    val pays by flowState(emptyList<LeasePayment>()) { dao.leasePaymentsFlow() }
    val exps by flowState(emptyList<PropExpense>()) { dao.propExpensesFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var range by rememberSaveable { mutableIntStateOf(2) }
    var from by rememberSaveable { mutableStateOf(LocalDate.now().withDayOfYear(1).toEpochDay()) }
    var to by rememberSaveable { mutableStateOf(Fmt.today()) }
    var onlyCurrent by rememberSaveable { mutableStateOf(false) }
    val pm = people.associateBy { it.id }
    val now = LocalDate.now()
    val rng: LongRange? = when (range) {
        0 -> LivingAuto.monthRange()
        1 -> now.withDayOfYear(1).toEpochDay()..now.withDayOfYear(now.lengthOfYear()).toEpochDay()
        3 -> minOf(from, to)..maxOf(from, to)
        else -> null
    }
    val all = Rent.stats(null, units, leases, pays, exps, rng)
    val rows = Docs.propRows(props, units, leases, pays, exps, rng)
    val lr = Docs.leaseRows(units, props, leases, pays)
    val yearly = rows.sumOf { it.yearly }
    val deposits = rows.sumOf { it.deposits }
    val remaining = lr.filter { it.l.active }.sumOf { it.remaining }
    fun doc() = Docs.allProperties(props, units, leases, pays, exps, pm, rng, onlyCurrent)

    ScreenScaffold(
        title = tr("تقرير العقارات الشامل", "Properties report"), onBack = { nav.popBackStack() },
        actions = { PdfShareButton(null, doc = { doc() }) { c -> Reports.doc(c, doc()) } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(tr("هذا الشهر", "This month"), tr("هذه السنة", "This year"), tr("الكل", "All"), tr("فترة مخصصة", "Custom")).forEachIndexed { i, t ->
                        FilterChip(range == i, { range = i }, label = { Text(t) })
                    }
                }
            }
            if (range == 3) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(tr("من", "From"), from, { d -> if (d != null) from = d }, modifier = Modifier.weight(1f))
                    DateField(tr("إلى", "To"), to, { d -> if (d != null) to = d }, modifier = Modifier.weight(1f))
                }
            }
            item { SwitchRow(tr("العقود السارية فقط في جدول العقود", "Only active leases in the leases table"), null, onlyCurrent) { onlyCurrent = it } }

            // الإجماليات
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(tr("صافي ربح العقارات", "Net property profit"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                        Text(Fmt.money(all.net), color = MaterialTheme.colorScheme.onPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(tr("المحصّل ", "Collected ") + Fmt.money(all.collected) + tr(" − المصروفات ", " − expenses ") + Fmt.money(all.expenses),
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("الإيجار الشهري", "Monthly rent"), Fmt.money(all.monthlyRent), Icons.Filled.CalendarMonth, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatCard(tr("الإيجار السنوي", "Yearly rent"), Fmt.money(yearly), Icons.Filled.Event, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("المتأخرات", "Overdue"), Fmt.money(all.overdue), Icons.Filled.Warning, DangerRed, Modifier.weight(1f))
                    StatCard(tr("الإشغال", "Occupancy"), "${all.occupancy}% (${all.occupied}/${all.units})", Icons.Filled.Apartment, WarnAmber, Modifier.weight(1f))
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(tr("الإجماليات", "Totals"), fontWeight = FontWeight.Bold)
                        KeyValue(tr("عدد العقارات", "Properties"), "${props.size}")
                        KeyValue(tr("الوحدات (مؤجّرة / شاغرة)", "Units (let / vacant)"), "${all.units} (${all.occupied} / ${all.units - all.occupied})")
                        KeyValue(tr("العقود السارية", "Active leases"), "${leases.count { Rent.isCurrent(it) }}")
                        KeyValue(tr("إجمالي المحصّل", "Total collected"), Fmt.money(all.collected), SuccessGreen)
                        KeyValue(tr("إجمالي المصروفات", "Total expenses"), Fmt.money(all.expenses), DangerRed)
                        KeyValue(tr("صافي الربح", "Net profit"), Fmt.money(all.net), if (all.net >= 0) SuccessGreen else DangerRed)
                        KeyValue(tr("المتبقي على العقود", "Remaining on leases"), Fmt.money(remaining))
                        KeyValue(tr("التأمينات المحتفظ بها", "Deposits held"), Fmt.money(deposits))
                    }
                }
            }

            item { SectionTitle(tr("تفاصيل كل عقار", "Per property")) }
            if (props.isEmpty()) item { EmptyState(Icons.Filled.Apartment, tr("لا توجد عقارات بعد", "No properties yet")) }
            items(rows, key = { it.p.id }) { r ->
                val us = units.filter { it.propertyId == r.p.id }
                Card(onClick = { nav.navigate("prop/${r.p.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Rent.propType(r.p.type).label + " • " + r.p.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (r.st.overdue > 0.005) StatusChip(tr("متأخر", "Overdue"), DangerRed) else StatusChip("${r.st.occupancy}%", SuccessGreen)
                        }
                        KeyValue(tr("الوحدات / المؤجّر", "Units / let"), "${r.st.units} / ${r.st.occupied}")
                        KeyValue(tr("الإيجار شهرياً / سنوياً", "Rent monthly / yearly"), Fmt.money(r.st.monthlyRent) + " / " + Fmt.money(r.yearly))
                        KeyValue(tr("المحصّل", "Collected"), Fmt.money(r.st.collected), SuccessGreen)
                        KeyValue(tr("المصروفات", "Expenses"), Fmt.money(r.st.expenses), DangerRed)
                        KeyValue(tr("الصافي", "Net"), Fmt.money(r.st.net))
                        if (r.st.overdue > 0.005) KeyValue(tr("المتأخر", "Overdue"), Fmt.money(r.st.overdue), DangerRed)
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        us.forEach { u ->
                            val l = leases.firstOrNull { it.unitId == u.id && Rent.isCurrent(it) }
                            val od = l?.let { Rent.overdue(it, pays).sumOf { d -> d.remaining } } ?: 0.0
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("• " + u.name, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                Text(
                                    l?.let { (pm[it.tenantId]?.name ?: "-") + " • " + Fmt.num(it.rentAmount) + "/" + Rent.periodName(it.periodMonths) } ?: tr("شاغرة", "Vacant"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = when { l == null -> MaterialTheme.colorScheme.outline; od > 0.005 -> DangerRed; else -> MaterialTheme.colorScheme.onSurface }
                                )
                            }
                        }
                    }
                }
            }
            item {
                Text(tr("📄 زر المشاركة أعلاه يصدّر التقرير كاملاً (PDF أو Excel أو رابط) بجداول: ملخص العقارات، الوحدات والمستأجرين، كل العقود، الدفعات، المصروفات، مع صف الإجمالي في كل جدول.",
                    "Share above exports the full report (PDF/Excel/link) with totals in every table."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
