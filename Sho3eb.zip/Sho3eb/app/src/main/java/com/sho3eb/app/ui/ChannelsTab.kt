@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** دليل القنوات: يفتح البث الرسمي المباشر للقناة (قنوات يوتيوب الرسمية والمواقع)، وقنوات M3U القانونية للمستخدم */
object Channels {
    data class Ch(val name: String, val emoji: String, val query: String = name)
    val groups: List<Pair<Opt, List<Ch>>> = listOf(
        Opt("SPORT_EG", "رياضية مصرية", "Egyptian sports", "⚽") to listOf(Ch("أون تايم سبورت ON Time Sports", "⚽", "ON Time Sports"), Ch("قناة الأهلي Al Ahly TV", "🔴", "Al Ahly TV"), Ch("قناة الزمالك Zamalek TV", "⚪", "قناة الزمالك"), Ch("النيل للرياضة", "🏆", "قناة النيل للرياضة")),
        Opt("SPORT_GULF", "رياضية خليجية", "Gulf sports", "🏟️") to listOf(Ch("SSC السعودية الرياضية", "🇸🇦", "SSC sports"), Ch("أبوظبي الرياضية", "🇦🇪", "Abu Dhabi Sports"), Ch("دبي الرياضية", "🇦🇪", "Dubai Sports"), Ch("الكأس القطرية Alkass", "🇶🇦", "Alkass"), Ch("الكويت الرياضية", "🇰🇼", "تلفزيون الكويت الرياضية"), Ch("beIN SPORTS News", "📰", "beIN SPORTS")),
        Opt("NEWS", "أخبار", "News", "📰") to listOf(Ch("القاهرة الإخبارية", "🇪🇬", "القاهرة الإخبارية"), Ch("إكسترا نيوز", "🇪🇬", "Extra News"), Ch("الجزيرة", "🌐", "Al Jazeera Arabic"), Ch("العربية", "🌐", "العربية"), Ch("الحدث", "🌐", "الحدث"), Ch("سكاي نيوز عربية", "🌐", "Sky News Arabia"), Ch("الشرق للأخبار", "🌐", "Asharq News")),
        Opt("EG", "عامة مصرية", "Egyptian", "🇪🇬") to listOf(Ch("القناة الأولى المصرية", "📺"), Ch("ON", "📺", "ON E"), Ch("CBC", "📺"), Ch("الحياة", "📺", "قناة الحياة"), Ch("DMC", "📺"), Ch("صدى البلد", "📺"), Ch("النهار", "📺", "قناة النهار"), Ch("TeN", "📺", "قناة TeN")),
        Opt("GULF", "عامة خليجية", "Gulf", "🌴") to listOf(Ch("السعودية الأولى", "🇸🇦", "القناة السعودية الأولى"), Ch("MBC 1", "📺"), Ch("MBC مصر", "📺", "MBC Masr"), Ch("روتانا خليجية", "📺"), Ch("أبوظبي", "🇦🇪", "قناة أبوظبي"), Ch("دبي", "🇦🇪", "تلفزيون دبي"), Ch("تلفزيون الكويت", "🇰🇼"), Ch("تلفزيون قطر", "🇶🇦"), Ch("تلفزيون عُمان", "🇴🇲"), Ch("تلفزيون البحرين", "🇧🇭")),
        Opt("RELIGION", "دينية", "Religious", "🕋") to listOf(Ch("قناة القرآن الكريم (مكة المكرمة)", "🕋", "قناة القرآن الكريم بث مباشر مكة"), Ch("قناة السنة النبوية (المدينة)", "🕌", "قناة السنة النبوية بث مباشر"), Ch("إذاعة القرآن الكريم من القاهرة", "📻", "إذاعة القرآن الكريم من القاهرة"), Ch("قناة المجد", "📖")),
        Opt("KIDS", "أطفال", "Kids", "🧸") to listOf(Ch("سبيستون Spacetoon", "🚀", "Spacetoon"), Ch("MBC3", "🎈"), Ch("ماجد Majid", "📚", "Majid TV"), Ch("براعم", "🌱", "قناة براعم"))
    )
    /** بحث يوتيوب عن البث المباشر فقط للقناة الرسمية */
    fun liveSearch(q: String) = "https://m.youtube.com/results?search_query=" + URLEncoder.encode("$q بث مباشر", "UTF-8") + "&sp=EgJAAQ%3D%3D"

    data class M3u(val name: String, val url: String, val group: String, val logo: String)
    fun parseM3u(text: String): List<M3u> {
        val out = mutableListOf<M3u>()
        var name = ""; var group = ""; var logo = ""
        text.lineSequence().map { it.trim() }.forEach { l ->
            when {
                l.startsWith("#EXTINF", true) -> {
                    name = l.substringAfterLast(",").trim()
                    group = Regex("group-title=\"([^\"]*)\"").find(l)?.groupValues?.get(1) ?: ""
                    logo = Regex("tvg-logo=\"([^\"]*)\"").find(l)?.groupValues?.get(1) ?: ""
                }
                l.isNotBlank() && !l.startsWith("#") -> { out += M3u(name.ifBlank { l.take(40) }, l, group, logo); name = ""; group = ""; logo = "" }
            }
        }
        return out
    }
    fun saved(): List<M3u> = runCatching { JSONArray(Extras.s("m3u_list", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> M3u(o.getString("n"), o.getString("u"), o.optString("g"), o.optString("l")) } } } }.getOrDefault(emptyList())
    fun save(l: List<M3u>) = Extras.ps("m3u_list", JSONArray(l.map { JSONObject().put("n", it.name).put("u", it.url).put("g", it.group).put("l", it.logo) }).toString())
    var favorites: Set<String> get() = Extras.s("ch_favs", "").split("|").filter { it.isNotBlank() }.toSet(); set(v) = Extras.ps("ch_favs", v.joinToString("|"))
}

@Composable
fun ChannelsTab(nav: NavController) {
    val ctx = LocalContext.current
    var group by rememberSaveable { mutableStateOf("FAV") }
    var favs by remember { mutableStateOf(Channels.favorites) }
    var mine by remember { mutableStateOf(Channels.saved()) }
    var q by rememberSaveable { mutableStateOf("") }
    var urlDlg by remember { mutableStateOf(false) }
    val pickM3u = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val t = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull() ?: ""
            val l = Channels.parseM3u(t)
            if (l.isEmpty()) toast(ctx, tr("لم يتم العثور على قنوات في الملف", "No channels found in the file")) else { mine = (mine + l).distinctBy { it.url }; Channels.save(mine); group = "MINE"; toast(ctx, tr("أُضيفت ${l.size} قناة", "${l.size} channels added")) }
        }
    }
    val all = Channels.groups.flatMap { it.second }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            HChips {
                FilterChip(group == "FAV", { group = "FAV" }, label = { Text(tr("⭐ المفضلة", "⭐ Favorites")) })
                Channels.groups.forEach { (g, _) -> FilterChip(group == g.key, { group = g.key }, label = { Text(g.emoji + " " + g.label) }) }
                FilterChip(group == "MINE", { group = "MINE" }, label = { Text(tr("📡 قنواتي (M3U)", "📡 My channels (M3U)")) })
            }
        }
        item { SearchField(q) { q = it } }
        when (group) {
            "MINE" -> {
                item {
                    Text(tr("استورد قائمة قنوات M3U من اشتراك قانوني تملكه (IPTV مرخص)، فتعمل في المشغل الداخلي بالجودة والصوت وملء الشاشة والتسجيل.", "Import an M3U list from a legal subscription you own."), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickM3u.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text(tr("ملف M3U", "M3U file")) }
                        OutlinedButton(onClick = { urlDlg = true }, modifier = Modifier.weight(1f)) { Text(tr("رابط M3U", "M3U URL")) }
                    }
                }
                val l = mine.filter { q.isBlank() || it.name.contains(q, true) || it.group.contains(q, true) }
                items(l.size) { i ->
                    val c = l[i]
                    Card(onClick = { nav.openPlayer(c.url, c.name) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (c.logo.isNotBlank()) UrlImage(c.logo, Modifier.size(36.dp)) else Text("📡", fontSize = 24.sp)
                            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) { Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); if (c.group.isNotBlank()) Text(c.group, style = MaterialTheme.typography.labelSmall) }
                            IconButton(onClick = { mine = mine.filter { it.url != c.url }; Channels.save(mine) }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                        }
                    }
                }
            }
            else -> {
                val list = (if (group == "FAV") all.filter { it.name in favs } else Channels.groups.firstOrNull { it.first.key == group }?.second ?: emptyList())
                    .filter { q.isBlank() || it.name.contains(q, true) }.let { if (q.isNotBlank() && group == "FAV") all.filter { c -> c.name.contains(q, true) } else it }
                if (group == "FAV" && list.isEmpty()) item { Text(tr("اضغط ⭐ بجانب أي قناة لإضافتها للمفضلة.", "Tap ⭐ next to a channel to add it."), style = MaterialTheme.typography.bodySmall) }
                items(list, key = { it.name }) { c ->
                    Card(onClick = { nav.openWeb(Channels.liveSearch(c.query), c.name) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(c.emoji, fontSize = 26.sp)
                            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                Text(c.name, fontWeight = FontWeight.Bold)
                                Text(tr("🔴 البث المباشر الرسمي", "🔴 Official live stream"), style = MaterialTheme.typography.labelSmall, color = DangerRed)
                            }
                            IconButton(onClick = { favs = if (c.name in favs) favs - c.name else favs + c.name; Channels.favorites = favs }) { Icon(if (c.name in favs) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
                item { Text(tr("تفتح القناة بثها المباشر الرسمي على يوتيوب داخل التطبيق إن كانت تبثه. المباريات المشفرة متاحة فقط عبر اشتراك القناة الرسمي.", "Opens the channel's official YouTube live stream in-app when available. Encrypted matches require the official subscription."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
    if (urlDlg) {
        val scope = rememberCoroutineScope()
        var u by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { urlDlg = false }, title = { Text(tr("رابط قائمة M3U", "M3U list URL")) }, text = { OutlinedTextField(u, { u = it.trim() }, singleLine = true, label = { Text("URL") }) },
            confirmButton = { TextButton(onClick = {
                urlDlg = false
                scope.launch {
                    val t = withContext(Dispatchers.IO) { runCatching { java.net.URL(u).readText() }.getOrNull() } ?: ""
                    val l = Channels.parseM3u(t)
                    if (l.isEmpty()) toast(ctx, tr("لم يتم العثور على قنوات", "No channels found")) else { mine = (mine + l).distinctBy { it.url }; Channels.save(mine); toast(ctx, tr("أُضيفت ${l.size} قناة", "${l.size} channels added")) }
                }
            }) { Text(tr("استيراد", "Import")) } },
            dismissButton = { TextButton(onClick = { urlDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
}
