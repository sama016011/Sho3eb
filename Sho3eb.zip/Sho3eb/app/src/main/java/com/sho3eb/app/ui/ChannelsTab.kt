@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** دليل القنوات: يفتح البث الرسمي المباشر للقناة (قنوات يوتيوب الرسمية والمواقع)، وقنوات M3U القانونية للمستخدم */
object Channels {
    data class Ch(val name: String, val emoji: String, val query: String = name)
    val groups: List<Pair<Opt, List<Ch>>> = listOf(
        Opt("SPORT_EG", "رياضية مصرية", "Egyptian sports", "⚽") to listOf(Ch("أون تايم سبورت ON Time Sports", "⚽", "ON Time Sports"), Ch("قناة الأهلي Al Ahly TV", "🔴", "Al Ahly TV"), Ch("قناة الزمالك Zamalek TV", "⚪", "قناة الزمالك"), Ch("النيل للرياضة", "🏆", "قناة النيل للرياضة")),
        Opt("SPORT_GULF", "رياضية خليجية", "Gulf sports", "🏟️") to listOf(Ch("SSC السعودية الرياضية", "🇸🇦", "SSC sports"), Ch("أبوظبي الرياضية", "🇦🇪", "Abu Dhabi Sports"), Ch("دبي الرياضية", "🇦🇪", "Dubai Sports"), Ch("الكأس القطرية Alkass", "🇶🇦", "Alkass"), Ch("الكويت الرياضية", "🇰🇼", "تلفزيون الكويت الرياضية"), Ch("beIN SPORTS News", "📰", "beIN SPORTS")),
        Opt("NEWS", "أخبار", "News", "📰") to listOf(Ch("القاهرة الإخبارية", "🇪🇬", "القاهرة الإخبارية"), Ch("إكسترا نيوز", "🇪🇬", "Extra News"), Ch("الجزيرة", "🌐", "Al Jazeera Arabic"), Ch("العربية", "🌐", "العربية"), Ch("الحدث", "🌐", "الحدث"), Ch("سكاي نيوز عربية", "🌐", "Sky News Arabia"), Ch("الشرق للأخبار", "🌐", "Asharq News")),
        Opt("EG", "عامة مصرية", "Egyptian", "🇪🇬") to listOf(Ch("القناة الأولى المصرية", "📺"), Ch("ON", "📺", "ON E"), Ch("CBC", "📺"), Ch("الحياة", "📺", "قناة الحياة"), Ch("DMC", "📺"), Ch("صدى البلد", "📺"), Ch("النهار", "📺", "قناة النهار"), Ch("TeN", "📺", "قناة TeN")),
        Opt("GULF", "عامة خليجية", "Gulf", "🌴") to listOf(Ch("السعودية الأولى", "🇸🇦", "القناة السعودية الأولى"), Ch("MBC 1", "📺"), Ch("MBC مصر", "📺", "MBC Masr"), Ch("روتانا خليجية", "📺"), Ch("أبوظبي", "🇦🇪", "قناة أبوظبي"), Ch("دبي", "🇦🇪", "تلفزيون دبي"), Ch("تلفزيون الكويت", "🇰🇼"), Ch("تلفزيون قطر", "🇶🇦"), Ch("تلفزيون عُمان", "🇴🇲"), Ch("تلفزيون البحرين", "🇧🇭")),
        Opt("RELIGION", "دينية", "Religious", "🕋") to listOf(Ch("قناة القرآن الكريم (مكة المكرمة)", "🕋", "قناة القرآن الكريم بث مباشر مكة"), Ch("قناة السنة النبوية (المدينة)", "🕌", "قناة السنة النبوية بث مباشر"), Ch("إذاعة القرآن الكريم من القاهرة", "📻", "إذاعة القرآن الكريم من القاهرة"), Ch("قناة المجد", "📖")),
        Opt("KIDS", "أطفال", "Kids", "🧸") to listOf(Ch("سبيستون Spacetoon", "🚀", "Spacetoon"), Ch("MBC3", "🎈"), Ch("ماجد Majid", "📚", "Majid TV"), Ch("براعم", "🌱", "قناة براعم"))
    )
    /** بحث يوتيوب عن البث المباشر فقط للقناة الرسمية */
    fun liveSearch(q: String) = "https://m.youtube.com/results?search_query=" + URLEncoder.encode("$q بث مباشر", "UTF-8") + "&sp=EgJAAQ%3D%3D"

    data class M3u(val name: String, val url: String, val group: String, val logo: String)
    fun parseM3u(text: String): List<M3u> {
        val out = mutableListOf<M3u>()
        var name = ""; var group = ""; var logo = ""
        text.lineSequence().map { it.trim() }.forEach { l ->
            when {
                l.startsWith("#EXTINF", true) -> {
                    name = l.substringAfterLast(",").trim()
                    group = Regex("group-title=\"([^\"]*)\"").find(l)?.groupValues?.get(1) ?: ""
                    logo = Regex("tvg-logo=\"([^\"]*)\"").find(l)?.groupValues?.get(1) ?: ""
                }
                l.isNotBlank() && !l.startsWith("#") -> { out += M3u(name.ifBlank { l.take(40) }, l, group, logo); name = ""; group = ""; logo = "" }
            }
        }
        return out
    }
    fun saved(): List<M3u> = runCatching { JSONArray(Extras.s("m3u_list", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> M3u(o.getString("n"), o.getString("u"), o.optString("g"), o.optString("l")) } } } }.getOrDefault(emptyList())
    fun save(l: List<M3u>) = Extras.ps("m3u_list", JSONArray(l.map { JSONObject().put("n", it.name).put("u", it.url).put("g", it.group).put("l", it.logo) }).toString())
    var favorites: Set<String> get() = Extras.s("ch_favs", "").split("|").filter { it.isNotBlank() }.toSet(); set(v) = Extras.ps("ch_favs", v.joinToString("|"))
}

/** تشغيل قناة: رابط مجاني/من قوائمك داخل المشغل، وإلا البث الرسمي على يوتيوب داخل التطبيق */
suspend fun resolveChannel(keys: List<String>): FreeTv.Ch? = withContext(Dispatchers.IO) { runCatching { FreeTv.find(keys) }.getOrNull() }

@Composable
fun ChannelsTab(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var group by rememberSaveable { mutableStateOf("FREE") }
    var favs by remember { mutableStateOf(Channels.favorites) }
    var tvFavs by remember { mutableStateOf(FreeTv.favs) }
    var mine by remember { mutableStateOf<List<FreeTv.Ch>>(emptyList()) }
    var q by rememberSaveable { mutableStateOf("") }
    var avail by remember { mutableStateOf<Map<String, FreeTv.Ch?>>(emptyMap()) }
    var urlDlg by remember { mutableStateOf(false) }
    var pasteDlg by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var paidDlg by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var src by rememberSaveable { mutableStateOf("ara") }
    var free by remember { mutableStateOf<List<FreeTv.Ch>?>(null) }
    var subGroup by rememberSaveable { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { mine = withContext(Dispatchers.IO) { FreeTv.mine } }
    LaunchedEffect(src, refresh) {
        if (group != "FREE" && refresh == 0) return@LaunchedEffect
        free = null; subGroup = ""
        val s0 = FreeTv.sources.firstOrNull { it.key == src } ?: return@LaunchedEffect
        free = withContext(Dispatchers.IO) { FreeTv.load(s0, force = refresh > 0) }
    }
    LaunchedEffect(group) { if (group == "FREE" && free == null) { val s0 = FreeTv.sources.firstOrNull { it.key == src }; if (s0 != null) free = withContext(Dispatchers.IO) { FreeTv.load(s0) } } }

    fun play(c: FreeTv.Ch) {
        // تشغيل مع بدائل: إن لم يعمل الرابط (محجوب جغرافياً/متوقف) ينتقل المشغل للرابط التالي تلقائياً
        val alts = FreeTv.alternatives(c)
        if (alts.size > 1) {
            MediaTools.queue.clear(); MediaTools.queue.addAll(alts.take(8).map { MediaTools.Track(TeamAr.channel(c.name), it.url) }); MediaTools.queueStart = 0
            nav.openPlayer("queue", TeamAr.channel(c.name))
        } else nav.openPlayer(c.url, TeamAr.channel(c.name))
    }
    fun openNamed(title: String, keys: List<String>, paid: Boolean, ytQuery: String = title) {
        scope.launch {
            busy = true
            val found = resolveChannel(keys)
            busy = false
            when {
                found != null -> nav.openPlayer(found.url, title)
                paid -> paidDlg = title to true
                else -> nav.openWeb(Channels.liveSearch(ytQuery), title)
            }
        }
    }
    val pickM3u = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val n = withContext(Dispatchers.IO) {
                val t = runCatching { ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } }.getOrNull() ?: ""
                FreeTv.importText(t).also { mine = FreeTv.mine }
            }
            busy = false
            if (n == 0) toast(ctx, tr("لم يتم العثور على قنوات في الملف (يجب أن يكون بصيغة M3U)", "No channels found (file must be M3U)")) else { group = "MINE"; toast(ctx, tr("أُضيفت $n قناة ✅", "$n channels added ✅")) }
        }
    }
    fun importUrl(u: String) {
        scope.launch {
            busy = true
            val (n, err) = withContext(Dispatchers.IO) { FreeTv.importUrl(u).also { mine = FreeTv.mine } }
            busy = false
            if (err != null) toast(ctx, err) else { group = "MINE"; toast(ctx, tr("أُضيفت $n قناة ✅", "$n channels added ✅")) }
        }
    }

    val all = Channels.groups.flatMap { it.second }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            HChips {
                FilterChip(group == "FREE", { group = "FREE" }, label = { Text(tr("🆓 قنوات مجانية مباشرة", "🆓 Free live channels")) })
                FilterChip(group == "FAV", { group = "FAV" }, label = { Text(tr("⭐ المفضلة", "⭐ Favorites")) })
                FilterChip(group == "ON", { group = "ON" }, label = { Text(tr("⚽ أون سبورت", "⚽ ON Sport")) })
                FilterChip(group == "BEIN", { group = "BEIN" }, label = { Text(tr("🏆 بي إن سبورت", "🏆 beIN SPORTS")) })
                Channels.groups.forEach { (g, _) -> FilterChip(group == g.key, { group = g.key }, label = { Text(g.emoji + " " + g.label) }) }
                FilterChip(group == "MINE", { group = "MINE" }, label = { Text(tr("📡 قنواتي (M3U)", "📡 My channels (M3U)")) })
            }
        }
        item { SearchField(q) { q = it } }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        when (group) {
            "FREE" -> {
                item {
                    Text(tr("قنوات مفتوحة متاحة للعامة تُشاهد مباشرة داخل التطبيق (من قوائم iptv-org المفتوحة). اختر الدولة أو النوع:", "Publicly available free channels played inside the app (open iptv-org lists). Pick a country or type:"), style = MaterialTheme.typography.bodySmall)
                    HChips { FreeTv.sources.forEach { s0 -> FilterChip(src == s0.key, { src = s0.key }, label = { Text(s0.emoji + " " + s0.label) }) } }
                }
                val l0 = free
                if (l0 == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
                else if (l0.isEmpty()) item {
                    Column { Text(tr("تعذر تحميل القائمة. تحقق من الإنترنت.", "Couldn't load the list. Check your connection."), color = DangerRed); TextButton(onClick = { refresh++ }) { Text(tr("إعادة المحاولة", "Retry")) } }
                } else {
                    val groupsList = l0.groupBy { it.group }.entries.sortedByDescending { it.value.size }.map { it.key }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("${l0.size} قناة", "${l0.size} channels"), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            IconButton(onClick = { refresh++ }) { Icon(Icons.Filled.Refresh, null) }
                        }
                        if (groupsList.size > 1) HChips {
                            FilterChip(subGroup == "", { subGroup = "" }, label = { Text(tr("الكل", "All")) })
                            groupsList.take(25).forEach { g -> FilterChip(subGroup == g, { subGroup = g }, label = { Text(TeamAr.category(g.substringBefore(';'))) }) }
                        }
                    }
                    val l = l0.filter { (subGroup.isBlank() || it.group == subGroup) && (q.isBlank() || it.name.contains(q, true) || it.group.contains(q, true) || TeamAr.channel(it.name).contains(q, true)) }
                    items(l.size) { i ->
                        val c = l[i]
                        TvRow(c, c.url in tvFavs, onFav = { tvFavs = if (c.url in tvFavs) tvFavs - c.url else tvFavs + c.url; FreeTv.favs = tvFavs }) { play(c) }
                    }
                }
                item { Text(tr("بعض القنوات قد تتوقف مؤقتاً من مصدرها؛ جرّب قناة أخرى أو حدّث القائمة.", "Some streams may go offline at the source; try another or refresh."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            "ON", "BEIN" -> {
                val list = if (group == "ON") ArabicMedia.onSport else ArabicMedia.beIn
                if (!Edition.isShared) item {
                    // مصدر خاص بصاحب البرنامج فقط: لا يظهر ولا يُصدَّر في نسخ المشاركة
                    var own by remember { mutableStateOf(FreeTv.ownUrl) }
                    var busyOwn by remember { mutableStateOf(false) }
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(tr("🔑 مصدري الخاص (للنسخة الأصلية فقط)", "🔑 My private source (original copy only)"), fontWeight = FontWeight.Bold)
                            Text(tr("الصق رابط M3U أو رابط بث من اشتراكك الشخصي (مثل باقة IPTV مشترك بها). يُستخدم أولاً لتشغيل القنوات داخل التطبيق، ولا يُنقل لأي نسخة مصدّرة.", "Paste an M3U or stream link from your own subscription. Used first for in-app playback; never copied to exported editions."), style = MaterialTheme.typography.labelSmall)
                            OutlinedTextField(own, { own = it.trim() }, label = { Text(tr("رابط اشتراكي", "My subscription link")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(enabled = !busyOwn, onClick = {
                                    busyOwn = true
                                    scope.launch {
                                        val (n, err) = withContext(Dispatchers.IO) { FreeTv.loadOwn(own) }
                                        busyOwn = false
                                        toast(ctx, err ?: tr("✅ حُفظ مصدرك الخاص ($n قناة)", "✅ Private source saved ($n channels)"))
                                        val m = HashMap<String, FreeTv.Ch?>(); list.forEach { (nm, keys) -> m[nm] = resolveChannel(keys) }; avail = m
                                    }
                                }) { Text(if (busyOwn) "…" else tr("حفظ وتحميل", "Save & load")) }
                                if (FreeTv.ownChannels.isNotEmpty()) Text(tr("📡 ${FreeTv.ownChannels.size} قناة خاصة", "📡 ${FreeTv.ownChannels.size} private channels"), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                item {
                    // فحص توفر كل قناة للتشغيل المباشر داخل التطبيق
                    LaunchedEffect(group, mine.size) {
                        val m = HashMap<String, FreeTv.Ch?>()
                        list.forEach { (n, keys) -> m[n] = resolveChannel(keys) }
                        avail = m
                    }
                }
                item {
                    Text(if (group == "ON") tr("قنوات أون سبورت والمجموعة المتحدة. تُشغّل داخل التطبيق من القوائم المجانية أو من قائمة اشتراكك (قنواتي)، وإلا تُفتح عبر المنصة الرسمية.", "ON Sport & United Media channels. Played in-app from free lists or your subscription list (My channels); otherwise via the official platform.")
                    else tr("قنوات بي إن سبورت مشفرة وتتطلب اشتراكاً رسمياً (beIN CONNECT / TOD). إن أضفت رابط اشتراكك القانوني في «قنواتي» تُشغّل هنا داخل التطبيق.", "beIN SPORTS channels are encrypted and need an official subscription (beIN CONNECT / TOD). Add your legal subscription link in «My channels» to play them in-app."), style = MaterialTheme.typography.bodySmall)
                }
                items(list.filter { q.isBlank() || it.first.contains(q, true) }, key = { it.first }) { (n, keys) ->
                    val ch = avail[n]
                    val checked = avail.containsKey(n)
                    Card(onClick = { if (ch != null) nav.openPlayer(ch.url, TeamAr.channel(n)) else paidDlg = TeamAr.channel(n) to true }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (ch?.logo?.isNotBlank() == true) UrlImage(ch.logo, Modifier.size(44.dp)) else Text(if (group == "ON") "⚽" else "🏆", fontSize = 24.sp)
                            Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 12.dp)) {
                                Text(TeamAr.channel(n), fontWeight = FontWeight.Bold)
                                Text(when { !checked -> tr("⏳ جارٍ الفحص…", "⏳ Checking…"); ch != null -> tr("🟢 متاحة الآن • ▶ تشغيل داخل التطبيق", "🟢 Available • ▶ Play in-app"); else -> tr("🔒 غير متاحة مجاناً الآن • اضغط للخيارات", "🔒 Not free right now • tap for options") },
                                    style = MaterialTheme.typography.labelSmall, color = if (ch != null) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { favs = if (n in favs) favs - n else favs + n; Channels.favorites = favs }) { Icon(if (n in favs) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }
            "MINE" -> {
                item {
                    Text(tr("استورد قائمة قنوات M3U (ملف أو رابط، ويدعم روابط اشتراكات IPTV القانونية ورابط m3u8 لقناة واحدة)؛ تعمل داخل المشغل بالجودة والصوت وملء الشاشة والتسجيل.", "Import an M3U list (file or link — supports legal IPTV subscription links and single m3u8 links); plays in the built-in player."), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { pickM3u.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text(tr("📄 ملف", "📄 File")) }
                        OutlinedButton(onClick = { urlDlg = true }, modifier = Modifier.weight(1f)) { Text(tr("🔗 رابط", "🔗 Link")) }
                        OutlinedButton(onClick = { pasteDlg = true }, modifier = Modifier.weight(1f)) { Text(tr("📋 لصق", "📋 Paste")) }
                    }
                    if (FreeTv.playlistUrls.isNotEmpty() || mine.isNotEmpty()) Row {
                        if (FreeTv.playlistUrls.isNotEmpty()) TextButton(onClick = { FreeTv.playlistUrls.forEach { importUrl(it) } }) { Text(tr("🔄 تحديث القوائم", "🔄 Refresh lists")) }
                        if (mine.isNotEmpty()) TextButton(onClick = { mine = emptyList(); FreeTv.mine = emptyList(); FreeTv.playlistUrls = emptyList() }) { Text(tr("🗑️ حذف الكل", "🗑️ Delete all"), color = DangerRed) }
                    }
                }
                val l = mine.filter { q.isBlank() || it.name.contains(q, true) || it.group.contains(q, true) }
                if (l.isEmpty()) item { Text(tr("لا توجد قنوات بعد", "No channels yet"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(l.size) { i ->
                    val c = l[i]
                    TvRow(c, c.url in tvFavs, onFav = { tvFavs = if (c.url in tvFavs) tvFavs - c.url else tvFavs + c.url; FreeTv.favs = tvFavs },
                        onDelete = { mine = mine.filter { it.url != c.url }; FreeTv.mine = mine }) { play(c) }
                }
            }
            else -> {
                val list = (if (group == "FAV") all.filter { it.name in favs } else Channels.groups.firstOrNull { it.first.key == group }?.second ?: emptyList())
                    .filter { q.isBlank() || it.name.contains(q, true) }.let { if (q.isNotBlank() && group == "FAV") all.filter { c -> c.name.contains(q, true) } else it }
                if (group == "FAV") {
                    val pool = (mine + FreeTv.sources.flatMap { FreeTv.cachedOnly(it.key) }).distinctBy { it.url }.filter { it.url in tvFavs }
                    items(pool.size) { i -> val c = pool[i]; TvRow(c, true, onFav = { tvFavs = tvFavs - c.url; FreeTv.favs = tvFavs }) { play(c) } }
                    val named = (ArabicMedia.onSport + ArabicMedia.beIn).filter { it.first in favs }
                    items(named, key = { "n" + it.first }) { (n, keys) -> Card(onClick = { openNamed(n, keys, paid = n.contains("beIN") && !n.contains("NEWS")) }, modifier = Modifier.fillMaxWidth()) { Text("⭐ " + n, Modifier.padding(14.dp), fontWeight = FontWeight.Bold) } }
                    if (list.isEmpty() && pool.isEmpty() && named.isEmpty()) item { Text(tr("اضغط ⭐ بجانب أي قناة لإضافتها للمفضلة.", "Tap ⭐ next to a channel to add it."), style = MaterialTheme.typography.bodySmall) }
                }
                items(list, key = { it.name }) { c ->
                    Card(onClick = { openNamed(c.name, listOf(c.query, c.name.substringAfterLast(' '), c.name), paid = false, ytQuery = c.query) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(c.emoji, fontSize = 26.sp)
                            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                Text(c.name, fontWeight = FontWeight.Bold)
                                Text(tr("🔴 بث مباشر داخل التطبيق", "🔴 Live in-app"), style = MaterialTheme.typography.labelSmall, color = DangerRed)
                            }
                            IconButton(onClick = { favs = if (c.name in favs) favs - c.name else favs + c.name; Channels.favorites = favs }) { Icon(if (c.name in favs) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
                item { Text(tr("تُشغّل القناة داخل التطبيق من القوائم المجانية إن توفرت، وإلا من بثها الرسمي على يوتيوب داخل التطبيق.", "Channels play in-app from free lists when available, otherwise from their official YouTube live inside the app."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
    if (urlDlg) {
        var u by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { urlDlg = false }, title = { Text(tr("رابط قائمة M3U", "M3U list URL")) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(u, { u = it.trim() }, label = { Text("http://… .m3u / .m3u8") }, modifier = Modifier.fillMaxWidth())
                Text(tr("مثال: رابط اشتراكك (get.php?username=…&type=m3u_plus) أو رابط قائمة مفتوحة.", "e.g. your subscription link (get.php?username=…&type=m3u_plus) or an open list."), style = MaterialTheme.typography.labelSmall)
                TextButton(onClick = { u = "https://iptv-org.github.io/iptv/languages/ara.m3u" }) { Text(tr("استخدم قائمة القنوات العربية المجانية", "Use the free Arabic channels list")) }
            }
        }, confirmButton = { TextButton(onClick = { urlDlg = false; importUrl(u) }) { Text(tr("استيراد", "Import")) } },
            dismissButton = { TextButton(onClick = { urlDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
    if (pasteDlg) {
        var t by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { pasteDlg = false }, title = { Text(tr("لصق محتوى M3U", "Paste M3U content")) }, text = {
            OutlinedTextField(t, { t = it }, minLines = 5, maxLines = 10, modifier = Modifier.fillMaxWidth(), label = { Text("#EXTM3U …") })
        }, confirmButton = { TextButton(onClick = {
            pasteDlg = false
            val n = FreeTv.importText(t); mine = FreeTv.mine
            if (n == 0) { if (t.trim().startsWith("http")) importUrl(t.trim()) else toast(ctx, tr("لم يتم العثور على قنوات", "No channels found")) } else { group = "MINE"; toast(ctx, tr("أُضيفت $n قناة ✅", "$n channels added ✅")) }
        }) { Text(tr("إضافة", "Add")) } }, dismissButton = { TextButton(onClick = { pasteDlg = false }) { Text(tr("إلغاء", "Cancel")) } })
    }
    paidDlg?.let { (n, _) ->
        AlertDialog(onDismissRequest = { paidDlg = null }, title = { Text(n) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(tr("هذه القناة مشفرة ولا تتوفر في القوائم المجانية. شاهدها عبر اشتراكك الرسمي، أو أضف رابط اشتراكك القانوني (M3U) في «قنواتي» لتعمل هنا داخل التطبيق.", "This channel is encrypted and not in free lists. Watch via your official subscription, or add your legal subscription link (M3U) in «My channels» to play it here."), style = MaterialTheme.typography.bodySmall)
                Football.platforms.filter { it.name.contains("beIN") || it.name.contains("TOD") || it.name.contains("Watch") }.forEach { p ->
                    OutlinedButton(onClick = { paidDlg = null; val i = ctx.packageManager.getLaunchIntentForPackage(p.pkg); if (i != null) ctx.startActivity(i) else nav.openWeb(p.url, p.name) }, modifier = Modifier.fillMaxWidth()) { Text(p.name) }
                }
                OutlinedButton(onClick = { paidDlg = null; group = "MINE"; urlDlg = true }, modifier = Modifier.fillMaxWidth()) { Text(tr("➕ إضافة رابط اشتراكي", "➕ Add my subscription link")) }
                TextButton(onClick = { paidDlg = null; nav.openWeb(Channels.liveSearch(n), n) }) { Text(tr("🔴 البحث عن بث رسمي مجاني على يوتيوب", "🔴 Look for an official free stream on YouTube")) }
            }
        }, confirmButton = { TextButton(onClick = { paidDlg = null }) { Text(tr("إغلاق", "Close")) } })
    }
}

@Composable
private fun TvRow(c: FreeTv.Ch, fav: Boolean, onFav: () -> Unit, onDelete: (() -> Unit)? = null, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (c.logo.isNotBlank()) UrlImage(c.logo, Modifier.size(40.dp)) else Text("📡", fontSize = 26.sp)
            Column(Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 8.dp)) {
                val ar = TeamAr.channel(c.name)
                Text(ar, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (FreeTv.isGeoBlocked(c)) Text(tr("🌍 محجوبة جغرافياً في بعض الدول • يُجرَّب رابط بديل تلقائياً", "🌍 Geo-blocked in some countries • alternatives tried automatically"), style = MaterialTheme.typography.labelSmall, color = WarnAmber)
                Text(listOf(if (ar != c.name) c.name.replace(Regex("\\[(.*?)]"), "").trim() else "", TeamAr.category(c.group)).filter { it.isNotBlank() }.joinToString(" • "), style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onFav) { Icon(if (fav) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = MaterialTheme.colorScheme.primary) }
            if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
        }
    }
}

/** المحتوى العربي: أفلام ومسلسلات مصرية، رمضان، التركي المدبلج، والكرتون العربي */
@Composable
fun ArabicTab(nav: NavController, initial: String = "eg_movies") {
    val ctx = LocalContext.current
    var key by rememberSaveable(initial) { mutableStateOf(initial) }
    val cat = ArabicMedia.cat(key) ?: ArabicMedia.cats.first()
    var q by rememberSaveable { mutableStateOf("") }
    var live by remember { mutableStateOf<List<FreeTv.Ch>?>(null) }
    var ia by remember { mutableStateOf<List<MediaLib.Item>>(emptyList()) }
    var openIa by remember { mutableStateOf<MediaLib.Item?>(null) }
    var ramYear by rememberSaveable { mutableIntStateOf(2025) }
    LaunchedEffect(key) {
        live = null; ia = emptyList()
        live = withContext(Dispatchers.IO) {
            val pool = FreeTv.load(FreeTv.sources.first { it.key == "ara" }) + if (key == "cartoon") FreeTv.cachedOnly("kids").filter { it.group.contains("Arab", true) } else emptyList()
            pool.filter { c -> cat.tvGroups.any { g -> c.group.contains(g, true) || c.name.contains(g, true) } }.distinctBy { it.url }.take(40)
        }
        if (cat.iaQuery.isNotBlank()) ia = withContext(Dispatchers.IO) { MediaLib.search(cat.iaQuery, "", openOnly = true) }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { HChips { ArabicMedia.cats.forEach { c -> FilterChip(key == c.key, { key = c.key }, label = { Text(c.emoji + " " + c.label) }) } } }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(q, { q = it }, label = { Text(tr("ابحث عن ", "Search ") + cat.label) }, singleLine = true, modifier = Modifier.weight(1f), trailingIcon = { MicButton { q = it } })
                IconButton(onClick = { if (q.isNotBlank()) nav.openWeb(ArabicMedia.ytLong(q.trim() + " " + cat.suffix), q) }) { Icon(Icons.Filled.Search, null) }
            }
        }
        item {
            Text(tr("📺 القنوات والقوائم الرسمية", "📺 Official channels & playlists"), fontWeight = FontWeight.Bold)
            HChips { cat.channels.forEach { (n, query) -> AssistChip({ nav.openWeb(ArabicMedia.ytPlaylist(query), n) }, label = { Text(n) }) } }
        }
        val lv = live
        item { Text(tr("📡 بث مباشر مجاني داخل التطبيق", "📡 Free live channels in-app"), fontWeight = FontWeight.Bold) }
        if (lv == null) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        else if (lv.isEmpty()) item { Text(tr("لا توجد قنوات مجانية لهذا القسم حالياً", "No free channels for this section now"), style = MaterialTheme.typography.bodySmall) }
        else item {
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(lv, key = { it.url }) { c ->
                    Card(onClick = { nav.openPlayer(c.url, TeamAr.channel(c.name)) }, modifier = Modifier.width(120.dp)) {
                        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            if (c.logo.isNotBlank()) UrlImage(c.logo, Modifier.size(56.dp)) else Text("📺", fontSize = 36.sp)
                            Text(TeamAr.channel(c.name), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
        if (key == "ramadan") {
            item {
                Text(tr("🌙 مسلسلات رمضان حسب السنة", "🌙 Ramadan series by year"), fontWeight = FontWeight.Bold)
                HChips { (2026 downTo 2016).forEach { y -> FilterChip(ramYear == y, { ramYear = y }, label = { Text("$y") }) } }
                OutlinedButton(onClick = { nav.openWeb(ArabicMedia.ytPlaylist("مسلسلات رمضان $ramYear"), tr("مسلسلات رمضان ", "Ramadan series ") + ramYear) }, modifier = Modifier.fillMaxWidth()) {
                    Text(tr("🔎 كل مسلسلات رمضان $ramYear", "🔎 All Ramadan $ramYear series"))
                }
            }
            items(ArabicMedia.ramadanByYear[ramYear].orEmpty(), key = { "r$ramYear$it" }) { t ->
                Card(onClick = { nav.openWeb(ArabicMedia.ytPlaylist("مسلسل $t رمضان $ramYear الحلقة"), t) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🌙", fontSize = 22.sp)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 10.dp)) {
                            Text(t, fontWeight = FontWeight.SemiBold)
                            Text(tr("رمضان $ramYear • الحلقات من القناة الرسمية", "Ramadan $ramYear • episodes from the official channel"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { nav.openWeb(MediaLib.whereToWatch(t), tr("أين أشاهده؟", "Where to watch")) }) { Icon(Icons.Filled.TravelExplore, null) }
                    }
                }
            }
        }
        if (key != "ramadan") item { Text(tr("⭐ الأشهر", "⭐ Popular"), fontWeight = FontWeight.Bold) }
        if (key != "ramadan") items(cat.titles, key = { it }) { t ->
            Card(onClick = { nav.openWeb(if (key == "ramadan") ArabicMedia.ytPlaylist(t) else ArabicMedia.ytPlaylist(t + " " + cat.suffix), t) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(cat.emoji, fontSize = 22.sp)
                    Text(t, Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 12.dp), fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { nav.openWeb(MediaLib.whereToWatch(t), tr("أين أشاهده؟", "Where to watch")) }) { Icon(Icons.Filled.TravelExplore, null) }
                }
            }
        }
        if (ia.isNotEmpty()) {
            item {
                Text(tr("🎞️ أعمال مفتوحة الترخيص: مشاهدة داخل التطبيق وتنزيل", "🎞️ Openly licensed works: watch in-app & download"), fontWeight = FontWeight.Bold)
                Text(tr("من أرشيف الإنترنت، ملكية عامة أو رخصة المشاع الإبداعي فقط. اضغط العمل ← ▶ للمشاهدة أو ⬇️ للتنزيل (وتنزيل الكل للمسلسلات).", "From Internet Archive, public-domain or Creative Commons only. Tap ← ▶ to watch or ⬇️ to download (Download all for series)."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(ia.take(20), key = { "ia" + it.id }) { m ->
                Card(onClick = { openIa = m }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        UrlImage(m.thumb, Modifier.size(width = 80.dp, height = 54.dp)); Spacer(Modifier.width(8.dp))
                        Text(m.title, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        item {
            Text(tr("🎟️ المنصات الرسمية", "🎟️ Official platforms"), fontWeight = FontWeight.Bold)
            HChips {
                ArabicMedia.platforms.forEach { p ->
                    AssistChip({ val i = ctx.packageManager.getLaunchIntentForPackage(p.pkg); if (i != null) ctx.startActivity(i) else nav.openWeb(p.url, p.name) }, label = { Text(p.name) })
                }
            }
            Text(tr("نعرض المحتوى من القنوات والمنصات الرسمية والمصادر المفتوحة فقط، ويُشغّل داخل التطبيق.", "Content comes from official channels/platforms and open sources only, played inside the app."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    openIa?.let { m ->
        var files by remember(m.id) { mutableStateOf<List<MediaLib.FileOpt>?>(null) }
        LaunchedEffect(m.id) { files = withContext(Dispatchers.IO) { MediaLib.files(m.id) } }
        AlertDialog(onDismissRequest = { openIa = null }, title = { Text(m.title) }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val f = files
                if (f == null) CircularProgressIndicator() else if (f.isEmpty()) Text(tr("لا توجد ملفات قابلة للتشغيل", "No playable files"))
                else Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    // ملف واحد لكل حلقة (أفضل صيغة)
                    val eps = f.groupBy { it.name.substringBeforeLast('.').substringBeforeLast(".ia").removeSuffix("_512kb").lowercase() }.values.map { g -> g.first() }.sortedBy { it.name }
                    if (eps.size > 1) Button(onClick = {
                        var n = 0; eps.forEachIndexed { k, x -> if (MediaLib.download(ctx, x.url, m.title + " - " + (k + 1))) n++ }
                        toast(ctx, tr("⬇️ بدأ تنزيل $n ملف", "⬇️ Downloading $n files"))
                    }, modifier = Modifier.fillMaxWidth()) { Text(tr("⬇️ تنزيل الكل (${eps.size})", "⬇️ Download all (${eps.size})")) }
                    eps.forEachIndexed { i, x ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { openIa = null; nav.openPlayer(x.url, m.title + if (eps.size > 1) " - ${i + 1}" else "") }, modifier = Modifier.weight(1f)) { Text((if (eps.size > 1) tr("▶ حلقة ${i + 1}", "▶ Part ${i + 1}") else tr("▶ تشغيل", "▶ Play")) + " • " + x.label, maxLines = 1) }
                        IconButton(onClick = { toast(ctx, if (MediaLib.download(ctx, x.url, m.title + if (eps.size > 1) " - ${i + 1}" else "")) tr("⬇️ بدأ التنزيل", "⬇️ Downloading") else tr("لا يمكن تنزيله", "Can't download")) }) { Icon(Icons.Filled.Download, null) }
                    }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { openIa = null }) { Text(tr("إغلاق", "Close")) } })
    }
}
