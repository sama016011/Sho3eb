package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate

/** نموذج كشف موحّد يُستخدم لرابط المشاركة وتصدير Excel */
data class RTable(
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>,
    /** حالة كل صف: 1 مدفوع، 2 متأخر، 3 جزئي، null عادي */
    val status: List<Int?>? = null
)

data class ReportDoc(
    val title: String,
    val subtitle: String,
    val info: List<Pair<String, String>>,
    val tables: List<RTable>,
    val totals: List<Pair<String, String>> = emptyList(),
    val notes: String = "",
    val fileName: String = "report"
)

object Docs {
    private val today get() = LocalDate.now()

    fun member(a: Association, member: AssocMember, members: List<AssocMember>, people: Map<Long, Person>, payments: List<AssocPayment>, payouts: List<AssocPayout>): ReportDoc {
        val rounds = associationRounds(a, members, payments, payouts)
        val p = people[member.personId]
        val myTurn = rounds.firstOrNull { it.recipient.id == member.id }
        val paidTotal = payments.filter { it.memberId == member.id }.sumOf { it.amount }
        return ReportDoc(
            tr("كشف حساب عضو في جمعية", "Association member statement"), a.name,
            listOf(
                tr("الاسم", "Name") to (p?.name ?: "-"),
                tr("الجمعية", "Association") to a.name,
                tr("قيمة السهم", "Share") to Fmt.money(a.shareAmount),
                tr("المدة", "Period") to Fmt.periodLabel(a.periodType, a.periodCount),
                tr("عدد الأعضاء", "Members") to "${members.size}",
                tr("دورك في الاستلام", "Your turn") to (myTurn?.let { "${it.round + 1} • ${Fmt.date(it.due)}" } ?: "-"),
                tr("قيمة القبضة", "Payout") to Fmt.money(a.shareAmount * members.size),
                tr("حالة الاستلام", "Received") to (myTurn?.payout?.let { tr("تم ", "Yes ") + Fmt.date(it.date) } ?: tr("لم يتم", "Not yet"))
            ),
            listOf(
                RTable(
                    tr("الدفعات", "Payments"),
                    listOf("#", tr("الموعد", "Due"), tr("المستلم", "Recipient"), tr("المبلغ", "Amount"), tr("الحالة", "Status"), tr("تاريخ الدفع", "Paid on")),
                    rounds.map { r ->
                        val pay = payments.firstOrNull { it.memberId == member.id && it.round == r.round }
                        listOf(
                            "${r.round + 1}", Fmt.date(r.due), people[r.recipient.personId]?.name ?: "-", Fmt.num(a.shareAmount),
                            when { pay != null -> tr("مدفوع", "Paid"); r.due.isBefore(today) -> tr("متأخر", "Late"); else -> tr("قادم", "Upcoming") },
                            pay?.let { Fmt.date(it.date) } ?: "-"
                        )
                    },
                    rounds.map { r ->
                        val paid = payments.any { it.memberId == member.id && it.round == r.round }
                        if (paid) 1 else if (r.due.isBefore(today)) 2 else null
                    }
                )
            ),
            listOf(
                tr("إجمالي المدفوع", "Total paid") to Fmt.money(paidTotal),
                tr("المتبقي", "Remaining") to Fmt.money((a.shareAmount * rounds.size - paidTotal).coerceAtLeast(0.0))
            ),
            a.notes, (p?.name ?: "member") + "_" + a.name
        )
    }

    fun association(a: Association, members: List<AssocMember>, people: Map<Long, Person>, payments: List<AssocPayment>, payouts: List<AssocPayout>): ReportDoc {
        val rounds = associationRounds(a, members, payments, payouts)
        return ReportDoc(
            tr("كشف جمعية", "Association statement"), a.name,
            listOf(
                tr("الجمعية", "Association") to a.name,
                tr("قيمة السهم", "Share") to Fmt.money(a.shareAmount),
                tr("المدة", "Period") to Fmt.periodLabel(a.periodType, a.periodCount),
                tr("عدد الأعضاء", "Members") to "${members.size}",
                tr("قيمة القبضة", "Payout") to Fmt.money(a.shareAmount * members.size)
            ),
            listOf(
                RTable(
                    tr("الدورات", "Rounds"),
                    listOf("#", tr("الموعد", "Due"), tr("المستلم", "Recipient"), tr("المحصّل", "Collected"), tr("دفعوا", "Paid"), tr("التسليم", "Delivered")),
                    rounds.map { r ->
                        listOf(
                            "${r.round + 1}", Fmt.date(r.due), people[r.recipient.personId]?.name ?: "-", Fmt.num(r.collected),
                            "${r.paidMemberIds.size}/${members.size}", r.payout?.let { Fmt.date(it.date) } ?: "-"
                        )
                    },
                    rounds.map { r -> if (r.payout != null) 1 else if (r.due.isBefore(today) && r.paidMemberIds.size < members.size) 2 else null }
                ),
                RTable(
                    tr("الأعضاء", "Members"),
                    listOf("#", tr("الاسم", "Name"), tr("الجوال", "Phone"), tr("المدفوع", "Paid")),
                    members.sortedBy { it.turnOrder }.mapIndexed { i, m ->
                        val p = people[m.personId]
                        listOf("${i + 1}", p?.name ?: "-", p?.phone ?: "", Fmt.num(payments.filter { it.memberId == m.id }.sumOf { it.amount }))
                    }
                )
            ),
            listOf(tr("إجمالي المحصّل", "Total collected") to Fmt.money(payments.sumOf { it.amount })),
            a.notes, a.name
        )
    }

    fun loan(person: Person, txs: List<LoanTx>): ReportDoc {
        val taken = txs.filter { it.type == LoanTx.LOAN }.sumOf { it.amount }
        val paid = txs.filter { it.type == LoanTx.PAY }.sumOf { it.amount }
        var bal = 0.0
        val sorted = txs.sortedWith(compareBy<LoanTx>({ it.date }, { it.id }))
        return ReportDoc(
            tr("كشف حساب سلفة", "Loan statement"), person.name,
            listOf(
                tr("الاسم", "Name") to person.name,
                tr("إجمالي السلف", "Total borrowed") to Fmt.money(taken),
                tr("إجمالي المسدد", "Total repaid") to Fmt.money(paid),
                tr("الرصيد المتبقي", "Balance") to Fmt.money(taken - paid)
            ),
            listOf(
                RTable(
                    tr("الحركات", "Transactions"),
                    listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("سلفة", "Loan"), tr("سداد", "Paid"), tr("الرصيد", "Balance"), tr("ملاحظات", "Notes")),
                    sorted.map { t ->
                        bal += if (t.type == LoanTx.LOAN) t.amount else -t.amount
                        listOf(
                            Fmt.date(t.date), if (t.type == LoanTx.LOAN) tr("سلفة", "Loan") else tr("سداد", "Repayment"),
                            if (t.type == LoanTx.LOAN) Fmt.num(t.amount) else "", if (t.type == LoanTx.PAY) Fmt.num(t.amount) else "",
                            Fmt.num(bal), t.note
                        )
                    },
                    sorted.map { if (it.type == LoanTx.PAY) 1 else null }
                )
            ),
            listOf(tr("الرصيد المتبقي", "Outstanding balance") to Fmt.money(taken - paid)),
            "", "loan_" + person.name
        )
    }

    fun sale(s: Sale, person: Person?, payments: List<SalePayment>): ReportDoc {
        val sch = saleSchedule(s, payments)
        val paid = payments.sumOf { it.amount }
        return ReportDoc(
            tr("كشف بيع بالتقسيط", "Installment sale statement"), s.product,
            listOf(
                tr("العميل", "Customer") to (person?.name ?: "-"),
                tr("المنتج", "Product") to s.product,
                tr("السعر الإجمالي", "Total price") to Fmt.money(s.totalPrice),
                tr("الدفعة المقدمة", "Down payment") to Fmt.money(s.downPayment),
                tr("عدد الأقساط", "Installments") to "${s.installmentsCount} • ${Fmt.periodLabel(s.periodType, s.periodCount)}",
                tr("قيمة القسط", "Installment") to Fmt.money(installmentAmount(s)),
                tr("المتبقي", "Remaining") to Fmt.money(saleRemaining(s, payments))
            ),
            listOf(
                RTable(
                    tr("جدول الأقساط", "Schedule"),
                    listOf("#", tr("الاستحقاق", "Due"), tr("القسط", "Amount"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"), tr("الحالة", "Status")),
                    sch.map { i ->
                        listOf(
                            "${i.index + 1}", Fmt.date(i.due), Fmt.num(i.amount), Fmt.num(i.paid), Fmt.num(i.remaining),
                            when { i.isPaid -> tr("مدفوع", "Paid"); i.paid > 0 -> tr("جزئي", "Partial"); i.due.isBefore(today) -> tr("متأخر", "Late"); else -> tr("قادم", "Upcoming") }
                        )
                    },
                    sch.map { i -> when { i.isPaid -> 1; i.paid > 0 -> 3; i.due.isBefore(today) -> 2; else -> null } }
                ),
                RTable(
                    tr("سجل الدفعات", "Payments"),
                    listOf(tr("التاريخ", "Date"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    payments.sortedBy { it.date }.map { listOf(Fmt.date(it.date), Fmt.num(it.amount), it.note) }
                )
            ),
            listOf(
                tr("إجمالي المدفوع (مع المقدم)", "Total paid (incl. down)") to Fmt.money(paid + s.downPayment),
                tr("المتبقي", "Remaining") to Fmt.money(saleRemaining(s, payments))
            ),
            s.notes, s.product + "_" + (person?.name ?: "")
        )
    }

    fun account(a: Account, person: Person?, txs: List<AccountTx>, from: Long? = null, to: Long? = null): ReportDoc {
        val lines = accountLines(txs).filter { (from == null || it.tx.date >= from) && (to == null || it.tx.date <= to) }
        return ReportDoc(
            tr("كشف حساب", "Account statement"), a.name,
            listOf(
                tr("الحساب", "Account") to a.name,
                tr("صاحب الحساب", "Owner") to (person?.name ?: "-"),
                tr("الفترة", "Period") to (if (from != null || to != null) (from?.let { Fmt.date(it) } ?: "…") + " ← " + (to?.let { Fmt.date(it) } ?: "…") else tr("كامل", "All")),
                tr("الرصيد الحالي", "Current balance") to Fmt.money(accountBalance(txs))
            ),
            listOf(
                RTable(
                    tr("الحركات", "Transactions"),
                    listOf(tr("التاريخ", "Date"), tr("إضافة", "In"), tr("صرف", "Out"), tr("الرصيد", "Balance"), tr("ملاحظات", "Notes")),
                    lines.map { l ->
                        listOf(
                            Fmt.date(l.tx.date), if (l.tx.type == AccountTx.IN) Fmt.num(l.tx.amount) else "",
                            if (l.tx.type == AccountTx.OUT) Fmt.num(l.tx.amount) else "", Fmt.num(l.after), l.tx.note
                        )
                    },
                    lines.map { if (it.tx.type == AccountTx.IN) 1 else null }
                )
            ),
            listOf(
                tr("إجمالي الإضافات", "Total in") to Fmt.money(lines.filter { it.tx.type == AccountTx.IN }.sumOf { it.tx.amount }),
                tr("إجمالي الصرف", "Total out") to Fmt.money(lines.filter { it.tx.type == AccountTx.OUT }.sumOf { it.tx.amount }),
                tr("الرصيد", "Balance") to Fmt.money(lines.lastOrNull()?.after ?: 0.0)
            ),
            "", "account_" + a.name
        )
    }

    fun livingEntries(title: String, subtitle: String, entries: List<LivEntry>, periods: Map<Long, String>, info: List<Pair<String, String>>): ReportDoc {
        val sorted = entries.sortedBy { it.date }
        val ti = entries.filter { it.kind == Living.INCOME }.sumOf { it.amount }
        val te = entries.filter { it.kind == Living.EXPENSE }.sumOf { it.amount }
        val byCat = entries.groupBy { it.kind to it.category }.map { (k, l) -> k to l.sumOf { it.amount } }.sortedWith(compareBy({ it.first.first != Living.INCOME }, { -it.second }))
        return ReportDoc(
            title, subtitle, info,
            listOf(
                RTable(
                    tr("بيان الحركات", "Statement"),
                    listOf(tr("التاريخ", "Date"), tr("البيان", "Item"), tr("النوع", "Type"), tr("الفئة", "Category"), tr("البند", "Period"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    sorted.map { e ->
                        listOf(
                            Fmt.date(e.date), e.name, if (e.kind == Living.INCOME) tr("دخل", "Income") else tr("مصروف", "Expense"),
                            Living.cat(e.kind, e.category).label, periods[e.periodId] ?: "", Fmt.num(e.amount), e.note
                        )
                    },
                    sorted.map { if (it.kind == Living.INCOME) 1 else null }
                ),
                RTable(
                    tr("حسب الفئة", "By category"),
                    listOf(tr("النوع", "Type"), tr("الفئة", "Category"), tr("المبلغ", "Amount")),
                    byCat.map { (k, v) -> listOf(if (k.first == Living.INCOME) tr("دخل", "Income") else tr("مصروف", "Expense"), Living.cat(k.first, k.second).label, Fmt.num(v)) }
                )
            ),
            listOf(
                tr("إجمالي الدخل", "Total income") to Fmt.money(ti),
                tr("إجمالي المصروفات", "Total expenses") to Fmt.money(te),
                tr("الصافي", "Net") to Fmt.money(ti - te)
            ),
            "", "living_" + subtitle
        )
    }

    fun livingPeriod(p: LivPeriod, entries: List<LivEntry>) = livingEntries(
        tr("كشف مصاريف المعيشة", "Living expenses"), p.name, entries, mapOf(p.id to p.name),
        listOf(tr("الفترة", "Period") to (Fmt.date(p.startDate) + " ← " + Fmt.date(p.endDate)), tr("عدد الأيام", "Days") to "${Living.days(p)}")
    )

    // ---------------- العقارات والإيجارات ----------------
    fun lease(l: Lease, unit: PropUnit?, prop: Property?, tenant: Person?, payments: List<LeasePayment>): ReportDoc {
        val sch = Rent.schedule(l, payments)
        val pays = payments.filter { it.leaseId == l.id }.sortedBy { it.date }
        val paid = pays.sumOf { it.amount }
        val total = sch.sumOf { it.amount }
        val overdue = sch.filter { !it.isPaid && !it.due.isAfter(today) }.sumOf { it.remaining }
        return ReportDoc(
            tr("كشف حساب مستأجر", "Tenant statement"), (prop?.name ?: "") + (unit?.let { " - " + it.name } ?: ""),
            listOf(
                tr("المستأجر", "Tenant") to (tenant?.name ?: "-"),
                tr("العقار", "Property") to (prop?.name ?: "-"),
                tr("الوحدة", "Unit") to (unit?.name ?: "-"),
                tr("مدة العقد", "Lease term") to (Fmt.date(l.startDate) + " ← " + Fmt.date(l.endDate)),
                tr("قيمة الدفعة", "Payment") to (Fmt.money(l.rentAmount) + " • " + Rent.periodName(l.periodMonths)),
                tr("التأمين", "Deposit") to Fmt.money(l.deposit),
                tr("إجمالي العقد", "Lease total") to Fmt.money(total),
                tr("المتأخر", "Overdue") to Fmt.money(overdue)
            ),
            listOf(
                RTable(
                    tr("جدول الدفعات", "Payment schedule"),
                    listOf("#", tr("الاستحقاق", "Due"), tr("المبلغ", "Amount"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"), tr("الحالة", "Status")),
                    sch.map { d ->
                        listOf("${d.index + 1}", Fmt.date(d.due), Fmt.num(d.amount), Fmt.num(d.paid), Fmt.num(d.remaining),
                            when { d.isPaid -> tr("مدفوع", "Paid"); d.paid > 0 -> tr("جزئي", "Partial"); d.due.isBefore(today) -> tr("متأخر", "Late"); else -> tr("قادم", "Upcoming") })
                    },
                    sch.map { d -> when { d.isPaid -> 1; d.paid > 0 -> 3; d.due.isBefore(today) -> 2; else -> null } }
                ),
                RTable(
                    tr("سجل الدفعات", "Payments"),
                    listOf(tr("التاريخ", "Date"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    pays.map { listOf(Fmt.date(it.date), Fmt.num(it.amount), it.note) }
                )
            ),
            listOf(
                tr("إجمالي المدفوع", "Total paid") to Fmt.money(paid),
                tr("المتبقي من العقد", "Remaining on lease") to Fmt.money((total - paid).coerceAtLeast(0.0))
            ),
            l.notes, "lease_" + (tenant?.name ?: "")
        )
    }

    fun property(p: Property, units: List<PropUnit>, leases: List<Lease>, payments: List<LeasePayment>, expenses: List<PropExpense>, people: Map<Long, Person>, range: LongRange? = null): ReportDoc {
        val us = units.filter { it.propertyId == p.id }
        val st = Rent.stats(p.id, units, leases, payments, expenses, range)
        val uids = us.map { it.id }.toSet()
        val ls = leases.filter { it.unitId in uids }
        val lids = ls.map { it.id }.toSet()
        val um = us.associateBy { it.id }
        val lm = ls.associateBy { it.id }
        val pays = payments.filter { it.leaseId in lids && (range == null || it.date in range) }.sortedBy { it.date }
        val exps = expenses.filter { it.propertyId == p.id && (range == null || it.date in range) }.sortedBy { it.date }
        return ReportDoc(
            tr("تقرير عقار", "Property report"), p.name,
            listOf(
                tr("العقار", "Property") to (Rent.propType(p.type).label + " • " + p.name),
                tr("العنوان", "Address") to p.address.ifBlank { "-" },
                tr("الفترة", "Period") to (range?.let { Fmt.date(it.first) + " ← " + Fmt.date(it.last) } ?: tr("كامل", "All")),
                tr("الوحدات", "Units") to "${st.units}",
                tr("المؤجّر منها", "Occupied") to "${st.occupied} (${st.occupancy}%)",
                tr("الإيجار الشهري المتوقع", "Expected monthly rent") to Fmt.money(st.monthlyRent),
                tr("المتأخرات", "Overdue") to Fmt.money(st.overdue)
            ),
            listOf(
                RTable(
                    tr("الوحدات والمستأجرون", "Units & tenants"),
                    listOf(tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("الإيجار", "Rent"), tr("نهاية العقد", "Ends"), tr("المتأخر", "Overdue")),
                    us.map { u ->
                        val l = ls.firstOrNull { it.unitId == u.id && Rent.isCurrent(it) }
                        listOf(u.name, l?.let { people[it.tenantId]?.name } ?: tr("شاغرة", "Vacant"), l?.let { Fmt.num(it.rentAmount) + " / " + Rent.periodName(it.periodMonths) } ?: "-",
                            l?.let { Fmt.date(it.endDate) } ?: "-", l?.let { Fmt.num(Rent.overdue(it, payments).sumOf { d -> d.remaining }) } ?: "-")
                    },
                    us.map { u -> val l = ls.firstOrNull { it.unitId == u.id && Rent.isCurrent(it) }; if (l == null) null else if (Rent.overdue(l, payments).isNotEmpty()) 2 else 1 }
                ),
                RTable(
                    tr("الإيرادات (دفعات الإيجار)", "Income (rent payments)"),
                    listOf(tr("التاريخ", "Date"), tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    pays.map { x -> val l = lm[x.leaseId]; listOf(Fmt.date(x.date), um[l?.unitId]?.name ?: "-", people[l?.tenantId]?.name ?: "-", Fmt.num(x.amount), x.note) }
                ),
                RTable(
                    tr("المصروفات", "Expenses"),
                    listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("الوحدة", "Unit"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    exps.map { e -> listOf(Fmt.date(e.date), Rent.expCat(e.category).label, e.unitId?.let { um[it]?.name } ?: "-", Fmt.num(e.amount), e.note) }
                )
            ),
            listOf(
                tr("إجمالي الإيرادات", "Total income") to Fmt.money(st.collected),
                tr("إجمالي المصروفات", "Total expenses") to Fmt.money(st.expenses),
                tr("صافي الربح", "Net profit") to Fmt.money(st.net)
            ),
            p.notes, "property_" + p.name
        )
    }

    // ---------------- ديوني ----------------
    fun debt(d: Debt, txs: List<DebtTx>): ReportDoc {
        val list = txs.filter { it.debtId == d.id }.sortedWith(compareBy({ it.date }, { it.id }))
        var bal = 0.0
        val nd = Debts.nextDue(d, txs)
        return ReportDoc(
            tr("كشف دين", "Debt statement"), d.creditor,
            listOf(
                tr("الدائن", "Creditor") to d.creditor,
                tr("النوع", "Type") to Debts.type(d.type).label,
                tr("إجمالي الدين", "Total borrowed") to Fmt.money(Debts.borrowed(d, txs)),
                tr("المسدد", "Paid") to Fmt.money(Debts.paid(d, txs)),
                tr("المتبقي", "Remaining") to Fmt.money(Debts.balance(d, txs)),
                tr("القسط", "Installment") to (if (d.installment > 0) Fmt.money(d.installment) + " • " + Rent.periodName(d.periodMonths) else "-"),
                tr("الاستحقاق القادم", "Next due") to (nd?.let { Fmt.date(it) } ?: "-")
            ),
            listOf(
                RTable(
                    tr("الحركات", "Transactions"),
                    listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("زيادة", "Borrowed"), tr("سداد", "Paid"), tr("المتبقي", "Balance"), tr("ملاحظات", "Notes")),
                    list.map { t ->
                        bal += if (t.type == DebtTx.BORROW) t.amount else -t.amount
                        listOf(Fmt.date(t.date), if (t.type == DebtTx.BORROW) tr("استدانة", "Borrow") else tr("سداد", "Payment"),
                            if (t.type == DebtTx.BORROW) Fmt.num(t.amount) else "", if (t.type == DebtTx.PAY) Fmt.num(t.amount) else "", Fmt.num(bal), t.note)
                    },
                    list.map { if (it.type == DebtTx.PAY) 1 else null }
                )
            ),
            listOf(tr("المتبقي عليّ", "Remaining I owe") to Fmt.money(Debts.balance(d, txs))),
            d.notes, "debt_" + d.creditor
        )
    }
}
