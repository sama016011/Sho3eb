package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate

/** نموذج كشف موحّد يُستخدم لرابط المشاركة وتصدير Excel */
data class RTable(
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>,
    /** حالة كل صف: 1 مدفوع، 2 متأخر، 3 جزئي، null عادي */
    val status: List<Int?>? = null
)

data class ReportDoc(
    val title: String,
    val subtitle: String,
    val info: List<Pair<String, String>>,
    val tables: List<RTable>,
    val totals: List<Pair<String, String>> = emptyList(),
    val notes: String = "",
    val fileName: String = "report"
)

object Docs {
    private val today get() = LocalDate.now()

    fun member(a: Association, member: AssocMember, members: List<AssocMember>, people: Map<Long, Person>, payments: List<AssocPayment>, payouts: List<AssocPayout>): ReportDoc {
        val rounds = associationRounds(a, members, payments, payouts)
        val p = people[member.personId]
        val myTurn = rounds.firstOrNull { it.recipient.id == member.id }
        val paidTotal = payments.filter { it.memberId == member.id }.sumOf { it.amount }
        return ReportDoc(
            tr("كشف حساب عضو في جمعية", "Association member statement"), a.name,
            listOf(
                tr("الاسم", "Name") to (p?.name ?: "-"),
                tr("الجمعية", "Association") to a.name,
                tr("قيمة السهم", "Share") to Fmt.money(a.shareAmount),
                tr("المدة", "Period") to Fmt.periodLabel(a.periodType, a.periodCount),
                tr("عدد الأعضاء", "Members") to "${members.size}",
                tr("دورك في الاستلام", "Your turn") to (myTurn?.let { "${it.round + 1} • ${Fmt.date(it.due)}" } ?: "-"),
                tr("قيمة القبضة", "Payout") to Fmt.money(a.shareAmount * members.size),
                tr("حالة الاستلام", "Received") to (myTurn?.payout?.let { tr("تم ", "Yes ") + Fmt.date(it.date) } ?: tr("لم يتم", "Not yet"))
            ),
            listOf(
                RTable(
                    tr("الدفعات", "Payments"),
                    listOf("#", tr("الموعد", "Due"), tr("المستلم", "Recipient"), tr("المبلغ", "Amount"), tr("الحالة", "Status"), tr("تاريخ الدفع", "Paid on")),
                    rounds.map { r ->
                        val pay = payments.firstOrNull { it.memberId == member.id && it.round == r.round }
                        listOf(
                            "${r.round + 1}", Fmt.date(r.due), people[r.recipient.personId]?.name ?: "-", Fmt.num(a.shareAmount),
                            when { pay != null -> tr("مدفوع", "Paid"); r.due.isBefore(today) -> tr("متأخر", "Late"); else -> tr("قادم", "Upcoming") },
                            pay?.let { Fmt.date(it.date) } ?: "-"
                        )
                    },
                    rounds.map { r ->
                        val paid = payments.any { it.memberId == member.id && it.round == r.round }
                        if (paid) 1 else if (r.due.isBefore(today)) 2 else null
                    }
                )
            ),
            listOf(
                tr("إجمالي المدفوع", "Total paid") to Fmt.money(paidTotal),
                tr("المتبقي", "Remaining") to Fmt.money((a.shareAmount * rounds.size - paidTotal).coerceAtLeast(0.0))
            ),
            a.notes, (p?.name ?: "member") + "_" + a.name
        )
    }

    fun association(a: Association, members: List<AssocMember>, people: Map<Long, Person>, payments: List<AssocPayment>, payouts: List<AssocPayout>): ReportDoc {
        val rounds = associationRounds(a, members, payments, payouts)
        return ReportDoc(
            tr("كشف جمعية", "Association statement"), a.name,
            listOf(
                tr("الجمعية", "Association") to a.name,
                tr("قيمة السهم", "Share") to Fmt.money(a.shareAmount),
                tr("المدة", "Period") to Fmt.periodLabel(a.periodType, a.periodCount),
                tr("عدد الأعضاء", "Members") to "${members.size}",
                tr("قيمة القبضة", "Payout") to Fmt.money(a.shareAmount * members.size)
            ),
            listOf(
                RTable(
                    tr("الدورات", "Rounds"),
                    listOf("#", tr("الموعد", "Due"), tr("المستلم", "Recipient"), tr("المحصّل", "Collected"), tr("دفعوا", "Paid"), tr("التسليم", "Delivered")),
                    rounds.map { r ->
                        listOf(
                            "${r.round + 1}", Fmt.date(r.due), people[r.recipient.personId]?.name ?: "-", Fmt.num(r.collected),
                            "${r.paidMemberIds.size}/${members.size}", r.payout?.let { Fmt.date(it.date) } ?: "-"
                        )
                    },
                    rounds.map { r -> if (r.payout != null) 1 else if (r.due.isBefore(today) && r.paidMemberIds.size < members.size) 2 else null }
                ),
                RTable(
                    tr("الأعضاء", "Members"),
                    listOf("#", tr("الاسم", "Name"), tr("الجوال", "Phone"), tr("المدفوع", "Paid")),
                    members.sortedBy { it.turnOrder }.mapIndexed { i, m ->
                        val p = people[m.personId]
                        listOf("${i + 1}", p?.name ?: "-", p?.phone ?: "", Fmt.num(payments.filter { it.memberId == m.id }.sumOf { it.amount }))
                    }
                )
            ),
            listOf(tr("إجمالي المحصّل", "Total collected") to Fmt.money(payments.sumOf { it.amount })),
            a.notes, a.name
        )
    }

    fun loan(person: Person, txs: List<LoanTx>): ReportDoc {
        val taken = txs.filter { it.type == LoanTx.LOAN }.sumOf { it.amount }
        val paid = txs.filter { it.type == LoanTx.PAY }.sumOf { it.amount }
        var bal = 0.0
        val sorted = txs.sortedWith(compareBy<LoanTx>({ it.date }, { it.id }))
        return ReportDoc(
            tr("كشف حساب سلفة", "Loan statement"), person.name,
            listOf(
                tr("الاسم", "Name") to person.name,
                tr("إجمالي السلف", "Total borrowed") to Fmt.money(taken),
                tr("إجمالي المسدد", "Total repaid") to Fmt.money(paid),
                tr("الرصيد المتبقي", "Balance") to Fmt.money(taken - paid)
            ),
            listOf(
                RTable(
                    tr("الحركات", "Transactions"),
                    listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("سلفة", "Loan"), tr("سداد", "Paid"), tr("الرصيد", "Balance"), tr("ملاحظات", "Notes")),
                    sorted.map { t ->
                        bal += if (t.type == LoanTx.LOAN) t.amount else -t.amount
                        listOf(
                            Fmt.date(t.date), if (t.type == LoanTx.LOAN) tr("سلفة", "Loan") else tr("سداد", "Repayment"),
                            if (t.type == LoanTx.LOAN) Fmt.num(t.amount) else "", if (t.type == LoanTx.PAY) Fmt.num(t.amount) else "",
                            Fmt.num(bal), t.note
                        )
                    },
                    sorted.map { if (it.type == LoanTx.PAY) 1 else null }
                )
            ),
            listOf(tr("الرصيد المتبقي", "Outstanding balance") to Fmt.money(taken - paid)),
            "", "loan_" + person.name
        )
    }

    fun sale(s: Sale, person: Person?, payments: List<SalePayment>): ReportDoc {
        val sch = saleSchedule(s, payments)
        val paid = payments.sumOf { it.amount }
        return ReportDoc(
            tr("كشف بيع بالتقسيط", "Installment sale statement"), s.product,
            listOf(
                tr("العميل", "Customer") to (person?.name ?: "-"),
                tr("المنتج", "Product") to s.product,
                tr("السعر الإجمالي", "Total price") to Fmt.money(s.totalPrice),
                tr("الدفعة المقدمة", "Down payment") to Fmt.money(s.downPayment),
                tr("عدد الأقساط", "Installments") to "${s.installmentsCount} • ${Fmt.periodLabel(s.periodType, s.periodCount)}",
                tr("قيمة القسط", "Installment") to Fmt.money(installmentAmount(s)),
                tr("المتبقي", "Remaining") to Fmt.money(saleRemaining(s, payments))
            ),
            listOf(
                RTable(
                    tr("جدول الأقساط", "Schedule"),
                    listOf("#", tr("الاستحقاق", "Due"), tr("القسط", "Amount"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"), tr("الحالة", "Status")),
                    sch.map { i ->
                        listOf(
                            "${i.index + 1}", Fmt.date(i.due), Fmt.num(i.amount), Fmt.num(i.paid), Fmt.num(i.remaining),
                            when { i.isPaid -> tr("مدفوع", "Paid"); i.paid > 0 -> tr("جزئي", "Partial"); i.due.isBefore(today) -> tr("متأخر", "Late"); else -> tr("قادم", "Upcoming") }
                        )
                    },
                    sch.map { i -> when { i.isPaid -> 1; i.paid > 0 -> 3; i.due.isBefore(today) -> 2; else -> null } }
                ),
                RTable(
                    tr("سجل الدفعات", "Payments"),
                    listOf(tr("التاريخ", "Date"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    payments.sortedBy { it.date }.map { listOf(Fmt.date(it.date), Fmt.num(it.amount), it.note) }
                )
            ),
            listOf(
                tr("إجمالي المدفوع (مع المقدم)", "Total paid (incl. down)") to Fmt.money(paid + s.downPayment),
                tr("المتبقي", "Remaining") to Fmt.money(saleRemaining(s, payments))
            ),
            s.notes, s.product + "_" + (person?.name ?: "")
        )
    }

    fun account(a: Account, person: Person?, txs: List<AccountTx>, from: Long? = null, to: Long? = null): ReportDoc {
        val lines = accountLines(txs).filter { (from == null || it.tx.date >= from) && (to == null || it.tx.date <= to) }
        return ReportDoc(
            tr("كشف حساب", "Account statement"), a.name,
            listOf(
                tr("الحساب", "Account") to a.name,
                tr("صاحب الحساب", "Owner") to (person?.name ?: "-"),
                tr("الفترة", "Period") to (if (from != null || to != null) (from?.let { Fmt.date(it) } ?: "…") + " ← " + (to?.let { Fmt.date(it) } ?: "…") else tr("كامل", "All")),
                tr("الرصيد الحالي", "Current balance") to Fmt.money(accountBalance(txs))
            ),
            listOf(
                RTable(
                    tr("الحركات", "Transactions"),
                    listOf(tr("التاريخ", "Date"), tr("إضافة", "In"), tr("صرف", "Out"), tr("الرصيد", "Balance"), tr("ملاحظات", "Notes")),
                    lines.map { l ->
                        listOf(
                            Fmt.date(l.tx.date), if (l.tx.type == AccountTx.IN) Fmt.num(l.tx.amount) else "",
                            if (l.tx.type == AccountTx.OUT) Fmt.num(l.tx.amount) else "", Fmt.num(l.after), l.tx.note
                        )
                    },
                    lines.map { if (it.tx.type == AccountTx.IN) 1 else null }
                )
            ),
            listOf(
                tr("إجمالي الإضافات", "Total in") to Fmt.money(lines.filter { it.tx.type == AccountTx.IN }.sumOf { it.tx.amount }),
                tr("إجمالي الصرف", "Total out") to Fmt.money(lines.filter { it.tx.type == AccountTx.OUT }.sumOf { it.tx.amount }),
                tr("الرصيد", "Balance") to Fmt.money(lines.lastOrNull()?.after ?: 0.0)
            ),
            "", "account_" + a.name
        )
    }

    fun livingEntries(title: String, subtitle: String, entries: List<LivEntry>, periods: Map<Long, String>, info: List<Pair<String, String>>): ReportDoc {
        val sorted = entries.sortedBy { it.date }
        val ti = entries.filter { it.kind == Living.INCOME }.sumOf { it.amount }
        val te = entries.filter { it.kind == Living.EXPENSE }.sumOf { it.amount }
        val byCat = entries.groupBy { it.kind to it.category }.map { (k, l) -> k to l.sumOf { it.amount } }.sortedWith(compareBy({ it.first.first != Living.INCOME }, { -it.second }))
        return ReportDoc(
            title, subtitle, info,
            listOf(
                RTable(
                    tr("بيان الحركات", "Statement"),
                    listOf(tr("التاريخ", "Date"), tr("البيان", "Item"), tr("النوع", "Type"), tr("الفئة", "Category"), tr("البند", "Period"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    sorted.map { e ->
                        listOf(
                            Fmt.date(e.date), e.name, if (e.kind == Living.INCOME) tr("دخل", "Income") else tr("مصروف", "Expense"),
                            Living.cat(e.kind, e.category).label, periods[e.periodId] ?: "", Fmt.num(e.amount), e.note
                        )
                    },
                    sorted.map { if (it.kind == Living.INCOME) 1 else null }
                ),
                RTable(
                    tr("حسب الفئة", "By category"),
                    listOf(tr("النوع", "Type"), tr("الفئة", "Category"), tr("المبلغ", "Amount")),
                    byCat.map { (k, v) -> listOf(if (k.first == Living.INCOME) tr("دخل", "Income") else tr("مصروف", "Expense"), Living.cat(k.first, k.second).label, Fmt.num(v)) }
                )
            ),
            listOf(
                tr("إجمالي الدخل", "Total income") to Fmt.money(ti),
                tr("إجمالي المصروفات", "Total expenses") to Fmt.money(te),
                tr("الصافي", "Net") to Fmt.money(ti - te)
            ),
            "", "living_" + subtitle
        )
    }

    fun livingPeriod(p: LivPeriod, entries: List<LivEntry>) = livingEntries(
        tr("كشف مصاريف المعيشة", "Living expenses"), p.name, entries, mapOf(p.id to p.name),
        listOf(tr("الفترة", "Period") to (Fmt.date(p.startDate) + " ← " + Fmt.date(p.endDate)), tr("عدد الأيام", "Days") to "${Living.days(p)}")
    )

    // ---------------- العقارات والإيجارات ----------------
    fun lease(l: Lease, unit: PropUnit?, prop: Property?, tenant: Person?, payments: List<LeasePayment>): ReportDoc {
        val sch = Rent.schedule(l, payments)
        val pays = payments.filter { it.leaseId == l.id }.sortedBy { it.date }
        val paid = pays.sumOf { it.amount }
        val total = sch.sumOf { it.amount }
        val overdue = sch.filter { !it.isPaid && !it.due.isAfter(today) }.sumOf { it.remaining }
        return ReportDoc(
            tr("كشف حساب مستأجر", "Tenant statement"), (prop?.name ?: "") + (unit?.let { " - " + it.name } ?: ""),
            listOf(
                tr("المستأجر", "Tenant") to (tenant?.name ?: "-"),
                tr("العقار", "Property") to (prop?.name ?: "-"),
                tr("الوحدة", "Unit") to (unit?.name ?: "-"),
                tr("مدة العقد", "Lease term") to (Fmt.date(l.startDate) + " ← " + Fmt.date(l.endDate)),
                tr("قيمة الدفعة", "Payment") to (Fmt.money(l.rentAmount) + " • " + Rent.periodName(l.periodMonths)),
                tr("التأمين", "Deposit") to Fmt.money(l.deposit),
                tr("إجمالي العقد", "Lease total") to Fmt.money(total),
                tr("المتأخر", "Overdue") to Fmt.money(overdue)
            ),
            listOf(
                RTable(
                    tr("جدول الدفعات", "Payment schedule"),
                    listOf("#", tr("الاستحقاق", "Due"), tr("المبلغ", "Amount"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"), tr("الحالة", "Status")),
                    sch.map { d ->
                        listOf("${d.index + 1}", Fmt.date(d.due), Fmt.num(d.amount), Fmt.num(d.paid), Fmt.num(d.remaining),
                            when { d.isPaid -> tr("مدفوع", "Paid"); d.paid > 0 -> tr("جزئي", "Partial"); d.due.isBefore(today) -> tr("متأخر", "Late"); else -> tr("قادم", "Upcoming") })
                    },
                    sch.map { d -> when { d.isPaid -> 1; d.paid > 0 -> 3; d.due.isBefore(today) -> 2; else -> null } }
                ),
                RTable(
                    tr("سجل الدفعات", "Payments"),
                    listOf(tr("التاريخ", "Date"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    pays.map { listOf(Fmt.date(it.date), Fmt.num(it.amount), it.note) }
                )
            ),
            listOf(
                tr("إجمالي المدفوع", "Total paid") to Fmt.money(paid),
                tr("المتبقي من العقد", "Remaining on lease") to Fmt.money((total - paid).coerceAtLeast(0.0))
            ),
            l.notes, "lease_" + (tenant?.name ?: "")
        )
    }

    fun property(p: Property, units: List<PropUnit>, leases: List<Lease>, payments: List<LeasePayment>, expenses: List<PropExpense>, people: Map<Long, Person>, range: LongRange? = null): ReportDoc {
        val us = units.filter { it.propertyId == p.id }
        val st = Rent.stats(p.id, units, leases, payments, expenses, range)
        val uids = us.map { it.id }.toSet()
        val ls = leases.filter { it.unitId in uids }
        val lids = ls.map { it.id }.toSet()
        val um = us.associateBy { it.id }
        val lm = ls.associateBy { it.id }
        val pays = payments.filter { it.leaseId in lids && (range == null || it.date in range) }.sortedBy { it.date }
        val exps = expenses.filter { it.propertyId == p.id && (range == null || it.date in range) }.sortedBy { it.date }
        return ReportDoc(
            tr("تقرير عقار", "Property report"), p.name,
            listOf(
                tr("العقار", "Property") to (Rent.propType(p.type).label + " • " + p.name),
                tr("العنوان", "Address") to p.address.ifBlank { "-" },
                tr("الفترة", "Period") to (range?.let { Fmt.date(it.first) + " ← " + Fmt.date(it.last) } ?: tr("كامل", "All")),
                tr("الوحدات", "Units") to "${st.units}",
                tr("المؤجّر منها", "Occupied") to "${st.occupied} (${st.occupancy}%)",
                tr("الإيجار الشهري المتوقع", "Expected monthly rent") to Fmt.money(st.monthlyRent),
                tr("المتأخرات", "Overdue") to Fmt.money(st.overdue)
            ),
            listOf(
                RTable(
                    tr("الوحدات والمستأجرون", "Units & tenants"),
                    listOf(tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("الإيجار", "Rent"), tr("نهاية العقد", "Ends"), tr("المتأخر", "Overdue")),
                    us.map { u ->
                        val l = ls.firstOrNull { it.unitId == u.id && Rent.isCurrent(it) }
                        listOf(u.name, l?.let { people[it.tenantId]?.name } ?: tr("شاغرة", "Vacant"), l?.let { Fmt.num(it.rentAmount) + " / " + Rent.periodName(it.periodMonths) } ?: "-",
                            l?.let { Fmt.date(it.endDate) } ?: "-", l?.let { Fmt.num(Rent.overdue(it, payments).sumOf { d -> d.remaining }) } ?: "-")
                    },
                    us.map { u -> val l = ls.firstOrNull { it.unitId == u.id && Rent.isCurrent(it) }; if (l == null) null else if (Rent.overdue(l, payments).isNotEmpty()) 2 else 1 }
                ),
                RTable(
                    tr("الإيرادات (دفعات الإيجار)", "Income (rent payments)"),
                    listOf(tr("التاريخ", "Date"), tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    pays.map { x -> val l = lm[x.leaseId]; listOf(Fmt.date(x.date), um[l?.unitId]?.name ?: "-", people[l?.tenantId]?.name ?: "-", Fmt.num(x.amount), x.note) }
                ),
                RTable(
                    tr("المصروفات", "Expenses"),
                    listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("الوحدة", "Unit"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    exps.map { e -> listOf(Fmt.date(e.date), Rent.expCat(e.category).label, e.unitId?.let { um[it]?.name } ?: "-", Fmt.num(e.amount), e.note) }
                )
            ),
            listOf(
                tr("إجمالي الإيرادات", "Total income") to Fmt.money(st.collected),
                tr("إجمالي المصروفات", "Total expenses") to Fmt.money(st.expenses),
                tr("صافي الربح", "Net profit") to Fmt.money(st.net)
            ),
            p.notes, "property_" + p.name
        )
    }

    // ---------------- تقرير شامل لكل العقارات والإيجارات ----------------
    data class PropRow(val p: Property, val st: Rent.PropStats, val yearly: Double, val deposits: Double)
    data class LeaseRow(val l: Lease, val unit: PropUnit?, val prop: Property?, val total: Double, val paid: Double, val overdue: Double) {
        val remaining get() = (total - paid).coerceAtLeast(0.0)
    }

    fun propRows(props: List<Property>, units: List<PropUnit>, leases: List<Lease>, payments: List<LeasePayment>, expenses: List<PropExpense>, range: LongRange?): List<PropRow> =
        props.map { p ->
            val uids = units.filter { it.propertyId == p.id }.map { it.id }.toSet()
            val cur = leases.filter { it.unitId in uids && Rent.isCurrent(it) }
            PropRow(p, Rent.stats(p.id, units, leases, payments, expenses, range), cur.sumOf { Rent.monthlyRent(it) } * 12, cur.sumOf { it.deposit })
        }

    fun leaseRows(units: List<PropUnit>, props: List<Property>, leases: List<Lease>, payments: List<LeasePayment>): List<LeaseRow> {
        val um = units.associateBy { it.id }; val pm = props.associateBy { it.id }
        return leases.map { l ->
            val sch = Rent.schedule(l, payments)
            val u = um[l.unitId]
            LeaseRow(l, u, pm[u?.propertyId], sch.sumOf { it.amount }, Rent.paid(l, payments), if (l.active) Rent.overdue(l, payments).sumOf { it.remaining } else 0.0)
        }.sortedWith(compareBy({ it.prop?.name ?: "" }, { it.unit?.name ?: "" }, { -it.l.startDate }))
    }

    fun allProperties(
        props: List<Property>, units: List<PropUnit>, leases: List<Lease>, payments: List<LeasePayment>,
        expenses: List<PropExpense>, people: Map<Long, Person>, range: LongRange?, onlyCurrent: Boolean = false
    ): ReportDoc {
        val rows = propRows(props, units, leases, payments, expenses, range)
        val all = Rent.stats(null, units, leases, payments, expenses, range)
        val lrAll = leaseRows(units, props, leases, payments)
        val lr = if (onlyCurrent) lrAll.filter { Rent.isCurrent(it.l) } else lrAll
        val pm = props.associateBy { it.id }; val um = units.associateBy { it.id }; val lm = leases.associateBy { it.id }
        val pays = payments.filter { range == null || it.date in range }.sortedBy { it.date }
        val exps = expenses.filter { range == null || it.date in range }.sortedBy { it.date }
        val yearly = rows.sumOf { it.yearly }
        val deposits = rows.sumOf { it.deposits }
        val T = tr("الإجمالي", "Total")

        // جدول الوحدات: كل وحدة مع عقدها الساري أو «شاغرة»
        val unitRows = props.flatMap { p ->
            units.filter { it.propertyId == p.id }.map { u ->
                val l = leases.firstOrNull { it.unitId == u.id && Rent.isCurrent(it) }
                Triple(p, u, l)
            }
        }
        return ReportDoc(
            tr("تقرير شامل للعقارات والإيجارات", "All properties & rentals report"),
            range?.let { Fmt.date(it.first) + " ← " + Fmt.date(it.last) } ?: tr("كل الفترات", "All time"),
            listOf(
                tr("عدد العقارات", "Properties") to "${props.size}",
                tr("عدد الوحدات", "Units") to "${all.units}",
                tr("المؤجّر / الشاغر", "Occupied / vacant") to "${all.occupied} / ${all.units - all.occupied}",
                tr("نسبة الإشغال", "Occupancy") to "${all.occupancy}%",
                tr("الإيجار الشهري المتوقع", "Expected monthly rent") to Fmt.money(all.monthlyRent),
                tr("الإيجار السنوي المتوقع", "Expected yearly rent") to Fmt.money(yearly),
                tr("العقود السارية", "Active leases") to "${leases.count { Rent.isCurrent(it) }}",
                tr("عقود تنتهي خلال 30 يوماً", "Ending in 30 days") to "${leases.count { Rent.isCurrent(it) && Rent.daysLeft(it) in 0..30 }}"
            ),
            listOf(
                RTable(
                    tr("ملخص العقارات", "Properties summary"),
                    listOf(tr("العقار", "Property"), tr("الوحدات", "Units"), tr("المؤجّر", "Occupied"), tr("شهرياً", "Monthly"), tr("سنوياً", "Yearly"), tr("المحصّل", "Collected"), tr("المصروفات", "Expenses"), tr("الصافي", "Net"), tr("المتأخر", "Overdue")),
                    rows.map { r ->
                        listOf(r.p.name, "${r.st.units}", "${r.st.occupied} (${r.st.occupancy}%)", Fmt.num(r.st.monthlyRent), Fmt.num(r.yearly), Fmt.num(r.st.collected), Fmt.num(r.st.expenses), Fmt.num(r.st.net), Fmt.num(r.st.overdue))
                    } + listOf(listOf(T, "${all.units}", "${all.occupied} (${all.occupancy}%)", Fmt.num(all.monthlyRent), Fmt.num(yearly), Fmt.num(all.collected), Fmt.num(all.expenses), Fmt.num(all.net), Fmt.num(all.overdue))),
                    rows.map { if (it.st.overdue > 0.005) 2 else null } + listOf(9)
                ),
                RTable(
                    tr("الوحدات والمستأجرون الحاليون", "Units & current tenants"),
                    listOf(tr("العقار", "Property"), tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("الجوال", "Phone"), tr("الإيجار", "Rent"), tr("شهرياً", "Monthly"), tr("نهاية العقد", "Ends"), tr("المتأخر", "Overdue")),
                    unitRows.map { (p, u, l) ->
                        val t = l?.let { people[it.tenantId] }
                        listOf(p.name, u.name, t?.name ?: tr("شاغرة", "Vacant"), t?.phone ?: "-", l?.let { Fmt.num(it.rentAmount) + " / " + Rent.periodName(it.periodMonths) } ?: "-",
                            l?.let { Fmt.num(Rent.monthlyRent(it)) } ?: "-", l?.let { Fmt.date(it.endDate) } ?: "-", l?.let { Fmt.num(Rent.overdue(it, payments).sumOf { d -> d.remaining }) } ?: "-")
                    } + listOf(listOf(T, "${unitRows.size}", tr("${unitRows.count { it.third != null }} مؤجّرة", "${unitRows.count { it.third != null }} let"), "", "", Fmt.num(all.monthlyRent), "", Fmt.num(unitRows.mapNotNull { it.third }.sumOf { l -> Rent.overdue(l, payments).sumOf { d -> d.remaining } }))),
                    unitRows.map { (_, _, l) -> if (l == null) null else if (Rent.overdue(l, payments).isNotEmpty()) 2 else 1 } + listOf(9)
                ),
                RTable(
                    if (onlyCurrent) tr("العقود السارية", "Active leases") else tr("كل عقود الإيجار", "All leases"),
                    listOf(tr("العقار", "Property"), tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("المدة", "Term"), tr("إجمالي العقد", "Lease total"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"), tr("المتأخر", "Overdue"), tr("الحالة", "Status")),
                    lr.map { r ->
                        listOf(r.prop?.name ?: "-", r.unit?.name ?: "-", people[r.l.tenantId]?.name ?: "-", Fmt.date(r.l.startDate) + " ← " + Fmt.date(r.l.endDate),
                            Fmt.num(r.total), Fmt.num(r.paid), Fmt.num(r.remaining), Fmt.num(r.overdue),
                            when { Rent.isCurrent(r.l) -> tr("ساري", "Active"); r.l.startDate > Fmt.today() && r.l.active -> tr("لم يبدأ", "Upcoming"); else -> tr("منتهي", "Ended") })
                    } + listOf(listOf(T, "", "${lr.size}", "", Fmt.num(lr.sumOf { it.total }), Fmt.num(lr.sumOf { it.paid }), Fmt.num(lr.sumOf { it.remaining }), Fmt.num(lr.sumOf { it.overdue }), "")),
                    lr.map { r -> when { r.overdue > 0.005 -> 2; r.remaining < 0.005 -> 1; r.paid > 0 -> 3; else -> null } } + listOf(9)
                ),
                RTable(
                    tr("دفعات الإيجار المحصّلة", "Rent collected"),
                    listOf(tr("التاريخ", "Date"), tr("العقار", "Property"), tr("الوحدة", "Unit"), tr("المستأجر", "Tenant"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    pays.map { x -> val l = lm[x.leaseId]; val u = um[l?.unitId]; listOf(Fmt.date(x.date), pm[u?.propertyId]?.name ?: "-", u?.name ?: "-", people[l?.tenantId]?.name ?: "-", Fmt.num(x.amount), x.note) } +
                        listOf(listOf(T, "", "", "${pays.size} " + tr("دفعة", "payments"), Fmt.num(pays.sumOf { it.amount }), "")),
                    pays.map { null } + listOf(9)
                ),
                RTable(
                    tr("مصروفات العقارات", "Property expenses"),
                    listOf(tr("التاريخ", "Date"), tr("العقار", "Property"), tr("الوحدة", "Unit"), tr("النوع", "Type"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    exps.map { e -> listOf(Fmt.date(e.date), pm[e.propertyId]?.name ?: "-", e.unitId?.let { um[it]?.name } ?: "-", Rent.expCat(e.category).label, Fmt.num(e.amount), e.note) } +
                        listOf(listOf(T, "", "", "", Fmt.num(exps.sumOf { it.amount }), "")),
                    exps.map { null } + listOf(9)
                ),
                RTable(
                    tr("المصروفات حسب النوع", "Expenses by type"),
                    listOf(tr("النوع", "Type"), tr("العدد", "Count"), tr("المبلغ", "Amount"), tr("النسبة", "Share")),
                    exps.groupBy { it.category }.entries.sortedByDescending { e -> e.value.sumOf { it.amount } }.map { (k, l) ->
                        val sum = l.sumOf { it.amount }
                        listOf(Rent.expCat(k).label, "${l.size}", Fmt.num(sum), if (all.expenses > 0) "${(sum * 100 / all.expenses).toInt()}%" else "-")
                    }
                )
            ),
            listOf(
                tr("الإيجار الشهري المتوقع", "Expected monthly rent") to Fmt.money(all.monthlyRent),
                tr("الإيجار السنوي المتوقع", "Expected yearly rent") to Fmt.money(yearly),
                tr("إجمالي المحصّل", "Total collected") to Fmt.money(all.collected),
                tr("إجمالي المصروفات", "Total expenses") to Fmt.money(all.expenses),
                tr("صافي الربح", "Net profit") to Fmt.money(all.net),
                tr("إجمالي المتأخرات", "Total overdue") to Fmt.money(all.overdue),
                tr("المتبقي على العقود", "Remaining on leases") to Fmt.money(lrAll.filter { it.l.active }.sumOf { it.remaining }),
                tr("التأمينات المحتفظ بها", "Deposits held") to Fmt.money(deposits)
            ),
            "", "properties_all"
        )
    }

    // ---------------- المحل: فاتورة ----------------
    fun invoice(r: Shop.InvRow, items: List<InvoiceItem>, pays: List<InvoicePayment>): ReportDoc {
        val i = r.inv
        val info = mutableListOf<Pair<String, String>>()
        if (Extras.shopName.isNotBlank()) info += tr("المحل", "Shop") to Extras.shopName
        if (Extras.shopPhone.isNotBlank()) info += tr("هاتف المحل", "Shop phone") to Extras.shopPhone
        if (Extras.shopAddress.isNotBlank()) info += tr("العنوان", "Address") to Extras.shopAddress
        if (Extras.shopTaxNo.isNotBlank()) info += tr("الرقم الضريبي", "Tax no.") to Extras.shopTaxNo
        info += tr("رقم الفاتورة", "Invoice no.") to Shop.numberText(i)
        info += tr("التاريخ", "Date") to Fmt.date(i.date)
        i.dueDate?.let { info += tr("تاريخ الاستحقاق", "Due date") to Fmt.date(it) }
        if (i.partyName.isNotBlank()) info += (if (Shop.isCustomerSide(i.type)) tr("العميل", "Customer") else tr("المورد", "Supplier")) to i.partyName
        if (i.partyPhone.isNotBlank()) info += tr("الجوال", "Phone") to i.partyPhone
        val tables = mutableListOf(
            RTable(
                tr("الأصناف", "Items"),
                listOf("#", tr("الصنف", "Item"), tr("الكمية", "Qty"), tr("السعر", "Price"), tr("الإجمالي", "Total")),
                items.mapIndexed { n, x -> listOf("${n + 1}", x.name, Fmt.num(x.qty), Fmt.num(x.price), Fmt.num(x.qty * x.price)) } +
                    listOf(listOf(tr("الإجمالي", "Total"), "", Fmt.num(items.sumOf { it.qty }), "", Fmt.num(r.t.subtotal))),
                items.map { null } + listOf(9)
            )
        )
        if (r.hasInst) tables += RTable(
            tr("جدول الأقساط", "Installment schedule"),
            listOf(tr("القسط", "Installment"), tr("الاستحقاق", "Due"), tr("المبلغ", "Amount"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"), tr("الحالة", "Status")),
            r.schedule.map { x ->
                listOf(Shop.instLabel(x, i.instCount), Fmt.date(x.due), Fmt.num(x.amount), Fmt.num(x.paid), Fmt.num(x.remaining),
                    when { x.isPaid -> tr("مدفوع", "Paid"); x.isLate -> tr("متأخر", "Late"); x.paid > 0 -> tr("جزئي", "Partial"); else -> tr("قادم", "Upcoming") })
            } + listOf(listOf(tr("الإجمالي", "Total"), "", Fmt.num(r.t.total), Fmt.num(r.paid), Fmt.num(r.remaining), "")),
            r.schedule.map { x -> when { x.isPaid -> 1; x.isLate -> 2; x.paid > 0 -> 3; else -> null } } + listOf(9)
        )
        val ps = pays.filter { it.invoiceId == i.id }
        if (ps.isNotEmpty()) tables += RTable(
            tr("الدفعات", "Payments"),
            listOf(tr("التاريخ", "Date"), tr("الطريقة", "Method"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
            ps.map { listOf(Fmt.date(it.date), Shop.method(it.method).label, Fmt.num(it.amount), it.note) }
        )
        val totals = mutableListOf(tr("المجموع", "Subtotal") to Fmt.money(r.t.subtotal))
        if (r.t.discount > 0) totals += tr("الخصم", "Discount") to Fmt.money(r.t.discount)
        if (r.t.tax > 0) totals += (tr("الضريبة ", "Tax ") + Fmt.num(i.taxPct) + "%") to Fmt.money(r.t.tax)
        totals += tr("الإجمالي النهائي", "Grand total") to Fmt.money(r.t.total)
        if (Shop.isMoney(i.type)) {
            totals += tr("المدفوع", "Paid") to Fmt.money(r.paid)
            totals += tr("المتبقي", "Balance due") to Fmt.money(r.remaining)
        }
        if (r.hasInst) {
            r.nextInst?.let { n -> totals += tr("القسط القادم", "Next installment") to (Fmt.money(n.remaining) + " • " + Fmt.date(n.due)) }
            if (r.lateAmount > 0) totals += tr("أقساط متأخرة", "Overdue installments") to Fmt.money(r.lateAmount)
        }
        val notes = listOf(i.notes, Extras.shopFooter).filter { it.isNotBlank() }.joinToString("\n")
        return ReportDoc(Shop.type(i.type).label, Shop.numberText(i) + (if (i.partyName.isNotBlank()) " • " + i.partyName else ""), info, tables, totals, notes, "invoice_" + Shop.numberText(i))
    }

    // ---------------- المحل: تقرير شامل ----------------
    fun shop(rows: List<Shop.InvRow>, items: List<InvoiceItem>, products: List<Product>, stock: Map<Long, Double>, range: LongRange?): ReportDoc {
        val st = Shop.stats(rows, items, range)
        val rr = rows.filter { (range == null || it.inv.date in range) && Shop.isMoney(it.inv.type) }.sortedBy { it.inv.date }
        val top = Shop.topItems(rows, items, range)
        val cust = Shop.parties(rows, true).filter { it.remaining > 0.01 }
        val supp = Shop.parties(rows, false).filter { it.remaining > 0.01 }
        val stockVal = products.filter { it.trackStock }.sumOf { (stock[it.id] ?: 0.0).coerceAtLeast(0.0) * it.cost }
        val T = tr("الإجمالي", "Total")
        return ReportDoc(
            tr("تقرير المحل", "Shop report"),
            (Extras.shopName.ifBlank { "" }) + " " + (range?.let { Fmt.date(it.first) + " ← " + Fmt.date(it.last) } ?: tr("كل الفترات", "All time")),
            listOf(
                tr("عدد فواتير البيع", "Sales invoices") to "${st.count}",
                tr("صافي المبيعات", "Net sales") to Fmt.money(st.net),
                tr("تكلفة البضاعة المباعة", "Cost of goods sold") to Fmt.money(st.cost),
                tr("مجمل الربح", "Gross profit") to Fmt.money(st.profit),
                tr("الضريبة المحصّلة", "Tax collected") to Fmt.money(st.tax),
                tr("المشتريات", "Purchases") to Fmt.money(st.purchases),
                tr("قيمة المخزون (بالتكلفة)", "Stock value (cost)") to Fmt.money(stockVal)
            ),
            listOf(
                RTable(
                    tr("الفواتير", "Invoices"),
                    listOf(tr("الرقم", "No."), tr("التاريخ", "Date"), tr("النوع", "Type"), tr("الطرف", "Party"), tr("الإجمالي", "Total"), tr("المدفوع", "Paid"), tr("المتبقي", "Due")),
                    rr.map { listOf(Shop.numberText(it.inv), Fmt.date(it.inv.date), Shop.type(it.inv.type).label, it.inv.partyName, Fmt.num(it.t.total), Fmt.num(it.paid), Fmt.num(it.remaining)) } +
                        listOf(listOf(T, "", "${rr.size}", "", Fmt.num(rr.sumOf { it.t.total }), Fmt.num(rr.sumOf { it.paid }), Fmt.num(rr.sumOf { it.remaining }))),
                    rr.map { when { it.overdue -> 2; it.isPaid -> 1; it.paid > 0 -> 3; else -> null } } + listOf(9)
                ),
                RTable(
                    tr("الأصناف الأكثر مبيعاً", "Top selling items"),
                    listOf(tr("الصنف", "Item"), tr("الكمية", "Qty"), tr("المبيعات", "Sales"), tr("الربح", "Profit")),
                    top.map { listOf(it.name, Fmt.num(it.qty), Fmt.num(it.amount), Fmt.num(it.profit)) } +
                        listOf(listOf(T, Fmt.num(top.sumOf { it.qty }), Fmt.num(top.sumOf { it.amount }), Fmt.num(top.sumOf { it.profit }))),
                    top.map { null } + listOf(9)
                ),
                RTable(
                    tr("المخزون", "Stock"),
                    listOf(tr("الصنف", "Item"), tr("الكود", "SKU"), tr("الكمية", "Qty"), tr("الحد الأدنى", "Min"), tr("التكلفة", "Cost"), tr("سعر البيع", "Price"), tr("القيمة", "Value")),
                    products.filter { it.trackStock }.map { p -> val q = stock[p.id] ?: 0.0; listOf(p.name, p.sku, Fmt.num(q), Fmt.num(p.minQty), Fmt.num(p.cost), Fmt.num(p.price), Fmt.num(q.coerceAtLeast(0.0) * p.cost)) } +
                        listOf(listOf(T, "", "", "", "", "", Fmt.num(stockVal))),
                    products.filter { it.trackStock }.map { p -> if (Shop.isLow(p, stock[p.id] ?: 0.0)) 2 else null } + listOf(9)
                ),
                RTable(
                    tr("ديون العملاء (لي)", "Customer balances (owed to me)"),
                    listOf(tr("العميل", "Customer"), tr("الجوال", "Phone"), tr("الفواتير", "Invoices"), tr("الإجمالي", "Total"), tr("المتبقي", "Due")),
                    cust.map { listOf(it.name, it.phone, "${it.count}", Fmt.num(it.total), Fmt.num(it.remaining)) } + listOf(listOf(T, "", "", "", Fmt.num(cust.sumOf { it.remaining }))),
                    cust.map { null } + listOf(9)
                ),
                RTable(
                    tr("مستحقات الموردين (عليّ)", "Supplier balances (I owe)"),
                    listOf(tr("المورد", "Supplier"), tr("الجوال", "Phone"), tr("الفواتير", "Invoices"), tr("الإجمالي", "Total"), tr("المتبقي", "Due")),
                    supp.map { listOf(it.name, it.phone, "${it.count}", Fmt.num(it.total), Fmt.num(it.remaining)) } + listOf(listOf(T, "", "", "", Fmt.num(supp.sumOf { it.remaining }))),
                    supp.map { null } + listOf(9)
                )
            ),
            listOf(
                tr("صافي المبيعات", "Net sales") to Fmt.money(st.net),
                tr("مجمل الربح", "Gross profit") to Fmt.money(st.profit),
                tr("المحصّل من المبيعات", "Collected") to Fmt.money(st.collected),
                tr("ديون العملاء", "Owed by customers") to Fmt.money(cust.sumOf { it.remaining }),
                tr("مستحقات الموردين", "Owed to suppliers") to Fmt.money(supp.sumOf { it.remaining }),
                tr("قيمة المخزون", "Stock value") to Fmt.money(stockVal)
            ),
            "", "shop_report"
        )
    }

    // ---------------- كشف عميل / مورد ----------------
    fun party(p: Shop.Party, rows: List<Shop.InvRow>): ReportDoc {
        val rr = rows.filter { Shop.isMoney(it.inv.type) && Shop.isCustomerSide(it.inv.type) == p.customer && Shop.partyKey(it.inv) == p.key }.sortedBy { it.inv.date }
        return ReportDoc(
            if (p.customer) tr("كشف حساب عميل", "Customer statement") else tr("كشف حساب مورد", "Supplier statement"), p.name,
            listOf(tr("الاسم", "Name") to p.name, tr("الجوال", "Phone") to p.phone.ifBlank { "-" }, tr("عدد الفواتير", "Invoices") to "${p.count}") +
                (if (Extras.shopName.isNotBlank()) listOf(tr("المحل", "Shop") to Extras.shopName) else emptyList()),
            listOf(RTable(
                tr("الفواتير", "Invoices"),
                listOf(tr("الرقم", "No."), tr("التاريخ", "Date"), tr("النوع", "Type"), tr("الإجمالي", "Total"), tr("المدفوع", "Paid"), tr("المتبقي", "Due")),
                rr.map { listOf(Shop.numberText(it.inv), Fmt.date(it.inv.date), Shop.type(it.inv.type).label, Fmt.num(it.t.total), Fmt.num(it.paid), Fmt.num(it.remaining)) } +
                    listOf(listOf(tr("الإجمالي", "Total"), "", "", Fmt.num(p.total), Fmt.num(p.paid), Fmt.num(p.remaining))),
                rr.map { when { it.overdue -> 2; it.isPaid -> 1; it.paid > 0 -> 3; else -> null } } + listOf(9)
            )),
            listOf(tr("الإجمالي", "Total") to Fmt.money(p.total), tr("المدفوع", "Paid") to Fmt.money(p.paid), tr("المتبقي", "Balance") to Fmt.money(p.remaining)),
            "", "statement_" + p.name
        )
    }

    // ---------------- خزنة المستندات ----------------
    fun vault(list: List<VaultDoc>): ReportDoc = ReportDoc(
        tr("خزنة المستندات", "Documents vault"), tr("${list.size} مستند", "${list.size} documents"),
        listOf(
            tr("منتهية", "Expired") to "${list.count { Vault.isExpired(it) }}",
            tr("تنتهي قريباً", "Expiring soon") to "${list.count { Vault.isSoon(it) }}"
        ),
        listOf(RTable(
            tr("المستندات", "Documents"),
            listOf(tr("المستند", "Document"), tr("النوع", "Type"), tr("صاحبه", "Holder"), tr("الرقم", "Number"), tr("الإصدار", "Issued"), tr("الانتهاء", "Expires"), tr("الحالة", "Status")),
            list.map { listOf(it.title, Vault.type(it.type).label, it.holder, it.number, it.issueDate?.let { d -> Fmt.date(d) } ?: "-", it.expiryDate?.let { d -> Fmt.date(d) } ?: "-", Vault.status(it)) },
            list.map { when { Vault.isExpired(it) -> 2; Vault.isSoon(it) -> 3; it.expiryDate != null -> 1; else -> null } }
        )),
        fileName = "vault"
    )

    // ---------------- المواريث ----------------
    fun faraid(r: Faraid.Result, e: Faraid.Estate, deceased: String, male: Boolean): ReportDoc {
        val heirs = r.shares.filter { it.blockedBy == null }
        val blocked = r.shares.filter { it.blockedBy != null }
        return ReportDoc(
            tr("تقسيم التركة (المواريث)", "Inheritance distribution"),
            deceased.ifBlank { if (male) tr("المتوفى", "The deceased") else tr("المتوفاة", "The deceased") },
            listOf(
                tr("إجمالي التركة", "Gross estate") to Fmt.money(e.gross),
                tr("تجهيز ودفن", "Funeral costs") to Fmt.money(e.funeral),
                tr("الديون", "Debts") to Fmt.money(e.debts),
                tr("الوصية (بحد أقصى الثلث)", "Bequest (max 1/3)") to Fmt.money(e.willCapped),
                tr("الصافي للورثة", "Net for heirs") to Fmt.money(e.net),
                tr("أصل المسألة", "Base") to "${r.asl}" + (if (r.awl) tr(" (عائلة)", " (‘awl)") else "") + (if (r.radd) tr(" (فيها رد)", " (radd)") else "")
            ),
            listOf(
                RTable(
                    tr("أنصبة الورثة", "Heirs' shares"),
                    listOf(tr("الوارث", "Heir"), tr("العدد", "Count"), tr("النصيب", "Share"), tr("السهام", "Parts"), tr("النسبة", "%"), tr("المبلغ", "Amount"), tr("للفرد", "Each"), tr("السبب", "Basis")),
                    heirs.map { s ->
                        listOf(s.h.label, "${s.count}", s.share.toString(), "${r.sihaam(s)} / ${r.asl}", String.format(java.util.Locale.US, "%.2f%%", s.share.v * 100),
                            Fmt.num(e.net * s.share.v), Fmt.num(e.net * s.each.v), s.basis)
                    } + listOf(listOf(tr("الإجمالي", "Total"), "${heirs.sumOf { it.count }}", "", "${r.asl}", "100%", Fmt.num(e.net * (1 - r.baitAlMal.v)), "", "")),
                    heirs.map { null } + listOf(9)
                ),
                RTable(
                    tr("المحجوبون", "Excluded heirs"),
                    listOf(tr("الوارث", "Heir"), tr("العدد", "Count"), tr("محجوب بـ", "Excluded by")),
                    blocked.map { listOf(it.h.label, "${it.count}", it.blockedBy ?: "") }
                )
            ),
            listOf(tr("الصافي للورثة", "Net for heirs") to Fmt.money(e.net)) +
                (if (!r.baitAlMal.isZero) listOf(tr("لبيت المال", "To treasury") to Fmt.money(e.net * r.baitAlMal.v)) else emptyList()),
            (r.notes + tr("هذه أداة حسابية مساعدة على قول جمهور العلماء، وللحالات الخاصة أو النزاع يُرجع إلى المحكمة أو أهل العلم.", "A helper tool based on the majority view; consult a court or scholar for disputes.")).joinToString("\n"),
            "inheritance"
        )
    }

    // ---------------- ديوني ----------------
    fun debt(d: Debt, txs: List<DebtTx>): ReportDoc {
        val list = txs.filter { it.debtId == d.id }.sortedWith(compareBy({ it.date }, { it.id }))
        var bal = 0.0
        val nd = Debts.nextDue(d, txs)
        return ReportDoc(
            tr("كشف دين", "Debt statement"), d.creditor,
            listOf(
                tr("الدائن", "Creditor") to d.creditor,
                tr("النوع", "Type") to Debts.type(d.type).label,
                tr("إجمالي الدين", "Total borrowed") to Fmt.money(Debts.borrowed(d, txs)),
                tr("المسدد", "Paid") to Fmt.money(Debts.paid(d, txs)),
                tr("المتبقي", "Remaining") to Fmt.money(Debts.balance(d, txs)),
                tr("القسط", "Installment") to (if (d.installment > 0) Fmt.money(d.installment) + " • " + Rent.periodName(d.periodMonths) else "-"),
                tr("الاستحقاق القادم", "Next due") to (nd?.let { Fmt.date(it) } ?: "-")
            ),
            listOf(
                RTable(
                    tr("الحركات", "Transactions"),
                    listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("زيادة", "Borrowed"), tr("سداد", "Paid"), tr("المتبقي", "Balance"), tr("ملاحظات", "Notes")),
                    list.map { t ->
                        bal += if (t.type == DebtTx.BORROW) t.amount else -t.amount
                        listOf(Fmt.date(t.date), if (t.type == DebtTx.BORROW) tr("استدانة", "Borrow") else tr("سداد", "Payment"),
                            if (t.type == DebtTx.BORROW) Fmt.num(t.amount) else "", if (t.type == DebtTx.PAY) Fmt.num(t.amount) else "", Fmt.num(bal), t.note)
                    },
                    list.map { if (it.type == DebtTx.PAY) 1 else null }
                )
            ),
            listOf(tr("المتبقي عليّ", "Remaining I owe") to Fmt.money(Debts.balance(d, txs))),
            d.notes, "debt_" + d.creditor
        )
    }

    // ---------------- العمال ----------------
    fun worker(w: Worker, entries: List<WorkerEntry>, range: LongRange? = null): ReportDoc {
        val es = entries.filter { it.workerId == w.id && (range == null || it.date in range) }.sortedWith(compareBy({ it.date }, { it.id }))
        val sm = Workers.sum(w, entries, range)
        var bal = 0.0
        return ReportDoc(
            tr("كشف حساب عامل", "Worker statement"), w.name,
            listOf(
                tr("العامل", "Worker") to w.name,
                tr("المهنة", "Job") to w.job.ifBlank { "-" },
                tr("الأجر", "Wage") to (Fmt.money(w.wage) + " • " + Workers.wageType(w.wageType).label),
                tr("الفترة", "Period") to (range?.let { Fmt.date(it.first) + " ← " + Fmt.date(it.last) } ?: tr("كامل", "All")),
                tr("أيام الحضور", "Days worked") to Fmt.num(sm.days).removeSuffix(".00"),
                tr("ساعات إضافية", "Overtime hours") to Fmt.num(sm.otHours).removeSuffix(".00")
            ),
            listOf(
                RTable(
                    tr("الحركات", "Entries"),
                    listOf(tr("التاريخ", "Date"), tr("البيان", "Type"), tr("الكمية", "Qty"), tr("مستحق له", "Earned"), tr("مدفوع له", "Paid"), tr("الرصيد", "Balance"), tr("ملاحظات", "Notes")),
                    es.map { e ->
                        val v = Workers.value(w, e)
                        val plus = e.type in listOf(Workers.ATT, Workers.OT, Workers.BONUS)
                        val minus = !plus
                        bal += if (plus) v else -v
                        listOf(
                            Fmt.date(e.date), Workers.entryType(e.type).label + if (e.project.isNotBlank()) " • " + e.project else "",
                            if (e.type == Workers.ATT || e.type == Workers.OT) Fmt.num(e.qty).removeSuffix(".00") else "",
                            if (plus) Fmt.num(v) else "", if (minus) Fmt.num(v) else "", Fmt.num(bal), e.note
                        )
                    },
                    es.map { if (Workers.isPayment(it.type)) 1 else null }
                )
            ),
            listOf(
                tr("إجمالي المستحق", "Total earned") to Fmt.money(sm.due),
                tr("السلف", "Advances") to Fmt.money(sm.advances),
                tr("المدفوع", "Paid") to Fmt.money(sm.paid),
                (if (sm.balance >= 0) tr("المتبقي للعامل", "Owed to worker") else tr("على العامل", "Worker owes")) to Fmt.money(kotlin.math.abs(sm.balance))
            ),
            w.notes, "worker_" + w.name
        )
    }

    // ---------------- الأصول ----------------
    fun assets(list: List<Asset>): ReportDoc {
        val active = list.filter { !it.sold }
        val sold = list.filter { it.sold }
        val cost = active.sumOf { it.buyPrice }
        val value = active.sumOf { Assets.value(it) }
        return ReportDoc(
            tr("تقرير الأصول والاستثمارات", "Assets & investments"), Fmt.date(Fmt.today()),
            listOf(
                tr("عدد الأصول", "Assets") to "${active.size}",
                tr("التكلفة", "Cost") to Fmt.money(cost),
                tr("القيمة الحالية", "Current value") to Fmt.money(value),
                tr("الربح / الخسارة", "Profit / loss") to Fmt.money(value - cost) + if (cost > 0) " (" + ((value - cost) / cost * 100).roundToInt2() + "%)" else "",
                tr("الذهب الخالص", "Pure gold") to String.format(java.util.Locale.US, "%.2f g", active.sumOf { Assets.pureGold(it) }),
                tr("سعر جرام 24", "Gold 24k/g") to (if (Extras.goldPrice24 > 0) Fmt.money(Extras.goldPrice24) else "-")
            ),
            listOf(
                RTable(
                    tr("الأصول الحالية", "Current assets"),
                    listOf(tr("الأصل", "Asset"), tr("النوع", "Type"), tr("الكمية", "Qty"), tr("التكلفة", "Cost"), tr("القيمة", "Value"), tr("الربح", "P/L"), tr("زكوي", "Zakat")),
                    active.map { a ->
                        listOf(a.name, Assets.type(a.type).label + if (a.type == "GOLD") " ${a.karat}" else "", if (a.qty > 0) Fmt.num(a.qty).removeSuffix(".00") + " " + a.unit else "-",
                            Fmt.num(a.buyPrice), Fmt.num(Assets.value(a)), Fmt.num(Assets.profit(a)), if (a.zakatable) "✓" else "")
                    },
                    active.map { if (Assets.profit(it) >= 0) 1 else 2 }
                ),
                RTable(
                    tr("أصول مباعة", "Sold assets"),
                    listOf(tr("الأصل", "Asset"), tr("تاريخ البيع", "Sold on"), tr("التكلفة", "Cost"), tr("سعر البيع", "Sale price"), tr("الربح", "P/L")),
                    sold.map { a -> listOf(a.name, a.sellDate?.let { Fmt.date(it) } ?: "-", Fmt.num(a.buyPrice), Fmt.num(a.sellPrice), Fmt.num(Assets.profit(a))) }
                )
            ),
            listOf(tr("القيمة الحالية", "Current value") to Fmt.money(value), tr("الربح / الخسارة", "Profit / loss") to Fmt.money(value - cost)),
            "", "assets"
        )
    }

    // ---------------- تقسيم المصاريف ----------------
    fun split(g: SplitGroup, members: List<SplitMember>, expenses: List<SplitExpense>, settles: List<SplitSettle>): ReportDoc {
        val mm = members.associateBy { it.id }
        val bal = Split.balances(members, expenses, settles)
        val tr0 = Split.settlements(bal)
        return ReportDoc(
            tr("تقسيم المصاريف", "Shared expenses"), g.name,
            listOf(
                tr("المجموعة", "Group") to g.name,
                tr("الأعضاء", "Members") to "${members.size}",
                tr("إجمالي المصاريف", "Total spent") to Fmt.money(expenses.sumOf { it.amount }),
                tr("نصيب الفرد (بالتساوي)", "Per person (equal)") to Fmt.money(if (members.isNotEmpty()) expenses.sumOf { it.amount } / members.size else 0.0)
            ),
            listOf(
                RTable(
                    tr("أرصدة الأعضاء", "Balances"),
                    listOf(tr("العضو", "Member"), tr("دفع", "Paid"), tr("نصيبه", "Share"), tr("الصافي", "Net")),
                    members.map { m -> listOf(m.name, Fmt.num(Split.spentBy(m.id, expenses)), Fmt.num(Split.shareOf(m.id, expenses)), (if ((bal[m.id] ?: 0.0) > 0) "+" else "") + Fmt.num(bal[m.id] ?: 0.0)) },
                    members.map { m -> val b = bal[m.id] ?: 0.0; if (b > 0.005) 1 else if (b < -0.005) 2 else null }
                ),
                RTable(
                    tr("التسوية المقترحة", "Suggested settlement"),
                    listOf(tr("من", "From"), tr("إلى", "To"), tr("المبلغ", "Amount")),
                    tr0.map { listOf(mm[it.from]?.name ?: "-", mm[it.to]?.name ?: "-", Fmt.num(it.amount)) }
                ),
                RTable(
                    tr("المصاريف", "Expenses"),
                    listOf(tr("التاريخ", "Date"), tr("البيان", "Item"), tr("دفعها", "Paid by"), tr("المبلغ", "Amount"), tr("مقسّمة على", "Split among")),
                    expenses.sortedBy { it.date }.map { e -> listOf(Fmt.date(e.date), e.title, mm[e.payerId]?.name ?: "-", Fmt.num(e.amount), Split.parse(e.shares).keys.mapNotNull { mm[it]?.name }.joinToString("، ")) }
                ),
                RTable(
                    tr("التسويات المدفوعة", "Settlements paid"),
                    listOf(tr("التاريخ", "Date"), tr("من", "From"), tr("إلى", "To"), tr("المبلغ", "Amount")),
                    settles.sortedBy { it.date }.map { s -> listOf(Fmt.date(s.date), mm[s.fromId]?.name ?: "-", mm[s.toId]?.name ?: "-", Fmt.num(s.amount)) }
                )
            ),
            emptyList(), g.notes, "split_" + g.name
        )
    }

    // ---------------- السيارة ----------------
    fun car(v: Vehicle, expenses: List<CarExpense>, reminders: List<CarReminder>, range: LongRange? = null): ReportDoc {
        val es = expenses.filter { it.vehicleId == v.id && (range == null || it.date in range) }.sortedBy { it.date }
        val st = Cars.stats(es)
        return ReportDoc(
            tr("تقرير السيارة", "Vehicle report"), v.name,
            listOf(
                tr("السيارة", "Vehicle") to (v.name + if (v.model.isNotBlank()) " • " + v.model else "") + if (v.year > 0) " ${v.year}" else "",
                tr("اللوحة", "Plate") to v.plate.ifBlank { "-" },
                tr("العداد", "Odometer") to "${v.odometer} " + tr("كم", "km"),
                tr("الفترة", "Period") to (range?.let { Fmt.date(it.first) + " ← " + Fmt.date(it.last) } ?: tr("كامل", "All")),
                tr("إجمالي المصروفات", "Total cost") to Fmt.money(st.total),
                tr("الوقود", "Fuel") to Fmt.money(st.fuel),
                tr("استهلاك الوقود", "Consumption") to if (st.per100 > 0) String.format(java.util.Locale.US, "%.1f L/100km • %.1f km/L", st.per100, st.kmPerLiter) else "-",
                tr("تكلفة الكيلو", "Cost per km") to if (st.costPerKm > 0) Fmt.money(st.costPerKm) else "-"
            ),
            listOf(
                RTable(
                    tr("حسب النوع", "By type"),
                    listOf(tr("النوع", "Type"), tr("العدد", "Count"), tr("المبلغ", "Amount")),
                    es.groupBy { it.type }.map { (k, l) -> listOf(Cars.type(k).label, "${l.size}", Fmt.num(l.sumOf { it.amount })) }
                ),
                RTable(
                    tr("المصروفات", "Expenses"),
                    listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("العداد", "Odometer"), tr("لتر", "Liters"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    es.map { e -> listOf(Fmt.date(e.date), Cars.type(e.type).label, if (e.odometer > 0) "${e.odometer}" else "", if (e.liters > 0) Fmt.num(e.liters) else "", Fmt.num(e.amount), e.note) }
                ),
                RTable(
                    tr("المواعيد والتذكيرات", "Schedules"),
                    listOf(tr("البند", "Item"), tr("الموعد القادم", "Next")),
                    reminders.filter { it.vehicleId == v.id && it.enabled }.map { r -> listOf(r.title, Cars.statusText(r, v.odometer)) },
                    reminders.filter { it.vehicleId == v.id && it.enabled }.map { if (Cars.isDue(it, v.odometer)) 2 else null }
                )
            ),
            listOf(tr("إجمالي المصروفات", "Total") to Fmt.money(st.total)),
            v.notes, "car_" + v.name
        )
    }

    // ---------------- الاشتراكات ----------------
    fun subs(list: List<Subscription>, payments: List<SubPayment>, range: LongRange? = null): ReportDoc {
        val active = list.filter { it.active }
        val sm = list.associateBy { it.id }
        val pays = payments.filter { range == null || it.date in range }.sortedBy { it.date }
        return ReportDoc(
            tr("الاشتراكات والفواتير الدورية", "Subscriptions & bills"), Fmt.date(Fmt.today()),
            listOf(
                tr("الاشتراكات النشطة", "Active") to "${active.size}",
                tr("التكلفة الشهرية", "Monthly cost") to Fmt.money(active.sumOf { Subs.monthly(it) }),
                tr("التكلفة السنوية", "Yearly cost") to Fmt.money(active.sumOf { Subs.yearly(it) }),
                tr("المدفوع في الفترة", "Paid in period") to Fmt.money(pays.sumOf { it.amount })
            ),
            listOf(
                RTable(
                    tr("الاشتراكات", "Subscriptions"),
                    listOf(tr("الاسم", "Name"), tr("النوع", "Type"), tr("المبلغ", "Amount"), tr("الدورية", "Every"), tr("شهرياً", "Monthly"), tr("الموعد القادم", "Next due")),
                    list.map { s -> listOf(s.name, Subs.cat(s.category).label, Fmt.num(s.amount), Rent.periodName(s.periodMonths), Fmt.num(Subs.monthly(s)), if (s.active) Fmt.date(s.nextDate) else tr("موقوف", "Paused")) },
                    list.map { if (!it.active) null else if (Subs.daysLeft(it) < 0) 2 else null }
                ),
                RTable(
                    tr("سجل المدفوعات", "Payments"),
                    listOf(tr("التاريخ", "Date"), tr("الاشتراك", "Subscription"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                    pays.map { p -> listOf(Fmt.date(p.date), sm[p.subId]?.name ?: "-", Fmt.num(p.amount), p.note) }
                )
            ),
            listOf(tr("التكلفة الشهرية", "Monthly cost") to Fmt.money(active.sumOf { Subs.monthly(it) })),
            "", "subscriptions"
        )
    }

    private fun Double.roundToInt2() = kotlin.math.round(this).toInt()
}
