package com.sho3eb.app.core

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone
import com.sho3eb.app.data.AppDao
import com.sho3eb.app.data.Person
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ContactItem(val name: String, val phone: String, val photoUri: String?)

object Contacts {
    fun cleanPhone(p: String): String {
        val sb = StringBuilder()
        for (ch in p) {
            when {
                ch == '+' && sb.isEmpty() -> sb.append(ch)
                ch in '0'..'9' -> sb.append(ch)
                ch in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                ch in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
            }
        }
        return sb.toString()
    }

    /** قراءة جهة اتصال تم اختيارها من شاشة النظام (لا تحتاج صلاحية) */
    fun readPicked(ctx: Context, uri: Uri): ContactItem? = try {
        ctx.contentResolver.query(
            uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.PHOTO_URI), null, null, null
        )?.use { c ->
            if (c.moveToFirst()) ContactItem(c.getString(0) ?: "", cleanPhone(c.getString(1) ?: ""), c.getString(2)) else null
        }
    } catch (e: Exception) {
        null
    }

    /** كل جهات الاتصال (تحتاج صلاحية READ_CONTACTS) */
    fun loadAll(ctx: Context): List<ContactItem> {
        val out = mutableListOf<ContactItem>()
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.PHOTO_URI),
                null, null, Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    out += ContactItem(name, cleanPhone(c.getString(1) ?: ""), c.getString(2))
                }
            }
        } catch (_: Exception) {
        }
        return out.distinctBy { it.name + "|" + it.phone.takeLast(9) }
    }

    /** إضافة جهة الاتصال كشخص أو إرجاع الشخص الموجود بنفس الرقم */
    suspend fun upsert(ctx: Context, dao: AppDao, c: ContactItem): Person = withContext(Dispatchers.IO) {
        if (c.phone.isNotBlank()) {
            val existing = dao.personByPhone(c.phone)
            if (existing != null) return@withContext existing
        }
        val photo = c.photoUri?.let { Photos.copyFromUri(ctx, Uri.parse(it)) }
        val p = Person(name = c.name.ifBlank { c.phone }, phone = c.phone, photoPath = photo)
        p.copy(id = dao.insertPerson(p))
    }
}
