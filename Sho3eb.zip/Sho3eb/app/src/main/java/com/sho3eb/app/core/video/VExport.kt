@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.sho3eb.app.core.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import com.sho3eb.app.core.MediaTools
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** تصدير مشروع المحرر إلى فيديو MP4 على الجهاز */
object VExport {

    /** طبقة ترسم كل ما في الإطار (الصورة بحركتها + النصوص + المؤثرات) لعنصر واحد */
    private class ItemOverlay(private val painter: VPainter, private val index: Int, private val clipStart: Long, private val clipDur: Long) : BitmapOverlay() {
        private val bufs = arrayOf(Bitmap.createBitmap(painter.w, painter.h, Bitmap.Config.ARGB_8888), Bitmap.createBitmap(painter.w, painter.h, Bitmap.Config.ARGB_8888))
        private var k = 0
        private var first = -1L
        private var lastT = Long.MIN_VALUE
        private var last: Bitmap? = null
        override fun getBitmap(presentationTimeUs: Long): Bitmap {
            if (presentationTimeUs == lastT) last?.let { return it }
            if (first < 0) first = presentationTimeUs
            val local = ((presentationTimeUs - first) / 1000).coerceIn(0, clipDur)
            val b = bufs[k]; k = 1 - k
            b.eraseColor(0)
            runCatching { painter.draw(Canvas(b), clipStart + local, index) }
            lastT = presentationTimeUs; last = b
            return b
        }
    }

    private fun baseImage(ctx: Context): File {
        val f = File(File(ctx.cacheDir, "vproj").apply { mkdirs() }, "base.png")
        if (!f.exists()) FileOutputStream(f).use { Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888).apply { eraseColor(0xFF000000.toInt()) }.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f
    }

    /** ملف صمت WAV بالمدة المطلوبة (لتأخير بداية الصوت) */
    private fun silence(ctx: Context, ms: Long): File {
        val f = File(File(ctx.cacheDir, "vproj").apply { mkdirs() }, "sil_$ms.wav")
        if (f.exists()) return f
        val rate = 44100; val ch = 2
        val frames = (ms * rate / 1000).toInt(); val data = frames * ch * 2
        FileOutputStream(f).use { o ->
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(36 + data); h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
            h.putInt(16); h.putShort(1); h.putShort(ch.toShort()); h.putInt(rate); h.putInt(rate * ch * 2); h.putShort((ch * 2).toShort()); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(data)
            o.write(h.array())
            val zero = ByteArray(64 * 1024); var left = data
            while (left > 0) { val n = minOf(left, zero.size); o.write(zero, 0, n); left -= n }
        }
        return f
    }

    private fun volume(v: Float): List<AudioProcessor> {
        if (v in 0.98f..1.02f) return emptyList()
        val p = ChannelMixingAudioProcessor()
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(v))
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
        return listOf(p)
    }

    private fun uriOf(s: String): Uri = if (s.startsWith("/")) Uri.fromFile(File(s)) else Uri.parse(s)

    fun build(ctx: Context, p: VProject): Composition {
        val (w, h) = p.outSize()
        val painter = VPainter(ctx.applicationContext, p, w, h, async = false)
        val base = Uri.fromFile(baseImage(ctx))
        val vids = p.clips.mapIndexed { i, c ->
            val start = p.startOf(i)
            val overlay = OverlayEffect(ImmutableList.of(ItemOverlay(painter, i, start, c.durMs)))
            if (!c.video) {
                EditedMediaItem.Builder(MediaItem.Builder().setUri(base).setImageDurationMs(c.durMs).build())
                    .setFrameRate(30)
                    .setEffects(Effects(emptyList(), listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_STRETCH_TO_FIT), overlay)))
                    .build()
            } else {
                val item = MediaItem.Builder().setUri(uriOf(c.uri)).setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.trimStartMs).setEndPositionMs(c.trimStartMs + c.durMs).build()).build()
                val filt = if (p.filter in setOf("BW", "SEPIA", "WARM", "COOL", "VIVID")) MediaTools.effects(MediaTools.Fx(filter = p.filter, fade = false), c.durMs) else emptyList()
                EditedMediaItem.Builder(item).setRemoveAudio(c.muted)
                    .setEffects(Effects(emptyList(), listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)) + filt + overlay))
                    .build()
            }
        }
        val seqs = mutableListOf(EditedMediaItemSequence(vids))
        val total = p.totalMs
        for (a in p.audios) {
            if (a.startMs >= total || a.lenMs < 200) continue
            val items = mutableListOf<EditedMediaItem>()
            if (a.startMs > 0) items += EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(silence(ctx, a.startMs)))).build()
            var remaining = total - a.startMs
            var firstSeg = true
            while (remaining > 200 && (firstSeg || a.loop) && items.size < 60) {
                val take = minOf(a.lenMs, remaining)
                val mi = MediaItem.Builder().setUri(uriOf(a.uri)).setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setStartPositionMs(a.trimStartMs).setEndPositionMs(a.trimStartMs + take).build()).build()
                items += EditedMediaItem.Builder(mi).setRemoveVideo(true).setEffects(Effects(volume(a.volume), emptyList())).build()
                remaining -= take; firstSeg = false
            }
            if (items.isNotEmpty()) seqs += EditedMediaItemSequence(items)
        }
        val hasAudio = p.audios.isNotEmpty() || p.clips.any { it.video && !it.muted }
        return Composition.Builder(seqs).experimentalSetForceAudioTrack(hasAudio).build()
    }

    /** يبدأ التصدير (من الخيط الرئيسي) */
    fun start(ctx: Context, p: VProject, onDone: (Uri?, String?) -> Unit): MediaTools.Job {
        val out = File(ctx.cacheDir, "export_" + System.currentTimeMillis() + ".mp4")
        val (w, h) = p.outSize()
        val bitrate = when { h * w >= 1920 * 1000 -> 10_000_000; h * w >= 1280 * 700 -> 5_000_000; else -> 2_500_000 }
        val enc = DefaultEncoderFactory.Builder(ctx).setEnableFallback(true)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build()).build()
        val t = Transformer.Builder(ctx).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC).setEncoderFactory(enc)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    val u = MediaTools.publish(ctx, out, false)
                    onDone(u, if (u == null) "save failed" else null)
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    out.delete(); onDone(null, exportException.errorCodeName + ": " + (exportException.message ?: ""))
                }
            }).build()
        t.start(build(ctx, p), out.absolutePath)
        return MediaTools.Job(t, out)
    }
}
