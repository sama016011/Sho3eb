package com.sho3eb.app.core

import android.content.Context
import com.sho3eb.app.data.*
import java.io.File
import java.time.LocalDate

/** تقارير PDF لكل قسم */
object Reports {
    private fun file(ctx: Context, name: String): File {
        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 86_400_000L }?.forEach { it.delete() }
        val safe = name.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").take(40)
        return File(dir, "Sho3eb_${safe}_${System.currentTimeMillis() % 100000}.pdf")
    }

    private fun pb() = PdfBuilder(AppState.isAr)

    // ---------------- الجمعية كاملة ----------------
    fun association(
        ctx: Context, a: Association, members: List<AssocMember>, people: Map<Long, Person>,
        payments: List<AssocPayment>, payouts: List<AssocPayout>
    ): File {
        val rounds = associationRounds(a, members, payments, payouts)
        val sorted = members.sortedBy { it.turnOrder }
        val today = LocalDate.now()
        val b = pb()
        b.title(tr("كشف جمعية: ", "Association statement: ") + a.name)
        b.infoBox(
            listOf(
                tr("قيمة السهم", "Share") to Fmt.money(a.shareAmount),
                tr("عدد الأعضاء", "Members") to "${sorted.size}",
                tr("قيمة القبضة", "Payout") to Fmt.money(a.shareAmount * sorted.size),
                tr("المدة", "Period") to Fmt.periodLabel(a.periodType, a.periodCount),
                tr("البداية", "Start") to Fmt.date(a.startDate),
                tr("النهاية", "End") to (rounds.lastOrNull()?.let { Fmt.date(it.due) } ?: "-"),
                tr("المحصّل", "Collected") to Fmt.money(payments.sumOf { it.amount }),
                tr("الدورات المسلّمة", "Rounds delivered") to "${rounds.count { it.payout != null }}/${rounds.size}"
            )
        )
        b.section(tr("جدول الدورات", "Rounds"))
        b.table(
            listOf("#", tr("الموعد", "Due"), tr("المستلم", "Recipient"), tr("المحصّل", "Collected"), tr("الحالة", "Status")),
            rounds.map { r ->
                listOf(
                    "${r.round + 1}", Fmt.date(r.due), people[r.recipient.personId]?.name ?: "-",
                    "${Fmt.num(r.collected)} / ${Fmt.num(r.expected)}",
                    when {
                        r.payout != null -> tr("تم التسليم ", "Delivered ") + Fmt.date(r.payout.date)
                        r.allPaid -> tr("مكتمل - بانتظار التسليم", "Complete - pending delivery")
                        r.due.isBefore(today) -> tr("متأخر", "Late")
                        else -> tr("قادمة", "Upcoming")
                    }
                )
            },
            listOf(0.5f, 1.3f, 2f, 1.6f, 2f),
            rounds.map { r ->
                when {
                    r.payout != null -> PdfBuilder.PAID
                    r.due.isBefore(today) && !r.allPaid -> PdfBuilder.LATE
                    else -> null
                }
            }
        )
        b.section(tr("الأعضاء", "Members"))
        b.table(
            listOf(tr("الدور", "Turn"), tr("الاسم", "Name"), tr("الجوال", "Phone"), tr("دفعات", "Paid rounds"), tr("إجمالي المدفوع", "Total paid"), tr("المتأخر", "Late")),
            sorted.mapIndexed { i, m ->
                val mp = payments.filter { it.memberId == m.id }
                val late = rounds.count { r -> !r.due.isAfter(today) && m.id !in r.paidMemberIds }
                listOf(
                    "${i + 1}", people[m.personId]?.name ?: "-", people[m.personId]?.phone ?: "",
                    "${mp.size}/${rounds.size}", Fmt.num(mp.sumOf { it.amount }), if (late > 0) "$late" else "-"
                )
            },
            listOf(0.6f, 2f, 1.6f, 1f, 1.3f, 0.8f)
        )
        if (a.notes.isNotBlank()) {
            b.section(tr("ملاحظات", "Notes")); b.text(a.notes)
        }
        return b.save(file(ctx, a.name))
    }

    // ---------------- كشف عضو في جمعية ----------------
    fun member(
        ctx: Context, a: Association, member: AssocMember, members: List<AssocMember>, people: Map<Long, Person>,
        payments: List<AssocPayment>, payouts: List<AssocPayout>
    ): File {
        val rounds = associationRounds(a, members, payments, payouts)
        val p = people[member.personId]
        val today = LocalDate.now()
        val myTurn = rounds.firstOrNull { it.recipient.id == member.id }
        val b = pb()
        b.title(tr("كشف حساب عضو", "Member statement"))
        b.infoBox(
            listOf(
                tr("الاسم", "Name") to (p?.name ?: "-"),
                tr("الجمعية", "Association") to a.name,
                tr("قيمة السهم", "Share") to Fmt.money(a.shareAmount),
                tr("دورك في الاستلام", "Your turn") to (myTurn?.let { "${it.round + 1} - ${Fmt.date(it.due)}" } ?: "-"),
                tr("قيمة القبضة", "Payout") to Fmt.money(a.shareAmount * members.size),
                tr("حالة الاستلام", "Received") to (myTurn?.payout?.let { tr("تم ", "Yes ") + Fmt.date(it.date) } ?: tr("لم يتم", "Not yet"))
            )
        )
        b.table(
            listOf("#", tr("الموعد", "Due"), tr("المبلغ", "Amount"), tr("الحالة", "Status"), tr("تاريخ الدفع", "Paid on")),
            rounds.map { r ->
                val pay = payments.firstOrNull { it.memberId == member.id && it.round == r.round }
                listOf(
                    "${r.round + 1}", Fmt.date(r.due), Fmt.num(a.shareAmount),
                    when {
                        pay != null -> tr("مدفوع", "Paid")
                        r.due.isBefore(today) -> tr("متأخر", "Late")
                        else -> tr("قادم", "Upcoming")
                    },
                    pay?.let { Fmt.date(it.date) } ?: "-"
                )
            },
            listOf(0.5f, 1.4f, 1.2f, 1.2f, 1.4f),
            rounds.map { r ->
                val paid = payments.any { it.memberId == member.id && it.round == r.round }
                if (paid) PdfBuilder.PAID else if (r.due.isBefore(today)) PdfBuilder.LATE else null
            }
        )
        val paidTotal = payments.filter { it.memberId == member.id }.sumOf { it.amount }
        b.totals(
            listOf(
                tr("إجمالي المدفوع", "Total paid") to Fmt.money(paidTotal),
                tr("المتبقي", "Remaining") to Fmt.money((a.shareAmount * rounds.size - paidTotal).coerceAtLeast(0.0))
            )
        )
        return b.save(file(ctx, (p?.name ?: "member") + "_" + a.name))
    }

    // ---------------- كشف سلفة ----------------
    fun loan(ctx: Context, person: Person, txs: List<LoanTx>): File {
        val b = pb()
        val taken = txs.filter { it.type == LoanTx.LOAN }.sumOf { it.amount }
        val paid = txs.filter { it.type == LoanTx.PAY }.sumOf { it.amount }
        b.title(tr("كشف حساب سلفة", "Loan statement"))
        b.infoBox(
            listOf(
                tr("الاسم", "Name") to person.name,
                tr("الجوال", "Phone") to person.phone.ifBlank { "-" },
                tr("إجمالي السلف", "Total borrowed") to Fmt.money(taken),
                tr("إجمالي المسدد", "Total repaid") to Fmt.money(paid),
                tr("الرصيد المتبقي", "Balance") to Fmt.money(taken - paid),
                tr("عدد الحركات", "Transactions") to "${txs.size}"
            )
        )
        var bal = 0.0
        val rows = txs.map { t ->
            bal += if (t.type == LoanTx.LOAN) t.amount else -t.amount
            listOf(
                Fmt.date(t.date),
                if (t.type == LoanTx.LOAN) tr("سلفة", "Loan") else tr("سداد", "Repayment"),
                if (t.type == LoanTx.LOAN) Fmt.num(t.amount) else "-",
                if (t.type == LoanTx.PAY) Fmt.num(t.amount) else "-",
                Fmt.num(bal),
                t.note + (t.dueDate?.let { (if (t.note.isBlank()) "" else " • ") + tr("استحقاق ", "due ") + Fmt.date(it) } ?: "")
            )
        }
        b.table(
            listOf(tr("التاريخ", "Date"), tr("النوع", "Type"), tr("سلفة", "Loan"), tr("سداد", "Paid"), tr("الرصيد", "Balance"), tr("ملاحظات", "Notes")),
            rows, listOf(1.2f, 0.9f, 1f, 1f, 1.1f, 2f),
            txs.map { if (it.type == LoanTx.PAY) PdfBuilder.PAID else null }
        )
        b.totals(listOf(tr("الرصيد المتبقي", "Outstanding balance") to Fmt.money(taken - paid)))
        if (person.notes.isNotBlank()) {
            b.section(tr("ملاحظات", "Notes")); b.text(person.notes)
        }
        return b.save(file(ctx, "loan_" + person.name))
    }

    // ---------------- كشف بيع بالتقسيط ----------------
    fun sale(ctx: Context, s: Sale, person: Person?, payments: List<SalePayment>): File {
        val sch = saleSchedule(s, payments)
        val today = LocalDate.now()
        val paid = payments.sumOf { it.amount }
        val b = pb()
        b.title(tr("كشف بيع بالتقسيط", "Installment sale statement"))
        b.infoBox(
            listOf(
                tr("العميل", "Customer") to (person?.name ?: "-"),
                tr("الجوال", "Phone") to (person?.phone?.ifBlank { "-" } ?: "-"),
                tr("المنتج", "Product") to s.product,
                tr("السعر الإجمالي", "Total price") to Fmt.money(s.totalPrice),
                tr("الدفعة المقدمة", "Down payment") to Fmt.money(s.downPayment),
                tr("عدد الأقساط", "Installments") to "${s.installmentsCount} • ${Fmt.periodLabel(s.periodType, s.periodCount)}",
                tr("قيمة القسط", "Installment") to Fmt.money(installmentAmount(s)),
                tr("المتبقي", "Remaining") to Fmt.money(saleRemaining(s, payments))
            )
        )
        b.section(tr("جدول الأقساط", "Schedule"))
        b.table(
            listOf("#", tr("الاستحقاق", "Due"), tr("القسط", "Amount"), tr("المدفوع", "Paid"), tr("المتبقي", "Remaining"), tr("الحالة", "Status")),
            sch.map { i ->
                listOf(
                    "${i.index + 1}", Fmt.date(i.due), Fmt.num(i.amount), Fmt.num(i.paid), Fmt.num(i.remaining),
                    when {
                        i.isPaid -> tr("مدفوع", "Paid")
                        i.paid > 0 -> tr("جزئي", "Partial")
                        i.due.isBefore(today) -> tr("متأخر", "Late")
                        else -> tr("قادم", "Upcoming")
                    }
                )
            },
            listOf(0.5f, 1.3f, 1.1f, 1.1f, 1.1f, 1f),
            sch.map { i ->
                when {
                    i.isPaid -> PdfBuilder.PAID
                    i.paid > 0 -> PdfBuilder.PARTIAL
                    i.due.isBefore(today) -> PdfBuilder.LATE
                    else -> null
                }
            }
        )
        if (payments.isNotEmpty()) {
            b.section(tr("سجل الدفعات", "Payments"))
            b.table(
                listOf(tr("التاريخ", "Date"), tr("المبلغ", "Amount"), tr("ملاحظات", "Notes")),
                payments.map { listOf(Fmt.date(it.date), Fmt.num(it.amount), it.note) },
                listOf(1.2f, 1.2f, 3f)
            )
        }
        b.totals(
            listOf(
                tr("إجمالي المدفوع (مع المقدم)", "Total paid (incl. down payment)") to Fmt.money(paid + s.downPayment),
                tr("المتبقي", "Remaining") to Fmt.money(saleRemaining(s, payments))
            )
        )
        if (s.notes.isNotBlank()) {
            b.section(tr("ملاحظات", "Notes")); b.text(s.notes)
        }
        return b.save(file(ctx, s.product + "_" + (person?.name ?: "")))
    }

    // ---------------- كشف حساب ----------------
    /** كشف حساب لفترة (from/to اختياريان) مع الرصيد الافتتاحي */
    fun account(ctx: Context, a: Account, person: Person?, txs: List<AccountTx>, from: Long? = null, to: Long? = null): File {
        val lines = accountLines(txs)
        val inRange = lines.filter { l -> (from == null || l.tx.date >= from) && (to == null || l.tx.date <= to) }
        val opening = lines.lastOrNull { from != null && it.tx.date < from }?.after ?: 0.0
        val closing = inRange.lastOrNull()?.after ?: opening
        val totalIn = inRange.filter { it.tx.type == AccountTx.IN }.sumOf { it.tx.amount }
        val totalOut = inRange.filter { it.tx.type == AccountTx.OUT }.sumOf { it.tx.amount }
        val b = pb()
        b.title(tr("كشف حساب: ", "Account statement: ") + a.name)
        b.infoBox(
            listOf(
                tr("الحساب", "Account") to a.name,
                tr("جهة الاتصال", "Contact") to (person?.let { it.name + if (it.phone.isNotBlank()) " - " + it.phone else "" } ?: "-"),
                tr("الفترة", "Period") to ((from?.let { Fmt.date(it) } ?: tr("البداية", "Start")) + "  ←  " + (to?.let { Fmt.date(it) } ?: tr("اليوم", "Today"))),
                tr("الرصيد الافتتاحي", "Opening balance") to Fmt.money(opening),
                tr("إجمالي الإضافات", "Total deposits") to Fmt.money(totalIn),
                tr("إجمالي المصروفات", "Total withdrawals") to Fmt.money(totalOut),
                tr("عدد الحركات", "Transactions") to "${inRange.size}",
                tr("الرصيد الختامي", "Closing balance") to Fmt.money(closing)
            )
        )
        b.table(
            listOf("#", tr("التاريخ", "Date"), tr("إضافة", "Deposit"), tr("صرف", "Withdrawal"), tr("الرصيد", "Balance"), tr("ملاحظات", "Notes")),
            inRange.mapIndexed { i, l ->
                listOf(
                    "${i + 1}", Fmt.date(l.tx.date),
                    if (l.tx.type == AccountTx.IN) Fmt.num(l.tx.amount) else "-",
                    if (l.tx.type == AccountTx.OUT) Fmt.num(l.tx.amount) else "-",
                    Fmt.num(l.after), l.tx.note
                )
            },
            listOf(0.5f, 1.2f, 1.1f, 1.1f, 1.2f, 2.4f),
            inRange.map { if (it.tx.type == AccountTx.IN) PdfBuilder.PAID else PdfBuilder.LATE }
        )
        b.totals(listOf(tr("الرصيد الختامي", "Closing balance") to Fmt.money(closing)))
        if (a.notes.isNotBlank()) {
            b.section(tr("ملاحظات", "Notes")); b.text(a.notes)
        }
        return b.save(file(ctx, "account_" + a.name))
    }

    /** إشعار بحركة واحدة */
    fun accountTx(ctx: Context, a: Account, person: Person?, line: AccountLine): File {
        val t = line.tx
        val isIn = t.type == AccountTx.IN
        val b = pb()
        b.title(if (isIn) tr("إشعار إضافة مبلغ", "Deposit receipt") else tr("إشعار صرف مبلغ", "Withdrawal receipt"))
        b.infoBox(
            listOf(
                tr("رقم الحركة", "Transaction no.") to "#${t.id}",
                tr("التاريخ", "Date") to Fmt.date(t.date),
                tr("الحساب", "Account") to a.name,
                tr("جهة الاتصال", "Contact") to (person?.name ?: "-"),
                tr("نوع الحركة", "Type") to (if (isIn) tr("إضافة", "Deposit") else tr("صرف", "Withdrawal")),
                tr("المبلغ", "Amount") to Fmt.money(t.amount),
                tr("الرصيد قبل الحركة", "Balance before") to Fmt.money(line.before),
                tr("الرصيد بعد الحركة", "Balance after") to Fmt.money(line.after)
            )
        )
        if (t.note.isNotBlank()) {
            b.section(tr("ملاحظات", "Notes")); b.text(t.note, 12f)
        }
        b.spacer(30f)
        b.text(tr("التوقيع: ....................................", "Signature: ...................................."))
        return b.save(file(ctx, "tx${t.id}_" + a.name))
    }
}
