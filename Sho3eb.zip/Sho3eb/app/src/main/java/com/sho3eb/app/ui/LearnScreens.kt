@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** إدخال صوتي بلغة محددة */
@Composable
fun rememberSpeechInput(onResult: (String) -> Unit): (String) -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(onResult)
    }
    return { tag ->
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, tr("تحدث الآن…", "Speak now…"))
        runCatching { launcher.launch(i) }.onFailure { toast(ctx, tr("التعرف على الصوت غير متاح. ثبّت تطبيق Google.", "Speech recognition unavailable. Install the Google app.")) }
    }
}

private fun copyTxt(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("text", text))
    toast(ctx, tr("تم النسخ", "Copied"))
}

private fun shareTxt(ctx: Context, text: String) {
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), tr("إرسال", "Send")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

// =====================================================================
//                              الواجهة الرئيسية
// =====================================================================
@Composable
fun LearnScreen(nav: NavController) {
    val ctx = LocalContext.current
    val data = remember { runCatching { Course.load(ctx) }.getOrNull() }
    val done = remember { Course.done }
    ScreenScaffold(title = tr("التعلم والترجمة", "Learn & translate"), onBack = { nav.popBackStack() }) { p ->
        Column(Modifier.padding(p).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            HubCard("🌐", tr("المترجم الفوري", "Instant translator"), tr("نص أو صوت بين ${Translate.langs.size} لغة، الرد نصاً أو صوتاً، نسخ وإرسال النص والصوت، ووضع المحادثة", "Text or voice across ${Translate.langs.size} languages, spoken replies, copy & send text/audio, conversation mode")) { nav.navigate("translate") }
            val total = data?.second?.size ?: 0
            HubCard("🎓", tr("كورس الإنجليزية من الصفر للاحتراف", "English course: zero to pro"),
                tr("${done.size} من $total درساً • 🔥 ${Course.streak} يوم متتالي", "${done.size}/$total lessons • 🔥 ${Course.streak}-day streak"), progress = if (total > 0) done.size.toFloat() / total else 0f) { nav.navigate("course") }
            HubCard("🎭", tr("محادثات المواقف", "Role-play situations"), tr("طبيب، محامٍ، سائق، طالب، مطعم، معرض سيارات، سنترال، بائع خضار، طيار وغيرها", "Doctor, lawyer, driver, student, restaurant, showroom, operator, greengrocer, pilot & more")) { nav.navigate("roleplay") }
            data?.second?.flatMap { it.words }?.let { all ->
                if (all.isNotEmpty()) {
                    val w = remember { all[(Fmt.today() % all.size).toInt()] }
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("💡 كلمة اليوم", "💡 Word of the day"), style = MaterialTheme.typography.labelMedium)
                                Text(w.en, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                                Text(w.ar + if (w.say.isNotBlank()) "  •  " + w.say else "")
                            }
                            IconButton(onClick = { Speaker.speak(ctx, w.en, "en-US") }) { Icon(Icons.Filled.VolumeUp, null) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HubCard(emoji: String, title: String, sub: String, progress: Float? = null, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 36.sp); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(sub, style = MaterialTheme.typography.bodySmall)
                if (progress != null) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

// =====================================================================
//                                  المترجم
// =====================================================================
private data class Bubble(val left: Boolean, val text: String, val translated: String, val lang: String, val tlang: String)

@Composable
fun TranslateScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var src by remember { mutableStateOf(Translate.src) }
    var dst by remember { mutableStateOf(Translate.dst) }
    var input by rememberSaveable { mutableStateOf("") }
    var output by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var autoSpeak by remember { mutableStateOf(Extras.b("tr_autospeak", false)) }
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var pickFor by remember { mutableStateOf(0) }
    var showHist by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val bubbles = remember { mutableStateListOf<Bubble>() }
    var convSide by remember { mutableStateOf(true) }
    DisposableEffect(Unit) { Speaker.init(ctx); onDispose { Speaker.stop() } }

    fun run(text: String, speak: Boolean = autoSpeak) {
        job?.cancel()
        if (text.isBlank()) { output = ""; return }
        job = scope.launch {
            busy = true; status = ""
            if (!Translate.isDownloaded(src) || !Translate.isDownloaded(dst)) status = tr("⏬ تنزيل حزمة اللغة لأول مرة (تعمل بعدها بدون إنترنت)…", "⏬ Downloading language pack once (works offline after)…")
            try {
                output = Translate.translate(text, src, dst)
                status = ""
                Translate.addHistory(Translate.Hist(text, output, src, dst, System.currentTimeMillis()))
                if (speak) Speaker.speak(ctx, output, Translate.lang(dst).speech)
            } catch (e: Exception) {
                status = tr("تعذرت الترجمة: تأكد من الاتصال بالإنترنت لتنزيل حزمة اللغة أول مرة.", "Translation failed: connect to the internet to download the language pack first.")
            }
            busy = false
        }
    }
    val mic = rememberSpeechInput { said -> input = said; run(said, true) }
    val convMic = rememberSpeechInput { said ->
        val from = if (convSide) src else dst; val to = if (convSide) dst else src
        val left = convSide
        scope.launch {
            busy = true
            val t = runCatching { Translate.translate(said, from, to) }.getOrElse { tr("⚠️ تعذرت الترجمة", "⚠️ Translation failed") }
            bubbles.add(Bubble(left, said, t, from, to))
            busy = false
            Speaker.speak(ctx, t, Translate.lang(to).speech)
        }
    }
    LaunchedEffect(input, src, dst) { if (mode == 0 && input.isNotBlank()) { delay(900); run(input, false) } }

    ScreenScaffold(title = tr("المترجم", "Translator"), onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { showHist = true }) { Icon(Icons.Filled.History, null) }
    }) { p ->
        Column(Modifier.padding(p).fillMaxSize()) {
            TabRow(mode) {
                Tab(mode == 0, { mode = 0 }, text = { Text(tr("✍️ نص وصوت", "✍️ Text & voice")) })
                Tab(mode == 1, { mode = 1 }, text = { Text(tr("🗣️ محادثة", "🗣️ Conversation")) })
            }
            Row(Modifier.fillMaxWidth().padding(12.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pickFor = 1 }, modifier = Modifier.weight(1f)) { Text(Translate.lang(src).flag + " " + Translate.lang(src).label, maxLines = 1) }
                IconButton(onClick = { val t = src; src = dst; dst = t; Translate.src = src; Translate.dst = dst; if (output.isNotBlank()) { input = output; output = "" } }) { Icon(Icons.Filled.SwapHoriz, null) }
                OutlinedButton(onClick = { pickFor = 2 }, modifier = Modifier.weight(1f)) { Text(Translate.lang(dst).flag + " " + Translate.lang(dst).label, maxLines = 1) }
            }
            if (status.isNotBlank()) Text(status, Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall, color = if (status.startsWith("⏬")) MaterialTheme.colorScheme.primary else DangerRed)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))
            if (mode == 0) Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        OutlinedTextField(input, { input = it }, placeholder = { Text(tr("اكتب أو اضغط الميكروفون للتحدث", "Type or tap the mic to speak")) }, minLines = 3,
                            textStyle = TextStyle(fontSize = 18.sp, textDirection = TextDirection.Content), modifier = Modifier.fillMaxWidth())
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FilledIconButton(onClick = { mic(Translate.lang(src).speech) }) { Icon(Icons.Filled.Mic, null) }
                            IconButton(onClick = { Speaker.speak(ctx, input, Translate.lang(src).speech) }, enabled = input.isNotBlank()) { Icon(Icons.Filled.VolumeUp, null) }
                            IconButton(onClick = { scope.launch { Translate.detect(input)?.let { d -> if (d != src && Translate.langs.any { it.code == d }) { src = d; Translate.src = d; toast(ctx, tr("تم اكتشاف: ", "Detected: ") + Translate.lang(d).label) } } } }, enabled = input.isNotBlank()) { Icon(Icons.Filled.TravelExplore, null) }
                            Spacer(Modifier.weight(1f))
                            if (input.isNotBlank()) IconButton(onClick = { input = ""; output = "" }) { Icon(Icons.Filled.Clear, null) }
                            Button(onClick = { run(input, autoSpeak) }, enabled = input.isNotBlank() && !busy) { Text(tr("ترجم", "Translate")) }
                        }
                    }
                }
                if (output.isNotBlank()) Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(Translate.lang(dst).flag + " " + Translate.lang(dst).label, style = MaterialTheme.typography.labelMedium)
                        Text(output, fontSize = 20.sp, style = TextStyle(textDirection = TextDirection.Content))
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { Speaker.speak(ctx, output, Translate.lang(dst).speech) }) { Icon(Icons.Filled.VolumeUp, null) }
                            IconButton(onClick = { Speaker.speak(ctx, output, Translate.lang(dst).speech, slow = true) }) { Icon(Icons.Filled.SlowMotionVideo, null) }
                            IconButton(onClick = { copyTxt(ctx, output) }) { Icon(Icons.Filled.ContentCopy, null) }
                            IconButton(onClick = { shareTxt(ctx, output) }) { Icon(Icons.Filled.Share, null) }
                            IconButton(onClick = {
                                scope.launch {
                                    val f = Speaker.toFile(ctx, output, Translate.lang(dst).speech)
                                    if (f != null) Share.shareFile(ctx, f, "audio/wav", null, false) else toast(ctx, tr("تعذر إنشاء الملف الصوتي", "Couldn't create audio"))
                                }
                            }) { Icon(Icons.Filled.AudioFile, null) }
                            IconButton(onClick = { Edition.open(ctx, "https://wa.me/?text=" + android.net.Uri.encode(output)) }) { Icon(Icons.Filled.Chat, null) }
                        }
                    }
                }
                SwitchRow(tr("نطق الترجمة تلقائياً بعد الإدخال الصوتي", "Speak translation after voice input"), null, autoSpeak, Icons.Filled.RecordVoiceOver) { autoSpeak = it; Extras.pb("tr_autospeak", it) }
                Text(tr("💡 الترجمة تعمل على جهازك بعد تنزيل حزمة كل لغة مرة واحدة (حوالي 30 ميجا). النطق والتعرف على الصوت يستخدمان محركات Google في هاتفك.",
                    "💡 Translation runs on-device after a one-time ~30MB pack per language. Speech uses your phone's Google engines."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else Column(Modifier.weight(1f)) {
                val ls = rememberLazyListState()
                LaunchedEffect(bubbles.size) { if (bubbles.isNotEmpty()) ls.animateScrollToItem(bubbles.size - 1) }
                LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (bubbles.isEmpty()) item { InfoBanner(tr("ضع الهاتف بينك وبين الطرف الآخر. اضغط زر لغتك وتحدث، وسيترجم التطبيق وينطق الترجمة للطرف الآخر، ثم يضغط هو زر لغته ويرد.", "Put the phone between you. Tap your language and speak; the app translates and speaks it. The other person replies with their button.")) }
                    items(bubbles) { b ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (b.left) Arrangement.Start else Arrangement.End) {
                            Card(Modifier.fillMaxWidth(0.85f), colors = CardDefaults.cardColors(containerColor = if (b.left) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(b.text, style = MaterialTheme.typography.bodySmall)
                                    Text(b.translated, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                    Row {
                                        IconButton(onClick = { Speaker.speak(ctx, b.translated, Translate.lang(b.tlang).speech) }) { Icon(Icons.Filled.VolumeUp, null) }
                                        IconButton(onClick = { copyTxt(ctx, b.translated) }) { Icon(Icons.Filled.ContentCopy, null) }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { convSide = true; convMic(Translate.lang(src).speech) }, modifier = Modifier.weight(1f).height(60.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
                        Icon(Icons.Filled.Mic, null); Spacer(Modifier.width(4.dp)); Text(Translate.lang(src).flag + " " + Translate.lang(src).label, maxLines = 1)
                    }
                    Button(onClick = { convSide = false; convMic(Translate.lang(dst).speech) }, modifier = Modifier.weight(1f).height(60.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)) {
                        Icon(Icons.Filled.Mic, null); Spacer(Modifier.width(4.dp)); Text(Translate.lang(dst).flag + " " + Translate.lang(dst).label, maxLines = 1)
                    }
                }
                if (bubbles.isNotEmpty()) TextButton(onClick = {
                    shareTxt(ctx, bubbles.joinToString("\n\n") { it.text + "\n→ " + it.translated })
                }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(4.dp)); Text(tr("مشاركة المحادثة", "Share conversation")) }
            }
        }
    }
    if (pickFor != 0) LangPickerDialog(if (pickFor == 1) src else dst, onDismiss = { pickFor = 0 }) { c ->
        if (pickFor == 1) { src = c; Translate.src = c } else { dst = c; Translate.dst = c }
        pickFor = 0
    }
    if (showHist) {
        var h by remember { mutableStateOf(Translate.history) }
        AlertDialog(onDismissRequest = { showHist = false }, title = { Text(tr("سجل الترجمة", "History")) }, text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                if (h.isEmpty()) item { Text(tr("لا يوجد سجل بعد", "No history yet")) }
                items(h) { x ->
                    Column(Modifier.fillMaxWidth().clickable { src = x.src; dst = x.dst; input = x.s; output = x.t; showHist = false }.padding(vertical = 8.dp)) {
                        Text(Translate.lang(x.src).flag + " " + x.s, maxLines = 2)
                        Text(Translate.lang(x.dst).flag + " " + x.t, fontWeight = FontWeight.Bold, maxLines = 2)
                    }
                    HorizontalDivider()
                }
            }
        }, confirmButton = { TextButton(onClick = { showHist = false }) { Text(tr("إغلاق", "Close")) } },
            dismissButton = { TextButton(onClick = { Translate.history = emptyList(); h = emptyList() }) { Text(tr("مسح السجل", "Clear")) } })
    }
}

@Composable
private fun LangPickerDialog(current: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var dl by remember { mutableStateOf<Set<String>>(emptySet()) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { dl = Translate.downloaded() }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("اختر اللغة", "Choose language")) }, text = {
        Column {
            SearchField(q) { q = it }
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(Translate.langs.filter { q.isBlank() || it.label.contains(q, true) || it.en.contains(q, true) }, key = { it.code }) { l ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(l.code) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(l.code == current, { onPick(l.code) })
                        Text(l.flag + "  " + l.label, Modifier.weight(1f))
                        if (l.code in dl) {
                            Text("✓ " + tr("بدون نت", "offline"), style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                            if (l.code != "en") IconButton(onClick = { scope.launch { Translate.deleteModel(l.code); dl = Translate.downloaded() } }) { Icon(Icons.Filled.Delete, null, tint = WarnAmber) }
                        }
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } })
}

// =====================================================================
//                              كورس الإنجليزية
// =====================================================================
@Composable
fun CourseScreen(nav: NavController) {
    val ctx = LocalContext.current
    val data = remember { runCatching { Course.load(ctx) }.getOrNull() }
    val done = remember { Course.done }
    ScreenScaffold(title = tr("كورس الإنجليزية", "English course"), onBack = { nav.popBackStack() }) { p ->
        if (data == null) { Box(Modifier.padding(p)) { Text(tr("تعذر تحميل المحتوى", "Couldn't load content")) }; return@ScreenScaffold }
        val (levels, lessons, _) = data
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(16.dp)) {
                        val on = MaterialTheme.colorScheme.onPrimary
                        Text(tr("رحلتك من الصفر إلى الاحتراف", "Your journey from zero to pro"), color = on, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(tr("${done.size} من ${lessons.size} درساً مكتملاً • 🔥 ${Course.streak} يوم", "${done.size}/${lessons.size} lessons done • 🔥 ${Course.streak} days"), color = on)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { if (lessons.isEmpty()) 0f else done.size.toFloat() / lessons.size }, modifier = Modifier.fillMaxWidth(), color = on, trackColor = on.copy(alpha = 0.3f))
                        val next = lessons.firstOrNull { it.id !in done }
                        if (next != null) {
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { nav.navigate("lesson/${next.id}") }, colors = ButtonDefaults.buttonColors(containerColor = on, contentColor = MaterialTheme.colorScheme.primary)) {
                                Text(tr("تابع: ", "Continue: ") + next.title)
                            }
                        }
                    }
                }
            }
            levels.forEach { lv ->
                val ls = lessons.filter { it.level == lv.n }
                val prevDone = lessons.filter { it.level < lv.n }.all { it.id in done }
                item {
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(lv.emoji, fontSize = 26.sp); Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tr("المستوى ${lv.n}: ", "Level ${lv.n}: ") + tr(lv.name, lv.nameEn), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(lv.desc, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("${ls.count { it.id in done }}/${ls.size}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    if (!prevDone) Text(tr("💡 يُنصح بإنهاء المستويات السابقة أولاً", "💡 Finishing previous levels first is recommended"), style = MaterialTheme.typography.labelSmall, color = WarnAmber)
                }
                items(ls, key = { it.id }) { l ->
                    val sc = Course.score(l.id)
                    Card(onClick = { nav.navigate("lesson/${l.id}") }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(36.dp).background(if (l.id in done) SuccessGreen else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                                Text(if (l.id in done) "✓" else l.id.substringAfter("-"), fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(l.title, fontWeight = FontWeight.Bold)
                                Text(l.titleEn + " • " + l.goal, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            }
                            if (sc >= 0) Text("$sc%", color = if (sc >= 67) SuccessGreen else WarnAmber, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LessonScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    val data = remember { runCatching { Course.load(ctx) }.getOrNull() }
    val l = data?.second?.firstOrNull { it.id == id }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var practiceTarget by remember { mutableStateOf<String?>(null) }
    var lastScore by remember { mutableStateOf<Pair<String, Int>?>(null) }
    DisposableEffect(Unit) { Speaker.init(ctx); onDispose { Speaker.stop() } }
    val mic = rememberSpeechInput { said -> practiceTarget?.let { t -> lastScore = said to Course.similarity(said, t) } }
    if (l == null) { ScreenScaffold(title = "…", onBack = { nav.popBackStack() }) { }; return }

    ScreenScaffold(title = l.title, onBack = { nav.popBackStack() }) { p ->
        Column(Modifier.padding(p)) {
            ScrollableTabRow(tab, edgePadding = 8.dp) {
                listOf(tr("📖 الكلمات", "📖 Words"), tr("💬 العبارات", "💬 Phrases"), tr("📐 القاعدة", "📐 Grammar"), tr("✅ الاختبار", "✅ Quiz")).forEachIndexed { i, t ->
                    Tab(tab == i, { tab = i }, text = { Text(t) })
                }
            }
            lastScore?.let { (said, sc) ->
                Card(Modifier.fillMaxWidth().padding(12.dp, 8.dp), colors = CardDefaults.cardColors(containerColor = if (sc >= 80) SuccessGreen.copy(alpha = 0.2f) else WarnAmber.copy(alpha = 0.2f))) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tr("قلت: ", "You said: ") + said)
                            Text(when { sc >= 90 -> tr("ممتاز! 🌟", "Excellent! 🌟"); sc >= 70 -> tr("جيد جداً 👍", "Very good 👍"); sc >= 40 -> tr("قريب، حاول مرة أخرى", "Close, try again"); else -> tr("استمع وأعد المحاولة", "Listen and try again") } + "  $sc%", fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { lastScore = null }) { Icon(Icons.Filled.Close, null) }
                    }
                }
            }
            when (tab) {
                0, 1 -> LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (tab == 0) item { Text("🎯 " + l.goal, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
                    items(if (tab == 0) l.words else l.phrases + l.examples) { w ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(w.en, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.fillMaxWidth()) }
                                    Text(w.ar)
                                    if (w.say.isNotBlank()) Text("🔊 " + w.say, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { Speaker.speak(ctx, w.en, "en-US") }) { Icon(Icons.Filled.VolumeUp, null) }
                                IconButton(onClick = { Speaker.speak(ctx, w.en, "en-US", slow = true) }) { Icon(Icons.Filled.SlowMotionVideo, null) }
                                IconButton(onClick = { practiceTarget = w.en; mic("en-US") }) { Icon(Icons.Filled.Mic, null, tint = MaterialTheme.colorScheme.primary) }
                            }
                        }
                    }
                }
                2 -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Text(l.grammar, Modifier.padding(16.dp), fontSize = 17.sp, lineHeight = 28.sp)
                    }
                    SectionTitle(tr("أمثلة", "Examples"))
                    l.examples.forEach { w ->
                        Row(Modifier.fillMaxWidth().clickable { Speaker.speak(ctx, w.en, "en-US") }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.VolumeUp, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                            Column { Text(w.en, fontWeight = FontWeight.SemiBold); Text(w.ar, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
                else -> QuizPane(l) { score ->
                    Course.setScore(l.id, score); Course.touchStreak()
                    if (score >= 67) Course.done = Course.done + l.id
                }
            }
            val all = data!!.second
            val idx = all.indexOfFirst { it.id == id }
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                if (idx > 0) TextButton(onClick = { nav.navigate("lesson/${all[idx - 1].id}") { popUpTo("course") } }) { Text(tr("→ السابق", "← Previous")) } else Spacer(Modifier.width(1.dp))
                if (idx < all.size - 1) TextButton(onClick = { nav.navigate("lesson/${all[idx + 1].id}") { popUpTo("course") } }) { Text(tr("التالي ←", "Next →")) }
            }
        }
    }
}

@Composable
private fun ColumnScope.QuizPane(l: Course.Lesson, onFinish: (Int) -> Unit) {
    val ctx = LocalContext.current
    var i by remember(l.id) { mutableIntStateOf(0) }
    var picked by remember(l.id) { mutableStateOf<Int?>(null) }
    var correct by remember(l.id) { mutableIntStateOf(0) }
    var finished by remember(l.id) { mutableStateOf(false) }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (l.quiz.isEmpty()) { Text(tr("لا يوجد اختبار لهذا الدرس", "No quiz")); return@Column }
        if (finished) {
            val sc = correct * 100 / l.quiz.size
            Text(if (sc >= 67) "🎉" else "💪", fontSize = 64.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            Text(tr("نتيجتك: $correct من ${l.quiz.size} ($sc%)", "Score: $correct/${l.quiz.size} ($sc%)"), fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            Text(if (sc >= 67) tr("أحسنت! تم إكمال الدرس ✅", "Well done! Lesson completed ✅") else tr("راجع الدرس وحاول مجدداً (المطلوب 67%)", "Review and retry (67% needed)"), modifier = Modifier.align(Alignment.CenterHorizontally))
            Button(onClick = { i = 0; picked = null; correct = 0; finished = false }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text(tr("إعادة الاختبار", "Retry")) }
            return@Column
        }
        val q = l.quiz[i]
        Text(tr("سؤال ${i + 1} من ${l.quiz.size}", "Question ${i + 1}/${l.quiz.size}"), style = MaterialTheme.typography.labelLarge)
        LinearProgressIndicator(progress = { (i + 1f) / l.quiz.size }, modifier = Modifier.fillMaxWidth())
        Text(q.q, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        q.options.forEachIndexed { k, o ->
            val color = when { picked == null -> MaterialTheme.colorScheme.surfaceVariant; k == q.answer -> SuccessGreen.copy(alpha = 0.3f); k == picked -> DangerRed.copy(alpha = 0.3f); else -> MaterialTheme.colorScheme.surfaceVariant }
            Card(onClick = {
                if (picked == null) { picked = k; if (k == q.answer) correct++ }
                if (o.any { it in 'a'..'z' || it in 'A'..'Z' }) Speaker.speak(ctx, o, "en-US")
            }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = color)) {
                Text(o, Modifier.padding(16.dp), fontSize = 17.sp)
            }
        }
        if (picked != null) Button(onClick = {
            if (i < l.quiz.size - 1) { i++; picked = null } else { finished = true; onFinish(correct * 100 / l.quiz.size) }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (i < l.quiz.size - 1) tr("التالي", "Next") else tr("النتيجة", "Result")) }
    }
}

// =====================================================================
//                              محادثات المواقف
// =====================================================================
@Composable
fun RoleplayListScreen(nav: NavController) {
    val ctx = LocalContext.current
    val data = remember { runCatching { Course.load(ctx) }.getOrNull() }
    val practiced = remember { Course.practiced }
    ScreenScaffold(title = tr("محادثات المواقف", "Role-play situations"), onBack = { nav.popBackStack() }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { InfoBanner(tr("اختر موقفاً ودورك فيه، استمع للطرف الآخر ثم تحدث بدورك؛ يقيّم التطبيق نطقك. يمكنك إخفاء الجملة لتحدٍّ أكبر.", "Pick a situation and your role, listen to the other side, then speak your line; the app rates your pronunciation.")) }
            items(data?.third.orEmpty(), key = { it.id }) { s ->
                Card(onClick = { nav.navigate("roleplay/${s.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(s.emoji, fontSize = 34.sp); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(s.titleEn + " • " + s.roleA + " ↔ " + s.roleB, style = MaterialTheme.typography.bodySmall)
                        }
                        if (s.id in practiced) Text("✅")
                    }
                }
            }
        }
    }
}

@Composable
fun RoleplayScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    val data = remember { runCatching { Course.load(ctx) }.getOrNull() }
    val s = data?.third?.firstOrNull { it.id == id }
    var role by rememberSaveable { mutableStateOf<Int?>(null) }
    var step by rememberSaveable { mutableIntStateOf(0) }
    var showAr by rememberSaveable { mutableStateOf(true) }
    var hide by rememberSaveable { mutableStateOf(false) }
    val scores = remember { mutableStateMapOf<Int, Pair<String, Int>>() }
    DisposableEffect(Unit) { Speaker.init(ctx); onDispose { Speaker.stop() } }
    val mic = rememberSpeechInput { said -> s?.lines?.getOrNull(step)?.let { ln -> scores[step] = said to Course.similarity(said, ln.en) } }
    if (s == null) { ScreenScaffold(title = "…", onBack = { nav.popBackStack() }) { }; return }
    val ls = rememberLazyListState()
    // نطق جملة الطرف الآخر تلقائياً
    LaunchedEffect(step, role) {
        val r = role ?: return@LaunchedEffect
        val ln = s.lines.getOrNull(step) ?: return@LaunchedEffect
        ls.animateScrollToItem((step + 1).coerceAtMost(s.lines.size))
        if (ln.who != r) Speaker.speak(ctx, ln.en, "en-US") { if (step < s.lines.size - 1 && s.lines[step].who != r) step++ }
    }

    ScreenScaffold(title = s.emoji + " " + s.title, onBack = { nav.popBackStack() }) { p ->
        if (role == null) {
            Column(Modifier.padding(p).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(s.emoji, fontSize = 72.sp)
                Text(s.title + " • " + s.titleEn, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(tr("اختر دورك في المحادثة", "Choose your role"), style = MaterialTheme.typography.titleMedium)
                Button(onClick = { role = 0; step = 0; scores.clear() }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text(tr("أنا ", "I'm the ") + s.roleA) }
                OutlinedButton(onClick = { role = 1; step = 0; scores.clear() }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text(tr("أنا ", "I'm the ") + s.roleB) }
                TextButton(onClick = { role = 2; step = 0 }) { Text(tr("👂 استماع للمحادثة كاملة", "👂 Just listen to the whole dialogue")) }
                SectionTitle(tr("كلمات مهمة", "Key words"))
                s.words.forEach { w -> Row(Modifier.fillMaxWidth().clickable { Speaker.speak(ctx, w.en, "en-US") }) { Text(w.en, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text(w.ar) } }
                if (s.tips.isNotBlank()) InfoBanner("💡 " + s.tips)
            }
            return@ScreenScaffold
        }
        val r = role!!
        Column(Modifier.padding(p).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(showAr, { showAr = !showAr }, label = { Text(tr("الترجمة", "Arabic")) })
                Spacer(Modifier.width(6.dp))
                if (r != 2) FilterChip(hide, { hide = !hide }, label = { Text(tr("إخفاء جملتي (تحدٍّ)", "Hide my line")) })
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { role = null; Speaker.stop() }) { Text(tr("تغيير الدور", "Change role")) }
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(s.lines.take(step + 1)) { i, ln ->
                    val mine = r != 2 && ln.who == r
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Card(Modifier.fillMaxWidth(0.88f), colors = CardDefaults.cardColors(containerColor = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(if (ln.who == 0) s.roleA else s.roleB, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Text(if (mine && hide && i == step && scores[i] == null) "• • • • •" else ln.en, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth())
                                }
                                if (showAr) Text(ln.ar, style = MaterialTheme.typography.bodySmall)
                                scores[i]?.let { (said, sc) ->
                                    Text("🎤 " + said, style = MaterialTheme.typography.labelSmall)
                                    Text("$sc% " + when { sc >= 85 -> "🌟"; sc >= 60 -> "👍"; else -> "🔁" }, fontWeight = FontWeight.Bold, color = if (sc >= 60) SuccessGreen else WarnAmber)
                                }
                                Row {
                                    IconButton(onClick = { Speaker.speak(ctx, ln.en, "en-US") }) { Icon(Icons.Filled.VolumeUp, null) }
                                    IconButton(onClick = { Speaker.speak(ctx, ln.en, "en-US", slow = true) }) { Icon(Icons.Filled.SlowMotionVideo, null) }
                                    if (mine) IconButton(onClick = { mic("en-US") }) { Icon(Icons.Filled.Mic, null, tint = MaterialTheme.colorScheme.primary) }
                                }
                            }
                        }
                    }
                }
                if (step >= s.lines.size - 1) item {
                    val avg = if (scores.isEmpty()) null else scores.values.map { it.second }.average().toInt()
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.18f))) {
                        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🎉 " + tr("انتهت المحادثة", "Dialogue complete"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            if (avg != null) Text(tr("متوسط نطقك: $avg%", "Your average: $avg%"))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { step = 0; scores.clear() }) { Text(tr("إعادة", "Again")) }
                                OutlinedButton(onClick = { role = if (r == 0) 1 else 0; step = 0; scores.clear() }) { Text(tr("بدّل الدور", "Swap roles")) }
                            }
                        }
                    }
                    LaunchedEffect(Unit) { Course.practiced = Course.practiced + s.id; Course.touchStreak() }
                }
            }
            val cur = s.lines.getOrNull(step)
            if (cur != null && step < s.lines.size - 1) Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (r != 2 && cur.who == r) Button(onClick = { mic("en-US") }, modifier = Modifier.weight(1f).height(56.dp)) { Icon(Icons.Filled.Mic, null); Spacer(Modifier.width(6.dp)); Text(tr("قل جملتك", "Say your line")) }
                OutlinedButton(onClick = { Speaker.stop(); step++ }, modifier = Modifier.weight(1f).height(56.dp)) { Text(tr("التالي ←", "Next →")) }
            }
        }
    }
}
