package com.sho3eb.app.core

import kotlin.math.abs

// =====================================================================
//                 حاسبة المواريث (علم الفرائض)
//   تعتمد قول الجمهور، مع خيار مذهب الجد مع الإخوة
// =====================================================================

/** كسر عادي مبسّط */
data class Frac(val n: Long, val d: Long) : Comparable<Frac> {
    companion object {
        val ZERO = Frac(0, 1)
        val ONE = Frac(1, 1)
        fun of(n: Long, d: Long): Frac {
            if (n == 0L) return ZERO
            val g = gcd(abs(n), abs(d))
            val s = if (d < 0) -1 else 1
            return Frac(s * n / g, s * d / g)
        }
        fun gcd(a: Long, b: Long): Long = if (b == 0L) a else gcd(b, a % b)
        fun lcm(a: Long, b: Long): Long = a / gcd(a, b) * b
    }
    operator fun plus(o: Frac) = of(n * o.d + o.n * d, d * o.d)
    operator fun minus(o: Frac) = of(n * o.d - o.n * d, d * o.d)
    operator fun times(o: Frac) = of(n * o.n, d * o.d)
    operator fun div(o: Frac) = of(n * o.d, d * o.n)
    fun times(k: Long) = of(n * k, d)
    fun divBy(k: Long) = of(n, d * k)
    override fun compareTo(other: Frac) = (n * other.d).compareTo(other.n * d)
    val isZero get() = n == 0L
    val v get() = n.toDouble() / d
    override fun toString() = if (d == 1L) "$n" else "$n/$d"
}

private fun fr(n: Long, d: Long) = Frac.of(n, d)

object Faraid {
    enum class H(val ar: String, val en: String, val max: Int, val male: Boolean) {
        HUSBAND("الزوج", "Husband", 1, true),
        WIFE("الزوجة", "Wife", 4, false),
        SON("الابن", "Son", 99, true),
        DAUGHTER("البنت", "Daughter", 99, false),
        SON_SON("ابن الابن", "Son's son", 99, true),
        SON_DAUGHTER("بنت الابن", "Son's daughter", 99, false),
        FATHER("الأب", "Father", 1, true),
        MOTHER("الأم", "Mother", 1, false),
        GRANDFATHER("الجد (أبو الأب)", "Paternal grandfather", 1, true),
        GM_MOTHER("الجدة لأم", "Maternal grandmother", 1, false),
        GM_FATHER("الجدة لأب", "Paternal grandmother", 1, false),
        FULL_BRO("الأخ الشقيق", "Full brother", 99, true),
        FULL_SIS("الأخت الشقيقة", "Full sister", 99, false),
        PAT_BRO("الأخ لأب", "Paternal half-brother", 99, true),
        PAT_SIS("الأخت لأب", "Paternal half-sister", 99, false),
        MAT_BRO("الأخ لأم", "Maternal half-brother", 99, true),
        MAT_SIS("الأخت لأم", "Maternal half-sister", 99, false),
        FULL_NEPHEW("ابن الأخ الشقيق", "Full brother's son", 99, true),
        PAT_NEPHEW("ابن الأخ لأب", "Half-brother's son", 99, true),
        FULL_UNCLE("العم الشقيق", "Full paternal uncle", 99, true),
        PAT_UNCLE("العم لأب", "Half paternal uncle", 99, true),
        FULL_COUSIN("ابن العم الشقيق", "Full uncle's son", 99, true),
        PAT_COUSIN("ابن العم لأب", "Half uncle's son", 99, true);
        val label get() = tr(ar, en)
    }

    data class Share(
        val h: H, val count: Int, val share: Frac, val basis: String,
        val blockedBy: String? = null
    ) {
        val each get() = if (count > 0) share.divBy(count.toLong()) else Frac.ZERO
    }

    data class Result(
        val shares: List<Share>, val asl: Long, val awl: Boolean, val radd: Boolean,
        val baitAlMal: Frac, val notes: List<String>
    ) {
        fun sihaam(s: Share) = s.share.n * (asl / s.share.d)
    }

    /**
     * @param c عدد كل وارث
     * @param gfWithSiblings 0 = قول الجمهور (المقاسمة)، 1 = الجد كالأب يحجب الإخوة (أبو حنيفة وجمع من المحققين)
     */
    fun solve(c0: Map<H, Int>, gfWithSiblings: Int = 0): Result {
        val c = c0.filterValues { it > 0 }.toMutableMap()
        fun n(h: H) = c[h] ?: 0
        fun has(h: H) = n(h) > 0
        val notes = mutableListOf<String>()
        val blocked = linkedMapOf<H, String>()
        fun block(h: H, by: String) { if (has(h) && h !in blocked) blocked[h] = by }
        fun alive(h: H) = has(h) && h !in blocked

        val desc = has(H.SON) || has(H.DAUGHTER) || has(H.SON_SON) || has(H.SON_DAUGHTER)
        val maleDesc = has(H.SON) || has(H.SON_SON)
        val femDesc = has(H.DAUGHTER) || has(H.SON_DAUGHTER)
        val siblingsAll = n(H.FULL_BRO) + n(H.FULL_SIS) + n(H.PAT_BRO) + n(H.PAT_SIS) + n(H.MAT_BRO) + n(H.MAT_SIS)

        // ---------- الحجب ----------
        if (has(H.FATHER)) block(H.GRANDFATHER, H.FATHER.label)
        if (has(H.MOTHER)) { block(H.GM_MOTHER, H.MOTHER.label); block(H.GM_FATHER, H.MOTHER.label) }
        if (has(H.FATHER)) block(H.GM_FATHER, H.FATHER.label)
        if (has(H.SON)) { block(H.SON_SON, H.SON.label); block(H.SON_DAUGHTER, H.SON.label) }
        if (n(H.DAUGHTER) >= 2 && !has(H.SON_SON)) block(H.SON_DAUGHTER, tr("استكمال البنات الثلثين", "daughters took 2/3"))
        val matBlocker = when {
            has(H.SON) -> H.SON.label; has(H.DAUGHTER) -> H.DAUGHTER.label
            has(H.SON_SON) -> H.SON_SON.label; has(H.SON_DAUGHTER) -> H.SON_DAUGHTER.label
            has(H.FATHER) -> H.FATHER.label; alive(H.GRANDFATHER) -> H.GRANDFATHER.label; else -> null
        }
        if (matBlocker != null) { block(H.MAT_BRO, matBlocker); block(H.MAT_SIS, matBlocker) }

        val gfAlive = alive(H.GRANDFATHER)
        val sibBlocker = when {
            has(H.SON) -> H.SON.label; alive(H.SON_SON) -> H.SON_SON.label; has(H.FATHER) -> H.FATHER.label
            gfAlive && gfWithSiblings == 1 -> H.GRANDFATHER.label; else -> null
        }
        if (sibBlocker != null) listOf(H.FULL_BRO, H.FULL_SIS, H.PAT_BRO, H.PAT_SIS).forEach { block(it, sibBlocker) }

        // الأخت الشقيقة عصبة مع الغير (مع البنات) إن لم يكن معها أخ شقيق
        val fullSisWithGhayr = alive(H.FULL_SIS) && !alive(H.FULL_BRO) && femDesc && !(gfAlive && gfWithSiblings == 0)
        if (alive(H.FULL_BRO)) { block(H.PAT_BRO, H.FULL_BRO.label); block(H.PAT_SIS, H.FULL_BRO.label) }
        if (fullSisWithGhayr) { block(H.PAT_BRO, tr("الأخت الشقيقة (عصبة مع البنات)", "full sister (residuary with daughters)")); block(H.PAT_SIS, tr("الأخت الشقيقة (عصبة مع البنات)", "full sister (residuary with daughters)")) }
        if (n(H.FULL_SIS) >= 2 && alive(H.FULL_SIS) && !alive(H.PAT_BRO)) block(H.PAT_SIS, tr("استكمال الشقيقات الثلثين", "full sisters took 2/3"))
        val patSisWithGhayr = alive(H.PAT_SIS) && !alive(H.PAT_BRO) && femDesc && !(gfAlive && gfWithSiblings == 0)

        // الجد مع الإخوة على قول الجمهور: يقاسم الإخوة الأشقاء، أو لأب عند عدم الأشقاء
        val gfShares = gfAlive && gfWithSiblings == 0 && !maleDesc &&
            (alive(H.FULL_BRO) || alive(H.FULL_SIS) || alive(H.PAT_BRO) || alive(H.PAT_SIS))
        if (gfShares && (alive(H.FULL_BRO) || alive(H.FULL_SIS))) {
            if (alive(H.PAT_BRO) || alive(H.PAT_SIS)) notes += tr("لم تُطبّق «المعادّة» بين الإخوة الأشقاء ولأب مع الجد، فالنتيجة تقريبية في هذه الحالة.", "Mu'adda (counting half-siblings against the grandfather) is not applied; result is approximate.")
            block(H.PAT_BRO, H.FULL_BRO.label.takeIf { alive(H.FULL_BRO) } ?: H.FULL_SIS.label)
            block(H.PAT_SIS, H.FULL_BRO.label.takeIf { alive(H.FULL_BRO) } ?: H.FULL_SIS.label)
        }

        // سلسلة العصبات بعد الإخوة: الأقرب يحجب الأبعد
        val chain = listOf(H.SON, H.SON_SON, H.FATHER, H.GRANDFATHER, H.FULL_BRO, H.FULL_SIS, H.PAT_BRO, H.PAT_SIS,
            H.FULL_NEPHEW, H.PAT_NEPHEW, H.FULL_UNCLE, H.PAT_UNCLE, H.FULL_COUSIN, H.PAT_COUSIN)
        // من يُعتبر عاصباً حاجباً لمن بعده من العصبات البعيدة (أبناء الإخوة فما بعد)
        val farStart = chain.indexOf(H.FULL_NEPHEW)
        var topAsaba: H? = null
        for (h in chain) {
            if (!alive(h)) continue
            val isAsaba = when (h) {
                H.FULL_SIS -> fullSisWithGhayr || alive(H.FULL_BRO) || gfShares
                H.PAT_SIS -> patSisWithGhayr || alive(H.PAT_BRO) || gfShares
                else -> true
            }
            if (isAsaba) { topAsaba = h; break }
        }
        // الجد يحجب أبناء الإخوة ومن بعدهم دائماً
        if (topAsaba != null) {
            val ti = chain.indexOf(topAsaba)
            for (k in maxOf(ti + 1, farStart) until chain.size) block(chain[k], topAsaba.label)
        }
        if (gfAlive) for (k in farStart until chain.size) block(chain[k], H.GRANDFATHER.label)
        // ابن الابن يحجب الإخوة وما بعدهم، والأب كذلك (تمت تغطيته)، والأخ لأب يحجب أبناء الإخوة... (السلسلة أعلاه)

        // ---------- الفروض ----------
        val fixed = linkedMapOf<H, Frac>()
        val basis = mutableMapOf<H, String>()
        fun fx(h: H, v: Frac, why: String) { fixed[h] = v; basis[h] = why }

        if (alive(H.HUSBAND)) fx(H.HUSBAND, if (desc) fr(1, 4) else fr(1, 2), if (desc) tr("الربع لوجود الفرع الوارث", "1/4: descendants exist") else tr("النصف لعدم الفرع الوارث", "1/2: no descendants"))
        if (alive(H.WIFE)) fx(H.WIFE, if (desc) fr(1, 8) else fr(1, 4), (if (desc) tr("الثمن لوجود الفرع الوارث", "1/8: descendants exist") else tr("الربع لعدم الفرع الوارث", "1/4: no descendants")) + if (n(H.WIFE) > 1) tr(" (يقتسمنه بالتساوي)", " (shared equally)") else "")
        val spouse = fixed[H.HUSBAND] ?: fixed[H.WIFE] ?: Frac.ZERO

        if (alive(H.MOTHER)) {
            when {
                desc -> fx(H.MOTHER, fr(1, 6), tr("السدس لوجود الفرع الوارث", "1/6: descendants exist"))
                siblingsAll >= 2 -> fx(H.MOTHER, fr(1, 6), tr("السدس لوجود جمع من الإخوة", "1/6: two or more siblings"))
                spouse > Frac.ZERO && has(H.FATHER) -> fx(H.MOTHER, (Frac.ONE - spouse).divBy(3), tr("ثلث الباقي بعد فرض الزوج/الزوجة (العُمَريّتان)", "1/3 of remainder after spouse (Umariyyatan)"))
                else -> fx(H.MOTHER, fr(1, 3), tr("الثلث لعدم الفرع الوارث وعدم جمع الإخوة", "1/3: no descendants, fewer than two siblings"))
            }
        }
        val gms = listOf(H.GM_MOTHER, H.GM_FATHER).filter { alive(it) }
        if (gms.size == 1) fx(gms[0], fr(1, 6), tr("السدس", "1/6"))
        if (gms.size == 2) { fx(H.GM_MOTHER, fr(1, 12), tr("السدس بين الجدتين مناصفة", "1/6 shared by both grandmothers")); fx(H.GM_FATHER, fr(1, 12), tr("السدس بين الجدتين مناصفة", "1/6 shared by both grandmothers")) }

        if (alive(H.FATHER) && maleDesc) fx(H.FATHER, fr(1, 6), tr("السدس فرضاً لوجود الفرع الوارث المذكر", "1/6: male descendants exist"))
        if (alive(H.FATHER) && !maleDesc && femDesc) fx(H.FATHER, fr(1, 6), tr("السدس فرضاً + الباقي تعصيباً", "1/6 + residue"))
        if (gfAlive && maleDesc) fx(H.GRANDFATHER, fr(1, 6), tr("السدس فرضاً لوجود الفرع الوارث المذكر", "1/6: male descendants exist"))
        if (gfAlive && !maleDesc && femDesc && !gfShares) fx(H.GRANDFATHER, fr(1, 6), tr("السدس فرضاً + الباقي تعصيباً", "1/6 + residue"))

        if (alive(H.DAUGHTER) && !has(H.SON)) fx(H.DAUGHTER, if (n(H.DAUGHTER) == 1) fr(1, 2) else fr(2, 3), if (n(H.DAUGHTER) == 1) tr("النصف لانفرادها وعدم المعصّب", "1/2: alone, no son") else tr("الثلثان للبنتين فأكثر", "2/3: two or more daughters"))
        if (alive(H.SON_DAUGHTER) && !alive(H.SON_SON)) {
            when (n(H.DAUGHTER)) {
                0 -> fx(H.SON_DAUGHTER, if (n(H.SON_DAUGHTER) == 1) fr(1, 2) else fr(2, 3), if (n(H.SON_DAUGHTER) == 1) tr("النصف", "1/2") else tr("الثلثان", "2/3"))
                1 -> fx(H.SON_DAUGHTER, fr(1, 6), tr("السدس تكملة للثلثين مع البنت", "1/6 completing 2/3 with the daughter"))
            }
        }
        val matN = (if (alive(H.MAT_BRO)) n(H.MAT_BRO) else 0) + (if (alive(H.MAT_SIS)) n(H.MAT_SIS) else 0)
        if (matN > 0) {
            val tot = if (matN == 1) fr(1, 6) else fr(1, 3)
            val why = if (matN == 1) tr("السدس لانفراده", "1/6: single") else tr("الثلث يقتسمونه بالتساوي ذكوراً وإناثاً", "1/3 shared equally")
            if (alive(H.MAT_BRO)) fx(H.MAT_BRO, tot.times(n(H.MAT_BRO).toLong()).divBy(matN.toLong()), why)
            if (alive(H.MAT_SIS)) fx(H.MAT_SIS, tot.times(n(H.MAT_SIS).toLong()).divBy(matN.toLong()), why)
        }
        if (alive(H.FULL_SIS) && !alive(H.FULL_BRO) && !fullSisWithGhayr && !gfShares)
            fx(H.FULL_SIS, if (n(H.FULL_SIS) == 1) fr(1, 2) else fr(2, 3), if (n(H.FULL_SIS) == 1) tr("النصف", "1/2") else tr("الثلثان", "2/3"))
        if (alive(H.PAT_SIS) && !alive(H.PAT_BRO) && !patSisWithGhayr && !gfShares) {
            val fs = if (alive(H.FULL_SIS) && !fullSisWithGhayr) n(H.FULL_SIS) else 0
            when (fs) {
                0 -> fx(H.PAT_SIS, if (n(H.PAT_SIS) == 1) fr(1, 2) else fr(2, 3), if (n(H.PAT_SIS) == 1) tr("النصف", "1/2") else tr("الثلثان", "2/3"))
                1 -> fx(H.PAT_SIS, fr(1, 6), tr("السدس تكملة للثلثين مع الشقيقة", "1/6 completing 2/3 with the full sister"))
            }
        }

        val shares = linkedMapOf<H, Frac>()
        shares.putAll(fixed)
        var sumFixed = fixed.values.fold(Frac.ZERO) { a, b -> a + b }
        var residue = Frac.ONE - sumFixed
        var asabaTook = false

        fun distribute(group: List<H>, amount: Frac, why: String) {
            // للذكر مثل حظ الأنثيين
            val units = group.sumOf { n(it).toLong() * (if (it.male) 2 else 1) }
            if (units == 0L) return
            group.forEach { h ->
                val part = amount.times(n(h).toLong() * (if (h.male) 2 else 1)).divBy(units)
                shares[h] = (shares[h] ?: Frac.ZERO) + part
                basis[h] = basis[h]?.let { "$it" } ?: why
            }
            asabaTook = true
        }

        if (gfShares) {
            // الجد مع الإخوة (قول زيد والجمهور): الأفضل له من المقاسمة أو ثلث الباقي أو سدس الجميع
            val sibs = if (alive(H.FULL_BRO) || alive(H.FULL_SIS)) listOf(H.FULL_BRO, H.FULL_SIS).filter { alive(it) } else listOf(H.PAT_BRO, H.PAT_SIS).filter { alive(it) }
            val units = 2L + sibs.sumOf { n(it).toLong() * (if (it.male) 2 else 1) }
            val r = residue
            val muq = r.times(2).divBy(units)
            val third = if (sumFixed.isZero) fr(1, 3) else r.divBy(3)
            val g = listOf(muq, third, fr(1, 6)).max()
            val which = when (g) { muq -> tr("المقاسمة مع الإخوة", "sharing with siblings"); fr(1, 6) -> tr("سدس جميع المال", "1/6 of the estate"); else -> if (sumFixed.isZero) tr("ثلث المال", "1/3 of the estate") else tr("ثلث الباقي", "1/3 of the remainder") }
            shares[H.GRANDFATHER] = g; basis[H.GRANDFATHER] = tr("الجد مع الإخوة: الأحظ له وهو ", "Grandfather with siblings: best option = ") + which
            sumFixed += g
            residue = Frac.ONE - sumFixed
            if (residue > Frac.ZERO) distribute(sibs, residue, tr("الباقي بعد الجد تعصيباً، للذكر مثل حظ الأنثيين", "remainder after grandfather, male = 2 females"))
            else sibs.forEach { shares[it] = Frac.ZERO; basis[it] = tr("لم يبقَ لهم شيء بعد الجد وأصحاب الفروض", "nothing left after grandfather and fixed heirs") }
            residue = Frac.ONE - shares.values.fold(Frac.ZERO) { a, b -> a + b }
            asabaTook = true
        } else if (topAsaba != null) {
            val group = when (topAsaba) {
                H.SON -> listOf(H.SON, H.DAUGHTER)
                H.SON_SON -> listOf(H.SON_SON, H.SON_DAUGHTER).filter { alive(it) }
                H.FULL_BRO -> listOf(H.FULL_BRO, H.FULL_SIS).filter { alive(it) }
                H.PAT_BRO -> listOf(H.PAT_BRO, H.PAT_SIS).filter { alive(it) }
                else -> listOf(topAsaba)
            }
            val why = when {
                group.size > 1 -> tr("الباقي تعصيباً، للذكر مثل حظ الأنثيين", "residue, male = 2 females")
                topAsaba == H.FULL_SIS || topAsaba == H.PAT_SIS -> tr("الباقي عصبة مع الغير (مع البنات)", "residue with daughters")
                topAsaba == H.FATHER || topAsaba == H.GRANDFATHER -> if (femDesc) tr("السدس فرضاً + الباقي تعصيباً", "1/6 + residue") else tr("الباقي تعصيباً", "residue")
                else -> tr("الباقي تعصيباً", "residue")
            }
            if (residue > Frac.ZERO) distribute(group, residue, why)
            else {
                group.filter { it !in fixed }.forEach { shares[it] = Frac.ZERO; basis[it] = tr("عاصب ولم يبقَ له شيء", "residuary, nothing left") }
                asabaTook = true
            }
            residue = Frac.ONE - shares.values.fold(Frac.ZERO) { a, b -> a + b }
        }

        // ---------- العول ----------
        var awl = false
        val total0 = shares.values.fold(Frac.ZERO) { a, b -> a + b }
        if (total0 > Frac.ONE) {
            awl = true
            shares.keys.toList().forEach { shares[it] = shares[it]!! / total0 }
            notes += tr("المسألة عائلة: زادت الفروض عن التركة فنقص نصيب كل وارث بنسبة فرضه.", "‘Awl: fixed shares exceeded the estate, all reduced proportionally.")
        }

        // ---------- الرد ----------
        var radd = false
        var bait = Frac.ZERO
        residue = Frac.ONE - shares.values.fold(Frac.ZERO) { a, b -> a + b }
        if (residue > Frac.ZERO && !asabaTook) {
            val raddHeirs = shares.keys.filter { it != H.HUSBAND && it != H.WIFE && !(shares[it]!!.isZero) }
            if (raddHeirs.isNotEmpty()) {
                radd = true
                val s = raddHeirs.fold(Frac.ZERO) { a, h -> a + shares[h]!! }
                raddHeirs.forEach { h -> shares[h] = shares[h]!! + residue * shares[h]!! / s; basis[h] = (basis[h] ?: "") + tr(" + الرد", " + return (radd)") }
                notes += tr("المسألة فيها رد: الباقي يُرد على أصحاب الفروض عدا الزوجين بنسبة فروضهم.", "Radd: the remainder returns to fixed heirs (except spouses) in proportion.")
            } else if (alive(H.HUSBAND) || alive(H.WIFE)) {
                val sp = if (alive(H.HUSBAND)) H.HUSBAND else H.WIFE
                radd = true
                shares[sp] = shares[sp]!! + residue
                basis[sp] = (basis[sp] ?: "") + tr(" + الباقي رداً (لعدم غيره، وعليه العمل في المحاكم المعاصرة)", " + remainder (no other heirs)")
                notes += tr("الرد على الزوج/الزوجة عند انعدام الورثة غيره هو المعمول به حالياً، وأصل المذاهب أن الباقي لبيت المال.", "Returning the remainder to the spouse is modern practice; classical view gives it to the treasury.")
            } else {
                bait = residue
                notes += tr("لا يوجد وارث يستحق الباقي، فيذهب لبيت مال المسلمين (أو ذوي الأرحام عند من يورّثهم).", "No heir for the remainder: it goes to the public treasury (or distant kin per some schools).")
            }
        }

        // ---------- أصل المسألة ----------
        val all = shares.values.filter { !it.isZero } + (if (!bait.isZero) listOf(bait) else emptyList())
        val asl = all.fold(1L) { a, x -> Frac.lcm(a, x.d) }

        val out = mutableListOf<Share>()
        H.values().forEach { h ->
            if (!has(h)) return@forEach
            val b = blocked[h]
            if (b != null) out += Share(h, n(h), Frac.ZERO, tr("محجوب", "Excluded"), b)
            else out += Share(h, n(h), shares[h] ?: Frac.ZERO, basis[h] ?: tr("لا شيء", "Nothing"))
        }
        if (out.isEmpty()) notes += tr("اختر الورثة الموجودين لحساب الأنصبة.", "Select the heirs to calculate.")
        return Result(out, asl, awl, radd, bait, notes)
    }

    // ---------- تجهيز التركة قبل القسمة ----------
    data class Estate(val gross: Double, val funeral: Double, val debts: Double, val will: Double) {
        val afterDebts get() = (gross - funeral - debts).coerceAtLeast(0.0)
        val willCapped get() = minOf(will, afterDebts / 3.0)
        val net get() = (afterDebts - willCapped).coerceAtLeast(0.0)
        val willExceeded get() = will > afterDebts / 3.0 + 0.005
    }
}
