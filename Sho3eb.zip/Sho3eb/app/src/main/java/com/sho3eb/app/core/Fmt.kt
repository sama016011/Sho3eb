package com.sho3eb.app.core

import android.content.Context
import android.widget.Toast
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Period {
    const val DAY = "DAY"
    const val WEEK = "WEEK"
    const val MONTH = "MONTH"
}

object Fmt {
    private val df = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.US)

    fun date(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(df)
    fun date(d: LocalDate): String = d.format(df)
    fun today(): Long = LocalDate.now().toEpochDay()

    fun num(v: Double): String {
        val s = String.format(Locale.US, "%,.2f", v)
        return if (s.endsWith(".00")) s.dropLast(3) else s
    }

    /** للحقول القابلة للتعديل: بدون فواصل الآلاف */
    fun plain(v: Double): String = num(v).replace(",", "")

    fun money(v: Double): String {
        val c = AppState.currency.value.trim()
        return if (c.isEmpty()) num(v) else "${num(v)} $c"
    }

    /** يقبل الأرقام العربية والهندية والفواصل */
    fun parse(s: String): Double? {
        val sb = StringBuilder()
        for (ch in s.trim()) {
            when {
                ch in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                ch in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                ch == '٫' -> sb.append('.')
                ch == ',' || ch == '٬' || ch == ' ' -> {}
                else -> sb.append(ch)
            }
        }
        return sb.toString().toDoubleOrNull()
    }

    fun parseInt(s: String): Int? = parse(s)?.toInt()

    fun unitName(type: String): String = when (type) {
        Period.DAY -> tr("يوم", "day")
        Period.WEEK -> tr("أسبوع", "week")
        else -> tr("شهر", "month")
    }

    fun periodLabel(type: String, count: Int): String {
        val ar = when (type) {
            Period.DAY -> if (count <= 1) "يومياً" else if (count == 2) "كل يومين" else "كل $count أيام"
            Period.WEEK -> if (count <= 1) "أسبوعياً" else if (count == 2) "كل أسبوعين" else "كل $count أسابيع"
            else -> if (count <= 1) "شهرياً" else if (count == 2) "كل شهرين" else "كل $count أشهر"
        }
        val en = when (type) {
            Period.DAY -> if (count <= 1) "Daily" else "Every $count days"
            Period.WEEK -> if (count <= 1) "Weekly" else "Every $count weeks"
            else -> if (count <= 1) "Monthly" else "Every $count months"
        }
        return tr(ar, en)
    }
}

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
