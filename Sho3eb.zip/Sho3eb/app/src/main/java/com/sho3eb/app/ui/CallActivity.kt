@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewAssetLoader
import com.sho3eb.app.core.chat.CallBus
import com.sho3eb.app.core.chat.Chat
import com.sho3eb.app.core.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** شاشة المكالمة الصوتية/المرئية (WebRTC داخل WebView مع واجهة أصلية) */
class CallActivity : ComponentActivity() {
    private var web: WebView? = null
    private lateinit var peer: String
    private lateinit var callId: String
    private var video = false
    private var incoming = false
    private val phase = mutableStateOf("init")          // ringing_out, ringing_in, connecting, connected, reconnecting, ended
    private val muted = mutableStateOf(false)
    private val camOn = mutableStateOf(true)
    private val speaker = mutableStateOf(false)
    private val remoteVideoOn = mutableStateOf(true)
    private val qualityText = mutableStateOf("")
    private val isVideo = mutableStateOf(false)
    private var connectedAt = 0L
    private var ringtone: android.media.Ringtone? = null
    private var tone: ToneGenerator? = null
    private var ended = false
    private var lastSig = 0L
    private val audio by lazy { getSystemService(AudioManager::class.java) }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) afterPermissions() else { toast(tr("يلزم إذن الميكروفون للمكالمة", "Microphone permission is required")); end(true) }
    }

    private fun toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        peer = intent.getStringExtra("peer") ?: return finish()
        callId = intent.getStringExtra("call") ?: return finish()
        video = intent.getBooleanExtra("video", false); isVideo.value = video
        incoming = intent.getBooleanExtra("incoming", false)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        CallBus.activeCall = callId
        CallBus.cancelNotification(this, callId)
        speaker.value = video
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { CallUi() } }
        lifecycleScope.launch { CallBus.flow.collect { s -> if (s.callId == callId) onSignal(s) } }
        // استطلاع احتياطي للإشارات
        lifecycleScope.launch(Dispatchers.IO) { while (!ended) { lastSig = CallBus.poll(callId, lastSig); delay(1500) } }
        if (incoming) { phase.value = "ringing_in"; startRingtone() }
        else { phase.value = "ringing_out"; requestPerms() }
        // انتهاء مهلة الرنين
        lifecycleScope.launch { delay(45_000); if (phase.value == "ringing_out") { CallBus.send(peer, callId, "end", "timeout"); logCall(missed = true); end(false) } else if (phase.value == "ringing_in") end(false) }
    }

    private fun requestPerms() {
        val need = listOf(Manifest.permission.RECORD_AUDIO) + if (video) listOf(Manifest.permission.CAMERA) else emptyList()
        if (need.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) afterPermissions() else perms.launch(need.toTypedArray())
    }

    private fun afterPermissions() {
        audio.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION") run { audio.isSpeakerphoneOn = speaker.value }
        if (!incoming) {
            CallBus.send(peer, callId, "ring", JSONObject().put("video", video).put("name", Chat.nameOf(com.sho3eb.app.core.chat.Supa.uid)).toString())
            runCatching { tone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 70).apply { startTone(ToneGenerator.TONE_SUP_RINGTONE) } }
        } else {
            CallBus.send(peer, callId, "accept")
            phase.value = "connecting"
            js("start(false, $video, '${CallBus.iceServers()}')")
        }
    }

    private fun onSignal(s: CallBus.Sig) {
        when (s.type) {
            "accept" -> { stopTones(); phase.value = "connecting"; js("start(true, $video, '${CallBus.iceServers()}')") }
            "reject", "busy" -> { toast(if (s.type == "busy") tr("المستخدم في مكالمة أخرى", "User is busy") else tr("تم رفض المكالمة", "Call declined")); logCall(missed = true); end(false) }
            "end" -> { if (phase.value == "ringing_in") toast(tr("مكالمة فائتة", "Missed call")); end(false) }
            "offer", "answer", "ice", "video" -> js("onSignal('${s.type}', ${JSONObject.quote(s.payload)})")
        }
    }

    private var pageReady = false
    private val pendingJs = mutableListOf<String>()
    private fun js(code: String) = runOnUiThread { if (pageReady) web?.evaluateJavascript(code, null) else pendingJs += code }

    private fun startRingtone() {
        runCatching { ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))?.apply { if (Build.VERSION.SDK_INT >= 28) isLooping = true; play() } }
    }
    private fun stopTones() { runCatching { ringtone?.stop() }; runCatching { tone?.stopTone(); tone?.release() }; ringtone = null; tone = null }

    private fun accept() { stopTones(); requestPerms() }
    private fun reject() { stopTones(); CallBus.send(peer, callId, "reject"); end(false) }

    private fun logCall(missed: Boolean) {
        if (incoming) return
        val dur = if (connectedAt > 0) (System.currentTimeMillis() - connectedAt) / 1000 else 0
        lifecycleScope.launch(Dispatchers.IO) { Chat.send(listOf(peer), Chat.Content("call", dur = dur, video = video, missed = missed)) }
    }

    private fun end(sendEnd: Boolean) {
        if (ended) return
        ended = true
        if (sendEnd) { CallBus.send(peer, callId, "end"); if (phase.value == "ringing_out") logCall(missed = true) else logCall(missed = false) }
        stopTones()
        js("hangup()")
        phase.value = "ended"
        runCatching { audio.mode = AudioManager.MODE_NORMAL; @Suppress("DEPRECATION") run { audio.isSpeakerphoneOn = false } }
        CallBus.activeCall = null
        lifecycleScope.launch { delay(900); finish() }
    }

    override fun onDestroy() { if (!ended && ::peer.isInitialized && ::callId.isInitialized) { CallBus.send(peer, callId, "end") ; CallBus.activeCall = null }; stopTones(); web?.destroy(); super.onDestroy() }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isVideo.value && phase.value == "connected" && Build.VERSION.SDK_INT >= 26) runCatching { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(9, 16)).build()) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(c: Context): WebView {
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(c)).build()
        return WebView(c).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true; settings.mediaPlaybackRequiresUserGesture = false; settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
                override fun onPageFinished(view: WebView, url: String?) { pageReady = true; pendingJs.forEach { view.evaluateJavascript(it, null) }; pendingJs.clear() }
            }
            webChromeClient = object : WebChromeClient() { override fun onPermissionRequest(request: PermissionRequest) { runOnUiThread { request.grant(request.resources) } } }
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("https://appassets.androidplatform.net/assets/call/call.html")
            web = this
        }
    }

    inner class Bridge {
        @JavascriptInterface fun signal(type: String, payload: String) = CallBus.send(peer, callId, type, payload)
        @JavascriptInterface fun state(s: String) = runOnUiThread {
            when {
                s == "connected" -> { if (connectedAt == 0L) connectedAt = System.currentTimeMillis(); phase.value = "connected" }
                s == "reconnecting" || s == "disconnected" -> if (phase.value == "connected") phase.value = "reconnecting"
                s == "failed" -> phase.value = "reconnecting"
                s.startsWith("media_error") -> toast(tr("تعذر تشغيل الميكروفون/الكاميرا", "Couldn't access mic/camera"))
            }
        }
        @JavascriptInterface fun quality(rtt: Int, loss: Int, res: String) = runOnUiThread {
            qualityText.value = (if (rtt < 150 && loss < 2) "📶 " + tr("ممتازة", "Excellent") else if (rtt < 350 && loss < 6) "📶 " + tr("جيدة", "Good") else "📶 " + tr("ضعيفة", "Weak")) + " • ${rtt}ms" + if (res != "0x0") " • $res" else ""
        }
        @JavascriptInterface fun remoteVideo(on: Boolean) = runOnUiThread { remoteVideoOn.value = on }
        @JavascriptInterface fun log(s: String) { android.util.Log.d("Sho3ebCall", s) }
    }

    @Composable
    private fun CallUi() {
        val p = phase.value
        var secs by remember { mutableLongStateOf(0L) }
        LaunchedEffect(p) { while (p == "connected" || p == "reconnecting") { secs = if (connectedAt > 0) (System.currentTimeMillis() - connectedAt) / 1000 else 0; delay(1000) } }
        val prof = remember { Chat.profile(peer) }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(factory = { makeWeb(it) }, modifier = Modifier.fillMaxSize())
            val showAvatar = !isVideo.value || p != "connected" || !remoteVideoOn.value
            if (showAvatar) Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B3D3A), Color(0xFF0F2027)))))
            Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (showAvatar) {
                    ChatAvatar(peer, 120)
                    Spacer(Modifier.height(16.dp))
                }
                Text(Chat.nameOf(peer), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                if (prof?.phone?.isNotBlank() == true && showAvatar) Text("+" + prof.phone, color = Color.White.copy(alpha = 0.7f))
                Text(when (p) {
                    "ringing_out" -> tr("جارٍ الاتصال…", "Calling…"); "ringing_in" -> if (isVideo.value) tr("مكالمة فيديو واردة", "Incoming video call") else tr("مكالمة صوتية واردة", "Incoming voice call")
                    "connecting" -> tr("جارٍ التوصيل…", "Connecting…"); "reconnecting" -> tr("إعادة الاتصال…", "Reconnecting…"); "ended" -> tr("انتهت المكالمة", "Call ended")
                    else -> String.format(java.util.Locale.US, "%02d:%02d", secs / 60, secs % 60)
                }, color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp))
                if (p == "connected" && qualityText.value.isNotBlank()) Text(qualityText.value, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Text("🔒 " + tr("مشفرة من طرف لطرف", "End-to-end encrypted"), color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (p == "ringing_in") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        RoundBtn(Icons.Filled.CallEnd, Color(0xFFDC2626), tr("رفض", "Decline")) { reject() }
                        RoundBtn(if (isVideo.value) Icons.Filled.Videocam else Icons.Filled.Call, Color(0xFF16A34A), tr("رد", "Answer")) { accept() }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        RoundBtn(if (muted.value) Icons.Filled.MicOff else Icons.Filled.Mic, if (muted.value) Color.White else Color(0x33FFFFFF), tr("كتم", "Mute"), dark = muted.value) {
                            muted.value = !muted.value; js("setMute(${muted.value})")
                        }
                        RoundBtn(if (speaker.value) Icons.Filled.VolumeUp else Icons.Filled.Hearing, if (speaker.value) Color.White else Color(0x33FFFFFF), tr("السماعة", "Speaker"), dark = speaker.value) {
                            speaker.value = !speaker.value; @Suppress("DEPRECATION") run { audio.isSpeakerphoneOn = speaker.value }
                        }
                        if (isVideo.value) {
                            RoundBtn(if (camOn.value) Icons.Filled.Videocam else Icons.Filled.VideocamOff, if (!camOn.value) Color.White else Color(0x33FFFFFF), tr("الكاميرا", "Camera"), dark = !camOn.value) {
                                camOn.value = !camOn.value; js("setVideo(${camOn.value})")
                            }
                            RoundBtn(Icons.Filled.Cameraswitch, Color(0x33FFFFFF), tr("تبديل", "Flip")) { js("switchCamera()") }
                        } else if (p == "connected") RoundBtn(Icons.Filled.Videocam, Color(0x33FFFFFF), tr("فيديو", "Video")) {
                            if (ContextCompat.checkSelfPermission(this@CallActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) { isVideo.value = true; speaker.value = true; @Suppress("DEPRECATION") run { audio.isSpeakerphoneOn = true }; js("addVideo()") }
                            else perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA))
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                    RoundBtn(Icons.Filled.CallEnd, Color(0xFFDC2626), tr("إنهاء", "End"), size = 72) { end(true) }
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(icon: ImageVector, bg: Color, label: String, dark: Boolean = false, size: Int = 60, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(size.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) { Icon(icon, label, tint = if (dark) Color.Black else Color.White, modifier = Modifier.size((size * 0.45).dp)) }
        }
        Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
