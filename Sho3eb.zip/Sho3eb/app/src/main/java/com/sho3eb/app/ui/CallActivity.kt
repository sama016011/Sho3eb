@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewAssetLoader
import com.sho3eb.app.core.chat.CallBus
import com.sho3eb.app.core.chat.Chat
import com.sho3eb.app.core.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** شاشة المكالمة الصوتية/المرئية (WebRTC داخل WebView مع واجهة أصلية) */
class CallActivity : ComponentActivity() {
    private var web: WebView? = null
    private lateinit var peer: String
    private lateinit var callId: String
    private var video = false
    private var incoming = false
    private val phase = mutableStateOf("init")          // ringing_out, ringing_in, connecting, connected, reconnecting, ended
    private val muted = mutableStateOf(false)
    private val camOn = mutableStateOf(!Chat.callStartCamOff)
    private val speaker = mutableStateOf(false)
    private val remoteVideoOn = mutableStateOf(true)
    private val qualityText = mutableStateOf("")
    private val isVideo = mutableStateOf(false)
    private val dialStatus = mutableStateOf("")
    // مسار الصوت: earpiece | speaker | bluetooth
    private val route = mutableStateOf("earpiece")
    private val btAvailable = mutableStateOf(false)
    // تسجيل المكالمة
    private val recording = mutableStateOf(false)
    private val peerRecording = mutableStateOf(false)
    private var recFile: java.io.File? = null
    private var recOut: java.io.OutputStream? = null
    private var recWaiting = false
    private var logged = false
    private var connectedAt = 0L
    private var ringtone: android.media.Ringtone? = null
    private var tone: ToneGenerator? = null
    private var ended = false
    private var lastSig = 0L
    private val audio by lazy { getSystemService(AudioManager::class.java) }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) afterPermissions() else { toast(tr("يلزم إذن الميكروفون للمكالمة", "Microphone permission is required")); end(true) }
    }

    private fun toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        peer = intent.getStringExtra("peer") ?: return finish()
        callId = intent.getStringExtra("call") ?: return finish()
        video = intent.getBooleanExtra("video", false); isVideo.value = video
        incoming = intent.getBooleanExtra("incoming", false)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        CallBus.activeCall = callId
        CallBus.cancelNotification(this, callId)
        speaker.value = video && Chat.callSpeakerVideo
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { CallUi() } }
        lifecycleScope.launch { CallBus.flow.collect { s -> if (s.callId == callId) onSignal(s) } }
        // استطلاع احتياطي للإشارات
        lifecycleScope.launch(Dispatchers.IO) { while (!ended) { lastSig = CallBus.poll(callId, lastSig); delay(1500) } }
        if (incoming) { phase.value = "ringing_in"; startRingtone(); if (video && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) js("preview(true)") }
        else {
            phase.value = "ringing_out"
            if (!Chat.isBlocked(peer)) requestPerms() else { toast(tr("ألغِ حظر هذا الشخص أولاً", "Unblock this person first")); end(false) }
        }
        // انتهاء مهلة الرنين
        lifecycleScope.launch { delay(45_000); if (phase.value == "ringing_out") { CallBus.send(peer, callId, "end", "timeout"); end(false) } else if (phase.value == "ringing_in") end(false) }
    }

    private fun requestPerms() {
        val need = listOf(Manifest.permission.RECORD_AUDIO) + (if (video) listOf(Manifest.permission.CAMERA) else emptyList()) + (if (Build.VERSION.SDK_INT >= 31) listOf(Manifest.permission.BLUETOOTH_CONNECT) else emptyList())
        if (need.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) afterPermissions() else perms.launch(need.toTypedArray())
    }

    // ===================== مسارات الصوت (سماعة الأذن / مكبر الصوت / بلوتوث) =====================
    private fun btDevice(): Any? {
        if (Build.VERSION.SDK_INT >= 31) return audio.availableCommunicationDevices.firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET }
        return audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
    }
    private fun refreshBt() { btAvailable.value = runCatching { btDevice() != null }.getOrDefault(false) }
    @Suppress("DEPRECATION")
    private fun setRoute(r: String) {
        runCatching {
            if (Build.VERSION.SDK_INT >= 31) {
                val devs = audio.availableCommunicationDevices
                val d = when (r) {
                    "bluetooth" -> devs.firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET }
                    "speaker" -> devs.firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    else -> devs.firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
                }
                if (d != null) audio.setCommunicationDevice(d) else audio.clearCommunicationDevice()
            } else {
                if (r == "bluetooth") { audio.isSpeakerphoneOn = false; audio.startBluetoothSco(); audio.isBluetoothScoOn = true }
                else { if (audio.isBluetoothScoOn) { audio.isBluetoothScoOn = false; audio.stopBluetoothSco() }; audio.isSpeakerphoneOn = r == "speaker" }
            }
        }
        route.value = r; speaker.value = r == "speaker"
    }
    private fun nextRoute() {
        refreshBt()
        val order = if (btAvailable.value) listOf("bluetooth", "speaker", "earpiece") else listOf("speaker", "earpiece")
        setRoute(order[(order.indexOf(route.value) + 1) % order.size])
    }
    private val btReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { refreshBt(); if (btAvailable.value && route.value != "bluetooth" && phase.value != "ended") setRoute("bluetooth") else if (!btAvailable.value && route.value == "bluetooth") setRoute(if (isVideo.value) "speaker" else "earpiece") }
    }

    // ===================== تسجيل المكالمة =====================
    private fun startRecording() {
        if (recording.value) return
        val f = java.io.File(cacheDir, "call_rec_${System.currentTimeMillis()}.webm")
        recFile = f; recOut = f.outputStream().buffered()
        recording.value = true
        js("startRec(${isVideo.value})")
        CallBus.send(peer, callId, "rec", "on")
        toast(tr("🔴 بدأ تسجيل المكالمة (أُبلغ الطرف الآخر)", "🔴 Recording started (the other side was notified)"))
    }
    private fun stopRecording() { if (recording.value) { recWaiting = true; js("stopRec()"); CallBus.send(peer, callId, "rec", "off") } }
    private fun saveRecording(mime: String) {
        val f = recFile ?: return
        runCatching { recOut?.flush(); recOut?.close() }; recOut = null
        recording.value = false; recWaiting = false
        if (f.length() < 1000) { f.delete(); return }
        val isVid = mime.startsWith("video")
        val name = (if (isVid) "مكالمة فيديو " else "مكالمة ") + Chat.nameOf(peer).take(30) + " " + java.text.SimpleDateFormat("yyyy-MM-dd HH-mm", java.util.Locale.US).format(java.util.Date()) + ".webm"
        val ok = runCatching {
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, if (isVid) "video/webm" else "audio/webm")
                if (Build.VERSION.SDK_INT >= 29) put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, (if (isVid) "Movies" else "Music") + "/Sho3eb/Calls")
            }
            val coll = if (isVid) android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI else android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val uri = contentResolver.insert(coll, cv) ?: throw Exception("insert")
            contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        }.isSuccess
        f.delete()
        toast(if (ok) tr("✅ حُفظ التسجيل في ", "✅ Recording saved to ") + (if (isVid) "Movies" else "Music") + "/Sho3eb/Calls" else tr("تعذر حفظ التسجيل", "Couldn't save the recording"))
    }

    private fun afterPermissions() {
        audio.mode = AudioManager.MODE_IN_COMMUNICATION
        refreshBt()
        setRoute(if (btAvailable.value) "bluetooth" else if (speaker.value) "speaker" else "earpiece")
        runCatching { registerReceiver(btReceiver, android.content.IntentFilter().apply { addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED); addAction("android.bluetooth.device.action.ACL_CONNECTED"); addAction("android.bluetooth.device.action.ACL_DISCONNECTED") }) }
        js("setOptions(${Chat.callDataSaver}, ${Chat.callStartCamOff})")
        if (!incoming) {
            if (video) js("preview(true)")   // فتح الكاميرا فوراً أثناء الرنين
            val payload = JSONObject().put("video", video).put("name", Chat.nameOf(com.sho3eb.app.core.chat.Supa.uid)).toString()
            // إرسال الرنين ثم إعادته كل 4 ثوانٍ حتى الرد (لضمان الوصول)
            lifecycleScope.launch(Dispatchers.IO) {
                var first = true
                while (!ended && phase.value == "ringing_out") {
                    val err = runCatching { CallBus.sendNow(peer, callId, "ring", payload) }.exceptionOrNull()
                    if (err != null && first) withContext(Dispatchers.Main) { toast(tr("تعذر إرسال الاتصال: ", "Couldn't place the call: ") + (err.message ?: "").take(120)) }
                    if (err == null && first) withContext(Dispatchers.Main) { dialStatus.value = tr("يرن…", "Ringing…") }
                    first = false
                    delay(4_000)
                }
            }
            // نغمة انتظار هادئة (كانت عالية وتسبب صافرة في سماعة الأذن)
            runCatching { tone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 25).apply { startTone(ToneGenerator.TONE_SUP_RINGTONE) } }
        } else {
            CallBus.send(peer, callId, "accept")
            phase.value = "connecting"
            js("start(false, $video, '${CallBus.iceServers()}')")
        }
    }

    private fun onSignal(s: CallBus.Sig) {
        when (s.type) {
            "accept" -> { stopTones(); phase.value = "connecting"; js("start(true, $video, '${CallBus.iceServers()}')") }
            "reject", "busy" -> { toast(if (s.type == "busy") tr("المستخدم في مكالمة أخرى", "User is busy") else tr("تم رفض المكالمة", "Call declined")); end(false) }
            "end" -> { if (phase.value == "ringing_in") toast(tr("مكالمة فائتة", "Missed call")); end(false) }
            "rec" -> peerRecording.value = s.payload == "on"
            "offer", "answer", "ice", "video" -> js("onSignal('${s.type}', ${JSONObject.quote(s.payload)})")
        }
    }

    private var pageReady = false
    private val pendingJs = mutableListOf<String>()
    private fun js(code: String) = runOnUiThread { if (pageReady) web?.evaluateJavascript(code, null) else pendingJs += code }

    private var vibrator: android.os.Vibrator? = null
    private fun startRingtone() {
        val uri = Chat.callRingtone.takeIf { it.isNotBlank() }?.let { android.net.Uri.parse(it) } ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        runCatching { ringtone = (RingtoneManager.getRingtone(this, uri) ?: RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)))?.apply { if (Build.VERSION.SDK_INT >= 28) isLooping = true; play() } }
        if (Chat.callVibrate) runCatching {
            @Suppress("DEPRECATION") val v = getSystemService(android.os.Vibrator::class.java)
            vibrator = v
            if (Build.VERSION.SDK_INT >= 26) v?.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        }
    }
    private fun stopTones() { runCatching { ringtone?.stop() }; runCatching { tone?.stopTone(); tone?.release() }; runCatching { vibrator?.cancel() }; ringtone = null; tone = null; vibrator = null }

    private fun accept() { stopTones(); requestPerms() }
    private fun reject() { stopTones(); CallBus.send(peer, callId, "reject"); end(false) }

    /** تسجيل المكالمة في المحادثة (يرسله المتصل فيظهر عند الطرفين) مع المدة */
    private fun logCall(missed: Boolean) {
        if (incoming || logged) return
        logged = true
        val dur = if (connectedAt > 0) (System.currentTimeMillis() - connectedAt) / 1000 else 0
        lifecycleScope.launch(Dispatchers.IO) { Chat.send(listOf(peer), Chat.Content("call", dur = dur, video = video, missed = missed)) }
    }

    private fun end(sendEnd: Boolean) {
        if (ended) return
        ended = true
        if (sendEnd) CallBus.send(peer, callId, "end")
        logCall(missed = connectedAt == 0L)
        stopTones()
        val wasRec = recording.value
        if (wasRec) stopRecording()
        phase.value = "ended"
        lifecycleScope.launch {
            // انتظار حفظ التسجيل قبل الإغلاق
            if (wasRec) { var n = 0; while (recWaiting && n++ < 30) delay(100) }
            js("hangup()")
            runCatching { setRoute("earpiece"); audio.mode = AudioManager.MODE_NORMAL; @Suppress("DEPRECATION") run { audio.isSpeakerphoneOn = false } }
            runCatching { unregisterReceiver(btReceiver) }
            CallBus.activeCall = null
            delay(900); finish()
        }
    }

    override fun onDestroy() { if (!ended && ::peer.isInitialized && ::callId.isInitialized) { CallBus.send(peer, callId, "end") ; CallBus.activeCall = null }; stopTones(); web?.destroy(); super.onDestroy() }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isVideo.value && phase.value == "connected" && Build.VERSION.SDK_INT >= 26) runCatching { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(9, 16)).build()) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(c: Context): WebView {
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(c)).build()
        return WebView(c).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true; settings.mediaPlaybackRequiresUserGesture = false; settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
                override fun onPageFinished(view: WebView, url: String?) { pageReady = true; pendingJs.forEach { view.evaluateJavascript(it, null) }; pendingJs.clear() }
            }
            webChromeClient = object : WebChromeClient() { override fun onPermissionRequest(request: PermissionRequest) { runOnUiThread { request.grant(request.resources) } } }
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("https://appassets.androidplatform.net/assets/call/call.html")
            web = this
        }
    }

    inner class Bridge {
        @JavascriptInterface fun signal(type: String, payload: String) = CallBus.send(peer, callId, type, payload)
        @JavascriptInterface fun state(s: String) = runOnUiThread {
            when {
                s == "connected" -> { stopTones(); if (connectedAt == 0L) connectedAt = System.currentTimeMillis(); phase.value = "connected" }
                s == "reconnecting" || s == "disconnected" -> if (phase.value == "connected") phase.value = "reconnecting"
                s == "failed" -> phase.value = "reconnecting"
                s.startsWith("media_error") -> toast(tr("تعذر تشغيل الميكروفون/الكاميرا", "Couldn't access mic/camera"))
                s.startsWith("rec_error") -> { recording.value = false; recWaiting = false; runCatching { recOut?.close() }; toast(tr("تعذر بدء التسجيل على هذا الجهاز", "Recording isn't supported on this device")) }
            }
        }
        @JavascriptInterface fun quality(rtt: Int, loss: Int, res: String) = runOnUiThread {
            qualityText.value = (if (rtt < 150 && loss < 2) "📶 " + tr("ممتازة", "Excellent") else if (rtt < 350 && loss < 6) "📶 " + tr("جيدة", "Good") else "📶 " + tr("ضعيفة", "Weak")) + " • ${rtt}ms" + if (res != "0x0") " • $res" else ""
        }
        @JavascriptInterface fun remoteVideo(on: Boolean) = runOnUiThread { remoteVideoOn.value = on }
        @JavascriptInterface fun log(s: String) { android.util.Log.d("Sho3ebCall", s) }
        @JavascriptInterface fun recChunk(b64: String) { runCatching { recOut?.write(android.util.Base64.decode(b64, android.util.Base64.DEFAULT)) } }
        @JavascriptInterface fun recDone(mime: String) = runOnUiThread { saveRecording(mime) }
    }

    @Composable
    private fun CallUi() {
        val p = phase.value
        var secs by remember { mutableLongStateOf(0L) }
        LaunchedEffect(p) { while (p == "connected" || p == "reconnecting") { secs = if (connectedAt > 0) (System.currentTimeMillis() - connectedAt) / 1000 else 0; delay(1000) } }
        val prof = remember { Chat.profile(peer) }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(factory = { makeWeb(it) }, modifier = Modifier.fillMaxSize())
            // في مكالمات الفيديو تبقى معاينة الكاميرا ظاهرة (لا نغطيها بالخلفية)
            val showAvatar = !isVideo.value || (p == "connected" && !remoteVideoOn.value)
            if (!isVideo.value) Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B3D3A), Color(0xFF0F2027)))))
            else if (p != "connected") Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0x99000000)))))
            else if (!remoteVideoOn.value) Box(Modifier.fillMaxSize().background(Color(0xCC0F2027)))
            Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (showAvatar) {
                    ChatAvatar(peer, 120)
                    Spacer(Modifier.height(16.dp))
                }
                Text(Chat.nameOf(peer), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                if (prof?.phone?.isNotBlank() == true && showAvatar) Text("+" + prof.phone, color = Color.White.copy(alpha = 0.7f))
                Text(when (p) {
                    "ringing_out" -> dialStatus.value.ifBlank { tr("جارٍ الاتصال…", "Calling…") }; "ringing_in" -> if (isVideo.value) tr("مكالمة فيديو واردة", "Incoming video call") else tr("مكالمة صوتية واردة", "Incoming voice call")
                    "connecting" -> tr("جارٍ التوصيل…", "Connecting…"); "reconnecting" -> tr("إعادة الاتصال…", "Reconnecting…"); "ended" -> tr("انتهت المكالمة", "Call ended")
                    else -> String.format(java.util.Locale.US, "%02d:%02d", secs / 60, secs % 60)
                }, color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp))
                if (p == "connected" && qualityText.value.isNotBlank()) Text(qualityText.value, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Text("🔒 " + tr("مشفرة من طرف لطرف", "End-to-end encrypted"), color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                if (recording.value) Text("🔴 " + tr("جارٍ تسجيل المكالمة", "Recording call"), color = Color(0xFFFF6B6B), fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                if (peerRecording.value) Text("🔴 " + tr("الطرف الآخر يسجّل المكالمة", "The other side is recording"), color = Color(0xFFFF6B6B), fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (p == "ringing_in") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        RoundBtn(Icons.Filled.CallEnd, Color(0xFFDC2626), tr("رفض", "Decline")) { reject() }
                        RoundBtn(if (isVideo.value) Icons.Filled.Videocam else Icons.Filled.Call, Color(0xFF16A34A), tr("رد", "Answer")) { accept() }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        RoundBtn(if (muted.value) Icons.Filled.MicOff else Icons.Filled.Mic, if (muted.value) Color.White else Color(0x33FFFFFF), tr("كتم", "Mute"), dark = muted.value) {
                            muted.value = !muted.value; js("setMute(${muted.value})")
                        }
                        val rt = route.value
                        RoundBtn(when (rt) { "bluetooth" -> Icons.Filled.BluetoothAudio; "speaker" -> Icons.Filled.VolumeUp; else -> Icons.Filled.Hearing }, if (rt != "earpiece") Color.White else Color(0x33FFFFFF),
                            when (rt) { "bluetooth" -> tr("بلوتوث", "Bluetooth"); "speaker" -> tr("مكبر", "Speaker"); else -> tr("السماعة", "Earpiece") }, dark = rt != "earpiece") { nextRoute() }
                        if (p == "connected") RoundBtn(Icons.Filled.FiberManualRecord, if (recording.value) Color(0xFFDC2626) else Color(0x33FFFFFF), if (recording.value) tr("إيقاف", "Stop") else tr("تسجيل", "Record")) {
                            if (recording.value) stopRecording() else startRecording()
                        }
                        if (isVideo.value) {
                            RoundBtn(if (camOn.value) Icons.Filled.Videocam else Icons.Filled.VideocamOff, if (!camOn.value) Color.White else Color(0x33FFFFFF), tr("الكاميرا", "Camera"), dark = !camOn.value) {
                                camOn.value = !camOn.value; js("setVideo(${camOn.value})")
                            }
                            RoundBtn(Icons.Filled.Cameraswitch, Color(0x33FFFFFF), tr("تبديل", "Flip")) { js("switchCamera()") }
                        } else if (p == "connected") RoundBtn(Icons.Filled.Videocam, Color(0x33FFFFFF), tr("فيديو", "Video")) {
                            if (ContextCompat.checkSelfPermission(this@CallActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) { isVideo.value = true; if (route.value != "bluetooth") setRoute("speaker"); js("addVideo()") }
                            else perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA))
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                    RoundBtn(Icons.Filled.CallEnd, Color(0xFFDC2626), tr("إنهاء", "End"), size = 72) { end(true) }
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(icon: ImageVector, bg: Color, label: String, dark: Boolean = false, size: Int = 60, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(size.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) { Icon(icon, label, tint = if (dark) Color.Black else Color.White, modifier = Modifier.size((size * 0.45).dp)) }
        }
        Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
