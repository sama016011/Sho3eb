@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.*
import com.sho3eb.app.data.Attachment
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.io.File

/** زر المرفقات مع عدّاد. يفتح نافذة إدارة المرفقات */
@Composable
fun AttachmentButton(type: String, ownerId: Long, phone: String? = null) {
    val dao = remember { appDao() }
    val list by flowState(emptyList<Attachment>(), type, ownerId) { dao.attachmentsFlow(type, ownerId) }
    var show by remember { mutableStateOf(false) }
    IconButton(onClick = { show = true }) {
        BadgedBox(badge = { if (list.isNotEmpty()) Badge { Text("${list.size}") } }) {
            Icon(Icons.Filled.AttachFile, contentDescription = tr("المرفقات", "Attachments"),
                tint = if (list.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (show) AttachmentsDialog(type, ownerId, phone) { show = false }
}

@Composable
fun AttachmentsDialog(type: String, ownerId: Long, phone: String?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val list by flowState(emptyList<Attachment>(), type, ownerId) { dao.attachmentsFlow(type, ownerId) }
    var camFile by remember { mutableStateOf<File?>(null) }
    var toDelete by remember { mutableStateOf<Attachment?>(null) }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            Attachments.addAll(ctx, type, ownerId, uris)
            toast(ctx, tr("تم إرفاق ${uris.size} ملف", "${uris.size} file(s) attached"))
        }
    }
    var camPending by remember { mutableStateOf<android.net.Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = camFile
        if (ok && f != null) scope.launch { Attachments.registerFile(type, ownerId, f) } else f?.delete()
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> val u = camPending; if (ok && u != null) camera.launch(u) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.AttachFile, null) },
        title = { Text(tr("المرفقات", "Attachments")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(
                        onClick = { pickFiles.launch(arrayOf("*/*")) },
                        label = { Text(tr("ملف / صورة", "File / image")) },
                        leadingIcon = { Icon(Icons.Filled.FileUpload, null, Modifier.size(18.dp)) }
                    )
                    AssistChip(
                        onClick = {
                            try {
                                val f = Attachments.newCameraFile(ctx)
                                camFile = f
                                Share.uriFor(ctx, f).let { u -> if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) camera.launch(u) else { camPending = u; camPerm.launch(android.Manifest.permission.CAMERA) } }
                            } catch (e: Exception) {
                                toast(ctx, tr("تعذر فتح الكاميرا", "Cannot open camera"))
                            }
                        },
                        label = { Text(tr("كاميرا", "Camera")) },
                        leadingIcon = { Icon(Icons.Filled.PhotoCamera, null, Modifier.size(18.dp)) }
                    )
                }
                if (list.isEmpty()) {
                    Text(
                        tr("لا توجد مرفقات. أرفق إيصالاً أو صورة أو أي ملف.", "No attachments. Attach a receipt, photo or any file."),
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(list, key = { it.id }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { Attachments.open(ctx, a) }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                when {
                                    a.mime.startsWith("image") -> Icons.Filled.Image
                                    a.mime.contains("pdf") -> Icons.Filled.PictureAsPdf
                                    a.mime.startsWith("audio") -> Icons.Filled.LibraryMusic
                                    else -> Icons.Filled.InsertDriveFile
                                }, null, tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    Attachments.sizeText(a.size) + " • " + Fmt.date(java.time.Instant.ofEpochMilli(a.createdAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate()),
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (!phone.isNullOrBlank()) IconButton(onClick = { Attachments.share(ctx, a, phone, true) }) {
                                Icon(Icons.Filled.Chat, null, tint = WhatsGreen)
                            }
                            IconButton(onClick = { Attachments.share(ctx, a, phone, false) }) { Icon(Icons.Filled.Share, null) }
                            IconButton(onClick = { toDelete = a }) { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("تم", "Done")) } }
    )
    toDelete?.let { a ->
        ConfirmDialog(
            title = tr("حذف المرفق", "Delete attachment"),
            text = a.name,
            confirmText = tr("حذف", "Delete"),
            onDismiss = { toDelete = null }
        ) { scope.launch { Attachments.delete(a) } }
    }
}

/** زر إرفاق داخل نافذة الإدخال قبل الحفظ */
@Composable
fun PendingAttachRow(pending: SnapshotStateList<Uri>) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { if (it !in pending) pending.add(it) }
    }
    OutlinedButton(onClick = { pick.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.AttachFile, null)
        Spacer(Modifier.width(6.dp))
        Text(
            if (pending.isEmpty()) tr("إرفاق ملف / صورة (اختياري)", "Attach file / image (optional)")
            else tr("تم اختيار ${pending.size} مرفق", "${pending.size} attachment(s) selected")
        )
    }
    if (pending.isNotEmpty()) TextButton(onClick = { pending.clear() }) { Text(tr("إزالة المرفقات المختارة", "Clear selected")) }
}
