@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun FxScreen(nav: NavController) {
    ScreenScaffold(title = tr("العملات الأجنبية", "Foreign currencies"), onBack = { nav.popBackStack() }) { p ->
        Box(Modifier.padding(p)) { FxPane(nav) }
    }
}

/** تبويب العملات الأجنبية: حيازات المستخدم وقيمتها الحالية بالعملة الرئيسية */
@Composable
fun FxPane(nav: NavController) {
    val scope = rememberCoroutineScope()
    var ver by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Fx.Holding?>(null) }
    var adding by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var conv by remember { mutableStateOf(false) }
    fun refresh(force: Boolean) {
        if (loading) return
        loading = true
        scope.launch { failed = !Fx.refresh(force); loading = false; ver++ }
    }
    LaunchedEffect(Unit) {
        while (true) {
            if (Fx.auto) { failed = !Fx.refresh(false); ver++ }
            delay(60_000)
        }
    }
    val main = remember(ver) { Fx.main }
    val list = remember(ver) { Fx.holdings.sortedByDescending { Fx.value(it) ?: 0.0 } }
    val total = remember(ver) { Fx.totalValue() }
    val cost = remember(ver) { Fx.totalCost() }
    val withCost = list.filter { it.buyRate > 0 }
    val pl = withCost.sumOf { Fx.profit(it) ?: 0.0 }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary)) {
                    Column(Modifier.padding(18.dp)) {
                        val on = MaterialTheme.colorScheme.onTertiary
                        Text(tr("قيمة عملاتك الأجنبية بـ ", "Your foreign cash in ") + Fx.label(main), color = on.copy(alpha = 0.85f))
                        Text(Fx.fmt(total, main), color = on, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        if (cost > 0) Text((if (pl >= 0) tr("ربح فرق العملة ", "FX gain ") else tr("خسارة فرق العملة ", "FX loss ")) + Fx.fmt(kotlin.math.abs(pl), main) +
                            " (" + String.format(java.util.Locale.US, "%.1f", pl / cost * 100) + "%)", color = on.copy(alpha = 0.9f), style = MaterialTheme.typography.bodySmall)
                        Text((if (Fx.auto) "🟢 " + tr("أسعار مباشرة • ", "Live rates • ") else "⏸ ") + Fx.agoText() + if (failed) tr(" • تعذر التحديث", " • update failed") else "",
                            color = on.copy(alpha = 0.85f), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("أسعار الصرف مقابل ", "Rates vs ") + main, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            if (loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else IconButton(onClick = { refresh(true) }) { Icon(Icons.Filled.Refresh, null) }
                            IconButton(onClick = { conv = true }) { Icon(Icons.Filled.SwapHoriz, null) }
                            IconButton(onClick = { settings = true }) { Icon(Icons.Filled.Settings, null) }
                        }
                        key(ver) {
                            Fx.watched.filter { it != main }.forEach { c ->
                                val r = Fx.rate(c)
                                val t = Fx.trend(c)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(Fx.flag(c), fontSize = 20.sp); Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("1 $c", fontWeight = FontWeight.SemiBold)
                                        Text(Fx.label(c) + if (Fx.manual(c) > 0) tr(" • يدوي", " • manual") else "", style = MaterialTheme.typography.labelSmall)
                                    }
                                    if (t != 0) Icon(if (t > 0) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward, null, tint = if (t > 0) SuccessGreen else DangerRed, modifier = Modifier.size(16.dp))
                                    Text(if (r != null) Fx.fmt(r, main) else "—", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
            if (list.isEmpty()) item { EmptyState(Icons.Filled.CurrencyExchange, tr("أضف ما تملكه من عملات أجنبية (دولار، يورو، ريال...) لمعرفة قيمتها الحالية بعملتك.", "Add the foreign cash you hold to see its current value.")) }
            else {
                item { SectionTitle(tr("حيازاتك", "Your holdings")) }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Fx.byCurrency().take(4).forEach { (c, a) -> AssistChip(onClick = {}, label = { Text(Fx.flag(c) + " " + Fmt.num(a).removeSuffix(".00") + " " + c) }) }
                    }
                }
                items(list, key = { it.id }) { h ->
                    val v = Fx.value(h)
                    Card(onClick = { edit = h }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(Fx.flag(h.code), fontSize = 28.sp); Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(Fmt.num(h.amount).removeSuffix(".00") + " " + h.code, fontWeight = FontWeight.Bold)
                                Text(Fx.label(h.code) + (if (h.note.isNotBlank()) " • " + h.note else ""), style = MaterialTheme.typography.bodySmall)
                                if (h.buyRate > 0) Text(tr("التكلفة ", "Cost ") + Fx.fmt(Fx.cost(h), main) + tr(" • سعر الوحدة ", " • unit ") + Fx.fmt(Fx.unitBuy(h), main), style = MaterialTheme.typography.labelSmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(if (v != null) Fx.fmt(v, main) else "—", fontWeight = FontWeight.Bold)
                                Fx.profit(h)?.let { d ->
                                    Text((if (d >= 0) tr("▲ ربح ", "▲ gain ") else tr("▼ خسارة ", "▼ loss ")) + Fmt.num(kotlin.math.abs(d)), color = if (d >= 0) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
            item { InfoBanner(tr("الأسعار من open.er-api.com وتتحدث تلقائياً كل دقيقة أثناء فتح الشاشة. يمكنك وضع سعر يدوي لأي عملة (سعر السوق المحلي) من الإعدادات ⚙️.", "Rates from open.er-api.com, refreshed every minute while open. Set a manual (local market) rate in ⚙️.")) }
        }
        ExtendedFloatingActionButton(onClick = { adding = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("عملة", "Currency")) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp))
    }

    if (adding || edit != null) HoldingDialog(edit, onDismiss = { adding = false; edit = null; ver++ })
    if (settings) FxSettingsDialog { settings = false; refresh(true) }
    if (conv) ConverterDialog { conv = false }
}

@Composable
private fun CurrencyDropdown(value: String, label: String, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text(Fx.flag(value) + " " + value + " • " + label) }
        DropdownMenu(open, { open = false }, Modifier.heightIn(max = 360.dp)) {
            Fx.allCodes.forEach { c -> DropdownMenuItem(text = { Text(Fx.flag(c) + "  " + c + " — " + Fx.label(c)) }, onClick = { open = false; onPick(c) }) }
        }
    }
}

@Composable
private fun HoldingDialog(h: Fx.Holding?, onDismiss: () -> Unit) {
    var code by remember { mutableStateOf(h?.code ?: Fx.watched.firstOrNull { it != Fx.main } ?: "USD") }
    var amount by remember { mutableStateOf(h?.amount?.let { Fmt.num(it).removeSuffix(".00").replace(",", "") } ?: "") }
    var paid by remember { mutableStateOf(h?.let { x -> Fx.cost(x).takeIf { it > 0 }?.let { String.format(java.util.Locale.US, "%.2f", it) } } ?: "") }
    var byUnit by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf(h?.note ?: "") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (h == null) tr("إضافة عملة أجنبية", "Add foreign currency") else tr("تعديل", "Edit")) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CurrencyDropdown(code, Fx.label(code)) { code = it }
            NumberField(amount, { amount = it }, tr("المبلغ", "Amount"))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(!byUnit, { byUnit = false }, label = { Text(tr("المبلغ المدفوع إجمالاً", "Total paid")) })
                FilterChip(byUnit, { byUnit = true }, label = { Text(tr("سعر الوحدة", "Unit rate")) })
            }
            NumberField(paid, { paid = it }, (if (byUnit) tr("سعر شراء الوحدة بـ ", "Buy rate per unit in ") else tr("إجمالي ما دفعته بـ ", "Total you paid in ")) + Fx.main + tr(" (اختياري)", " (optional)"))
            Fx.rate(code)?.let { r -> TextButton(onClick = { val a0 = Fmt.parse(amount) ?: 0.0; paid = String.format(java.util.Locale.US, "%.2f", if (byUnit) r else r * a0) }) { Text(tr("استخدم السعر الحالي: ", "Use current rate: ") + Fx.fmt(r, Fx.main)) } }
            run {
                val a0 = Fmt.parse(amount) ?: 0.0; val p0 = Fmt.parse(paid) ?: 0.0
                val unit = if (byUnit) p0 else if (a0 > 0) p0 / a0 else 0.0
                val r = Fx.rate(code)
                if (p0 > 0 && a0 > 0 && r != null) {
                    val gain = a0 * r - unit * a0
                    Text(tr("سعر الوحدة: ", "Unit: ") + Fx.fmt(unit, Fx.main) + "\n" + (if (gain >= 0) tr("ربح حالي: ", "Current gain: ") else tr("خسارة حالية: ", "Current loss: ")) + Fx.fmt(kotlin.math.abs(gain), Fx.main),
                        color = if (gain >= 0) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                }
            }
            OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة (مكان الحفظ، الغرض...)", "Note (where kept, purpose...)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            val a = Fmt.parse(amount) ?: 0.0
            Fx.rate(code)?.let { r -> if (a > 0) Text(tr("القيمة الحالية: ", "Current value: ") + Fx.fmt(a * r, Fx.main), fontWeight = FontWeight.Bold) }
        }
    }, confirmButton = {
        TextButton(onClick = {
            val a = Fmt.parse(amount) ?: 0.0
            val p0 = Fmt.parse(paid) ?: 0.0
            val unit = if (byUnit) p0 else if (a > 0) p0 / a else 0.0
            if (a > 0) Fx.upsert(Fx.Holding(h?.id ?: System.currentTimeMillis(), code, a, unit, note.trim(), h?.date ?: System.currentTimeMillis()))
            onDismiss()
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = {
        Row {
            if (h != null) TextButton(onClick = { Fx.delete(h.id); onDismiss() }) { Text(tr("حذف", "Delete"), color = DangerRed) }
            TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) }
        }
    })
}

/** إعدادات العملات: العملة الرئيسية، العملات المتابعة، الأسعار اليدوية */
@Composable
fun FxSettingsDialog(onDismiss: () -> Unit) {
    var main by remember { mutableStateOf(Fx.main) }
    var watched by remember { mutableStateOf(Fx.watched) }
    var auto by remember { mutableStateOf(Fx.auto) }
    var manualFor by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("إعدادات العملات", "Currency settings")) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("العملة الرئيسية (تُحسب بها القيم)", "Main currency (values are shown in it)"), style = MaterialTheme.typography.labelLarge)
            CurrencyDropdown(main, Fx.label(main)) { main = it }
            SwitchRow(tr("تحديث تلقائي للأسعار", "Auto-update rates"), null, auto) { auto = it }
            Text(tr("العملات الأجنبية المتابعة (اضغط مطولاً لسعر يدوي)", "Watched foreign currencies (long-press for a manual rate)"), style = MaterialTheme.typography.labelLarge)
            Fx.allCodes.filter { it != main }.forEach { c ->
                Row(Modifier.fillMaxWidth().clickable { watched = if (c in watched) watched - c else watched + c }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(c in watched, { watched = if (it) watched + c else watched - c })
                    Text(Fx.flag(c) + " " + c + " — " + Fx.label(c), Modifier.weight(1f))
                    TextButton(onClick = { manualFor = c }) { Text(if (Fx.manual(c) > 0) "✍️ " + Fmt.num(Fx.manual(c)) else tr("سعر يدوي", "Manual")) }
                }
            }
        }
    }, confirmButton = {
        TextButton(onClick = {
            if (main != Fx.main) { Fx.allCodes.forEach { Fx.setManual(it, 0.0) } }
            Fx.main = main; Fx.watched = watched; Fx.auto = auto
            Fx.symbols[main]?.let { sym -> appPrefs().currency = sym; AppState.currency.value = sym }
            onDismiss()
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } })
    manualFor?.let { c ->
        var v by remember(c) { mutableStateOf(Fx.manual(c).takeIf { it > 0 }?.toString() ?: "") }
        AlertDialog(onDismissRequest = { manualFor = null }, title = { Text(tr("سعر يدوي لـ ", "Manual rate for ") + c) }, text = {
            Column {
                Text(tr("قيمة 1 $c بـ $main (اتركه فارغاً للسعر المباشر)", "Value of 1 $c in $main (blank = live)"), style = MaterialTheme.typography.bodySmall)
                NumberField(v, { v = it }, main)
            }
        }, confirmButton = { TextButton(onClick = { Fx.setManual(c, Fmt.parse(v) ?: 0.0); manualFor = null }) { Text(tr("حفظ", "Save")) } },
            dismissButton = { TextButton(onClick = { manualFor = null }) { Text(tr("إلغاء", "Cancel")) } })
    }
}

@Composable
private fun ConverterDialog(onDismiss: () -> Unit) {
    var from by remember { mutableStateOf(Fx.watched.firstOrNull { it != Fx.main } ?: "USD") }
    var to by remember { mutableStateOf(Fx.main) }
    var amt by remember { mutableStateOf("1") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("محوّل العملات", "Currency converter")) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField(amt, { amt = it }, tr("المبلغ", "Amount"))
            CurrencyDropdown(from, tr("من", "From")) { from = it }
            IconButton(onClick = { val t = from; from = to; to = t }) { Icon(Icons.Filled.SwapVert, null) }
            CurrencyDropdown(to, tr("إلى", "To")) { to = it }
            val r = Fx.convert(Fmt.parse(amt) ?: 0.0, from, to)
            Text(if (r != null) Fx.fmt(r, to) else tr("حدّث الأسعار أولاً", "Update rates first"), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } })
}
