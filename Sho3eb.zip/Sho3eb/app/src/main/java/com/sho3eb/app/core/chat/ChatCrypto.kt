package com.sho3eb.app.core.chat

import android.util.Base64
import com.sho3eb.app.core.Extras
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** تشفير من طرف لطرف: ECDH (P-256) لاشتقاق مفتاح مشترك + AES-256-GCM */
object ChatCrypto {
    private val rnd = SecureRandom()
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    private fun ensureKeys() {
        if (Extras.s("chat_priv", "").isNotBlank()) return
        val g = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1"), rnd) }
        val kp = g.generateKeyPair()
        Extras.ps("chat_priv", b64(kp.private.encoded)); Extras.ps("chat_pub", b64(kp.public.encoded))
    }
    val publicKey: String get() { ensureKeys(); return Extras.s("chat_pub", "") }
    private val privateKey: PrivateKey get() { ensureKeys(); return KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(unb64(Extras.s("chat_priv", "")))) }

    private val cache = HashMap<String, ByteArray>()
    /** مفتاح المحادثة المشترك مع صديق */
    fun sharedKey(theirPub: String): ByteArray = cache.getOrPut(theirPub) {
        val pub: PublicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(unb64(theirPub)))
        val ka = KeyAgreement.getInstance("ECDH"); ka.init(privateKey); ka.doPhase(pub, true)
        hkdf(ka.generateSecret(), "sho3eb-chat-v1".toByteArray())
    }

    private fun hkdf(ikm: ByteArray, info: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(ByteArray(32), "HmacSHA256")); val prk = mac.doFinal(ikm)
        mac.init(SecretKeySpec(prk, "HmacSHA256")); mac.update(info); mac.update(1)
        return mac.doFinal()
    }

    fun randomKey(): ByteArray = ByteArray(32).also { rnd.nextBytes(it) }

    fun encryptBytes(key: ByteArray, data: ByteArray): ByteArray {
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return iv + c.doFinal(data)
    }
    fun decryptBytes(key: ByteArray, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, data, 0, 12))
        return c.doFinal(data, 12, data.size - 12)
    }
    fun encrypt(key: ByteArray, text: String): String = "e1:" + b64(encryptBytes(key, text.toByteArray(Charsets.UTF_8)))
    fun decrypt(key: ByteArray, s: String): String? = runCatching { if (!s.startsWith("e1:")) null else String(decryptBytes(key, unb64(s.removePrefix("e1:"))), Charsets.UTF_8) }.getOrNull()
    fun keyB64(k: ByteArray) = b64(k)
    fun keyFrom(s: String) = unb64(s)
}
