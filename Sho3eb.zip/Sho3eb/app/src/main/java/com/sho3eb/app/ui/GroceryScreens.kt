@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch

@Composable
fun GroceryScreen(nav: NavController) {
    val dao = remember { appDao() }
    val books by flowState(emptyList<CreditBook>()) { dao.creditBooksFlow() }
    val entries by flowState(emptyList<CreditEntry>()) { dao.creditEntriesFlow() }
    var mode by rememberSaveable { mutableStateOf(Grocery.OWE_ME) }
    var q by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableIntStateOf(0) }
    var add by remember { mutableStateOf(false) }
    var quick by remember { mutableStateOf<CreditBook?>(null) }
    val all = remember(books, entries) { Grocery.books(books, entries) }
    val mine = all.filter { it.b.mode == mode }
    val list = mine.filter { q.isBlank() || it.b.name.contains(q, true) || it.b.phone.contains(q) }.let { l ->
        when (sort) { 0 -> l.sortedByDescending { it.balance }; 1 -> l.sortedByDescending { it.daysSincePay ?: -1 }; else -> l.sortedBy { it.b.name } }
    }.sortedBy { it.b.closed }
    ScreenScaffold(
        title = tr("دفتر ديون البقالة", "Grocery credit book"), onBack = { nav.popBackStack() },
        actions = { PdfShareButton(null, doc = { Grocery.allDoc(mine, mode) }) { c -> Reports.doc(c, Grocery.allDoc(mine, mode)) } },
        fab = { ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.PersonAdd, null) }, text = { Text(if (mode == Grocery.OWE_ME) tr("زبون", "Customer") else tr("محل", "Shop")) }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                TabRow(if (mode == Grocery.OWE_ME) 0 else 1) {
                    Tab(mode == Grocery.OWE_ME, { mode = Grocery.OWE_ME }, text = { Text(tr("زبائني (لي عندهم)", "My customers")) })
                    Tab(mode == Grocery.I_OWE, { mode = Grocery.I_OWE }, text = { Text(tr("حسابي عند المحلات", "My tabs")) })
                }
            }
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(if (mode == Grocery.OWE_ME) tr("إجمالي المستحق على الزبائن", "Total owed by customers") else tr("إجمالي ما عليّ للمحلات", "Total I owe shops"), color = Color.White.copy(alpha = 0.85f))
                        Text(Fmt.money(mine.sumOf { it.balance }), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(tr("مشتريات هذا الشهر: ", "This month: ") + Fmt.money(mine.sumOf { it.monthBought }) + tr(" • متأخرون +30 يوم: ", " • 30+ days late: ") + mine.count { (it.daysSincePay ?: 0) > 30 },
                            color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { SearchField(q) { q = it } }
            item {
                HChips {
                    listOf(tr("الأعلى رصيداً", "Highest balance"), tr("الأقدم سداداً", "Longest unpaid"), tr("الاسم", "Name")).forEachIndexed { i, t -> FilterChip(sort == i, { sort = i }, label = { Text(t) }) }
                }
            }
            if (list.isEmpty()) item {
                EmptyState(Icons.Filled.MenuBook, if (mode == Grocery.OWE_ME) tr("سجّل زبائن الآجل: كل سحب بضاعة وكل سداد، مع تذكير واتساب وكشف PDF.", "Record customers who buy on credit, with WhatsApp reminders and PDF statements.")
                    else tr("سجّل حسابك عند البقالة أو الجزار أو الصيدلية لتعرف ما عليك دائماً.", "Track your tab at the grocer, butcher or pharmacy."))
            }
            items(list, key = { it.b.id }) { k ->
                Card(onClick = { nav.navigate("credit/${k.b.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(null, k.b.name, 42.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(k.b.name + if (k.b.closed) tr(" (مغلق)", " (closed)") else "", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val d = k.daysSincePay
                            Text(
                                (k.lastBuy?.let { tr("آخر سحب ", "Last buy ") + Fmt.date(it) } ?: tr("لا حركات", "No entries")) + (if (d != null && d > 0) tr(" • بدون سداد منذ $d يوم", " • unpaid for $d days") else ""),
                                style = MaterialTheme.typography.bodySmall, color = if ((d ?: 0) > 30) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.money(k.balance), fontWeight = FontWeight.Bold, color = if (k.balance <= 0.01) SuccessGreen else if (k.overLimit) DangerRed else WarnAmber)
                            if (k.overLimit) Text(tr("تجاوز الحد", "Over limit"), style = MaterialTheme.typography.labelSmall, color = DangerRed)
                        }
                        IconButton(onClick = { quick = k.b }) { Icon(Icons.Filled.AddShoppingCart, null, tint = MaterialTheme.colorScheme.primary) }
                    }
                }
            }
        }
    }
    if (add) CreditBookDialog(null, mode) { id -> add = false; if (id != null) nav.navigate("credit/$id") }
    quick?.let { b -> CreditEntryDialog(b, Grocery.BUY, null) { quick = null } }
}

@Composable
fun CreditBookScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val books by flowState(emptyList<CreditBook>()) { dao.creditBooksFlow() }
    val entries by flowState(emptyList<CreditEntry>()) { dao.creditEntriesFlow() }
    val b = books.firstOrNull { it.id == id }
    var entry by remember { mutableStateOf<String?>(null) }
    var editEntry by remember { mutableStateOf<CreditEntry?>(null) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var delEntry by remember { mutableStateOf<CreditEntry?>(null) }
    val (ps, pf, pt) = rememberPeriod(4)
    val range = periodRange(ps.value, pf.value, pt.value)
    if (b == null) { ScreenScaffold(tr("الدفتر", "Book"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val k = Grocery.Book(b, entries.filter { it.bookId == b.id })
    val rows = k.rows().filter { range == null || it.e.date in range }
    val oweMe = b.mode == Grocery.OWE_ME
    ScreenScaffold(
        title = b.name, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(b.phone.ifBlank { null }, doc = { Grocery.doc(k, range) }) { c -> Reports.doc(c, Grocery.doc(k, range)) }
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (k.overLimit) DangerRed else MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(if (oweMe) tr("المستحق على الزبون", "Customer owes") else tr("المستحق عليّ", "I owe"), color = Color.White.copy(alpha = 0.85f))
                        Text(Fmt.money(k.balance), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text(tr("مشتريات ", "Bought ") + Fmt.money(k.bought) + tr(" • مسدد ", " • paid ") + Fmt.money(k.paid), color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
                        if (b.creditLimit > 0) Text(tr("الحد: ", "Limit: ") + Fmt.money(b.creditLimit) + if (k.overLimit) tr(" ⚠️ تم تجاوزه", " ⚠️ exceeded") else "", color = Color.White, style = MaterialTheme.typography.bodySmall)
                        k.daysSincePay?.takeIf { it > 0 }?.let { Text(tr("⏳ آخر سداد منذ $it يوم", "⏳ Last payment $it days ago"), color = Color.White, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { entry = Grocery.BUY }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = WarnAmber)) { Icon(Icons.Filled.AddShoppingCart, null); Spacer(Modifier.width(4.dp)); Text(tr("مشتريات", "Purchase")) }
                    Button(onClick = { entry = Grocery.PAY }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Icon(Icons.Filled.Payments, null); Spacer(Modifier.width(4.dp)); Text(tr("سداد", "Payment")) }
                }
            }
            if (b.phone.isNotBlank()) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { Share.whatsappMessage(ctx, b.phone, Grocery.reminder(k)) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Chat, null, tint = WhatsGreen); Spacer(Modifier.width(4.dp)); Text(if (oweMe) tr("تذكير واتساب", "WhatsApp reminder") else tr("طلب كشف", "Ask statement"))
                    }
                    OutlinedButton(onClick = { Share.dial(ctx, b.phone) }) { Icon(Icons.Filled.Call, null) }
                }
            }
            item { PeriodPicker(ps, pf, pt) }
            if (rows.isEmpty()) item { Text(tr("لا توجد حركات", "No entries"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(rows.reversed(), key = { it.e.id }) { r ->
                val buy = r.e.type == Grocery.BUY
                Card(onClick = { editEntry = r.e }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (buy) Icons.Filled.ShoppingBasket else Icons.Filled.Payments, null, tint = if (buy) WarnAmber else SuccessGreen)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.e.items.ifBlank { if (buy) tr("مشتريات", "Purchase") else tr("سداد", "Payment") }, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(Fmt.date(r.e.date) + tr(" • الرصيد ", " • balance ") + Fmt.num(r.balance) + (if (r.e.note.isNotBlank()) " • " + r.e.note else ""), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                        Text((if (buy) "+" else "−") + Fmt.num(r.e.amount), fontWeight = FontWeight.Bold, color = if (buy) WarnAmber else SuccessGreen)
                        AttachmentButton(Attachments.CREDIT, r.e.id)
                        IconButton(onClick = { delEntry = r.e }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                    }
                }
            }
            item {
                Row {
                    TextButton(onClick = { scope.launch { dao.updateCreditBook(b.copy(closed = !b.closed)) } }) { Text(if (b.closed) tr("إعادة فتح الدفتر", "Reopen") else tr("إغلاق الدفتر", "Close book")) }
                    TextButton(onClick = { del = true }) { Text(tr("حذف الدفتر", "Delete book"), color = DangerRed) }
                }
            }
        }
    }
    entry?.let { t -> CreditEntryDialog(b, t, null) { entry = null } }
    editEntry?.let { e -> CreditEntryDialog(b, e.type, e) { editEntry = null } }
    if (edit) CreditBookDialog(b, b.mode) { edit = false }
    delEntry?.let { e ->
        ConfirmDialog(tr("حذف الحركة", "Delete entry"), Fmt.money(e.amount), onDismiss = { delEntry = null }) {
            delEntry = null
            scope.launch { Attachments.deleteFor(Attachments.CREDIT, e.id); dao.deleteLinkedTx(AccountTx.SRC_CREDIT, e.id); dao.deleteCreditEntry(e.id) }
        }
    }
    if (del) ConfirmDialog(tr("حذف الدفتر", "Delete book"), tr("سيُحذف «${b.name}» وكل حركاته.", "This book and all its entries will be deleted."), onDismiss = { del = false }) {
        del = false
        scope.launch { dao.deleteCreditBookFull(b.id); nav.popBackStack() }
    }
}

@Composable
fun CreditBookDialog(existing: CreditBook?, mode: String, onDone: (Long?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var personId by remember { mutableStateOf(existing?.personId) }
    var limit by remember { mutableStateOf(existing?.creditLimit?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var opening by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var m by remember { mutableStateOf(existing?.mode ?: mode) }
    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text(existing?.name ?: if (m == Grocery.OWE_ME) tr("زبون آجل جديد", "New credit customer") else tr("حساب عند محل", "New shop tab")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HChips {
                    FilterChip(m == Grocery.OWE_ME, { m = Grocery.OWE_ME }, label = { Text(tr("زبون عندي", "My customer")) })
                    FilterChip(m == Grocery.I_OWE, { m = Grocery.I_OWE }, label = { Text(tr("محل أتعامل معه", "A shop I use")) })
                }
                PersonSelector(null, tr("من جهات الاتصال", "From contacts")) { p -> name = p.name; phone = p.phone; personId = p.id }
                OutlinedTextField(name, { name = it }, label = { Text(if (m == Grocery.OWE_ME) tr("اسم الزبون", "Customer name") else tr("اسم المحل", "Shop name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text(tr("الجوال", "Phone")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                MoneyField(limit, { limit = it }, tr("الحد الأقصى للدين (اختياري)", "Credit limit (optional)"))
                if (existing == null) MoneyField(opening, { opening = it }, tr("رصيد سابق (اختياري)", "Previous balance (optional)"))
                NotesField(notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل الاسم", "Enter the name")); return@TextButton }
                val x = CreditBook(name = name.trim(), phone = phone.trim(), personId = personId, mode = m, creditLimit = Fmt.parse(limit) ?: 0.0, notes = notes.trim())
                scope.launch {
                    if (existing == null) {
                        val id = dao.insertCreditBook(x)
                        val ob = Fmt.parse(opening) ?: 0.0
                        if (ob > 0) dao.insertCreditEntry(CreditEntry(bookId = id, type = Grocery.BUY, amount = ob, items = tr("رصيد سابق", "Previous balance"), date = Fmt.today()))
                        onDone(id)
                    } else { dao.updateCreditBook(x.copy(id = existing.id, closed = existing.closed, createdAt = existing.createdAt)); onDone(existing.id) }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
fun CreditEntryDialog(b: CreditBook, type: String, existing: CreditEntry?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var t by remember { mutableStateOf(existing?.type ?: type) }
    var amount by remember { mutableStateOf(existing?.amount?.let { Fmt.plain(it) } ?: "") }
    var items by remember { mutableStateOf(existing?.items ?: "") }
    var date by remember { mutableStateOf(existing?.date ?: Fmt.today()) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    val acc = remember { mutableStateOf(Posting.lastAccount("credit_" + b.mode)) }
    var toLiving by remember { mutableStateOf(b.mode == Grocery.I_OWE && existing == null) }
    val pending = remember { mutableStateListOf<Uri>() }
    val quickItems = listOf(tr("خبز", "Bread"), tr("حليب", "Milk"), tr("بيض", "Eggs"), tr("أرز", "Rice"), tr("سكر", "Sugar"), tr("زيت", "Oil"), tr("شاي", "Tea"), tr("جبن", "Cheese"), tr("خضار", "Vegetables"), tr("فاكهة", "Fruit"), tr("منظفات", "Detergent"), tr("مياه", "Water"))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(b.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HChips {
                    FilterChip(t == Grocery.BUY, { t = Grocery.BUY }, label = { Text(tr("🛒 مشتريات بالآجل", "🛒 On credit")) })
                    FilterChip(t == Grocery.PAY, { t = Grocery.PAY }, label = { Text(tr("💵 سداد", "💵 Payment")) })
                }
                SmartInputRow(onVoice = { r ->
                    r.amount?.let { amount = Fmt.plain(it) }
                    if (r.title.isNotBlank()) { if (t == Grocery.BUY) items = r.title else note = r.title }
                    val n = VoiceParse.norm(r.text); if (listOf("سدد", "دفع", "سداد", "paid").any { n.contains(it) }) t = Grocery.PAY
                    date = r.date
                }, onScan = if (t == Grocery.BUY) { r, f ->
                    r.total?.let { amount = Fmt.plain(it) }
                    r.date?.let { date = it }
                    if (items.isBlank()) items = r.lines.take(15).joinToString("، ") { it.name + if (it.qty > 1) " ×" + Fmt.num(it.qty) else "" }
                    pending.add(Share.uriFor(ctx, f))
                } else null)
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                if (t == Grocery.BUY) {
                    OutlinedTextField(items, { items = it }, label = { Text(tr("الأصناف (اختياري)", "Items (optional)")) }, modifier = Modifier.fillMaxWidth())
                    HChips { quickItems.forEach { q -> AssistChip({ items = if (items.isBlank()) q else "$items، $q" }, label = { Text(q) }) } }
                }
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (t == Grocery.PAY && existing == null) AccountPickRow(acc, if (b.mode == Grocery.OWE_ME) tr("إيداع في حساب (اختياري)", "Deposit to account (optional)") else tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
                if (t == Grocery.BUY && b.mode == Grocery.I_OWE && existing == null) SwitchRow(tr("سجّلها أيضاً في مصاريف المعيشة (طعام)", "Also add to living expenses (food)"), null, toLiving) { toLiving = it }
                if (existing == null) PendingAttachRow(pending)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(amount)
                if (v == null || v <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                val x = CreditEntry(bookId = b.id, type = t, amount = v, items = if (t == Grocery.BUY) items.trim() else "", date = date, note = note.trim())
                scope.launch {
                    if (existing != null) { dao.updateCreditEntry(x.copy(id = existing.id, createdAt = existing.createdAt)); onDismiss(); return@launch }
                    val id = dao.insertCreditEntry(x)
                    Attachments.addAll(ctx, Attachments.CREDIT, id, pending.toList())
                    if (t == Grocery.PAY && acc.value != null) {
                        Posting.setLastAccount("credit_" + b.mode, acc.value)
                        Posting.post(acc.value, AccountTx.SRC_CREDIT, id, b.mode == Grocery.OWE_ME, v, date, tr("دفتر الآجل • ", "Credit book • ") + b.name)
                    }
                    if (toLiving && t == Grocery.BUY && b.mode == Grocery.I_OWE) QuickAdd.living(ctx, Living.EXPENSE, items.trim().ifBlank { b.name }, "FOOD", v, date, b.name)
                    // تنبيه تجاوز الحد
                    val bal = dao.allCreditEntries().filter { it.bookId == b.id }.sumOf { if (it.type == Grocery.BUY) it.amount else -it.amount }
                    if (b.creditLimit > 0 && bal > b.creditLimit) toast(ctx, tr("⚠️ تجاوز الحد: الرصيد ${Fmt.money(bal)}", "⚠️ Over limit: balance ${Fmt.money(bal)}"))
                    else toast(ctx, tr("تم الحفظ • الرصيد ${Fmt.money(bal)}", "Saved • balance ${Fmt.money(bal)}"))
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
