package com.sho3eb.app.core

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.sho3eb.app.R
import com.sho3eb.app.Sho3ebApp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/** جداول المنبه والمواعيد (العلاج، المحاضرات، ...) */
object Alarms {
    const val MODE_DAILY = "daily"
    const val MODE_WEEKLY = "weekly"
    const val MODE_ONCE = "once"
    const val MODE_INTERVAL = "interval"
    const val CHANNEL = "sho3eb_alarm_v1"
    const val ACTION_FIRE = "com.sho3eb.app.ALARM_FIRE"
    const val ACTION_DISMISS = "com.sho3eb.app.ALARM_DISMISS"
    const val ACTION_SNOOZE = "com.sho3eb.app.ALARM_SNOOZE"

    data class Item(
        val id: Long, val title: String, val note: String, val hour: Int, val minute: Int,
        val mode: String = MODE_DAILY, val days: Set<Int> = emptySet(), val date: Long = 0L,
        val enabled: Boolean = true, val everyHours: Int = 8
    ) {
        fun json() = JSONObject().put("id", id).put("title", title).put("note", note).put("h", hour).put("m", minute).put("mode", mode)
            .put("days", JSONArray(days.toList())).put("date", date).put("on", enabled).put("every", everyHours)
        companion object {
            fun from(o: JSONObject) = Item(
                o.optLong("id"), o.optString("title"), o.optString("note"), o.optInt("h"), o.optInt("m"), o.optString("mode", MODE_DAILY),
                o.optJSONArray("days")?.let { a -> (0 until a.length()).map { a.getInt(it) }.toSet() } ?: emptySet(),
                o.optLong("date"), o.optBoolean("on", true), o.optInt("every", 8)
            )
        }
    }

    data class Schedule(
        val id: Long, val name: String, val desc: String = "", val emoji: String = "⏰", val enabled: Boolean = true,
        val vibrate: Boolean = true, val sound: String = "", val soundName: String = "", val volume: Int = 90,
        val snooze: Int = 10, val ramp: Boolean = true, val items: List<Item> = emptyList()
    ) {
        fun json() = JSONObject().put("id", id).put("name", name).put("desc", desc).put("emoji", emoji).put("on", enabled).put("vib", vibrate)
            .put("sound", sound).put("soundName", soundName).put("vol", volume).put("snooze", snooze).put("ramp", ramp)
            .put("items", JSONArray().apply { items.forEach { put(it.json()) } })
        companion object {
            fun from(o: JSONObject) = Schedule(
                o.optLong("id"), o.optString("name"), o.optString("desc"), o.optString("emoji", "⏰"), o.optBoolean("on", true), o.optBoolean("vib", true),
                o.optString("sound"), o.optString("soundName"), o.optInt("vol", 90), o.optInt("snooze", 10), o.optBoolean("ramp", true),
                o.optJSONArray("items")?.let { a -> (0 until a.length()).map { Item.from(a.getJSONObject(it)) } } ?: emptyList()
            )
        }
    }

    val templates = listOf(
        Triple("💊", tr("العلاج", "Medicine"), tr("مواعيد الأدوية والجرعات", "Medicine doses")),
        Triple("🩺", tr("مواعيد الطبيب", "Doctor visits"), tr("الكشف والتحاليل والمتابعة", "Check-ups & tests")),
        Triple("📚", tr("المذاكرة", "Study"), tr("جدول المذاكرة والمحاضرات", "Study & lectures")),
        Triple("💼", tr("العمل", "Work"), tr("الاجتماعات والمهام", "Meetings & tasks")),
        Triple("🏃", tr("الرياضة", "Exercise"), tr("التمارين والمشي", "Workouts & walks")),
        Triple("💧", tr("شرب الماء", "Drink water"), tr("تذكير بشرب الماء", "Hydration reminders"))
    )

    // ---------- التخزين ----------
    val version = androidx.compose.runtime.mutableIntStateOf(0)
    var schedules: List<Schedule>
        get() = runCatching { JSONArray(Extras.s("alarm_scheds", "[]")).let { a -> (0 until a.length()).map { Schedule.from(a.getJSONObject(it)) } } }.getOrDefault(emptyList())
        set(v) { Extras.ps("alarm_scheds", JSONArray().apply { v.forEach { put(it.json()) } }.toString()); version.intValue++ }

    fun schedule(id: Long) = schedules.firstOrNull { it.id == id }
    fun upsert(ctx: Context, s: Schedule) { schedules = schedules.filter { it.id != s.id } + s; rescheduleAll(ctx) }
    fun delete(ctx: Context, id: Long) { schedules = schedules.filter { it.id != id }; rescheduleAll(ctx) }
    fun find(itemId: Long): Pair<Schedule, Item>? = schedules.firstNotNullOfOrNull { s -> s.items.firstOrNull { it.id == itemId }?.let { s to it } }

    // ---------- حساب الموعد التالي ----------
    fun next(item: Item, from: LocalDateTime = LocalDateTime.now()): LocalDateTime? {
        if (!item.enabled) return null
        val t = java.time.LocalTime.of(item.hour.coerceIn(0, 23), item.minute.coerceIn(0, 59))
        return when (item.mode) {
            MODE_ONCE -> LocalDate.ofEpochDay(item.date).atTime(t).takeIf { it.isAfter(from) }
            MODE_WEEKLY -> {
                if (item.days.isEmpty()) null
                else (0..7).map { from.toLocalDate().plusDays(it.toLong()).atTime(t) }.firstOrNull { it.isAfter(from) && it.dayOfWeek.value in item.days }
            }
            MODE_INTERVAL -> {
                val step = item.everyHours.coerceIn(1, 24).toLong()
                var d = from.toLocalDate().atTime(t)
                while (d.isAfter(from)) d = d.minusHours(step)
                while (!d.isAfter(from)) d = d.plusHours(step)
                d
            }
            else -> from.toLocalDate().atTime(t).let { if (it.isAfter(from)) it else it.plusDays(1) }
        }
    }

    fun millis(d: LocalDateTime) = d.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    fun describe(item: Item): String {
        val time = String.format(java.util.Locale.US, "%02d:%02d", item.hour, item.minute)
        return when (item.mode) {
            MODE_ONCE -> Fmt.date(item.date) + " • " + time
            MODE_WEEKLY -> item.days.sorted().joinToString("، ") { dayName(it) } + " • " + time
            MODE_INTERVAL -> tr("كل ${item.everyHours} ساعات من ", "Every ${item.everyHours} h from ") + time
            else -> tr("يومياً • ", "Daily • ") + time
        }
    }

    fun dayName(d: Int): String = when (DayOfWeek.of(d)) {
        DayOfWeek.SATURDAY -> tr("السبت", "Sat"); DayOfWeek.SUNDAY -> tr("الأحد", "Sun"); DayOfWeek.MONDAY -> tr("الإثنين", "Mon")
        DayOfWeek.TUESDAY -> tr("الثلاثاء", "Tue"); DayOfWeek.WEDNESDAY -> tr("الأربعاء", "Wed"); DayOfWeek.THURSDAY -> tr("الخميس", "Thu")
        else -> tr("الجمعة", "Fri")
    }
    /** ترتيب أيام الأسبوع بدءاً من السبت */
    val weekOrder = listOf(6, 7, 1, 2, 3, 4, 5)

    /** أقرب منبه قادم في كل الجداول */
    fun upcoming(): Triple<Schedule, Item, LocalDateTime>? = schedules.filter { it.enabled }.flatMap { s -> s.items.mapNotNull { i -> next(i)?.let { Triple(s, i, it) } } }.minByOrNull { it.third }

    // ---------- الجدولة ----------
    private fun code(itemId: Long) = (itemId % 1_000_000L).toInt() + 50_000_000

    private fun firePi(ctx: Context, itemId: Long, snooze: Boolean = false): PendingIntent =
        PendingIntent.getBroadcast(ctx, code(itemId) + if (snooze) 7 else 0,
            Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_FIRE).putExtra("item", itemId),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun showPi(ctx: Context): PendingIntent {
        val i = (ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent()).putExtra("route", "alarms")
        return PendingIntent.getActivity(ctx, 49_999_999, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    private fun setAt(ctx: Context, time: Long, pi: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        try {
            if (canExact(ctx)) am.setAlarmClock(AlarmManager.AlarmClockInfo(time, showPi(ctx)), pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
        }
    }

    fun rescheduleAll(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        // إلغاء المسجّل سابقاً
        Extras.s("alarm_codes", "").split(",").mapNotNull { it.toLongOrNull() }.forEach { id -> runCatching { am.cancel(firePi(ctx, id)) } }
        val ids = mutableListOf<Long>()
        val now = LocalDateTime.now()
        schedules.filter { it.enabled }.forEach { s ->
            s.items.forEach { i ->
                next(i, now)?.let { d -> setAt(ctx, millis(d), firePi(ctx, i.id)); ids += i.id }
            }
        }
        Extras.ps("alarm_codes", ids.joinToString(","))
    }

    fun snooze(ctx: Context, itemId: Long, minutes: Int) {
        setAt(ctx, System.currentTimeMillis() + minutes.coerceIn(1, 120) * 60_000L, firePi(ctx, itemId, true))
    }

    /** بعد رنين منبه "مرة واحدة" يتم تعطيله */
    fun afterFire(ctx: Context, itemId: Long) {
        val (s, i) = find(itemId) ?: return
        if (i.mode == MODE_ONCE) schedules = schedules.map { if (it.id == s.id) it.copy(items = it.items.map { x -> if (x.id == i.id) x.copy(enabled = false) else x }) else it }
        rescheduleAll(ctx)
    }

    // ---------- الأصوات ----------
    data class Sound(val uri: String, val name: String, val user: Boolean = false)

    fun soundsDir(ctx: Context) = File(ctx.filesDir, "alarm_sounds").apply { mkdirs() }

    fun systemSounds(ctx: Context): List<Sound> {
        val out = mutableListOf<Sound>()
        listOf(RingtoneManager.TYPE_ALARM, RingtoneManager.TYPE_RINGTONE, RingtoneManager.TYPE_NOTIFICATION).forEach { type ->
            runCatching {
                val rm = RingtoneManager(ctx).apply { setType(type) }
                val c = rm.cursor
                while (c.moveToNext()) out += Sound(rm.getRingtoneUri(c.position).toString(), c.getString(RingtoneManager.TITLE_COLUMN_INDEX))
            }
        }
        return out.distinctBy { it.uri }
    }

    fun userSounds(ctx: Context): List<Sound> = soundsDir(ctx).listFiles()?.sortedBy { it.name }?.map { Sound(Uri.fromFile(it).toString(), it.nameWithoutExtension, true) } ?: emptyList()

    fun addUserSound(ctx: Context, uri: Uri): Sound? = runCatching {
        var name = "sound_" + System.currentTimeMillis()
        ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: name }
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val f = File(soundsDir(ctx), safe)
        ctx.contentResolver.openInputStream(uri)?.use { inp -> f.outputStream().use { inp.copyTo(it) } }
        Sound(Uri.fromFile(f).toString(), f.nameWithoutExtension, true)
    }.getOrNull()

    fun defaultSound(): Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

    fun channel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, tr("المنبه والمواعيد", "Alarms & schedules"), NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null); enableVibration(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC; setBypassDnd(true)
            }
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    fun canFullScreen(ctx: Context): Boolean = Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    fun canOverlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun openFullScreenSettings(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 34) runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    fun openOverlaySettings(ctx: Context) = runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun openExactSettings(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 31) runCatching { ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    /** تجربة الرنين الآن */
    fun test(ctx: Context, s: Schedule) {
        val item = s.items.firstOrNull() ?: Item(-1, tr("تجربة المنبه", "Alarm test"), "", 0, 0)
        ContextCompat.startForegroundService(ctx, Intent(ctx, AlarmRingService::class.java).putExtra("item", item.id).putExtra("test", s.json().toString()))
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Alarms.ACTION_FIRE -> {
                val id = intent.getLongExtra("item", 0L)
                runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, AlarmRingService::class.java).putExtra("item", id)) }
                Alarms.afterFire(ctx, id)
            }
            else -> Alarms.rescheduleAll(ctx)
        }
    }
}

/** خدمة الرنين: صوت متكرر + اهتزاز حتى يضغط المستخدم إيقاف */
class AlarmRingService : Service() {
    private var mp: MediaPlayer? = null
    private var vib: Vibrator? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var itemId = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            Alarms.ACTION_DISMISS -> { stopAll(); return START_NOT_STICKY }
            Alarms.ACTION_SNOOZE -> {
                val s = Alarms.find(itemId)?.first
                Alarms.snooze(this, itemId, s?.snooze ?: 10)
                toast(this, tr("تم التأجيل ${s?.snooze ?: 10} دقيقة", "Snoozed ${s?.snooze ?: 10} min"))
                stopAll(); return START_NOT_STICKY
            }
        }
        AppState.lang.value = Sho3ebApp.instance.prefs.lang
        itemId = intent?.getLongExtra("item", 0L) ?: 0L
        val testJson = intent?.getStringExtra("test")
        val pair = if (testJson != null) runCatching { Alarms.Schedule.from(JSONObject(testJson)) }.getOrNull()?.let { it to (it.items.firstOrNull() ?: Alarms.Item(-1, tr("تجربة المنبه", "Alarm test"), "", 0, 0)) } else Alarms.find(itemId)
        if (pair == null) { stopSelf(); return START_NOT_STICKY }
        val (sch, item) = pair
        Alarms.channel(this)
        Ringing.current.value = Ringing.Info(item.id, sch.emoji + " " + sch.name, item.title, item.note, String.format(java.util.Locale.US, "%02d:%02d", java.time.LocalTime.now().hour, java.time.LocalTime.now().minute), sch.snooze)

        val full = Intent(this, com.sho3eb.app.ui.AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        val fullPi = PendingIntent.getActivity(this, 49_999_998, full, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val dismissPi = PendingIntent.getService(this, 49_999_997, Intent(this, AlarmRingService::class.java).setAction(Alarms.ACTION_DISMISS), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val snoozePi = PendingIntent.getService(this, 49_999_996, Intent(this, AlarmRingService::class.java).setAction(Alarms.ACTION_SNOOZE), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, Alarms.CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(sch.emoji + " " + item.title.ifBlank { sch.name })
            .setContentText(listOf(sch.name, item.note).filter { it.isNotBlank() }.joinToString(" • "))
            .setStyle(NotificationCompat.BigTextStyle().bigText(listOf(sch.name, sch.desc, item.note).filter { it.isNotBlank() }.joinToString("\n")))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullPi, true)
            .setContentIntent(fullPi)
            .setOngoing(true).setAutoCancel(false)
            .addAction(0, tr("⏹ إيقاف", "⏹ Dismiss"), dismissPi)
            .addAction(0, tr("💤 تأجيل", "💤 Snooze"), snoozePi)
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        try {
            ServiceCompat.startForeground(this, 4501, n, if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0)
        } catch (e: Exception) {
            runCatching { getSystemService(NotificationManager::class.java).notify(4501, n) }
        }
        runCatching {
            wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sho3eb:alarm").apply { acquire(30 * 60_000L) }
        }
        // إظهار الشاشة فوق كل التطبيقات
        if (Alarms.canOverlay(this)) runCatching { startActivity(full) }
        startSound(sch)
        if (sch.vibrate) startVibration()
        // حماية: إيقاف تلقائي بعد 30 دقيقة دون استجابة
        handler.postDelayed({ stopAll() }, 30 * 60_000L)
        return START_NOT_STICKY
    }

    private fun startSound(s: Alarms.Schedule) {
        mp?.release()
        val uri = s.sound.takeIf { it.isNotBlank() }?.let { Uri.parse(it) } ?: Alarms.defaultSound()
        val vol = s.volume.coerceIn(5, 100) / 100f
        mp = runCatching {
            MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@AlarmRingService, uri)
                isLooping = true
                prepare()
                setVolume(if (s.ramp) vol * 0.2f else vol, if (s.ramp) vol * 0.2f else vol)
                start()
            }
        }.getOrElse {
            runCatching {
                MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                    setDataSource(this@AlarmRingService, Alarms.defaultSound()); isLooping = true; prepare(); start()
                }
            }.getOrNull()
        }
        runCatching {
            val am = getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max / 3) am.setStreamVolume(AudioManager.STREAM_ALARM, max / 2, 0)
        }
        if (s.ramp) for (i in 1..10) handler.postDelayed({ runCatching { val v = vol * (0.2f + 0.08f * i); mp?.setVolume(v, v) } }, i * 3000L)
    }

    private fun startVibration() {
        vib = if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator else getSystemService(Vibrator::class.java)
        val pattern = longArrayOf(0, 800, 500, 800, 500, 1200, 900)
        runCatching {
            if (Build.VERSION.SDK_INT >= 33) vib?.vibrate(VibrationEffect.createWaveform(pattern, 0), android.os.VibrationAttributes.createForUsage(android.os.VibrationAttributes.USAGE_ALARM))
            else vib?.vibrate(VibrationEffect.createWaveform(pattern, 0), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        }
    }

    private fun stopAll() {
        Ringing.current.value = null
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        mp?.let { runCatching { it.stop() }; it.release() }
        mp = null
        runCatching { vib?.cancel() }
        runCatching { if (wake?.isHeld == true) wake?.release() }
        Ringing.current.value = null
        runCatching { getSystemService(NotificationManager::class.java).cancel(4501) }
        super.onDestroy()
    }

    companion object {
        fun dismiss(ctx: Context) = runCatching { ctx.startService(Intent(ctx, AlarmRingService::class.java).setAction(Alarms.ACTION_DISMISS)) }
        fun snooze(ctx: Context) = runCatching { ctx.startService(Intent(ctx, AlarmRingService::class.java).setAction(Alarms.ACTION_SNOOZE)) }
    }
}

/** حالة الرنين الحالية لعرضها في شاشة المنبه */
object Ringing {
    data class Info(val itemId: Long, val schedule: String, val title: String, val note: String, val time: String, val snooze: Int)
    val current = androidx.compose.runtime.mutableStateOf<Info?>(null)
}
