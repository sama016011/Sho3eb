@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.sho3eb.app.core.AppState
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import com.sho3eb.app.islam.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** الحصول على الموقع الحالي */
@SuppressLint("MissingPermission")
fun fetchLocation(ctx: Context, onResult: (Location?) -> Unit) {
    val lm = ctx.getSystemService(LocationManager::class.java)
    if (lm == null) { onResult(null); return }
    val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        .filter { try { lm.isProviderEnabled(it) } catch (e: Exception) { false } }
    val last = providers.mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
    if (last != null && System.currentTimeMillis() - last.time < 30 * 60_000L) { onResult(last); return }
    val p = providers.firstOrNull { it != LocationManager.PASSIVE_PROVIDER }
    if (p == null) { onResult(last); return }
    var done = false
    val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            if (!done) { done = true; lm.removeUpdates(this); onResult(l) }
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }
    try {
        lm.requestLocationUpdates(p, 0L, 0f, listener, Looper.getMainLooper())
    } catch (e: Exception) {
        onResult(last); return
    }
    Handler(Looper.getMainLooper()).postDelayed({
        if (!done) { done = true; lm.removeUpdates(listener); onResult(last) }
    }, 25_000)
}

private fun methodForCountry(cc: String?): CalcMethod = when (cc?.uppercase()) {
    "SA", "YE" -> CalcMethod.UMM_AL_QURA
    "EG", "SD", "LY" -> CalcMethod.EGYPT
    "AE" -> CalcMethod.DUBAI
    "KW" -> CalcMethod.KUWAIT
    "QA" -> CalcMethod.QATAR
    "BH", "OM" -> CalcMethod.GULF
    "PK", "IN", "BD", "AF" -> CalcMethod.KARACHI
    "US", "CA" -> CalcMethod.ISNA
    else -> CalcMethod.MWL
}

// ============================ مواقيت الصلاة ============================
@Composable
fun PrayerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(ZonedDateTime.now(Prayer.zone())) }
    var locating by remember { mutableStateOf(false) }
    var showCities by remember { mutableStateOf(false) }
    var showMethod by remember { mutableStateOf(false) }
    var showAzan by remember { mutableStateOf(false) }
    var showAdjust by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { while (true) { now = ZonedDateTime.now(Prayer.zone()); delay(1000) } }
    val times = remember(tick, now.toLocalDate()) { Prayer.timesFor(now.toLocalDate()) }
    val next = remember(tick, now.minute) { Prayer.next(now) }
    fun changed() { tick++; IslamAlarms.schedulePrayer(ctx) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) {
            locating = true
            fetchLocation(ctx) { loc ->
                if (loc == null) { locating = false; toast(ctx, tr("تعذر تحديد الموقع. فعّل الموقع أو اختر المدينة يدوياً", "Location unavailable. Enable location or pick a city")); return@fetchLocation }
                scope.launch {
                    val (city, cc) = withContext(Dispatchers.IO) {
                        try {
                            @Suppress("DEPRECATION")
                            val ad = Geocoder(ctx, if (AppState.isAr) Locale("ar") else Locale.ENGLISH).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
                            (ad?.locality ?: ad?.subAdminArea ?: ad?.adminArea ?: "") to ad?.countryCode
                        } catch (e: Exception) { "" to null }
                    }
                    IslamPrefs.lat = loc.latitude; IslamPrefs.lng = loc.longitude
                    IslamPrefs.cityName = city.ifBlank { String.format(Locale.US, "%.3f, %.3f", loc.latitude, loc.longitude) }
                    IslamPrefs.zoneId = ""
                    if (cc != null) IslamPrefs.method = methodForCountry(cc).name
                    locating = false
                    changed()
                    toast(ctx, tr("تم تحديد الموقع: ", "Location set: ") + IslamPrefs.cityName)
                }
            }
        } else toast(ctx, tr("لم يتم منح صلاحية الموقع", "Location permission denied"))
    }

    ScreenScaffold(
        title = tr("مواقيت الصلاة", "Prayer times"),
        onBack = { nav.popBackStack() },
        actions = { IconButton(onClick = { nav.navigate("qibla") }) { Icon(Icons.Filled.Explore, null) } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                val left = Duration.between(now, next.second).coerceAtLeast(Duration.ZERO)
                val primary = MaterialTheme.colorScheme.primary
                val tertiary = MaterialTheme.colorScheme.tertiary
                Card {
                    Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(primary, tertiary))).padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.LocationOn, null, tint = Color.White)
                            Spacer(Modifier.width(6.dp))
                            Text(IslamPrefs.cityName, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(Prayer.hijri(), color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(tr("الصلاة القادمة", "Next prayer"), color = Color.White.copy(alpha = 0.85f))
                        Text(Prayer.names[next.first] + "  " + Prayer.fmt(next.second), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            tr("متبقي ", "In ") + String.format(Locale.US, "%02d:%02d:%02d", left.toHours(), left.toMinutes() % 60, left.seconds % 60),
                            color = Color(0xFFFDE68A), fontSize = 20.sp, fontWeight = FontWeight.Bold
                        )
                        Text(now.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", if (AppState.isAr) Locale("ar") else Locale.ENGLISH)), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        permLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    }, enabled = !locating, modifier = Modifier.weight(1f)) {
                        if (locating) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White) else Icon(Icons.Filled.MyLocation, null)
                        Spacer(Modifier.width(6.dp)); Text(tr("موقعي", "My location"))
                    }
                    OutlinedButton(onClick = { showCities = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.LocationCity, null); Spacer(Modifier.width(6.dp)); Text(tr("اختيار مدينة", "Pick city"))
                    }
                }
            }
            items(times.indices.toList()) { k ->
                val isNext = k == next.first && times[k].toLocalDate() == next.second.toLocalDate()
                val icons = listOf(Icons.Filled.Brightness4, Icons.Filled.WbSunny, Icons.Filled.LightMode, Icons.Filled.WbCloudy, Icons.Filled.Brightness2, Icons.Filled.DarkMode)
                Card(colors = CardDefaults.cardColors(containerColor = if (isNext) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icons[k], null, tint = if (isNext) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Text(Prayer.names[k], fontWeight = if (isNext) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        Text(Prayer.fmt(times[k]), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        var on by remember(tick) { mutableStateOf(IslamPrefs.notifyFor(k)) }
                        IconButton(onClick = { on = !on; IslamPrefs.setNotifyFor(k, on); changed() }) {
                            Icon(if (on) Icons.Filled.NotificationsActive else Icons.Filled.NotificationsOff, null,
                                tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(8.dp)) {
                        SettingRow(Icons.Filled.Calculate, tr("طريقة الحساب", "Calculation method"),
                            (try { CalcMethod.valueOf(IslamPrefs.method) } catch (e: Exception) { CalcMethod.UMM_AL_QURA }).label) { showMethod = true }
                        var hanafi by remember { mutableStateOf(IslamPrefs.asrHanafi) }
                        Box(Modifier.padding(horizontal = 8.dp)) {
                            SwitchRow(tr("العصر على المذهب الحنفي", "Hanafi Asr"), tr("الافتراضي: مذهب الجمهور", "Default: majority (Shafi'i)"), hanafi, Icons.Filled.WbCloudy) {
                                hanafi = it; IslamPrefs.asrHanafi = it; changed()
                            }
                        }
                        SettingRow(Icons.Filled.MusicNote, tr("صوت الأذان", "Azan sound"),
                            IslamPrefs.azanSounds.firstOrNull { it.path == IslamPrefs.azanPath }?.name ?: tr("صوت الإشعار الافتراضي", "Default notification sound")) { showAzan = true }
                        SettingRow(Icons.Filled.Tune, tr("تعديل الأوقات يدوياً", "Manual adjustments"), tr("إضافة أو طرح دقائق لكل صلاة", "Add or subtract minutes")) { showAdjust = true }
                        var pre by remember { mutableIntStateOf(IslamPrefs.preReminder) }
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                            Text(tr("تنبيه قبل الأذان", "Reminder before azan"), fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(0, 5, 10, 15, 30).forEach { m ->
                                    FilterChip(pre == m, { pre = m; IslamPrefs.preReminder = m; changed() }, label = { Text(if (m == 0) tr("بدون", "Off") else tr("$m د", "${m}m")) })
                                }
                            }
                        }
                        var master by remember { mutableStateOf(IslamPrefs.prayerNotify) }
                        Box(Modifier.padding(horizontal = 8.dp)) {
                            SwitchRow(tr("تنبيهات أوقات الصلاة", "Prayer notifications"), null, master, Icons.Filled.Notifications) {
                                master = it; IslamPrefs.prayerNotify = it; changed()
                            }
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= 31) item {
                val am = ctx.getSystemService(AlarmManager::class.java)
                if (am != null && !am.canScheduleExactAlarms()) {
                    Card(onClick = {
                        try { ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))) } catch (_: Exception) {}
                    }) {
                        InfoBanner(tr("لضبط الأذان على الدقيقة بالضبط اضغط هنا واسمح بالمنبهات الدقيقة", "Tap to allow exact alarms for on-time azan"), MaterialTheme.colorScheme.error)
                    }
                }
            }
            item { SectionTitle(tr("مواقيت الأسبوع", "This week")) }
            items((1..6).toList()) { d ->
                val date = now.toLocalDate().plusDays(d.toLong())
                val t = remember(tick, date) { Prayer.timesFor(date) }
                Card {
                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                        Text(date.format(DateTimeFormatter.ofPattern("EEEE d/M", if (AppState.isAr) Locale("ar") else Locale.ENGLISH)) + "  •  " + Prayer.hijri(date), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            listOf(0, 2, 3, 4, 5).forEach { k ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(Prayer.names[k], fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(t[k].format(DateTimeFormatter.ofPattern("HH:mm")), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCities) CityDialog(onDismiss = { showCities = false }) { c ->
        IslamPrefs.lat = c.lat; IslamPrefs.lng = c.lng; IslamPrefs.cityName = if (AppState.isAr) c.ar else c.en
        IslamPrefs.zoneId = c.zone; IslamPrefs.method = c.method.name
        showCities = false; changed()
    }
    if (showMethod) AlertDialog(
        onDismissRequest = { showMethod = false },
        title = { Text(tr("طريقة الحساب", "Calculation method")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                CalcMethod.values().forEach { m ->
                    Row(Modifier.fillMaxWidth().clickable { IslamPrefs.method = m.name; showMethod = false; changed() }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = IslamPrefs.method == m.name, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(m.label)
                            Text(
                                tr("الفجر ${m.fajr}° • العشاء ", "Fajr ${m.fajr}° • Isha ") + if (m.ishaMinutes > 0) tr("${m.ishaMinutes} دقيقة بعد المغرب", "${m.ishaMinutes} min after Maghrib") else "${m.isha}°",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showMethod = false }) { Text(tr("إغلاق", "Close")) } }
    )
    if (showAzan) AzanDialog(onDismiss = { showAzan = false; tick++ })
    if (showAdjust) AdjustDialog(onDismiss = { showAdjust = false; changed() })
}

@Composable
private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Filled.ChevronLeft, null)
    }
}

@Composable
private fun CityDialog(onDismiss: () -> Unit, onPick: (City) -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("اختيار المدينة", "Choose city")) },
        text = {
            Column {
                SearchField(q) { q = it }
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(Prayer.cities.filter { q.isBlank() || it.ar.contains(q) || it.en.contains(q, true) }) { c ->
                        Text(if (AppState.isAr) c.ar else c.en, modifier = Modifier.fillMaxWidth().clickable { onPick(c) }.padding(vertical = 12.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
}

@Composable
private fun AdjustDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("تعديل الأوقات (دقائق)", "Adjust times (minutes)")) },
        text = {
            Column {
                Prayer.names.forEachIndexed { k, n ->
                    var v by remember { mutableIntStateOf(IslamPrefs.offsetFor(k)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(n, modifier = Modifier.weight(1f))
                        IconButton(onClick = { v--; IslamPrefs.setOffsetFor(k, v) }) { Icon(Icons.Filled.Remove, null) }
                        Text("$v", fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp), textAlign = TextAlign.Center)
                        IconButton(onClick = { v++; IslamPrefs.setOffsetFor(k, v) }) { Icon(Icons.Filled.Add, null) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("تم", "Done")) } }
    )
}

/** اختيار صوت المؤذن: من ملف على الهاتف أو رابط تنزيل */
@Composable
fun AzanDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sounds by remember { mutableStateOf(IslamPrefs.azanSounds) }
    var selected by remember { mutableStateOf(IslamPrefs.azanPath) }
    var fajr by remember { mutableStateOf(IslamPrefs.fajrAzanPath) }
    var forFajr by remember { mutableStateOf(false) }
    var showUrl by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<MediaPlayer?>(null) }
    var busy by remember { mutableStateOf(false) }
    val dir = remember { File(ctx.filesDir, "azan").apply { mkdirs() } }

    fun addSound(name: String, f: File) {
        sounds = sounds + AzanSound(name, f.absolutePath)
        IslamPrefs.azanSounds = sounds
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val res = withContext(Dispatchers.IO) {
                try {
                    var name = "azan"
                    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0)?.let { name = it } }
                    val f = File(dir, "azan_${System.currentTimeMillis()}." + name.substringAfterLast('.', "mp3"))
                    ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
                    name.substringBeforeLast('.') to f
                } catch (e: Exception) { null }
            }
            busy = false
            if (res != null) addSound(res.first, res.second) else toast(ctx, tr("تعذر إضافة الملف", "Could not add file"))
        }
    }
    DisposableEffect(Unit) { onDispose { preview?.release() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.MusicNote, null) },
        title = { Text(tr("صوت الأذان", "Azan sound")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(!forFajr, { forFajr = false }, label = { Text(tr("كل الصلوات", "All prayers")) })
                    FilterChip(forFajr, { forFajr = true }, label = { Text(tr("أذان الفجر", "Fajr azan")) })
                }
                val cur = if (forFajr) fajr else selected
                fun choose(path: String) {
                    if (forFajr) { fajr = path; IslamPrefs.fajrAzanPath = path } else { selected = path; IslamPrefs.azanPath = path }
                }
                Row(Modifier.fillMaxWidth().clickable { choose("") }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(cur == "", null); Spacer(Modifier.width(6.dp))
                    Text(if (forFajr) tr("نفس أذان باقي الصلوات", "Same as other prayers") else tr("صوت الإشعار الافتراضي (بدون أذان)", "Default notification (no azan)"))
                }
                sounds.forEach { s ->
                    Row(Modifier.fillMaxWidth().clickable { choose(s.path) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(cur == s.path, null); Spacer(Modifier.width(6.dp))
                        Text(s.name, modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            preview?.release()
                            preview = try { MediaPlayer().apply { setDataSource(s.path); prepare(); start() } } catch (e: Exception) { null }
                        }) { Icon(Icons.Filled.PlayArrow, null) }
                        IconButton(onClick = {
                            File(s.path).delete()
                            sounds = sounds.filterNot { it.path == s.path }; IslamPrefs.azanSounds = sounds
                            if (selected == s.path) { selected = ""; IslamPrefs.azanPath = "" }
                            if (fajr == s.path) { fajr = ""; IslamPrefs.fajrAzanPath = "" }
                        }) { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) }
                    }
                }
                if (preview != null) TextButton(onClick = { preview?.release(); preview = null }) { Icon(Icons.Filled.Stop, null); Text(tr("إيقاف المعاينة", "Stop preview")) }
                HorizontalDivider()
                Text(tr("إضافة صوت مؤذن", "Add a muezzin voice"), fontWeight = FontWeight.Bold)
                Text(tr("نزّل ملف الأذان الذي تحبه (MP3) من أي موقع ثم اختره من الهاتف، أو الصق رابط الملف المباشر.", "Download any azan MP3 then pick it from your phone, or paste its direct link."), style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { pick.launch(arrayOf("audio/*")) }, enabled = !busy) { Icon(Icons.Filled.LibraryMusic, null); Spacer(Modifier.width(4.dp)); Text(tr("من الهاتف", "From phone")) }
                    OutlinedButton(onClick = { showUrl = true }, enabled = !busy) { Icon(Icons.Filled.Link, null); Spacer(Modifier.width(4.dp)); Text(tr("من رابط", "From link")) }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                OutlinedButton(onClick = {
                    val p = if (forFajr && fajr.isNotBlank()) fajr else selected
                    if (p.isNotBlank()) AzanService.start(ctx, p, tr("تجربة", "Test")) else toast(ctx, tr("اختر صوتاً أولاً", "Choose a sound first"))
                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.NotificationsActive, null); Spacer(Modifier.width(4.dp)); Text(tr("تجربة الأذان كتنبيه", "Test as alarm")) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("تم", "Done")) } }
    )
    if (showUrl) {
        var name by remember { mutableStateOf("") }
        var url by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showUrl = false },
            title = { Text(tr("تنزيل أذان من رابط", "Download azan from link")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text(tr("اسم المؤذن", "Muezzin name")) }, singleLine = true)
                    OutlinedTextField(url, { url = it.trim() }, label = { Text(tr("رابط ملف MP3", "MP3 link")) }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!url.startsWith("http")) { toast(ctx, tr("أدخل رابطاً صحيحاً", "Enter a valid link")); return@TextButton }
                    showUrl = false; busy = true
                    scope.launch {
                        val f = File(dir, "azan_${System.currentTimeMillis()}.mp3")
                        val ok = withContext(Dispatchers.IO) { try { Net.download(url, f); true } catch (e: Exception) { false } }
                        busy = false
                        if (ok) { addSound(name.ifBlank { tr("أذان", "Azan") }, f); toast(ctx, tr("تم تنزيل الأذان ✅", "Azan downloaded ✅")) }
                        else toast(ctx, tr("فشل التنزيل", "Download failed"))
                    }
                }) { Text(tr("تنزيل", "Download")) }
            },
            dismissButton = { TextButton(onClick = { showUrl = false }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
}

// ============================ القبلة ============================
@Composable
fun QiblaScreen(nav: NavController) {
    val ctx = LocalContext.current
    val qibla = remember { Prayer.qibla(IslamPrefs.lat, IslamPrefs.lng) }
    val dist = remember { Prayer.distanceToMakkah(IslamPrefs.lat, IslamPrefs.lng) }
    var azimuth by remember { mutableStateOf(0f) }
    var hasSensor by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) { hasSensor = false; onDispose { } }
        else {
            val rot = FloatArray(9)
            val ori = FloatArray(3)
            val l = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    SensorManager.getRotationMatrixFromVector(rot, e.values)
                    SensorManager.getOrientation(rot, ori)
                    val deg = ((Math.toDegrees(ori[0].toDouble()) + 360) % 360).toFloat()
                    azimuth = azimuth + (((deg - azimuth + 540) % 360) - 180) * 0.15f
                }
                override fun onAccuracyChanged(s: Sensor?, a: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
            onDispose { sm.unregisterListener(l) }
        }
    }

    ScreenScaffold(title = tr("اتجاه القبلة", "Qibla direction"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(IslamPrefs.cityName, fontWeight = FontWeight.Bold)
            val primary = MaterialTheme.colorScheme.primary
            val secondary = MaterialTheme.colorScheme.secondary
            val outline = MaterialTheme.colorScheme.outline
            val diff = ((qibla - azimuth + 540) % 360) - 180
            val aligned = hasSensor && kotlin.math.abs(diff) < 4
            Canvas(Modifier.size(280.dp)) {
                val c = Offset(size.width / 2, size.height / 2)
                val r = size.minDimension / 2 - 8
                drawCircle(if (aligned) Color(0xFF16A34A) else outline, r, c, style = Stroke(6f))
                rotate(-azimuth, c) {
                    for (k in 0 until 360 step 30) rotate(k.toFloat(), c) {
                        drawLine(outline, Offset(c.x, c.y - r), Offset(c.x, c.y - r + if (k % 90 == 0) 26f else 12f), 4f)
                    }
                    drawCircle(Color(0xFFDC2626), 10f, Offset(c.x, c.y - r + 40))   // الشمال
                    rotate(qibla.toFloat(), c) {
                        val p = Path().apply {
                            moveTo(c.x, c.y - r + 30); lineTo(c.x - 26, c.y + 10); lineTo(c.x, c.y - 10); lineTo(c.x + 26, c.y + 10); close()
                        }
                        drawPath(p, if (aligned) Color(0xFF16A34A) else primary)
                        drawRect(secondary, Offset(c.x - 16, c.y - r + 2), androidx.compose.ui.geometry.Size(32f, 26f))
                    }
                }
                drawCircle(primary, 8f, c)
            }
            Text(tr("القبلة: ${qibla.toInt()}° من الشمال", "Qibla: ${qibla.toInt()}° from North"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(tr("المسافة إلى مكة المكرمة: ${dist.toInt()} كم", "Distance to Makkah: ${dist.toInt()} km"))
            if (!hasSensor) InfoBanner(tr("لا يوجد حساس بوصلة في هذا الجهاز. استخدم الزاوية أعلاه مع بوصلة خارجية.", "No compass sensor. Use the angle above with a compass."))
            else Text(
                if (aligned) tr("✅ أنت باتجاه القبلة", "✅ You are facing the Qibla") else tr("أدر الهاتف حتى يصبح السهم للأعلى", "Rotate until the arrow points up"),
                color = if (aligned) Color(0xFF16A34A) else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold
            )
            Text(tr("للدقة: ضع الهاتف أفقياً وبعيداً عن المعادن، وحرّكه على شكل الرقم 8 لمعايرة البوصلة.", "For accuracy: hold flat, away from metal, and move in a figure-8 to calibrate."), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
    }
}

@Suppress("unused")
private fun today(): LocalDate = LocalDate.now()
