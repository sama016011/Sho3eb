@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.AccountTx
import com.sho3eb.app.data.LivEntry
import com.sho3eb.app.data.LivItem
import com.sho3eb.app.data.LivPeriod
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate

// =====================================================================
//                       مصاريف المعيشة
// =====================================================================

@Composable
private fun priorityColor(p: String): Color = when (p) {
    Living.ESSENTIAL -> MaterialTheme.colorScheme.primary
    Living.IMPORTANT -> WarnAmber
    else -> MaterialTheme.colorScheme.tertiary
}

@Composable
private fun ChipsRow(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), content = content)
}

/** بطاقة مختصرة في الشاشة الرئيسية */
@Composable
fun LivingHomeCard(nav: NavController) {
    val dao = remember { appDao() }
    val periods by flowState(emptyList<LivPeriod>()) { dao.livPeriodsFlow() }
    val entries by flowState(emptyList<LivEntry>()) { dao.allLivEntriesFlow() }
    val today = Fmt.today()
    val cur = periods.firstOrNull { today in it.startDate..it.endDate }
    Card(
        onClick = { if (cur != null) nav.navigate("living_period/${cur.id}") else nav.navigate("living") },
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconCircle(Icons.Filled.ShoppingBasket, MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tr("مصاريف المعيشة", "Living expenses"), fontWeight = FontWeight.Bold)
                if (cur == null) {
                    Text(tr("نظّم دخلك ومصروفاتك وابدأ بنداً لهذا الشهر", "Organise income & expenses; start this month"), style = MaterialTheme.typography.bodySmall)
                } else {
                    val es = entries.filter { it.periodId == cur.id }
                    val bal = es.filter { it.kind == Living.INCOME }.sumOf { it.amount } - es.filter { it.kind == Living.EXPENSE }.sumOf { it.amount }
                    Text(cur.name, style = MaterialTheme.typography.bodySmall)
                    Text(
                        tr("المتبقي: ", "Remaining: ") + Fmt.money(bal),
                        color = if (bal >= 0) SuccessGreen else DangerRed, fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            Icon(Icons.Filled.ChevronLeft, null)
        }
    }
}

// ---------------------------------------------------------------------
//                           الشاشة الرئيسية
// ---------------------------------------------------------------------
@Composable
fun LivingHomeScreen(nav: NavController) {
    val dao = remember { appDao() }
    val items by flowState(emptyList<LivItem>()) { dao.livItemsFlow() }
    val periods by flowState(emptyList<LivPeriod>()) { dao.livPeriodsFlow() }
    val entries by flowState(emptyList<LivEntry>()) { dao.allLivEntriesFlow() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var editItem by remember { mutableStateOf<LivItem?>(null) }
    var newKind by remember { mutableStateOf<String?>(null) }
    var newPeriod by remember { mutableStateOf(false) }

    ScreenScaffold(
        title = tr("مصاريف المعيشة", "Living expenses"),
        onBack = { nav.popBackStack() },
        fab = {
            when (tab) {
                0 -> ExtendedFloatingActionButton(
                    onClick = { newKind = Living.EXPENSE },
                    icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("مصروف", "Expense")) }
                )
                1 -> ExtendedFloatingActionButton(
                    onClick = { newPeriod = true },
                    icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("بند جديد", "New period")) }
                )
                else -> {}
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("ديباجة المعيشة", "Template")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("البنود", "Periods")) })
                Tab(tab == 2, { tab = 2 }, text = { Text(tr("التحليل", "Analysis")) })
                Tab(tab == 3, { tab = 3 }, text = { Text(tr("التقارير", "Reports")) })
            }
            when (tab) {
                0 -> TemplateTab(items, entries, onAdd = { newKind = it }, onEdit = { editItem = it })
                1 -> PeriodsTab(periods, entries, nav)
                2 -> AnalysisTab(items, periods, entries)
                else -> LivingReportsTab(periods, entries)
            }
        }
    }

    newKind?.let { k -> ItemDialog(k, null) { newKind = null } }
    editItem?.let { it0 -> ItemDialog(it0.kind, it0) { editItem = null } }
    if (newPeriod) PeriodDialog(null, items, onDismiss = { newPeriod = false }) { id ->
        newPeriod = false
        nav.navigate("living_period/$id")
    }
}

// ---------------------------------------------------------------------
//                           تبويب الديباجة
// ---------------------------------------------------------------------
@Composable
private fun TemplateTab(items: List<LivItem>, entries: List<LivEntry>, onAdd: (String) -> Unit, onEdit: (LivItem) -> Unit) {
    var unitIdx by rememberSaveable { mutableIntStateOf(2) }
    var editBudgets by remember { mutableStateOf(false) }
    var budgetsVer by remember { mutableIntStateOf(0) }
    val budgetStates = remember(entries, budgetsVer) { LivingAuto.budgetStates(entries) }
    if (editBudgets) BudgetDialog(items) { editBudgets = false; budgetsVer++ }
    val unit = Living.freqs[unitIdx]
    val incomes = items.filter { it.kind == Living.INCOME }
    val expenses = items.filter { it.kind == Living.EXPENSE }
    val t = Living.totals(Living.templateLines(items, Living.INCOME, unit), Living.templateLines(items, Living.EXPENSE, unit))

    LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            InfoBanner(tr(
                "الديباجة هي ميزانيتك الثابتة: أضف دخلك ومصروفاتك المعتادة مع تكرارها (يومي/أسبوعي/شهري/سنوي)، ثم اخترها بسهولة داخل كل بند مثل «شهر يناير».",
                "The template is your standing budget: add usual incomes and expenses with their frequency, then pick them inside each period like “January”."
            ))
        }
        item {
            Text(tr("عرض الإجماليات:", "Show totals:"), style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            ChipsRow { Living.freqs.forEachIndexed { i, f -> FilterChip(unitIdx == i, { unitIdx = i }, label = { Text(Living.freqName(f)) }) } }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(tr("إجمالي الدخل", "Total income"), Fmt.money(t.income), Icons.Filled.ArrowDownward, SuccessGreen, Modifier.weight(1f))
                StatCard(tr("إجمالي المصروفات", "Total expenses"), Fmt.money(t.expense), Icons.Filled.ArrowUpward, DangerRed, Modifier.weight(1f))
            }
        }
        item { BalanceCard(t.balance, t.income, t.expense, Living.perName(unit)) }
        item { BudgetsCard(budgetStates) { editBudgets = true } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onAdd(Living.INCOME) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text(tr("إضافة دخل", "Add income"))
                }
                OutlinedButton(onClick = { onAdd(Living.EXPENSE) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text(tr("إضافة مصروف", "Add expense"))
                }
            }
        }
        if (items.isEmpty()) {
            item { EmptyState(Icons.Filled.ShoppingBasket, tr("ابدأ بإضافة راتبك ثم مصروفاتك المعتادة", "Start by adding your salary, then usual expenses")) }
        }
        if (incomes.isNotEmpty()) {
            item { SectionTitle(tr("الدخل", "Income")) }
            items(incomes, key = { it.id }) { ItemRow(it, unit) { onEdit(it) } }
        }
        if (expenses.isNotEmpty()) {
            item { SectionTitle(tr("المصروفات حسب النوع", "Expenses by type")) }
            item { PriorityStrip(t.byPriority, t.expense) }
            val groups = expenses.groupBy { it.category }.toList()
                .sortedByDescending { g -> g.second.sumOf { Living.convert(it.amount, it.freq, unit) } }
            groups.forEach { (c, list) ->
                item(key = "h_$c") {
                    val cat = Living.cat(Living.EXPENSE, c)
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(cat.emoji + "  " + cat.label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(Fmt.money(list.sumOf { Living.convert(it.amount, it.freq, unit) }), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
                items(list, key = { it.id }) { ItemRow(it, unit) { onEdit(it) } }
            }
        }
    }
}

@Composable
private fun BalanceCard(balance: Double, income: Double, expense: Double, per: String) {
    val ok = balance >= 0
    Card(colors = CardDefaults.cardColors(containerColor = (if (ok) SuccessGreen else DangerRed).copy(alpha = 0.12f))) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (ok) Icons.Filled.Savings else Icons.Filled.Warning, null, tint = if (ok) SuccessGreen else DangerRed)
                Spacer(Modifier.width(8.dp))
                Text(if (ok) tr("المتبقي (الفائض)", "Remaining (surplus)") else tr("العجز", "Deficit"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(Fmt.money(balance) + " " + per, fontWeight = FontWeight.Bold, color = if (ok) SuccessGreen else DangerRed)
            }
            if (income > 0) {
                Spacer(Modifier.height(8.dp))
                val r = (expense / income).toFloat().coerceIn(0f, 1f)
                LinearProgressIndicator(progress = { r }, modifier = Modifier.fillMaxWidth().height(8.dp), color = if (expense > income) DangerRed else if (r > 0.9f) WarnAmber else SuccessGreen)
                Spacer(Modifier.height(4.dp))
                Text(tr("تنفق ${(expense / income * 100).toInt()}% من الدخل", "You spend ${(expense / income * 100).toInt()}% of income"), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PriorityStrip(byPriority: Map<String, Double>, total: Double) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Living.priorities.forEach { p ->
            val v = byPriority[p] ?: 0.0
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = priorityColor(p).copy(alpha = 0.12f))) {
                Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(Living.priorityName(p), color = priorityColor(p), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Text(Fmt.num(v), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text(if (total > 0) "${(v / total * 100).toInt()}%" else "-", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun ItemRow(i: LivItem, unit: String, onClick: () -> Unit) {
    val cat = Living.cat(i.kind, i.category)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(cat.emoji, fontSize = 24.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(i.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    cat.label + " • " + Fmt.money(i.amount) + " " + Living.perName(i.freq),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (i.notes.isNotBlank()) Text(i.notes, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (i.autoDay > 0) Text(tr("🔁 يُضاف تلقائياً يوم ${i.autoDay} من كل شهر", "🔁 Auto-added on day ${i.autoDay} monthly"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    Fmt.money(Living.convert(i.amount, i.freq, unit)), fontWeight = FontWeight.Bold,
                    color = if (i.kind == Living.INCOME) SuccessGreen else MaterialTheme.colorScheme.onSurface
                )
                if (i.kind == Living.EXPENSE) StatusChip(Living.priorityName(i.priority), priorityColor(i.priority))
            }
        }
    }
}

/** إضافة / تعديل بند في الديباجة */
@Composable
private fun ItemDialog(kind: String, existing: LivItem?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val isIncome = kind == Living.INCOME
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var cat by remember { mutableStateOf(existing?.category ?: Living.cats(kind).first().key) }
    var amount by remember { mutableStateOf(existing?.let { Fmt.plain(it.amount) } ?: "") }
    var freq by remember { mutableStateOf(existing?.freq ?: (if (isIncome) "MONTH" else "MONTH")) }
    var pr by remember { mutableStateOf(existing?.priority ?: Living.cat(kind, cat).priority) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var autoDay by remember { mutableIntStateOf(existing?.autoDay ?: 0) }
    var confirmDel by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existing != null) tr("تعديل البند", "Edit item")
                else if (isIncome) tr("إضافة دخل", "Add income") else tr("إضافة مصروف", "Add expense")
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (isIncome) tr("نوع الدخل", "Income type") else tr("نوع المصروف", "Expense type"), style = MaterialTheme.typography.labelLarge)
                ChipsRow {
                    Living.cats(kind).forEach { c ->
                        FilterChip(cat == c.key, {
                            cat = c.key
                            if (!isIncome) pr = c.priority
                        }, label = { Text(c.emoji + " " + c.label) })
                    }
                }
                OutlinedTextField(
                    name, { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(tr("الاسم (اختياري)", "Name (optional)")) },
                    placeholder = { Text(Living.cat(kind, cat).label) }
                )
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                Text(tr("التكرار", "Frequency"), style = MaterialTheme.typography.labelLarge)
                ChipsRow { Living.freqs.forEach { f -> FilterChip(freq == f, { freq = f }, label = { Text(Living.freqName(f)) }) } }
                Fmt.parse(amount)?.let { v ->
                    Text(
                        tr("يعادل: ", "Equals: ") + Fmt.money(Living.convert(v, freq, "DAY")) + " " + Living.perName("DAY") + "  •  " +
                            Fmt.money(Living.convert(v, freq, "MONTH")) + " " + Living.perName("MONTH") + "  •  " +
                            Fmt.money(Living.convert(v, freq, "YEAR")) + " " + Living.perName("YEAR"),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (!isIncome) {
                    Text(tr("الأولوية", "Priority"), style = MaterialTheme.typography.labelLarge)
                    ChipsRow {
                        Living.priorities.forEach { p ->
                            FilterChip(pr == p, { pr = p }, label = { Text(Living.priorityName(p)) })
                        }
                    }
                    Text(Living.priorityHint(pr), style = MaterialTheme.typography.bodySmall, color = priorityColor(pr))
                }
                NotesField(notes) { notes = it }
                SwitchRow(
                    tr("إضافة تلقائية كل شهر", "Auto-add every month"),
                    tr("مثل الإيجار والفواتير والاشتراكات والراتب، مع تذكير قبلها بيوم", "For rent, bills, subscriptions or salary, with a reminder a day before"),
                    autoDay > 0, Icons.Filled.Autorenew
                ) { autoDay = if (it) LocalDate.now().dayOfMonth.coerceAtMost(28) else 0 }
                if (autoDay > 0) {
                    Text(tr("يوم الإضافة من الشهر: $autoDay", "Day of month: $autoDay"), style = MaterialTheme.typography.labelLarge)
                    Slider(autoDay.toFloat(), { autoDay = it.toInt().coerceIn(1, 31) }, valueRange = 1f..31f, steps = 29)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(amount)
                if (v == null || v <= 0) { toast(ctx, tr("أدخل مبلغاً صحيحاً", "Enter a valid amount")); return@TextButton }
                val nm = name.trim().ifBlank { Living.cat(kind, cat).label }
                val priority = if (isIncome) Living.ESSENTIAL else pr
                scope.launch {
                    if (existing == null) dao.insertLivItem(LivItem(kind = kind, name = nm, category = cat, amount = v, freq = freq, priority = priority, notes = notes.trim(), autoDay = autoDay))
                    else dao.updateLivItem(existing.copy(name = nm, category = cat, amount = v, freq = freq, priority = priority, notes = notes.trim(), autoDay = autoDay))
                    if (autoDay > 0) LivingWorker.schedule(ctx)
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = {
            Row {
                if (existing != null) TextButton(onClick = { confirmDel = true }) { Text(tr("حذف", "Delete"), color = DangerRed) }
                TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) }
            }
        }
    )
    if (confirmDel && existing != null) ConfirmDialog(
        tr("حذف البند", "Delete item"),
        tr("حذف «${existing.name}» من الديباجة؟ لن تتأثر البنود الشهرية المسجلة.", "Delete “${existing.name}” from the template? Recorded periods are not affected."),
        onDismiss = { confirmDel = false }
    ) { scope.launch { dao.deleteLivItem(existing.id); confirmDel = false; onDismiss() } }
}

// ---------------------------------------------------------------------
//                           تبويب البنود (الفترات)
// ---------------------------------------------------------------------
@Composable
private fun PeriodsTab(periods: List<LivPeriod>, entries: List<LivEntry>, nav: NavController) {
    val today = Fmt.today()
    LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (periods.isEmpty()) {
            item {
                EmptyState(Icons.Filled.CalendarMonth, tr("لا توجد بنود بعد.\nأنشئ بنداً مثل «شهر يناير» وأضف فيه الراتب والمصروفات.", "No periods yet.\nCreate one like “January” and add salary & expenses."))
            }
        }
        items(periods, key = { it.id }) { p ->
            val es = entries.filter { it.periodId == p.id }
            val ti = es.filter { it.kind == Living.INCOME }.sumOf { it.amount }
            val te = es.filter { it.kind == Living.EXPENSE }.sumOf { it.amount }
            val bal = ti - te
            val current = today in p.startDate..p.endDate
            Card(onClick = { nav.navigate("living_period/${p.id}") }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Filled.CalendarMonth, MaterialTheme.colorScheme.primary, 38.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text(Fmt.date(p.startDate) + " ← " + Fmt.date(p.endDate), style = MaterialTheme.typography.bodySmall)
                        }
                        if (current) StatusChip(tr("الحالي", "Current"), SuccessGreen)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row {
                        KeyCol(tr("الدخل", "Income"), Fmt.num(ti), SuccessGreen, Modifier.weight(1f))
                        KeyCol(tr("المصروفات", "Expenses"), Fmt.num(te), DangerRed, Modifier.weight(1f))
                        KeyCol(tr("المتبقي", "Remaining"), Fmt.num(bal), if (bal >= 0) MaterialTheme.colorScheme.primary else DangerRed, Modifier.weight(1f))
                    }
                    if (ti > 0) {
                        Spacer(Modifier.height(6.dp))
                        val r = (te / ti).toFloat().coerceIn(0f, 1f)
                        LinearProgressIndicator(progress = { r }, modifier = Modifier.fillMaxWidth(), color = if (te > ti) DangerRed else if (r > 0.9f) WarnAmber else SuccessGreen)
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyCol(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold, color = color)
    }
}

/** إنشاء / تعديل بند (فترة) */
@Composable
private fun PeriodDialog(existing: LivPeriod?, items: List<LivItem>, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val now = LocalDate.now()
    var name by remember { mutableStateOf(existing?.name ?: Living.monthTitle(now)) }
    var start by remember { mutableStateOf(existing?.startDate ?: now.withDayOfMonth(1).toEpochDay()) }
    var end by remember { mutableStateOf(existing?.endDate ?: now.withDayOfMonth(now.lengthOfMonth()).toEpochDay()) }
    var goal by remember { mutableStateOf(existing?.savingsGoal?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var addTemplate by remember { mutableStateOf(existing == null && items.isNotEmpty()) }
    var preset by remember { mutableIntStateOf(if (existing == null) 0 else -1) }

    fun applyPreset(i: Int) {
        preset = i
        when (i) {
            0 -> { name = Living.monthTitle(now); start = now.withDayOfMonth(1).toEpochDay(); end = now.withDayOfMonth(now.lengthOfMonth()).toEpochDay() }
            1 -> {
                val n = now.plusMonths(1)
                name = Living.monthTitle(n); start = n.withDayOfMonth(1).toEpochDay(); end = n.withDayOfMonth(n.lengthOfMonth()).toEpochDay()
            }
            2 -> {
                val s = now.with(DayOfWeek.SATURDAY).let { if (it.isAfter(now)) it.minusWeeks(1) else it }
                name = tr("أسبوع ", "Week of ") + Fmt.date(s); start = s.toEpochDay(); end = s.plusDays(6).toEpochDay()
            }
            3 -> { name = tr("سنة ", "Year ") + now.year; start = now.withDayOfYear(1).toEpochDay(); end = now.withDayOfYear(now.lengthOfYear()).toEpochDay() }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("بند جديد", "New period") else tr("تعديل البند", "Edit period")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ChipsRow {
                    listOf(tr("هذا الشهر", "This month"), tr("الشهر القادم", "Next month"), tr("هذا الأسبوع", "This week"), tr("هذه السنة", "This year"))
                        .forEachIndexed { i, s -> FilterChip(preset == i, { applyPreset(i) }, label = { Text(s) }) }
                }
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم البند (مثل: شهر يناير)", "Name (e.g. January)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                DateField(tr("من", "From"), start, { d -> if (d != null) { start = d; preset = -1 } })
                DateField(tr("إلى", "To"), end, { d -> if (d != null) { end = d; preset = -1 } })
                MoneyField(goal, { goal = it }, tr("هدف الادخار (اختياري)", "Savings goal (optional)"))
                NotesField(notes) { notes = it }
                if (existing == null && items.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().clickable { addTemplate = !addTemplate }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(addTemplate, { addTemplate = it })
                        Text(tr("إضافة كل بنود الديباجة تلقائياً (محسوبة حسب مدة البند)", "Add all template items automatically (scaled to the period)"), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل اسم البند", "Enter a name")); return@TextButton }
                if (end < start) { toast(ctx, tr("تاريخ النهاية قبل البداية", "End date is before start")); return@TextButton }
                val g = Fmt.parse(goal) ?: 0.0
                scope.launch {
                    if (existing != null) {
                        dao.updateLivPeriod(existing.copy(name = name.trim(), startDate = start, endDate = end, savingsGoal = g, notes = notes.trim()))
                        onSaved(existing.id)
                    } else {
                        val id = dao.insertLivPeriod(LivPeriod(name = name.trim(), startDate = start, endDate = end, savingsGoal = g, notes = notes.trim()))
                        if (addTemplate) {
                            val days = (end - start + 1).toInt()
                            items.forEach { i ->
                                dao.insertLivEntry(
                                    LivEntry(
                                        periodId = id, kind = i.kind, itemId = i.id, name = i.name, category = i.category,
                                        priority = i.priority, amount = Living.forDays(i.amount, i.freq, days), date = start, note = i.notes
                                    )
                                )
                            }
                        }
                        onSaved(id)
                    }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// ---------------------------------------------------------------------
//                           تبويب التحليل
// ---------------------------------------------------------------------
@Composable
private fun AnalysisTab(items: List<LivItem>, periods: List<LivPeriod>, entries: List<LivEntry>) {
    var src by rememberSaveable { mutableIntStateOf(0) }
    val avg = remember(periods, entries) { Living.averages(periods, entries) }
    val hasActual = avg.days > 0

    // سطور شهرية للخطة
    val incomeLines: List<Living.Line>
    val expenseLines: List<Living.Line>
    if (src == 0 || !hasActual) {
        incomeLines = Living.templateLines(items, Living.INCOME)
        expenseLines = Living.templateLines(items, Living.EXPENSE)
    } else {
        val used = periods.filter { p -> entries.any { it.periodId == p.id } }.map { it.id }.toSet()
        val es = entries.filter { it.periodId in used }
        val f = 365.0 / 12.0 / avg.days
        incomeLines = es.filter { it.kind == Living.INCOME }.groupBy { it.category }
            .map { (c, l) -> Living.Line(Living.cat(Living.INCOME, c).label, c, Living.ESSENTIAL, l.sumOf { it.amount } * f) }
        expenseLines = es.filter { it.kind == Living.EXPENSE }.groupBy { it.name to it.category }
            .map { (k, l) -> Living.Line(k.first, k.second, l.first().priority, l.sumOf { it.amount } * f) }
    }
    val plan = remember(incomeLines, expenseLines) { Living.plan(incomeLines, expenseLines) }
    val title = if (src == 0 || !hasActual) tr("الديباجة (شهري)", "Template (monthly)") else tr("متوسط فعلي (شهري)", "Actual average (monthly)")

    LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(tr("مصدر التحليل:", "Analyse using:"), style = MaterialTheme.typography.labelLarge)
            ChipsRow {
                FilterChip(src == 0, { src = 0 }, label = { Text(tr("الديباجة", "Template")) })
                FilterChip(src == 1, { src = 1 }, enabled = hasActual, label = { Text(tr("الحركات الفعلية", "Actual entries")) })
            }
            if (!hasActual) Text(tr("سجّل حركات في البنود لتفعيل التحليل الفعلي.", "Record entries in periods to enable actual analysis."), style = MaterialTheme.typography.bodySmall)
        }
        // ---- المتوسطات ----
        item { SectionTitle(tr("متوسط المصروفات والدخل", "Average spending & income")) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val tplExpDay = items.filter { it.kind == Living.EXPENSE }.sumOf { Living.perDay(it.amount, it.freq) }
                    val tplIncDay = items.filter { it.kind == Living.INCOME }.sumOf { Living.perDay(it.amount, it.freq) }
                    Row {
                        Text("", Modifier.weight(1.2f))
                        Text(tr("حسب الديباجة", "Template"), Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        Text(tr("فعلي", "Actual"), Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                    HorizontalDivider()
                    Living.freqs.forEach { f ->
                        Row {
                            Text(tr("مصروف ", "Spend ") + Living.freqName(f), Modifier.weight(1.2f), style = MaterialTheme.typography.bodyMedium)
                            Text(Fmt.num(Living.fromDay(tplExpDay, f)), Modifier.weight(1f), color = DangerRed)
                            Text(if (hasActual) Fmt.num(avg.expense(f)) else "-", Modifier.weight(1f), color = DangerRed, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    HorizontalDivider()
                    Living.freqs.forEach { f ->
                        Row {
                            Text(tr("دخل ", "Income ") + Living.freqName(f), Modifier.weight(1.2f), style = MaterialTheme.typography.bodyMedium)
                            Text(Fmt.num(Living.fromDay(tplIncDay, f)), Modifier.weight(1f), color = SuccessGreen)
                            Text(if (hasActual) Fmt.num(avg.income(f)) else "-", Modifier.weight(1f), color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    if (hasActual) Text(
                        tr("المتوسط الفعلي محسوب من ${avg.periods} بند بإجمالي ${avg.days} يوماً.", "Actual average from ${avg.periods} period(s), ${avg.days} days."),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        // ---- توزيع الفئات ----
        if (expenseLines.isNotEmpty()) {
            item { SectionTitle(tr("توزيع المصروفات شهرياً", "Monthly spending by type")) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val total = expenseLines.sumOf { it.amount }
                        expenseLines.groupBy { it.category }.map { it.key to it.value.sumOf { l -> l.amount } }.sortedByDescending { it.second }.forEach { (c, v) ->
                            val cat = Living.cat(Living.EXPENSE, c)
                            Column {
                                Row {
                                    Text(cat.emoji + " " + cat.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                    Text(Fmt.num(v) + "  (" + (if (total > 0) (v / total * 100).toInt() else 0) + "%)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                }
                                LinearProgressIndicator(progress = { if (total > 0) (v / total).toFloat() else 0f }, modifier = Modifier.fillMaxWidth(), color = priorityColor(cat.priority))
                            }
                        }
                    }
                }
            }
        }
        // ---- الخطة ----
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(tr("أفضل طريقة لإدارة مصروفاتك", "Best way to manage your spending"), Modifier.weight(1f))
                PdfShareButton(null) { c -> Reports.livingPlan(c, title, plan) }
            }
        }
        planItems(plan)
    }
}

/** عرض خطة الإدارة (يُستخدم في التحليل وداخل البند) */
private fun androidx.compose.foundation.lazy.LazyListScope.planItems(plan: Living.Plan) {
    item { RuleCard(plan) }
    items(plan.tips) { t -> TipCard(t) }
    if (plan.cuts.isNotEmpty()) {
        item { SectionTitle(tr("ما يمكن تقليله أو الاستغناء عنه", "What you can reduce or drop")) }
        items(plan.cuts) { c -> CutCard(c, true) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.12f)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Savings, null, tint = SuccessGreen)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("التوفير المتوقع", "Potential savings"), fontWeight = FontWeight.Bold)
                        Text(tr("المتبقي بعد التطبيق: ", "Remaining after: ") + Fmt.money(plan.balanceAfter), style = MaterialTheme.typography.bodySmall)
                    }
                    Text(Fmt.money(plan.potentialSaving), fontWeight = FontWeight.Bold, color = SuccessGreen)
                }
            }
        }
    }
    if (plan.keep.isNotEmpty()) {
        item { SectionTitle(tr("الأساسيات (لا يمكن الاستغناء عنها)", "Essentials (cannot be dropped)")) }
        items(plan.keep) { c -> CutCard(c, false) }
    }
}

@Composable
private fun RuleCard(plan: Living.Plan) {
    if (plan.income <= 0) return
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("قاعدة 50/30/20", "50/30/20 rule"), fontWeight = FontWeight.Bold)
            listOf(
                Triple(tr("احتياجات أساسية", "Needs"), plan.needs, 0.5),
                Triple(tr("رغبات وكماليات", "Wants"), plan.wants, 0.3),
                Triple(tr("ادخار", "Savings"), plan.savings, 0.2)
            ).forEachIndexed { i, (label, v, target) ->
                val share = v / plan.income
                val ok = if (i == 2) share >= target else share <= target
                Column {
                    Row {
                        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${(share * 100).toInt()}% / " + (if (i == 2) "≥" else "≤") + "${(target * 100).toInt()}%",
                            color = if (ok) SuccessGreen else WarnAmber, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    LinearProgressIndicator(progress = { share.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp), color = if (ok) SuccessGreen else WarnAmber)
                }
            }
        }
    }
}

@Composable
private fun TipCard(t: Living.Tip) {
    val color = when (t.level) { 0 -> SuccessGreen; 1 -> MaterialTheme.colorScheme.primary; 2 -> WarnAmber; else -> DangerRed }
    val icon = when (t.level) { 0 -> Icons.Filled.CheckCircle; 1 -> Icons.Filled.Lightbulb; 2 -> Icons.Filled.Warning; else -> Icons.Filled.Error }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f))) {
        Row(Modifier.padding(12.dp)) {
            Icon(icon, null, tint = color)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(t.title, fontWeight = FontWeight.Bold, color = color)
                Text(t.text, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun CutCard(c: Living.Cut, showSaving: Boolean) {
    val cat = Living.cat(Living.EXPENSE, c.category)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(cat.emoji, fontSize = 20.sp)
                Spacer(Modifier.width(8.dp))
                Text(c.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                StatusChip(Living.priorityName(c.priority), priorityColor(c.priority))
            }
            Spacer(Modifier.height(4.dp))
            if (showSaving) Text(
                tr("الحالي ", "Now ") + Fmt.num(c.current) + "  ←  " + tr("المقترح ", "Suggested ") + Fmt.num(c.suggested) +
                    "  (" + tr("توفير ", "save ") + Fmt.num(c.saving) + ")",
                style = MaterialTheme.typography.bodyMedium, color = SuccessGreen, fontWeight = FontWeight.SemiBold
            ) else Text(Fmt.money(c.current), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(c.action, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------------------------------------------------------------
//                           تفاصيل البند
// ---------------------------------------------------------------------
@Composable
fun LivingPeriodScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val period by flowState<LivPeriod?>(null, id) { dao.livPeriodFlow(id) }
    val entries by flowState(emptyList<LivEntry>(), id) { dao.livEntriesFlow(id) }
    val items by flowState(emptyList<LivItem>()) { dao.livItemsFlow() }
    val linked = rememberLinkedIds(AccountTx.SRC_LIV)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var addKind by remember { mutableStateOf<String?>(null) }
    var fromTemplate by remember { mutableStateOf(false) }
    var editPeriod by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    var delEntry by remember { mutableStateOf<LivEntry?>(null) }
    var postEntry by remember { mutableStateOf<LivEntry?>(null) }

    val p = period
    if (p == null) {
        ScreenScaffold(tr("البند", "Period"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }
        return
    }
    val days = Living.days(p)
    val incomes = entries.filter { it.kind == Living.INCOME }
    val expenses = entries.filter { it.kind == Living.EXPENSE }
    val ti = incomes.sumOf { it.amount }
    val te = expenses.sumOf { it.amount }
    val bal = ti - te
    val today = Fmt.today()
    val daysLeft = if (today in p.startDate..p.endDate) (p.endDate - today + 1).toInt() else 0
    val plan = remember(entries) { Living.plan(Living.entryLines(entries, Living.INCOME), Living.entryLines(entries, Living.EXPENSE)) }

    ScreenScaffold(
        title = p.name,
        onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(null, doc = { Docs.livingPeriod(p, entries) }) { c -> Reports.living(c, p, entries) }
            IconButton(onClick = { editPeriod = true }) { Icon(Icons.Filled.Edit, tr("تعديل", "Edit")) }
            IconButton(onClick = { confirmDel = true }) { Icon(Icons.Filled.Delete, tr("حذف", "Delete")) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(Fmt.date(p.startDate) + " ← " + Fmt.date(p.endDate) + "  •  " + tr("$days يوم", "$days days"), style = MaterialTheme.typography.bodySmall)
                        Row {
                            KeyCol(tr("الدخل", "Income"), Fmt.num(ti), SuccessGreen, Modifier.weight(1f))
                            KeyCol(tr("المصروفات", "Expenses"), Fmt.num(te), DangerRed, Modifier.weight(1f))
                            KeyCol(tr("المتبقي", "Remaining"), Fmt.num(bal), if (bal >= 0) MaterialTheme.colorScheme.primary else DangerRed, Modifier.weight(1f))
                        }
                        if (ti > 0) {
                            val r = (te / ti).toFloat().coerceIn(0f, 1f)
                            LinearProgressIndicator(progress = { r }, modifier = Modifier.fillMaxWidth().height(8.dp), color = if (te > ti) DangerRed else if (r > 0.9f) WarnAmber else SuccessGreen)
                            Text(tr("تم صرف ${(te / ti * 100).toInt()}% من الدخل", "Spent ${(te / ti * 100).toInt()}% of income"), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(tr("متوسط المصروف اليومي: ", "Avg daily spend: ") + Fmt.money(te / days), style = MaterialTheme.typography.bodyMedium)
                        if (daysLeft > 0) {
                            val spendable = bal - p.savingsGoal
                            Text(
                                tr("متبقٍ $daysLeft يوم • المسموح يومياً: ", "$daysLeft days left • Daily allowance: ") + Fmt.money(if (spendable > 0) spendable / daysLeft else 0.0),
                                style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (p.savingsGoal > 0) {
                            val g = (bal / p.savingsGoal).toFloat().coerceIn(0f, 1f)
                            Text(tr("هدف الادخار: ", "Savings goal: ") + Fmt.money(p.savingsGoal) + "  (" + (g * 100).toInt() + "%)", style = MaterialTheme.typography.bodyMedium)
                            LinearProgressIndicator(progress = { g }, modifier = Modifier.fillMaxWidth(), color = SuccessGreen)
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { addKind = Living.INCOME }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(6.dp)) {
                        Icon(Icons.Filled.ArrowDownward, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(tr("دخل", "Income"))
                    }
                    FilledTonalButton(onClick = { addKind = Living.EXPENSE }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(6.dp)) {
                        Icon(Icons.Filled.ArrowUpward, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(tr("مصروف", "Expense"))
                    }
                    FilledTonalButton(onClick = { fromTemplate = true }, modifier = Modifier.weight(1.2f), contentPadding = PaddingValues(6.dp)) {
                        Icon(Icons.Filled.LibraryAdd, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(tr("من الديباجة", "From template"), maxLines = 1)
                    }
                }
            }
            item {
                TabRow(selectedTabIndex = tab) {
                    Tab(tab == 0, { tab = 0 }, text = { Text(tr("المصروفات", "Expenses")) })
                    Tab(tab == 1, { tab = 1 }, text = { Text(tr("الدخل", "Income")) })
                    Tab(tab == 2, { tab = 2 }, text = { Text(tr("الميزانية", "Budget")) })
                }
            }
            when (tab) {
                0 -> {
                    if (expenses.isEmpty()) item { EmptyState(Icons.Filled.ShoppingCart, tr("لا توجد مصروفات بعد", "No expenses yet")) }
                    expenses.groupBy { it.category }.toList().sortedByDescending { g -> g.second.sumOf { it.amount } }.forEach { (c, list) ->
                        item(key = "c_$c") {
                            val cat = Living.cat(Living.EXPENSE, c)
                            Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                                Text(cat.emoji + "  " + cat.label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(Fmt.money(list.sumOf { it.amount }), fontWeight = FontWeight.Bold, color = DangerRed)
                            }
                        }
                        items(list, key = { it.id }) { e ->
                            EntryRow(e, e.id in linked, onPost = { postEntry = e }, onDelete = { delEntry = e })
                        }
                    }
                }
                1 -> {
                    if (incomes.isEmpty()) item { EmptyState(Icons.Filled.Payments, tr("أضف الراتب أو أي دخل لهذا البند", "Add salary or any income for this period")) }
                    items(incomes, key = { it.id }) { e ->
                        EntryRow(e, e.id in linked, onPost = { postEntry = e }, onDelete = { delEntry = e })
                    }
                    if (incomes.isNotEmpty()) item {
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(tr("إجمالي الدخل", "Total income"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(Fmt.money(ti), fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                    }
                }
                else -> {
                    item { BudgetCard(items, expenses, days) }
                    item { SectionTitle(tr("نصائح لهذا البند", "Advice for this period")) }
                    planItems(plan)
                }
            }
        }
    }

    addKind?.let { k -> EntryDialog(k, p, items) { addKind = null } }
    if (fromTemplate) FromTemplateDialog(p, items, entries) { fromTemplate = false }
    if (editPeriod) PeriodDialog(p, items, onDismiss = { editPeriod = false }) { editPeriod = false }
    if (confirmDel) ConfirmDialog(
        tr("حذف البند", "Delete period"),
        tr("سيتم حذف «${p.name}» وكل حركاته ومرفقاته، وكذلك الحركات المرحّلة منه إلى الحسابات.", "“${p.name}” with all its entries, attachments and posted account transactions will be deleted."),
        onDismiss = { confirmDel = false }
    ) {
        confirmDel = false
        scope.launch {
            entries.forEach { Attachments.deleteFor(Attachments.LIV_ENTRY, it.id) }
            dao.deleteLivPeriodFull(p.id)
            toast(ctx, tr("تم الحذف", "Deleted"))
            nav.popBackStack()
        }
    }
    delEntry?.let { e ->
        ConfirmDialog(
            tr("حذف الحركة", "Delete entry"),
            tr("حذف «${e.name}» بمبلغ ${Fmt.money(e.amount)}؟", "Delete “${e.name}” (${Fmt.money(e.amount)})?"),
            onDismiss = { delEntry = null }
        ) {
            delEntry = null
            scope.launch {
                Attachments.deleteFor(Attachments.LIV_ENTRY, e.id)
                dao.deleteLinkedTx(AccountTx.SRC_LIV, e.id)
                dao.deleteLivEntry(e.id)
            }
        }
    }
    postEntry?.let { e ->
        val isIn = e.kind == Living.INCOME
        PostToAccountDialog(tr("ترحيل إلى حساب", "Post to account"), isIn, onDismiss = { postEntry = null }) { acc ->
            postEntry = null
            scope.launch {
                Posting.post(acc, AccountTx.SRC_LIV, e.id, isIn, e.amount, e.date, p.name + " - " + e.name + if (e.note.isNotBlank()) " - ${e.note}" else "")
                toast(ctx, tr("تم الترحيل", "Posted"))
            }
        }
    }
}

@Composable
private fun EntryRow(e: LivEntry, linked: Boolean, onPost: () -> Unit, onDelete: () -> Unit) {
    val cat = Living.cat(e.kind, e.category)
    val isIn = e.kind == Living.INCOME
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(cat.emoji, fontSize = 22.sp)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(e.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    Fmt.date(e.date) + (if (!isIn) " • " + Living.priorityName(e.priority) else " • " + cat.label),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (e.note.isNotBlank()) Text(e.note, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    (if (isIn) "+ " else "- ") + Fmt.money(e.amount),
                    fontWeight = FontWeight.Bold, color = if (isIn) SuccessGreen else DangerRed
                )
            }
            AttachmentButton(Attachments.LIV_ENTRY, e.id)
            PostButton(linked, onPost)
            IconButton(onClick = onDelete) { Icon(Icons.Filled.DeleteOutline, tr("حذف", "Delete"), tint = DangerRed) }
        }
    }
}

/** الميزانية المخططة (من الديباجة) مقابل الفعلي لكل فئة */
@Composable
private fun BudgetCard(items: List<LivItem>, expenses: List<LivEntry>, days: Int) {
    val budget = items.filter { it.kind == Living.EXPENSE }.groupBy { it.category }
        .mapValues { (_, l) -> l.sumOf { Living.forDays(it.amount, it.freq, days) } }
    val actual = expenses.groupBy { it.category }.mapValues { (_, l) -> l.sumOf { it.amount } }
    val cats = (budget.keys + actual.keys).distinct().sortedByDescending { maxOf(budget[it] ?: 0.0, actual[it] ?: 0.0) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("المخطط (الديباجة) مقابل الفعلي", "Planned (template) vs actual"), fontWeight = FontWeight.Bold)
            if (cats.isEmpty()) Text(tr("أضف بنوداً في الديباجة لمقارنة الميزانية.", "Add template items to compare."), style = MaterialTheme.typography.bodySmall)
            cats.forEach { c ->
                val b = budget[c] ?: 0.0
                val a = actual[c] ?: 0.0
                val cat = Living.cat(Living.EXPENSE, c)
                val over = b > 0 && a > b
                Column {
                    Row {
                        Text(cat.emoji + " " + cat.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(Fmt.num(a) + " / " + (if (b > 0) Fmt.num(b) else "—"), color = if (over) DangerRed else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    }
                    LinearProgressIndicator(
                        progress = { if (b > 0) (a / b).toFloat().coerceIn(0f, 1f) else if (a > 0) 1f else 0f },
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        color = if (over || b <= 0) DangerRed else if (a > b * 0.9) WarnAmber else SuccessGreen
                    )
                    if (over) Text(tr("تجاوز بمقدار ", "Over by ") + Fmt.money(a - b), style = MaterialTheme.typography.bodySmall, color = DangerRed)
                    else if (b > 0) Text(tr("المتبقي ", "Left ") + Fmt.money(b - a), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

/** إضافة دخل/مصروف للبند: من الديباجة أو جديد */
@Composable
private fun EntryDialog(kind: String, p: LivPeriod, items: List<LivItem>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val isIncome = kind == Living.INCOME
    val days = Living.days(p)
    val tpl = items.filter { it.kind == kind }
    var picked by remember { mutableStateOf<LivItem?>(null) }
    var name by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(Living.cats(kind).first().key) }
    var pr by remember { mutableStateOf(Living.cat(kind, cat).priority) }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today().coerceIn(p.startDate, p.endDate)) }
    var note by remember { mutableStateOf("") }
    var saveToTpl by remember { mutableStateOf(false) }
    val pending = remember { mutableStateListOf<android.net.Uri>() }
    val postKey = if (isIncome) "liv_in" else "liv_out"
    val post = remember { mutableStateOf(Posting.lastAccount(postKey)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isIncome) tr("إضافة دخل", "Add income") else tr("إضافة مصروف", "Add expense")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (tpl.isNotEmpty()) {
                    Text(tr("اختر من الديباجة أو أضف جديداً", "Pick from template or add new"), style = MaterialTheme.typography.labelLarge)
                    ChipsRow {
                        FilterChip(picked == null, { picked = null }, label = { Text(tr("➕ جديد", "➕ New")) })
                        tpl.forEach { i ->
                            FilterChip(picked?.id == i.id, {
                                picked = i
                                name = i.name; cat = i.category; pr = i.priority
                                amount = Fmt.plain(Living.forDays(i.amount, i.freq, days))
                                note = i.notes
                            }, label = { Text(Living.cat(kind, i.category).emoji + " " + i.name) })
                        }
                    }
                }
                Text(if (isIncome) tr("نوع الدخل", "Income type") else tr("نوع المصروف", "Expense type"), style = MaterialTheme.typography.labelLarge)
                ChipsRow {
                    Living.cats(kind).forEach { c ->
                        FilterChip(cat == c.key, { cat = c.key; if (!isIncome) pr = c.priority }, label = { Text(c.emoji + " " + c.label) })
                    }
                }
                OutlinedTextField(
                    name, { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(tr("البيان", "Description")) }, placeholder = { Text(Living.cat(kind, cat).label) }
                )
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                if (!isIncome) {
                    ChipsRow { Living.priorities.forEach { x -> FilterChip(pr == x, { pr = x }, label = { Text(Living.priorityName(x)) }) } }
                }
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
                if (picked == null) {
                    Row(Modifier.fillMaxWidth().clickable { saveToTpl = !saveToTpl }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(saveToTpl, { saveToTpl = it })
                        Text(tr("حفظه أيضاً في الديباجة (شهري)", "Also save to the template (monthly)"), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                AccountPickRow(post, if (isIncome) tr("إيداع في حساب (اختياري)", "Deposit to account (optional)") else tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
                PendingAttachRow(pending)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(amount)
                if (v == null || v <= 0) { toast(ctx, tr("أدخل مبلغاً صحيحاً", "Enter a valid amount")); return@TextButton }
                val nm = name.trim().ifBlank { Living.cat(kind, cat).label }
                val priority = if (isIncome) Living.ESSENTIAL else pr
                scope.launch {
                    var itemId = picked?.id
                    if (picked == null && saveToTpl) {
                        val monthly = if (days in 28..31) v else Living.round2(v / days * 365.0 / 12.0)
                        itemId = dao.insertLivItem(LivItem(kind = kind, name = nm, category = cat, amount = monthly, freq = "MONTH", priority = priority))
                    }
                    val eid = dao.insertLivEntry(
                        LivEntry(periodId = p.id, kind = kind, itemId = itemId, name = nm, category = cat, priority = priority, amount = v, date = date, note = note.trim())
                    )
                    Attachments.addAll(ctx, Attachments.LIV_ENTRY, eid, pending.toList())
                    if (!isIncome) LivingAuto.checkBudget(ctx, cat)
                    Posting.setLastAccount(postKey, post.value)
                    Posting.post(post.value, AccountTx.SRC_LIV, eid, isIncome, v, date, p.name + " - " + nm + if (note.isNotBlank()) " - ${note.trim()}" else "")
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/** إضافة عدة بنود من الديباجة دفعة واحدة */
@Composable
private fun FromTemplateDialog(p: LivPeriod, items: List<LivItem>, entries: List<LivEntry>, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val days = Living.days(p)
    val used = remember(entries) { entries.mapNotNull { it.itemId }.toSet() }
    val checked = remember { mutableStateMapOf<Long, Boolean>().apply { items.forEach { put(it.id, it.id !in used) } } }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.LibraryAdd, null) },
        title = { Text(tr("إضافة من الديباجة", "Add from template")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (items.isEmpty()) Text(tr("الديباجة فارغة. أضف بنوداً من تبويب «ديباجة المعيشة».", "The template is empty. Add items in the Template tab."))
                Text(tr("المبالغ محسوبة حسب مدة البند ($days يوم).", "Amounts scaled to the period ($days days)."), style = MaterialTheme.typography.bodySmall)
                items.forEach { i ->
                    val amt = Living.forDays(i.amount, i.freq, days)
                    Row(Modifier.fillMaxWidth().clickable { checked[i.id] = !(checked[i.id] ?: false) }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked[i.id] ?: false, { checked[i.id] = it })
                        Column(Modifier.weight(1f)) {
                            Text(Living.cat(i.kind, i.category).emoji + " " + i.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (i.id in used) Text(tr("مضاف مسبقاً", "Already added"), style = MaterialTheme.typography.bodySmall, color = WarnAmber)
                        }
                        Text(
                            (if (i.kind == Living.INCOME) "+" else "-") + Fmt.num(amt),
                            color = if (i.kind == Living.INCOME) SuccessGreen else DangerRed, fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val date = Fmt.today().coerceIn(p.startDate, p.endDate)
                    items.filter { checked[it.id] == true }.forEach { i ->
                        dao.insertLivEntry(
                            LivEntry(
                                periodId = p.id, kind = i.kind, itemId = i.id, name = i.name, category = i.category,
                                priority = i.priority, amount = Living.forDays(i.amount, i.freq, days),
                                date = if (i.kind == Living.INCOME) p.startDate else date, note = i.notes
                            )
                        )
                    }
                    onDismiss()
                }
            }) { Text(tr("إضافة", "Add")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// ---------------------------------------------------------------------
//                           تبويب التقارير
// ---------------------------------------------------------------------
/** تقارير مرنة: كل المصروفات خلال فترة، أو مصروفات نوع معين (طعام، تعليم...) أو بند معين خلال فترة */
@Composable
private fun LivingReportsTab(periods: List<LivPeriod>, entries: List<LivEntry>) {
    val now = LocalDate.now()
    var preset by rememberSaveable { mutableIntStateOf(0) }
    var from by rememberSaveable { mutableStateOf(now.withDayOfMonth(1).toEpochDay()) }
    var to by rememberSaveable { mutableStateOf(now.withDayOfMonth(now.lengthOfMonth()).toEpochDay()) }
    var kind by rememberSaveable { mutableIntStateOf(0) }       // 0 مصروفات، 1 دخل، 2 الكل
    var cat by rememberSaveable { mutableStateOf("") }          // "" = كل الأنواع
    var item by rememberSaveable { mutableStateOf("") }         // "" = كل البنود
    var periodId by rememberSaveable { mutableStateOf(-1L) }    // -1 = كل البنود الشهرية

    fun applyPreset(i: Int) {
        preset = i
        when (i) {
            0 -> { from = now.withDayOfMonth(1).toEpochDay(); to = now.withDayOfMonth(now.lengthOfMonth()).toEpochDay() }
            1 -> { val m = now.minusMonths(1); from = m.withDayOfMonth(1).toEpochDay(); to = m.withDayOfMonth(m.lengthOfMonth()).toEpochDay() }
            2 -> { from = now.minusMonths(2).withDayOfMonth(1).toEpochDay(); to = now.withDayOfMonth(now.lengthOfMonth()).toEpochDay() }
            3 -> { from = now.withDayOfYear(1).toEpochDay(); to = now.withDayOfYear(now.lengthOfYear()).toEpochDay() }
            4 -> {
                from = entries.minOfOrNull { it.date } ?: now.toEpochDay()
                to = entries.maxOfOrNull { it.date } ?: now.toEpochDay()
            }
        }
    }

    val kindKey = when (kind) { 0 -> Living.EXPENSE; 1 -> Living.INCOME; else -> null }
    val inRange = entries.filter { it.date in from..to && (periodId < 0 || it.periodId == periodId) && (kindKey == null || it.kind == kindKey) }
    val catKeys = inRange.map { it.kind to it.category }.distinct()
    val byCat = if (cat.isBlank()) inRange else inRange.filter { it.category == cat }
    val names = byCat.map { it.name }.distinct().sorted()
    val result = (if (item.isBlank()) byCat else byCat.filter { it.name == item }).sortedBy { it.date }
    val days = (to - from + 1).coerceAtLeast(1)
    val total = result.sumOf { if (it.kind == Living.INCOME) it.amount else it.amount }
    val te = result.filter { it.kind == Living.EXPENSE }.sumOf { it.amount }
    val ti = result.filter { it.kind == Living.INCOME }.sumOf { it.amount }
    val allExpRange = entries.filter { it.date in from..to && it.kind == Living.EXPENSE && (periodId < 0 || it.periodId == periodId) }.sumOf { it.amount }
    val pNames = periods.associate { it.id to it.name }

    val filterDesc = buildString {
        append(when (kind) { 0 -> tr("المصروفات", "Expenses"); 1 -> tr("الدخل", "Income"); else -> tr("الدخل والمصروفات", "All") })
        if (cat.isNotBlank()) append(" • " + Living.cat(kindKey ?: Living.EXPENSE, cat).label)
        if (item.isNotBlank()) append(" • " + item)
        if (periodId >= 0) append(" • " + (pNames[periodId] ?: ""))
    }
    val title = tr("تقرير مصاريف المعيشة", "Living report") + if (item.isNotBlank()) ": $item" else if (cat.isNotBlank()) ": " + Living.cat(kindKey ?: Living.EXPENSE, cat).label else ""

    LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("الفترة", "Period"), style = MaterialTheme.typography.labelLarge)
                    ChipsRow {
                        listOf(tr("هذا الشهر", "This month"), tr("الشهر الماضي", "Last month"), tr("آخر 3 أشهر", "Last 3 months"), tr("هذه السنة", "This year"), tr("الكل", "All"), tr("مخصص", "Custom"))
                            .forEachIndexed { i, s0 -> FilterChip(preset == i, { applyPreset(i) }, label = { Text(s0) }) }
                    }
                    if (preset == 5) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DateField(tr("من", "From"), from, { d -> if (d != null) from = d }, modifier = Modifier.weight(1f))
                        DateField(tr("إلى", "To"), to, { d -> if (d != null) to = d }, modifier = Modifier.weight(1f))
                    } else Text(Fmt.date(from) + "  ←  " + Fmt.date(to), style = MaterialTheme.typography.bodySmall)
                    if (periods.isNotEmpty()) {
                        Text(tr("البند الشهري", "Period"), style = MaterialTheme.typography.labelLarge)
                        ChipsRow {
                            FilterChip(periodId < 0, { periodId = -1 }, label = { Text(tr("الكل", "All")) })
                            periods.forEach { p ->
                                FilterChip(periodId == p.id, {
                                    periodId = p.id; from = p.startDate; to = p.endDate; preset = 5; cat = ""; item = ""
                                }, label = { Text(p.name) })
                            }
                        }
                    }
                    Text(tr("نوع الحركات", "Entries"), style = MaterialTheme.typography.labelLarge)
                    ChipsRow {
                        listOf(tr("المصروفات", "Expenses"), tr("الدخل", "Income"), tr("الكل", "All"))
                            .forEachIndexed { i, s0 -> FilterChip(kind == i, { kind = i; cat = ""; item = "" }, label = { Text(s0) }) }
                    }
                    Text(tr("القسم (النوع)", "Type"), style = MaterialTheme.typography.labelLarge)
                    ChipsRow {
                        FilterChip(cat.isBlank(), { cat = ""; item = "" }, label = { Text(tr("كل الأنواع", "All types")) })
                        catKeys.map { it.second }.distinct().forEach { c ->
                            val k = catKeys.first { it.second == c }.first
                            val cc = Living.cat(k, c)
                            FilterChip(cat == c, { cat = c; item = "" }, label = { Text(cc.emoji + " " + cc.label) })
                        }
                    }
                    if (names.size > 1 || item.isNotBlank()) {
                        Text(tr("البند", "Item"), style = MaterialTheme.typography.labelLarge)
                        ChipsRow {
                            FilterChip(item.isBlank(), { item = "" }, label = { Text(tr("كل البنود", "All items")) })
                            names.forEach { n -> FilterChip(item == n, { item = n }, label = { Text(n) }) }
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(filterDesc, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        PdfShareButton(null, doc = {
                            Docs.livingEntries(title, filterDesc, result, pNames, listOf(tr("الفترة", "Period") to (Fmt.date(from) + " ← " + Fmt.date(to))))
                        }) { c -> Reports.livingRange(c, title, filterDesc, from, to, result, pNames) }
                    }
                    if (kind != 1 && (te > 0 || kind == 0)) {
                        KeyValue(tr("إجمالي المصروفات", "Total expenses"), Fmt.money(te), DangerRed)
                        KeyValue(tr("متوسط يومي", "Daily average"), Fmt.money(te / days))
                        KeyValue(tr("متوسط أسبوعي", "Weekly average"), Fmt.money(te / days * 7))
                        KeyValue(tr("متوسط شهري", "Monthly average"), Fmt.money(te / days * 365.0 / 12.0))
                        if ((cat.isNotBlank() || item.isNotBlank()) && allExpRange > 0)
                            KeyValue(tr("نسبته من كل المصروفات", "Share of all expenses"), "${(te / allExpRange * 100).toInt()}%")
                    }
                    if (ti > 0 || kind == 1) {
                        KeyValue(tr("إجمالي الدخل (الإضافات)", "Total income"), Fmt.money(ti), SuccessGreen)
                        if (kind == 1) {
                            KeyValue(tr("متوسط الدخل اليومي", "Daily income avg"), Fmt.money(ti / days))
                            KeyValue(tr("متوسط الدخل الشهري", "Monthly income avg"), Fmt.money(ti / days * 365.0 / 12.0))
                            val allIncRange = entries.filter { it.date in from..to && it.kind == Living.INCOME && (periodId < 0 || it.periodId == periodId) }.sumOf { it.amount }
                            if ((cat.isNotBlank() || item.isNotBlank()) && allIncRange > 0)
                                KeyValue(tr("نسبته من كل الدخل", "Share of all income"), "${(ti / allIncRange * 100).toInt()}%")
                        }
                    }
                    if (kind == 2) KeyValue(tr("الصافي", "Net"), Fmt.money(ti - te), if (ti >= te) SuccessGreen else DangerRed)
                    KeyValue(tr("عدد الحركات", "Entries"), "${result.size}")
                }
            }
        }
        // توزيع حسب النوع أو البند
        val groupKind = if (kind == 1) Living.INCOME else Living.EXPENSE
        val groups = if (cat.isBlank()) result.filter { it.kind == groupKind }.groupBy { Living.cat(groupKind, it.category).let { c -> c.emoji + " " + c.label } }
        else result.groupBy { it.name }
        if (groups.size > 1 && item.isBlank()) {
            item {
                SectionTitle(
                    (if (cat.isBlank()) tr("التوزيع حسب النوع", "By type") else tr("التوزيع حسب البند", "By item")) +
                        if (groupKind == Living.INCOME) tr(" — الدخل", " — income") else tr(" — المصروفات", " — expenses")
                )
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val gt = groups.values.sumOf { l -> l.sumOf { it.amount } }
                        groups.map { it.key to it.value.sumOf { e -> e.amount } }.sortedByDescending { it.second }.forEach { (k, v) ->
                            Column {
                                Row {
                                    Text(k, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                    Text(Fmt.num(v) + "  (" + (if (gt > 0) (v / gt * 100).toInt() else 0) + "%)", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                }
                                LinearProgressIndicator(progress = { if (gt > 0) (v / gt).toFloat() else 0f }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
        }
        // حسب الشهر
        val months = result.filter { it.kind == groupKind }.groupBy { LocalDate.ofEpochDay(it.date).let { d -> d.year * 100 + d.monthValue } }.toSortedMap()
        if (months.size > 1) {
            item { SectionTitle(tr("حسب الشهر", "By month")) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val mx = months.values.maxOf { l -> l.sumOf { it.amount } }
                        months.forEach { (k, l) ->
                            val v = l.sumOf { it.amount }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(Living.monthName(k % 100) + " " + (k / 100), Modifier.width(110.dp), style = MaterialTheme.typography.bodySmall)
                                LinearProgressIndicator(progress = { if (mx > 0) (v / mx).toFloat() else 0f }, modifier = Modifier.weight(1f).height(8.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(Fmt.num(v), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle(tr("بيان الحركات", "Statement") + " (${result.size})") }
        if (result.isEmpty()) item { EmptyState(Icons.Filled.Search, tr("لا توجد حركات مطابقة لهذه التصفية", "No matching entries")) }
        items(result, key = { "r_${it.id}" }) { e ->
            val c = Living.cat(e.kind, e.category)
            val isIn = e.kind == Living.INCOME
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.emoji, fontSize = 20.sp)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(Fmt.date(e.date) + " • " + (pNames[e.periodId] ?: ""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (e.note.isNotBlank()) Text(e.note, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text((if (isIn) "+" else "-") + Fmt.num(e.amount), fontWeight = FontWeight.Bold, color = if (isIn) SuccessGreen else DangerRed)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------
//                           الميزانيات الشهرية
// ---------------------------------------------------------------------
@Composable
private fun BudgetsCard(states: List<LivingAuto.BudgetState>, onEdit: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Savings, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(tr("ميزانيات هذا الشهر", "This month's budgets"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onEdit) { Text(if (states.isEmpty()) tr("تحديد", "Set") else tr("تعديل", "Edit")) }
            }
            if (states.isEmpty()) Text(
                tr("حدّد حداً شهرياً لكل نوع (مثل الطعام أو المطاعم) وسيصلك تنبيه عند صرف 80% وعند التجاوز.", "Set a monthly limit per type and get alerts at 80% and when exceeded."),
                style = MaterialTheme.typography.bodySmall
            )
            states.forEach { b ->
                val c = Living.cat(Living.EXPENSE, b.category)
                val color = when { b.ratio > 1 -> DangerRed; b.ratio >= 0.8 -> WarnAmber; else -> SuccessGreen }
                Column {
                    Row {
                        Text(c.emoji + " " + c.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(Fmt.num(b.spent) + " / " + Fmt.num(b.budget), color = color, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    }
                    LinearProgressIndicator(progress = { b.ratio.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp), color = color)
                    Text(
                        if (b.left >= 0) tr("متبقٍ ", "Left ") + Fmt.money(b.left) else tr("تجاوز بـ ", "Over by ") + Fmt.money(-b.left),
                        style = MaterialTheme.typography.bodySmall, color = if (b.left >= 0) MaterialTheme.colorScheme.onSurfaceVariant else DangerRed
                    )
                }
            }
        }
    }
}

@Composable
private fun BudgetDialog(items: List<LivItem>, onDismiss: () -> Unit) {
    val current = remember { Extras.budgets }
    val values = remember { mutableStateMapOf<String, String>().apply { current.forEach { (k, v) -> put(k, Fmt.plain(v)) } } }
    var alerts by remember { mutableStateOf(Extras.budgetAlerts) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Savings, null) },
        title = { Text(tr("الميزانيات الشهرية", "Monthly budgets")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SwitchRow(tr("التنبيه عند الاقتراب والتجاوز", "Alerts near/over budget"), null, alerts, Icons.Filled.NotificationsActive) { alerts = it }
                Text(tr("اترك الحقل فارغاً لإلغاء الميزانية. اضغط «من الديباجة» لتعبئة القيم الشهرية تلقائياً.", "Leave empty to remove. “From template” fills monthly values."), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = {
                    items.filter { it.kind == Living.EXPENSE }.groupBy { it.category }.forEach { (c, l) ->
                        values[c] = Fmt.plain(Living.round2(l.sumOf { Living.monthly(it.amount, it.freq) }))
                    }
                }) { Icon(Icons.Filled.LibraryAdd, null); Spacer(Modifier.width(6.dp)); Text(tr("من الديباجة", "From template")) }
                Living.expenseCats.forEach { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(c.emoji + " " + c.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        OutlinedTextField(
                            values[c.key] ?: "", { values[c.key] = it }, singleLine = true, modifier = Modifier.width(120.dp),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                            placeholder = { Text("—") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Extras.budgets = values.mapNotNull { (k, v) -> Fmt.parse(v)?.takeIf { it > 0 }?.let { k to it } }.toMap()
                Extras.budgetAlerts = alerts
                onDismiss()
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
