package com.sho3eb.app.islam

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.sho3eb.app.R
import com.sho3eb.app.core.tr
import com.sho3eb.app.ui.MainActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

/**
 * تنزيل تلاوة سور كاملة (أو المصحف كله) دفعة واحدة في الخلفية.
 * يعمل كخدمة أمامية بإشعار تقدّم، ويتجاوز الملفات المنزّلة مسبقاً فيمكن استكماله في أي وقت.
 */
object QuranBulk {
    const val WORK = "quran_bulk_download"
    const val CHANNEL = "quran_download"
    const val NOTIF_ID = 7301
    const val K_RECITER = "reciter"; const val K_NAME = "name"; const val K_TEMPLATE = "template"; const val K_SURAHS = "surahs"
    const val P_DONE = "done"; const val P_TOTAL = "total"; const val P_SURAH = "surah"; const val P_FAILED = "failed"; const val P_NAME = "rname"

    fun start(ctx: Context, r: Reciter, surahs: List<Int>, wifiOnly: Boolean) {
        val data = workDataOf(K_RECITER to r.id, K_NAME to r.name, K_TEMPLATE to (r.template ?: ""), K_SURAHS to surahs.joinToString(","))
        val req = OneTimeWorkRequestBuilder<QuranBulkWorker>()
            .setInputData(data)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.LINEAR, WorkRequest.MIN_BACKOFF_MILLIS, java.util.concurrent.TimeUnit.MILLISECONDS)
            .addTag(WORK)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(WORK, ExistingWorkPolicy.APPEND_OR_REPLACE, req)
    }

    fun cancel(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK)
        NotificationManagerCompat.from(ctx).cancel(NOTIF_ID)
    }

    /** حالة التنزيل الحالية (للعرض في الواجهة) */
    data class State(val running: Boolean, val queued: Int, val done: Int, val total: Int, val surah: Int, val failed: Int, val name: String)

    suspend fun state(ctx: Context): State = withContext(Dispatchers.IO) {
        val infos = try { WorkManager.getInstance(ctx).getWorkInfosForUniqueWork(WORK).get() } catch (_: Exception) { emptyList() }
        val run = infos.firstOrNull { it.state == WorkInfo.State.RUNNING }
        val queued = infos.count { it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.BLOCKED }
        val p = run?.progress
        State(run != null, queued, p?.getInt(P_DONE, 0) ?: 0, p?.getInt(P_TOTAL, 0) ?: 0, p?.getInt(P_SURAH, 0) ?: 0, p?.getInt(P_FAILED, 0) ?: 0, p?.getString(P_NAME) ?: "")
    }

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, tr("تنزيل تلاوات القرآن", "Quran audio downloads"), NotificationManager.IMPORTANCE_LOW)
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    fun notification(ctx: Context, title: String, text: String, done: Int, total: Int, ongoing: Boolean, cancel: PendingIntent?): android.app.Notification {
        createChannel(ctx)
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF0F766E.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setSilent(true)
        if (ongoing) b.setProgress(total.coerceAtLeast(1), done, total == 0)
        if (cancel != null) b.addAction(android.R.drawable.ic_menu_close_clear_cancel, tr("إيقاف", "Stop"), cancel)
        return b.build()
    }
}

class QuranBulkWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val app = ctx.applicationContext

    private fun fg(title: String, text: String, done: Int, total: Int): ForegroundInfo {
        val cancel = WorkManager.getInstance(app).createCancelPendingIntent(id)
        val n = QuranBulk.notification(app, title, text, done, total, true, cancel)
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(QuranBulk.NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(QuranBulk.NOTIF_ID, n)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = fg(tr("تنزيل التلاوة", "Downloading recitation"), "", 0, 0)

    /** روابط صوت آيات سورة كاملة باستدعاء واحد */
    private fun surahUrls(r: Reciter, s: Int): List<Pair<Int, String>> {
        if (r.template != null) {
            val su = QuranRepo.surah(s) ?: return emptyList()
            return (0 until su.count).map { k -> val g = su.firstGlobal + k; g to QuranRepo.remoteAudioUrl(r, g) }
        }
        val json = JSONObject(Net.get("https://api.alquran.cloud/v1/surah/$s/${URLEncoder.encode(r.id, "UTF-8")}", 30000))
        val arr = json.getJSONObject("data").getJSONArray("ayahs")
        return (0 until arr.length()).map { k ->
            val o = arr.getJSONObject(k)
            val url = o.optString("audio").ifBlank { o.optJSONArray("audioSecondary")?.optString(0) ?: "" }
            o.getInt("number") to url
        }.filter { it.second.isNotBlank() }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val rid = inputData.getString(QuranBulk.K_RECITER) ?: return@withContext Result.failure()
        val name = inputData.getString(QuranBulk.K_NAME) ?: rid
        val template = inputData.getString(QuranBulk.K_TEMPLATE)?.takeIf { it.isNotBlank() }
        val surahs = inputData.getString(QuranBulk.K_SURAHS).orEmpty().split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..114 }
        if (surahs.isEmpty()) return@withContext Result.success()
        val r = Reciter(rid, name, template)
        QuranRepo.ensureLoaded(app)
        val counts = surahs.associateWith { QuranRepo.surah(it)?.count ?: 0 }
        val total = counts.values.sum()
        val done = AtomicInteger(0)
        val failed = AtomicInteger(0)
        val title = tr("تنزيل تلاوة ", "Downloading ") + name
        try { setForeground(fg(title, tr("جارٍ التحضير...", "Preparing..."), 0, total)) } catch (_: Exception) { }

        for (s in surahs) {
            if (isStopped) return@withContext Result.success()
            val sName = QuranRepo.surah(s)?.let { QuranRepo.surahNameClean(it) } ?: "$s"
            val list = try { surahUrls(r, s) } catch (e: Exception) {
                failed.addAndGet(counts[s] ?: 0); done.addAndGet(counts[s] ?: 0); continue
            }
            val todo = list.filter { !QuranRepo.audioFile(app, rid, it.first).exists() }
            done.addAndGet(list.size - todo.size)
            // 4 تنزيلات متوازية لتسريع العملية
            for (chunk in todo.chunked(4)) {
                if (isStopped) return@withContext Result.success()
                coroutineScope {
                    chunk.map { (g, url) ->
                        async {
                            var ok = false
                            repeat(3) { attempt ->
                                if (!ok) ok = try { Net.download(url, QuranRepo.audioFile(app, rid, g), 30000); true } catch (_: Exception) {
                                    if (attempt < 2) Thread.sleep(1500L * (attempt + 1)); false
                                }
                            }
                            if (!ok) failed.incrementAndGet()
                            done.incrementAndGet()
                        }
                    }.awaitAll()
                }
                val d = done.get()
                setProgress(workDataOf(QuranBulk.P_DONE to d, QuranBulk.P_TOTAL to total, QuranBulk.P_SURAH to s, QuranBulk.P_FAILED to failed.get(), QuranBulk.P_NAME to name))
                try { setForeground(fg(title, tr("سورة ", "Surah ") + sName + " • " + d + " / " + total + tr(" آية", " ayat"), d, total)) } catch (_: Exception) { }
            }
            setProgress(workDataOf(QuranBulk.P_DONE to done.get(), QuranBulk.P_TOTAL to total, QuranBulk.P_SURAH to s, QuranBulk.P_FAILED to failed.get(), QuranBulk.P_NAME to name))
        }

        val f = failed.get()
        val msg = if (f == 0) tr("اكتمل تنزيل ${surahs.size} سورة (${total} آية) ✅ يمكنك الاستماع بدون إنترنت.", "Downloaded ${surahs.size} surahs ($total ayat) ✅ available offline.")
        else tr("انتهى التنزيل مع تعذّر $f آية. أعد التنزيل لاستكمال الناقص فقط.", "Finished with $f failed ayat. Start again to fetch only the missing ones.")
        try { NotificationManagerCompat.from(app).notify(QuranBulk.NOTIF_ID + 1, QuranBulk.notification(app, name, msg, 0, 0, false, null)) } catch (_: SecurityException) { }
        Result.success()
    }
}
