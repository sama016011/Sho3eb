package com.sho3eb.app.core

import android.content.Context
import android.util.Xml
import com.sho3eb.app.Sho3ebApp
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/**
 * كرة القدم: المباريات والنتائج والترتيب والأخبار والإشعارات.
 * المصدر الأساسي TheSportsDB (مجاني، يغطي الدوري المصري وكل الدوريات)،
 * مع تفاصيل الأهداف من ESPN للدوريات الأوروبية، و API-Football اختيارياً (مفتاح مجاني) للهدافين والأحداث الكاملة.
 */
object Football {
    private const val SDB = "https://www.thesportsdb.com/api/v1/json/123/"

    data class League(val id: String, val name: String, val country: String, val badge: String = "", val espn: String = "", val nameAr: String = "") {
        val title get() = if (nameAr.isNotBlank()) tr(nameAr, name) else name
    }
    data class Match(
        val id: String, val apiId: String, val leagueId: String, val leagueName: String, val season: String, val round: Int,
        val time: Long, val home: String, val away: String, val homeId: String, val awayId: String, val homeBadge: String, val awayBadge: String,
        val hs: Int?, val aws: Int?, val status: String, val venue: String, val video: String, val thumb: String
    ) {
        val live get() = status in liveCodes
        val finished get() = status in doneCodes
        val notStarted get() = !live && !finished
        val date: LocalDate get() = Instant.ofEpochMilli(time).atZone(ZoneId.systemDefault()).toLocalDate()
        val score get() = if (hs != null && aws != null) "$hs - $aws" else "-"
    }
    data class Row(val team: String, val teamId: String, val badge: String, var p: Int = 0, var w: Int = 0, var d: Int = 0, var l: Int = 0, var gf: Int = 0, var ga: Int = 0, val form: MutableList<Char> = mutableListOf()) {
        val pts get() = w * 3 + d
        val gd get() = gf - ga
    }
    data class News(val title: String, val link: String, val source: String, val time: Long)
    data class Event(val minute: String, val type: String, val player: String, val team: String, val detail: String)
    data class Player(val name: String, val team: String, val photo: String, val goals: Int, val assists: Int, val apps: Int)

    val liveCodes = setOf("1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT", "PEN")
    val doneCodes = setOf("FT", "AET", "PEN_FT", "AP", "Match Finished", "AWD", "WO")
    fun statusLabel(s: String) = when (s) {
        "NS", "" -> tr("لم تبدأ", "Not started"); "1H" -> tr("الشوط الأول", "1st half"); "HT" -> tr("بين الشوطين", "Half-time"); "2H" -> tr("الشوط الثاني", "2nd half")
        "ET" -> tr("وقت إضافي", "Extra time"); "P", "PEN" -> tr("ركلات ترجيح", "Penalties"); "FT", "Match Finished" -> tr("انتهت", "Full-time"); "AET" -> tr("انتهت بعد الإضافي", "After extra time")
        "PST" -> tr("مؤجلة", "Postponed"); "CANC" -> tr("ملغاة", "Cancelled"); "ABD" -> tr("متوقفة", "Abandoned"); "SUSP" -> tr("معلقة", "Suspended"); "LIVE" -> tr("مباشر", "Live")
        else -> s
    }

    /** الدوريات الافتراضية (معرّفات TheSportsDB + ESPN) */
    val defaults = listOf(
        League("4829", "Egyptian Premier League", "Egypt", espn = "", nameAr = "الدوري المصري الممتاز"),
        League("5185", "Egypt League Cup", "Egypt", nameAr = "كأس رابطة الأندية المصرية"),
        League("4480", "UEFA Champions League", "Europe", espn = "uefa.champions", nameAr = "دوري أبطال أوروبا"),
        League("4481", "UEFA Europa League", "Europe", espn = "uefa.europa", nameAr = "الدوري الأوروبي"),
        League("4328", "English Premier League", "England", espn = "eng.1", nameAr = "الدوري الإنجليزي"),
        League("4335", "Spanish La Liga", "Spain", espn = "esp.1", nameAr = "الدوري الإسباني"),
        League("4332", "Italian Serie A", "Italy", espn = "ita.1", nameAr = "الدوري الإيطالي"),
        League("4331", "German Bundesliga", "Germany", espn = "ger.1", nameAr = "الدوري الألماني"),
        League("4334", "French Ligue 1", "France", espn = "fra.1", nameAr = "الدوري الفرنسي"),
        League("4668", "Saudi Pro League", "Saudi Arabia", espn = "ksa.1", nameAr = "الدوري السعودي")
    )
    val countries = listOf(
        "Egypt" to "مصر", "England" to "إنجلترا", "Spain" to "إسبانيا", "Italy" to "إيطاليا", "Germany" to "ألمانيا", "France" to "فرنسا", "Saudi Arabia" to "السعودية",
        "United Arab Emirates" to "الإمارات", "Qatar" to "قطر", "Kuwait" to "الكويت", "Morocco" to "المغرب", "Tunisia" to "تونس", "Algeria" to "الجزائر", "Portugal" to "البرتغال",
        "Netherlands" to "هولندا", "Turkey" to "تركيا", "Belgium" to "بلجيكا", "Scotland" to "اسكتلندا", "USA" to "أمريكا", "Brazil" to "البرازيل", "Argentina" to "الأرجنتين",
        "Africa" to "أفريقيا", "Europe" to "أوروبا", "Asia" to "آسيا", "World" to "العالم"
    )

    // ---------------- الإعدادات ----------------
    fun leagues(): List<League> {
        val s = Extras.s("fb_leagues", "")
        if (s.isBlank()) return defaults
        return runCatching { JSONArray(s).let { a -> (0 until a.length()).map { i -> a.getJSONObject(i).let { o -> League(o.getString("id"), o.getString("n"), o.optString("c"), o.optString("b"), o.optString("e"), o.optString("a")) } } } }.getOrDefault(defaults)
    }
    fun saveLeagues(list: List<League>) = Extras.ps("fb_leagues", JSONArray(list.map { JSONObject().put("id", it.id).put("n", it.name).put("c", it.country).put("b", it.badge).put("e", it.espn).put("a", it.nameAr) }).toString())
    var favTeamId: String get() = Extras.s("fb_fav_team", ""); set(v) = Extras.ps("fb_fav_team", v)
    var favTeamName: String get() = Extras.s("fb_fav_team_n", ""); set(v) = Extras.ps("fb_fav_team_n", v)
    var favTeamBadge: String get() = Extras.s("fb_fav_team_b", ""); set(v) = Extras.ps("fb_fav_team_b", v)
    var favLeague: String get() = Extras.s("fb_fav_league", "4829"); set(v) = Extras.ps("fb_fav_league", v)
    var apiKey: String get() = Extras.s("fb_apikey", ""); set(v) = Extras.ps("fb_apikey", v.trim())
    var notify: Boolean get() = Extras.b("fb_notify", true); set(v) = Extras.pb("fb_notify", v)
    var notifyGoals: Boolean get() = Extras.b("fb_n_goals", true); set(v) = Extras.pb("fb_n_goals", v)
    var notifyStart: Boolean get() = Extras.b("fb_n_start", true); set(v) = Extras.pb("fb_n_start", v)
    var notifyEnd: Boolean get() = Extras.b("fb_n_end", true); set(v) = Extras.pb("fb_n_end", v)
    var notifyAllFavLeague: Boolean get() = Extras.b("fb_n_league", false); set(v) = Extras.pb("fb_n_league", v)
    fun followedMatches(): Set<String> = Extras.s("fb_follow", "").split(",").filter { it.isNotBlank() }.toSet()
    var favTeamLeague: String get() = Extras.s("fb_fav_team_l", ""); set(v) = Extras.ps("fb_fav_team_l", v)
    fun followLeagues(): Set<String> = Extras.s("fb_follow_l", "").split(",").filter { it.isNotBlank() }.toSet()
    fun addFollowLeague(id: String) = Extras.ps("fb_follow_l", (followLeagues() + id).joinToString(","))
    fun toggleFollow(id: String) { val s = followedMatches(); Extras.ps("fb_follow", (if (id in s) s - id else s + id).takeLast(60).joinToString(",")) }

    // ---------------- الشبكة والتخزين المؤقت ----------------
    private fun cacheDir() = File(Sho3ebApp.instance.cacheDir, "football").apply { mkdirs() }
    private fun http(url: String, headers: Map<String, String> = emptyMap()): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Sho3eb")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (c.responseCode !in 200..299) null else c.inputStream.bufferedReader().use { it.readText() }
    }.getOrNull()

    /** جلب مع تخزين مؤقت؛ ttl بالثواني */
    fun cached(key: String, ttl: Long, url: String, headers: Map<String, String> = emptyMap()): String? {
        val f = File(cacheDir(), key.replace(Regex("[^A-Za-z0-9_.-]"), "_"))
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < ttl * 1000) return f.readText()
        val t = http(url, headers)
        if (t != null) { f.writeText(t); return t }
        return if (f.exists()) f.readText() else null
    }
    fun clearCache() = cacheDir().listFiles()?.forEach { it.delete() }

    // ---------------- TheSportsDB ----------------
    private fun parseTime(o: JSONObject): Long {
        val ts = o.optString("strTimestamp").takeIf { it.isNotBlank() && it != "null" }
        if (ts != null) runCatching { return LocalDateTime.parse(ts.take(19)).toInstant(ZoneOffset.UTC).toEpochMilli() }
        val d = o.optString("dateEvent"); val t = o.optString("strTime").takeIf { it.isNotBlank() && it != "null" } ?: "00:00:00"
        return runCatching { LocalDateTime.parse(d + "T" + t.take(8)).toInstant(ZoneOffset.UTC).toEpochMilli() }.getOrDefault(0L)
    }
    private fun s(o: JSONObject, k: String) = o.optString(k).takeIf { it != "null" } ?: ""
    private fun i(o: JSONObject, k: String) = o.optString(k).takeIf { it.isNotBlank() && it != "null" }?.toIntOrNull()
    fun parseEvent(o: JSONObject) = Match(
        s(o, "idEvent"), s(o, "idAPIfootball"), s(o, "idLeague"), s(o, "strLeague"), s(o, "strSeason"), i(o, "intRound") ?: 0, parseTime(o),
        s(o, "strHomeTeam"), s(o, "strAwayTeam"), s(o, "idHomeTeam"), s(o, "idAwayTeam"), s(o, "strHomeTeamBadge"), s(o, "strAwayTeamBadge"),
        i(o, "intHomeScore"), i(o, "intAwayScore"), s(o, "strStatus").ifBlank { if (i(o, "intHomeScore") != null) "FT" else "NS" }, s(o, "strVenue"), s(o, "strVideo"), s(o, "strThumb")
    )
    private fun events(json: String?, key: String = "events"): List<Match> = runCatching {
        val a = JSONObject(json ?: return emptyList()).optJSONArray(key) ?: return emptyList()
        (0 until a.length()).map { parseEvent(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    data class LeagueInfo(val season: String, val badge: String, val round: Int)
    fun leagueInfo(id: String): LeagueInfo {
        val j = cached("lg_$id", 6 * 3600, SDB + "lookupleague.php?id=$id")
        val o = runCatching { JSONObject(j ?: "{}").optJSONArray("leagues")?.getJSONObject(0) }.getOrNull()
        val season = o?.let { s(it, "strCurrentSeason") } ?: ""
        val badge = o?.let { s(it, "strBadge") } ?: ""
        val next = events(cached("nx_$id", 600, SDB + "eventsnextleague.php?id=$id")).firstOrNull()
        val past = events(cached("pa_$id", 600, SDB + "eventspastleague.php?id=$id")).firstOrNull()
        val round = next?.round?.takeIf { it > 0 } ?: past?.round ?: 1
        return LeagueInfo(season.ifBlank { next?.season ?: past?.season ?: "" }, badge, round)
    }
    /** مباريات جولة؛ الجولات المنتهية تُخزن طويلاً، والجارية دقيقة واحدة */
    fun round(id: String, season: String, r: Int, live: Boolean = false): List<Match> {
        val key = "rd_${id}_${season}_$r"
        val f = File(cacheDir(), key.replace(Regex("[^A-Za-z0-9_.-]"), "_"))
        val prev = if (f.exists()) events(f.readText()) else emptyList()
        val done = prev.isNotEmpty() && prev.all { it.finished || it.status in setOf("PST", "CANC", "ABD") } && prev.maxOf { it.time } < System.currentTimeMillis() - 6 * 3600_000
        val ttl = when { done -> 30L * 24 * 3600; live || prev.any { it.live } -> 60L; else -> 900L }
        return events(cached(key, ttl, SDB + "eventsround.php?id=$id&r=$r&s=" + URLEncoder.encode(season, "UTF-8")))
    }
    /** مباريات حول الجولة الحالية (السابقة، الحالية، التالية) */
    fun around(l: League, live: Boolean = false): List<Match> {
        val info = leagueInfo(l.id)
        return (maxOf(1, info.round - 1)..info.round + 1).flatMap { round(l.id, info.season, it, live) }.distinctBy { it.id }
    }
    /** الموسم كاملاً حتى الجولة الحالية (للترتيب) */
    fun season(l: League): List<Match> {
        val info = leagueInfo(l.id)
        val out = mutableListOf<Match>()
        var r = 1; var empty = 0
        while (r <= info.round + 1 && r < 60) {
            val m = round(l.id, info.season, r)
            if (m.isEmpty()) empty++ else { empty = 0; out += m }
            if (empty >= 3) break
            r++
        }
        return out.distinctBy { it.id }
    }
    fun table(matches: List<Match>): List<Row> {
        val rows = mutableMapOf<String, Row>()
        matches.filter { it.finished && it.hs != null && it.aws != null }.sortedBy { it.time }.forEach { m ->
            val h = rows.getOrPut(m.homeId.ifBlank { m.home }) { Row(m.home, m.homeId, m.homeBadge) }
            val a = rows.getOrPut(m.awayId.ifBlank { m.away }) { Row(m.away, m.awayId, m.awayBadge) }
            h.p++; a.p++; h.gf += m.hs!!; h.ga += m.aws!!; a.gf += m.aws; a.ga += m.hs
            when { m.hs > m.aws -> { h.w++; a.l++; h.form += 'W'; a.form += 'L' }; m.hs < m.aws -> { a.w++; h.l++; h.form += 'L'; a.form += 'W' }; else -> { h.d++; a.d++; h.form += 'D'; a.form += 'D' } }
        }
        return rows.values.sortedWith(compareByDescending<Row> { it.pts }.thenByDescending { it.gd }.thenByDescending { it.gf }.thenBy { it.team })
    }
    fun searchLeagues(country: String): List<League> = runCatching {
        val j = cached("cty_$country", 7 * 24 * 3600, SDB + "search_all_leagues.php?s=Soccer&c=" + URLEncoder.encode(country, "UTF-8"))
        val a = JSONObject(j ?: "{}").optJSONArray("countries") ?: JSONObject(j ?: "{}").optJSONArray("countrys") ?: return@runCatching emptyList()
        (0 until a.length()).map { a.getJSONObject(it) }.map { o -> League(s(o, "idLeague"), s(o, "strLeague"), country, s(o, "strBadge")) }
    }.getOrDefault(emptyList())
    data class Team(val id: String, val name: String, val badge: String, val stadium: String, val year: String, val desc: String, val league: String)
    fun team(id: String): Team? = runCatching {
        val o = JSONObject(cached("tm_$id", 7 * 24 * 3600, SDB + "lookupteam.php?id=$id") ?: return null).getJSONArray("teams").getJSONObject(0)
        Team(s(o, "idTeam"), s(o, "strTeam"), s(o, "strBadge"), s(o, "strStadium"), s(o, "intFormedYear"), s(o, "strDescriptionAR").ifBlank { s(o, "strDescriptionEN") }, s(o, "strLeague"))
    }.getOrNull()
    data class Tv(val channel: String, val country: String, val logo: String)
    fun tv(eventId: String): List<Tv> = runCatching {
        val a = JSONObject(cached("tv_$eventId", 6 * 3600, SDB + "lookuptv.php?id=$eventId") ?: return emptyList()).optJSONArray("tvevent") ?: return emptyList()
        (0 until a.length()).map { a.getJSONObject(it) }.map { Tv(s(it, "strChannel"), s(it, "strCountry"), s(it, "strLogo")) }.filter { it.channel.isNotBlank() }
    }.getOrDefault(emptyList())

    // ---------------- ESPN: أحداث المباريات للدوريات الأوروبية ----------------
    private fun norm(n: String) = n.lowercase().replace(Regex("\\b(fc|cf|ac|sc|afc|ssc|as|club|de|cd|rc|sv|vfb|tsg|1\\.)\\b"), "").replace(Regex("[^a-z]"), "")
    private fun same(a: String, b: String): Boolean { val x = norm(a); val y = norm(b); return x.isNotEmpty() && y.isNotEmpty() && (x.contains(y) || y.contains(x) || x.take(5) == y.take(5)) }
    fun espnEvents(l: League, m: Match): List<Event> {
        if (l.espn.isBlank()) return emptyList()
        val d = m.date.format(DateTimeFormatter.BASIC_ISO_DATE)
        return runCatching {
            val j = cached("es_${l.espn}_$d", if (m.live) 60 else 1800, "https://site.api.espn.com/apis/site/v2/sports/soccer/${l.espn}/scoreboard?dates=$d") ?: return emptyList()
            val evs = JSONObject(j).optJSONArray("events") ?: return emptyList()
            for (k in 0 until evs.length()) {
                val comp = evs.getJSONObject(k).getJSONArray("competitions").getJSONObject(0)
                val cs = comp.getJSONArray("competitors")
                val names = (0 until cs.length()).associate { cs.getJSONObject(it).let { c -> c.optString("homeAway") to c.getJSONObject("team").optString("displayName") } }
                val ids = (0 until cs.length()).associate { cs.getJSONObject(it).let { c -> c.getJSONObject("team").optString("id") to c.getJSONObject("team").optString("displayName") } }
                if (same(names["home"] ?: "", m.home) && same(names["away"] ?: "", m.away)) {
                    val det = comp.optJSONArray("details") ?: return emptyList()
                    return (0 until det.length()).map { det.getJSONObject(it) }.map { e ->
                        val type = e.optJSONObject("type")?.optString("text") ?: ""
                        val ath = e.optJSONArray("athletesInvolved")?.let { a -> if (a.length() > 0) a.getJSONObject(0).optString("displayName") else "" } ?: ""
                        Event(e.optJSONObject("clock")?.optString("displayValue") ?: "", type, ath, ids[e.optJSONObject("team")?.optString("id")] ?: "",
                            if (e.optBoolean("penaltyKick")) tr("ركلة جزاء", "penalty") else if (e.optBoolean("ownGoal")) tr("هدف عكسي", "own goal") else "")
                    }
                }
            }
            emptyList()
        }.getOrDefault(emptyList())
    }
    fun espnNews(l: League): List<News> = runCatching {
        if (l.espn.isBlank()) return emptyList()
        val a = JSONObject(cached("en_${l.espn}", 1800, "https://site.api.espn.com/apis/site/v2/sports/soccer/${l.espn}/news") ?: return emptyList()).optJSONArray("articles") ?: return emptyList()
        (0 until a.length()).map { a.getJSONObject(it) }.map { o -> News(o.optString("headline"), o.optJSONObject("links")?.optJSONObject("web")?.optString("href") ?: "", "ESPN", runCatching { Instant.parse(o.optString("published")).toEpochMilli() }.getOrDefault(0L)) }
    }.getOrDefault(emptyList())

    // ---------------- API-Football (اختياري بمفتاح مجاني) ----------------
    private fun apif(path: String, ttl: Long): JSONObject? {
        if (apiKey.isBlank()) return null
        return runCatching { JSONObject(cached("af_" + path, ttl, "https://v3.football.api-sports.io/$path", mapOf("x-apisports-key" to apiKey)) ?: return null) }.getOrNull()
    }
    fun apifError(o: JSONObject?): String? = o?.opt("errors")?.let { e -> when (e) { is JSONObject -> e.keys().asSequence().map { e.optString(it) }.joinToString("\n").ifBlank { null }; is JSONArray -> if (e.length() > 0) e.toString() else null; else -> null } }
    /** تفاصيل المباراة: الأحداث */
    fun apifEvents(m: Match): Pair<List<Event>, String?> {
        if (m.apiId.isBlank()) return emptyList<Event>() to null
        val o = apif("fixtures?id=${m.apiId}", if (m.live) 60 else 3 * 3600) ?: return emptyList<Event>() to null
        apifError(o)?.let { return emptyList<Event>() to it }
        val f = o.optJSONArray("response")?.optJSONObject(0) ?: return emptyList<Event>() to null
        // حفظ ربط الدوري بالموسم في API-Football
        f.optJSONObject("league")?.let { lg -> Extras.ps("af_map_${m.leagueId}", lg.optInt("id").toString() + ":" + lg.optInt("season")) }
        val ev = f.optJSONArray("events") ?: return emptyList<Event>() to null
        return (0 until ev.length()).map { ev.getJSONObject(it) }.map { e ->
            val t = e.optJSONObject("time"); val min = (t?.optInt("elapsed") ?: 0).toString() + (t?.optInt("extra")?.takeIf { it > 0 }?.let { "+$it" } ?: "") + "'"
            Event(min, e.optString("type"), e.optJSONObject("player")?.optString("name") ?: "", e.optJSONObject("team")?.optString("name") ?: "", e.optString("detail"))
        } to null
    }
    /** الهدافون أو صناع اللعب */
    fun apifPlayers(leagueId: String, assists: Boolean): Pair<List<Player>, String?> {
        if (apiKey.isBlank()) return emptyList<Player>() to tr("أضف مفتاح API-Football المجاني من إعدادات كرة القدم لعرض الهدافين وصناع اللعب.", "Add a free API-Football key in football settings to see scorers and assisters.")
        val map = Extras.s("af_map_$leagueId", "")
        if (map.isBlank()) return emptyList<Player>() to tr("افتح أي مباراة من هذا الدوري أولاً لربطه بالمصدر، ثم ارجع هنا.", "Open any match of this league first to link it, then come back.")
        val (lid, season) = map.split(":").let { it[0] to it.getOrElse(1) { "" } }
        val o = apif("players/" + (if (assists) "topassists" else "topscorers") + "?league=$lid&season=$season", 6 * 3600) ?: return emptyList<Player>() to tr("تعذر الاتصال", "Connection failed")
        apifError(o)?.let { return emptyList<Player>() to it }
        val a = o.optJSONArray("response") ?: return emptyList<Player>() to null
        return (0 until a.length()).map { a.getJSONObject(it) }.map { r ->
            val p = r.getJSONObject("player"); val st = r.getJSONArray("statistics").getJSONObject(0)
            Player(p.optString("name"), st.optJSONObject("team")?.optString("name") ?: "", p.optString("photo"), st.optJSONObject("goals")?.optInt("total") ?: 0, st.optJSONObject("goals")?.optInt("assists") ?: 0, st.optJSONObject("games")?.optInt("appearences") ?: 0)
        } to null
    }

    // ---------------- الأخبار (Google News بالعربية) ----------------
    fun news(query: String): List<News> = runCatching {
        val url = "https://news.google.com/rss/search?q=" + URLEncoder.encode(query, "UTF-8") + "&hl=ar&gl=EG&ceid=EG:ar"
        val xml = cached("nw_" + query.hashCode(), 1200, url) ?: return emptyList()
        val p = Xml.newPullParser(); p.setInput(xml.reader())
        val out = mutableListOf<News>()
        var inItem = false; var title = ""; var link = ""; var src = ""; var date = ""; var tag = ""
        while (p.eventType != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> { tag = p.name; if (tag == "item") { inItem = true; title = ""; link = ""; src = ""; date = "" } }
                XmlPullParser.TEXT -> if (inItem) when (tag) { "title" -> title += p.text; "link" -> link += p.text; "source" -> src += p.text; "pubDate" -> date += p.text }
                XmlPullParser.END_TAG -> { if (p.name == "item") { inItem = false; out += News(title.substringBeforeLast(" - ").trim(), link.trim(), src.trim(), runCatching { java.time.ZonedDateTime.parse(date.trim(), DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() }.getOrDefault(0L)) }; tag = "" }
            }
            p.next()
        }
        out.take(40)
    }.getOrDefault(emptyList())

    // ---------------- روابط ----------------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    fun highlightsSearch(m: Match) = "https://m.youtube.com/results?search_query=" + enc(tr("ملخص مباراة ", "highlights ") + m.home + " " + m.away + " " + m.date.year)
    fun goalsSearch(m: Match) = "https://m.youtube.com/results?search_query=" + enc(tr("أهداف مباراة ", "goals ") + m.home + " " + m.away + " " + m.date)
    fun whereToWatch(m: Match) = "https://www.google.com/search?q=" + enc(tr("القناة الناقلة لمباراة ", "where to watch ") + m.home + " " + m.away + " " + m.date)

    /** منصات رسمية مقترحة (يفتحها المستخدم؛ لا تُبث أي مباراة بدون ترخيص) */
    data class Platform(val name: String, val pkg: String, val url: String)
    val platforms = listOf(
        Platform("beIN CONNECT", "com.bein.beIN", "https://connect.bein.com"),
        Platform("Shahid", "net.mbc.shahid", "https://shahid.mbc.net"),
        Platform("STC tv", "com.stc.tv", "https://www.stctv.com"),
        Platform("TOD", "com.beinmedia.tod", "https://www.tod.tv"),
        Platform("Yango Play", "com.yango.play", "https://play.yango.com"),
        Platform("ON / Watch iT", "com.watchit.vod", "https://www.watchit.com")
    )
    /** روابط بث قانونية أضافها المستخدم */
    data class UserStream(val name: String, val url: String)
    fun userStreams(): List<UserStream> = runCatching { JSONArray(Extras.s("fb_streams", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> UserStream(o.getString("n"), o.getString("u")) } } } }.getOrDefault(emptyList())
    fun saveUserStreams(l: List<UserStream>) = Extras.ps("fb_streams", JSONArray(l.map { JSONObject().put("n", it.name).put("u", it.url) }).toString())

    fun localTime(t: Long): String = Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
    fun relDay(d: LocalDate): String { val t = LocalDate.now(); return when (d) { t -> tr("اليوم", "Today"); t.plusDays(1) -> tr("غداً", "Tomorrow"); t.minusDays(1) -> tr("أمس", "Yesterday"); else -> Fmt.date(d.toEpochDay()) } }
    fun leagueOf(id: String) = leagues().firstOrNull { it.id == id } ?: defaults.firstOrNull { it.id == id }
}
