@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.data.Person
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

// ============================ قائمة الجمعيات ============================
@Composable
fun AssocListScreen(nav: NavController) {
    val dao = remember { appDao() }
    val assocs by flowState(emptyList<Association>()) { dao.associationsFlow() }
    val members by flowState(emptyList<AssocMember>()) { dao.allMembersFlow() }
    val pays by flowState(emptyList<AssocPayment>()) { dao.allAssocPaymentsFlow() }
    val payouts by flowState(emptyList<AssocPayout>()) { dao.allPayoutsFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val pmap = remember(people) { people.associateBy { it.id } }
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    val today = remember { LocalDate.now() }

    ScreenScaffold(
        title = tr("الجمعيات", "Associations"),
        fab = {
            ExtendedFloatingActionButton(
                onClick = { nav.navigate("assoc_edit/0") },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(tr("جمعية جديدة", "New association")) }
            )
        }
    ) { pad ->
        val rows = assocs.map { a ->
            a to associationRounds(
                a, members.filter { it.associationId == a.id },
                pays.filter { it.associationId == a.id }, payouts.filter { it.associationId == a.id }
            )
        }.filter { (a, r) ->
            (q.isBlank() || a.name.contains(q, true)) && when (filter) {
                1 -> !assocFinished(r)
                2 -> assocFinished(r)
                else -> true
            }
        }
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SearchField(q) { q = it } }
            item { FilterRow(listOf(tr("الكل", "All"), tr("نشطة", "Active"), tr("منتهية", "Finished")), filter) { filter = it } }
            if (rows.isEmpty()) item {
                EmptyState(Icons.Filled.Groups, tr("لا توجد جمعيات. اضغط \"جمعية جديدة\" للبدء.", "No associations yet. Tap \"New association\" to start."))
            }
            items(rows, key = { it.first.id }) { (a, r) ->
                AssocCard(a, r, pmap, today) { nav.navigate("assoc/${a.id}") }
            }
        }
    }
}

@Composable
private fun AssocCard(a: Association, rounds: List<RoundInfo>, people: Map<Long, Person>, today: LocalDate, onClick: () -> Unit) {
    val n = rounds.size
    val done = rounds.count { it.payout != null }
    val current = rounds.firstOrNull { it.payout == null }
    val finished = assocFinished(rounds)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconCircle(Icons.Filled.Groups, MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${Fmt.money(a.shareAmount)} • ${Fmt.periodLabel(a.periodType, a.periodCount)} • ${tr("$n أعضاء", "$n members")}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (finished) StatusChip(tr("منتهية", "Finished"), SuccessGreen)
                else StatusChip(tr("نشطة", "Active"), MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { if (n == 0) 0f else done.toFloat() / n },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp))
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Text(tr("الدورات المسلّمة: $done/$n", "Delivered: $done/$n"), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                Text(tr("القبضة: ", "Payout: ") + Fmt.money(a.shareAmount * n), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            }
            if (current != null) {
                val late = current.due.isBefore(today)
                Text(
                    tr("الدورة الحالية ${current.round + 1}: ", "Current round ${current.round + 1}: ") +
                        (people[current.recipient.personId]?.name ?: "-") + " • " + Fmt.date(current.due),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (late) DangerRed else MaterialTheme.colorScheme.primary,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ============================ إضافة / تعديل جمعية ============================
private data class EditMember(val memberId: Long, val person: Person)

@Composable
fun AssocEditScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    var existing by remember { mutableStateOf<Association?>(null) }
    var name by remember { mutableStateOf("") }
    var share by remember { mutableStateOf("") }
    var ptype by remember { mutableStateOf(Period.MONTH) }
    var pcount by remember { mutableStateOf("1") }
    var start by remember { mutableLongStateOf(Fmt.today()) }
    var notes by remember { mutableStateOf("") }
    var reminder by remember { mutableStateOf(true) }
    val members = remember { mutableStateListOf<EditMember>() }
    var showPicker by remember { mutableStateOf(false) }
    var removeTarget by remember { mutableStateOf<EditMember?>(null) }
    var loaded by remember { mutableStateOf(id == 0L) }

    LaunchedEffect(id) {
        if (id != 0L) {
            val a = dao.association(id)
            if (a != null) {
                existing = a
                name = a.name; share = Fmt.plain(a.shareAmount); ptype = a.periodType
                pcount = a.periodCount.toString(); start = a.startDate; notes = a.notes; reminder = a.reminderEnabled
                members.clear()
                dao.members(id).forEach { m -> dao.person(m.personId)?.let { members.add(EditMember(m.id, it)) } }
            }
            loaded = true
        }
    }

    fun save() {
        val s = Fmt.parse(share)
        val c = Fmt.parseInt(pcount)
        when {
            name.isBlank() -> { toast(ctx, tr("أدخل اسم الجمعية", "Enter association name")); return }
            s == null || s <= 0 -> { toast(ctx, tr("أدخل قيمة السهم", "Enter the share amount")); return }
            c == null || c < 1 -> { toast(ctx, tr("أدخل مدة صحيحة", "Enter a valid period")); return }
            members.size < 2 -> { toast(ctx, tr("أضف عضوين على الأقل", "Add at least two members")); return }
        }
        scope.launch {
            val a = Association(
                id = id, name = name.trim(), shareAmount = s!!, periodType = ptype, periodCount = c!!,
                startDate = start, notes = notes.trim(), reminderEnabled = reminder,
                createdAt = existing?.createdAt ?: System.currentTimeMillis()
            )
            val aid = if (id == 0L) dao.insertAssociation(a) else { dao.updateAssociation(a); id }
            val keep = members.filter { it.memberId != 0L }.map { it.memberId }.toSet()
            dao.members(aid).filter { it.id !in keep }.forEach { dao.removeMember(it.id) }
            members.forEachIndexed { i, m ->
                if (m.memberId == 0L) dao.insertMember(AssocMember(associationId = aid, personId = m.person.id, turnOrder = i))
                else dao.updateMember(AssocMember(id = m.memberId, associationId = aid, personId = m.person.id, turnOrder = i))
            }
            toast(ctx, tr("تم الحفظ", "Saved"))
            nav.popBackStack()
            if (id == 0L) nav.navigate("assoc/$aid")
        }
    }

    ScreenScaffold(
        title = if (id == 0L) tr("جمعية جديدة", "New association") else tr("تعديل الجمعية", "Edit association"),
        onBack = { nav.popBackStack() },
        actions = { TextButton(onClick = { save() }) { Text(tr("حفظ", "Save"), fontWeight = FontWeight.Bold) } }
    ) { pad ->
        if (!loaded) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@ScreenScaffold
        }
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(name, { name = it }, label = { Text(tr("اسم الجمعية", "Association name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            MoneyField(share, { share = it }, tr("المبلغ الذي يدفعه كل عضو في الدورة", "Amount each member pays per round"))
            PeriodSelector(ptype, pcount, { ptype = it }, { pcount = it })
            DateField(tr("تاريخ الدورة الأولى", "First round date"), start, { d -> if (d != null) start = d })
            val sv = Fmt.parse(share) ?: 0.0
            if (members.isNotEmpty() && sv > 0) {
                InfoBanner(
                    tr(
                        "قيمة القبضة لكل دورة: ${Fmt.money(sv * members.size)} • عدد الدورات: ${members.size} • آخر دورة: ${Fmt.date(dueDate(start, ptype, Fmt.parseInt(pcount) ?: 1, members.size - 1))}",
                        "Payout per round: ${Fmt.money(sv * members.size)} • Rounds: ${members.size} • Last round: ${Fmt.date(dueDate(start, ptype, Fmt.parseInt(pcount) ?: 1, members.size - 1))}"
                    ),
                    MaterialTheme.colorScheme.primary
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(tr("الأعضاء وترتيب الاستلام (${members.size})", "Members & payout order (${members.size})"), Modifier.weight(1f))
                if (members.size > 1) TextButton(onClick = {
                    val shuffled = members.shuffled()
                    members.clear(); members.addAll(shuffled)
                    toast(ctx, tr("تم ترتيب الأعضاء بالقرعة 🎲", "Order drawn randomly 🎲"))
                }) {
                    Icon(Icons.Filled.Casino, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(tr("قرعة", "Draw"))
                }
            }
            OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.PersonAdd, null); Spacer(Modifier.width(8.dp))
                Text(tr("إضافة أعضاء (يدوي / جهات الاتصال)", "Add members (manual / contacts)"))
            }
            members.forEachIndexed { i, m ->
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.width(26.dp))
                        PersonRow(m.person.name, m.person.phone, m.person.photoPath, Modifier.weight(1f))
                        IconButton(onClick = { if (i > 0) { val t = members[i - 1]; members[i - 1] = m; members[i] = t } }, enabled = i > 0) {
                            Icon(Icons.Filled.KeyboardArrowUp, null)
                        }
                        IconButton(onClick = { if (i < members.size - 1) { val t = members[i + 1]; members[i + 1] = m; members[i] = t } }, enabled = i < members.size - 1) {
                            Icon(Icons.Filled.KeyboardArrowDown, null)
                        }
                        IconButton(onClick = { if (m.memberId == 0L) { members.remove(m) } else { removeTarget = m } }) {
                            Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            SwitchRow(tr("تنبيهات المواعيد", "Due reminders"), tr("تنبيه قبل موعد كل دورة", "Notify before each round"), reminder, Icons.Filled.Notifications) { reminder = it }
            NotesField(notes) { notes = it }
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(tr("حفظ الجمعية", "Save association")) }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showPicker) PersonPickerDialog(
        multi = true, exclude = members.map { it.person.id }.toSet(),
        onDismiss = { showPicker = false }
    ) { list ->
        showPicker = false
        list.forEach { p -> if (members.none { it.person.id == p.id }) members.add(EditMember(0L, p)) }
    }
    removeTarget?.let { m ->
        ConfirmDialog(
            title = tr("حذف العضو", "Remove member"),
            text = tr("سيتم حذف ${m.person.name} وكل دفعاته في هذه الجمعية عند الحفظ.", "${m.person.name} and all their payments in this association will be removed on save."),
            onDismiss = { removeTarget = null }
        ) { members.remove(m) }
    }
}

// ============================ تفاصيل الجمعية ============================
@Composable
fun AssocDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val assoc by flowState<Association?>(null, id) { dao.associationFlow(id) }
    val members by flowState(emptyList<AssocMember>(), id) { dao.membersFlow(id) }
    val payments by flowState(emptyList<AssocPayment>(), id) { dao.assocPaymentsFlow(id) }
    val payouts by flowState(emptyList<AssocPayout>(), id) { dao.payoutsFlow(id) }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val pmap = remember(people) { people.associateBy { it.id } }
    var tab by remember { mutableIntStateOf(0) }
    var confirmDelete by remember { mutableStateOf(false) }
    var unpayTarget by remember { mutableStateOf<Pair<AssocMember, Int>?>(null) }
    var expanded by remember { mutableIntStateOf(-2) }
    val today = remember { LocalDate.now() }

    val a = assoc
    if (a == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val rounds = remember(a, members, payments, payouts) { associationRounds(a, members, payments, payouts) }
    val currentIdx = rounds.indexOfFirst { it.payout == null }
    LaunchedEffect(currentIdx, rounds.size) { if (expanded == -2 && rounds.isNotEmpty()) expanded = currentIdx }
    if (expanded == -2 && rounds.isNotEmpty()) expanded = currentIdx

    ScreenScaffold(
        title = a.name,
        onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(null, doc = { Docs.association(a, members, pmap, payments, payouts) }) { c -> Reports.association(c, a, members, pmap, payments, payouts) }
            IconButton(onClick = { nav.navigate("assoc_edit/${a.id}") }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, null) }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        val done = rounds.count { it.payout != null }
                        Text(tr("قيمة القبضة", "Payout per round"), color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(Fmt.money(a.shareAmount * members.size), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { if (rounds.isEmpty()) 0f else done.toFloat() / rounds.size },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(Modifier.height(10.dp))
                        KeyValue(tr("السهم", "Share"), Fmt.money(a.shareAmount))
                        KeyValue(tr("المدة", "Period"), Fmt.periodLabel(a.periodType, a.periodCount))
                        KeyValue(tr("الأعضاء / الدورات", "Members / rounds"), "${members.size}")
                        KeyValue(tr("من - إلى", "From - to"), Fmt.date(a.startDate) + "  ←  " + (rounds.lastOrNull()?.let { Fmt.date(it.due) } ?: "-"))
                        KeyValue(tr("الدورات المسلّمة", "Delivered"), "$done/${rounds.size}")
                        KeyValue(tr("إجمالي المحصّل", "Total collected"), Fmt.money(payments.sumOf { it.amount }))
                    }
                }
            }
            if (a.notes.isNotBlank()) item { InfoBanner(a.notes) }
            item {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(tr("الدورات", "Rounds")) })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(tr("الأعضاء", "Members")) })
                }
            }
            if (members.isEmpty()) item {
                EmptyState(Icons.Filled.Groups, tr("لا يوجد أعضاء. عدّل الجمعية لإضافة أعضاء.", "No members. Edit the association to add some."))
            }
            if (tab == 0) {
                itemsIndexed(rounds, key = { _, r -> "r${r.round}" }) { i, r ->
                    RoundCard(
                        a, r, members, pmap, today, payments.filter { it.round == r.round },
                        isCurrent = i == currentIdx,
                        expanded = expanded == i,
                        onToggleExpand = { expanded = if (expanded == i) -1 else i },
                        onTogglePaid = { m ->
                            if (m.id in r.paidMemberIds) {
                                unpayTarget = m to r.round
                            } else {
                                scope.launch {
                                    dao.insertAssocPayment(AssocPayment(associationId = a.id, memberId = m.id, round = r.round, amount = a.shareAmount, date = Fmt.today()))
                                }
                            }
                        },
                        onPayAll = {
                            scope.launch {
                                members.filter { it.id !in r.paidMemberIds }.forEach { m ->
                                    dao.insertAssocPayment(AssocPayment(associationId = a.id, memberId = m.id, round = r.round, amount = a.shareAmount, date = Fmt.today()))
                                }
                            }
                        },
                        onDeliver = {
                            scope.launch {
                                if (r.payout == null) {
                                    dao.insertPayout(AssocPayout(associationId = a.id, round = r.round, memberId = r.recipient.id, amount = r.collected, date = Fmt.today()))
                                    toast(ctx, tr("تم تسجيل التسليم ✅", "Delivery recorded ✅"))
                                } else {
                                    Attachments.deleteFor(Attachments.ASSOC_PAYOUT, r.payout.id)
                                    dao.deletePayout(a.id, r.round)
                                }
                            }
                        },
                        onRemind = { m ->
                            val p = pmap[m.personId]
                            if (p != null) Share.whatsappMessage(ctx, p.phone, Messages.assocShare(p.name, a.name, r.round + 1, a.shareAmount, Fmt.date(r.due)))
                        }
                    )
                }
            } else {
                items(members.sortedBy { it.turnOrder }, key = { it.id }) { m ->
                    MemberCard(a, m, members, rounds, payments, payouts, pmap, today)
                }
            }
        }
    }

    if (confirmDelete) ConfirmDialog(
        title = tr("حذف الجمعية", "Delete association"),
        text = tr("سيتم حذف الجمعية وكل الدفعات المسجلة نهائياً.", "The association and all its payments will be permanently deleted."),
        confirmText = tr("حذف", "Delete"),
        onDismiss = { confirmDelete = false }
    ) {
        scope.launch { dao.deleteAssociationFull(a.id); nav.popBackStack() }
    }
    unpayTarget?.let { (m, round) ->
        ConfirmDialog(
            title = tr("إلغاء الدفعة", "Undo payment"),
            text = tr("إلغاء تسجيل دفعة ${pmap[m.personId]?.name ?: ""} للدورة ${round + 1}؟", "Undo ${pmap[m.personId]?.name ?: ""}'s payment for round ${round + 1}?"),
            onDismiss = { unpayTarget = null }
        ) {
            scope.launch {
                payments.filter { it.memberId == m.id && it.round == round }.forEach { Attachments.deleteFor(Attachments.ASSOC_PAY, it.id) }
                dao.deleteAssocPayment(a.id, m.id, round)
            }
        }
    }
}

@Composable
private fun RoundCard(
    a: Association, r: RoundInfo, members: List<AssocMember>, pmap: Map<Long, Person>, today: LocalDate,
    roundPayments: List<AssocPayment>,
    isCurrent: Boolean, expanded: Boolean, onToggleExpand: () -> Unit, onTogglePaid: (AssocMember) -> Unit,
    onPayAll: () -> Unit, onDeliver: () -> Unit, onRemind: (AssocMember) -> Unit
) {
    val recipient = pmap[r.recipient.personId]
    val late = r.due.isBefore(today) && !r.allPaid
    val (statusText, statusColor) = when {
        r.payout != null -> tr("تم التسليم", "Delivered") to SuccessGreen
        r.allPaid -> tr("مكتملة", "Complete") to MaterialTheme.colorScheme.tertiary
        late -> tr("متأخرة", "Late") to DangerRed
        isCurrent -> tr("الحالية", "Current") to MaterialTheme.colorScheme.secondary
        else -> tr("قادمة", "Upcoming") to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onToggleExpand).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    IconCircle(Icons.Filled.Event, statusColor, 40.dp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr("الدورة ${r.round + 1}", "Round ${r.round + 1}") + " • " + Fmt.date(r.due), fontWeight = FontWeight.Bold)
                    Text(tr("المستلم: ", "Recipient: ") + (recipient?.name ?: "-"), style = MaterialTheme.typography.bodySmall)
                    Text(
                        "${r.paidMemberIds.size}/${members.size} • ${Fmt.money(r.collected)}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatusChip(statusText, statusColor)
                Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null)
            }
            AnimatedVisibility(expanded) {
                Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)) {
                    HorizontalDivider()
                    members.sortedBy { it.turnOrder }.forEach { m ->
                        val p = pmap[m.personId]
                        val paid = m.id in r.paidMemberIds
                        Row(
                            Modifier.fillMaxWidth().clickable { onTogglePaid(m) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (paid) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked, null,
                                tint = if (paid) SuccessGreen else MaterialTheme.colorScheme.outline
                            )
                            Spacer(Modifier.width(10.dp))
                            Avatar(p?.photoPath, p?.name ?: "?", 32.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p?.name ?: "-", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (paid) tr("مدفوع", "Paid") else tr("لم يدفع", "Unpaid"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (paid) SuccessGreen else if (r.due.isBefore(today)) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            val payRow = roundPayments.firstOrNull { it.memberId == m.id }
                            if (payRow != null) AttachmentButton(Attachments.ASSOC_PAY, payRow.id, p?.phone)
                            if (!paid && !p?.phone.isNullOrBlank()) {
                                IconButton(onClick = { onRemind(m) }) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (r.paidMemberIds.size < members.size) {
                            OutlinedButton(onClick = onPayAll, modifier = Modifier.weight(1f)) { Text(tr("الكل دفع", "All paid"), maxLines = 1) }
                        }
                        if (r.payout == null) {
                            Button(onClick = onDeliver, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Filled.Payments, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                                Text(tr("تسليم القبضة", "Deliver payout"), maxLines = 1)
                            }
                        } else {
                            AttachmentButton(Attachments.ASSOC_PAYOUT, r.payout.id, pmap[r.recipient.personId]?.phone)
                            OutlinedButton(onClick = onDeliver, modifier = Modifier.weight(1f)) {
                                Text(tr("إلغاء التسليم (${Fmt.date(r.payout.date)})", "Undo delivery (${Fmt.date(r.payout.date)})"), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MemberCard(
    a: Association, m: AssocMember, members: List<AssocMember>, rounds: List<RoundInfo>,
    payments: List<AssocPayment>, payouts: List<AssocPayout>, pmap: Map<Long, Person>, today: LocalDate
) {
    val ctx = LocalContext.current
    val p = pmap[m.personId]
    val myRound = rounds.firstOrNull { it.recipient.id == m.id }
    val paidCount = payments.count { it.memberId == m.id }
    val late = rounds.count { r -> !r.due.isAfter(today) && m.id !in r.paidMemberIds }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            PersonRow(p?.name ?: "-", p?.phone ?: "", p?.photoPath) {
                PdfShareButton(p?.phone, doc = { Docs.member(a, m, members, pmap, payments, payouts) }) { c -> Reports.member(c, a, m, members, pmap, payments, payouts) }
                if (!p?.phone.isNullOrBlank()) {
                    IconButton(onClick = {
                        val pp = p!!
                        val msg = if (myRound != null) Messages.assocTurn(pp.name, a.name, myRound.round + 1, a.shareAmount * members.size, Fmt.date(myRound.due))
                        else tr("السلام عليكم ${pp.name}", "Hello ${pp.name}")
                        Share.whatsappMessage(ctx, pp.phone, msg)
                    }) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                }
            }
            Spacer(Modifier.height(8.dp))
            KeyValue(tr("دوره في الاستلام", "Payout turn"), myRound?.let { "${it.round + 1} • ${Fmt.date(it.due)}" } ?: "-")
            KeyValue(tr("الدفعات", "Payments"), "$paidCount/${rounds.size} • ${Fmt.money(paidCount * a.shareAmount)}")
            KeyValue(
                tr("الاستلام", "Received"),
                myRound?.payout?.let { tr("تم ", "Yes ") + Fmt.date(it.date) } ?: tr("لم يستلم بعد", "Not yet"),
                if (myRound?.payout != null) SuccessGreen else MaterialTheme.colorScheme.onSurface
            )
            if (late > 0) KeyValue(tr("دورات متأخرة", "Late rounds"), "$late", DangerRed)
        }
    }
}
