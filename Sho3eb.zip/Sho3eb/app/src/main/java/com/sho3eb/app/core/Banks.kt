package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import com.sho3eb.app.data.Account

/** الحسابات البنكية والبطاقات: أنواع الحسابات، إخفاء الأرقام، فتح تطبيق البنك للدفع */
object Banks {
    const val CASH = "CASH"; const val BANK = "BANK"; const val CARD = "CARD"; const val WALLET = "WALLET"

    val kinds = listOf(
        Opt(CASH, "صندوق نقدي", "Cash box", "💵"),
        Opt(BANK, "حساب بنكي", "Bank account", "🏦"),
        Opt(CARD, "بطاقة ائتمان/مدى", "Card", "💳"),
        Opt(WALLET, "محفظة إلكترونية", "e-Wallet", "📱")
    )
    fun kind(k: String) = kinds.firstOrNull { it.key == k } ?: kinds.first()
    fun emoji(a: Account) = kind(a.kind).emoji

    /** بنوك ومحافظ شائعة في مصر والخليج (اقتراحات للكتابة) */
    val commonBanks = listOf(
        "البنك الأهلي المصري", "بنك مصر", "CIB", "بنك القاهرة", "QNB", "بنك الإسكندرية", "فوري", "فودافون كاش", "إنستاباي InstaPay",
        "الراجحي", "الأهلي SNB", "الإنماء", "الرياض", "البلاد", "STC Pay", "الإمارات دبي الوطني", "أبوظبي الأول", "بيت التمويل الكويتي", "QIB"
    )

    fun maskIban(s: String): String {
        val c = s.replace(" ", "")
        return if (c.length <= 8) c else c.take(4) + " •••• •••• " + c.takeLast(4)
    }

    fun digits4(s: String) = s.filter { it.isDigit() }.takeLast(4)

    /** تنسيق تاريخ انتهاء البطاقة MM/YY */
    fun expiry(s: String): String {
        val d = s.filter { it.isDigit() }.take(4)
        return if (d.length > 2) d.take(2) + "/" + d.drop(2) else d
    }

    fun isExpired(exp: String): Boolean {
        val d = exp.filter { it.isDigit() }
        if (d.length != 4) return false
        val m = d.take(2).toIntOrNull() ?: return false
        val y = 2000 + (d.drop(2).toIntOrNull() ?: return false)
        val now = java.time.YearMonth.now()
        return java.time.YearMonth.of(y, m.coerceIn(1, 12)).isBefore(now)
    }

    fun subtitle(a: Account): String = listOfNotNull(
        a.bank.takeIf { it.isNotBlank() },
        a.cardLast4.takeIf { it.isNotBlank() }?.let { "•••• $it" },
        a.cardExpiry.takeIf { it.isNotBlank() }?.let { tr("ينتهي ", "exp ") + it },
        a.iban.takeIf { it.isNotBlank() && a.cardLast4.isBlank() }?.let { maskIban(it) }
    ).joinToString(" • ")

    fun canPay(a: Account) = a.payApp.isNotBlank() || a.payLink.isNotBlank()

    /** فتح تطبيق البنك أو رابط الدفع. لا يتم أي دفع داخل التطبيق ولا تُحفظ بيانات البطاقة الكاملة. */
    fun pay(ctx: Context, a: Account): Boolean {
        if (a.payApp.isNotBlank()) {
            val i = ctx.packageManager.getLaunchIntentForPackage(a.payApp)
            if (i != null) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true }
        }
        if (a.payLink.isNotBlank()) {
            val url = if (a.payLink.startsWith("http")) a.payLink else "https://" + a.payLink
            return runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)
        }
        if (a.payApp.isNotBlank()) runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + a.payApp)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        }
        return false
    }

    data class App(val pkg: String, val label: String, val icon: Drawable?)

    private val bankHints = listOf("bank", "pay", "wallet", "cash", "rajhi", "alahli", "snb", "inma", "riyad", "bilad", "nbe", "banque", "misr", "cib", "qnb", "fawry",
        "vodafone", "instapay", "stc", "emirates", "enbd", "adcb", "fab", "kfh", "qib", "mada", "visa", "master", "tabby", "tamara", "valu", "meeza", "urpay", "barq")

    /** التطبيقات المثبتة (تطبيقات البنوك والمحافظ أولاً) */
    fun installedApps(ctx: Context): List<App> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return runCatching {
            pm.queryIntentActivities(i, 0).map { r -> App(r.activityInfo.packageName, r.loadLabel(pm).toString(), runCatching { r.loadIcon(pm) }.getOrNull()) }
                .filter { it.pkg != ctx.packageName }.distinctBy { it.pkg }
                .sortedWith(compareBy({ a -> if (bankHints.any { h -> a.pkg.contains(h, true) || a.label.contains(h, true) }) 0 else 1 }, { it.label }))
        }.getOrDefault(emptyList())
    }

    fun appLabel(ctx: Context, pkg: String): String = runCatching {
        val pm = ctx.packageManager; pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)
}
