@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.UserRecipe
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun rememberAllRecipes(): List<Food.Recipe> {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val users by flowState(emptyList<UserRecipe>()) { dao.userRecipesFlow() }
    val builtIn = remember { Food.recipes(ctx) }
    return remember(users, builtIn) { users.map { Food.fromUser(it) } + builtIn }
}

@Composable
fun RecipesScreen(nav: NavController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var addRecipe by remember { mutableStateOf(false) }
    ScreenScaffold(
        title = tr("الوصفات والمطبخ", "Recipes & kitchen"), onBack = { nav.popBackStack() },
        actions = { IconButton(onClick = { nav.navigate("diabetes") }) { Icon(Icons.Filled.Bloodtype, contentDescription = tr("السكري", "Diabetes"), tint = DangerRed) } },
        fab = { if (tab == 0) ExtendedFloatingActionButton(onClick = { addRecipe = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("وصفتي", "My recipe")) }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(tab, edgePadding = 8.dp) {
                listOf(tr("الوصفات", "Recipes"), tr("ماذا أطبخ؟", "What to cook?"), tr("الخضار والفاكهة", "Produce"), tr("أجهزة المطبخ", "Appliances")).forEachIndexed { i, t ->
                    Tab(tab == i, { tab = i }, text = { Text(t) })
                }
            }
            when (tab) {
                0 -> RecipeListTab(nav)
                1 -> SuggestTab(nav)
                2 -> ProduceTab()
                else -> AppliancesTab(nav)
            }
        }
    }
    if (addRecipe) UserRecipeDialog(null, null) { addRecipe = false }
}

@Composable
private fun RecipeListTab(nav: NavController) {
    val all = rememberAllRecipes()
    var cuisine by rememberSaveable { mutableStateOf("ALL") }
    var meal by rememberSaveable { mutableStateOf("ALL") }
    var sort by rememberSaveable { mutableIntStateOf(0) }
    var diabOnly by rememberSaveable { mutableStateOf(false) }
    var maxKcal by rememberSaveable { mutableStateOf(0) }
    var q by rememberSaveable { mutableStateOf("") }
    var online by remember { mutableStateOf<String?>(null) }
    val list = Food.searchRecipes(all, q).filter { r ->
        (cuisine == "ALL" || r.cuisine == cuisine) && (meal == "ALL" || r.meal == meal) && (!diabOnly || r.diab == "G") && (maxKcal == 0 || r.kcal <= maxKcal)
    }.let { l ->
        when (sort) {
            1 -> l.sortedBy { it.kcal }; 2 -> l.sortedByDescending { it.kcal }; 3 -> l.sortedBy { it.minutes }
            4 -> l.sortedByDescending { it.protein }; 5 -> l.sortedBy { it.carbs }
            else -> l.sortedWith(compareBy({ Food.meals.indexOfFirst { m -> m.key == it.meal } }, { it.kcal }))
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { SearchField(q) { q = it } }
                MicButton { q = it }
            }
        }
        item { HChips { Food.cuisines.forEach { c -> FilterChip(cuisine == c.key, { cuisine = c.key }, label = { Text(c.emoji + " " + c.label) }) } } }
        item { HChips { Food.meals.forEach { m -> FilterChip(meal == m.key, { meal = m.key }, label = { Text(m.emoji + " " + m.label) }) } } }
        item {
            HChips {
                listOf(tr("حسب الوجبة", "By meal"), tr("الأقل سعرات", "Lowest kcal"), tr("الأعلى سعرات", "Highest kcal"), tr("الأسرع", "Quickest"), tr("الأعلى بروتيناً", "Most protein"), tr("الأقل نشويات", "Fewest carbs")).forEachIndexed { i, t ->
                    FilterChip(sort == i, { sort = i }, label = { Text(t) })
                }
            }
        }
        item {
            HChips {
                FilterChip(diabOnly, { diabOnly = !diabOnly }, label = { Text(tr("🟢 مناسبة للسكري", "🟢 Diabetes-friendly")) })
                listOf(0 to tr("أي سعرات", "Any kcal"), 300 to "≤ 300", 450 to "≤ 450", 600 to "≤ 600").forEach { (v, l) -> FilterChip(maxKcal == v, { maxKcal = v }, label = { Text(l) }) }
            }
        }
        item { Text(tr("${list.size} وصفة • السعرات والقيم الغذائية للحصة الواحدة وتقريبية", "${list.size} recipes • nutrition per serving, approximate"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (list.isEmpty()) item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr("لم أجد «$q» في الوصفات", "\"$q\" not found"), fontWeight = FontWeight.Bold)
                    Text(tr("ابحث عنها أونلاين أو شاهد فيديو، ثم أضفها لوصفاتك.", "Search online or watch a video, then add it to your recipes."), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (q.isNotBlank()) Button(onClick = { online = q }) { Icon(Icons.Filled.TravelExplore, null); Spacer(Modifier.width(4.dp)); Text(tr("بحث أونلاين", "Search online")) }
                        val ctx = LocalContext.current
                        if (q.isNotBlank()) OutlinedButton(onClick = { Share.openUrl(ctx, Food.youtube(q)) }) { Icon(Icons.Filled.PlayCircle, null, tint = DangerRed); Spacer(Modifier.width(4.dp)); Text(tr("فيديو", "Video")) }
                    }
                }
            }
        }
        var lastMeal = ""
        list.forEach { r ->
            if (sort == 0 && r.meal != lastMeal) { lastMeal = r.meal; val m = Food.meal(r.meal); item(key = "h_" + r.meal) { SectionTitle(m.emoji + " " + m.label) } }
            item(key = r.id) { RecipeCard(r) { nav.navigate("recipe/${r.id}") } }
        }
        if (list.isNotEmpty() && q.isNotBlank()) item { TextButton(onClick = { online = q }) { Text(tr("🔎 ابحث عن «$q» أونلاين أيضاً", "🔎 Also search \"$q\" online")) } }
    }
    online?.let { s -> OnlineRecipeDialog(s) { online = null } }
}

@Composable
fun RecipeCard(r: Food.Recipe, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (r.cuisine == "MINE") "⭐" else Food.meal(r.meal).emoji, fontSize = 28.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Food.diabEmoji(r.diab) + " " + (if (r.minutes > 0) "⏱️ ${r.minutes} " + tr("د", "min") + " • " else "") + tr("نشويات ", "carbs ") + Fmt.num(r.carbs) + tr("جم • بروتين ", "g • protein ") + Fmt.num(r.protein) + tr("جم", "g"),
                    style = MaterialTheme.typography.bodySmall, maxLines = 1)
                val price = listOfNotNull(r.priceEG.takeIf { it.isNotBlank() && it != "—" }?.let { "🇪🇬 $it " + tr("ج", "EGP") }, r.priceGulf.takeIf { it.isNotBlank() && it != "—" }?.let { "🇸🇦 $it " + tr("ر.س", "SAR") }).joinToString("  ")
                if (price.isNotBlank()) Text(tr("مطعم: ", "Restaurant: ") + price, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${r.kcal}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = when { r.kcal <= 300 -> SuccessGreen; r.kcal <= 500 -> WarnAmber; else -> DangerRed })
                Text(tr("سعرة", "kcal"), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun scaleQty(q: String, f: Double): String {
    val v = when {
        q.contains('/') -> q.split('/').let { (a, b) -> (a.trim().toDoubleOrNull() ?: return q) / (b.trim().toDoubleOrNull() ?: return q) }
        else -> q.trim().toDoubleOrNull() ?: return q
    }
    val x = v * f
    return when {
        x >= 10 -> Fmt.num(x.roundToInt().toDouble())
        kotlin.math.abs(x - 0.25) < 0.02 -> "¼"; kotlin.math.abs(x - 0.5) < 0.02 -> "½"; kotlin.math.abs(x - 0.75) < 0.02 -> "¾"
        kotlin.math.abs(x - 1.0 / 3) < 0.02 -> "⅓"
        else -> Fmt.num((x * 4).roundToInt() / 4.0)
    }
}

@Composable
fun RecipeScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val all = rememberAllRecipes()
    val r = all.firstOrNull { it.id == id }
    var people by rememberSaveable { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    val users by flowState(emptyList<UserRecipe>()) { dao.userRecipesFlow() }
    if (r == null) { ScreenScaffold(tr("الوصفة", "Recipe"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad)) {} }; return }
    val serv = if (people > 0) people else r.servings
    val f = serv.toDouble() / r.servings.coerceAtLeast(1)
    val u = r.userId?.let { uid -> users.firstOrNull { it.id == uid } }
    fun shareTxt() = buildString {
        append("🍽️ ").append(r.name).append("\n").append(tr("لـ $serv أشخاص", "Serves $serv")).append(" • ").append(r.kcal).append(tr(" سعرة للحصة", " kcal/serving")).append("\n\n")
        append(tr("المكونات:\n", "Ingredients:\n")); r.ing.forEach { append("• ").append(listOf(scaleQty(it.q, f), it.u, it.n).filter { s -> s.isNotBlank() }.joinToString(" ")).append("\n") }
        append(tr("\nالطريقة:\n", "\nMethod:\n")); r.steps.forEachIndexed { i, s -> append(i + 1).append(") ").append(s).append("\n") }
    }
    ScreenScaffold(
        title = r.name, onBack = { nav.popBackStack() },
        actions = {
            IconButton(onClick = { Share.shareText(ctx, shareTxt()) }) { Icon(Icons.Filled.Share, null) }
            if (u != null) {
                IconButton(onClick = { scope.launch { dao.updateUserRecipe(u.copy(favorite = !u.favorite)) } }) { Icon(if (u.favorite) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = WarnAmber) }
                IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, null) }
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(Food.meal(r.meal).emoji + " " + Food.meal(r.meal).label + " • " + (Food.cuisines.firstOrNull { it.key == r.cuisine }?.label ?: "") + (if (r.minutes > 0) " • ⏱️ ${r.minutes} " + tr("دقيقة", "min") else ""), style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                            NutBox("${r.kcal}", tr("سعرة", "kcal"))
                            NutBox(Fmt.num(r.carbs), tr("نشويات جم", "carbs g"))
                            NutBox(Fmt.num(r.protein), tr("بروتين جم", "protein g"))
                            NutBox(Fmt.num(r.fat), tr("دهون جم", "fat g"))
                        }
                        Text(tr("للحصة الواحدة • قيم تقريبية • ≈ ", "Per serving • approximate • ≈ ") + Fmt.num(r.carbServings) + tr(" حصة كربوهيدرات", " carb servings"), style = MaterialTheme.typography.labelSmall)
                        Text(Food.diabEmoji(r.diab) + " " + Food.diabLabel(r.diab), fontWeight = FontWeight.SemiBold, color = when (r.diab) { "G" -> SuccessGreen; "M" -> WarnAmber; else -> DangerRed })
                    }
                }
            }
            if (r.priceEG.isNotBlank() && r.priceEG != "—" || r.priceGulf.isNotBlank() && r.priceGulf != "—") item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(tr("💰 سعر الطبق في المطاعم (تقريبي)", "💰 Restaurant price (approx.)"), fontWeight = FontWeight.Bold)
                        if (r.priceEG.isNotBlank() && r.priceEG != "—") KeyValue(tr("🇪🇬 مصر", "🇪🇬 Egypt"), r.priceEG + tr(" جنيه", " EGP"))
                        if (r.priceGulf.isNotBlank() && r.priceGulf != "—") KeyValue(tr("🇸🇦 الخليج", "🇸🇦 Gulf"), r.priceGulf + tr(" ريال/درهم", " SAR/AED"))
                        Text(tr("تختلف حسب المطعم والمدينة؛ عمله في البيت أوفر عادةً.", "Varies by restaurant and city; homemade is usually cheaper."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("المكونات", "Ingredients"), fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { if (serv > 1) people = serv - 1 }) { Icon(Icons.Filled.Remove, null) }
                    Text(tr("$serv أشخاص", "$serv people"), fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { people = serv + 1 }) { Icon(Icons.Filled.Add, null) }
                }
            }
            items(r.ing) { i ->
                Row(Modifier.padding(horizontal = 4.dp)) {
                    Text("• ", color = MaterialTheme.colorScheme.primary)
                    Text(listOf(scaleQty(i.q, f), i.u, i.n).filter { it.isNotBlank() }.joinToString(" "))
                }
            }
            if (r.apps.isNotEmpty()) item { Text(tr("الأجهزة: ", "Appliances: ") + r.apps.joinToString("، ") { Food.applianceName(ctx, it) }, style = MaterialTheme.typography.bodySmall) }
            item { Text(tr("طريقة التحضير", "Method"), fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            items(r.steps.size) { i ->
                Row(Modifier.padding(horizontal = 4.dp)) {
                    Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.primary) { Text("${i + 1}", Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(8.dp))
                    Text(r.steps[i])
                }
            }
            if (r.benefits.isNotBlank()) item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.10f))) {
                    Column(Modifier.padding(12.dp)) { Text(tr("💚 الفوائد الصحية", "💚 Health benefits"), fontWeight = FontWeight.Bold, color = SuccessGreen); Text(r.benefits) }
                }
            }
            if (r.harms.isNotBlank()) item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.08f))) {
                    Column(Modifier.padding(12.dp)) { Text(tr("⚠️ الأضرار والتحذيرات", "⚠️ Cautions"), fontWeight = FontWeight.Bold, color = DangerRed); Text(r.harms) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { Share.openUrl(ctx, r.videoUrl.ifBlank { Food.youtube(r.ar) }) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.PlayCircle, null, tint = DangerRed); Spacer(Modifier.width(4.dp)); Text(if (r.videoUrl.isNotBlank()) tr("مشاهدة الفيديو", "Watch video") else tr("فيديوهات يوتيوب", "YouTube videos"))
                    }
                    if (u != null) OutlinedButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
                }
            }
        }
    }
    if (edit && u != null) UserRecipeDialog(u, null) { edit = false }
    if (del && u != null) ConfirmDialog(tr("حذف الوصفة", "Delete recipe"), u.name, onDismiss = { del = false }) { scope.launch { dao.deleteUserRecipe(u.id); nav.popBackStack() } }
}

@Composable
private fun NutBox(v: String, l: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(v, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
        Text(l, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun UserRecipeDialog(existing: UserRecipe?, prefill: Food.Online?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var name by remember { mutableStateOf(existing?.name ?: prefill?.name ?: "") }
    var meal by remember { mutableStateOf(existing?.meal ?: "LUNCH") }
    var ing by remember { mutableStateOf(existing?.ingredients ?: prefill?.ingredients?.joinToString("\n") ?: "") }
    var steps by remember { mutableStateOf(existing?.steps ?: prefill?.steps?.joinToString("\n") ?: "") }
    var servings by remember { mutableStateOf((existing?.servings ?: 4).toString()) }
    var minutes by remember { mutableStateOf(existing?.minutes?.takeIf { it > 0 }?.toString() ?: "") }
    var kcal by remember { mutableStateOf(existing?.calories?.takeIf { it > 0 }?.toString() ?: "") }
    var carbs by remember { mutableStateOf(existing?.carbs?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var prot by remember { mutableStateOf(existing?.protein?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var fat by remember { mutableStateOf(existing?.fat?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var video by remember { mutableStateOf(existing?.videoUrl ?: prefill?.video ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("إضافة وصفة", "Add recipe") else tr("تعديل الوصفة", "Edit recipe")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tr("اسم الأكلة", "Dish name")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), trailingIcon = { MicButton { name = it } })
                HChips { Food.meals.drop(1).forEach { m -> FilterChip(meal == m.key, { meal = m.key }, label = { Text(m.emoji + " " + m.label) }) } }
                OutlinedTextField(ing, { ing = it }, label = { Text(tr("المكونات (كل مكون في سطر)", "Ingredients (one per line)")) }, minLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(steps, { steps = it }, label = { Text(tr("الخطوات (كل خطوة في سطر)", "Steps (one per line)")) }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField(servings, { servings = it.filter { c -> c.isDigit() }.take(2) }, tr("أشخاص", "Serves"), Modifier.weight(1f))
                    NumberField(minutes, { minutes = it.filter { c -> c.isDigit() }.take(3) }, tr("دقائق", "Minutes"), Modifier.weight(1f))
                }
                Text(tr("القيم الغذائية للحصة (اختياري)", "Nutrition per serving (optional)"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NumberField(kcal, { kcal = it.filter { c -> c.isDigit() }.take(4) }, tr("سعرات", "kcal"), Modifier.weight(1f))
                    NumberField(carbs, { carbs = it }, tr("نشويات", "Carbs"), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NumberField(prot, { prot = it }, tr("بروتين", "Protein"), Modifier.weight(1f))
                    NumberField(fat, { fat = it }, tr("دهون", "Fat"), Modifier.weight(1f))
                }
                OutlinedTextField(video, { video = it.trim() }, label = { Text(tr("رابط فيديو (يوتيوب…)", "Video link (YouTube…)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (name.isNotBlank()) TextButton(onClick = { Share.openUrl(ctx, Food.youtube(name)) }) { Text(tr("🔎 ابحث عن فيديو «$name» في يوتيوب", "🔎 Find a video on YouTube")) }
                OutlinedTextField(notes, { notes = it }, label = { Text(tr("ملاحظات / فوائد", "Notes / benefits")) }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { toast(ctx, tr("أدخل اسم الأكلة", "Enter the dish name")); return@TextButton }
                val x = UserRecipe(name = name.trim(), meal = meal, ingredients = ing.trim(), steps = steps.trim(), servings = servings.toIntOrNull()?.coerceAtLeast(1) ?: 4,
                    minutes = minutes.toIntOrNull() ?: 0, calories = kcal.toIntOrNull() ?: 0, carbs = Fmt.parse(carbs) ?: 0.0, protein = Fmt.parse(prot) ?: 0.0, fat = Fmt.parse(fat) ?: 0.0,
                    videoUrl = video, notes = notes.trim(), favorite = existing?.favorite ?: false)
                scope.launch {
                    if (existing == null) dao.insertUserRecipe(x) else dao.updateUserRecipe(x.copy(id = existing.id, createdAt = existing.createdAt, photoPath = existing.photoPath))
                    toast(ctx, tr("تم الحفظ ✅", "Saved ✅")); onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun OnlineRecipeDialog(q: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var res by remember { mutableStateOf<List<Food.Online>?>(null) }
    var add by remember { mutableStateOf<Food.Online?>(null) }
    var manual by remember { mutableStateOf(false) }
    LaunchedEffect(q) { res = withContext(Dispatchers.IO) { Food.searchOnline(q) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("نتائج «$q»", "Results for \"$q\"")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val list = res
                when {
                    list == null -> CircularProgressIndicator()
                    list.isEmpty() -> Text(tr("لم توجد نتائج في قاعدة الوصفات العالمية (تبحث بالإنجليزية مثل: Kebab, Shawarma, Biryani). يمكنك مشاهدة فيديو وإضافتها يدوياً.", "No results in the global recipe database. Try English names, or add it manually."), style = MaterialTheme.typography.bodySmall)
                    else -> list.take(8).forEach { o ->
                        Card(onClick = { add = o }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text(o.name, fontWeight = FontWeight.Bold)
                                Text(o.area + " • " + o.category + " • " + o.ingredients.size + tr(" مكون", " ingredients"), style = MaterialTheme.typography.bodySmall)
                                Text(tr("اضغط لإضافتها لوصفاتي", "Tap to add to my recipes"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { Share.openUrl(ctx, Food.youtube(q)) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.PlayCircle, null, tint = DangerRed); Spacer(Modifier.width(4.dp)); Text(tr("فيديوهات «$q» على يوتيوب", "YouTube videos")) }
                OutlinedButton(onClick = { Share.openUrl(ctx, Food.google(tr("طريقة عمل ", "how to make ") + q + tr(" بالمقادير والسعرات", " recipe calories"))) }, modifier = Modifier.fillMaxWidth()) { Text(tr("🔎 بحث Google بالعربي", "🔎 Google search")) }
                TextButton(onClick = { manual = true }) { Text(tr("✍️ أضفها يدوياً", "✍️ Add manually")) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
    add?.let { o -> UserRecipeDialog(null, o) { add = null; onDismiss() } }
    if (manual) UserRecipeDialog(null, Food.Online(q, "", "", emptyList(), emptyList(), "", "")) { manual = false; onDismiss() }
}

// ---------------------------------- ماذا أطبخ؟ ----------------------------------
@Composable
private fun SuggestTab(nav: NavController) {
    val ctx = LocalContext.current
    val all = rememberAllRecipes()
    var pantry by remember { mutableStateOf(Food.savedSet(Food.pantryKey)) }
    var apps by remember { mutableStateOf(Food.savedSet(Food.myAppliancesKey).ifEmpty { setOf("stove") }) }
    var extra by remember { mutableStateOf("") }
    var diabOnly by rememberSaveable { mutableStateOf(false) }
    val appliances = remember { Food.appliances(ctx) }
    fun togglePantry(x: String) { pantry = if (x in pantry) pantry - x else pantry + x; Food.saveSet(Food.pantryKey, pantry) }
    fun toggleApp(x: String) { apps = if (x in apps) apps - x else apps + x; Food.saveSet(Food.myAppliancesKey, apps) }
    val matches = remember(all, pantry, apps, diabOnly) { Food.suggest(all.filter { !diabOnly || it.diab == "G" }, pantry, apps) }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(tr("🧺 ماذا عندك في المطبخ؟", "🧺 What's in your kitchen?"), fontWeight = FontWeight.Bold) }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (Food.pantryChoices + pantry.filter { it !in Food.pantryChoices }).forEach { x -> FilterChip(x in pantry, { togglePantry(x) }, label = { Text(x) }) }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(extra, { extra = it }, label = { Text(tr("مكون آخر", "Other ingredient")) }, singleLine = true, modifier = Modifier.weight(1f),
                    trailingIcon = { MicButton { t -> t.split(Regex("[،,\\s]+")).map { w -> if (w.startsWith("و") && w.length > 3) w.drop(1) else w }.filter { it.length > 1 }.forEach { w -> if (w !in pantry) togglePantry(w) } } })
                IconButton(onClick = { if (extra.isNotBlank()) { togglePantry(extra.trim()); extra = "" } }) { Icon(Icons.Filled.AddCircle, null, tint = MaterialTheme.colorScheme.primary) }
            }
        }
        if (pantry.isNotEmpty()) item { TextButton(onClick = { pantry = emptySet(); Food.saveSet(Food.pantryKey, pantry) }) { Text(tr("مسح الاختيار", "Clear"), color = DangerRed) } }
        item { Text(tr("🔌 أجهزتك", "🔌 Your appliances"), fontWeight = FontWeight.Bold) }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip("stove" in apps, { toggleApp("stove") }, label = { Text(tr("🔥 بوتاجاز", "🔥 Stove")) })
                appliances.forEach { a -> FilterChip(a.id in apps, { toggleApp(a.id) }, label = { Text(a.emoji + " " + a.name) }) }
            }
        }
        item { FilterChip(diabOnly, { diabOnly = !diabOnly }, label = { Text(tr("🟢 مناسبة للسكري فقط", "🟢 Diabetes-friendly only")) }) }
        item { HorizontalDivider() }
        if (pantry.isEmpty()) item { Text(tr("اختر المكونات المتوفرة وسأقترح عليك ما يمكنك طبخه الآن.", "Pick what you have and I'll suggest dishes."), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        else if (matches.isEmpty()) item { Text(tr("لا توجد وصفة مطابقة؛ أضف مكونات أكثر.", "No match; add more ingredients."), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(matches.take(30), key = { "m" + it.r.id }) { m ->
            Card(onClick = { nav.navigate("recipe/${m.r.id}") }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(Food.meal(m.r.meal).emoji + " " + m.r.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("${m.pct}%", fontWeight = FontWeight.ExtraBold, color = if (m.pct >= 70) SuccessGreen else if (m.pct >= 40) WarnAmber else MaterialTheme.colorScheme.outline)
                    }
                    LinearProgressIndicator(progress = { m.pct / 100f }, modifier = Modifier.fillMaxWidth())
                    Text(tr("لديك ${m.have} من ${m.total} مكونات • ${m.r.kcal} سعرة", "You have ${m.have}/${m.total} • ${m.r.kcal} kcal"), style = MaterialTheme.typography.bodySmall)
                    if (m.missing.isNotEmpty()) Text(tr("ينقصك: ", "Missing: ") + m.missing.take(5).joinToString("، "), style = MaterialTheme.typography.bodySmall, color = WarnAmber)
                    if (!m.appsOk) Text(tr("تحتاج: ", "Needs: ") + m.r.apps.joinToString("، ") { Food.applianceName(ctx, it) }, style = MaterialTheme.typography.bodySmall, color = DangerRed)
                }
            }
        }
    }
}

// ---------------------------------- الخضار والفاكهة ----------------------------------
@Composable
private fun ProduceTab() {
    val ctx = LocalContext.current
    var type by rememberSaveable { mutableStateOf("VEG") }
    var q by rememberSaveable { mutableStateOf("") }
    var open by remember { mutableStateOf<Food.FoodItem?>(null) }
    val list = (if (q.isBlank()) Food.foods(ctx) else Food.searchFoods(ctx, q)).filter { type == "ALL" || it.type == type || q.isNotBlank() }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { SearchField(q) { q = it } }; MicButton { q = it } } }
        item { HChips { Food.foodTypes.forEach { t -> FilterChip(type == t.key, { type = t.key }, label = { Text(t.emoji + " " + t.label) }) } } }
        items(list, key = { it.ar }) { f -> FoodRow(f) { open = f } }
    }
    open?.let { f -> FoodDialog(f) { open = null } }
}

@Composable
fun FoodRow(f: Food.FoodItem, onClick: () -> Unit) {
    val e = Food.effect(f)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(f.emoji, fontSize = 28.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, fontWeight = FontWeight.Bold)
                Text(f.benefits, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(e.emoji + " " + e.label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
            }
            if (f.kcal >= 0) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(Fmt.num(f.kcal), fontWeight = FontWeight.Bold)
                Text(tr("سعرة/100جم", "kcal/100g"), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun FoodDialog(f: Food.FoodItem, onDismiss: () -> Unit) {
    val e = Food.effect(f)
    val color = when (e.level) { 0, 1, 2 -> SuccessGreen; 3 -> WarnAmber; else -> DangerRed }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(f.emoji + " " + f.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = color.copy(alpha = 0.12f), shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                        Text(tr("التأثير على سكر الدم", "Effect on blood sugar"), style = MaterialTheme.typography.labelLarge)
                        Text(e.emoji + " " + e.label, fontWeight = FontWeight.Bold, color = color)
                        Text(f.diab, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (f.kcal >= 0) KeyValue(tr("السعرات لكل 100 جم", "kcal per 100 g"), Fmt.num(f.kcal))
                if (f.carbs >= 0) KeyValue(tr("الكربوهيدرات لكل 100 جم", "Carbs per 100 g"), Fmt.num(f.carbs) + tr(" جم", " g"))
                KeyValue(tr("المؤشر الجلايسيمي", "Glycemic index"), if (f.gi >= 0) "${f.gi} (" + Food.giLabel(f.gi) + ")" else Food.giLabel(f.gi))
                KeyValue(tr("الحصة المقترحة", "Suggested serving"), f.serving)
                Text(tr("💚 الفوائد", "💚 Benefits"), fontWeight = FontWeight.Bold, color = SuccessGreen)
                Text(f.benefits)
                Text(tr("⚠️ تحذيرات", "⚠️ Cautions"), fontWeight = FontWeight.Bold, color = DangerRed)
                Text(f.cautions)
                Text(tr("معلومات توعوية تقريبية ولا تغني عن الطبيب أو أخصائي التغذية.", "Approximate educational info, not a substitute for your doctor."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } }
    )
}

// ---------------------------------- أجهزة المطبخ ----------------------------------
@Composable
private fun AppliancesTab(nav: NavController) {
    val ctx = LocalContext.current
    val list = remember { Food.appliances(ctx) }
    val all = rememberAllRecipes()
    var open by remember { mutableStateOf<Food.Appliance?>(null) }
    var model by rememberSaveable { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr("🔎 اكتب موديل جهاز لمعرفة سعره ومواصفاته", "🔎 Type a model to check price & specs"), fontWeight = FontWeight.Bold)
                    OutlinedTextField(model, { model = it }, label = { Text(tr("مثال: Philips HD9252 أو Ninja AF300", "e.g. Philips HD9252")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), trailingIcon = { MicButton { model = it } })
                    if (model.isNotBlank()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Food.priceLinks(model).forEach { (n, u) -> AssistChip({ Share.openUrl(ctx, u) }, label = { Text(n) }) }
                    }
                    Text(tr("الأسعار تتغير باستمرار؛ الروابط تفتح الأسعار الحالية في المتاجر.", "Prices change often; links open current store prices."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        items(list, key = { it.id }) { a ->
            Card(onClick = { open = a }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(a.emoji, fontSize = 28.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text(a.caps.take(2).joinToString(" • "), style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("🇪🇬 " + a.priceEG + "  •  🇸🇦 " + a.priceGulf, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
    open?.let { a ->
        val uses = all.filter { a.id in it.apps }
        AlertDialog(
            onDismissRequest = { open = null },
            title = { Text(a.emoji + " " + a.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr("ماذا يفعل؟", "What can it do?"), fontWeight = FontWeight.Bold)
                    a.caps.forEach { Text("• $it") }
                    Text(tr("نصائح الشراء", "Buying tips"), fontWeight = FontWeight.Bold)
                    a.tips.forEach { Text("✓ $it", style = MaterialTheme.typography.bodySmall) }
                    Text(tr("أفضل الماركات", "Top brands"), fontWeight = FontWeight.Bold)
                    Text(a.brands.joinToString(" • "))
                    KeyValue(tr("🇪🇬 السعر التقريبي في مصر", "🇪🇬 Approx. price Egypt"), a.priceEG)
                    KeyValue(tr("🇸🇦 السعر التقريبي في الخليج", "🇸🇦 Approx. price Gulf"), a.priceGulf)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Food.priceLinks(a.en).forEach { (n, u) -> AssistChip({ Share.openUrl(ctx, u) }, label = { Text(n) }) } }
                    if (uses.isNotEmpty()) {
                        Text(tr("وصفات تُعمل به", "Recipes using it"), fontWeight = FontWeight.Bold)
                        uses.take(12).forEach { r -> Text("• " + r.name + " (${r.kcal} " + tr("سعرة", "kcal") + ")", Modifier.clickable { open = null; nav.navigate("recipe/${r.id}") }.padding(vertical = 3.dp), color = MaterialTheme.colorScheme.primary) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = null }) { Text(tr("إغلاق", "Close")) } }
        )
    }
}
