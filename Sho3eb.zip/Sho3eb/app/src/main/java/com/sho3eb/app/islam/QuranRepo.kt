package com.sho3eb.app.islam

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

data class Surah(val num: Int, val name: String, val enName: String, val type: String, val count: Int, val firstGlobal: Int, val startPage: Int)
data class Ayah(val global: Int, val surah: Int, val num: Int, val page: Int, val juz: Int, val hizbQ: Int, val sajda: Boolean, val text: String)
data class Edition(val id: String, val name: String, val lang: String)
data class Reciter(val id: String, val name: String, val template: String? = null)

/**
 * مصدر بيانات القرآن: نص المصحف (رسم عثماني) من api.alquran.cloud
 * يُنزّل مرة واحدة ويُحفظ على الجهاز للعمل بدون إنترنت.
 */
object QuranRepo {
    private const val API = "https://api.alquran.cloud/v1"
    const val PAGES = 604
    const val AYAT = 6236

    val ready = mutableStateOf(false)
    val progress = mutableStateOf<Float?>(null)
    val error = mutableStateOf<String?>(null)

    @Volatile var ayat: List<Ayah> = emptyList(); private set
    @Volatile var surahs: List<Surah> = emptyList(); private set
    private var pages: Array<List<Ayah>> = emptyArray()
    private val loadLock = Mutex()

    private fun dir(ctx: Context) = File(ctx.filesDir, "quran").apply { mkdirs() }
    private fun dataFile(ctx: Context) = File(dir(ctx), "quran_uthmani_v1.tsv")
    fun isDownloaded(ctx: Context) = dataFile(ctx).exists()

    // ======================= التحميل =======================
    suspend fun ensureLoaded(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        loadLock.withLock {
            if (ayat.isNotEmpty()) return@withLock true
            val f = dataFile(ctx)
            // نص المصحف مضمّن داخل التطبيق: يُجهّز تلقائياً عند أول فتح بلا إنترنت
            if (!f.exists()) runCatching { installFromAssets(ctx) }
            if (!f.exists()) return@withLock false
            try {
                loadTsv(f); true
            } catch (e: Exception) {
                f.delete(); false
            }
        }
    }

    private fun loadTsv(f: File) {
        val ss = mutableListOf<Array<String>>()
        val aa = ArrayList<Ayah>(AYAT)
        f.bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.forEach { line ->
                val p = line.split('\t')
                if (p[0] == "S") ss += p.toTypedArray()
                else if (p[0] == "A" && p.size >= 9) aa += Ayah(
                    p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt(), p[6].toInt(), p[7] == "1", p[8]
                )
            }
        }
        val pg = Array<MutableList<Ayah>>(PAGES + 1) { mutableListOf() }
        aa.forEach { if (it.page in 1..PAGES) pg[it.page].add(it) }
        val bySurah = aa.groupBy { it.surah }
        surahs = ss.map { p ->
            val n = p[1].toInt()
            val list = bySurah[n] ?: emptyList()
            Surah(n, p[2], p[3], p[4], list.size, list.firstOrNull()?.global ?: 1, list.firstOrNull()?.page ?: 1)
        }
        pages = Array(PAGES + 1) { pg[it].toList() }
        ayat = aa
        ready.value = aa.size >= AYAT
    }

    /** تجهيز المصحف من النسخة المضمنة في التطبيق (assets/quran/quran-uthmani.json) */
    private fun installFromAssets(ctx: Context): Boolean {
        val names = runCatching { ctx.assets.list("quran")?.toList() }.getOrNull() ?: return false
        val name = names.firstOrNull { it.startsWith("quran-uthmani") } ?: return false
        val tmp = File(ctx.cacheDir, "quran_asset.json")
        ctx.assets.open("quran/$name").use { i ->
            val src = if (name.endsWith(".gz")) java.util.zip.GZIPInputStream(i) else i
            tmp.outputStream().use { src.copyTo(it) }
        }
        return try { writeTsv(ctx, tmp); true } finally { tmp.delete() }
    }
    private fun writeTsv(ctx: Context, json: File) {
        val out = File(dir(ctx), "quran.tmp")
        out.bufferedWriter(Charsets.UTF_8).use { w ->
            parseEdition(json) { s, sName, sEn, sType, a ->
                if (a == null) w.write("S\t$s\t$sName\t$sEn\t$sType\n")
                else w.write("A\t${a.global}\t${a.surah}\t${a.num}\t${a.page}\t${a.juz}\t${a.hizbQ}\t${if (a.sajda) 1 else 0}\t${a.text}\n")
            }
        }
        val f = dataFile(ctx)
        if (f.exists()) f.delete()
        out.renameTo(f)
    }

    /** تنزيل المصحف كاملاً (مرة واحدة) */
    suspend fun download(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        error.value = null
        progress.value = 0f
        val tmp = File(ctx.cacheDir, "quran_dl.json")
        try {
            Net.download("$API/quran/quran-uthmani", tmp, 60000) { done, total ->
                progress.value = if (total > 0) (done.toFloat() / total) * 0.9f else 0.45f
            }
            val out = File(dir(ctx), "quran.tmp")
            out.bufferedWriter(Charsets.UTF_8).use { w ->
                parseEdition(tmp) { s, sName, sEn, sType, a ->
                    if (a == null) w.write("S\t$s\t$sName\t$sEn\t$sType\n")
                    else w.write("A\t${a.global}\t${a.surah}\t${a.num}\t${a.page}\t${a.juz}\t${a.hizbQ}\t${if (a.sajda) 1 else 0}\t${a.text}\n")
                }
            }
            tmp.delete()
            val f = dataFile(ctx)
            if (f.exists()) f.delete()
            out.renameTo(f)
            loadLock.withLock { loadTsv(f) }
            progress.value = null
            true
        } catch (e: Exception) {
            tmp.delete()
            progress.value = null
            error.value = e.message ?: "error"
            false
        }
    }

    /** قراءة ملف JSON لنسخة كاملة من القرآن بطريقة التدفق (لتوفير الذاكرة) */
    private fun parseEdition(file: File, emit: (Int, String, String, String, Ayah?) -> Unit) {
        JsonReader(file.bufferedReader(Charsets.UTF_8)).use { r ->
            r.beginObject()
            while (r.hasNext()) {
                if (r.nextName() != "data") { r.skipValue(); continue }
                r.beginObject()
                while (r.hasNext()) {
                    if (r.nextName() != "surahs") { r.skipValue(); continue }
                    r.beginArray()
                    while (r.hasNext()) parseSurah(r, emit)
                    r.endArray()
                }
                r.endObject()
            }
            r.endObject()
        }
    }

    private fun parseSurah(r: JsonReader, emit: (Int, String, String, String, Ayah?) -> Unit) {
        var num = 0
        var name = ""
        var en = ""
        var type = ""
        val list = mutableListOf<Ayah>()
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "number" -> num = r.nextInt()
                "name" -> name = r.nextString()
                "englishName" -> en = r.nextString()
                "revelationType" -> type = r.nextString()
                "ayahs" -> {
                    r.beginArray()
                    while (r.hasNext()) {
                        var g = 0; var n = 0; var page = 0; var juz = 0; var hq = 0; var sajda = false; var text = ""
                        r.beginObject()
                        while (r.hasNext()) {
                            when (r.nextName()) {
                                "number" -> g = r.nextInt()
                                "text" -> text = r.nextString()
                                "numberInSurah" -> n = r.nextInt()
                                "page" -> page = r.nextInt()
                                "juz" -> juz = r.nextInt()
                                "hizbQuarter" -> hq = r.nextInt()
                                "sajda" -> {
                                    if (r.peek() == JsonToken.BOOLEAN) sajda = r.nextBoolean()
                                    else { r.skipValue(); sajda = true }
                                }
                                else -> r.skipValue()
                            }
                        }
                        r.endObject()
                        list += Ayah(g, 0, n, page, juz, hq, sajda, text)
                    }
                    r.endArray()
                }
                else -> r.skipValue()
            }
        }
        r.endObject()
        emit(num, name.replace('\t', ' '), en.replace('\t', ' '), type, null)
        list.forEach { a ->
            var t = a.text.replace('\t', ' ').replace('\n', ' ').replace("﻿", "").trim()
            // حذف البسملة الملحقة بأول آية في السور (عدا الفاتحة والتوبة) لعرضها كعنوان مستقل
            if (num != 1 && num != 9 && a.num == 1) {
                val w = t.split(' ')
                if (w.size > 4 && w[0].contains("سْم")) t = w.drop(4).joinToString(" ")
            }
            emit(num, name, en, type, a.copy(surah = num, text = t))
        }
    }

    // ======================= الاستعلام =======================
    fun page(p: Int): List<Ayah> = if (p in 1..PAGES && pages.size > p) pages[p] else emptyList()
    fun ayah(global: Int): Ayah? = ayat.getOrNull(global - 1)
    fun ayah(surah: Int, num: Int): Ayah? = surahs.getOrNull(surah - 1)?.let { ayat.getOrNull(it.firstGlobal - 1 + num - 1) }
    fun surah(n: Int): Surah? = surahs.getOrNull(n - 1)
    fun juzStartPage(j: Int): Int = ayat.firstOrNull { it.juz == j }?.page ?: 1
    fun pageOf(global: Int): Int = ayah(global)?.page ?: 1
    fun surahNameClean(s: Surah): String = s.name.removePrefix("سُورَةُ ").trim()

    /** "2:255" أو "2:1-5" أو "112" (السورة كاملة) مفصولة بفواصل */
    fun refs(spec: String): List<Ayah> {
        if (ayat.isEmpty()) return emptyList()
        val out = mutableListOf<Ayah>()
        spec.split(',').map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
            try {
                if (!part.contains(':')) {
                    val s = surah(part.toInt()) ?: return@forEach
                    for (k in 1..s.count) ayah(s.num, k)?.let { out += it }
                } else {
                    val (sp, rp) = part.split(':')
                    val s = sp.toInt()
                    val (from, to) = if (rp.contains('-')) rp.split('-').let { it[0].toInt() to it[1].toInt() } else rp.toInt() to rp.toInt()
                    for (k in from..to) ayah(s, k)?.let { out += it }
                }
            } catch (_: Exception) {
            }
        }
        return out
    }

    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            val c = ch.code
            if (c in 0x064B..0x065F || c == 0x0670 || c in 0x06D6..0x06ED || c == 0x0640) continue
            sb.append(
                when (ch) {
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                    'ة' -> 'ه'
                    'ى', 'ئ' -> 'ي'
                    'ؤ' -> 'و'
                    else -> ch
                }
            )
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private var normCache: List<String>? = null
    fun search(q: String, limit: Int = 200): List<Ayah> {
        val nq = normalize(q)
        if (nq.length < 2 || ayat.isEmpty()) return emptyList()
        val norm = normCache ?: ayat.map { normalize(it.text) }.also { normCache = it }
        val out = mutableListOf<Ayah>()
        for (k in norm.indices) {
            if (norm[k].contains(nq)) {
                out += ayat[k]; if (out.size >= limit) break
            }
        }
        return out
    }

    fun arabicNum(n: Int): String = n.toString().map { if (it in '0'..'9') ('٠' + (it - '0')) else it }.joinToString("")

    // ======================= التفسير والترجمة =======================
    private fun edDir(ctx: Context, ed: String) = File(dir(ctx), "ed_$ed").apply { mkdirs() }
    private val edMaps = HashMap<String, Map<Int, String>>()

    fun isEditionDownloaded(ctx: Context, ed: String) = File(dir(ctx), "full_$ed.tsv").exists()

    private fun fullEdition(ctx: Context, ed: String): Map<Int, String>? {
        edMaps[ed]?.let { return it }
        val f = File(dir(ctx), "full_$ed.tsv")
        if (!f.exists()) return null
        val m = HashMap<Int, String>(AYAT)
        f.bufferedReader(Charsets.UTF_8).useLines { ls ->
            ls.forEach { l -> val i = l.indexOf('\t'); if (i > 0) m[l.substring(0, i).toInt()] = l.substring(i + 1) }
        }
        edMaps[ed] = m
        return m
    }

    /** نص آية من نسخة (تفسير/ترجمة)، مع تخزين مؤقت */
    suspend fun editionText(ctx: Context, global: Int, ed: String): String = withContext(Dispatchers.IO) {
        fullEdition(ctx, ed)?.get(global)?.let { return@withContext it }
        val f = File(edDir(ctx, ed), "$global.txt")
        if (f.exists()) return@withContext f.readText()
        val json = JSONObject(Net.get("$API/ayah/$global/$ed"))
        val t = json.getJSONObject("data").getString("text")
        f.writeText(t)
        t
    }

    /** تنزيل تفسير/ترجمة كاملة للعمل بدون إنترنت */
    suspend fun downloadEdition(ctx: Context, ed: String, onProgress: (Float) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val tmp = File(ctx.cacheDir, "ed_dl.json")
        try {
            Net.download("$API/quran/$ed", tmp, 60000) { d, t -> onProgress(if (t > 0) d.toFloat() / t else 0.5f) }
            val out = File(dir(ctx), "full_$ed.tsv")
            out.bufferedWriter(Charsets.UTF_8).use { w ->
                parseEdition(tmp) { _, _, _, _, a ->
                    if (a != null) w.write("${a.global}\t${a.text.replace('\n', ' ')}\n")
                }
            }
            edMaps.remove(ed)
            true
        } catch (e: Exception) {
            false
        } finally {
            tmp.delete()
        }
    }

    private fun cachedList(ctx: Context, name: String, url: String, maxAgeMs: Long = 7L * 86_400_000L): String {
        val f = File(dir(ctx), name)
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < maxAgeMs) return f.readText()
        return try {
            Net.get(url).also { f.writeText(it) }
        } catch (e: Exception) {
            if (f.exists()) f.readText() else throw e
        }
    }

    suspend fun editions(ctx: Context, type: String): List<Edition> = withContext(Dispatchers.IO) {
        try {
            val arr = JSONObject(cachedList(ctx, "editions_$type.json", "$API/edition/type/$type")).getJSONArray("data")
            (0 until arr.length()).map { k ->
                val o = arr.getJSONObject(k)
                Edition(o.getString("identifier"), o.optString("name").ifBlank { o.optString("englishName") }, o.optString("language"))
            }.sortedWith(compareBy<Edition>({ if (it.lang == "ar") 0 else 1 }, { it.lang }))
        } catch (e: Exception) {
            if (type == "tafsir") listOf(Edition("ar.muyassar", "التفسير الميسر", "ar"), Edition("ar.jalalayn", "تفسير الجلالين", "ar"))
            else listOf(Edition("en.sahih", "Saheeh International", "en"))
        }
    }

    // ======================= التلاوات =======================
    val defaultReciters = listOf(
        Reciter("ar.alafasy", "مشاري راشد العفاسي"),
        Reciter("ar.abdulbasitmurattal", "عبد الباسط عبد الصمد (مرتل)"),
        Reciter("ar.husary", "محمود خليل الحصري"),
        Reciter("ar.minshawi", "محمد صديق المنشاوي"),
        Reciter("ar.abdurrahmaansudais", "عبد الرحمن السديس"),
        Reciter("ar.saoodshuraym", "سعود الشريم"),
        Reciter("ar.mahermuaiqly", "ماهر المعيقلي"),
        Reciter("ar.hudhaify", "علي الحذيفي"),
        Reciter("ar.ahmedajamy", "أحمد بن علي العجمي"),
        Reciter("ar.muhammadayyoub", "محمد أيوب")
    )

    /** قوالب جاهزة لإضافة قراء من مصادر أخرى (مثال quran.com) */
    val templateExamples = listOf(
        "عبد الباسط (مجوّد)" to "https://verses.quran.com/AbdulBaset/Mujawwad/mp3/{sss}{aaa}.mp3",
        "العفاسي (quran.com)" to "https://verses.quran.com/Alafasy/mp3/{sss}{aaa}.mp3"
    )

    suspend fun reciters(ctx: Context): List<Reciter> = withContext(Dispatchers.IO) {
        val api = try {
            val arr = JSONObject(cachedList(ctx, "reciters.json", "$API/edition?format=audio&type=versebyverse")).getJSONArray("data")
            (0 until arr.length()).map { arr.getJSONObject(it) }
                .filter { it.optString("language") == "ar" }
                .map { Reciter(it.getString("identifier"), it.optString("name").ifBlank { it.optString("englishName") }) }
        } catch (e: Exception) {
            defaultReciters
        }
        IslamPrefs.customReciters.map { Reciter(it.id, it.name, it.template) } + api.ifEmpty { defaultReciters }
    }

    fun reciterById(id: String): Reciter =
        IslamPrefs.customReciters.firstOrNull { it.id == id }?.let { Reciter(it.id, it.name, it.template) }
            ?: Reciter(id, IslamPrefs.reciterName)

    fun audioFile(ctx: Context, reciterId: String, global: Int): File =
        File(File(ctx.filesDir, "audio/" + reciterId.replace(Regex("[^A-Za-z0-9._-]"), "_")), "$global.mp3")

    fun isAudioDownloaded(ctx: Context, reciterId: String, global: Int) = audioFile(ctx, reciterId, global).exists()

    private fun fillTemplate(t: String, global: Int): String {
        val a = ayah(global)
        val s = a?.surah ?: 1
        val n = a?.num ?: 1
        return t.replace("{sss}", String.format("%03d", s)).replace("{aaa}", String.format("%03d", n))
            .replace("{s}", s.toString()).replace("{a}", n.toString()).replace("{n}", global.toString())
    }

    /** رابط ملف صوت الآية */
    fun remoteAudioUrl(r: Reciter, global: Int): String {
        r.template?.let { return fillTemplate(it, global) }
        val json = JSONObject(Net.get("$API/ayah/$global/${URLEncoder.encode(r.id, "UTF-8")}"))
        val d = json.getJSONObject("data")
        return d.optString("audio").ifBlank { d.getJSONArray("audioSecondary").getString(0) }
    }

    /** مصدر التشغيل: ملف محلي إن كان منزّلاً وإلا رابط مباشر */
    suspend fun audioSource(ctx: Context, r: Reciter, global: Int): String = withContext(Dispatchers.IO) {
        val f = audioFile(ctx, r.id, global)
        if (f.exists()) f.absolutePath else remoteAudioUrl(r, global)
    }

    suspend fun downloadAyahAudio(ctx: Context, r: Reciter, global: Int): Boolean = withContext(Dispatchers.IO) {
        val f = audioFile(ctx, r.id, global)
        if (f.exists()) return@withContext true
        try {
            Net.download(remoteAudioUrl(r, global), f); true
        } catch (e: Exception) {
            false
        }
    }

    /** تنزيل مجموعة آيات (سورة/رقية) مع تقدم */
    suspend fun downloadMany(ctx: Context, r: Reciter, globals: List<Int>, onProgress: (Int, Int) -> Unit): Int {
        var ok = 0
        globals.forEachIndexed { i, g ->
            if (downloadAyahAudio(ctx, r, g)) ok++
            onProgress(i + 1, globals.size)
        }
        return ok
    }

    fun deleteReciterAudio(ctx: Context, reciterId: String) {
        audioFile(ctx, reciterId, 1).parentFile?.deleteRecursively()
    }

    fun downloadedCount(ctx: Context, reciterId: String): Int =
        audioFile(ctx, reciterId, 1).parentFile?.listFiles()?.count { it.name.endsWith(".mp3") } ?: 0

    /** دمج ملفات MP3 لعدة آيات في ملف واحد (لنفس القارئ) */
    fun mergeMp3(files: List<File>, out: File): Boolean = try {
        out.parentFile?.mkdirs()
        out.outputStream().use { o -> files.filter { it.exists() }.forEach { f -> f.inputStream().use { it.copyTo(o) } } }
        out.length() > 0
    } catch (e: Exception) {
        false
    }

    fun ayahImageUrl(a: Ayah) = "https://cdn.islamic.network/quran/images/high-resolution/${a.surah}_${a.num}.png"
}
