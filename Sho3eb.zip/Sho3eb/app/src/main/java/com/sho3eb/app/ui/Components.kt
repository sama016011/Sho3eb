@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sho3eb.app.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** جمع Flow مع حفظه بين إعادة الرسم */
@Composable
fun <T> flowState(initial: T, vararg keys: Any?, block: () -> Flow<T>): State<T> {
    val flow = remember(*keys) { block() }
    return flow.collectAsState(initial)
}

@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    fab: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = fab,
        containerColor = MaterialTheme.colorScheme.background,
        content = content
    )
}

@Composable
fun Avatar(photoPath: String?, name: String, size: Dp = 44.dp, modifier: Modifier = Modifier) {
    val bmp = remember(photoPath) { photoPath?.let { if (File(it).exists()) Photos.load(it) else null } }
    if (bmp != null) {
        Image(
            bitmap = bmp.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop,
            modifier = modifier.size(size).clip(CircleShape)
        )
    } else {
        Box(
            modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(
                name.trim().take(1).uppercase().ifEmpty { "?" },
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.42f).sp
            )
        }
    }
}

@Composable
fun IconCircle(icon: ImageVector, color: Color, size: Dp = 42.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(size * 0.55f)) }
}

@Composable
fun StatCard(title: String, value: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            IconCircle(icon, color, 36.dp)
            Spacer(Modifier.height(8.dp))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
fun StatusChip(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f)).padding(horizontal = 10.dp, vertical = 4.dp)
    ) { Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier.padding(top = 6.dp), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
}

@Composable
fun EmptyState(icon: ImageVector, text: String) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 48.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
        Spacer(Modifier.height(12.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        placeholder = { Text(tr("بحث...", "Search...")) },
        leadingIcon = { Icon(Icons.Filled.Search, null) },
        trailingIcon = { if (value.isNotEmpty()) IconButton(onClick = { onChange("") }) { Icon(Icons.Filled.Close, null) } },
        singleLine = true, shape = RoundedCornerShape(50),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun FilterRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o ->
            FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(o) })
        }
    }
}

@Composable
fun MoneyField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        suffix = { Text(AppState.currency.value) },
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun NumberField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun NotesField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(tr("ملاحظات", "Notes")) },
        leadingIcon = { Icon(Icons.Filled.Description, null) },
        minLines = 3, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun DateField(label: String, epochDay: Long?, onChange: (Long?) -> Unit, allowClear: Boolean = false, modifier: Modifier = Modifier) {
    var show by remember { mutableStateOf(false) }
    Box(modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = epochDay?.let { Fmt.date(it) } ?: "", onValueChange = {}, readOnly = true,
            label = { Text(label) }, singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Event, null) },
            modifier = Modifier.fillMaxWidth()
        )
        Box(Modifier.matchParentSize().clip(RoundedCornerShape(8.dp)).clickable { show = true })
    }
    if (show) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (epochDay ?: Fmt.today()) * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { onChange(it / 86_400_000L) }
                    show = false
                }) { Text(tr("تم", "OK")) }
            },
            dismissButton = {
                Row {
                    if (allowClear) TextButton(onClick = { onChange(null); show = false }) { Text(tr("مسح", "Clear")) }
                    TextButton(onClick = { show = false }) { Text(tr("إلغاء", "Cancel")) }
                }
            }
        ) { DatePicker(state = state) }
    }
}

@Composable
fun PeriodSelector(type: String, count: String, onType: (String) -> Unit, onCount: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(tr("مدة الدورة / القسط", "Period"), style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(Period.DAY to tr("يوم", "Day"), Period.WEEK to tr("أسبوع", "Week"), Period.MONTH to tr("شهر", "Month"))
                .forEach { (k, l) -> FilterChip(selected = type == k, onClick = { onType(k) }, label = { Text(l) }) }
        }
        NumberField(count, onCount, tr("كل كم ${Fmt.unitName(type)}؟", "Every how many ${Fmt.unitName(type)}s?"))
        Fmt.parseInt(count)?.let {
            Text(Fmt.periodLabel(type, it), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String? = null, checked: Boolean, icon: ImageVector? = null, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun InfoBanner(text: String, color: Color = MaterialTheme.colorScheme.secondary) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.12f)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Info, null, tint = color)
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun KeyValue(label: String, value: String, valueColor: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.SemiBold, color = valueColor)
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirmText: String = tr("تأكيد", "Confirm"), danger: Boolean = true, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(if (danger) Icons.Filled.Warning else Icons.Filled.Info, null) },
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = { onConfirm(); onDismiss() }) {
                Text(confirmText, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/** نافذة إدخال مبلغ (دفعة / سلفة / سداد) */
@Composable
fun AmountDialog(
    title: String,
    initial: Double? = null,
    info: String? = null,
    showDue: Boolean = false,
    maxAmount: Double? = null,
    confirmText: String = tr("حفظ", "Save"),
    initialDate: Long? = null,
    initialNote: String = "",
    onDismiss: () -> Unit,
    onConfirm: (amount: Double, date: Long, due: Long?, note: String) -> Unit
) {
    val ctx = LocalContext.current
    var amount by remember { mutableStateOf(initial?.let { Fmt.plain(it) } ?: "") }
    var date by remember { mutableStateOf(initialDate ?: Fmt.today()) }
    var due by remember { mutableStateOf<Long?>(null) }
    var note by remember { mutableStateOf(initialNote) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (info != null) InfoBanner(info)
                MoneyField(amount, { amount = it }, tr("المبلغ", "Amount"))
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                if (showDue) DateField(tr("موعد السداد (اختياري)", "Repayment due date (optional)"), due, { due = it }, allowClear = true)
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = Fmt.parse(amount)
                when {
                    v == null || v <= 0 -> toast(ctx, tr("أدخل مبلغاً صحيحاً", "Enter a valid amount"))
                    maxAmount != null && v > maxAmount + 0.005 ->
                        toast(ctx, tr("المبلغ أكبر من المتبقي (${Fmt.money(maxAmount)})", "Amount exceeds the remaining (${Fmt.money(maxAmount)})"))
                    else -> onConfirm(v, date, due, note.trim())
                }
            }) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

/** زر PDF: إرسال عبر واتساب أو مشاركة */
@Composable
fun PdfShareButton(phone: String?, build: (android.content.Context) -> File) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var menu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    fun go(wa: Boolean) {
        scope.launch {
            busy = true
            try {
                val f = withContext(Dispatchers.IO) { build(ctx) }
                Share.sharePdf(ctx, f, phone, wa)
            } catch (e: Exception) {
                toast(ctx, tr("تعذر إنشاء التقرير", "Could not create report"))
            } finally {
                busy = false
            }
        }
    }
    Box {
        IconButton(onClick = { menu = true }, enabled = !busy) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            else Icon(Icons.Filled.PictureAsPdf, contentDescription = "PDF")
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(tr("إرسال PDF عبر واتساب", "Send PDF via WhatsApp")) },
                leadingIcon = { Icon(Icons.Filled.Chat, null) },
                onClick = { menu = false; go(true) }
            )
            DropdownMenuItem(
                text = { Text(tr("مشاركة / حفظ PDF", "Share / save PDF")) },
                leadingIcon = { Icon(Icons.Filled.Share, null) },
                onClick = { menu = false; go(false) }
            )
        }
    }
}

@Composable
fun PersonRow(name: String, phone: String, photo: String?, modifier: Modifier = Modifier, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Avatar(photo, name, 40.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (phone.isNotBlank()) Text(phone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}
