package com.sho3eb.app.islam

import android.app.DownloadManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Environment
import android.os.PowerManager
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import java.io.File

/**
 * الرقية الشرعية كاملة بأصوات المشايخ (تسجيلات صوتية جاهزة من أرشيف الإنترنت archive.org)
 * يمكن الاستماع المباشر أو التنزيل في الخلفية عبر مدير التنزيلات للاستماع بدون إنترنت.
 */
object RuqyahAudio {
    data class Part(val key: String, val ar: String, val en: String, val emoji: String) {
        val label get() = tr(ar, en)
    }

    data class Track(val sheikh: Sheikh, val part: Part?, val file: String, val minutes: Int, val sizeMb: Int) {
        val url get() = "https://archive.org/download/${sheikh.archiveId}/$file"
        val id get() = sheikh.id + "_" + (part?.key ?: "full")
        val title get() = tr("الرقية الشرعية - ", "Ruqyah - ") + (part?.label ?: tr("كاملة", "complete")) + " • " + sheikh.label
    }

    data class Sheikh(val id: String, val ar: String, val en: String, val archiveId: String) {
        val label get() = tr(ar, en)
    }

    val parts = listOf(
        Part("seher", "رقية السحر", "Ruqyah for magic", "🪄"),
        Part("mass", "رقية المس", "Ruqyah for possession", "🌀"),
        Part("hasd", "رقية العين والحسد", "Ruqyah for evil eye & envy", "👁️"),
        Part("3thab", "آيات العذاب", "Verses of punishment", "⚡")
    )

    private fun series(id: String, ar: String, en: String, archive: String, prefix: String, mins: List<Int>, mb: List<Int>, fileFix: Map<String, String> = emptyMap()): List<Track> {
        val sh = Sheikh(id, ar, en, archive)
        return parts.mapIndexed { i, p -> Track(sh, p, fileFix[p.key] ?: "$prefix-${p.key}.mp3", mins[i], mb[i]) }
    }

    /** المسار: seher, mass, hasd, 3thab */
    val tracks: List<Track> = listOf(
        series("afasy", "مشاري راشد العفاسي", "Mishary Alafasy", "e3fasi-Rokia", "e3fasi", listOf(25, 31, 23, 45), listOf(24, 29, 22, 43)),
        series("minshawi", "محمد صديق المنشاوي", "Muhammad Siddiq Al-Minshawi", "minshawi-Roqia", "minshawi", listOf(25, 31, 22, 43), listOf(24, 29, 22, 42), mapOf("3thab" to "minshawi-3htab.mp3")),
        series("hudhaifi", "عبد الرحمن الحذيفي", "Abdul Rahman Al-Hudhaifi", "hothife-Roqia", "hothife", listOf(24, 31, 21, 43), listOf(23, 29, 20, 42)),
        series("muhaisni", "محمد المحيسني", "Muhammad Al-Muhaisni", "mihesni-rokia", "mihesni", listOf(36, 34, 21, 36), listOf(34, 32, 17, 33)),
        series("dosari", "ياسر الدوسري", "Yasser Al-Dosari", "dosari-Roqia", "dosari", listOf(23, 27, 20, 39), listOf(22, 26, 19, 37)),
        series("qatami", "ناصر القطامي", "Nasser Al-Qatami", "alqtami-Roqiaa", "alqtami", listOf(22, 26, 19, 41), listOf(22, 25, 19, 39)),
        series("rifai", "هاني الرفاعي", "Hani Ar-Rifai", "rifa3i-Roqia", "rifa3i", listOf(23, 28, 20, 40), listOf(22, 27, 20, 39)),
        series("muaiqly", "ماهر المعيقلي", "Maher Al-Muaiqly", "Maher-Al-Meaqli-Roqia2", "maher", listOf(16, 21, 16, 32), listOf(16, 20, 15, 30)),
        series("abdulkarim", "محمد عبد الكريم", "Muhammad Abdul Karim", "abdalkareem-Roqia", "abdalkareem", listOf(19, 24, 17, 32), listOf(18, 23, 16, 31))
    ) .flatten() + listOf(
        Track(Sheikh("ghamdi", "سعد الغامدي", "Saad Al-Ghamdi", "Roquia_Saad_Al_Ghamdi_uP_bY_mUSLEm"), null, "009-_up_by_muslem.mp3", 59, 57),
        Track(Sheikh("ajmi", "أحمد العجمي", "Ahmad Al-Ajmi", "Roquia_Ahmad_Al_Ajmi_uP_bY_mUSLEm"), null, "003-_up_by_muslem.mp3", 128, 123),
        Track(Sheikh("abdulbasit", "عبد الباسط عبد الصمد", "Abdul Basit Abdul Samad", "Roquia_Abdulbaset_Abdulsamad_uP_bY_mUSLEm"), null, "001-_up_by_muslem.mp3", 78, 75)
    )

    val sheikhs: List<Sheikh> get() = tracks.map { it.sheikh }.distinctBy { it.id }
    fun tracksOf(id: String) = tracks.filter { it.sheikh.id == id }

    // ---------------- الملفات والتنزيل ----------------
    private fun dir(ctx: Context) = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir, "ruqyah").apply { mkdirs() }
    fun file(ctx: Context, t: Track) = File(dir(ctx), t.id + ".mp3")
    fun isDownloaded(ctx: Context, t: Track) = file(ctx, t).let { it.exists() && it.length() > 100_000 }

    private fun dm(ctx: Context) = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ruqyah_dl", Context.MODE_PRIVATE)

    /** يبدأ التنزيل في الخلفية مع إشعار النظام */
    fun download(ctx: Context, t: Track, wifiOnly: Boolean = false) {
        if (isDownloaded(ctx, t) || isDownloading(ctx, t)) return
        val f = file(ctx, t)
        f.delete()
        val req = DownloadManager.Request(Uri.parse(t.url))
            .setTitle(t.title)
            .setDescription(tr("تنزيل الرقية الشرعية", "Downloading ruqyah"))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationUri(Uri.fromFile(f))
            .setAllowedOverMetered(!wifiOnly)
            .setAllowedOverRoaming(!wifiOnly)
        try {
            val id = dm(ctx).enqueue(req)
            prefs(ctx).edit().putLong(t.id, id).apply()
        } catch (e: Exception) {
            toast(ctx, tr("تعذّر بدء التنزيل", "Couldn't start the download"))
        }
    }

    data class Progress(val done: Long, val total: Long, val running: Boolean, val failed: Boolean)

    fun progress(ctx: Context, t: Track): Progress? {
        val id = prefs(ctx).getLong(t.id, -1L).takeIf { it > 0 } ?: return null
        return try {
            dm(ctx).query(DownloadManager.Query().setFilterById(id)).use { c ->
                if (!c.moveToFirst()) return null
                val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                if (st == DownloadManager.STATUS_SUCCESSFUL) { prefs(ctx).edit().remove(t.id).apply(); null }
                else Progress(done, total, st == DownloadManager.STATUS_RUNNING || st == DownloadManager.STATUS_PENDING || st == DownloadManager.STATUS_PAUSED, st == DownloadManager.STATUS_FAILED)
            }
        } catch (_: Exception) { null }
    }

    fun isDownloading(ctx: Context, t: Track) = progress(ctx, t)?.running == true

    fun cancel(ctx: Context, t: Track) {
        val id = prefs(ctx).getLong(t.id, -1L)
        if (id > 0) try { dm(ctx).remove(id) } catch (_: Exception) { }
        prefs(ctx).edit().remove(t.id).apply()
        file(ctx, t).delete()
    }

    fun delete(ctx: Context, t: Track) { cancel(ctx, t) }

    fun downloadedSizeMb(ctx: Context) = (dir(ctx).listFiles()?.sumOf { it.length() } ?: 0L) / 1_048_576

    // ---------------- المشغّل ----------------
    private var mp: MediaPlayer? = null
    val current = mutableStateOf<Track?>(null)
    val playing = mutableStateOf(false)
    val loading = mutableStateOf(false)
    val position = mutableIntStateOf(0)
    val durMs = mutableIntStateOf(0)
    /** تكرار التشغيل (مفيد للرقية) */
    val loop = mutableStateOf(false)

    fun play(ctx: Context, t: Track) {
        SeqPlayer.stop()
        if (current.value?.id == t.id && mp != null) { resume(); return }
        stop()
        current.value = t
        loading.value = true
        val src = if (isDownloaded(ctx, t)) file(ctx, t).absolutePath else t.url
        try {
            mp = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                setWakeMode(ctx.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                setOnPreparedListener { loading.value = false; RuqyahAudio.durMs.intValue = it.duration; it.isLooping = loop.value; it.start(); playing.value = true }
                setOnCompletionListener { playing.value = false; position.intValue = 0 }
                setOnErrorListener { _, _, _ ->
                    loading.value = false; playing.value = false
                    toast(ctx, tr("تعذّر تشغيل الصوت. تحقق من الاتصال أو نزّل الملف", "Couldn't play. Check your connection or download the file"))
                    true
                }
                setDataSource(src)
                prepareAsync()
            }
        } catch (e: Exception) {
            loading.value = false
            toast(ctx, tr("تعذّر تشغيل الصوت", "Couldn't play audio"))
        }
    }

    fun pause() { try { mp?.pause() } catch (_: Exception) { }; playing.value = false }
    fun resume() { try { mp?.start(); playing.value = true } catch (_: Exception) { } }
    fun toggle(ctx: Context, t: Track) = if (current.value?.id == t.id && playing.value) pause() else play(ctx, t)
    fun seekBy(ms: Int) { mp?.let { p -> try { p.seekTo((p.currentPosition + ms).coerceIn(0, p.duration)); position.intValue = p.currentPosition } catch (_: Exception) { } } }
    fun seekTo(ms: Int) { mp?.let { p -> try { p.seekTo(ms); position.intValue = ms } catch (_: Exception) { } } }
    fun setLoop(v: Boolean) { loop.value = v; try { mp?.isLooping = v } catch (_: Exception) { } }

    /** يُستدعى دورياً من الواجهة لتحديث شريط التقدم */
    fun tick() { mp?.let { p -> try { if (playing.value) position.intValue = p.currentPosition } catch (_: Exception) { } } }

    fun stop() {
        mp?.let { try { it.stop() } catch (_: Exception) { }; it.release() }
        mp = null
        playing.value = false; loading.value = false
        position.intValue = 0; RuqyahAudio.durMs.intValue = 0
        current.value = null
    }

    fun fmt(ms: Int): String {
        val s = ms / 1000
        return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60) else String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }
}
