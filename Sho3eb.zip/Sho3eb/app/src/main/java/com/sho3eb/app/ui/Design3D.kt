package com.sho3eb.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.tr
import kotlin.math.*

/** صندوق ثلاثي الأبعاد (سم) */
data class Box3(val x: Double, val y: Double, val z: Double, val w: Double, val d: Double, val h: Double, val color: Color, val label: String = "", val order: Int = 0)

private fun shade(c: Color, f: Float) = Color(red = (c.red * f).coerceIn(0f, 1f), green = (c.green * f).coerceIn(0f, 1f), blue = (c.blue * f).coerceIn(0f, 1f), alpha = c.alpha)

/**
 * عرض أيزومتري متحرك: يدور تلقائياً ويمكن تدويره بالسحب، والقطع "تُبنى" تدريجياً عند الفتح.
 * floorW/floorL أبعاد الأرضية، walls = رسم الجدارين البعيدين (أسلوب البيت المفتوح).
 */
@Composable
fun Iso3DView(boxes: List<Box3>, floorW: Double, floorL: Double, wallH: Double, walls: Boolean, floorColor: Color, modifier: Modifier = Modifier, key: Any? = null) {
    var auto by remember { mutableStateOf(true) }
    var manual by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    val inf = rememberInfiniteTransition(label = "rot")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "spin")
    val build = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { build.snapTo(0f); build.animateTo(1f, tween(2200, easing = FastOutSlowInEasing)) }
    val angle = (if (auto) spin else 0f) + manual + 35f
    val wallC = MaterialTheme.colorScheme.surfaceVariant
    val lineC = MaterialTheme.colorScheme.outline
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()
            .pointerInput(Unit) { detectDragGestures(onDragStart = { auto = false }) { ch, drag -> ch.consume(); manual += drag.x * 0.4f } }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 1.6f }) }
        ) {
            drawIso(boxes, floorW, floorL, wallH, walls, floorColor, wallC, lineC, angle.toDouble(), build.value, zoom)
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(4.dp)) {
            SmallFloatingActionButton(onClick = { auto = !auto }) { Icon(if (auto) Icons.Filled.Pause else Icons.Filled.Autorenew, contentDescription = tr("تدوير", "Rotate")) }
            Spacer(Modifier.width(6.dp))
            SmallFloatingActionButton(onClick = { zoom = if (zoom > 1.2f) 1f else 1.6f }) { Icon(if (zoom > 1.2f) Icons.Filled.ZoomOut else Icons.Filled.ZoomIn, null) }
        }
    }
}

private fun DrawScope.drawIso(
    boxes: List<Box3>, fw: Double, fl: Double, wallH: Double, walls: Boolean, floorC: Color, wallC: Color, lineC: Color, angleDeg: Double, progress: Float, zoom: Float
) {
    val a = Math.toRadians(angleDeg)
    val ca = cos(a); val sa = sin(a)
    val cx = fw / 2; val cy = fl / 2
    val diag = sqrt(fw * fw + fl * fl)
    val s = (min(size.width / (diag * 0.95), size.height / ((diag * 0.5 + wallH) * 1.05)) * zoom)
    val ox = size.width / 2; val oy = size.height / 2 + (wallH * s * 0.35).toFloat()
    val c30 = cos(Math.PI / 6); val s30 = sin(Math.PI / 6)
    fun rot(x: Double, y: Double): Pair<Double, Double> { val dx = x - cx; val dy = y - cy; return (dx * ca - dy * sa) to (dx * sa + dy * ca) }
    fun p(x: Double, y: Double, z: Double): Offset { val (rx, ry) = rot(x, y); return Offset((ox + (rx - ry) * c30 * s).toFloat(), (oy + (rx + ry) * s30 * s - z * s).toFloat()) }
    fun depth(x: Double, y: Double): Double { val (rx, ry) = rot(x, y); return rx + ry }
    fun poly(pts: List<Offset>, c: Color, outline: Boolean = true) {
        val path = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) }; close() }
        drawPath(path, c)
        if (outline) drawPath(path, lineC.copy(alpha = 0.35f), style = Stroke(1f))
    }
    // الأرضية
    poly(listOf(p(0.0, 0.0, 0.0), p(fw, 0.0, 0.0), p(fw, fl, 0.0), p(0.0, fl, 0.0)), floorC)
    // شبكة متر
    var gx = 100.0
    while (gx < fw) { drawLine(lineC.copy(alpha = 0.12f), p(gx, 0.0, 0.0), p(gx, fl, 0.0)); gx += 100 }
    var gy = 100.0
    while (gy < fl) { drawLine(lineC.copy(alpha = 0.12f), p(0.0, gy, 0.0), p(fw, gy, 0.0)); gy += 100 }
    // الجداران البعيدان
    if (walls) {
        val edges = listOf(
            Triple(Offset(0f, 0f), Offset(fw.toFloat(), 0f), 0), Triple(Offset(fw.toFloat(), 0f), Offset(fw.toFloat(), fl.toFloat()), 1),
            Triple(Offset(fw.toFloat(), fl.toFloat()), Offset(0f, fl.toFloat()), 2), Triple(Offset(0f, fl.toFloat()), Offset(0f, 0f), 3)
        ).sortedBy { (a1, b1, _) -> depth((a1.x + b1.x) / 2.0, (a1.y + b1.y) / 2.0) }.take(2)
        edges.forEach { (a1, b1, _) ->
            poly(listOf(p(a1.x.toDouble(), a1.y.toDouble(), 0.0), p(b1.x.toDouble(), b1.y.toDouble(), 0.0), p(b1.x.toDouble(), b1.y.toDouble(), wallH), p(a1.x.toDouble(), a1.y.toDouble(), wallH)), shade(wallC, 0.95f))
        }
    }
    // القطع مرتبة من الأبعد للأقرب
    val n = boxes.size.coerceAtLeast(1)
    boxes.sortedWith(compareBy({ depth(it.x + it.w / 2, it.y + it.d / 2) - (if (it.h <= 2) 100000.0 else 0.0) }, { it.z })).forEach { b ->
        val idx = b.order.coerceIn(0, n)
        val local = ((progress * (n + 4) - idx) / 4f).coerceIn(0f, 1f)
        if (local <= 0f) return@forEach
        val h = max(b.h * local, 0.5)
        val z0 = b.z * local
        val x0 = b.x; val y0 = b.y; val x1 = b.x + b.w; val y1 = b.y + b.d
        val col = b.color.copy(alpha = (0.35f + 0.65f * local) * b.color.alpha)
        // وجهان جانبيان أقرب للمشاهد + السطح
        val faces = listOf(
            listOf(x0 to y0, x1 to y0), listOf(x1 to y0, x1 to y1), listOf(x1 to y1, x0 to y1), listOf(x0 to y1, x0 to y0)
        ).sortedBy { e -> depth((e[0].first + e[1].first) / 2, (e[0].second + e[1].second) / 2) }
        faces.takeLast(2).forEachIndexed { i, e ->
            poly(listOf(p(e[0].first, e[0].second, z0), p(e[1].first, e[1].second, z0), p(e[1].first, e[1].second, z0 + h), p(e[0].first, e[0].second, z0 + h)), shade(col, if (i == 0) 0.72f else 0.85f))
        }
        poly(listOf(p(x0, y0, z0 + h), p(x1, y0, z0 + h), p(x1, y1, z0 + h), p(x0, y1, z0 + h)), shade(col, 1.08f))
    }
}

/** مخطط ثنائي الأبعاد من أعلى */
@Composable
fun Plan2DView(
    w: Double, l: Double, rects: List<Box3>, modifier: Modifier = Modifier, door: Pair<Int, Double>? = null, window: Pair<Int, Double>? = null,
    doorWidth: Double = 90.0, windowWidth: Double = 140.0, showDims: Boolean = true, labels: Boolean = true
) {
    val lineC = MaterialTheme.colorScheme.onSurface
    val bg = MaterialTheme.colorScheme.surface
    val prim = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        val pad = 28f
        val s = min((size.width - 2 * pad) / w, (size.height - 2 * pad) / l).toFloat()
        val ox = (size.width - w.toFloat() * s) / 2; val oy = (size.height - l.toFloat() * s) / 2
        fun X(v: Double) = ox + v.toFloat() * s
        fun Y(v: Double) = oy + v.toFloat() * s
        drawRect(bg, Offset(X(0.0), Y(0.0)), Size(w.toFloat() * s, l.toFloat() * s))
        val paint = android.graphics.Paint().apply { color = android.graphics.Color.DKGRAY; textSize = 24f; textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }
        rects.sortedBy { if (it.h <= 2) 0 else 1 }.forEach { r ->
            drawRect(r.color.copy(alpha = if (r.h <= 2) 0.35f else 0.85f), Offset(X(r.x), Y(r.y)), Size(r.w.toFloat() * s, r.d.toFloat() * s))
            drawRect(lineC.copy(alpha = 0.6f), Offset(X(r.x), Y(r.y)), Size(r.w.toFloat() * s, r.d.toFloat() * s), style = Stroke(1.5f))
            if (labels && r.label.isNotBlank() && r.w * s > 50 && r.d * s > 22) {
                paint.textSize = min(24f, (r.w * s / max(4, r.label.length) * 1.6).toFloat()).coerceAtLeast(14f)
                drawContext.canvas.nativeCanvas.drawText(r.label, X(r.x + r.w / 2), Y(r.y + r.d / 2) + paint.textSize / 3, paint)
            }
        }
        // الجدران
        drawRect(lineC, Offset(X(0.0), Y(0.0)), Size(w.toFloat() * s, l.toFloat() * s), style = Stroke(6f))
        fun opening(wall: Int, pos: Double, width: Double, isDoor: Boolean) {
            val len = if (wall % 2 == 0) w else l
            val c = pos * len; val a0 = c - width / 2; val a1 = c + width / 2
            val (p0, p1) = when (wall) {
                0 -> Offset(X(a0), Y(0.0)) to Offset(X(a1), Y(0.0)); 2 -> Offset(X(a0), Y(l)) to Offset(X(a1), Y(l))
                3 -> Offset(X(0.0), Y(a0)) to Offset(X(0.0), Y(a1)); else -> Offset(X(w), Y(a0)) to Offset(X(w), Y(a1))
            }
            drawLine(bg, p0, p1, strokeWidth = 8f)
            if (isDoor) {
                val r = (width * s).toFloat()
                val (start, ctr) = when (wall) { 0 -> 0f to p0; 2 -> 270f to p0; 3 -> 0f to p0; else -> 90f to p0 }
                drawArc(prim.copy(alpha = 0.6f), start, 90f, true, Offset(ctr.x - r, ctr.y - r), Size(2 * r, 2 * r), style = Stroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))))
            } else drawLine(Color(0xFF42A5F5), p0, p1, strokeWidth = 5f)
        }
        door?.let { opening(it.first, it.second, doorWidth, true) }
        window?.let { opening(it.first, it.second, windowWidth, false) }
        if (showDims) {
            paint.textSize = 26f; paint.color = android.graphics.Color.rgb(25, 118, 210)
            drawContext.canvas.nativeCanvas.drawText(String.format(java.util.Locale.US, "%.2f m", w / 100), X(w / 2), Y(0.0) - 8f, paint)
            drawContext.canvas.nativeCanvas.save()
            drawContext.canvas.nativeCanvas.rotate(-90f, X(0.0) - 10f, Y(l / 2))
            drawContext.canvas.nativeCanvas.drawText(String.format(java.util.Locale.US, "%.2f m", l / 100), X(0.0) - 10f, Y(l / 2), paint)
            drawContext.canvas.nativeCanvas.restore()
        }
    }
}
