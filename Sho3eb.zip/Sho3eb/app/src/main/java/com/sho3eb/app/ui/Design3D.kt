package com.sho3eb.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.sho3eb.app.core.Design
import com.sho3eb.app.core.tr
import kotlin.math.*

/** صندوق ثلاثي الأبعاد (سم) */
data class Box3(val x: Double, val y: Double, val z: Double, val w: Double, val d: Double, val h: Double, val color: Color, val label: String = "", val order: Int = 0, val glass: Boolean = false)

/** فتحة في جدار (باب/شباك) لرسمها في المشهد */
data class Opening3(val wall: Int, val pos: Double, val width: Double, val door: Boolean)

private fun shade(c: Color, f: Float) = Color(red = (c.red * f).coerceIn(0f, 1f), green = (c.green * f).coerceIn(0f, 1f), blue = (c.blue * f).coerceIn(0f, 1f), alpha = c.alpha)
private fun mix(a: Color, b: Color, t: Float) = Color(a.red + (b.red - a.red) * t, a.green + (b.green - a.green) * t, a.blue + (b.blue - a.blue) * t, a.alpha)

// ============================================================================
//            تحويل قطعة الأثاث إلى أجزاء واقعية (أرجل، مساند، وسائد…)
// ============================================================================
fun furnitureParts(it: Design.Item, order: Int): List<Box3> {
    val c = Color(it.color)
    val dark = shade(c, 0.7f)
    val light = mix(c, Color.White, 0.35f)
    val leg = Color(0xFF4E342E)
    val metal = Color(0xFF9E9E9E)
    val x = it.x; val y = it.y; val w = it.w; val d = it.d; val h = it.h
    val horiz = w >= d   // الطول على محور x
    val out = mutableListOf<Box3>()
    fun b(bx: Double, by: Double, bz: Double, bw: Double, bd: Double, bh: Double, col: Color, glass: Boolean = false) { out += Box3(bx, by, bz, bw, bd, bh, col, "", order, glass) }
    fun legs4(top: Double, t: Double = 5.0, col: Color = leg) {
        b(x + 2, y + 2, 0.0, t, t, top, col); b(x + w - t - 2, y + 2, 0.0, t, t, top, col)
        b(x + 2, y + d - t - 2, 0.0, t, t, top, col); b(x + w - t - 2, y + d - t - 2, 0.0, t, t, top, col)
    }
    // جهة الظهر = الجدار الأقرب
    val backTop = y <= 1.0; val backLeft = x <= 1.0
    val key = it.key.trimEnd { ch -> ch.isDigit() }
    when {
        it.flat -> { // سجادة بإطار
            b(x, y, 0.0, w, d, 1.2, dark); b(x + 8, y + 8, 0.0, w - 16, d - 16, 1.6, c)
            b(x + w / 2 - w * 0.2, y + d / 2 - d * 0.2, 0.0, w * 0.4, d * 0.4, 1.8, light)
        }
        key == "bed" || key == "bed1" || key == "bed2" -> {
            val wood = Color(0xFF6D4C41)
            b(x, y, 8.0, w, d, 22.0, wood)                                  // القاعدة
            legs4(8.0, 6.0, shade(wood, 0.8f))
            b(x + 3, y + 3, 30.0, w - 6, d - 6, 22.0, Color(0xFFF5F5F5))     // المرتبة
            // اللحاف يغطي ثلثي المرتبة من جهة القدم
            if (horiz) {
                val headLeft = backLeft
                val qx = if (headLeft) x + w * 0.33 else x + 3
                b(qx, y + 1, 50.0, w * 0.67 - 3, d - 2, 5.0, c)
                val px = if (headLeft) x + 10 else x + w - 55
                b(px, y + 12, 52.0, 42.0, d / 2 - 18, 12.0, Color.White); b(px, y + d / 2 + 6, 52.0, 42.0, d / 2 - 18, 12.0, Color.White)
                b(if (headLeft) x - 6 else x + w, y, 8.0, 8.0, d, 110.0, dark)  // ظهر السرير
            } else {
                val headTop = backTop
                val qy = if (headTop) y + d * 0.33 else y + 3
                b(x + 1, qy, 50.0, w - 2, d * 0.67 - 3, 5.0, c)
                val py = if (headTop) y + 10 else y + d - 55
                b(x + 12, py, 52.0, w / 2 - 18, 42.0, 12.0, Color.White); b(x + w / 2 + 6, py, 52.0, w / 2 - 18, 42.0, 12.0, Color.White)
                b(x, if (headTop) y - 6 else y + d, 8.0, w, 8.0, 110.0, dark)
            }
        }
        key == "bunk" -> {
            b(x, y, 0.0, w, d, 6.0, dark); legs4(170.0, 7.0, dark)
            b(x + 4, y + 4, 25.0, w - 8, d - 8, 15.0, light); b(x + 2, y + 2, 20.0, w - 4, d - 4, 5.0, dark)
            b(x + 4, y + 4, 125.0, w - 8, d - 8, 15.0, c); b(x + 2, y + 2, 120.0, w - 4, d - 4, 5.0, dark)
        }
        key == "night" || key == "side" -> {
            b(x, y, 6.0, w, d, h - 6, c); legs4(6.0, 4.0)
            b(x + 3, y + 3, h - 18, w - 6, d - 6, 1.0, dark)               // خط الدرج
            if (key == "night") { b(x + w / 2 - 7, y + d / 2 - 7, h, 14.0, 14.0, 18.0, Color(0xFFBCAAA4)); b(x + w / 2 - 12, y + d / 2 - 12, h + 18, 24.0, 24.0, 16.0, Color(0xFFFFF8E1)) }
        }
        key == "wardrobe" -> {
            b(x, y, 0.0, w, d, h, c)
            val n = max(2, (max(w, d) / 50).toInt())
            for (i in 1 until n) { val f = i.toDouble() / n; if (horiz) b(x + w * f - 0.6, y + (if (backTop) d else -0.5), 5.0, 1.2, 1.0, h - 10, dark) else b(x + (if (backLeft) w else -0.5), y + d * f - 0.6, 5.0, 1.0, 1.2, h - 10, dark) }
            for (i in 0 until n) { val f = (i + 0.5) / n; if (horiz) b(x + w * f - 1.5, y + (if (backTop) d else -2.0), h * 0.45, 3.0, 2.0, 25.0, metal) else b(x + (if (backLeft) w else -2.0), y + d * f - 1.5, h * 0.45, 2.0, 3.0, 25.0, metal) }
            b(x - 1, y - 1, h, w + 2, d + 2, 4.0, dark)
        }
        key == "dresser" || key == "buffet" || key == "tv" || key == "cabinet" || key == "toys" -> {
            b(x, y, 8.0, w, d, h - 8, c); legs4(8.0, 4.0)
            b(x - 1, y - 1, h, w + 2, d + 2, 3.0, dark)
            if (key == "dresser") { if (horiz) b(x + w * 0.15, y + (if (backTop) 0.0 else d - 3), h + 3, w * 0.7, 3.0, 85.0, Color(0xFFB3E5FC), true) else b(x + (if (backLeft) 0.0 else w - 3), y + d * 0.15, h + 3, 3.0, d * 0.7, 85.0, Color(0xFFB3E5FC), true) }
            if (key == "tv") { if (horiz) b(x + w * 0.1, y + (if (backTop) 5.0 else d - 9), h + 3, w * 0.8, 4.0, w * 0.8 * 0.56, Color(0xFF212121)) else b(x + (if (backLeft) 5.0 else w - 9), y + d * 0.1, h + 3, 4.0, d * 0.8, d * 0.8 * 0.56, Color(0xFF212121)) }
        }
        key == "sofa" || key == "armchair" || key.startsWith("majlis") -> {
            val arm = if (key == "armchair") 14.0 else 18.0
            b(x, y, 0.0, w, d, 10.0, shade(leg, 1.1f))                     // قاعدة
            b(x, y, 10.0, w, d, 32.0, c)                                    // المقعد
            if (horiz) {
                val by = if (backTop) y else y + d - 20
                b(x, by, 10.0, w, 20.0, h - 10, dark)                       // الظهر
                b(x, y, 10.0, arm, d, 52.0, dark); b(x + w - arm, y, 10.0, arm, d, 52.0, dark)
                val n = if (key == "armchair") 1 else max(2, ((w - 2 * arm) / 65).toInt())
                val cw = (w - 2 * arm) / n
                for (i in 0 until n) b(x + arm + i * cw + 2, if (backTop) y + 20 else y + 2, 42.0, cw - 4, d - 24, 10.0, light)
                for (i in 0 until n) b(x + arm + i * cw + 8, if (backTop) y + 18 else y + d - 30, 52.0, cw - 16, 12.0, 30.0, light)
            } else {
                val bx = if (backLeft) x else x + w - 20
                b(bx, y, 10.0, 20.0, d, h - 10, dark)
                b(x, y, 10.0, w, arm, 52.0, dark); b(x, y + d - arm, 10.0, w, arm, 52.0, dark)
                val n = if (key == "armchair") 1 else max(2, ((d - 2 * arm) / 65).toInt())
                val cd = (d - 2 * arm) / n
                for (i in 0 until n) b(if (backLeft) x + 20 else x + 2, y + arm + i * cd + 2, 42.0, w - 24, cd - 4, 10.0, light)
                for (i in 0 until n) b(if (backLeft) x + 18 else x + w - 30, y + arm + i * cd + 8, 52.0, 12.0, cd - 16, 30.0, light)
            }
        }
        key == "coffee" || key == "table" || key == "ktable" || key == "desk" -> {
            val top = if (key == "coffee") 4.0 else 4.0
            legs4(h - top, if (key == "coffee") 5.0 else 6.0, if (key == "desk") metal else leg)
            b(x, y, h - top, w, d, top, c)
            if (key == "coffee") b(x + 6, y + 6, 12.0, w - 12, d - 12, 2.5, dark)
            if (key == "desk") { b(x + w / 2 - 18, y + d / 2 - 12, h, 36.0, 24.0, 2.0, Color(0xFF424242)); b(x + w / 2 - 18, if (backTop || !horiz) y + 4 else y + d - 6, h, 36.0, 2.0, 24.0, Color(0xFF424242)) }
            if (key == "table") b(x + w / 2 - 12, y + d / 2 - 12, h, 24.0, 24.0, 22.0, Color(0xFFE1F5FE), true)
        }
        key == "chair" || key == "ochair" -> {
            legs4(45.0, 4.0, if (key == "ochair") metal else leg)
            b(x, y, 45.0, w, d, 6.0, c)
            // الظهر بعيداً عن الطاولة: نستخدم الجهة الأبعد عن مركز القطعة نسبياً (تقريب)
            b(x, y, 51.0, w, 5.0, h - 51, dark)
        }
        key.startsWith("shelf") -> {
            b(x, y, 0.0, w, d, h, dark)
            val inset = 2.0
            val cols = listOf(Color(0xFFC62828), Color(0xFF1565C0), Color(0xFF2E7D32), Color(0xFFF9A825), Color(0xFF6A1B9A))
            var level = 1; var z = 10.0
            while (z + 30 < h) {
                b(x + inset, y + inset, z, w - 2 * inset, d - 2 * inset, 2.0, light)
                val n = 5
                for (i in 0 until n) if ((i + level) % 4 != 0) {
                    if (horiz) b(x + 6 + i * (w - 12) / n, y + 5, z + 2, (w - 12) / n - 3, d - 10, 20.0 + (i * 3 % 7), cols[(i + level) % cols.size])
                    else b(x + 5, y + 6 + i * (d - 12) / n, z + 2, w - 10, (d - 12) / n - 3, 20.0 + (i * 3 % 7), cols[(i + level) % cols.size])
                }
                z += 38; level++
            }
        }
        key == "plant" -> {
            b(x + w * 0.2, y + d * 0.2, 0.0, w * 0.6, d * 0.6, 32.0, Color(0xFF8D6E63))
            b(x + w * 0.1, y + d * 0.1, 32.0, w * 0.8, d * 0.8, h * 0.35, Color(0xFF43A047))
            b(x + w * 0.2, y + d * 0.2, 32 + h * 0.35, w * 0.6, d * 0.6, h * 0.3, Color(0xFF66BB6A))
            b(x + w * 0.32, y + d * 0.32, 32 + h * 0.65, w * 0.36, d * 0.36, h * 0.2, Color(0xFF81C784))
        }
        key.startsWith("counter") -> {
            b(x, y, 0.0, w, d, 10.0, Color(0xFF424242))
            b(x, y, 10.0, w, d, 78.0, c)
            b(x - 1, y - 1, 88.0, w + 2, d + 2, 4.0, Color(0xFFECEFF1))      // رخامة
            // دواليب علوية
            if (horiz) b(x, if (backTop) y else y + d - 35, 150.0, w, 35.0, 70.0, light) else b(if (backLeft) x else x + w - 35, y, 150.0, 35.0, d, 70.0, light)
            // حوض وبوتاجاز
            if (horiz) { b(x + w * 0.25, y + d * 0.2, 92.0, 55.0, d * 0.6, 1.0, metal); b(x + w * 0.65, y + d * 0.2, 92.0, 55.0, d * 0.6, 1.5, Color(0xFF212121)) }
            else { b(x + w * 0.2, y + d * 0.25, 92.0, w * 0.6, 55.0, 1.0, metal); b(x + w * 0.2, y + d * 0.65, 92.0, w * 0.6, 55.0, 1.5, Color(0xFF212121)) }
        }
        key == "fridge" -> { b(x, y, 0.0, w, d, h, Color(0xFFE0E0E0)); b(x - 0.5, y - 0.5, h * 0.62, w + 1, d + 1, 1.0, Color(0xFF9E9E9E)) }
        key == "toilet" -> {
            b(x + w * 0.15, y + d * 0.35, 0.0, w * 0.7, d * 0.6, 40.0, Color.White)
            if (horiz) b(if (backLeft) x else x + w - 18, y, 40.0, 18.0, d, 35.0, Color(0xFFF5F5F5)) else b(x, if (backTop) y else y + d - 18, 40.0, w, 18.0, 35.0, Color(0xFFF5F5F5))
        }
        key == "basin" -> { b(x, y, 0.0, w, d, h - 10, c); b(x - 2, y - 2, h - 10, w + 4, d + 4, 10.0, Color.White) }
        key == "shower" -> { b(x, y, 0.0, w, d, 12.0, Color.White); b(x, y, 12.0, w, d, h - 12, Color(0xFFB3E5FC).copy(alpha = 0.35f), true) }
        key == "tub" -> { b(x, y, 0.0, w, d, h, Color.White); b(x + 8, y + 8, h - 1, w - 16, d - 16, 1.5, Color(0xFF81D4FA)) }
        else -> b(x, y, 0.0, w, d, h, c)
    }
    return out
}

// ============================================================================
//                       العرض ثلاثي الأبعاد المتحرك
// ============================================================================
@Composable
fun Iso3DView(
    boxes: List<Box3>, floorW: Double, floorL: Double, wallH: Double, walls: Boolean, floorColor: Color, modifier: Modifier = Modifier, key: Any? = null,
    wallColor: Color? = null, openings: List<Opening3> = emptyList(), planks: Boolean = false
) {
    var auto by remember { mutableStateOf(true) }
    var manual by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var tilt by remember { mutableFloatStateOf(30f) }
    val inf = rememberInfiniteTransition(label = "rot")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(30000, easing = LinearEasing)), label = "spin")
    val build = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { build.snapTo(0f); build.animateTo(1f, tween(2600, easing = FastOutSlowInEasing)) }
    val angle = (if (auto) spin else 0f) + manual + 35f
    val wallC = wallColor ?: Color(0xFFF1EDE6)
    val lineC = MaterialTheme.colorScheme.outline
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, z, _ ->
                    auto = false
                    manual += pan.x * 0.35f
                    tilt = (tilt - pan.y * 0.12f).coerceIn(12f, 70f)
                    zoom = (zoom * z).coerceIn(0.6f, 3f)
                }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 1.7f }) }
        ) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFE3F2FD), Color(0xFFFFFFFF))))
            drawIso(boxes, floorW, floorL, wallH, walls, floorColor, wallC, lineC, angle.toDouble(), tilt.toDouble(), build.value, zoom, openings, planks)
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(4.dp)) {
            SmallFloatingActionButton(onClick = { auto = !auto }) { Icon(if (auto) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = tr("تدوير", "Rotate")) }
            Spacer(Modifier.width(6.dp))
            SmallFloatingActionButton(onClick = { zoom = if (zoom > 1.2f) 1f else 1.7f }) { Icon(if (zoom > 1.2f) Icons.Filled.ZoomOut else Icons.Filled.ZoomIn, null) }
        }
        Text(tr("اسحب للتدوير والإمالة • اقرص للتكبير", "Drag to rotate/tilt • pinch to zoom"), Modifier.align(Alignment.TopCenter).padding(4.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF607D8B))
    }
}

private fun DrawScope.drawIso(
    boxes: List<Box3>, fw: Double, fl: Double, wallH: Double, walls: Boolean, floorC: Color, wallC: Color, lineC: Color,
    angleDeg: Double, tiltDeg: Double, progress: Float, zoom: Float, openings: List<Opening3>, planks: Boolean
) {
    val a = Math.toRadians(angleDeg)
    val ca = cos(a); val sa = sin(a)
    val cx = fw / 2; val cy = fl / 2
    val tl = Math.toRadians(tiltDeg)
    val st = sin(tl); val ct = cos(tl)
    val diag = sqrt(fw * fw + fl * fl)
    val s = (min(size.width / (diag * 1.0), size.height / ((diag * st + wallH * ct) * 1.12)) * zoom)
    val ox = size.width / 2; val oy = size.height / 2 + (wallH * ct * s * 0.4).toFloat()
    fun rot(x: Double, y: Double): Pair<Double, Double> { val dx = x - cx; val dy = y - cy; return (dx * ca - dy * sa) to (dx * sa + dy * ca) }
    // إسقاط مائل: الأفقي = فرق المحورين، العمودي = مجموعهما × جيب الإمالة - الارتفاع × جيب تمام الإمالة
    fun p(x: Double, y: Double, z: Double): Offset { val (rx, ry) = rot(x, y); return Offset((ox + (rx - ry) * 0.7071 * s).toFloat(), (oy + (rx + ry) * 0.7071 * st * s - z * ct * s).toFloat()) }
    fun depth(x: Double, y: Double): Double { val (rx, ry) = rot(x, y); return rx + ry }
    fun poly(pts: List<Offset>, c: Color, outline: Boolean = true, alphaLine: Float = 0.25f) {
        val path = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) }; close() }
        drawPath(path, c)
        if (outline) drawPath(path, lineC.copy(alpha = alphaLine), style = Stroke(0.8f))
    }
    // الأرضية
    poly(listOf(p(0.0, 0.0, 0.0), p(fw, 0.0, 0.0), p(fw, fl, 0.0), p(0.0, fl, 0.0)), floorC, alphaLine = 0.5f)
    if (planks) {
        var gx = 20.0; var i = 0
        while (gx < fw) { drawLine(shade(floorC, 0.88f), p(gx, 0.0, 0.0), p(gx, fl, 0.0), 1f); gx += 20; i++ }
    } else {
        var gx = 60.0; while (gx < fw) { drawLine(shade(floorC, 0.9f), p(gx, 0.0, 0.0), p(gx, fl, 0.0), 1f); gx += 60 }
        var gy = 60.0; while (gy < fl) { drawLine(shade(floorC, 0.9f), p(0.0, gy, 0.0), p(fw, gy, 0.0), 1f); gy += 60 }
    }
    // الجدران البعيدة مع الشبابيك والأبواب
    if (walls) {
        data class E(val x0: Double, val y0: Double, val x1: Double, val y1: Double, val id: Int)
        val edges = listOf(E(0.0, 0.0, fw, 0.0, 0), E(fw, 0.0, fw, fl, 1), E(fw, fl, 0.0, fl, 2), E(0.0, fl, 0.0, 0.0, 3))
            .sortedBy { e -> depth((e.x0 + e.x1) / 2, (e.y0 + e.y1) / 2) }.take(2)
        edges.forEach { e ->
            val sh = if (e.id % 2 == 0) 0.96f else 0.88f
            poly(listOf(p(e.x0, e.y0, 0.0), p(e.x1, e.y1, 0.0), p(e.x1, e.y1, wallH), p(e.x0, e.y0, wallH)), shade(wallC, sh), alphaLine = 0.4f)
            // وزرة
            poly(listOf(p(e.x0, e.y0, 0.0), p(e.x1, e.y1, 0.0), p(e.x1, e.y1, 10.0), p(e.x0, e.y0, 10.0)), shade(wallC, sh * 0.8f), outline = false)
            val len = if (e.id % 2 == 0) fw else fl
            openings.filter { it.wall == e.id }.forEach { o ->
                // الموضع على الجدار حسب اتجاه رسم الحافة
                val c0 = o.pos * len - o.width / 2; val c1 = o.pos * len + o.width / 2
                fun at(t: Double): Pair<Double, Double> = when (e.id) { 0 -> t to 0.0; 2 -> t to fl; 1 -> fw to t; else -> 0.0 to t }
                val (ax, ay) = at(c0); val (bx, by) = at(c1)
                val z0 = if (o.door) 0.0 else 95.0; val z1 = if (o.door) min(210.0, wallH - 5) else min(215.0, wallH - 10)
                if (o.door) poly(listOf(p(ax, ay, z0), p(bx, by, z0), p(bx, by, z1), p(ax, ay, z1)), Color(0xFF8D6E63))
                else {
                    poly(listOf(p(ax, ay, z0), p(bx, by, z0), p(bx, by, z1), p(ax, ay, z1)), Color(0xFFFFFFFF))
                    poly(listOf(p(ax, ay, z0 + 4), p(bx, by, z0 + 4), p(bx, by, z1 - 4), p(ax, ay, z1 - 4)), Color(0xFF90CAF9).copy(alpha = 0.85f))
                    val (mx, my) = at((c0 + c1) / 2)
                    drawLine(Color.White, p(mx, my, z0), p(mx, my, z1), 3f)
                    // ستارة
                    poly(listOf(p(ax, ay, z0 - 20), p(at(c0 + 22).first, at(c0 + 22).second, z0 - 20), p(at(c0 + 22).first, at(c0 + 22).second, z1 + 15), p(ax, ay, z1 + 15)), Color(0xFFD7CCC8).copy(alpha = 0.9f), outline = false)
                }
            }
        }
    }
    // ظلال ناعمة تحت القطع
    boxes.filter { it.z < 1 && it.h > 3 }.forEach { bx ->
        poly(listOf(p(bx.x + 4, bx.y + 4, 0.2), p(bx.x + bx.w + 6, bx.y + 4, 0.2), p(bx.x + bx.w + 6, bx.y + bx.d + 6, 0.2), p(bx.x + 4, bx.y + bx.d + 6, 0.2)), Color.Black.copy(alpha = 0.07f * progress), outline = false)
    }
    // القطع مرتبة من الأبعد للأقرب
    val maxOrder = (boxes.maxOfOrNull { it.order } ?: 0) + 1
    boxes.sortedWith(compareBy({ if (it.h <= 2.5 && it.z < 1) 0 else 1 }, { depth(it.x + it.w / 2, it.y + it.d / 2) + it.z * 0.02 })).forEach { b ->
        val local = ((progress * (maxOrder + 3) - b.order) / 3f).coerceIn(0f, 1f)
        if (local <= 0f) return@forEach
        val h = max(b.h * local, 0.3)
        val z0 = b.z * local
        val x0 = b.x; val y0 = b.y; val x1 = b.x + b.w; val y1 = b.y + b.d
        val col = if (b.glass) b.color else b.color.copy(alpha = (0.3f + 0.7f * local) * b.color.alpha)
        val faces = listOf(listOf(x0 to y0, x1 to y0), listOf(x1 to y0, x1 to y1), listOf(x1 to y1, x0 to y1), listOf(x0 to y1, x0 to y0))
            .sortedBy { e -> depth((e[0].first + e[1].first) / 2, (e[0].second + e[1].second) / 2) }
        faces.takeLast(2).forEachIndexed { i, e ->
            poly(listOf(p(e[0].first, e[0].second, z0), p(e[1].first, e[1].second, z0), p(e[1].first, e[1].second, z0 + h), p(e[0].first, e[0].second, z0 + h)), shade(col, if (i == 0) 0.7f else 0.84f), alphaLine = if (b.glass) 0.5f else 0.2f)
        }
        poly(listOf(p(x0, y0, z0 + h), p(x1, y0, z0 + h), p(x1, y1, z0 + h), p(x0, y1, z0 + h)), shade(col, 1.06f), alphaLine = if (b.glass) 0.5f else 0.2f)
    }
}

/** مخطط ثنائي الأبعاد من أعلى */
@Composable
fun Plan2DView(
    w: Double, l: Double, rects: List<Box3>, modifier: Modifier = Modifier, door: Pair<Int, Double>? = null, window: Pair<Int, Double>? = null,
    doorWidth: Double = 90.0, windowWidth: Double = 140.0, showDims: Boolean = true, labels: Boolean = true
) {
    val lineC = MaterialTheme.colorScheme.onSurface
    val bg = MaterialTheme.colorScheme.surface
    val prim = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        val pad = 30f
        val s = min((size.width - 2 * pad) / w, (size.height - 2 * pad) / l).toFloat()
        val ox = (size.width - w.toFloat() * s) / 2; val oy = (size.height - l.toFloat() * s) / 2
        fun X(v: Double) = ox + v.toFloat() * s
        fun Y(v: Double) = oy + v.toFloat() * s
        drawRect(bg, Offset(X(0.0), Y(0.0)), Size(w.toFloat() * s, l.toFloat() * s))
        // شبكة 50 سم
        var g = 50.0
        while (g < w) { drawLine(lineC.copy(alpha = 0.06f), Offset(X(g), Y(0.0)), Offset(X(g), Y(l))); g += 50 }
        g = 50.0
        while (g < l) { drawLine(lineC.copy(alpha = 0.06f), Offset(X(0.0), Y(g)), Offset(X(w), Y(g))); g += 50 }
        val paint = android.graphics.Paint().apply { color = android.graphics.Color.DKGRAY; textSize = 24f; textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }
        rects.sortedBy { if (it.h <= 2) 0 else 1 }.forEach { r ->
            val tl = Offset(X(r.x), Y(r.y)); val sz = Size(r.w.toFloat() * s, r.d.toFloat() * s)
            drawRoundRect(r.color.copy(alpha = if (r.h <= 2) 0.3f else 0.85f), tl, sz, androidx.compose.ui.geometry.CornerRadius(4f, 4f))
            drawRoundRect(lineC.copy(alpha = 0.55f), tl, sz, androidx.compose.ui.geometry.CornerRadius(4f, 4f), style = Stroke(1.5f))
            if (labels && r.label.isNotBlank() && r.w * s > 46 && r.d * s > 20) {
                paint.textSize = min(24f, (r.w * s / max(4, r.label.length) * 1.6).toFloat()).coerceAtLeast(13f)
                drawContext.canvas.nativeCanvas.drawText(r.label, X(r.x + r.w / 2), Y(r.y + r.d / 2) + paint.textSize / 3, paint)
            }
        }
        drawRect(lineC, Offset(X(0.0) - 4, Y(0.0) - 4), Size(w.toFloat() * s + 8, l.toFloat() * s + 8), style = Stroke(8f))
        fun opening(wall: Int, pos: Double, width: Double, isDoor: Boolean) {
            val len = if (wall % 2 == 0) w else l
            val c = pos * len; val a0 = c - width / 2; val a1 = c + width / 2
            val (p0, p1) = when (wall) {
                0 -> Offset(X(a0), Y(0.0)) to Offset(X(a1), Y(0.0)); 2 -> Offset(X(a0), Y(l)) to Offset(X(a1), Y(l))
                3 -> Offset(X(0.0), Y(a0)) to Offset(X(0.0), Y(a1)); else -> Offset(X(w), Y(a0)) to Offset(X(w), Y(a1))
            }
            drawLine(bg, p0, p1, strokeWidth = 12f)
            if (isDoor) {
                val r = (width * s).toFloat()
                val start = when (wall) { 0 -> 0f; 2 -> 270f; 3 -> 0f; else -> 90f }
                drawArc(prim.copy(alpha = 0.6f), start, 90f, true, Offset(p0.x - r, p0.y - r), Size(2 * r, 2 * r), style = Stroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))))
            } else { drawLine(Color(0xFF42A5F5), p0, p1, strokeWidth = 6f); drawLine(Color.White, p0, p1, strokeWidth = 2f) }
        }
        door?.let { opening(it.first, it.second, doorWidth, true) }
        window?.let { opening(it.first, it.second, windowWidth, false) }
        if (showDims) {
            paint.textSize = 26f; paint.color = android.graphics.Color.rgb(25, 118, 210)
            drawContext.canvas.nativeCanvas.drawText(String.format(java.util.Locale.US, "%.2f m", w / 100), X(w / 2), Y(0.0) - 12f, paint)
            drawContext.canvas.nativeCanvas.save()
            drawContext.canvas.nativeCanvas.rotate(-90f, X(0.0) - 14f, Y(l / 2))
            drawContext.canvas.nativeCanvas.drawText(String.format(java.util.Locale.US, "%.2f m", l / 100), X(0.0) - 14f, Y(l / 2), paint)
            drawContext.canvas.nativeCanvas.restore()
        }
    }
}
