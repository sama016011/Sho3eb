package com.sho3eb.app.core.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * تحسين وتجميل الصور على الهاتف:
 * تحسين تلقائي للألوان والتباين، تنعيم البشرة، تنقية التشويش، زيادة الوضوح، إضاءة الصور المظلمة،
 * وعزل الشخص عن الخلفية بنموذج ML Kit (يعمل بدون إنترنت).
 */
object VEnhance {

    fun apply(src: Bitmap, enh: String): Bitmap {
        if (enh.isBlank()) return src
        val set = enh.split(",").toSet()
        var b = if (src.isMutable && src.config == Bitmap.Config.ARGB_8888) src else src.copy(Bitmap.Config.ARGB_8888, true)
        if ("BRIGHT" in set) b = brighten(b)
        if ("AUTO" in set) b = autoLevels(b)
        if ("DENOISE" in set) b = smooth(b, strength = 0.55f, edge = 26)
        if ("BEAUTY" in set) b = beauty(b)
        if ("SHARP" in set) b = sharpen(b)
        if ("PORTRAIT" in set) b = portrait(b)
        return b
    }

    /** نسخة مغبشة سريعة (تصغير ثم تكبير بفلترة ناعمة مرتين) */
    fun blur(b: Bitmap, factor: Int): Bitmap {
        val w = max(2, b.width / factor); val h = max(2, b.height / factor)
        val small = Bitmap.createScaledBitmap(b, w, h, true)
        val mid = Bitmap.createScaledBitmap(small, max(2, b.width / (factor / 2).coerceAtLeast(1)), max(2, b.height / (factor / 2).coerceAtLeast(1)), true)
        return Bitmap.createScaledBitmap(mid, b.width, b.height, true)
    }

    private fun autoLevels(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val hr = IntArray(256); val hg = IntArray(256); val hb = IntArray(256)
        val step = max(1, px.size / 200_000)
        var n = 0
        for (i in px.indices step step) { val c = px[i]; hr[(c shr 16) and 255]++; hg[(c shr 8) and 255]++; hb[c and 255]++; n++ }
        fun lo(hh: IntArray): Int { var a = 0; for (i in 0..255) { a += hh[i]; if (a > n * 0.01) return i }; return 0 }
        fun hi(hh: IntArray): Int { var a = 0; for (i in 255 downTo 0) { a += hh[i]; if (a > n * 0.01) return i }; return 255 }
        val l = min(lo(hr), min(lo(hg), lo(hb))); val hgh = max(hi(hr), max(hi(hg), hi(hb))).coerceAtLeast(l + 40)
        val k = 255f / (hgh - l)
        val m = ColorMatrix(floatArrayOf(k, 0f, 0f, 0f, -l * k, 0f, k, 0f, 0f, -l * k, 0f, 0f, k, 0f, -l * k, 0f, 0f, 0f, 1f, 0f))
        m.postConcat(ColorMatrix().apply { setSaturation(1.15f) })
        return withMatrix(b, m)
    }

    private fun brighten(b: Bitmap): Bitmap {
        // تصحيح جاما يرفع الظلال دون حرق الإضاءات
        val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val lut = IntArray(256) { (255 * Math.pow(it / 255.0, 0.72)).toInt().coerceIn(0, 255) }
        for (i in px.indices) { val c = px[i]; px[i] = (c and -0x1000000) or (lut[(c shr 16) and 255] shl 16) or (lut[(c shr 8) and 255] shl 8) or lut[c and 255] }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); out.setPixels(px, 0, w, 0, 0, w, h); return out
    }

    private fun withMatrix(b: Bitmap, m: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(b, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(m) })
        return out
    }

    /** تنعيم يحافظ على الحواف: يمزج مع النسخة المغبشة حيث الفرق صغير فقط */
    private fun smooth(b: Bitmap, strength: Float, edge: Int, mask: FloatArray? = null): Bitmap {
        val w = b.width; val h = b.height
        val bl = blur(b, 10)
        val a = IntArray(w * h); val c = IntArray(w * h)
        b.getPixels(a, 0, w, 0, 0, w, h); bl.getPixels(c, 0, w, 0, 0, w, h)
        for (i in a.indices) {
            val p = a[i]; val q = c[i]
            val dr = abs(((p shr 16) and 255) - ((q shr 16) and 255)); val dg = abs(((p shr 8) and 255) - ((q shr 8) and 255)); val db = abs((p and 255) - (q and 255))
            val d = (dr + dg + db) / 3
            var t = if (d >= edge) 0f else strength * (1f - d.toFloat() / edge)
            if (mask != null) t *= mask[i]
            if (t <= 0.01f) continue
            val r = (((p shr 16) and 255) * (1 - t) + ((q shr 16) and 255) * t).toInt()
            val g = (((p shr 8) and 255) * (1 - t) + ((q shr 8) and 255) * t).toInt()
            val bb = ((p and 255) * (1 - t) + (q and 255) * t).toInt()
            a[i] = (p and -0x1000000) or (r shl 16) or (g shl 8) or bb
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); out.setPixels(a, 0, w, 0, 0, w, h); return out
    }

    /** تجميل: تنعيم البشرة (داخل الشخص إن أمكن تحديده) مع إشراق ودفء خفيف */
    private fun beauty(b: Bitmap): Bitmap {
        val mask = runCatching { personMask(b) }.getOrNull()
        val s = smooth(b, strength = 0.75f, edge = 34, mask = mask)
        val m = ColorMatrix(floatArrayOf(1.04f, 0f, 0f, 0f, 10f, 0f, 1.02f, 0f, 0f, 8f, 0f, 0f, 1f, 0f, 4f, 0f, 0f, 0f, 1f, 0f))
        return withMatrix(s, m)
    }

    private fun sharpen(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val bl = blur(b, 4)
        val a = IntArray(w * h); val c = IntArray(w * h)
        b.getPixels(a, 0, w, 0, 0, w, h); bl.getPixels(c, 0, w, 0, 0, w, h)
        val k = 0.7f
        for (i in a.indices) {
            val p = a[i]; val q = c[i]
            fun ch(sh: Int): Int { val x = (p shr sh) and 255; val y = (q shr sh) and 255; return (x + (x - y) * k).toInt().coerceIn(0, 255) }
            a[i] = (p and -0x1000000) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); out.setPixels(a, 0, w, 0, 0, w, h); return out
    }

    /** قناع الشخص (0..1 لكل بكسل) بنموذج ML Kit لتقسيم الصورة */
    fun personMask(b: Bitmap): FloatArray {
        val seg = Segmentation.getClient(SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).enableRawSizeMask().build())
        try {
            val m = Tasks.await(seg.process(InputImage.fromBitmap(b, 0)))
            val mw = m.width; val mh = m.height
            val buf = m.buffer.order(ByteOrder.nativeOrder()).asFloatBuffer()
            val raw = FloatArray(mw * mh); buf.rewind(); buf.get(raw)
            if (mw == b.width && mh == b.height) return raw
            val out = FloatArray(b.width * b.height)
            for (y in 0 until b.height) { val sy = y * mh / b.height; for (x in 0 until b.width) out[y * b.width + x] = raw[sy * mw + x * mw / b.width] }
            return out
        } finally { seg.close() }
    }

    /** عزل الشخص وتغبيش الخلفية (تأثير البورتريه) */
    private fun portrait(b: Bitmap): Bitmap {
        val mask = runCatching { personMask(b) }.getOrNull() ?: return b
        val w = b.width; val h = b.height
        val bl = blur(b, 14)
        val a = IntArray(w * h); val c = IntArray(w * h)
        b.getPixels(a, 0, w, 0, 0, w, h); bl.getPixels(c, 0, w, 0, 0, w, h)
        for (i in a.indices) {
            val t = mask[i].coerceIn(0f, 1f); if (t > 0.98f) continue
            val p = a[i]; val q = c[i]
            val r = (((p shr 16) and 255) * t + ((q shr 16) and 255) * (1 - t)).toInt()
            val g = (((p shr 8) and 255) * t + ((q shr 8) and 255) * (1 - t)).toInt()
            val bb = ((p and 255) * t + (q and 255) * (1 - t)).toInt()
            a[i] = (p and -0x1000000) or (r shl 16) or (g shl 8) or bb
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); out.setPixels(a, 0, w, 0, 0, w, h); return out
    }

    /** قص الشخص من الصورة (خلفية شفافة) لاستخدامه كطبقة فوق صورة أخرى */
    fun cutout(b: Bitmap): Bitmap? {
        val mask = runCatching { personMask(b) }.getOrNull() ?: return null
        val w = b.width; val h = b.height
        val a = IntArray(w * h); b.getPixels(a, 0, w, 0, 0, w, h)
        for (i in a.indices) { val t = ((mask[i] - 0.15f) / 0.7f).coerceIn(0f, 1f); a[i] = ((t * 255).toInt() shl 24) or (a[i] and 0xffffff) }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); out.setPixels(a, 0, w, 0, 0, w, h); return out
    }
}
