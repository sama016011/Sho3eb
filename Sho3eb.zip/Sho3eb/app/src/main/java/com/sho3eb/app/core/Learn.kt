package com.sho3eb.app.core

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { c.resume(it) }
    addOnFailureListener { c.resumeWithException(it) }
}

/** الترجمة على الجهاز (ML Kit) + النطق + التعرف على اللغة */
object Translate {
    data class Lang(val code: String, val ar: String, val en: String, val speech: String, val flag: String) { val label get() = tr(ar, en) }

    val langs = listOf(
        Lang(TranslateLanguage.ARABIC, "العربية", "Arabic", "ar-EG", "🇪🇬"),
        Lang(TranslateLanguage.ENGLISH, "الإنجليزية", "English", "en-US", "🇺🇸"),
        Lang(TranslateLanguage.FRENCH, "الفرنسية", "French", "fr-FR", "🇫🇷"),
        Lang(TranslateLanguage.SPANISH, "الإسبانية", "Spanish", "es-ES", "🇪🇸"),
        Lang(TranslateLanguage.GERMAN, "الألمانية", "German", "de-DE", "🇩🇪"),
        Lang(TranslateLanguage.ITALIAN, "الإيطالية", "Italian", "it-IT", "🇮🇹"),
        Lang(TranslateLanguage.TURKISH, "التركية", "Turkish", "tr-TR", "🇹🇷"),
        Lang(TranslateLanguage.URDU, "الأردية", "Urdu", "ur-PK", "🇵🇰"),
        Lang(TranslateLanguage.HINDI, "الهندية", "Hindi", "hi-IN", "🇮🇳"),
        Lang(TranslateLanguage.BENGALI, "البنغالية", "Bengali", "bn-BD", "🇧🇩"),
        Lang(TranslateLanguage.INDONESIAN, "الإندونيسية", "Indonesian", "id-ID", "🇮🇩"),
        Lang(TranslateLanguage.MALAY, "الملايوية", "Malay", "ms-MY", "🇲🇾"),
        Lang(TranslateLanguage.PERSIAN, "الفارسية", "Persian", "fa-IR", "🇮🇷"),
        Lang(TranslateLanguage.RUSSIAN, "الروسية", "Russian", "ru-RU", "🇷🇺"),
        Lang(TranslateLanguage.CHINESE, "الصينية", "Chinese", "zh-CN", "🇨🇳"),
        Lang(TranslateLanguage.JAPANESE, "اليابانية", "Japanese", "ja-JP", "🇯🇵"),
        Lang(TranslateLanguage.KOREAN, "الكورية", "Korean", "ko-KR", "🇰🇷"),
        Lang(TranslateLanguage.PORTUGUESE, "البرتغالية", "Portuguese", "pt-BR", "🇧🇷"),
        Lang(TranslateLanguage.DUTCH, "الهولندية", "Dutch", "nl-NL", "🇳🇱"),
        Lang(TranslateLanguage.GREEK, "اليونانية", "Greek", "el-GR", "🇬🇷"),
        Lang(TranslateLanguage.SWAHILI, "السواحيلية", "Swahili", "sw-KE", "🇰🇪"),
        Lang(TranslateLanguage.TAGALOG, "الفلبينية", "Filipino", "fil-PH", "🇵🇭"),
        Lang(TranslateLanguage.THAI, "التايلاندية", "Thai", "th-TH", "🇹🇭"),
        Lang(TranslateLanguage.VIETNAMESE, "الفيتنامية", "Vietnamese", "vi-VN", "🇻🇳"),
        Lang(TranslateLanguage.HEBREW, "العبرية", "Hebrew", "he-IL", "🇮🇱"),
        Lang(TranslateLanguage.POLISH, "البولندية", "Polish", "pl-PL", "🇵🇱"),
        Lang(TranslateLanguage.SWEDISH, "السويدية", "Swedish", "sv-SE", "🇸🇪"),
        Lang(TranslateLanguage.UKRAINIAN, "الأوكرانية", "Ukrainian", "uk-UA", "🇺🇦")
    )
    fun lang(code: String) = langs.firstOrNull { it.code == code } ?: Lang(code, code, code, code, "🌐")

    var src: String get() = Extras.s("tr_src", TranslateLanguage.ARABIC); set(v) = Extras.ps("tr_src", v)
    var dst: String get() = Extras.s("tr_dst", TranslateLanguage.ENGLISH); set(v) = Extras.ps("tr_dst", v)

    private val clients = HashMap<String, Translator>()

    private fun client(s: String, t: String): Translator = clients.getOrPut("$s>$t") {
        Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build())
    }

    suspend fun isDownloaded(code: String): Boolean = runCatching {
        RemoteModelManager.getInstance().isModelDownloaded(TranslateRemoteModel.Builder(code).build()).awaitTask()
    }.getOrDefault(false)

    suspend fun downloaded(): Set<String> = runCatching {
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java).awaitTask().map { it.language }.toSet()
    }.getOrDefault(emptySet())

    suspend fun deleteModel(code: String) = runCatching { RemoteModelManager.getInstance().deleteDownloadedModel(TranslateRemoteModel.Builder(code).build()).awaitTask() }

    /** ترجمة نص (تنزيل نموذج اللغة تلقائياً أول مرة ~30MB) */
    suspend fun translate(text: String, s: String, t: String, wifiOnly: Boolean = false): String {
        if (text.isBlank()) return ""
        if (s == t) return text
        val c = client(s, t)
        c.downloadModelIfNeeded(DownloadConditions.Builder().apply { if (wifiOnly) requireWifi() }.build()).awaitTask()
        // ترجمة سطراً بسطر للحفاظ على التنسيق
        return text.split("\n").map { line -> if (line.isBlank()) line else c.translate(line).awaitTask() }.joinToString("\n")
    }

    /** التعرف على لغة النص */
    suspend fun detect(text: String): String? = runCatching {
        LanguageIdentification.getClient().identifyLanguage(text).awaitTask().takeIf { it != "und" }?.let { TranslateLanguage.fromLanguageTag(it) }
    }.getOrNull()

    // ---------- السجل ----------
    data class Hist(val s: String, val t: String, val src: String, val dst: String, val time: Long, val fav: Boolean = false)
    var history: List<Hist>
        get() = runCatching { JSONArray(Extras.s("tr_hist", "[]")).let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> Hist(o.optString("s"), o.optString("t"), o.optString("a"), o.optString("b"), o.optLong("time"), o.optBoolean("fav")) } } } }.getOrDefault(emptyList())
        set(v) = Extras.ps("tr_hist", JSONArray().apply { v.take(200).forEach { put(JSONObject().put("s", it.s).put("t", it.t).put("a", it.src).put("b", it.dst).put("time", it.time).put("fav", it.fav)) } }.toString())
    fun addHistory(h: Hist) { history = listOf(h) + history.filter { !(it.s == h.s && it.dst == h.dst) } }
}

/** النطق الصوتي (Text-to-Speech) مع حفظ ملف صوتي للمشاركة */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = mutableListOf<() -> Unit>()
    var rate: Float get() = Extras.i("tts_rate", 95) / 100f; set(v) = Extras.pi("tts_rate", (v * 100).toInt())

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) { pending.forEach { it() }; pending.clear() }
        }
    }

    private fun run(ctx: Context, f: () -> Unit) { init(ctx); if (ready) f() else pending += f }

    fun locale(tag: String): Locale = Locale.forLanguageTag(tag)

    fun available(tag: String): Boolean = runCatching { (tts?.isLanguageAvailable(locale(tag)) ?: -2) >= TextToSpeech.LANG_AVAILABLE }.getOrDefault(false)

    fun speak(ctx: Context, text: String, tag: String, slow: Boolean = false, onDone: (() -> Unit)? = null) = run(ctx) {
        val t = tts ?: return@run
        t.language = locale(tag)
        t.setSpeechRate(if (slow) rate * 0.7f else rate)
        val id = "u" + System.nanoTime()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (utteranceId == id) onDone?.let { android.os.Handler(android.os.Looper.getMainLooper()).post(it) } }
            @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { if (utteranceId == id) onDone?.let { android.os.Handler(android.os.Looper.getMainLooper()).post(it) } }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() { runCatching { tts?.stop() } }

    /** حفظ النطق كملف صوتي (wav) */
    suspend fun toFile(ctx: Context, text: String, tag: String): File? = suspendCancellableCoroutine { c ->
        run(ctx) {
            val t = tts
            if (t == null) { c.resume(null); return@run }
            val dir = File(ctx.filesDir, "tts").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
            val f = File(dir, "voice_" + System.currentTimeMillis() + ".wav")
            val id = "f" + System.nanoTime()
            t.language = locale(tag); t.setSpeechRate(rate)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (utteranceId == id && c.isActive) c.resume(f.takeIf { it.exists() && it.length() > 0 }) }
                @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { if (utteranceId == id && c.isActive) c.resume(null) }
            })
            if (t.synthesizeToFile(text, null, f, id) != TextToSpeech.SUCCESS && c.isActive) c.resume(null)
        }
    }
}

/** محتوى كورس الإنجليزي ومحادثات المواقف (من ملفات assets/learn) */
object Course {
    data class Word(val en: String, val ar: String, val say: String)
    data class Q(val q: String, val options: List<String>, val answer: Int)
    data class Lesson(val id: String, val level: Int, val title: String, val titleEn: String, val goal: String, val words: List<Word>, val phrases: List<Word>, val grammar: String, val examples: List<Word>, val quiz: List<Q>)
    data class Level(val n: Int, val name: String, val nameEn: String, val desc: String, val emoji: String)
    data class Line(val who: Int, val en: String, val ar: String)
    data class Situation(val id: String, val emoji: String, val title: String, val titleEn: String, val roleA: String, val roleB: String, val lines: List<Line>, val words: List<Word>, val tips: String)

    private var cache: Triple<List<Level>, List<Lesson>, List<Situation>>? = null

    private fun words(a: JSONArray?): List<Word> = if (a == null) emptyList() else (0 until a.length()).map { i -> a.getJSONArray(i).let { Word(it.getString(0), it.getString(1), it.optString(2)) } }

    fun load(ctx: Context): Triple<List<Level>, List<Lesson>, List<Situation>> {
        cache?.let { return it }
        val c = JSONObject(ctx.assets.open("learn/course.json").use { it.readBytes().toString(Charsets.UTF_8) })
        val levels = c.getJSONArray("levels").let { a -> (0 until a.length()).map { a.getJSONObject(it).let { o -> Level(o.getInt("n"), o.getString("name"), o.getString("en"), o.getString("desc"), o.getString("emoji")) } } }
        val lessons = c.getJSONArray("lessons").let { a ->
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Lesson(o.getString("id"), o.getInt("level"), o.getString("title"), o.getString("en"), o.optString("goal"), words(o.optJSONArray("words")), words(o.optJSONArray("phrases")),
                    o.optString("grammar"), words(o.optJSONArray("examples")),
                    o.optJSONArray("quiz")?.let { q -> (0 until q.length()).map { j -> q.getJSONObject(j).let { x -> Q(x.getString("q"), x.getJSONArray("o").let { op -> (0 until op.length()).map { op.getString(it) } }, x.getInt("a")) } } } ?: emptyList())
            }
        }
        val r = JSONObject(ctx.assets.open("learn/roleplay.json").use { it.readBytes().toString(Charsets.UTF_8) }).getJSONArray("situations")
        val sits = (0 until r.length()).map { i ->
            val o = r.getJSONObject(i)
            Situation(o.getString("id"), o.getString("emoji"), o.getString("title"), o.getString("en"), o.getString("a"), o.getString("b"),
                o.getJSONArray("lines").let { l -> (0 until l.length()).map { j -> l.getJSONArray(j).let { x -> Line(x.getInt(0), x.getString(1), x.getString(2)) } } },
                words(o.optJSONArray("words")), o.optString("tips"))
        }
        return Triple(levels, lessons, sits).also { cache = it }
    }

    // ---------- التقدم ----------
    var done: Set<String>
        get() = Extras.s("course_done", "").split(",").filter { it.isNotBlank() }.toSet()
        set(v) = Extras.ps("course_done", v.joinToString(","))
    fun score(id: String) = Extras.i("course_sc_$id", -1)
    fun setScore(id: String, s: Int) = Extras.pi("course_sc_$id", maxOf(s, score(id)))
    var streakDay: Long get() = Extras.l("course_streak_day", 0L); set(v) = Extras.pl("course_streak_day", v)
    var streak: Int get() = Extras.i("course_streak", 0); set(v) = Extras.pi("course_streak", v)
    fun touchStreak() {
        val t = Fmt.today()
        when (streakDay) { t -> {}; t - 1 -> { streak += 1; streakDay = t }; else -> { streak = 1; streakDay = t } }
    }
    var practiced: Set<String>
        get() = Extras.s("rp_done", "").split(",").filter { it.isNotBlank() }.toSet()
        set(v) = Extras.ps("rp_done", v.joinToString(","))

    /** نسبة تطابق النطق مع الجملة المطلوبة */
    fun similarity(said: String, target: String): Int {
        fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9' ]"), " ").split(" ").filter { it.isNotBlank() }
        val a = norm(said); val b = norm(target)
        if (b.isEmpty()) return 0
        val bag = a.toMutableList()
        var hit = 0
        b.forEach { w -> val i = bag.indexOf(w); if (i >= 0) { hit++; bag.removeAt(i) } }
        val extra = (a.size - hit).coerceAtLeast(0)
        return ((hit.toDouble() / b.size - extra * 0.05).coerceIn(0.0, 1.0) * 100).toInt()
    }
}
