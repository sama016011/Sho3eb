@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.data.Person
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

private data class Row3(val s: Sale, val sch: List<Installment>, val remaining: Double, val paid: Double)

// ============================ قائمة البيع بالتقسيط ============================
@Composable
fun SaleListScreen(nav: NavController) {
    val dao = remember { appDao() }
    val sales by flowState(emptyList<Sale>()) { dao.salesFlow() }
    val pays by flowState(emptyList<SalePayment>()) { dao.allSalePaymentsFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val pmap = remember(people) { people.associateBy { it.id } }
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(1) }
    val today = remember { LocalDate.now() }

    ScreenScaffold(
        title = tr("البيع بالتقسيط", "Installment sales"),
        fab = {
            ExtendedFloatingActionButton(
                onClick = { nav.navigate("sale_edit/0") },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(tr("بيع جديد", "New sale")) }
            )
        }
    ) { pad ->
        val all = sales.map { s ->
            val sp = pays.filter { it.saleId == s.id }
            Row3(s, saleSchedule(s, sp), saleRemaining(s, sp), sp.sumOf { it.amount })
        }
        val totalRemaining = all.sumOf { it.remaining }
        val totalCollected = all.sumOf { it.paid + it.s.downPayment }
        val profit = all.sumOf { if (it.s.costPrice > 0) it.s.totalPrice - it.s.costPrice else 0.0 }
        val list = all.filter { r ->
            val p = pmap[r.s.personId]
            val overdue = r.sch.any { !it.isPaid && it.due.isBefore(today) }
            (q.isBlank() || r.s.product.contains(q, true) || (p?.name?.contains(q, true) == true)) &&
                when (filter) {
                    1 -> r.remaining > 0.005
                    2 -> overdue
                    3 -> r.remaining <= 0.005
                    else -> true
                }
        }
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("المتبقي للتحصيل", "To collect"), Fmt.money(totalRemaining), Icons.Filled.HourglassBottom, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f))
                    StatCard(tr("المحصّل", "Collected"), Fmt.money(totalCollected), Icons.Filled.CheckCircle, SuccessGreen, Modifier.weight(1f))
                }
            }
            if (profit > 0) item {
                InfoBanner(tr("إجمالي الأرباح المتوقعة: ${Fmt.money(profit)}", "Expected total profit: ${Fmt.money(profit)}"), SuccessGreen)
            }
            item { SearchField(q) { q = it } }
            item {
                FilterRow(listOf(tr("الكل", "All"), tr("جارية", "Active"), tr("متأخرة", "Late"), tr("مكتملة", "Done")), filter) { filter = it }
            }
            if (list.isEmpty()) item { EmptyState(Icons.Filled.ShoppingCart, tr("لا توجد عمليات بيع هنا", "No sales here")) }
            items(list, key = { it.s.id }) { r ->
                val p = pmap[r.s.personId]
                val next = r.sch.firstOrNull { !it.isPaid }
                val late = next != null && next.due.isBefore(today)
                val financed = (r.s.totalPrice - r.s.downPayment).coerceAtLeast(0.01)
                Card(onClick = { nav.navigate("sale/${r.s.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p?.photoPath, p?.name ?: "?", 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.s.product, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(p?.name ?: "-", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            when {
                                r.remaining <= 0.005 -> StatusChip(tr("مكتمل", "Done"), SuccessGreen)
                                late -> StatusChip(tr("متأخر", "Late"), DangerRed)
                                else -> StatusChip(tr("جاري", "Active"), MaterialTheme.colorScheme.tertiary)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { (r.paid / financed).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Spacer(Modifier.height(6.dp))
                        Row {
                            Text(
                                tr("الأقساط: ${r.sch.count { it.isPaid }}/${r.sch.size}", "Paid: ${r.sch.count { it.isPaid }}/${r.sch.size}"),
                                style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f)
                            )
                            Text(tr("المتبقي: ", "Left: ") + Fmt.money(r.remaining), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        }
                        if (next != null) {
                            Text(
                                tr("القسط القادم: ${Fmt.money(next.remaining)} في ${Fmt.date(next.due)}", "Next: ${Fmt.money(next.remaining)} on ${Fmt.date(next.due)}"),
                                style = MaterialTheme.typography.bodySmall, color = if (late) DangerRed else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================ إضافة / تعديل بيع ============================
@Composable
fun SaleEditScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    var existing by remember { mutableStateOf<Sale?>(null) }
    var person by remember { mutableStateOf<Person?>(null) }
    var product by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var down by remember { mutableStateOf("") }
    var count by remember { mutableStateOf("12") }
    var ptype by remember { mutableStateOf(Period.MONTH) }
    var pcount by remember { mutableStateOf("1") }
    var start by remember { mutableLongStateOf(LocalDate.now().plusMonths(1).toEpochDay()) }
    var notes by remember { mutableStateOf("") }
    var reminder by remember { mutableStateOf(true) }

    LaunchedEffect(id) {
        if (id != 0L) dao.sale(id)?.let { s ->
            existing = s
            person = dao.person(s.personId)
            product = s.product; total = Fmt.plain(s.totalPrice); cost = if (s.costPrice > 0) Fmt.plain(s.costPrice) else ""
            down = if (s.downPayment > 0) Fmt.plain(s.downPayment) else ""; count = s.installmentsCount.toString()
            ptype = s.periodType; pcount = s.periodCount.toString(); start = s.startDate; notes = s.notes; reminder = s.reminderEnabled
        }
    }

    val t = Fmt.parse(total) ?: 0.0
    val dp = Fmt.parse(down) ?: 0.0
    val n = Fmt.parseInt(count) ?: 0
    val preview = if (n > 0 && t > dp) (t - dp) / n else 0.0

    fun save() {
        val c = Fmt.parseInt(pcount)
        when {
            person == null -> { toast(ctx, tr("اختر العميل", "Choose the customer")); return }
            product.isBlank() -> { toast(ctx, tr("أدخل اسم المنتج", "Enter product name")); return }
            t <= 0 -> { toast(ctx, tr("أدخل السعر الإجمالي", "Enter total price")); return }
            dp >= t -> { toast(ctx, tr("المقدم يجب أن يكون أقل من السعر", "Down payment must be less than the price")); return }
            n < 1 -> { toast(ctx, tr("أدخل عدد الأقساط", "Enter number of installments")); return }
            c == null || c < 1 -> { toast(ctx, tr("أدخل مدة صحيحة", "Enter a valid period")); return }
        }
        scope.launch {
            val s = Sale(
                id = id, personId = person!!.id, product = product.trim(), totalPrice = t,
                costPrice = Fmt.parse(cost) ?: 0.0, downPayment = dp, installmentsCount = n,
                periodType = ptype, periodCount = c!!, startDate = start, notes = notes.trim(),
                reminderEnabled = reminder, createdAt = existing?.createdAt ?: System.currentTimeMillis()
            )
            val sid = if (id == 0L) dao.insertSale(s) else { dao.updateSale(s); id }
            toast(ctx, tr("تم الحفظ", "Saved"))
            nav.popBackStack()
            if (id == 0L) nav.navigate("sale/$sid")
        }
    }

    ScreenScaffold(
        title = if (id == 0L) tr("بيع بالتقسيط جديد", "New installment sale") else tr("تعديل البيع", "Edit sale"),
        onBack = { nav.popBackStack() },
        actions = { TextButton(onClick = { save() }) { Text(tr("حفظ", "Save"), fontWeight = FontWeight.Bold) } }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PersonSelector(person, tr("اختيار العميل (يدوي / جهات الاتصال)", "Choose customer (manual / contacts)")) { person = it }
            OutlinedTextField(product, { product = it }, label = { Text(tr("المنتج / السلعة", "Product")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Inventory2, null) }, modifier = Modifier.fillMaxWidth())
            MoneyField(total, { total = it }, tr("سعر البيع الإجمالي", "Total selling price"))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MoneyField(down, { down = it }, tr("الدفعة المقدمة", "Down payment"), Modifier.weight(1f))
                MoneyField(cost, { cost = it }, tr("سعر التكلفة (اختياري)", "Cost (optional)"), Modifier.weight(1f))
            }
            NumberField(count, { count = it }, tr("عدد الأقساط", "Number of installments"))
            PeriodSelector(ptype, pcount, { ptype = it }, { pcount = it })
            DateField(tr("موعد القسط الأول", "First installment date"), start, { d -> if (d != null) start = d })
            if (preview > 0) {
                val profit = (Fmt.parse(cost) ?: 0.0).let { if (it > 0) t - it else null }
                InfoBanner(
                    tr("قيمة القسط: ${Fmt.money(preview)} × $n", "Installment: ${Fmt.money(preview)} × $n") +
                        (profit?.let { tr(" • الربح: ${Fmt.money(it)}", " • Profit: ${Fmt.money(it)}") } ?: ""),
                    MaterialTheme.colorScheme.tertiary
                )
            }
            SwitchRow(tr("تنبيهات الأقساط", "Installment reminders"), null, reminder, Icons.Filled.Notifications) { reminder = it }
            NotesField(notes) { notes = it }
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(tr("حفظ", "Save")) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ============================ تفاصيل البيع ============================
@Composable
fun SaleDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val sale by flowState<Sale?>(null, id) { dao.saleFlow(id) }
    val pays by flowState(emptyList<SalePayment>(), id) { dao.salePaymentsFlow(id) }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var showPay by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<SalePayment?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val today = remember { LocalDate.now() }

    val s = sale
    if (s == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val p = people.firstOrNull { it.id == s.personId }
    val sch = remember(s, pays) { saleSchedule(s, pays) }
    val remaining = saleRemaining(s, pays)
    val paid = pays.sumOf { it.amount }
    val next = sch.firstOrNull { !it.isPaid }

    ScreenScaffold(
        title = s.product,
        onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(p?.phone) { c -> Reports.sale(c, s, p, pays) }
            IconButton(onClick = { nav.navigate("sale_edit/${s.id}") }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, null) }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p?.photoPath, p?.name ?: "?", 50.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p?.name ?: "-", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                if (!p?.phone.isNullOrBlank()) Text(p?.phone ?: "", style = MaterialTheme.typography.bodySmall)
                            }
                            if (p != null && p.phone.isNotBlank()) {
                                IconButton(onClick = { Share.dial(ctx, p.phone) }) { Icon(Icons.Filled.Call, null) }
                                IconButton(onClick = {
                                    val nx = next
                                    val msg = if (nx != null) Messages.installment(p.name, s.product, nx.remaining, Fmt.date(nx.due), remaining)
                                    else tr("السلام عليكم ${p.name}، شكراً لإتمام سداد أقساط ${s.product} 🌹", "Hello ${p.name}, thank you for completing your ${s.product} installments 🌹")
                                    Share.whatsappMessage(ctx, p.phone, msg)
                                }) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(tr("المتبقي", "Remaining"), color = MaterialTheme.colorScheme.onTertiaryContainer)
                        Text(
                            Fmt.money(remaining), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
                            color = if (remaining > 0.005) MaterialTheme.colorScheme.onTertiaryContainer else SuccessGreen
                        )
                        KeyValue(tr("السعر الإجمالي", "Total price"), Fmt.money(s.totalPrice))
                        if (s.downPayment > 0) KeyValue(tr("المقدم", "Down payment"), Fmt.money(s.downPayment))
                        KeyValue(tr("المدفوع من الأقساط", "Installments paid"), Fmt.money(paid), SuccessGreen)
                        KeyValue(tr("القسط", "Installment"), "${Fmt.money(installmentAmount(s))} • ${Fmt.periodLabel(s.periodType, s.periodCount)}")
                        KeyValue(tr("الأقساط المدفوعة", "Paid installments"), "${sch.count { it.isPaid }}/${sch.size}")
                        if (s.costPrice > 0) KeyValue(tr("الربح", "Profit"), Fmt.money(s.totalPrice - s.costPrice), SuccessGreen)
                    }
                }
            }
            if (s.notes.isNotBlank()) item { InfoBanner(s.notes) }
            if (remaining > 0.005) item {
                Button(onClick = { showPay = true }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Icon(Icons.Filled.Payments, null); Spacer(Modifier.width(8.dp))
                    Text(tr("تسجيل دفعة", "Record payment") + (next?.let { " (${Fmt.money(it.remaining)})" } ?: ""))
                }
            }
            item {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(tr("جدول الأقساط", "Schedule")) })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(tr("الدفعات (${pays.size})", "Payments (${pays.size})")) })
                }
            }
            if (tab == 0) {
                items(sch, key = { "i${it.index}" }) { i ->
                    val (txt, col) = when {
                        i.isPaid -> tr("مدفوع", "Paid") to SuccessGreen
                        i.paid > 0 -> tr("جزئي", "Partial") to WarnAmber
                        i.due.isBefore(today) -> tr("متأخر", "Late") to DangerRed
                        else -> tr("قادم", "Upcoming") to MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i.index + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.width(28.dp))
                            Column(Modifier.weight(1f)) {
                                Text(Fmt.money(i.amount), fontWeight = FontWeight.Bold)
                                Text(
                                    Fmt.date(i.due) + if (i.paid > 0 && !i.isPaid) tr(" • مدفوع ${Fmt.money(i.paid)}", " • paid ${Fmt.money(i.paid)}") else "",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusChip(txt, col)
                        }
                    }
                }
            } else {
                if (pays.isEmpty()) item { EmptyState(Icons.Filled.ReceiptLong, tr("لا توجد دفعات بعد", "No payments yet")) }
                items(pays.reversed(), key = { it.id }) { pay ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconCircle(Icons.Filled.CheckCircle, SuccessGreen, 36.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(Fmt.money(pay.amount), fontWeight = FontWeight.Bold)
                                Text(Fmt.date(pay.date), style = MaterialTheme.typography.bodySmall)
                                if (pay.note.isNotBlank()) Text(pay.note, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { delPay = pay }) { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)) }
                        }
                    }
                }
            }
        }
    }

    if (showPay) AmountDialog(
        title = tr("تسجيل دفعة", "Record payment"),
        initial = next?.remaining,
        info = tr("المتبقي الكلي: ${Fmt.money(remaining)}", "Total remaining: ${Fmt.money(remaining)}"),
        maxAmount = remaining,
        onDismiss = { showPay = false }
    ) { amount, date, _, note ->
        scope.launch {
            dao.insertSalePayment(SalePayment(saleId = s.id, amount = amount, date = date, note = note))
            showPay = false
            if (round2(remaining - amount) <= 0.005) toast(ctx, tr("تم سداد جميع الأقساط 🎉", "All installments paid 🎉"))
        }
    }
    delPay?.let { pay ->
        ConfirmDialog(
            title = tr("حذف الدفعة", "Delete payment"),
            text = tr("حذف دفعة بمبلغ ${Fmt.money(pay.amount)}؟", "Delete payment of ${Fmt.money(pay.amount)}?"),
            confirmText = tr("حذف", "Delete"),
            onDismiss = { delPay = null }
        ) { scope.launch { dao.deleteSalePayment(pay.id) } }
    }
    if (confirmDelete) ConfirmDialog(
        title = tr("حذف عملية البيع", "Delete sale"),
        text = tr("سيتم حذف عملية البيع وكل دفعاتها نهائياً.", "The sale and all its payments will be permanently deleted."),
        confirmText = tr("حذف", "Delete"),
        onDismiss = { confirmDelete = false }
    ) { scope.launch { dao.deleteSaleFull(s.id); nav.popBackStack() } }
}
