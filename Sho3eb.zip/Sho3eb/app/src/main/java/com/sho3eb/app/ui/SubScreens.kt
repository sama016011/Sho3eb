@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch
import java.time.LocalDate

// =====================================================================
//                    الاشتراكات والفواتير الدورية
// =====================================================================
@Composable
fun SubsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val subs by flowState(emptyList<Subscription>()) { dao.subscriptionsFlow() }
    val pays by flowState(emptyList<SubPayment>()) { dao.subPaymentsFlow() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Subscription?>(null) }
    var pay by remember { mutableStateOf<Subscription?>(null) }
    var delP by remember { mutableStateOf<SubPayment?>(null) }
    val active = subs.filter { it.active }
    val sm = subs.associateBy { it.id }
    val month = LivingAuto.monthRange()

    ScreenScaffold(
        title = tr("الاشتراكات والفواتير", "Subscriptions & bills"), onBack = { nav.popBackStack() },
        actions = { PdfShareButton(null, doc = { Docs.subs(subs, pays) }) { c -> Reports.doc(c, Docs.subs(subs, pays)) } },
        fab = { if (tab == 0) ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("اشتراك", "Subscription")) }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("الاشتراكات", "Subscriptions")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("سجل الدفع", "Payments")) })
            }
            LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard(tr("شهرياً", "Monthly"), Fmt.money(active.sumOf { Subs.monthly(it) }), Icons.Filled.CalendarMonth, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        StatCard(tr("سنوياً", "Yearly"), Fmt.money(active.sumOf { Subs.yearly(it) }), Icons.Filled.Event, WarnAmber, Modifier.weight(1f))
                        StatCard(tr("دُفع هذا الشهر", "Paid this month"), Fmt.money(pays.filter { it.date in month }.sumOf { it.amount }), Icons.Filled.CheckCircle, SuccessGreen, Modifier.weight(1f))
                    }
                }
                if (tab == 0) {
                    if (subs.isEmpty()) item { EmptyState(Icons.Filled.Autorenew, tr("أضف الإنترنت والجوال والكهرباء والمنصات والنادي... وسيذكّرك التطبيق قبل كل موعد ويسجّلها في مصاريف المعيشة.", "Add internet, mobile, utilities, streaming... get reminders and auto-logging.")) }
                    items(subs.sortedWith(compareBy({ !it.active }, { it.nextDate })), key = { it.id }) { s ->
                        val c = Subs.cat(s.category)
                        val left = Subs.daysLeft(s)
                        val color = when { !s.active -> MaterialTheme.colorScheme.outline; left < 0 -> DangerRed; left <= s.remindDays -> WarnAmber; else -> SuccessGreen }
                        Card(onClick = { edit = s }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(c.emoji, fontSize = 26.sp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(s.name, fontWeight = FontWeight.Bold)
                                    Text(Fmt.money(s.amount) + " • " + Rent.periodName(s.periodMonths) + if (s.variable) tr(" • متغيرة", " • variable") else "", style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        if (!s.active) tr("موقوف", "Paused") else Fmt.date(s.nextDate) + " • " + when { left < 0 -> tr("متأخر ${-left} يوم", "${-left} d overdue"); left == 0 -> tr("اليوم", "today"); else -> tr("بعد $left يوم", "in $left d") },
                                        color = color, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold
                                    )
                                }
                                if (s.active) FilledTonalButton(onClick = { pay = s }) { Text(tr("دفع", "Pay")) }
                            }
                        }
                    }
                } else {
                    if (pays.isEmpty()) item { Text(tr("لا توجد مدفوعات بعد", "No payments yet"), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(pays, key = { "p${it.id}" }) { p ->
                        val s = sm[p.subId]
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(s?.let { Subs.cat(it.category).emoji } ?: "📦", fontSize = 20.sp)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text((s?.name ?: "-") + " • " + Fmt.money(p.amount), fontWeight = FontWeight.SemiBold)
                                    Text(Fmt.date(p.date) + if (p.note.isNotBlank()) " • " + p.note else "", style = MaterialTheme.typography.bodySmall)
                                }
                                AttachmentButton(Attachments.SUB_PAY, p.id)
                                IconButton(onClick = { delP = p }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                            }
                        }
                    }
                }
            }
        }
    }
    if (add) SubDialog(null) { add = false }
    edit?.let { s -> SubDialog(s) { edit = null } }
    pay?.let { s -> SubPayDialog(s) { pay = null } }
    delP?.let { p ->
        ConfirmDialog(tr("حذف الدفعة", "Delete payment"), tr("حذف دفعة ${Fmt.money(p.amount)}؟ لن يرجع موعد الاستحقاق تلقائياً.", "Delete payment? The due date won't roll back."), onDismiss = { delP = null }) {
            delP = null
            scope.launch { Attachments.deleteFor(Attachments.SUB_PAY, p.id); dao.deleteLinkedTx(AccountTx.SRC_SUB, p.id); LivingLink.remove(LivingLink.SUB, p.id); dao.deleteSubPayment(p.id) }
        }
    }
}

@Composable
private fun SubDialog(existing: Subscription?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var cat by remember { mutableStateOf(existing?.category ?: "INTERNET") }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var amount by remember { mutableStateOf(existing?.amount?.let { Fmt.plain(it) } ?: "") }
    var period by remember { mutableIntStateOf(existing?.periodMonths ?: 1) }
    var next by remember { mutableStateOf(existing?.nextDate ?: LocalDate.now().plusMonths(1).withDayOfMonth(1).toEpochDay()) }
    var variable by remember { mutableStateOf(existing?.variable ?: false) }
    var remind by remember { mutableIntStateOf(existing?.remindDays ?: 3) }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var toLiving by remember { mutableStateOf(existing?.toLiving ?: true) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var confirmDel by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("اشتراك / فاتورة دورية", "Subscription / bill") else existing.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HChips { Subs.cats.forEach { (c, _) -> FilterChip(cat == c.key, { cat = c.key; if (c.key in listOf("ELECTRIC", "WATER", "GAS")) variable = true }, label = { Text(c.emoji + " " + c.label) }) } }
                OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم (مثل: STC فايبر، نتفلكس)", "Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                MoneyField(amount, { amount = it }, if (variable) tr("المبلغ التقريبي", "Approx. amount") else tr("المبلغ", "Amount"))
                HChips { Subs.periods.forEach { m -> FilterChip(period == m, { period = m }, label = { Text(Rent.periodName(m)) }) } }
                DateField(tr("موعد الدفع القادم", "Next due date"), next, { d -> if (d != null) next = d })
                SwitchRow(tr("مبلغ متغير (فاتورة)", "Variable amount (bill)"), tr("تُدخل المبلغ الفعلي عند الدفع", "Enter the actual amount when paying"), variable) { variable = it }
                Text(tr("التذكير قبل الموعد:", "Remind before:"), style = MaterialTheme.typography.labelLarge)
                HChips { listOf(0, 1, 3, 7).forEach { d -> FilterChip(remind == d, { remind = d }, label = { Text(if (d == 0) tr("يوم الموعد", "On the day") else tr("$d أيام", "$d days")) }) } }
                SwitchRow(tr("تسجيل في مصاريف المعيشة عند الدفع", "Record in living expenses"), Living.cat(Living.EXPENSE, Subs.livingCat(cat)).label, toLiving) { toLiving = it }
                if (existing != null) SwitchRow(tr("نشط", "Active"), null, active) { active = it }
                NotesField(notes) { notes = it }
                if (existing != null) TextButton(onClick = { confirmDel = true }) { Text(tr("حذف الاشتراك", "Delete"), color = DangerRed) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Fmt.parse(amount)
                if (a == null || a < 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                val s = Subscription(name = name.trim().ifBlank { Subs.cat(cat).label }, category = cat, amount = a, periodMonths = period, nextDate = next, variable = variable, remindDays = remind, active = active, toLiving = toLiving, notes = notes.trim())
                scope.launch { if (existing == null) dao.insertSubscription(s) else dao.updateSubscription(s.copy(id = existing.id, accountId = existing.accountId, createdAt = existing.createdAt)); onDismiss() }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
    if (confirmDel && existing != null) ConfirmDialog(tr("حذف الاشتراك", "Delete"), tr("حذف «${existing.name}» وسجل مدفوعاته والحركات المرتبطة؟", "Delete with payment history and linked entries?"), onDismiss = { confirmDel = false }) {
        scope.launch { dao.deleteSubscriptionFull(existing.id); confirmDel = false; onDismiss() }
    }
}

@Composable
private fun SubPayDialog(s: Subscription, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var amount by remember { mutableStateOf(Fmt.plain(s.amount)) }
    var date by remember { mutableStateOf(Fmt.today()) }
    var note by remember { mutableStateOf("") }
    var toLiving by remember { mutableStateOf(s.toLiving) }
    val pending = remember { mutableStateListOf<Uri>() }
    val post = remember { mutableStateOf(s.accountId ?: Posting.lastAccount("sub")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("دفع ", "Pay ") + s.name) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MoneyField(amount, { amount = it }, tr("المبلغ المدفوع", "Amount paid"))
                DateField(tr("تاريخ الدفع", "Paid on"), date, { d -> if (d != null) date = d })
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة (رقم الفاتورة...)", "Note (bill no...)")) }, modifier = Modifier.fillMaxWidth())
                Text(tr("الموعد القادم سيصبح: ", "Next due becomes: ") + Fmt.date(Subs.advance(s)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                SwitchRow(tr("تسجيل في مصاريف المعيشة", "Record in living expenses"), null, toLiving) { toLiving = it }
                AccountPickRow(post, tr("خصم من حساب (اختياري)", "Withdraw from account (optional)"))
                PendingAttachRow(pending)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Fmt.parse(amount)
                if (a == null || a <= 0) { toast(ctx, tr("أدخل المبلغ", "Enter amount")); return@TextButton }
                scope.launch {
                    val pid = dao.insertSubPayment(SubPayment(subId = s.id, amount = a, date = date, note = note.trim()))
                    Attachments.addAll(ctx, Attachments.SUB_PAY, pid, pending.toList())
                    dao.updateSubscription(s.copy(nextDate = Subs.advance(s), amount = if (s.variable) s.amount else a, accountId = post.value))
                    Posting.setLastAccount("sub", post.value)
                    Posting.post(post.value, AccountTx.SRC_SUB, pid, false, a, date, s.name)
                    if (toLiving) LivingLink.addExpense(ctx, LivingLink.SUB, pid, s.name, Subs.livingCat(s.category), a, date, note.trim())
                    toast(ctx, tr("تم الدفع ✅", "Paid ✅"))
                    onDismiss()
                }
            }) { Text(tr("تأكيد", "Confirm")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
