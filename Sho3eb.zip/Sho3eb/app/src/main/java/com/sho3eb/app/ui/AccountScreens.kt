@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.data.Person
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

// ============================ قائمة الحسابات ============================
@Composable
fun AccountListScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    var kindF by remember { mutableStateOf("ALL") }
    val accounts by flowState(emptyList<Account>()) { dao.accountsFlow() }
    val txs by flowState(emptyList<AccountTx>()) { dao.allAccountTxFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val pmap = remember(people) { people.associateBy { it.id } }
    var q by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }

    ScreenScaffold(
        title = tr("الحسابات", "Accounts"),
        onBack = { nav.popBackStack() },
        fab = {
            ExtendedFloatingActionButton(
                onClick = { showNew = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(tr("حساب جديد", "New account")) }
            )
        }
    ) { pad ->
        val byAcc = txs.groupBy { it.accountId }
        val total = accounts.sumOf { accountBalance(byAcc[it.id] ?: emptyList()) }
        val list = accounts.filter { a -> kindF == "ALL" || a.kind == kindF }.filter { a ->
            q.isBlank() || a.bank.contains(q, true) || a.cardLast4.contains(q) || a.name.contains(q, true) || (a.personId?.let { pmap[it]?.name?.contains(q, true) } == true)
        }
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Filled.AccountBalanceWallet, MaterialTheme.colorScheme.primary, 48.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(tr("إجمالي أرصدة الحسابات", "Total of all balances"), color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                Fmt.money(total), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                                color = if (total < 0) DangerRed else MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(tr("${accounts.size} حساب", "${accounts.size} accounts"), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item { SearchField(q) { q = it } }
            if (accounts.any { it.kind != Banks.CASH }) item {
                HChips {
                    FilterChip(kindF == "ALL", { kindF = "ALL" }, label = { Text(tr("الكل", "All")) })
                    Banks.kinds.forEach { k ->
                        val n = accounts.count { it.kind == k.key }
                        if (n > 0) FilterChip(kindF == k.key, { kindF = k.key }, label = { Text(k.emoji + " " + k.label + " ($n)") })
                    }
                }
            }
            if (list.isEmpty()) item {
                EmptyState(Icons.Filled.AccountBalanceWallet, tr("لا توجد حسابات. اضغط \"حساب جديد\".", "No accounts yet. Tap \"New account\"."))
            }
            items(list, key = { it.id }) { a ->
                val p = a.personId?.let { pmap[it] }
                val at = byAcc[a.id] ?: emptyList()
                val bal = accountBalance(at)
                Card(onClick = { nav.navigate("account/${a.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (p != null) Avatar(p.photoPath, p.name, 46.dp)
                        else Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) { Text(Banks.emoji(a), fontSize = 28.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Banks.subtitle(a).takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = if (Banks.isExpired(a.cardExpiry)) DangerRed else MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            Text(
                                (p?.name ?: tr("بدون جهة اتصال", "No contact")) + " • " + tr("${at.size} حركة", "${at.size} txns"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            at.maxByOrNull { it.date }?.let {
                                Text(tr("آخر حركة: ", "Last: ") + Fmt.date(it.date), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                Fmt.money(bal), fontWeight = FontWeight.ExtraBold,
                                color = if (bal < 0) DangerRed else MaterialTheme.colorScheme.primary
                            )
                            if (Banks.canPay(a)) TextButton(onClick = { if (!Banks.pay(ctx, a)) toast(ctx, tr("تعذر فتح تطبيق البنك", "Couldn't open bank app")) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(tr("💳 ادفع", "💳 Pay")) }
                        }
                    }
                }
            }
        }
    }
    if (showNew) AccountEditDialog(null, null, onDismiss = { showNew = false }) { id ->
        showNew = false
        nav.navigate("account/$id")
    }
}

// ============================ إنشاء / تعديل حساب ============================
@Composable
fun AccountEditDialog(existing: Account?, existingPerson: Person?, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var person by remember { mutableStateOf(existingPerson) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var opening by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(existing?.kind ?: Banks.CASH) }
    var bank by remember { mutableStateOf(existing?.bank ?: "") }
    var iban by remember { mutableStateOf(existing?.iban ?: "") }
    var last4 by remember { mutableStateOf(existing?.cardLast4 ?: "") }
    var exp by remember { mutableStateOf(existing?.cardExpiry ?: "") }
    var limit by remember { mutableStateOf(existing?.creditLimit?.takeIf { it > 0 }?.let { Fmt.plain(it) } ?: "") }
    var dueDay by remember { mutableStateOf(existing?.dueDay?.takeIf { it > 0 }?.toString() ?: "") }
    var payApp by remember { mutableStateOf(existing?.payApp ?: "") }
    var payLink by remember { mutableStateOf(existing?.payLink ?: "") }
    var pickApp by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("حساب جديد", "New account") else tr("تعديل الحساب", "Edit account")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    name, { name = it }, label = { Text(tr("اسم الحساب", "Account name")) }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.AccountBalanceWallet, null) }, modifier = Modifier.fillMaxWidth()
                )
                HChips { Banks.kinds.forEach { k -> FilterChip(kind == k.key, { kind = k.key }, label = { Text(k.emoji + " " + k.label) }) } }
                if (kind != Banks.CASH) {
                    OutlinedTextField(bank, { bank = it }, label = { Text(tr("البنك / المحفظة", "Bank / wallet")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (bank.isBlank()) HChips { Banks.commonBanks.forEach { b -> AssistChip({ bank = b }, label = { Text(b) }) } }
                }
                if (kind == Banks.BANK) OutlinedTextField(iban, { iban = it.uppercase().filter { c -> c.isLetterOrDigit() || c == ' ' }.take(40) }, label = { Text(tr("رقم الآيبان / الحساب (اختياري)", "IBAN / account no. (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (kind == Banks.CARD || kind == Banks.BANK) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(last4, { last4 = it.filter { c -> c.isDigit() }.take(4) }, label = { Text(tr("آخر 4 أرقام", "Last 4 digits")) }, singleLine = true, modifier = Modifier.weight(1f),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword))
                        OutlinedTextField(exp, { exp = Banks.expiry(it) }, label = { Text("MM/YY") }, singleLine = true, modifier = Modifier.weight(1f),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number))
                    }
                    Text(tr("🔒 لا يُحفظ رقم البطاقة كاملاً ولا الرمز السري أو CVV، فقط آخر 4 أرقام للتمييز.", "🔒 The full card number, PIN and CVV are never stored — only the last 4 digits."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (kind == Banks.CARD) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyField(limit, { limit = it }, tr("الحد الائتماني", "Credit limit"), Modifier.weight(1f))
                    NumberField(dueDay, { dueDay = it.filter { c -> c.isDigit() }.take(2) }, tr("يوم السداد", "Due day"), Modifier.weight(1f))
                }
                if (kind != Banks.CASH) {
                    OutlinedButton(onClick = { pickApp = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Apps, null); Spacer(Modifier.width(6.dp))
                        Text(if (payApp.isBlank()) tr("اختيار تطبيق البنك للدفع", "Choose bank app for paying") else Banks.appLabel(ctx, payApp), maxLines = 1)
                    }
                    OutlinedTextField(payLink, { payLink = it.trim() }, label = { Text(tr("رابط الدفع / موقع البنك (اختياري)", "Payment link / bank site (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Text(tr("ربط بجهة تواصل (اختياري)", "Link to a contact (optional)"), style = MaterialTheme.typography.labelLarge)
                PersonSelector(person, tr("اختيار جهة تواصل", "Choose a contact")) { person = it }
                if (person != null) TextButton(onClick = { person = null }) { Text(tr("إلغاء الربط", "Unlink contact")) }
                if (existing == null) MoneyField(opening, { opening = it }, tr("رصيد افتتاحي (اختياري)", "Opening balance (optional)"))
                OutlinedTextField(notes, { notes = it }, label = { Text(tr("ملاحظات", "Notes")) }, minLines = 2, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) {
                    toast(ctx, tr("أدخل اسم الحساب", "Enter account name")); return@TextButton
                }
                scope.launch {
                    val d = Account(name = name.trim(), personId = person?.id, notes = notes.trim(), kind = kind,
                        bank = if (kind == Banks.CASH) "" else bank.trim(), iban = if (kind == Banks.BANK) iban.trim() else "",
                        cardLast4 = if (kind == Banks.CARD || kind == Banks.BANK) Banks.digits4(last4) else "", cardExpiry = if (kind == Banks.CARD || kind == Banks.BANK) exp else "",
                        creditLimit = if (kind == Banks.CARD) Fmt.parse(limit) ?: 0.0 else 0.0, dueDay = if (kind == Banks.CARD) (dueDay.toIntOrNull() ?: 0).coerceIn(0, 31) else 0,
                        payApp = if (kind == Banks.CASH) "" else payApp, payLink = if (kind == Banks.CASH) "" else payLink)
                    if (existing == null) {
                        val id = dao.insertAccount(d)
                        val ob = Fmt.parse(opening) ?: 0.0
                        if (ob != 0.0) dao.insertAccountTx(
                            AccountTx(
                                accountId = id, type = if (ob > 0) AccountTx.IN else AccountTx.OUT, amount = kotlin.math.abs(ob),
                                date = Fmt.today(), note = tr("رصيد افتتاحي", "Opening balance")
                            )
                        )
                        onSaved(id)
                    } else {
                        dao.updateAccount(d.copy(id = existing.id, createdAt = existing.createdAt))
                        onSaved(existing.id)
                    }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
    if (pickApp) BankAppPicker({ pickApp = false }) { payApp = it; pickApp = false }
}

@Composable
fun BankAppPicker(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Banks.App>?>(null) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Banks.installedApps(ctx) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("تطبيق البنك / المحفظة", "Bank / wallet app")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SearchField(q) { q = it }
                val list = apps
                if (list == null) CircularProgressIndicator()
                else LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(list.filter { q.isBlank() || it.label.contains(q, true) || it.pkg.contains(q, true) }, key = { it.pkg }) { a ->
                        Row(Modifier.fillMaxWidth().clickable { onPick(a.pkg) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            val bmp = remember(a.pkg) { a.icon?.let { runCatching { it.toBitmap(96, 96).asImageBitmap() }.getOrNull() } }
                            if (bmp != null) Image(bmp, null, Modifier.size(36.dp)) else Icon(Icons.Filled.Apps, null, Modifier.size(36.dp))
                            Spacer(Modifier.width(10.dp))
                            Column { Text(a.label, fontWeight = FontWeight.SemiBold); Text(a.pkg, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onPick("") }) { Text(tr("بدون تطبيق", "No app")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// ============================ كشف الحساب ============================
@Composable
fun AccountDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val account by flowState<Account?>(null, id) { dao.accountFlow(id) }
    val txs by flowState(emptyList<AccountTx>(), id) { dao.accountTxFlow(id) }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var addType by remember { mutableStateOf<String?>(null) }
    var editLine by remember { mutableStateOf<AccountLine?>(null) }
    var deleteLine by remember { mutableStateOf<AccountLine?>(null) }
    var showEdit by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var filter by remember { mutableIntStateOf(0) }
    var from by remember { mutableStateOf<Long?>(null) }
    var to by remember { mutableStateOf<Long?>(null) }
    var showRange by remember { mutableStateOf(false) }

    val a = account
    if (a == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val p = a.personId?.let { pid -> people.firstOrNull { it.id == pid } }
    val lines = remember(txs) { accountLines(txs) }
    val balance = lines.lastOrNull()?.after ?: 0.0
    val today = LocalDate.now()
    // حدود الفترة حسب الفلتر
    val (rFrom, rTo) = when (filter) {
        1 -> today.withDayOfMonth(1).toEpochDay() to null
        2 -> today.minusDays(30).toEpochDay() to null
        3 -> from to to
        else -> null to null
    }
    val shown = lines.filter { l -> (rFrom == null || l.tx.date >= rFrom) && (rTo == null || l.tx.date <= rTo) }
    val inSum = shown.filter { it.tx.type == AccountTx.IN }.sumOf { it.tx.amount }
    val outSum = shown.filter { it.tx.type == AccountTx.OUT }.sumOf { it.tx.amount }

    ScreenScaffold(
        title = a.name,
        onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(p?.phone, doc = { Docs.account(a, p, txs, rFrom, rTo) }) { c -> Reports.account(c, a, p, txs, rFrom, rTo) }
            IconButton(onClick = { showEdit = true }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, null) }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        if (p != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Avatar(p.photoPath, p.name, 46.dp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Bold)
                                    if (p.phone.isNotBlank()) Text(p.phone, style = MaterialTheme.typography.bodySmall)
                                }
                                if (p.phone.isNotBlank()) {
                                    IconButton(onClick = { Share.dial(ctx, p.phone) }) { Icon(Icons.Filled.Call, null) }
                                    IconButton(onClick = { Share.whatsappMessage(ctx, p.phone, Messages.accountBalance(a.name, balance)) }) {
                                        Icon(Icons.Filled.Chat, null, tint = WhatsGreen)
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                        }
                        if (a.kind != Banks.CASH) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(Banks.emoji(a) + " " + Banks.kind(a.kind).label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                if (Banks.canPay(a)) Button(onClick = { if (!Banks.pay(ctx, a)) toast(ctx, tr("تعذر فتح تطبيق البنك", "Couldn't open bank app")) }) { Text(tr("💳 ادفع الآن", "💳 Pay now")) }
                            }
                            Banks.subtitle(a).takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                            if (a.iban.isNotBlank()) Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("IBAN: " + Banks.maskIban(a.iban), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                TextButton(onClick = { Share.copy(ctx, a.iban.replace(" ", "")) }) { Text(tr("نسخ", "Copy")) }
                            }
                            if (Banks.isExpired(a.cardExpiry)) Text(tr("⚠️ البطاقة منتهية الصلاحية", "⚠️ Card expired"), color = DangerRed, style = MaterialTheme.typography.bodySmall)
                            if (a.kind == Banks.CARD && a.creditLimit > 0) {
                                val used = (-balance).coerceAtLeast(0.0)
                                KeyValue(tr("المستخدم من الحد", "Used of limit"), Fmt.money(used) + " / " + Fmt.money(a.creditLimit), if (used > a.creditLimit * 0.8) DangerRed else SuccessGreen)
                                LinearProgressIndicator(progress = { (used / a.creditLimit).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                            }
                            if (a.dueDay > 0) Text(tr("📅 يوم سداد البطاقة: ", "📅 Card due day: ") + a.dueDay, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(8.dp))
                        }
                        Text(tr("إجمالي الحساب", "Account balance"), color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(
                            Fmt.money(balance), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                            color = if (balance < 0) DangerRed else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        KeyValue(tr("الإضافات (الفترة)", "Deposits (period)"), Fmt.money(inSum), SuccessGreen)
                        KeyValue(tr("المصروفات (الفترة)", "Withdrawals (period)"), Fmt.money(outSum), DangerRed)
                        KeyValue(tr("عدد الحركات", "Transactions"), "${shown.size}")
                    }
                }
            }
            if (a.notes.isNotBlank()) item { InfoBanner(a.notes) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { addType = AccountTx.IN },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة مبلغ", "Deposit")) }
                    Button(
                        onClick = { addType = AccountTx.OUT },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) { Icon(Icons.Filled.Remove, null); Spacer(Modifier.width(6.dp)); Text(tr("صرف مبلغ", "Withdraw")) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(tr("الكل", "All"), tr("هذا الشهر", "This month"), tr("30 يوم", "30 days"), tr("فترة", "Range")).forEachIndexed { i, l ->
                        FilterChip(selected = filter == i, onClick = { if (i == 3) showRange = true else filter = i }, label = { Text(l, maxLines = 1) })
                    }
                }
            }
            if (filter == 3) item {
                Text(
                    tr("من ", "From ") + (from?.let { Fmt.date(it) } ?: "-") + tr(" إلى ", " to ") + (to?.let { Fmt.date(it) } ?: "-"),
                    color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall
                )
            }
            item { SectionTitle(tr("الحركات (الأحدث أولاً)", "Transactions (newest first)")) }
            if (shown.isEmpty()) item { EmptyState(Icons.Filled.ReceiptLong, tr("لا توجد حركات", "No transactions")) }
            items(shown.reversed(), key = { it.tx.id }) { l ->
                TxCard(
                    l,
                    onPdf = { c -> Reports.accountTx(c, a, p, l) },
                    phone = p?.phone,
                    onWhatsApp = {
                        Share.whatsappMessage(
                            ctx, p?.phone ?: "",
                            Messages.accountTx(a.name, l.tx.type == AccountTx.IN, l.tx.amount, Fmt.date(l.tx.date), l.tx.note, l.after)
                        )
                    },
                    onEdit = { editLine = l },
                    onDelete = { deleteLine = l }
                )
            }
        }
    }

    addType?.let { type ->
        val isIn = type == AccountTx.IN
        val pending = remember(type) { mutableStateListOf<android.net.Uri>() }
        AmountDialog(
            pending = pending,
            title = if (isIn) tr("إضافة مبلغ", "Deposit") else tr("صرف مبلغ", "Withdrawal"),
            info = tr("الرصيد الحالي: ${Fmt.money(balance)}", "Current balance: ${Fmt.money(balance)}"),
            onDismiss = { addType = null }
        ) { amount, date, _, note ->
            scope.launch {
                val txId = dao.insertAccountTx(AccountTx(accountId = a.id, type = type, amount = amount, date = date, note = note))
                Attachments.addAll(ctx, Attachments.ACC_TX, txId, pending.toList())
                addType = null
                val nb = round2(balance + if (isIn) amount else -amount)
                toast(ctx, tr("الرصيد الآن: ${Fmt.money(nb)}", "Balance now: ${Fmt.money(nb)}"))
            }
        }
    }
    editLine?.let { l ->
        AmountDialog(
            title = tr("تعديل الحركة", "Edit transaction"),
            initial = l.tx.amount, initialDate = l.tx.date, initialNote = l.tx.note,
            onDismiss = { editLine = null }
        ) { amount, date, _, note ->
            scope.launch {
                dao.updateAccountTx(l.tx.copy(amount = amount, date = date, note = note))
                editLine = null
            }
        }
    }
    deleteLine?.let { l ->
        ConfirmDialog(
            title = tr("حذف الحركة", "Delete transaction"),
            text = tr(
                "حذف حركة ${if (l.tx.type == AccountTx.IN) "إضافة" else "صرف"} بمبلغ ${Fmt.money(l.tx.amount)} بتاريخ ${Fmt.date(l.tx.date)}؟ سيُعاد حساب الرصيد تلقائياً.",
                "Delete ${if (l.tx.type == AccountTx.IN) "deposit" else "withdrawal"} of ${Fmt.money(l.tx.amount)} on ${Fmt.date(l.tx.date)}? The balance will be recalculated."
            ),
            confirmText = tr("حذف", "Delete"),
            onDismiss = { deleteLine = null }
        ) { scope.launch { Attachments.deleteFor(Attachments.ACC_TX, l.tx.id); dao.deleteAccountTx(l.tx.id); toast(ctx, tr("تم حذف الحركة", "Transaction deleted")) } }
    }
    if (showEdit) AccountEditDialog(a, p, onDismiss = { showEdit = false }) { showEdit = false }
    if (confirmDelete) ConfirmDialog(
        title = tr("حذف الحساب", "Delete account"),
        text = tr("سيتم حذف الحساب وكل حركاته نهائياً.", "The account and all its transactions will be permanently deleted."),
        confirmText = tr("حذف", "Delete"),
        onDismiss = { confirmDelete = false }
    ) { scope.launch { dao.deleteAccountFull(a.id); nav.popBackStack() } }
    if (showRange) RangeDialog(from, to, onDismiss = { showRange = false }) { f, t ->
        from = f; to = t; filter = 3; showRange = false
    }
}

@Composable
private fun TxCard(
    l: AccountLine,
    onPdf: (android.content.Context) -> java.io.File,
    phone: String?,
    onWhatsApp: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isIn = l.tx.type == AccountTx.IN
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconCircle(
                if (isIn) Icons.Filled.ArrowDownward else Icons.Filled.ArrowUpward,
                if (isIn) SuccessGreen else DangerRed, 38.dp
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    (if (isIn) "+ " else "- ") + Fmt.money(l.tx.amount),
                    fontWeight = FontWeight.Bold, color = if (isIn) SuccessGreen else DangerRed
                )
                Text(
                    Fmt.date(l.tx.date) + " • " + (if (isIn) tr("إضافة", "Deposit") else tr("صرف", "Withdrawal")),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (l.tx.note.isNotBlank()) Text(l.tx.note, style = MaterialTheme.typography.bodySmall)
                Posting.sourceLabel(l.tx)?.let { StatusChip(it, MaterialTheme.colorScheme.tertiary) }
                Text(
                    tr("الإجمالي بعد الحركة: ", "Balance after: ") + Fmt.money(l.after),
                    style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold,
                    color = if (l.after < 0) DangerRed else MaterialTheme.colorScheme.primary
                )
            }
            AttachmentButton(Attachments.ACC_TX, l.tx.id, phone)
            PdfShareButton(phone, build = onPdf)
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (!phone.isNullOrBlank()) DropdownMenuItem(
                        text = { Text(tr("إرسال نص الحركة واتساب", "Send as WhatsApp text")) },
                        leadingIcon = { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) },
                        onClick = { menu = false; onWhatsApp() }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("تعديل", "Edit")) },
                        leadingIcon = { Icon(Icons.Filled.Edit, null) },
                        onClick = { menu = false; onEdit() }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("حذف الحركة", "Delete"), color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
private fun RangeDialog(from: Long?, to: Long?, onDismiss: () -> Unit, onApply: (Long?, Long?) -> Unit) {
    var f by remember { mutableStateOf(from ?: LocalDate.now().withDayOfMonth(1).toEpochDay()) }
    var t by remember { mutableStateOf(to ?: Fmt.today()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("تحديد الفترة", "Select period")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DateField(tr("من تاريخ", "From"), f, { d -> if (d != null) f = d })
                DateField(tr("إلى تاريخ", "To"), t, { d -> if (d != null) t = d })
            }
        },
        confirmButton = { TextButton(onClick = { onApply(minOf(f, t), maxOf(f, t)) }) { Text(tr("تطبيق", "Apply")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
