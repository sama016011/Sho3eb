@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.data.Person
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

// ============================ قائمة الحسابات ============================
@Composable
fun AccountListScreen(nav: NavController) {
    val dao = remember { appDao() }
    val accounts by flowState(emptyList<Account>()) { dao.accountsFlow() }
    val txs by flowState(emptyList<AccountTx>()) { dao.allAccountTxFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val pmap = remember(people) { people.associateBy { it.id } }
    var q by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }

    ScreenScaffold(
        title = tr("الحسابات", "Accounts"),
        onBack = { nav.popBackStack() },
        fab = {
            ExtendedFloatingActionButton(
                onClick = { showNew = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(tr("حساب جديد", "New account")) }
            )
        }
    ) { pad ->
        val byAcc = txs.groupBy { it.accountId }
        val total = accounts.sumOf { accountBalance(byAcc[it.id] ?: emptyList()) }
        val list = accounts.filter { a ->
            q.isBlank() || a.name.contains(q, true) || (a.personId?.let { pmap[it]?.name?.contains(q, true) } == true)
        }
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Filled.AccountBalanceWallet, MaterialTheme.colorScheme.primary, 48.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(tr("إجمالي أرصدة الحسابات", "Total of all balances"), color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                Fmt.money(total), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                                color = if (total < 0) DangerRed else MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(tr("${accounts.size} حساب", "${accounts.size} accounts"), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item { SearchField(q) { q = it } }
            if (list.isEmpty()) item {
                EmptyState(Icons.Filled.AccountBalanceWallet, tr("لا توجد حسابات. اضغط \"حساب جديد\".", "No accounts yet. Tap \"New account\"."))
            }
            items(list, key = { it.id }) { a ->
                val p = a.personId?.let { pmap[it] }
                val at = byAcc[a.id] ?: emptyList()
                val bal = accountBalance(at)
                Card(onClick = { nav.navigate("account/${a.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (p != null) Avatar(p.photoPath, p.name, 46.dp)
                        else IconCircle(Icons.Filled.AccountBalanceWallet, MaterialTheme.colorScheme.primary, 46.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                (p?.name ?: tr("بدون جهة اتصال", "No contact")) + " • " + tr("${at.size} حركة", "${at.size} txns"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            at.maxByOrNull { it.date }?.let {
                                Text(tr("آخر حركة: ", "Last: ") + Fmt.date(it.date), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Text(
                            Fmt.money(bal), fontWeight = FontWeight.ExtraBold,
                            color = if (bal < 0) DangerRed else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
    if (showNew) AccountEditDialog(null, null, onDismiss = { showNew = false }) { id ->
        showNew = false
        nav.navigate("account/$id")
    }
}

// ============================ إنشاء / تعديل حساب ============================
@Composable
fun AccountEditDialog(existing: Account?, existingPerson: Person?, onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var person by remember { mutableStateOf(existingPerson) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var opening by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) tr("حساب جديد", "New account") else tr("تعديل الحساب", "Edit account")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    name, { name = it }, label = { Text(tr("اسم الحساب", "Account name")) }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.AccountBalanceWallet, null) }, modifier = Modifier.fillMaxWidth()
                )
                Text(tr("ربط بجهة تواصل (اختياري)", "Link to a contact (optional)"), style = MaterialTheme.typography.labelLarge)
                PersonSelector(person, tr("اختيار جهة تواصل", "Choose a contact")) { person = it }
                if (person != null) TextButton(onClick = { person = null }) { Text(tr("إلغاء الربط", "Unlink contact")) }
                if (existing == null) MoneyField(opening, { opening = it }, tr("رصيد افتتاحي (اختياري)", "Opening balance (optional)"))
                OutlinedTextField(notes, { notes = it }, label = { Text(tr("ملاحظات", "Notes")) }, minLines = 2, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) {
                    toast(ctx, tr("أدخل اسم الحساب", "Enter account name")); return@TextButton
                }
                scope.launch {
                    if (existing == null) {
                        val id = dao.insertAccount(Account(name = name.trim(), personId = person?.id, notes = notes.trim()))
                        val ob = Fmt.parse(opening) ?: 0.0
                        if (ob != 0.0) dao.insertAccountTx(
                            AccountTx(
                                accountId = id, type = if (ob > 0) AccountTx.IN else AccountTx.OUT, amount = kotlin.math.abs(ob),
                                date = Fmt.today(), note = tr("رصيد افتتاحي", "Opening balance")
                            )
                        )
                        onSaved(id)
                    } else {
                        dao.updateAccount(existing.copy(name = name.trim(), personId = person?.id, notes = notes.trim()))
                        onSaved(existing.id)
                    }
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}

// ============================ كشف الحساب ============================
@Composable
fun AccountDetailScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val account by flowState<Account?>(null, id) { dao.accountFlow(id) }
    val txs by flowState(emptyList<AccountTx>(), id) { dao.accountTxFlow(id) }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    var addType by remember { mutableStateOf<String?>(null) }
    var editLine by remember { mutableStateOf<AccountLine?>(null) }
    var deleteLine by remember { mutableStateOf<AccountLine?>(null) }
    var showEdit by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var filter by remember { mutableIntStateOf(0) }
    var from by remember { mutableStateOf<Long?>(null) }
    var to by remember { mutableStateOf<Long?>(null) }
    var showRange by remember { mutableStateOf(false) }

    val a = account
    if (a == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val p = a.personId?.let { pid -> people.firstOrNull { it.id == pid } }
    val lines = remember(txs) { accountLines(txs) }
    val balance = lines.lastOrNull()?.after ?: 0.0
    val today = LocalDate.now()
    // حدود الفترة حسب الفلتر
    val (rFrom, rTo) = when (filter) {
        1 -> today.withDayOfMonth(1).toEpochDay() to null
        2 -> today.minusDays(30).toEpochDay() to null
        3 -> from to to
        else -> null to null
    }
    val shown = lines.filter { l -> (rFrom == null || l.tx.date >= rFrom) && (rTo == null || l.tx.date <= rTo) }
    val inSum = shown.filter { it.tx.type == AccountTx.IN }.sumOf { it.tx.amount }
    val outSum = shown.filter { it.tx.type == AccountTx.OUT }.sumOf { it.tx.amount }

    ScreenScaffold(
        title = a.name,
        onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(p?.phone, doc = { Docs.account(a, p, txs, rFrom, rTo) }) { c -> Reports.account(c, a, p, txs, rFrom, rTo) }
            IconButton(onClick = { showEdit = true }) { Icon(Icons.Filled.Edit, null) }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, null) }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        if (p != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Avatar(p.photoPath, p.name, 46.dp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Bold)
                                    if (p.phone.isNotBlank()) Text(p.phone, style = MaterialTheme.typography.bodySmall)
                                }
                                if (p.phone.isNotBlank()) {
                                    IconButton(onClick = { Share.dial(ctx, p.phone) }) { Icon(Icons.Filled.Call, null) }
                                    IconButton(onClick = { Share.whatsappMessage(ctx, p.phone, Messages.accountBalance(a.name, balance)) }) {
                                        Icon(Icons.Filled.Chat, null, tint = WhatsGreen)
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                        }
                        Text(tr("إجمالي الحساب", "Account balance"), color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(
                            Fmt.money(balance), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                            color = if (balance < 0) DangerRed else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        KeyValue(tr("الإضافات (الفترة)", "Deposits (period)"), Fmt.money(inSum), SuccessGreen)
                        KeyValue(tr("المصروفات (الفترة)", "Withdrawals (period)"), Fmt.money(outSum), DangerRed)
                        KeyValue(tr("عدد الحركات", "Transactions"), "${shown.size}")
                    }
                }
            }
            if (a.notes.isNotBlank()) item { InfoBanner(a.notes) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { addType = AccountTx.IN },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة مبلغ", "Deposit")) }
                    Button(
                        onClick = { addType = AccountTx.OUT },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) { Icon(Icons.Filled.Remove, null); Spacer(Modifier.width(6.dp)); Text(tr("صرف مبلغ", "Withdraw")) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(tr("الكل", "All"), tr("هذا الشهر", "This month"), tr("30 يوم", "30 days"), tr("فترة", "Range")).forEachIndexed { i, l ->
                        FilterChip(selected = filter == i, onClick = { if (i == 3) showRange = true else filter = i }, label = { Text(l, maxLines = 1) })
                    }
                }
            }
            if (filter == 3) item {
                Text(
                    tr("من ", "From ") + (from?.let { Fmt.date(it) } ?: "-") + tr(" إلى ", " to ") + (to?.let { Fmt.date(it) } ?: "-"),
                    color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall
                )
            }
            item { SectionTitle(tr("الحركات (الأحدث أولاً)", "Transactions (newest first)")) }
            if (shown.isEmpty()) item { EmptyState(Icons.Filled.ReceiptLong, tr("لا توجد حركات", "No transactions")) }
            items(shown.reversed(), key = { it.tx.id }) { l ->
                TxCard(
                    l,
                    onPdf = { c -> Reports.accountTx(c, a, p, l) },
                    phone = p?.phone,
                    onWhatsApp = {
                        Share.whatsappMessage(
                            ctx, p?.phone ?: "",
                            Messages.accountTx(a.name, l.tx.type == AccountTx.IN, l.tx.amount, Fmt.date(l.tx.date), l.tx.note, l.after)
                        )
                    },
                    onEdit = { editLine = l },
                    onDelete = { deleteLine = l }
                )
            }
        }
    }

    addType?.let { type ->
        val isIn = type == AccountTx.IN
        val pending = remember(type) { mutableStateListOf<android.net.Uri>() }
        AmountDialog(
            pending = pending,
            title = if (isIn) tr("إضافة مبلغ", "Deposit") else tr("صرف مبلغ", "Withdrawal"),
            info = tr("الرصيد الحالي: ${Fmt.money(balance)}", "Current balance: ${Fmt.money(balance)}"),
            onDismiss = { addType = null }
        ) { amount, date, _, note ->
            scope.launch {
                val txId = dao.insertAccountTx(AccountTx(accountId = a.id, type = type, amount = amount, date = date, note = note))
                Attachments.addAll(ctx, Attachments.ACC_TX, txId, pending.toList())
                addType = null
                val nb = round2(balance + if (isIn) amount else -amount)
                toast(ctx, tr("الرصيد الآن: ${Fmt.money(nb)}", "Balance now: ${Fmt.money(nb)}"))
            }
        }
    }
    editLine?.let { l ->
        AmountDialog(
            title = tr("تعديل الحركة", "Edit transaction"),
            initial = l.tx.amount, initialDate = l.tx.date, initialNote = l.tx.note,
            onDismiss = { editLine = null }
        ) { amount, date, _, note ->
            scope.launch {
                dao.updateAccountTx(l.tx.copy(amount = amount, date = date, note = note))
                editLine = null
            }
        }
    }
    deleteLine?.let { l ->
        ConfirmDialog(
            title = tr("حذف الحركة", "Delete transaction"),
            text = tr(
                "حذف حركة ${if (l.tx.type == AccountTx.IN) "إضافة" else "صرف"} بمبلغ ${Fmt.money(l.tx.amount)} بتاريخ ${Fmt.date(l.tx.date)}؟ سيُعاد حساب الرصيد تلقائياً.",
                "Delete ${if (l.tx.type == AccountTx.IN) "deposit" else "withdrawal"} of ${Fmt.money(l.tx.amount)} on ${Fmt.date(l.tx.date)}? The balance will be recalculated."
            ),
            confirmText = tr("حذف", "Delete"),
            onDismiss = { deleteLine = null }
        ) { scope.launch { Attachments.deleteFor(Attachments.ACC_TX, l.tx.id); dao.deleteAccountTx(l.tx.id); toast(ctx, tr("تم حذف الحركة", "Transaction deleted")) } }
    }
    if (showEdit) AccountEditDialog(a, p, onDismiss = { showEdit = false }) { showEdit = false }
    if (confirmDelete) ConfirmDialog(
        title = tr("حذف الحساب", "Delete account"),
        text = tr("سيتم حذف الحساب وكل حركاته نهائياً.", "The account and all its transactions will be permanently deleted."),
        confirmText = tr("حذف", "Delete"),
        onDismiss = { confirmDelete = false }
    ) { scope.launch { dao.deleteAccountFull(a.id); nav.popBackStack() } }
    if (showRange) RangeDialog(from, to, onDismiss = { showRange = false }) { f, t ->
        from = f; to = t; filter = 3; showRange = false
    }
}

@Composable
private fun TxCard(
    l: AccountLine,
    onPdf: (android.content.Context) -> java.io.File,
    phone: String?,
    onWhatsApp: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isIn = l.tx.type == AccountTx.IN
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconCircle(
                if (isIn) Icons.Filled.ArrowDownward else Icons.Filled.ArrowUpward,
                if (isIn) SuccessGreen else DangerRed, 38.dp
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    (if (isIn) "+ " else "- ") + Fmt.money(l.tx.amount),
                    fontWeight = FontWeight.Bold, color = if (isIn) SuccessGreen else DangerRed
                )
                Text(
                    Fmt.date(l.tx.date) + " • " + (if (isIn) tr("إضافة", "Deposit") else tr("صرف", "Withdrawal")),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (l.tx.note.isNotBlank()) Text(l.tx.note, style = MaterialTheme.typography.bodySmall)
                Posting.sourceLabel(l.tx)?.let { StatusChip(it, MaterialTheme.colorScheme.tertiary) }
                Text(
                    tr("الإجمالي بعد الحركة: ", "Balance after: ") + Fmt.money(l.after),
                    style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold,
                    color = if (l.after < 0) DangerRed else MaterialTheme.colorScheme.primary
                )
            }
            AttachmentButton(Attachments.ACC_TX, l.tx.id, phone)
            PdfShareButton(phone, onPdf)
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (!phone.isNullOrBlank()) DropdownMenuItem(
                        text = { Text(tr("إرسال نص الحركة واتساب", "Send as WhatsApp text")) },
                        leadingIcon = { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) },
                        onClick = { menu = false; onWhatsApp() }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("تعديل", "Edit")) },
                        leadingIcon = { Icon(Icons.Filled.Edit, null) },
                        onClick = { menu = false; onEdit() }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("حذف الحركة", "Delete"), color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
private fun RangeDialog(from: Long?, to: Long?, onDismiss: () -> Unit, onApply: (Long?, Long?) -> Unit) {
    var f by remember { mutableStateOf(from ?: LocalDate.now().withDayOfMonth(1).toEpochDay()) }
    var t by remember { mutableStateOf(to ?: Fmt.today()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("تحديد الفترة", "Select period")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DateField(tr("من تاريخ", "From"), f, { d -> if (d != null) f = d })
                DateField(tr("إلى تاريخ", "To"), t, { d -> if (d != null) t = d })
            }
        },
        confirmButton = { TextButton(onClick = { onApply(minOf(f, t), maxOf(f, t)) }) { Text(tr("تطبيق", "Apply")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
