package com.sho3eb.app.core

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.sho3eb.app.data.LivEntry
import com.sho3eb.app.data.LivPeriod
import com.sho3eb.app.data.AccountTx
import kotlinx.coroutines.suspendCancellableCoroutine
import java.time.LocalDate
import kotlin.coroutines.resume

// =====================================================================
//                 تحليل الإدخال الصوتي (عربي / إنجليزي)
// =====================================================================
object VoiceParse {

    data class Result(val text: String, val amount: Double?, val title: String, val kind: String, val category: String, val date: Long)

    private val arDigits = mapOf('٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4', '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9', '٫' to '.', '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4', '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9')

    fun normDigits(s: String) = s.map { arDigits[it] ?: it }.joinToString("")

    /** توحيد الحروف العربية لتسهيل المطابقة */
    fun norm(s: String) = normDigits(s).lowercase()
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي')
        .replace("ـ", "").replace(Regex("[\\u064B-\\u0652]"), "")

    private val units = mapOf(
        "صفر" to 0, "واحد" to 1, "واحده" to 1, "اثنين" to 2, "اتنين" to 2, "اثنان" to 2, "ثلاث" to 3, "ثلاثه" to 3, "تلات" to 3, "تلاته" to 3,
        "اربع" to 4, "اربعه" to 4, "خمس" to 5, "خمسه" to 5, "ست" to 6, "سته" to 6, "سبع" to 7, "سبعه" to 7, "ثمان" to 8, "ثماني" to 8, "ثمانيه" to 8, "تمن" to 8, "تمانيه" to 8, "تسع" to 9, "تسعه" to 9,
        "عشر" to 10, "عشره" to 10, "احدعشر" to 11, "حداشر" to 11, "اثناعشر" to 12, "اطناشر" to 12, "اتناشر" to 12,
        "عشرين" to 20, "عشرون" to 20, "ثلاثين" to 30, "تلاتين" to 30, "اربعين" to 40, "خمسين" to 50, "ستين" to 60, "سبعين" to 70, "ثمانين" to 80, "تمانين" to 80, "تسعين" to 90,
        "ميه" to 100, "مائه" to 100, "مية" to 100, "ميتين" to 200, "مئتين" to 200, "مائتين" to 200, "ثلاثمائه" to 300, "تلتمية" to 300, "تلتميه" to 300, "اربعمائه" to 400, "ربعميه" to 400, "خمسمائه" to 500, "خمسميه" to 500,
        "ستمائه" to 600, "ستميه" to 600, "سبعمائه" to 700, "سبعميه" to 700, "ثمانمائه" to 800, "تمنميه" to 800, "تسعمائه" to 900, "تسعميه" to 900,
        "نص" to -2, "نصف" to -2, "ربع" to -4,
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10,
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90, "hundred" to 100
    )
    private val mult = mapOf("الف" to 1000, "الاف" to 1000, "الفين" to 2000, "مليون" to 1_000_000, "ملايين" to 1_000_000, "thousand" to 1000, "million" to 1_000_000)

    /** يستخرج المبلغ: أرقام مكتوبة أو كلمات عربية مثل «ميتين وخمسين» أو «ألف ونص» */
    fun amount(text: String): Double? {
        val t = norm(text)
        Regex("(\\d+(?:[.,]\\d+)?)\\s*(الف|k|مليون)?").findAll(t).map { m ->
            val v = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: 0.0
            when (m.groupValues[2]) { "الف", "k" -> v * 1000; "مليون" -> v * 1_000_000; else -> v }
        }.maxOrNull()?.let { if (it > 0) return it }
        val words = t.split(Regex("[\\s،,]+")).flatMap { w -> if (w.startsWith("و") && w.length > 2 && (units.containsKey(w.drop(1)) || mult.containsKey(w.drop(1)))) listOf(w.drop(1)) else listOf(w) }
        var total = 0.0; var cur = 0.0; var found = false
        for (w in words) {
            val u = units[w]; val m = mult[w]
            when {
                u != null && u > 0 -> { cur += u; found = true }
                u == -2 -> { cur += if (cur == 0.0 && total > 0) 500.0 / (if (total >= 1000) 1 else 10) else 0.5; found = true }
                u == -4 -> { cur += if (total > 0 && cur == 0.0) 250.0 else 0.25; found = true }
                m != null -> { val base = if (w == "الفين") 1.0 else if (cur == 0.0) 1.0 else cur; total += base * m; cur = 0.0; found = true }
            }
        }
        val r = total + cur
        return if (found && r > 0) r else null
    }

    private val incomeWords = listOf("قبضت", "استلمت", "راتب", "دخل", "ربحت", "جالي", "وصلني", "حصلت", "income", "salary", "received", "got paid")
    private val catWords: List<Pair<String, List<String>>> = listOf(
        "FOOD" to listOf("اكل", "طعام", "خبز", "عيش", "خضار", "فاكهه", "لحم", "فراخ", "دجاج", "سمك", "بقاله", "سوبر", "ماركت", "تموين", "رز", "سكر", "زيت", "حليب", "لبن", "grocery", "food"),
        "RESTAURANTS" to listOf("مطعم", "كافيه", "قهوه", "شاي", "عشاء بره", "غدا بره", "بيتزا", "برجر", "شاورما", "كشري", "فول", "طلبات", "هنقرستيشن", "restaurant", "coffee"),
        "TRANSPORT" to listOf("بنزين", "وقود", "تاكسي", "اوبر", "كريم", "مواصلات", "مترو", "باص", "سياره", "غسيل سياره", "زيت سياره", "fuel", "uber", "taxi"),
        "BILLS" to listOf("كهرباء", "كهربا", "مياه", "ميه", "غاز", "فاتوره", "electric", "water"),
        "TELECOM" to listOf("نت", "انترنت", "شحن", "رصيد", "جوال", "موبايل", "باقه", "internet", "phone"),
        "HOUSING" to listOf("ايجار", "سكن", "شقه", "rent"),
        "HEALTH" to listOf("دواء", "علاج", "صيدليه", "دكتور", "مستشفي", "تحاليل", "pharmacy", "doctor"),
        "EDUCATION" to listOf("مدرسه", "دروس", "كورس", "جامعه", "كتب", "school", "course"),
        "CLOTHES" to listOf("ملابس", "هدوم", "جزمه", "حذاء", "قميص", "clothes", "shoes"),
        "KIDS" to listOf("اطفال", "عيال", "حفاضات", "بامبرز", "لعب", "kids"),
        "CHARITY" to listOf("صدقه", "زكاه", "تبرع", "charity"),
        "GIFTS" to listOf("هديه", "هدايا", "عيديه", "gift"),
        "TRAVEL" to listOf("سفر", "طيران", "فندق", "رحله", "travel", "hotel"),
        "ENTERTAIN" to listOf("سينما", "نتفلكس", "اشتراك", "لعبه", "netflix"),
        "HOUSEHOLD" to listOf("منظفات", "مستلزمات", "ادوات", "detergent"),
        "PERSONAL" to listOf("حلاق", "صالون", "عطر", "barber"),
        "DEBT" to listOf("قسط", "دين", "سداد", "installment")
    )

    fun category(text: String, kind: String): String {
        val t = norm(text)
        if (kind == Living.INCOME) return when {
            listOf("راتب", "salary").any { t.contains(it) } -> "SALARY"
            listOf("ايجار", "rent").any { t.contains(it) } -> "RENT"
            listOf("ربح", "ارباح", "تجاره", "محل").any { t.contains(it) } -> "PRIVATE"
            else -> "OTHER"
        }
        return catWords.firstOrNull { (_, ws) -> ws.any { t.contains(norm(it)) } }?.first ?: "OTHER"
    }

    fun parse(text: String): Result {
        val t = norm(text)
        val kind = if (incomeWords.any { t.contains(norm(it)) }) Living.INCOME else Living.EXPENSE
        val date = when {
            t.contains("امبارح") || t.contains("امس") || t.contains("yesterday") -> Fmt.today() - 1
            else -> Fmt.today()
        }
        // العنوان: النص بعد حذف الأرقام وكلمات الحشو
        val filler = listOf("صرفت", "دفعت", "اشتريت", "جبت", "قبضت", "استلمت", "ريال", "جنيه", "جنيها", "درهم", "دينار", "دولار", "على", "علي", "في", "ب", "من", "اليوم", "امبارح", "امس", "مبلغ", "spent", "paid", "bought", "on", "for", "riyal", "pound")
        val title = normDigits(text).split(Regex("\\s+"))
            .filter { w -> val n = norm(w); n.isNotBlank() && n.none { it.isDigit() } && n !in filler && !units.containsKey(n) && !units.containsKey(n.removePrefix("و")) && !mult.containsKey(n) && !mult.containsKey(n.removePrefix("و")) && n != "و" }
            .joinToString(" ").trim()
        return Result(text, amount(text), title, kind, category(text, kind), date)
    }
}

// =====================================================================
//                 قراءة الفواتير بالكاميرا (OCR)
// =====================================================================
object ReceiptScan {

    data class Line(val name: String, val qty: Double, val price: Double)
    data class Result(val raw: String, val total: Double?, val date: Long?, val store: String, val lines: List<Line>, val vat: Double?)

    suspend fun recognize(ctx: Context, uri: Uri): String = suspendCancellableCoroutine { cont ->
        try {
            val img = InputImage.fromFilePath(ctx, uri)
            val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            rec.process(img)
                .addOnSuccessListener { r -> if (cont.isActive) cont.resume(r.text) }
                .addOnFailureListener { if (cont.isActive) cont.resume("") }
        } catch (e: Exception) {
            if (cont.isActive) cont.resume("")
        }
    }

    private val numRe = Regex("(\\d{1,3}(?:[,،]\\d{3})+(?:\\.\\d{1,3})?|\\d+(?:[.,]\\d{1,3})?)")
    private val totalKeys = listOf("grand total", "total due", "net total", "total amount", "amount due", "total", "net", "balance due", "to pay", "الاجمالي", "اجمالي", "المجموع", "الصافي", "المطلوب", "الاجمالى", "المبلغ")
    private val skipKeys = listOf("subtotal", "sub total", "vat", "tax", "change", "cash", "card", "discount", "qty", "tel", "phone", "vat no", "cr no", "invoice no", "رقم", "ضريبه", "خصم", "الباقي", "نقدا")

    private fun toNum(s: String): Double? {
        var x = VoiceParse.normDigits(s).replace("،", ",")
        x = if (Regex("\\d{1,3}(,\\d{3})+(\\.\\d+)?").matches(x)) x.replace(",", "") else x.replace(',', '.')
        return x.toDoubleOrNull()
    }

    private fun numsIn(line: String) = numRe.findAll(VoiceParse.normDigits(line)).mapNotNull { toNum(it.value) }.toList()

    fun parse(raw: String): Result {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }
        val low = lines.map { VoiceParse.norm(it) }
        // الإجمالي: أقوى سطر يحتوي كلمة إجمالي، وإلا أكبر رقم عشري معقول
        var total: Double? = null
        for (k in totalKeys) {
            val i = low.indexOfLast { l -> l.contains(VoiceParse.norm(k)) && (k != "total" || !l.contains("subtotal")) }
            if (i >= 0) {
                val here = numsIn(lines[i]).filter { it > 0 && it < 10_000_000 }
                val v = here.lastOrNull() ?: lines.getOrNull(i + 1)?.let { numsIn(it).lastOrNull() }
                if (v != null && v > 0) { total = v; break }
            }
        }
        if (total == null) total = lines.flatMap { l -> numRe.findAll(VoiceParse.normDigits(l)).filter { it.value.contains('.') }.mapNotNull { toNum(it.value) }.toList() }.filter { it < 1_000_000 }.maxOrNull()
        // الضريبة
        val vatIdx = low.indexOfFirst { it.contains("vat") || it.contains("ضريبه") || it.contains("tax") }
        val vat = if (vatIdx >= 0) numsIn(lines[vatIdx]).filter { it > 0 && it < (total ?: Double.MAX_VALUE) && it != 15.0 && it != 14.0 && it != 5.0 }.lastOrNull() else null
        // التاريخ
        val date = parseDate(VoiceParse.normDigits(raw))
        // اسم المحل: أول سطر نصي غير رقمي
        val store = lines.take(4).firstOrNull { l -> l.count { it.isLetter() } >= 3 && numsIn(l).isEmpty() } ?: ""
        // البنود: سطر يحتوي اسماً وسعراً
        val items = mutableListOf<Line>()
        lines.forEachIndexed { i, l ->
            val n = low[i]
            if (totalKeys.any { n.contains(VoiceParse.norm(it)) } || skipKeys.any { n.contains(VoiceParse.norm(it)) }) return@forEachIndexed
            val nums = numsIn(l)
            val name = l.replace(numRe, "").replace(Regex("[x×*@=:#\\-]+"), " ").trim()
            if (nums.isEmpty() || name.count { it.isLetter() } < 2) return@forEachIndexed
            val price = nums.last()
            if (price <= 0 || (total != null && price > total)) return@forEachIndexed
            val qty = if (nums.size >= 2 && nums.first() in 1.0..99.0 && nums.first() % 1.0 == 0.0) nums.first() else 1.0
            val unit = if (qty > 1 && nums.size >= 3) nums[nums.size - 2] else price / qty
            items += Line(name.take(40), qty, Living.round2(unit))
        }
        return Result(raw, total, date, store.take(40), items.take(40), vat)
    }

    private fun parseDate(s: String): Long? {
        val pats = listOf(
            Regex("(20\\d{2})[-/.](\\d{1,2})[-/.](\\d{1,2})") to { m: MatchResult -> Triple(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()) },
            Regex("(\\d{1,2})[-/.](\\d{1,2})[-/.](20\\d{2})") to { m: MatchResult -> Triple(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt()) },
            Regex("(\\d{1,2})[-/.](\\d{1,2})[-/.](\\d{2})\\b") to { m: MatchResult -> Triple(2000 + m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt()) }
        )
        for ((re, f) in pats) {
            val m = re.find(s) ?: continue
            val (y, mo, d) = f(m)
            val r = runCatching { LocalDate.of(y, mo, d) }.getOrNull() ?: runCatching { LocalDate.of(y, d, mo) }.getOrNull() ?: continue
            if (r.year in 2015..LocalDate.now().year + 1) return r.toEpochDay()
        }
        return null
    }
}

// =====================================================================
//                إضافة سريعة لمصاريف/دخل المعيشة
// =====================================================================
object QuickAdd {
    /** يضيف حركة للمعيشة في فترة الشهر الحالي (وينشئها عند الحاجة) ويرحّلها لحساب اختياري */
    suspend fun living(ctx: Context, kind: String, name: String, category: String, amount: Double, date: Long, note: String = "", accountId: Long? = null): Long {
        val dao = appDao()
        val d = LocalDate.ofEpochDay(date)
        var period: LivPeriod? = dao.allLivPeriods().firstOrNull { date in it.startDate..it.endDate }
        if (period == null) {
            val p = LivPeriod(name = Living.monthTitle(d), startDate = d.withDayOfMonth(1).toEpochDay(), endDate = d.withDayOfMonth(d.lengthOfMonth()).toEpochDay())
            period = p.copy(id = dao.insertLivPeriod(p))
        }
        val c = Living.cat(kind, category)
        val id = dao.insertLivEntry(LivEntry(periodId = period.id, kind = kind, name = name.ifBlank { c.label }, category = c.key, priority = c.priority, amount = amount, date = date, note = note))
        if (accountId != null) Posting.post(accountId, AccountTx.SRC_LIV, id, kind == Living.INCOME, amount, date, name.ifBlank { c.label })
        if (kind == Living.EXPENSE) runCatching { LivingAuto.checkBudget(ctx, c.key) }
        return id
    }
}
