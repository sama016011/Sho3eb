package com.sho3eb.app.core.chat

import android.content.Context
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.core.Extras
import com.sho3eb.app.core.tr
import com.sho3eb.app.data.AppDatabase
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * الحساب السحابي: تسجيل برقم الهاتف وكلمة مرور، استعادة كلمة المرور برمز (SMS/واتساب/بريد)،
 * التحقق من رقم الهاتف، ونسخ احتياطي واستعادة لكل بيانات التطبيق (مالية، إسلامية، تواصل…).
 */
object Cloud {
    class CloudError(msg: String) : Exception(msg)

    val available get() = Supa.configured
    val loggedIn get() = Supa.configured && Supa.signedIn && !Supa.isAnonymous
    var loginId: String get() = Extras.s("cloud_login", ""); private set(v) = Extras.ps("cloud_login", v)

    /** البريد الداخلي للحساب عند عدم إدخال بريد حقيقي */
    fun phoneEmail(phone: String) = "p" + Chat.normPhone(phone) + "@sho3eb.app"
    private fun e164(phone: String) = "+" + Chat.normPhone(phone)

    private fun check(r: Pair<Int, JSONObject>): JSONObject {
        if (r.first !in 200..299) throw CloudError(friendly(Supa.authError(r.second)))
        return r.second
    }
    fun friendly(m: String): String = when {
        m.contains("Invalid login", true) -> tr("رقم الهاتف أو كلمة المرور غير صحيحة", "Wrong phone or password")
        m.contains("already registered", true) || m.contains("already been registered", true) || m.contains("exists", true) -> tr("هذا الحساب مسجل من قبل؛ اختر «لدي حساب» وسجّل الدخول", "Account already exists; sign in instead")
        m.contains("Email not confirmed", true) -> tr("يجب تعطيل «Confirm email» في إعدادات Supabase (Authentication ← Sign In / Providers ← Email)", "Disable \"Confirm email\" in Supabase settings")
        m.contains("phone provider", true) || m.contains("Unsupported phone provider", true) || m.contains("sms", true) && m.contains("provider", true) ->
            tr("لم يُضبط مزود رسائل SMS/واتساب في Supabase بعد (Authentication ← Sign In / Providers ← Phone)", "No SMS/WhatsApp provider is configured in Supabase yet")
        m.contains("Token has expired", true) || m.contains("invalid", true) && m.contains("otp", true) -> tr("الرمز غير صحيح أو انتهت صلاحيته", "Code is wrong or expired")
        m.contains("Password should be", true) -> tr("كلمة المرور 6 أحرف على الأقل", "Password must be at least 6 characters")
        m.contains("rate limit", true) -> tr("محاولات كثيرة؛ انتظر قليلاً ثم أعد المحاولة", "Too many attempts; wait a bit")
        else -> m
    }

    /** حساب جديد (يحوّل حساب التواصل الحالي إلى حساب دائم فتبقى المحادثات) */
    fun register(name: String, phone: String, email: String, password: String) {
        val mail = email.trim().ifBlank { phoneEmail(phone) }
        val meta = JSONObject().put("name", name).put("phone", Chat.normPhone(phone))
        if (Supa.signedIn && Supa.isAnonymous) {
            check(Supa.auth("PUT", "user", JSONObject().put("email", mail).put("password", password).put("data", meta), withSession = true))
            // تحديث الجلسة لتصبح دائمة
            val r = Supa.auth("POST", "token?grant_type=password", JSONObject().put("email", mail).put("password", password))
            if (r.first in 200..299) Supa.adoptSession(r.second)
        } else {
            val o = check(Supa.auth("POST", "signup", JSONObject().put("email", mail).put("password", password).put("data", meta)))
            if (!o.has("access_token")) throw CloudError(friendly("Email not confirmed"))
            Supa.adoptSession(o)
        }
        Supa.markPermanent(true); loginId = mail; Extras.ps("cloud_login_phone", Chat.latinDigits(phone))
        afterLogin(name, phone, mail)
        runCatching { vaultSync(password) }
    }

    /** تسجيل الدخول برقم الهاتف (أو البريد) وكلمة المرور */
    fun signIn(phoneOrEmail: String, password: String) {
        val id = phoneOrEmail.trim()
        val candidates = if (id.contains('@')) listOf(id) else buildList {
            val found = runCatching { Supa.rpc("account_email", JSONObject().put("p", Chat.normPhone(id)), anon = true).trim().trim('"').takeIf { it.contains('@') && it != "null" } }.getOrNull()
            found?.let { add(it) }
            // آخر بريد دخل به هذا الجهاز لنفس الرقم
            loginId.takeIf { it.contains('@') && Chat.tail(Extras.s("cloud_login_phone", "")) == Chat.tail(id) }?.let { add(it) }
            add(phoneEmail(id))
            // نفس الرقم بمفاتيح دول شائعة (إن اختلف مفتاح الدولة بين الجهازين)
            val t = Chat.latinDigits(id).filter { it.isDigit() }.trimStart('0')
            if (found == null) for (cc in listOf("20", "966", "971", "965", "974", "973", "968", "962", "964", "212", "213", "216", "218", "249", "967", "963", "961", "970"))
                if (t.length in 8..10 && !t.startsWith(cc)) add("p$cc$t@sho3eb.app")
            add("p$t@sho3eb.app")
        }.distinct()
        var last: Pair<Int, JSONObject>? = null
        for (mail in candidates) {
            val r = Supa.auth("POST", "token?grant_type=password", JSONObject().put("email", mail).put("password", password))
            if (r.first in 200..299) {
                Supa.signOut(); Supa.adoptSession(r.second); Supa.markPermanent(true); loginId = mail
                if (!id.contains('@')) Extras.ps("cloud_login_phone", Chat.latinDigits(id))
                val meta = r.second.optJSONObject("user")?.optJSONObject("user_metadata")
                afterLogin(meta?.optString("name") ?: "", meta?.optString("phone")?.ifBlank { null } ?: if (!id.contains('@')) id else "", mail)
                runCatching { vaultSync(password) }
                return
            }
            last = r
            if (Supa.authError(r.second).contains("rate limit", true)) break
        }
        throw CloudError(friendly(last?.let { Supa.authError(it.second) } ?: "Invalid login"))
    }

    private fun afterLogin(name: String, phone: String, mail: String) {
        val prefs = Sho3ebApp.instance.prefs
        if (name.isNotBlank() && prefs.displayName.isBlank()) prefs.displayName = name
        if (phone.isNotBlank()) prefs.phone = Chat.latinDigits(phone)
        runCatching {
            val row = JSONObject().put("id", Supa.uid).put("login_email", mail)
            Supa.upsert("profiles", row)
        }
        runCatching { Chat.publishProfile() }
    }

    // ---------------- خزنة المفاتيح: استعادة المحادثات والأصدقاء على أي جهاز ----------------
    /** مفتاح مشتق من كلمة المرور (لا يعرفه الخادم) يشفّر مفاتيح التواصل وقائمة الأصدقاء */
    private fun deriveKey(password: String, salt: String): ByteArray {
        val f = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return f.generateSecret(javax.crypto.spec.PBEKeySpec(password.toCharArray(), ("sho3eb-vault:" + salt).toByteArray(), 60_000, 256)).encoded
    }
    private fun vaultKey(): ByteArray? = Extras.s("cloud_vk", "").takeIf { it.isNotBlank() }?.let { android.util.Base64.decode(it, android.util.Base64.NO_WRAP) }
    private fun seal(key: ByteArray, plain: String): String {
        val iv = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding").apply { init(javax.crypto.Cipher.ENCRYPT_MODE, javax.crypto.spec.SecretKeySpec(key, "AES"), javax.crypto.spec.GCMParameterSpec(128, iv)) }
        return android.util.Base64.encodeToString(iv + c.doFinal(plain.toByteArray()), android.util.Base64.NO_WRAP)
    }
    private fun open(key: ByteArray, sealed: String): String {
        val b = android.util.Base64.decode(sealed, android.util.Base64.NO_WRAP)
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding").apply { init(javax.crypto.Cipher.DECRYPT_MODE, javax.crypto.spec.SecretKeySpec(key, "AES"), javax.crypto.spec.GCMParameterSpec(128, b.copyOfRange(0, 12))) }
        return String(c.doFinal(b, 12, b.size - 12))
    }
    /** رفع الخزنة (مفاتيح التواصل + الأصدقاء + المجموعات) */
    fun vaultPush() {
        val k = vaultKey() ?: return
        if (!loggedIn) return
        ChatCrypto.publicKey  // يضمن وجود المفاتيح
        val o = JSONObject().put("priv", Extras.s("chat_priv", "")).put("pub", Extras.s("chat_pub", ""))
            .put("friends", Extras.s("chat_friends", "[]")).put("groups", Extras.s("chat_groups", "[]")).put("blocked", Extras.s("chat_blocked", ""))
            .put("cleared", Extras.s("chat_cleared", "{}")).put("delme", Extras.s("chat_delme", "")).put("pin", Extras.s("chat_pin", "")).put("hide", Extras.s("chat_hide", "")).put("mute", Extras.s("chat_mute", ""))
        runCatching { Supa.upsert("vault", JSONObject().put("id", Supa.uid).put("data", seal(k, o.toString()))) }
    }
    @Volatile private var pushPending = false
    /** رفع مؤجل بعد تغيير الأصدقاء */
    fun vaultPushSoon() {
        if (pushPending || vaultKey() == null || !loggedIn) return
        pushPending = true
        Thread { runCatching { Thread.sleep(4000); pushPending = false; vaultPush() } }.start()
    }
    /** بعد الدخول: استعادة المفاتيح والأصدقاء ثم جلب كل المحادثات من الخادم */
    private fun vaultSync(password: String) {
        val k = deriveKey(password, Supa.uid)
        Extras.ps("cloud_vk", android.util.Base64.encodeToString(k, android.util.Base64.NO_WRAP))
        val row = runCatching { Supa.select("vault?select=data&id=eq.${Supa.uid}") }.getOrNull()
        val data = row?.takeIf { it.length() > 0 }?.getJSONObject(0)?.optString("data")
        val o = data?.let { runCatching { JSONObject(open(k, it)) }.getOrNull() }
        if (o != null) {
            val priv = o.optString("priv"); val pub = o.optString("pub")
            if (priv.isNotBlank() && pub.isNotBlank()) { Extras.ps("chat_priv", priv); Extras.ps("chat_pub", pub) }
            // دمج الأصدقاء المحفوظين مع الموجودين
            runCatching {
                val cur = org.json.JSONArray(Extras.s("chat_friends", "[]")); val saved = org.json.JSONArray(o.optString("friends", "[]"))
                val seen = HashSet<String>(); val out = org.json.JSONArray()
                for (a in listOf(saved, cur)) for (i in 0 until a.length()) { val f = a.getJSONObject(i); if (seen.add(f.optString("p"))) out.put(f) }
                Extras.ps("chat_friends", out.toString())
            }
            if (o.optString("groups").length > 2 && Extras.s("chat_groups", "[]").length <= 2) Extras.ps("chat_groups", o.optString("groups"))
            if (o.optString("blocked").isNotBlank()) Extras.ps("chat_blocked", o.optString("blocked"))
            // حالة المحادثات كما تركها المستخدم آخر مرة (المحذوفة/المثبتة/المخفية/المكتومة)
            runCatching {
                val mine = JSONObject(Extras.s("chat_cleared", "{}")); val saved = JSONObject(o.optString("cleared", "{}"))
                saved.keys().forEach { k -> mine.put(k, maxOf(mine.optLong(k, 0L), saved.optLong(k, 0L))) }
                Extras.ps("chat_cleared", mine.toString())
            }
            fun merge(k: String, v: String) { if (v.isNotBlank()) Extras.ps(k, (Extras.s(k, "").split(",") + v.split(",")).filter { it.isNotBlank() }.distinct().joinToString(",")) }
            merge("chat_delme", o.optString("delme")); merge("chat_pin", o.optString("pin")); merge("chat_hide", o.optString("hide")); merge("chat_mute", o.optString("mute"))
        }
        // جلب كل الرسائل القديمة من الخادم وفكّ تشفيرها
        Extras.ps("chat_cursor", "1970-01-01T00:00:00Z")
        Chat.reloadForAccount()
        if (o == null) vaultPush()
    }
    /** بعد تغيير كلمة المرور: إعادة تشفير الخزنة بالمفتاح الجديد */
    private fun rekeyVault(newPassword: String) {
        Extras.ps("cloud_vk", android.util.Base64.encodeToString(deriveKey(newPassword, Supa.uid), android.util.Base64.NO_WRAP))
        vaultPush()
    }

    // ---------------- رموز التحقق ----------------
    /** إرسال رمز لاستعادة كلمة المرور: channel = sms | whatsapp | email */
    fun sendResetCode(phoneOrEmail: String, channel: String) {
        val body = JSONObject().put("create_user", false)
        if (channel == "email") {
            val id = phoneOrEmail.trim()
            val mail = if (id.contains('@')) id else runCatching { Supa.rpc("account_email", JSONObject().put("p", Chat.normPhone(id)), anon = true).trim().trim('"') }.getOrNull()?.takeIf { it.contains('@') && !it.endsWith("@sho3eb.app") }
                ?: throw CloudError(tr("لا يوجد بريد إلكتروني مربوط بهذا الرقم", "No email is linked to this phone"))
            // الرابط في البريد يفتح التطبيق مباشرة (sho3eb://auth) لتعيين كلمة مرور جديدة
            check(Supa.auth("POST", "otp?redirect_to=" + java.net.URLEncoder.encode(LINK_URL, "UTF-8"), body.put("email", mail)))
            Extras.ps("cloud_reset_id", mail)
        } else {
            check(Supa.auth("POST", "otp", body.put("phone", e164(phoneOrEmail)).put("channel", channel)))
            Extras.ps("cloud_reset_id", e164(phoneOrEmail))
        }
    }
    /** التحقق من رمز الاستعادة ثم تعيين كلمة مرور جديدة والدخول */
    fun resetWithCode(code: String, newPassword: String) {
        val id = Extras.s("cloud_reset_id", "")
        val body = JSONObject().put("token", code.trim())
        if (id.contains('@')) body.put("type", "email").put("email", id) else body.put("type", "sms").put("phone", id)
        val o = check(Supa.auth("POST", "verify", body))
        finishReset(o, newPassword)
    }

    const val LINK_URL = "sho3eb://auth"
    /** رابط دخول وصل من البريد وفُتح به التطبيق (ينتظر تعيين كلمة مرور جديدة) */
    val pendingLink = androidx.compose.runtime.mutableStateOf<Map<String, String>?>(null)

    /** قراءة رابط sho3eb://auth#access_token=...&refresh_token=... */
    fun handleLink(uri: android.net.Uri?): Boolean {
        if (uri == null || uri.scheme != "sho3eb" || uri.host != "auth") return false
        val raw = (uri.encodedFragment ?: "").ifBlank { uri.encodedQuery ?: "" }
        val m = raw.split("&").mapNotNull { kv -> kv.split("=", limit = 2).takeIf { it.size == 2 }?.let { java.net.URLDecoder.decode(it[0], "UTF-8") to java.net.URLDecoder.decode(it[1], "UTF-8") } }.toMap()
        pendingLink.value = m
        return true
    }

    /** تعيين كلمة مرور جديدة باستخدام رابط البريد */
    fun resetWithLink(link: Map<String, String>, newPassword: String): String {
        link["error_description"]?.let { throw CloudError(tr("الرابط غير صالح أو انتهت صلاحيته؛ اطلب رابطاً جديداً", "The link is invalid or expired; request a new one") + "\n" + it) }
        val access = link["access_token"] ?: throw CloudError(tr("الرابط غير صالح؛ اطلب رابطاً جديداً", "Invalid link; request a new one"))
        val u = Supa.userFor(access)
        if (u.first !in 200..299) throw CloudError(tr("انتهت صلاحية الرابط؛ اطلب رابطاً جديداً", "The link expired; request a new one"))
        val o = JSONObject().put("access_token", access).put("refresh_token", link["refresh_token"] ?: "")
            .put("expires_in", link["expires_in"]?.toLongOrNull() ?: 3600L).put("user", u.second)
        finishReset(o, newPassword)
        pendingLink.value = null
        return u.second.optJSONObject("user_metadata")?.optString("phone")?.ifBlank { null } ?: u.second.optString("email")
    }

    private fun finishReset(o: JSONObject, newPassword: String) {
        Supa.signOut(); Supa.adoptSession(o); Supa.markPermanent(true)
        check(Supa.auth("PUT", "user", JSONObject().put("password", newPassword), withSession = true))
        val mail = o.optJSONObject("user")?.optString("email") ?: ""
        loginId = mail
        val meta = o.optJSONObject("user")?.optJSONObject("user_metadata")
        afterLogin(meta?.optString("name") ?: "", meta?.optString("phone") ?: "", mail)
        // إن كانت الخزنة تُفتح بمفتاح محفوظ على هذا الجهاز نعيد تشفيرها بكلمة المرور الجديدة؛ وإلا نبدأ خزنة جديدة
        runCatching { rekeyVault(newPassword) }
        runCatching { Extras.ps("chat_cursor", "1970-01-01T00:00:00Z"); Chat.reloadForAccount() }
    }

    /** إرسال رمز للتحقق من أن رقم الهاتف لصاحبه */
    fun sendPhoneCode(phone: String, channel: String = Supa.otpChannel) {
        Supa.ensureSession()
        check(Supa.auth("PUT", "user", JSONObject().put("phone", e164(phone)).put("channel", channel), withSession = true))
    }
    fun verifyPhoneCode(phone: String, code: String) {
        val o = check(Supa.auth("POST", "verify", JSONObject().put("type", "phone_change").put("phone", e164(phone)).put("token", code.trim()), withSession = true))
        if (o.has("access_token")) Supa.adoptSession(o)
        Extras.ps("phone_verified", Chat.normPhone(phone))
    }
    fun isPhoneVerified(phone: String) = phone.isNotBlank() && Extras.s("phone_verified", "") == Chat.normPhone(phone)

    // ---------------- النسخ الاحتياطي السحابي ----------------
    private val skipPrefs = setOf("extras_prefs.xml")  // تحتوي جلسة الخادم الحالية؛ تُدمج بدل الاستبدال
    var lastBackup: Long get() = Extras.l("cloud_last_backup", 0L); private set(v) = Extras.pl("cloud_last_backup", v)

    /** ضغط كل بيانات التطبيق ورفعها لحساب المستخدم */
    fun backup(ctx: Context) {
        if (!loggedIn) throw CloudError(tr("سجّل الدخول بحساب أولاً", "Sign in first"))
        val app = Sho3ebApp.instance
        runCatching { app.db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close() }
        val out = File(ctx.cacheDir, "cloud_backup.zip")
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            fun add(f: File, name: String) { if (f.isFile && f.length() < 60_000_000) { z.putNextEntry(ZipEntry(name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() } }
            add(ctx.getDatabasePath(AppDatabase.NAME), "db/" + AppDatabase.NAME)
            File(ctx.applicationInfo.dataDir, "shared_prefs").listFiles()?.forEach { f -> add(f, "prefs/" + f.name) }
            listOf("chat", "photos", "quran_marks").forEach { d -> File(ctx.filesDir, d).walkTopDown().filter { it.isFile }.forEach { f -> add(f, "files/" + f.relativeTo(ctx.filesDir).path) } }
        }
        Supa.upload("${Supa.uid}/backup.zip", out.readBytes(), "application/zip", Supa.backupBucket)
        out.delete()
        lastBackup = System.currentTimeMillis()
    }

    /** هل يوجد نسخة احتياطية في الحساب؟ */
    fun hasBackup(): Boolean = runCatching { Supa.download("${Supa.uid}/backup.zip", Supa.backupBucket).size > 100 }.getOrDefault(false)

    /** استعادة كل البيانات من الحساب ثم إعادة تشغيل التطبيق */
    fun restore(ctx: Context) {
        val bytes = Supa.download("${Supa.uid}/backup.zip", Supa.backupBucket)
        // حفظ الجلسة الحالية لإعادتها بعد الاستبدال
        val keep = JSONObject()
        listOf("supa_url", "supa_key", "supa_at", "supa_rt", "supa_uid", "cloud_login", "supa_bucket", "supa_backup_bucket").forEach { k -> runCatching { Extras.s(k, "") }.getOrNull()?.takeIf { it.isNotBlank() }?.let { keep.put(k, it) } }
        keep.put("supa_exp", Extras.l("supa_exp", 0L)).put("supa_anon", false)
        File(ctx.filesDir, "pending_session.json").writeText(keep.toString())
        Sho3ebApp.instance.db.close()
        val dataDir = File(ctx.applicationInfo.dataDir)
        ZipInputStream(bytes.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name
                val target = when {
                    n.startsWith("db/") -> ctx.getDatabasePath(n.removePrefix("db/"))
                    n.startsWith("prefs/") -> File(dataDir, "shared_prefs/" + n.removePrefix("prefs/"))
                    n.startsWith("files/") -> File(ctx.filesDir, n.removePrefix("files/"))
                    else -> null
                }
                if (target != null && !n.contains("..")) {
                    target.parentFile?.mkdirs()
                    if (n.startsWith("db/")) listOf("-wal", "-shm", "-journal").forEach { File(target.path + it).delete() }
                    target.outputStream().use { z.copyTo(it) }
                }
                e = z.nextEntry
            }
        }
        com.sho3eb.app.core.Backup.restart(ctx)
    }

    /** يُستدعى عند بدء التطبيق: إعادة الجلسة بعد الاستعادة، ونسخ احتياطي تلقائي يومي */
    fun onAppStart(ctx: Context) {
        val f = File(ctx.filesDir, "pending_session.json")
        if (f.exists()) runCatching {
            val o = JSONObject(f.readText())
            o.keys().forEach { k -> when (k) { "supa_exp" -> Extras.pl(k, o.getLong(k)); "supa_anon" -> Extras.pb(k, o.getBoolean(k)); else -> Extras.ps(k, o.getString(k)) } }
            f.delete()
        }
        if (loggedIn && Extras.b("cloud_auto_backup", true) && System.currentTimeMillis() - lastBackup > 24 * 3600_000L)
            Thread { runCatching { Thread.sleep(30_000); backup(ctx) } }.start()
    }
}
