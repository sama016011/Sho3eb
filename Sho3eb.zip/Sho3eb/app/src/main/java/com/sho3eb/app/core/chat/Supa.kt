package com.sho3eb.app.core.chat

import com.sho3eb.app.BuildConfig
import com.sho3eb.app.core.Extras
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** عميل Supabase مبسّط: تسجيل دخول مجهول + REST + التخزين */
object Supa {
    val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS)
            .pingInterval(25, TimeUnit.SECONDS).build()
    }
    private val JSON = "application/json".toMediaType()

    var url: String
        get() = Extras.s("supa_url", "").ifBlank { BuildConfig.SUPABASE_URL }.ifBlank { com.sho3eb.app.core.Edition.embeddedString("supa_url") }.trim().trimEnd('/')
        set(v) = Extras.ps("supa_url", v.trim().trimEnd('/'))
    var key: String
        get() = Extras.s("supa_key", "").ifBlank { BuildConfig.SUPABASE_KEY }.ifBlank { com.sho3eb.app.core.Edition.embeddedString("supa_key") }.trim()
        set(v) = Extras.ps("supa_key", v.trim())
    val configured: Boolean get() = url.startsWith("https://") && key.length > 20

    // ---------- الجلسة ----------
    var access: String get() = Extras.s("supa_at", ""); private set(v) = Extras.ps("supa_at", v)
    var refresh: String get() = Extras.s("supa_rt", ""); private set(v) = Extras.ps("supa_rt", v)
    var uid: String get() = Extras.s("supa_uid", ""); private set(v) = Extras.ps("supa_uid", v)
    private var expiresAt: Long get() = Extras.l("supa_exp", 0L); set(v) = Extras.pl("supa_exp", v)
    val signedIn: Boolean get() = uid.isNotBlank() && refresh.isNotBlank()

    class SupaError(msg: String, val code: Int = 0) : Exception(msg)

    private fun saveSession(o: JSONObject) {
        access = o.getString("access_token"); refresh = o.optString("refresh_token", refresh)
        expiresAt = System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000 - 60_000
        o.optJSONObject("user")?.optString("id")?.takeIf { it.isNotBlank() }?.let { uid = it }
    }

    @Synchronized
    fun ensureSession() {
        if (!configured) throw SupaError("not configured")
        if (signedIn && System.currentTimeMillis() < expiresAt && access.isNotBlank()) return
        if (refresh.isNotBlank()) {
            val r = raw("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", refresh).toString(), auth = false)
            if (r.first in 200..299) { saveSession(JSONObject(r.second)); return }
        }
        val r = raw("POST", "/auth/v1/signup", "{}", auth = false)
        if (r.first !in 200..299) throw SupaError(if (r.second.contains("anonymous", true)) "anonymous_disabled" else "auth ${r.first}: ${r.second.take(200)}", r.first)
        saveSession(JSONObject(r.second))
    }

    fun signOut() { access = ""; refresh = ""; uid = ""; expiresAt = 0 }

    private fun raw(method: String, path: String, body: String?, auth: Boolean = true, headers: Map<String, String> = emptyMap()): Pair<Int, String> {
        val b = Request.Builder().url(url + path).header("apikey", key)
        if (auth && access.isNotBlank()) b.header("Authorization", "Bearer $access")
        else if (!key.startsWith("sb_")) b.header("Authorization", "Bearer $key")
        headers.forEach { (k, v) -> b.header(k, v) }
        val rb = body?.toRequestBody(JSON)
        when (method) { "GET" -> b.get(); "DELETE" -> if (rb != null) b.delete(rb) else b.delete(); else -> b.method(method, rb ?: "".toRequestBody(JSON)) }
        http.newCall(b.build()).execute().use { r -> return r.code to (r.body?.string() ?: "") }
    }

    /** طلب REST على الجداول */
    fun rest(method: String, path: String, body: Any? = null, prefer: String? = null): String {
        ensureSession()
        var r = raw(method, "/rest/v1/$path", body?.toString(), headers = if (prefer != null) mapOf("Prefer" to prefer) else emptyMap())
        if (r.first == 401) { expiresAt = 0; ensureSession(); r = raw(method, "/rest/v1/$path", body?.toString(), headers = if (prefer != null) mapOf("Prefer" to prefer) else emptyMap()) }
        if (r.first !in 200..299) throw SupaError("${r.first}: ${r.second.take(300)}", r.first)
        return r.second
    }
    fun select(path: String): JSONArray = JSONArray(rest("GET", path).ifBlank { "[]" })
    fun insert(table: String, row: JSONObject): JSONObject = JSONArray(rest("POST", table, row, "return=representation")).getJSONObject(0)
    fun insertMany(table: String, rows: JSONArray): JSONArray = JSONArray(rest("POST", table, rows, "return=representation"))
    fun update(path: String, patch: JSONObject) { rest("PATCH", path, patch, "return=minimal") }
    fun upsert(table: String, row: JSONObject) { rest("POST", table, row, "resolution=merge-duplicates,return=minimal") }

    // ---------- التخزين ----------
    fun upload(path: String, bytes: ByteArray, mime: String = "application/octet-stream") {
        ensureSession()
        val req = Request.Builder().url("$url/storage/v1/object/chat/$path").header("apikey", key).header("Authorization", "Bearer $access")
            .header("x-upsert", "true").post(bytes.toRequestBody(mime.toMediaType())).build()
        http.newCall(req).execute().use { r -> if (!r.isSuccessful) throw SupaError("upload ${r.code}: ${r.body?.string()?.take(200)}", r.code) }
    }
    fun download(path: String): ByteArray {
        ensureSession()
        val req = Request.Builder().url("$url/storage/v1/object/authenticated/chat/$path").header("apikey", key).header("Authorization", "Bearer $access").get().build()
        http.newCall(req).execute().use { r -> if (!r.isSuccessful) throw SupaError("download ${r.code}", r.code); return r.body!!.bytes() }
    }
}
