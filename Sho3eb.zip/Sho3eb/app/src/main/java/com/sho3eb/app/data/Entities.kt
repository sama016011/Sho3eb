package com.sho3eb.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** شخص (عضو جمعية / مستلف / عميل تقسيط) */
@Entity(tableName = "people")
data class Person(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val photoPath: String? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** الجمعية */
@Entity(tableName = "associations")
data class Association(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val shareAmount: Double,          // المبلغ الذي يدفعه كل عضو في كل دورة
    val periodType: String = "MONTH", // DAY / WEEK / MONTH
    val periodCount: Int = 1,         // كل كم (يوم/أسبوع/شهر)
    val startDate: Long,              // epochDay لموعد الدورة الأولى
    val notes: String = "",
    val reminderEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/** عضو في جمعية + ترتيب استلامه */
@Entity(tableName = "assoc_members", indices = [Index("associationId"), Index("personId")])
data class AssocMember(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val associationId: Long,
    val personId: Long,
    val turnOrder: Int
)

/** دفعة عضو في دورة معينة */
@Entity(tableName = "assoc_payments", indices = [Index("associationId"), Index("memberId")])
data class AssocPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val associationId: Long,
    val memberId: Long,
    val round: Int,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

/** تسليم إجمالي الدورة للمستلم */
@Entity(tableName = "assoc_payouts", indices = [Index("associationId")])
data class AssocPayout(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val associationId: Long,
    val round: Int,
    val memberId: Long,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

/** حركة سلفة: LOAN = سلفة جديدة (تضاف على الدين) / PAY = سداد (يخصم) */
@Entity(tableName = "loan_tx", indices = [Index("personId")])
data class LoanTx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val type: String,
    val amount: Double,
    val date: Long,
    val dueDate: Long? = null,
    val note: String = ""
) {
    companion object {
        const val LOAN = "LOAN"
        const val PAY = "PAY"
    }
}

/** عملية بيع بالتقسيط */
@Entity(tableName = "sales", indices = [Index("personId")])
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val product: String,
    val totalPrice: Double,
    val costPrice: Double = 0.0,
    val downPayment: Double = 0.0,
    val installmentsCount: Int,
    val periodType: String = "MONTH",
    val periodCount: Int = 1,
    val startDate: Long,              // موعد القسط الأول
    val notes: String = "",
    val reminderEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sale_payments", indices = [Index("saleId")])
data class SalePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

/** حساب مالي (صندوق) يمكن ربطه بجهة تواصل */
@Entity(tableName = "accounts", indices = [Index("personId")])
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val personId: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** حركة حساب: IN = إضافة / OUT = صرف */
@Entity(tableName = "account_tx", indices = [Index("accountId")])
data class AccountTx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: Long,
    val type: String,
    val amount: Double,
    val date: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val IN = "IN"
        const val OUT = "OUT"
    }
}
