package com.sho3eb.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** شخص (عضو جمعية / مستلف / عميل تقسيط) */
@Entity(tableName = "people")
data class Person(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val photoPath: String? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** الجمعية */
@Entity(tableName = "associations")
data class Association(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val shareAmount: Double,          // المبلغ الذي يدفعه كل عضو في كل دورة
    val periodType: String = "MONTH", // DAY / WEEK / MONTH
    val periodCount: Int = 1,         // كل كم (يوم/أسبوع/شهر)
    val startDate: Long,              // epochDay لموعد الدورة الأولى
    val notes: String = "",
    val reminderEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/** عضو في جمعية + ترتيب استلامه */
@Entity(tableName = "assoc_members", indices = [Index("associationId"), Index("personId")])
data class AssocMember(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val associationId: Long,
    val personId: Long,
    val turnOrder: Int
)

/** دفعة عضو في دورة معينة */
@Entity(tableName = "assoc_payments", indices = [Index("associationId"), Index("memberId")])
data class AssocPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val associationId: Long,
    val memberId: Long,
    val round: Int,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

/** تسليم إجمالي الدورة للمستلم */
@Entity(tableName = "assoc_payouts", indices = [Index("associationId")])
data class AssocPayout(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val associationId: Long,
    val round: Int,
    val memberId: Long,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

/** حركة سلفة: LOAN = سلفة جديدة (تضاف على الدين) / PAY = سداد (يخصم) */
@Entity(tableName = "loan_tx", indices = [Index("personId")])
data class LoanTx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val type: String,
    val amount: Double,
    val date: Long,
    val dueDate: Long? = null,
    val note: String = ""
) {
    companion object {
        const val LOAN = "LOAN"
        const val PAY = "PAY"
    }
}

/** عملية بيع بالتقسيط */
@Entity(tableName = "sales", indices = [Index("personId")])
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val product: String,
    val totalPrice: Double,
    val costPrice: Double = 0.0,
    val downPayment: Double = 0.0,
    val installmentsCount: Int,
    val periodType: String = "MONTH",
    val periodCount: Int = 1,
    val startDate: Long,              // موعد القسط الأول
    val notes: String = "",
    val reminderEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sale_payments", indices = [Index("saleId")])
data class SalePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

/** حساب مالي (صندوق) يمكن ربطه بجهة تواصل */
@Entity(tableName = "accounts", indices = [Index("personId")])
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val personId: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** نوع الحساب: CASH صندوق نقدي، BANK حساب بنكي، CARD بطاقة ائتمان، WALLET محفظة إلكترونية */
    val kind: String = "CASH",
    val bank: String = "",
    val iban: String = "",
    /** آخر 4 أرقام من البطاقة فقط (لا يُحفظ الرقم كاملاً) */
    val cardLast4: String = "",
    val cardExpiry: String = "",
    @ColumnInfo(defaultValue = "0") val creditLimit: Double = 0.0,
    /** يوم استحقاق سداد البطاقة */
    @ColumnInfo(defaultValue = "0") val dueDay: Int = 0,
    /** تطبيق البنك للدفع (اسم الحزمة) */
    val payApp: String = "",
    /** رابط الدفع / موقع البنك */
    val payLink: String = ""
)

/** حركة حساب: IN = إضافة / OUT = صرف */
@Entity(tableName = "account_tx", indices = [Index("accountId")])
data class AccountTx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: Long,
    val type: String,
    val amount: Double,
    val date: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val srcType: String? = null,   // مصدر الحركة إن كانت مرحّلة من قسم آخر
    val srcId: Long? = null
) {
    companion object {
        const val IN = "IN"
        const val OUT = "OUT"
        const val SRC_LOAN = "LOAN_TX"
        const val SRC_SALE_PAY = "SALE_PAY"
        const val SRC_SALE_DOWN = "SALE_DOWN"
        const val SRC_LIV = "LIV"
        const val SRC_RENT = "RENT_PAY"
        const val SRC_DEPOSIT = "LEASE_DEP"
        const val SRC_PROP_EXP = "PROP_EXP"
        const val SRC_DEBT = "DEBT_TX"
        const val SRC_WORKER = "WORKER_TX"
        const val SRC_ASSET = "ASSET"
        const val SRC_SPLIT = "SPLIT_EXP"
        const val SRC_CAR = "CAR_EXP"
        const val SRC_SUB = "SUB_PAY"
        const val SRC_INV = "INV_PAY"
        const val SRC_PARTY = "PARTY_TX"
        const val SRC_CREDIT = "CREDIT"
    }
}

/** مرفق (صورة / ملف) مرتبط بأي حركة في البرنامج */
@Entity(tableName = "attachments", indices = [Index(value = ["ownerType", "ownerId"])])
data class Attachment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ownerType: String,
    val ownerId: Long,
    val name: String,
    val path: String,
    val mime: String = "",
    val size: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

// ======================= مصاريف المعيشة =======================
/** بند في ديباجة المعيشة: دخل أو مصروف ثابت مع تكراره */
@Entity(tableName = "liv_items")
data class LivItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,                 // INCOME / EXPENSE
    val name: String,
    val category: String,
    val amount: Double,
    val freq: String = "MONTH",       // DAY / WEEK / MONTH / YEAR
    val priority: String = "ESSENTIAL", // ESSENTIAL / IMPORTANT / LUXURY
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** إضافة تلقائية شهرياً في هذا اليوم (0 = متوقف) */
    @ColumnInfo(defaultValue = "0") val autoDay: Int = 0
)

/** فترة معيشة مثل "شهر يناير" */
@Entity(tableName = "liv_periods")
data class LivPeriod(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startDate: Long,
    val endDate: Long,
    val notes: String = "",
    val savingsGoal: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

/** حركة فعلية داخل الفترة */
@Entity(tableName = "liv_entries", indices = [Index("periodId")])
data class LivEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val periodId: Long,
    val kind: String,
    val itemId: Long? = null,
    val name: String,
    val category: String,
    val priority: String = "ESSENTIAL",
    val amount: Double,
    val date: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ======================= العقارات والإيجارات =======================
@Entity(tableName = "properties")
data class Property(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String = "BUILDING",      // APARTMENT / VILLA / BUILDING / SHOP / OFFICE / WAREHOUSE / LAND / OTHER
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "prop_units", indices = [Index("propertyId")])
data class PropUnit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val propertyId: Long,
    val name: String,
    val type: String = "APARTMENT",
    val rent: Double = 0.0,              // الإيجار المقترح شهرياً
    val notes: String = ""
)

@Entity(tableName = "leases", indices = [Index("unitId")])
data class Lease(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val unitId: Long,
    val tenantId: Long,
    val startDate: Long,
    val endDate: Long,
    val rentAmount: Double,             // قيمة الدفعة الواحدة
    val periodMonths: Int = 1,          // كل كم شهر تُدفع (1، 3، 6، 12)
    val deposit: Double = 0.0,          // التأمين
    val active: Boolean = true,
    val reminderEnabled: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "lease_payments", indices = [Index("leaseId")])
data class LeasePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val leaseId: Long,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

@Entity(tableName = "prop_expenses", indices = [Index("propertyId")])
data class PropExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val propertyId: Long,
    val unitId: Long? = null,
    val category: String = "MAINT",     // MAINT / ELECTRIC / WATER / TAX / INSURANCE / COMMISSION / CLEANING / FURNISH / OTHER
    val amount: Double,
    val date: Long,
    val note: String = ""
)

// ======================= ديوني (ما عليّ) =======================
@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val creditor: String,
    val personId: Long? = null,
    val type: String = "PERSON",         // PERSON / BANK / STORE / COMPANY / OTHER
    val startDate: Long,
    val dueDate: Long? = null,           // موعد السداد النهائي
    val installment: Double = 0.0,       // قسط دوري (0 = بدون أقساط)
    val periodMonths: Int = 1,
    val firstDue: Long? = null,
    val priority: Int = 2,               // 1 عالية، 2 متوسطة، 3 منخفضة
    val reminderEnabled: Boolean = true,
    val notes: String = "",
    val closed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "debt_tx", indices = [Index("debtId")])
data class DebtTx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val debtId: Long,
    val type: String,                    // BORROW (زيادة الدين) / PAY (سداد)
    val amount: Double,
    val date: Long,
    val note: String = ""
) {
    companion object {
        const val BORROW = "BORROW"
        const val PAY = "PAY"
    }
}

// ======================= العمال، الأصول، التقسيم، السيارة، الاشتراكات =======================
@Entity(tableName = "workers")
data class Worker(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val personId: Long? = null,
    val phone: String = "",
    val job: String = "",
    val wageType: String = "DAY",
    val wage: Double = 0.0,
    val otRate: Double = 0.0,
    val startDate: Long,
    val active: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "worker_entries", indices = [Index("workerId")])
data class WorkerEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: Long,
    val date: Long,
    val type: String,
    val qty: Double = 0.0,
    val amount: Double = 0.0,
    val project: String = "",
    val note: String = ""
)

@Entity(tableName = "assets")
data class Asset(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val qty: Double = 0.0,
    val unit: String = "",
    val karat: Int = 24,
    val buyPrice: Double = 0.0,
    val buyDate: Long,
    val unitPrice: Double = 0.0,
    val currentValue: Double = 0.0,
    val priceDate: Long = 0L,
    val zakatable: Boolean = false,
    val sold: Boolean = false,
    val sellPrice: Double = 0.0,
    val sellDate: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "split_groups")
data class SplitGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val notes: String = "",
    val closed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "split_members", indices = [Index("groupId")])
data class SplitMember(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupId: Long,
    val name: String,
    val phone: String = "",
    val personId: Long? = null,
    val isMe: Boolean = false
)

@Entity(tableName = "split_expenses", indices = [Index("groupId")])
data class SplitExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupId: Long,
    val title: String,
    val amount: Double,
    val payerId: Long,
    val date: Long,
    val shares: String = "",
    val note: String = ""
)

@Entity(tableName = "split_settles", indices = [Index("groupId")])
data class SplitSettle(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupId: Long,
    val fromId: Long,
    val toId: Long,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val plate: String = "",
    val model: String = "",
    val year: Int = 0,
    val odometer: Long = 0L,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "car_expenses", indices = [Index("vehicleId")])
data class CarExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val type: String,
    val amount: Double,
    val date: Long,
    val odometer: Long = 0L,
    val liters: Double = 0.0,
    val note: String = ""
)

@Entity(tableName = "car_reminders", indices = [Index("vehicleId")])
data class CarReminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val title: String,
    val type: String = "OTHER",
    val lastDate: Long? = null,
    val lastKm: Long = 0L,
    val intervalMonths: Int = 0,
    val intervalKm: Long = 0L,
    val dueDate: Long? = null,
    val enabled: Boolean = true
)

@Entity(tableName = "subscriptions")
data class Subscription(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val amount: Double,
    val periodMonths: Int = 1,
    val nextDate: Long,
    val variable: Boolean = false,
    val remindDays: Int = 3,
    val active: Boolean = true,
    val toLiving: Boolean = true,
    val accountId: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sub_payments", indices = [Index("subId")])
data class SubPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subId: Long,
    val amount: Double,
    val date: Long,
    val note: String = ""
)

// ======================= المحل والمخزون والفواتير، خزنة المستندات =======================
@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sku: String = "",
    val category: String = "",
    val unit: String = "",
    val cost: Double = 0.0,
    val price: Double = 0.0,
    val openingQty: Double = 0.0,
    val minQty: Double = 0.0,
    val trackStock: Boolean = true,
    val active: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "invoices")
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val number: Long = 0L,
    val partyName: String = "",
    val partyPhone: String = "",
    val personId: Long? = null,
    val date: Long,
    val dueDate: Long? = null,
    val discount: Double = 0.0,
    val taxPct: Double = 0.0,
    val status: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    /** نظام الأقساط: عدد الأقساط (0 = بدون تقسيط) */
    @ColumnInfo(defaultValue = "0") val instCount: Int = 0,
    /** المدة بين كل قسط والذي يليه بالأشهر */
    @ColumnInfo(defaultValue = "1") val instMonths: Int = 1,
    /** تاريخ أول قسط */
    val instStart: Long? = null,
    /** الدفعة المقدمة (تُخصم قبل التقسيط) */
    @ColumnInfo(defaultValue = "0") val instDown: Double = 0.0,
    /** العميل/المورد المسجّل (مع الكود) */
    val partyId: Long? = null
)

@Entity(tableName = "invoice_items", indices = [Index("invoiceId")])
data class InvoiceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long,
    val productId: Long? = null,
    val name: String,
    val qty: Double = 1.0,
    val price: Double = 0.0,
    val cost: Double = 0.0
)

@Entity(tableName = "invoice_payments", indices = [Index("invoiceId")])
data class InvoicePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long,
    val amount: Double,
    val date: Long,
    val method: String = "CASH",
    val note: String = ""
)

@Entity(tableName = "stock_adjs", indices = [Index("productId")])
data class StockAdj(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val qty: Double,
    val date: Long,
    val note: String = ""
)

@Entity(tableName = "vault_docs")
data class VaultDoc(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: String = "OTHER",
    val number: String = "",
    val holder: String = "",
    val issuer: String = "",
    val issueDate: Long? = null,
    val expiryDate: Long? = null,
    val remindDays: Int = 30,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ======================= العملاء والموردون (حسابات المحل) =======================
@Entity(tableName = "parties")
data class Party(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String = "",
    val name: String,
    val type: String = "CUSTOMER",
    val phone: String = "",
    val personId: Long? = null,
    val address: String = "",
    val taxNo: String = "",
    val opening: Double = 0.0,
    val creditLimit: Double = 0.0,
    val active: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "party_tx", indices = [Index("partyId")])
data class PartyTx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val partyId: Long,
    val type: String = "RECEIPT",
    val amount: Double,
    val date: Long,
    val method: String = "CASH",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ======================= دفتر ديون البقالة =======================
/** دفتر حساب آجل: OWE_ME = زبون يأخذ مني بالآجل، I_OWE = أنا آخذ من البقالة بالآجل */
@Entity(tableName = "credit_books")
data class CreditBook(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val personId: Long? = null,
    val mode: String = "OWE_ME",
    val creditLimit: Double = 0.0,
    val notes: String = "",
    val closed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "credit_entries", indices = [Index("bookId")])
data class CreditEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val type: String = "BUY",          // BUY = سحب بضاعة (يزيد الدين) / PAY = سداد
    val amount: Double,
    val items: String = "",
    val date: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// ======================= الوصفات والسكري والتصاميم =======================
@Entity(tableName = "user_recipes")
data class UserRecipe(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val cuisine: String = "",
    val meal: String = "",
    val ingredients: String = "",
    val steps: String = "",
    val servings: Int = 4,
    val minutes: Int = 0,
    val calories: Int = 0,
    val carbs: Double = 0.0,
    val protein: Double = 0.0,
    val fat: Double = 0.0,
    val videoUrl: String = "",
    val photoPath: String = "",
    val notes: String = "",
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

/** قراءات سكر الدم */
@Entity(tableName = "glucose_logs")
data class GlucoseLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val value: Double,                 // mg/dL دائماً
    val context: String = "RANDOM",    // FASTING / BEFORE / AFTER / BEDTIME / RANDOM
    val date: Long,
    val minute: Int = 0,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/** مشاريع تصميم الغرف والشقق والأراضي (البيانات بصيغة JSON) */
@Entity(tableName = "design_projects")
data class DesignProject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String = "ROOM",         // ROOM / APARTMENT / LAND
    val name: String,
    val data: String = "",
    val cost: Double = 0.0,
    val photoPath: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
