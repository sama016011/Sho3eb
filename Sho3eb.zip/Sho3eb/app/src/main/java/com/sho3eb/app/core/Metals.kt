package com.sho3eb.app.core

import com.sho3eb.app.islam.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * أسعار الذهب والفضة المحدّثة من الإنترنت (السعر الفوري العالمي) محوّلة إلى العملة المختارة.
 * المصادر مجانية وبدون مفتاح:
 *  - السعر الفوري للأونصة بالدولار: api.gold-api.com
 *  - أسعار العملات: open.er-api.com ، والاحتياطي: currency-api عبر jsdelivr (يحتوي أيضاً XAU و XAG)
 * ملاحظة: هذا سعر الخام دون المصنعية وهامش المحلات.
 */
object Metals {
    const val OUNCE = 31.1034768

    data class Cur(val code: String, val ar: String, val en: String) {
        val label get() = tr(ar, en)
    }

    val currencies = listOf(
        Cur("SAR", "ريال سعودي", "Saudi riyal"), Cur("AED", "درهم إماراتي", "UAE dirham"), Cur("KWD", "دينار كويتي", "Kuwaiti dinar"),
        Cur("QAR", "ريال قطري", "Qatari riyal"), Cur("BHD", "دينار بحريني", "Bahraini dinar"), Cur("OMR", "ريال عماني", "Omani rial"),
        Cur("EGP", "جنيه مصري", "Egyptian pound"), Cur("JOD", "دينار أردني", "Jordanian dinar"), Cur("IQD", "دينار عراقي", "Iraqi dinar"),
        Cur("YER", "ريال يمني", "Yemeni rial"), Cur("SDG", "جنيه سوداني", "Sudanese pound"), Cur("LYD", "دينار ليبي", "Libyan dinar"),
        Cur("TND", "دينار تونسي", "Tunisian dinar"), Cur("DZD", "دينار جزائري", "Algerian dinar"), Cur("MAD", "درهم مغربي", "Moroccan dirham"),
        Cur("LBP", "ليرة لبنانية", "Lebanese pound"), Cur("SYP", "ليرة سورية", "Syrian pound"), Cur("USD", "دولار أمريكي", "US dollar"),
        Cur("EUR", "يورو", "Euro"), Cur("GBP", "جنيه إسترليني", "British pound"), Cur("TRY", "ليرة تركية", "Turkish lira"),
        Cur("PKR", "روبية باكستانية", "Pakistani rupee"), Cur("INR", "روبية هندية", "Indian rupee"), Cur("BDT", "تاكا بنغلاديشي", "Bangladeshi taka"),
        Cur("IDR", "روبية إندونيسية", "Indonesian rupiah"), Cur("MYR", "رينغيت ماليزي", "Malaysian ringgit"), Cur("CAD", "دولار كندي", "Canadian dollar"),
        Cur("AUD", "دولار أسترالي", "Australian dollar"), Cur("CHF", "فرنك سويسري", "Swiss franc"), Cur("NGN", "نيرة نيجيرية", "Nigerian naira")
    )
    fun cur(code: String) = currencies.firstOrNull { it.code == code } ?: Cur(code, code, code)

    /** تخمين العملة من رمز العملة المكتوب في إعدادات التطبيق */
    fun guessFromSymbol(sym: String): String {
        val s = sym.trim().lowercase()
        return when {
            s.contains("ر.س") || s == "sar" || s.contains("ريال س") -> "SAR"
            s.contains("د.إ") || s.contains("aed") || s.contains("درهم إ") -> "AED"
            s.contains("د.ك") || s.contains("kwd") -> "KWD"
            s.contains("ر.ق") || s.contains("qar") -> "QAR"
            s.contains("د.ب") || s.contains("bhd") -> "BHD"
            s.contains("ر.ع") || s.contains("omr") -> "OMR"
            s.contains("ج.م") || s.contains("egp") || s.contains("جنيه") -> "EGP"
            s.contains("د.أ") || s.contains("jod") -> "JOD"
            s.contains("د.م") || s.contains("mad") -> "MAD"
            s.contains("د.ج") || s.contains("dzd") -> "DZD"
            s.contains("د.ت") || s.contains("tnd") -> "TND"
            s.contains("د.ع") || s.contains("iqd") -> "IQD"
            s == "$" || s.contains("usd") || s.contains("دولار") -> "USD"
            s.contains("€") || s.contains("eur") -> "EUR"
            s.contains("£") || s.contains("gbp") -> "GBP"
            s.contains("₺") || s == "tl" || s.contains("try") -> "TRY"
            s.contains("rs") || s.contains("pkr") -> "PKR"
            s.contains("rp") || s.contains("idr") -> "IDR"
            s.contains("rm") || s.contains("myr") -> "MYR"
            s.contains("₹") || s.contains("inr") -> "INR"
            else -> "SAR"
        }
    }

    // ---------- الإعدادات المحفوظة ----------
    var currency: String
        get() = Extras.s("metalCur", "").ifBlank { guessFromSymbol(AppState.currency.value) }
        set(v) = Extras.ps("metalCur", v)
    /** تحديث تلقائي من الإنترنت (يتوقف عند التعديل اليدوي) */
    var auto: Boolean get() = Extras.b("metalAuto", true); set(v) = Extras.pb("metalAuto", v)
    var updatedAt: Long get() = Extras.l("metalUpd", 0L); set(v) = Extras.pl("metalUpd", v)
    var goldOzUsd: Double get() = Extras.d("goldOzUsd", 0.0); set(v) = Extras.pd("goldOzUsd", v)
    var silverOzUsd: Double get() = Extras.d("silverOzUsd", 0.0); set(v) = Extras.pd("silverOzUsd", v)
    var rate: Double get() = Extras.d("metalRate", 0.0); set(v) = Extras.pd("metalRate", v)
    /** السعر السابق لإظهار اتجاه التغير */
    var prevGold: Double get() = Extras.d("prevGold24", 0.0); set(v) = Extras.pd("prevGold24", v)

    val karats = listOf(24, 22, 21, 18, 14)
    fun goldGram(karat: Int = 24) = Extras.goldPrice24 * karat / 24.0
    val trend: Int get() = when { prevGold <= 0 || Extras.goldPrice24 <= 0 -> 0; Extras.goldPrice24 > prevGold + 0.001 -> 1; Extras.goldPrice24 < prevGold - 0.001 -> -1; else -> 0 }

    private suspend fun spotUsd(sym: String): Double? = try {
        JSONObject(Net.get("https://api.gold-api.com/price/$sym", 15000)).getDouble("price").takeIf { it > 0 }
    } catch (_: Exception) { null }

    private var fxCache: Pair<Long, JSONObject>? = null

    /** أسعار العملات مقابل الدولار (تُخزَّن 10 دقائق) */
    private fun fxRates(): JSONObject? {
        fxCache?.let { (t, j) -> if (System.currentTimeMillis() - t < 10 * 60_000) return j }
        val j = try { JSONObject(Net.get("https://open.er-api.com/v6/latest/USD", 15000)).getJSONObject("rates") } catch (_: Exception) { null }
        if (j != null) fxCache = System.currentTimeMillis() to j
        return j
    }

    private fun fallback(): JSONObject? = try {
        JSONObject(Net.get("https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json", 15000)).getJSONObject("usd")
    } catch (_: Exception) { null }

    /**
     * يجلب الأسعار ويحدّث سعر جرام الذهب عيار 24 والفضة بالعملة المختارة.
     * @return true عند النجاح
     */
    suspend fun refresh(force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (!force && System.currentTimeMillis() - updatedAt < 30_000) return@withContext true
        val code = currency
        var gold = spotUsd("XAU")
        var silver = spotUsd("XAG")
        var r: Double? = if (code == "USD") 1.0 else fxRates()?.optDouble(code)?.takeIf { !it.isNaN() && it > 0 }
        if (gold == null || silver == null || r == null) {
            val fb = fallback()
            if (fb != null) {
                if (gold == null) gold = fb.optDouble("xau").takeIf { !it.isNaN() && it > 0 }?.let { 1.0 / it }
                if (silver == null) silver = fb.optDouble("xag").takeIf { !it.isNaN() && it > 0 }?.let { 1.0 / it }
                if (r == null) r = fb.optDouble(code.lowercase()).takeIf { !it.isNaN() && it > 0 }
            }
        }
        if (gold == null || r == null) return@withContext false
        goldOzUsd = gold
        silver?.let { silverOzUsd = it }
        rate = r
        val g24 = round2(gold * r / OUNCE)
        if (Extras.goldPrice24 > 0 && kotlin.math.abs(Extras.goldPrice24 - g24) > 0.001) prevGold = Extras.goldPrice24
        Extras.goldPrice24 = g24
        silver?.let { Extras.silverPrice = round2(it * r / OUNCE) }
        updatedAt = System.currentTimeMillis()
        true
    }

    fun agoText(): String {
        if (updatedAt <= 0) return tr("لم يُحدَّث بعد", "Not updated yet")
        val sec = (System.currentTimeMillis() - updatedAt) / 1000
        return when {
            sec < 60 -> tr("الآن", "just now")
            sec < 3600 -> tr("منذ ${sec / 60} د", "${sec / 60} min ago")
            sec < 86400 -> tr("منذ ${sec / 3600} س", "${sec / 3600} h ago")
            else -> Fmt.date(java.time.LocalDate.now().minusDays(sec / 86400).toEpochDay())
        }
    }
}
