@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.sho3eb.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.core.video.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

private data class Sel(val kind: String, val id: String)

private fun fmtT(ms: Long): String { val s = ms / 1000; return String.format(java.util.Locale.US, "%02d:%02d.%d", s / 60, s % 60, (ms % 1000) / 100) }
private fun secs(ms: Long) = String.format(java.util.Locale.US, "%.1f", ms / 1000f)

private fun durationOf(ctx: Context, uri: String): Long = runCatching {
    val r = MediaMetadataRetriever()
    try { if (uri.startsWith("/")) r.setDataSource(uri) else r.setDataSource(ctx, Uri.parse(uri)); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L } finally { r.release() }
}.getOrDefault(0L)

private fun keep(ctx: Context, u: Uri) { runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
private fun vdir(ctx: Context) = File(ctx.filesDir, "vproj").apply { mkdirs() }

@Composable
fun VideoEditorScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val proj by VEditor.project
    var t by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Sel?>(null) }
    var dialog by remember { mutableStateOf("") }
    val density = LocalDensity.current
    var pps by remember { mutableFloatStateOf(with(density) { 46.dp.toPx() }) }
    val total = proj.totalMs.coerceAtLeast(1000)
    LaunchedEffect(total) { if (t > total) t = total }

    // ---------- إضافة الوسائط ----------
    fun addClips(uris: List<Uri>) {
        scope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.map { u ->
                    keep(ctx, u)
                    val mime = ctx.contentResolver.getType(u) ?: ""
                    val isVid = mime.startsWith("video") || u.toString().endsWith(".mp4")
                    val d = if (isVid) durationOf(ctx, u.toString()) else 0L
                    VClip(uri = u.toString(), video = isVid, durMs = if (isVid) d.coerceAtLeast(1000) else 4000, srcDurMs = d, motion = listOf("ZOOM_IN", "PAN_L", "ZOOM_OUT", "PAN_R")[(proj.clips.size) % 4])
                }
            }
            VEditor.update { it.copy(clips = it.clips + added) }
        }
    }
    fun addAudio(uri: String, name: String) {
        scope.launch {
            val d = withContext(Dispatchers.IO) { durationOf(ctx, uri) }
            if (d <= 0) { toast(ctx, tr("تعذر قراءة الملف الصوتي", "Couldn't read audio")); return@launch }
            val st = if (t < proj.totalMs) t else 0L
            val a = VAudio(uri = uri, name = name, srcDurMs = d, startMs = st, trimEndMs = d)
            VEditor.update { it.copy(audios = it.audios + a) }; sel = Sel("audio", a.id)
        }
    }
    fun addOverlay(o: VOverlay) { VEditor.update { it.copy(overlays = it.overlays + o) }; sel = Sel("ov", o.id) }
    fun atPlayhead(d: Long) = (if (t < total - 300) t else 0L) to d.coerceAtMost(total)

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l -> if (l.isNotEmpty()) addClips(l) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { keep(ctx, u); addAudio(u.toString(), MediaTools.nameOf(ctx, u)) } }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            val path = withContext(Dispatchers.IO) { runCatching { val f = File(vdir(ctx), "logo_" + System.currentTimeMillis() + ".png"); ctx.contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; f.absolutePath }.getOrNull() }
            if (path != null) {
                val ex = proj.overlays.firstOrNull { it.kind == "LOGO" && it.id == sel?.id }
                if (ex != null) VEditor.update { p -> p.copy(overlays = p.overlays.map { if (it.id == ex.id) it.copy(uri = path) else it }) }
                else addOverlay(VOverlay(kind = "LOGO", uri = path, startMs = 0, durMs = total, x = 0.88f, y = 0.12f, size = 0.07f, anim = "NONE", opacity = 0.9f))
                VPainter.clearCache()
            }
        }
    }
    var camFile by remember { mutableStateOf<File?>(null) }
    // استعادة لقطة الكاميرا إن أُعيد تشغيل التطبيق أثناء التصوير
    LaunchedEffect(Unit) {
        val pend = Extras.s("vcam_pending", "")
        if (pend.isNotBlank()) {
            Extras.ps("vcam_pending", "")
            val kind = pend.substringBefore("|"); val f = File(pend.substringAfter("|"))
            if (f.exists() && f.length() > 0 && VEditor.project.value.clips.none { it.uri == f.absolutePath }) {
                val d = if (kind == "video") withContext(Dispatchers.IO) { durationOf(ctx, f.absolutePath) } else 0L
                VEditor.update { p -> p.copy(clips = p.clips + VClip(uri = f.absolutePath, video = kind == "video", durMs = if (kind == "video") d.coerceAtLeast(1000) else 4000, srcDurMs = d)) }
                toast(ctx, tr("✅ أُضيفت اللقطة من الكاميرا", "✅ Camera shot added"))
            }
        }
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> Extras.ps("vcam_pending", ""); camFile?.let { f -> if (ok && f.length() > 0) VEditor.update { p -> p.copy(clips = p.clips + VClip(uri = f.absolutePath, video = false, durMs = 4000)) } } }
    val takeVideo = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        Extras.ps("vcam_pending", "")
        camFile?.let { f -> if (ok && f.length() > 0) scope.launch { val d = withContext(Dispatchers.IO) { durationOf(ctx, f.absolutePath) }; VEditor.update { p -> p.copy(clips = p.clips + VClip(uri = f.absolutePath, video = true, durMs = d.coerceAtLeast(1000), srcDurMs = d)) } } }
    }
    var pendingCam by remember { mutableStateOf("") }
    fun launchCam(kind: String) {
        val f = File(vdir(ctx), (if (kind == "photo") "cam_" else "vid_") + System.currentTimeMillis() + if (kind == "photo") ".jpg" else ".mp4")
        camFile = f
        // إن أغلق النظام التطبيق أثناء الكاميرا نستعيد الصورة/الفيديو عند العودة
        Extras.ps("vcam_pending", kind + "|" + f.absolutePath); Extras.pl("vcam_time", System.currentTimeMillis())
        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        runCatching { if (kind == "photo") takePhoto.launch(u) else takeVideo.launch(u) }.onFailure { toast(ctx, tr("لا يوجد تطبيق كاميرا", "No camera app")) }
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) launchCam(pendingCam) else toast(ctx, tr("يلزم إذن الكاميرا", "Camera permission needed")) }
    fun camera(kind: String) {
        pendingCam = kind
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchCam(kind) else camPerm.launch(Manifest.permission.CAMERA)
    }

    // ---------- المشغلات للمعاينة ----------
    val videoPlayer = remember { ExoPlayer.Builder(ctx).build().apply { repeatMode = Player.REPEAT_MODE_OFF } }
    val audioPlayers = remember { mutableMapOf<String, ExoPlayer>() }
    DisposableEffect(Unit) { onDispose { videoPlayer.release(); audioPlayers.values.forEach { it.release() }; audioPlayers.clear() } }
    val curIdx = if (proj.clips.isEmpty()) -1 else proj.clipAt(t)
    val curClip = proj.clips.getOrNull(curIdx)
    var loadedVideo by remember { mutableStateOf("") }

    LaunchedEffect(playing) {
        if (!playing) { videoPlayer.pause(); audioPlayers.values.forEach { it.pause() }; return@LaunchedEffect }
        if (t >= total - 50) t = 0
        var last = withFrameMillis { it }
        while (playing) {
            withFrameMillis { now -> t = (t + (now - last)).coerceAtMost(total); last = now }
            if (t >= total) { playing = false; break }
        }
    }
    // مزامنة الصوت والفيديو مع مؤشر الزمن
    LaunchedEffect(Unit) {
        while (true) {
            val p = VEditor.project.value
            // فيديو العنصر الحالي
            val ci = if (p.clips.isEmpty()) -1 else p.clipAt(t)
            val c = p.clips.getOrNull(ci)
            if (c != null && c.video) {
                if (loadedVideo != c.id + c.uri) { videoPlayer.setMediaItem(MediaItem.fromUri(if (c.uri.startsWith("/")) Uri.fromFile(File(c.uri)) else Uri.parse(c.uri))); videoPlayer.prepare(); loadedVideo = c.id + c.uri }
                val want = c.trimStartMs + (t - p.startOf(ci))
                videoPlayer.volume = if (c.muted) 0f else 1f
                if (abs(videoPlayer.currentPosition - want) > (if (playing) 400 else 60)) videoPlayer.seekTo(want)
                if (playing && !videoPlayer.isPlaying) videoPlayer.play() else if (!playing && videoPlayer.isPlaying) videoPlayer.pause()
            } else if (videoPlayer.isPlaying) videoPlayer.pause()
            // المسارات الصوتية
            val ids = p.audios.map { it.id }.toSet()
            audioPlayers.keys.filter { it !in ids }.forEach { audioPlayers.remove(it)?.release() }
            for (a in p.audios) {
                val pl = audioPlayers.getOrPut(a.id) { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(if (a.uri.startsWith("/")) Uri.fromFile(File(a.uri)) else Uri.parse(a.uri))); prepare() } }
                val rel = t - a.startMs
                val len = a.lenMs.coerceAtLeast(1)
                val active = playing && rel >= 0 && (rel < len || (a.loop && t < p.totalMs))
                if (active) {
                    val want = a.trimStartMs + (rel % len)
                    pl.volume = a.volume.coerceIn(0f, 1f)
                    if (abs(pl.currentPosition - want) > 400) pl.seekTo(want)
                    if (!pl.isPlaying) pl.play()
                } else if (pl.isPlaying) pl.pause()
            }
            delay(150)
        }
    }

    ScreenScaffold(title = tr("🎬 محرر الفيديو", "🎬 Video editor"), onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { dialog = "settings" }) { Icon(Icons.Filled.Settings, null) }
        FilledTonalButton(onClick = { playing = false; dialog = "export" }, enabled = proj.clips.isNotEmpty(), modifier = Modifier.padding(end = 6.dp)) { Icon(Icons.Filled.Upload, null); Spacer(Modifier.width(4.dp)); Text(tr("تصدير", "Export")) }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // ================= نافذة المعاينة =================
            Box(Modifier.fillMaxWidth().background(Color(0xFF0E0E12)).heightIn(max = 300.dp), contentAlignment = Alignment.Center) {
                PreviewPane(proj, t, curClip, videoPlayer, sel, onSelect = { sel = it }, onTogglePlay = { playing = !playing })
            }
            // ================= أزرار التشغيل =================
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { t = 0; playing = false }) { Icon(Icons.Filled.SkipPrevious, null) }
                FilledIconButton(onClick = { playing = !playing }, enabled = proj.clips.isNotEmpty()) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null) }
                Text(" " + fmtT(t) + " / " + fmtT(proj.totalMs), fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { pps = (pps / 1.4f).coerceAtLeast(8f) }) { Icon(Icons.Filled.ZoomOut, null) }
                IconButton(onClick = { pps = (pps * 1.4f).coerceAtMost(400f) }) { Icon(Icons.Filled.ZoomIn, null) }
            }
            // ================= الخط الزمني (مساطر بالثواني) =================
            Timeline(proj, t, pps, sel, playing, onSeek = { t = it.coerceIn(0, total); }, onSelect = { sel = it })
            HorizontalDivider()
            // ================= لوحة التعديل / الأدوات =================
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val s = sel
                when {
                    s?.kind == "clip" && proj.clips.any { it.id == s.id } -> ClipPanel(proj, s.id) { sel = null }
                    s?.kind == "audio" && proj.audios.any { it.id == s.id } -> AudioPanel(proj, s.id) { sel = null }
                    s?.kind == "ov" && proj.overlays.any { it.id == s.id } -> OverlayPanel(proj, s.id, onLogo = { pickLogo.launch(arrayOf("image/*")) }) { sel = null }
                    else -> {
                        if (proj.clips.isEmpty()) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                            Text(tr("ابدأ بإضافة صور أو فيديو، ثم أضف الموسيقى والنصوص والمؤثرات أو اختر قالباً جاهزاً. كل ما تضيفه يظهر فوراً في نافذة المعاينة وعلى الخط الزمني بالأسفل.",
                                "Start by adding photos or videos, then music, text and effects — or pick a ready template. Everything appears instantly in the preview and timeline."), Modifier.padding(12.dp))
                        }
                        Text(tr("اضغط على أي عنصر في الخط الزمني لتعديله، واضغط مطولاً ثم اسحبه لتغيير وقت بدايته، واسحب طرفه الأيمن لتغيير مدته.",
                            "Tap any timeline item to edit it; when selected, drag it to change its start and drag its right edge to change its length."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // ================= شريط الإضافة =================
            Surface(tonalElevation = 3.dp) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp, horizontal = 4.dp)) {
                    Tool("🖼️", tr("صور/فيديو", "Media")) { pickMedia.launch(arrayOf("image/*", "video/*")) }
                    Tool("📸", tr("كاميرا", "Camera")) { camera("photo") }
                    Tool("🎥", tr("تصوير فيديو", "Record video")) { camera("video") }
                    Tool("🎵", tr("موسيقى/صوت", "Music")) { pickAudio.launch(arrayOf("audio/*", "video/*")) }
                    Tool("🎙️", tr("تسجيل صوت", "Voice")) { dialog = "mic" }
                    Tool("🔤", tr("نص", "Text")) { val (st, d) = atPlayhead(3500); addOverlay(VOverlay(kind = "TEXT", text = tr("اكتب هنا", "Your text"), startMs = st, durMs = d, x = 0.5f, y = 0.8f, anim = "POP")) }
                    Tool("🏷️", tr("شعار", "Logo")) { sel = null; pickLogo.launch(arrayOf("image/*")) }
                    Tool("😀", tr("ملصقات", "Stickers")) { dialog = "sticker" }
                    Tool("✨", tr("مؤثرات", "Effects")) { dialog = "fx" }
                    Tool("🖼", tr("إطارات", "Frames")) { dialog = "frame" }
                    Tool("🎨", tr("قوالب جاهزة", "Templates")) { dialog = "templates" }
                    Tool("🎬", tr("بداية ونهاية", "Intro/Outro")) { dialog = "cards" }
                    Tool("🔀", tr("انتقالات", "Transitions")) { dialog = "trans" }
                    Tool("⚙️", tr("الجودة والمقاس", "Format")) { dialog = "settings" }
                }
            }
        }
    }

    when (dialog) {
        "sticker" -> StickerDialog({ dialog = "" }) { e -> dialog = ""; val (st, d) = atPlayhead(4000); addOverlay(VOverlay(kind = "STICKER", key = e, startMs = st, durMs = d, x = 0.5f, y = 0.35f, size = 0.12f, anim = "FLOAT")) }
        "fx" -> OptDialog(tr("✨ المؤثرات المتحركة", "✨ Animated effects"), VEditor.fxKinds, { dialog = "" }) { k -> dialog = ""; addOverlay(VOverlay(kind = "FX", key = k, startMs = 0, durMs = total, anim = "FADE")) }
        "frame" -> OptDialog(tr("🖼 إطارات احترافية", "🖼 Pro frames"), VEditor.frames, { dialog = "" }) { k -> dialog = ""; addOverlay(VOverlay(kind = "FRAME", key = k, startMs = 0, durMs = total, anim = "FADE")) }
        "templates" -> TemplatesDialog(proj, { dialog = "" }, onPick = { pickMedia.launch(arrayOf("image/*", "video/*")) }) { dialog = ""; sel = null; t = 0 }
        "settings" -> SettingsDialog(proj) { dialog = "" }
        "cards" -> CardsDialog({ dialog = "" }) { kind, style -> dialog = ""; val id = VEditor.setCard(kind, style); sel = Sel("clip", id); t = if (kind == "intro") 0L else VEditor.project.value.let { it.startOf(it.clips.lastIndex) } }
        "trans" -> OptDialog(tr("🔀 الانتقال بين الصور (للكل)", "🔀 Transition between photos (all)"), VEditor.transitions, { dialog = "" }) { k -> dialog = ""; VEditor.update { p -> p.copy(clips = p.clips.map { it.copy(transition = k) }) }; toast(ctx, tr("تم تطبيق الانتقال على كل الصور، ويمكنك تغييره لكل صورة على حدة بالضغط عليها", "Applied to all; tap a photo to change it individually")) }
        "mic" -> MicDialog({ dialog = "" }) { path -> dialog = ""; addAudio(path, tr("تسجيل صوتي", "Voice recording")) }
        "export" -> ExportDialog(proj, nav) { dialog = "" }
    }
}

@Composable
private fun Tool(emoji: String, label: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp).widthIn(min = 58.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 22.sp)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

// =====================================================================
// نافذة المعاينة
// =====================================================================
@Composable
private fun PreviewPane(proj: VProject, t: Long, cur: VClip?, player: ExoPlayer, sel: Sel?, onSelect: (Sel?) -> Unit, onTogglePlay: () -> Unit) {
    val ctx = LocalContext.current
    BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val maxW = maxWidth; val maxH = 300.dp
        val ratio = proj.ratio
        val (bw, bh) = if (maxW / ratio <= maxH) maxW to maxW / ratio else maxH * ratio to maxH
        val density = LocalDensity.current
        val wpx = with(density) { bw.roundToPx() }.coerceAtLeast(16); val hpx = with(density) { bh.roundToPx() }.coerceAtLeast(16)
        var ready by remember { mutableIntStateOf(0) }
        val painter = remember(wpx, hpx) { VPainter(ctx.applicationContext, proj, wpx, hpx, async = true) }
        painter.proj = proj
        DisposableEffect(painter) { painter.onReady = { ready++ }; onDispose { painter.onReady = null } }
        // تجهيز الصور القريبة مسبقاً
        LaunchedEffect(painter, proj.clips, cur?.id) {
            val i = proj.clips.indexOfFirst { it.id == cur?.id }.coerceAtLeast(0)
            proj.clips.drop(i).take(3).filter { !it.video && !it.isCard }.forEach { painter.warm(it.uri) }
        }
        val selOv = proj.overlays.firstOrNull { it.id == sel?.id && sel.kind == "ov" }
        Box(Modifier.size(bw, bh).clip(RoundedCornerShape(4.dp)).background(Color.Black)) {
            if (cur?.video == true) AndroidView(factory = { c -> PlayerView(c).apply { useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; setShutterBackgroundColor(android.graphics.Color.BLACK) } },
                update = { it.player = player }, modifier = Modifier.fillMaxSize())
            val selNow by rememberUpdatedState(sel)
            val selectCb by rememberUpdatedState(onSelect)
            val toggleCb by rememberUpdatedState(onTogglePlay)
            Canvas(Modifier.fillMaxSize()
                .pointerInput(wpx, hpx) {
                    // سحب أي نص/ملصق/شعار مباشرة، تكبيره بإصبعين وتدويره بإصبعين
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val hit = painter.bounds.entries.firstOrNull { it.value.contains(down.position.x, down.position.y) }?.key
                        val target = hit ?: selNow?.takeIf { it.kind == "ov" }?.id?.takeIf { id -> VEditor.project.value.overlays.any { it.id == id && it.kind in setOf("TEXT", "LOGO", "STICKER") } && painter.bounds.containsKey(id) }
                        if (hit != null) selectCb(Sel("ov", hit))
                        var moved = false
                        do {
                            val ev = awaitPointerEvent()
                            val pan = ev.calculatePan(); val zoom = ev.calculateZoom(); val rot = ev.calculateRotation()
                            if (target != null && (pan != Offset.Zero || zoom != 1f || rot != 0f)) {
                                if (abs(pan.x) + abs(pan.y) > 1f || zoom != 1f || rot != 0f) moved = true
                                VEditor.update { p -> p.copy(overlays = p.overlays.map { o ->
                                    if (o.id != target) o else o.copy(x = (o.x + pan.x / wpx).coerceIn(-0.2f, 1.2f), y = (o.y + pan.y / hpx).coerceIn(-0.2f, 1.2f),
                                        size = (o.size * zoom).coerceIn(0.02f, 0.45f), rot = ((o.rot + rot + 540f) % 360f) - 180f)
                                }) }
                                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                            } else if (target == null && ev.changes.any { (it.position - down.position).getDistance() > 24f }) moved = true
                        } while (ev.changes.any { it.pressed })
                        if (!moved && hit == null) toggleCb()
                    }
                }) {
                ready
                drawIntoCanvas { painter.draw(it.nativeCanvas, t) }
                if (selOv != null) painter.bounds[selOv.id]?.let { r ->
                    drawRect(Color(0xFF29B6F6), Offset(r.left, r.top), androidx.compose.ui.geometry.Size(r.width(), r.height()), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 8f))))
                }
            }
        }
    }
}

// =====================================================================
// الخط الزمني
// =====================================================================
@Composable
private fun Timeline(proj: VProject, t: Long, pps: Float, sel: Sel?, playing: Boolean, onSeek: (Long) -> Unit, onSelect: (Sel?) -> Unit) {
    val density = LocalDensity.current
    val total = proj.totalMs.coerceAtLeast(1000)
    val hs = rememberScrollState()
    val widthPx = total / 1000f * pps + with(density) { 140.dp.toPx() }
    // متابعة مؤشر التشغيل
    LaunchedEffect(t, playing) {
        if (playing) { val x = (t / 1000f * pps).toInt(); if (x < hs.value || x > hs.value + hs.viewportSize - 60) hs.scrollTo((x - 80).coerceAtLeast(0)) }
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxWidth().heightIn(max = 250.dp).verticalScroll(rememberScrollState())) {
            Column(Modifier.horizontalScroll(hs).width(with(density) { widthPx.toDp() })
                .drawWithContent {
                    drawContent()
                    val x = t / 1000f * pps
                    drawLine(Color(0xFFFF1744), Offset(x, 0f), Offset(x, size.height), 2.dp.toPx())
                    drawCircle(Color(0xFFFF1744), 5.dp.toPx(), Offset(x, 4.dp.toPx()))
                }) {
                Ruler(total, pps, onSeek)
                // مسار الصور والفيديو
                TRow(tr("🖼️ الصور", "🖼️ Media")) {
                    proj.clips.forEachIndexed { i, c ->
                        val trE = VEditor.transitions.firstOrNull { it.key == c.transition && it.key != "NONE" }?.emoji ?: ""
                        TBlock(proj.startOf(i), c.durMs, pps, if (c.isCard) Color(0xFF00695C) else Color(0xFF3949AB),
                            (if (c.isCard) (if (c.kind == "intro") tr("🎬 بداية ", "🎬 Intro ") else tr("🏁 نهاية ", "🏁 Outro ")) else if (c.video) "🎥 " else "") + secs(c.durMs) + tr("ث", "s") + if (i < proj.clips.lastIndex && trE.isNotBlank()) "  ⟶$trE" else "", sel?.id == c.id,
                            thumb = c.takeIf { !it.isCard }, onTap = { onSelect(Sel("clip", c.id)) }, onMove = null,
                            onResize = { dMs -> VEditor.update { p -> p.copy(clips = p.clips.map { if (it.id == c.id) it.copy(durMs = (it.durMs + dMs).coerceIn(500, if (it.video) (it.srcDurMs - it.trimStartMs).coerceAtLeast(500) else 60_000)) else it }) } })
                    }
                }
                proj.audios.forEachIndexed { k, a ->
                    TRow("🎵 ${k + 1}") {
                        if (a.loop) {
                            var s0 = a.startMs + a.lenMs
                            while (s0 < total && a.lenMs > 200) { TBlock(s0, minOf(a.lenMs, total - s0), pps, Color(0x5543A047), "↻", false, onTap = { onSelect(Sel("audio", a.id)) }); s0 += a.lenMs }
                        }
                        TBlock(a.startMs, a.lenMs, pps, Color(0xFF2E7D32), a.name + " • " + secs(a.lenMs) + tr("ث", "s"), sel?.id == a.id,
                            onTap = { onSelect(Sel("audio", a.id)) },
                            onMove = { dMs -> VEditor.update { p -> p.copy(audios = p.audios.map { if (it.id == a.id) it.copy(startMs = (it.startMs + dMs).coerceAtLeast(0)) else it }) } },
                            onResize = { dMs -> VEditor.update { p -> p.copy(audios = p.audios.map { if (it.id == a.id) it.copy(trimEndMs = (it.trimEndMs + dMs).coerceIn(it.trimStartMs + 300, it.srcDurMs)) else it }) } })
                    }
                }
                proj.overlays.forEach { o ->
                    val (emoji, col) = when (o.kind) { "TEXT" -> "🔤" to Color(0xFFEF6C00); "LOGO" -> "🏷️" to Color(0xFF6D4C41); "STICKER" -> o.key to Color(0xFFAD1457); "FX" -> "✨" to Color(0xFF6A1B9A); else -> "🖼" to Color(0xFF00838F) }
                    val label = when (o.kind) { "TEXT" -> o.text.replace("\n", " "); "FX" -> VEditor.fxKinds.firstOrNull { it.key == o.key }?.label ?: o.key; "FRAME" -> VEditor.frames.firstOrNull { it.key == o.key }?.label ?: o.key; "LOGO" -> tr("الشعار", "Logo"); else -> "" }
                    TRow(emoji) {
                        TBlock(o.startMs, o.durMs, pps, col, label + " • " + secs(o.durMs) + tr("ث", "s"), sel?.id == o.id,
                            onTap = { onSelect(Sel("ov", o.id)) },
                            onMove = { dMs -> VEditor.update { p -> p.copy(overlays = p.overlays.map { if (it.id == o.id) it.copy(startMs = (it.startMs + dMs).coerceIn(0, (p.totalMs - 300).coerceAtLeast(0))) else it }) } },
                            onResize = { dMs -> VEditor.update { p -> p.copy(overlays = p.overlays.map { if (it.id == o.id) it.copy(durMs = (it.durMs + dMs).coerceAtLeast(300)) else it }) } })
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

@Composable
private fun Ruler(total: Long, pps: Float, onSeek: (Long) -> Unit) {
    val tp = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9E9E9E.toInt() } }
    val density = LocalDensity.current
    Canvas(Modifier.fillMaxWidth().height(26.dp).background(MaterialTheme.colorScheme.surfaceVariant)
        .pointerInput(pps) { detectTapGestures { onSeek((it.x / pps * 1000).toLong()) } }
        .pointerInput(pps) { detectHorizontalDragGestures { ch, _ -> ch.consume(); onSeek((ch.position.x / pps * 1000).toLong()) } }) {
        tp.textSize = with(density) { 10.sp.toPx() }
        val labelEvery = when { pps < 14 -> 10; pps < 30 -> 5; pps < 70 -> 2; else -> 1 }
        val secsN = (total / 1000).toInt() + 3
        for (sIdx in 0..secsN) {
            val x = sIdx * pps
            val major = sIdx % labelEvery == 0
            drawLine(Color(0xFF9E9E9E), Offset(x, size.height), Offset(x, size.height * (if (major) 0.45f else 0.72f)), 1.dp.toPx())
            if (major) drawContext.canvas.nativeCanvas.drawText(String.format(java.util.Locale.US, "%d:%02d", sIdx / 60, sIdx % 60), x + 3, size.height * 0.42f, tp)
            if (pps > 90) for (k in 1..4) { val xx = x + k * pps / 5; drawLine(Color(0x669E9E9E), Offset(xx, size.height), Offset(xx, size.height * 0.84f), 1f) }
        }
    }
}

@Composable
private fun TRow(label: String, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxWidth().height(42.dp).padding(vertical = 3.dp)) {
        Text(label, Modifier.align(Alignment.CenterStart).padding(start = 2.dp), fontSize = 9.sp, color = MaterialTheme.colorScheme.outline)
        content()
    }
}

@Composable
private fun TBlock(startMs: Long, durMs: Long, pps: Float, color: Color, label: String, selected: Boolean, thumb: VClip? = null,
                   onTap: () -> Unit, onMove: ((Long) -> Unit)? = null, onResize: ((Long) -> Unit)? = null) {
    val density = LocalDensity.current
    val x = startMs / 1000f * pps; val wpx = (durMs / 1000f * pps).coerceAtLeast(6f)
    val shape = RoundedCornerShape(6.dp)
    val ctx = LocalContext.current
    Box(Modifier.offset { IntOffset(x.toInt(), 0) }.width(with(density) { wpx.toDp() }).fillMaxHeight()
        .clip(shape).background(color.copy(alpha = if (selected) 1f else 0.78f))
        .then(if (selected) Modifier.border(2.dp, Color.White, shape) else Modifier)
        .pointerInput(selected) {
            detectTapGestures(onTap = { onTap() })
        }
        .pointerInput(selected, onMove != null) {
            if (selected && onMove != null) detectHorizontalDragGestures { ch, dx -> ch.consume(); onMove((dx / pps * 1000).toLong()) }
        }) {
        if (thumb != null) {
            val bmp by produceState<Bitmap?>(null, thumb.uri) { value = withContext(Dispatchers.IO) { if (thumb.video) VPainter.videoFrame(ctx, thumb.uri, 500, 160) else VPainter.decode(ctx, thumb.uri, 160) } }
            Row(Modifier.fillMaxSize()) {
                val n = (wpx / with(density) { 40.dp.toPx() }).toInt().coerceIn(1, 12)
                repeat(n) { bmp?.let { Image(it.asImageBitmap(), null, Modifier.weight(1f).fillMaxHeight(), contentScale = ContentScale.Crop, alpha = 0.75f) } ?: Spacer(Modifier.weight(1f)) }
            }
        }
        Text(label, Modifier.align(Alignment.CenterStart).padding(horizontal = 4.dp), color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
        if (selected && onResize != null) Box(Modifier.align(Alignment.CenterEnd).width(16.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.85f))
            .pointerInput(Unit) { detectHorizontalDragGestures { ch, dx -> ch.consume(); onResize((dx / pps * 1000).toLong()) } }, contentAlignment = Alignment.Center) {
            Text("⋮", color = Color.Black, fontSize = 12.sp)
        }
    }
}

// =====================================================================
// لوحات التعديل
// =====================================================================
@Composable
private fun PanelHeader(title: String, onClose: () -> Unit, extra: @Composable RowScope.() -> Unit = {}) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        extra()
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, null) }
    }
}

@Composable
private fun OptChips(opts: List<VOpt>, selected: String, onPick: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(selected == o.key, { onPick(o.key) }, label = { Text(o.emoji + " " + o.label) }) } }
}

@Composable
private fun ClipPanel(proj: VProject, id: String, onClose: () -> Unit) {
    val i = proj.clips.indexOfFirst { it.id == id }; val c = proj.clips[i]
    fun upd(f: (VClip) -> VClip) = VEditor.update { p -> p.copy(clips = p.clips.map { if (it.id == id) f(it) else it }) }
    PanelHeader(if (c.isCard) (if (c.kind == "intro") tr("🎬 بداية الفيديو", "🎬 Intro") else tr("🏁 نهاية الفيديو", "🏁 Outro")) else (if (c.video) tr("🎥 فيديو ", "🎥 Video ") else tr("🖼️ صورة ", "🖼️ Photo ")) + "${i + 1}", onClose) {
        IconButton(onClick = { if (i > 0) VEditor.update { p -> p.copy(clips = p.clips.toMutableList().apply { add(i - 1, removeAt(i)) }) } }, enabled = i > 0) { Icon(Icons.Filled.ChevronLeft, null) }
        IconButton(onClick = { if (i < proj.clips.lastIndex) VEditor.update { p -> p.copy(clips = p.clips.toMutableList().apply { add(i + 1, removeAt(i)) }) } }, enabled = i < proj.clips.lastIndex) { Icon(Icons.Filled.ChevronRight, null) }
        IconButton(onClick = { VEditor.update { p -> p.copy(clips = p.clips.toMutableList().apply { add(i + 1, c.copy(id = uid())) }) } }) { Icon(Icons.Filled.ContentCopy, null) }
        IconButton(onClick = { VEditor.update { p -> p.copy(clips = p.clips.filter { it.id != id }) }; onClose() }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
    }
    if (c.isCard) {
        OutlinedTextField(c.title, { v -> upd { it.copy(title = v) } }, label = { Text(tr("العنوان", "Title")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(c.sub, { v -> upd { it.copy(sub = v) } }, label = { Text(tr("نص صغير أسفل العنوان", "Subtitle")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text(tr("لون العنوان", "Title color"), style = MaterialTheme.typography.labelLarge)
        ColorRow(c.color) { col -> upd { it.copy(color = col) } }
        Text(tr("المدة: ", "Duration: ") + secs(c.durMs) + tr(" ثانية", " s"), style = MaterialTheme.typography.labelLarge)
        Slider(c.durMs / 1000f, { v -> upd { it.copy(durMs = (v * 2).toInt() * 500L) } }, valueRange = 2f..10f)
        Text(if (c.kind == "intro") tr("قالب البداية", "Intro style") else tr("قالب النهاية", "Outro style"), style = MaterialTheme.typography.labelLarge)
        OptChips(if (c.kind == "intro") VEditor.intros else VEditor.outros, c.style) { k -> upd { it.copy(style = k) } }
    } else if (!c.video) {
        Text(tr("المدة: ", "Duration: ") + secs(c.durMs) + tr(" ثانية", " s"), style = MaterialTheme.typography.labelLarge)
        Slider(c.durMs / 1000f, { v -> upd { it.copy(durMs = (v * 2).toInt() * 500L) } }, valueRange = 1f..20f)
        Text(tr("طريقة ظهور الصورة (قوالب حركة)", "How the photo appears"), style = MaterialTheme.typography.labelLarge)
        OptChips(VEditor.styles, c.style) { k -> upd { it.copy(style = k) } }
        if (c.style == "NORMAL") { Text(tr("حركة الكاميرا", "Camera motion"), style = MaterialTheme.typography.labelLarge); OptChips(VEditor.motions, c.motion) { k -> upd { it.copy(motion = k) } } }
        if (c.style in setOf("CARD", "BOUNCE", "BALLOONS", "BIRDS", "ANIMAL", "PLANE", "GIFT"))
            OutlinedTextField(c.caption, { v -> upd { it.copy(caption = v) } }, label = { Text(tr("كتابة أسفل الصورة (اختياري)", "Caption under photo (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        TextButton(onClick = { VEditor.update { p -> p.copy(clips = p.clips.map { if (it.video) it else it.copy(style = c.style, motion = c.motion, durMs = c.durMs) }) } }) { Text(tr("تطبيق هذه الطريقة والمدة على كل الصور", "Apply style & duration to all photos")) }
    } else {
        val src = c.srcDurMs.coerceAtLeast(c.trimStartMs + c.durMs).coerceAtLeast(1)
        Text(tr("قص الفيديو: من ", "Trim: from ") + secs(c.trimStartMs) + tr(" إلى ", " to ") + secs(c.trimStartMs + c.durMs) + tr(" ث", " s"), style = MaterialTheme.typography.labelLarge)
        RangeSlider(c.trimStartMs.toFloat() / src..(c.trimStartMs + c.durMs).toFloat() / src, { r ->
            upd { it.copy(trimStartMs = (r.start * src).toLong(), durMs = ((r.endInclusive - r.start) * src).toLong().coerceAtLeast(500)) }
        })
        SwitchRow(tr("كتم صوت الفيديو الأصلي", "Mute original sound"), null, c.muted) { m -> upd { it.copy(muted = m) } }
    }
    Text(tr("الانتقال إلى العنصر التالي", "Transition to next"), style = MaterialTheme.typography.labelLarge)
    OptChips(VEditor.transitions, c.transition) { k -> upd { it.copy(transition = k) } }
    TextButton(onClick = { VEditor.update { p -> p.copy(clips = p.clips.map { it.copy(transition = c.transition) }) } }) { Text(tr("تطبيق الانتقال على الكل", "Apply transition to all")) }
}

@Composable
private fun AudioPanel(proj: VProject, id: String, onClose: () -> Unit) {
    val a = proj.audios.first { it.id == id }
    fun upd(f: (VAudio) -> VAudio) = VEditor.update { p -> p.copy(audios = p.audios.map { if (it.id == id) f(it) else it }) }
    val total = proj.totalMs.coerceAtLeast(1000)
    PanelHeader("🎵 " + a.name, onClose) {
        IconButton(onClick = { VEditor.update { p -> p.copy(audios = p.audios.filter { it.id != id }) }; onClose() }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
    }
    Text(tr("يبدأ في الفيديو عند: ", "Starts in video at: ") + secs(a.startMs) + tr(" ث", " s"), style = MaterialTheme.typography.labelLarge)
    Slider(a.startMs.toFloat(), { v -> upd { it.copy(startMs = v.toLong()) } }, valueRange = 0f..total.toFloat())
    Text(tr("✂️ الجزء المستخدم من الصوت: من ", "✂️ Used part: from ") + secs(a.trimStartMs) + tr(" إلى ", " to ") + secs(a.trimEndMs) + tr(" ث (المدة ", " s (length ") + secs(a.lenMs) + ")", style = MaterialTheme.typography.labelLarge)
    val src = a.srcDurMs.coerceAtLeast(1)
    RangeSlider(a.trimStartMs.toFloat() / src..a.trimEndMs.toFloat() / src, { r -> upd { it.copy(trimStartMs = (r.start * src).toLong(), trimEndMs = (r.endInclusive * src).toLong().coerceAtLeast((r.start * src).toLong() + 300)) } })
    Text(tr("يظهر في الفيديو الجزء المحدد فقط", "Only the selected part plays in the video"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(tr("مستوى الصوت ", "Volume ") + "${(a.volume * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
    Slider(a.volume, { v -> upd { it.copy(volume = v) } }, valueRange = 0f..2f)
    SwitchRow(tr("تكرار حتى نهاية الفيديو", "Loop to the end"), null, a.loop) { l -> upd { it.copy(loop = l) } }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { upd { it.copy(startMs = 0) } }) { Text(tr("من البداية", "From start")) }
        OutlinedButton(onClick = { upd { it.copy(trimStartMs = 0, trimEndMs = it.srcDurMs) } }) { Text(tr("الصوت كاملاً", "Full audio")) }
    }
}

@Composable
private fun OverlayPanel(proj: VProject, id: String, onLogo: () -> Unit, onClose: () -> Unit) {
    val o = proj.overlays.first { it.id == id }
    fun upd(f: (VOverlay) -> VOverlay) = VEditor.update { p -> p.copy(overlays = p.overlays.map { if (it.id == id) f(it) else it }) }
    val total = proj.totalMs.coerceAtLeast(1000)
    val title = when (o.kind) { "TEXT" -> tr("🔤 نص", "🔤 Text"); "LOGO" -> tr("🏷️ الشعار", "🏷️ Logo"); "STICKER" -> tr("😀 ملصق", "😀 Sticker"); "FX" -> tr("✨ مؤثر", "✨ Effect"); else -> tr("🖼 إطار", "🖼 Frame") }
    PanelHeader(title, onClose) {
        IconButton(onClick = { VEditor.update { p -> p.copy(overlays = p.overlays.toMutableList().apply { add(o.copy(id = uid(), startMs = (o.startMs + o.durMs).coerceAtMost(total - 300))) }) } }) { Icon(Icons.Filled.ContentCopy, null) }
        IconButton(onClick = { VEditor.update { p -> p.copy(overlays = p.overlays.filter { it.id != id }) }; onClose() }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
    }
    when (o.kind) {
        "TEXT" -> {
            OutlinedTextField(o.text, { v -> upd { it.copy(text = v) } }, label = { Text(tr("النص", "Text")) }, modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = 4)
            Text(tr("حجم الخط ", "Font size ") + "${(o.size * 1000).toInt()}", style = MaterialTheme.typography.labelLarge)
            Slider(o.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.03f..0.25f)
            Text(tr("لون الخط", "Text color"), style = MaterialTheme.typography.labelLarge)
            ColorRow(o.color) { col -> upd { it.copy(color = col) } }
            Text(tr("حركة النص", "Text animation"), style = MaterialTheme.typography.labelLarge)
            OptChips(VEditor.textAnims, o.anim) { k -> upd { it.copy(anim = k) } }
            SwitchRow(tr("خلفية خلف النص", "Background box"), null, o.bg) { b -> upd { it.copy(bg = b) } }
            Text(tr("💡 اسحب النص بإصبعك في نافذة المعاينة لأي مكان، وباعد إصبعين أو قرّبهما للتكبير والتصغير، وأدِرهما لتدوير النص.", "💡 Drag the text anywhere in the preview; pinch to resize and twist two fingers to rotate."), style = MaterialTheme.typography.labelSmall)
        }
        "LOGO" -> {
            OutlinedButton(onClick = onLogo) { Icon(Icons.Filled.Image, null); Spacer(Modifier.width(6.dp)); Text(tr("تغيير صورة الشعار", "Change logo image")) }
            Text(tr("الحجم", "Size"), style = MaterialTheme.typography.labelLarge); Slider(o.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.03f..0.3f)
            Text(tr("الشفافية ", "Opacity ") + "${(o.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelLarge); Slider(o.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.15f..1f)
            Text(tr("المكان", "Position"), style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(Triple("↖️", 0.12f, 0.12f), Triple("↗️", 0.88f, 0.12f), Triple("↙️", 0.12f, 0.88f), Triple("↘️", 0.88f, 0.88f), Triple("⏺️", 0.5f, 0.5f)).forEach { (e, x, y) ->
                    AssistChip({ upd { it.copy(x = x, y = y) } }, label = { Text(e) })
                }
            }
        }
        "STICKER" -> {
            Text(tr("الملصق", "Sticker"), style = MaterialTheme.typography.labelLarge)
            VEditor.stickerSets.forEach { (name, list) ->
                Text(name, style = MaterialTheme.typography.labelSmall)
                FlowRow { list.split(" ").forEach { e -> Text(e, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).background(if (e == o.key) MaterialTheme.colorScheme.primaryContainer else Color.Transparent).clickable { upd { it.copy(key = e) } }.padding(4.dp)) } }
            }
            Text(tr("الحجم", "Size"), style = MaterialTheme.typography.labelLarge); Slider(o.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.04f..0.35f)
            Text(tr("الحركة", "Animation"), style = MaterialTheme.typography.labelLarge); OptChips(VEditor.stickerAnims, o.anim) { k -> upd { it.copy(anim = k) } }
        }
        "FX" -> {
            Text(tr("🔍 حجم المؤثر ", "🔍 Effect size ") + "${(o.size / 0.09f * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(o.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.03f..0.3f)
            Text(tr("الشفافية ", "Opacity ") + "${(o.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(o.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.15f..1f)
            if (o.key.startsWith("C_")) {
                Text(tr("مسار الحركة: ارفعه أو أنزله", "Path: move up or down"), style = MaterialTheme.typography.labelLarge)
                Slider(o.y, { v -> upd { it.copy(y = v) } }, valueRange = 0f..1f)
            }
            OptChips(VEditor.fxKinds, o.key) { k -> upd { it.copy(key = k) } }
        }
        "FRAME" -> { OptChips(VEditor.frames, o.key) { k -> upd { it.copy(key = k) } } }
    }
    if (o.kind in setOf("TEXT", "LOGO", "STICKER")) {
        HorizontalDivider()
        Text(tr("📐 الاتجاه والدوران: ", "📐 Direction & rotation: ") + "${o.rot.toInt()}°", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0f to tr("↔️ أفقي", "↔️ Horizontal"), -90f to tr("↕️ رأسي (لأعلى)", "↕️ Vertical (up)"), 90f to tr("↕️ رأسي (لأسفل)", "↕️ Vertical (down)"),
                -45f to tr("↗️ مائل (نصف أفقي)", "↗️ Diagonal up"), 45f to tr("↘️ مائل لأسفل", "↘️ Diagonal down"), 180f to tr("🔄 مقلوب", "🔄 Upside down")).forEach { (d, l) ->
                FilterChip(abs(o.rot - d) < 0.5f, { upd { it.copy(rot = d) } }, label = { Text(l) })
            }
        }
        Slider(o.rot, { v -> upd { it.copy(rot = v) } }, valueRange = -180f..180f)
        if (o.kind == "TEXT") SwitchRow(tr("حروف عمودية (كل حرف تحت الآخر)", "Stacked vertical letters"), null, o.vert) { v -> upd { it.copy(vert = v) } }
        Text(tr("📍 المكان (أفقي ", "📍 Position (x ") + "${(o.x * 100).toInt()}% • " + tr("رأسي ", "y ") + "${(o.y * 100).toInt()}%)", style = MaterialTheme.typography.labelLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("↔", Modifier.width(22.dp)); Slider(o.x, { v -> upd { it.copy(x = v) } }, valueRange = 0f..1f, modifier = Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("↕", Modifier.width(22.dp)); Slider(o.y, { v -> upd { it.copy(y = v) } }, valueRange = 0f..1f, modifier = Modifier.weight(1f))
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { upd { it.copy(x = it.x - 0.01f) } }) { Icon(Icons.Filled.KeyboardArrowLeft, null) }
                IconButton(onClick = { upd { it.copy(y = it.y - 0.01f) } }) { Icon(Icons.Filled.KeyboardArrowUp, null) }
                IconButton(onClick = { upd { it.copy(y = it.y + 0.01f) } }) { Icon(Icons.Filled.KeyboardArrowDown, null) }
                IconButton(onClick = { upd { it.copy(x = it.x + 0.01f) } }) { Icon(Icons.Filled.KeyboardArrowRight, null) }
                AssistChip({ upd { it.copy(x = 0.5f) } }, label = { Text(tr("توسيط أفقي", "Center H")) })
                AssistChip({ upd { it.copy(y = 0.5f) } }, label = { Text(tr("توسيط رأسي", "Center V")) })
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(tr("أعلى", "Top") to 0.12f, tr("منتصف", "Middle") to 0.5f, tr("أسفل", "Bottom") to 0.86f).forEach { (l, y) -> AssistChip({ upd { it.copy(y = y) } }, label = { Text(l) }) }
            listOf(tr("يمين", "Right") to 0.85f, tr("يسار", "Left") to 0.15f).forEach { (l, x) -> AssistChip({ upd { it.copy(x = x) } }, label = { Text(l) }) }
        }
    }
    HorizontalDivider()
    Text(tr("⏱️ يبدأ عند ", "⏱️ Starts at ") + secs(o.startMs) + tr(" ث • يستمر ", " s • lasts ") + secs(o.durMs) + tr(" ث", " s"), style = MaterialTheme.typography.labelLarge)
    Slider(o.startMs.toFloat(), { v -> upd { it.copy(startMs = v.toLong()) } }, valueRange = 0f..total.toFloat())
    Slider(o.durMs.toFloat(), { v -> upd { it.copy(durMs = v.toLong()) } }, valueRange = 300f..total.toFloat().coerceAtLeast(301f))
    OutlinedButton(onClick = { upd { it.copy(startMs = 0, durMs = total) } }) { Text(tr("طوال الفيديو", "Whole video")) }
}

@Composable
private fun ColorRow(sel: Int, onPick: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        VEditor.colors.forEach { col ->
            Box(Modifier.size(32.dp).clip(CircleShape).background(Color(col)).border(if (col == sel) 3.dp else 1.dp, if (col == sel) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape).clickable { onPick(col) })
        }
    }
}

// =====================================================================
// النوافذ
// =====================================================================
@Composable
private fun OptDialog(title: String, opts: List<VOpt>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } },
        title = { Text(title) },
        text = {
            FlowRow(Modifier.verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                opts.forEach { o ->
                    Card(onClick = { onPick(o.key) }, modifier = Modifier.width(96.dp)) {
                        Column(Modifier.padding(8.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) { Text(o.emoji, fontSize = 28.sp); Text(o.label, style = MaterialTheme.typography.labelSmall, maxLines = 2) }
                    }
                }
            }
        })
}

@Composable
private fun CardsDialog(onDismiss: () -> Unit, onPick: (String, String) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } },
        title = { Text(tr("🎬 بدايات ونهايات احترافية", "🎬 Pro intros & outros")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((kind, list) in listOf("intro" to VEditor.intros, "outro" to VEditor.outros)) {
                    Text(if (kind == "intro") tr("بداية الفيديو", "Intro") else tr("نهاية الفيديو", "Outro"), fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        list.forEach { o ->
                            Card(onClick = { onPick(kind, o.key) }, modifier = Modifier.width(100.dp)) {
                                Column(Modifier.padding(8.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) { Text(o.emoji, fontSize = 28.sp); Text(o.label, style = MaterialTheme.typography.labelSmall, maxLines = 2) }
                            }
                        }
                    }
                }
                Text(tr("بعد الإضافة اكتب العنوان واختر لونه من لوحة التعديل.", "After adding, edit the title and color in the panel."), style = MaterialTheme.typography.labelSmall)
            }
        })
}

@Composable
private fun StickerDialog(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } },
        title = { Text(tr("😀 ملصقات المناسبات", "😀 Occasion stickers")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                VEditor.stickerSets.forEach { (name, list) ->
                    Text(name, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                    FlowRow { list.split(" ").forEach { e -> Text(e, fontSize = 30.sp, modifier = Modifier.clip(CircleShape).clickable { onPick(e) }.padding(5.dp)) } }
                }
            }
        })
}

@Composable
private fun TemplatesDialog(proj: VProject, onDismiss: () -> Unit, onPick: () -> Unit, onApplied: () -> Unit) {
    var secsEach by remember { mutableIntStateOf(4) }
    val photos = proj.clips.count { !it.video }
    AlertDialog(onDismissRequest = onDismiss, confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } },
        title = { Text(tr("🎨 قوالب جاهزة للمناسبات", "🎨 Occasion templates")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (proj.clips.isEmpty()) {
                    Text(tr("أضف صورك أولاً ثم اختر القالب: سيُرتّب طريقة ظهور كل صورة (بالونات، حيوانات تحمل الصورة، بطاقات، قلوب…) والانتقالات والعنوان والمؤثرات والإطار تلقائياً.",
                        "Add your photos first, then pick a template: it arranges photo animations (balloons, animals carrying photos, cards, hearts…), transitions, title, effects and frame automatically."), color = MaterialTheme.colorScheme.primary)
                    Button(onClick = onPick) { Icon(Icons.Filled.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة صور", "Add photos")) }
                } else Text(tr("عدد الصور: $photos • مدة كل صورة: $secsEach ث", "Photos: $photos • each: $secsEach s"), style = MaterialTheme.typography.labelLarge)
                Slider(secsEach.toFloat(), { secsEach = it.toInt() }, valueRange = 2f..10f, steps = 7)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    VEditor.templates.forEach { tpl ->
                        Card(onClick = { if (proj.clips.isNotEmpty()) { VEditor.applyTemplate(tpl, secsEach); onApplied() } else onPick() }, modifier = Modifier.width(112.dp),
                            colors = CardDefaults.cardColors(containerColor = if (proj.template == tpl.key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.padding(10.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(tpl.emoji, fontSize = 34.sp)
                                Text(tpl.label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                Text(tpl.styles.take(3).joinToString(" ") { k -> VEditor.styles.firstOrNull { it.key == k }?.emoji ?: "" } + " " + tpl.fx.joinToString(" ") { k -> VEditor.fxKinds.firstOrNull { it.key == k }?.emoji ?: "" }, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        })
}

@Composable
private fun SettingsDialog(proj: VProject, onDismiss: () -> Unit) {
    var confirmNew by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = onDismiss) { Text(tr("تم", "Done")) } },
        title = { Text(tr("⚙️ المقاس والجودة", "⚙️ Format & quality")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("مقاس الفيديو", "Aspect ratio"), fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("16:9" to tr("🖥️ يوتيوب 16:9", "🖥️ 16:9"), "9:16" to tr("📱 ريلز/ستوري 9:16", "📱 Reels 9:16"), "1:1" to tr("⬛ مربع 1:1", "⬛ Square"), "4:5" to tr("📷 إنستجرام 4:5", "📷 4:5")).forEach { (k, l) ->
                        FilterChip(proj.aspect == k, { VEditor.update { it.copy(aspect = k) }; VPainter.clearCache() }, label = { Text(l) })
                    }
                }
                Text(tr("جودة التصدير", "Export quality"), fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(480 to tr("480p (حجم صغير)", "480p (small)"), 720 to "720p HD", 1080 to tr("1080p Full HD", "1080p Full HD")).forEach { (q, l) ->
                        FilterChip(proj.quality == q, { VEditor.update { it.copy(quality = q) } }, label = { Text(l) })
                    }
                }
                val (w, h) = proj.outSize()
                Text(tr("الأبعاد: ", "Size: ") + "$w×$h", style = MaterialTheme.typography.labelSmall)
                Text(tr("فلتر الألوان", "Color filter"), fontWeight = FontWeight.Bold)
                OptChips(VEditor.filters, proj.filter) { k -> VEditor.update { it.copy(filter = k) } }
                Text(tr("مدة الانتقال بين الصور: ", "Transition length: ") + secs(proj.transitionMs) + tr(" ث", " s"), fontWeight = FontWeight.Bold)
                Slider(proj.transitionMs.toFloat(), { v -> VEditor.update { it.copy(transitionMs = v.toLong()) } }, valueRange = 300f..1600f)
                HorizontalDivider()
                OutlinedButton(onClick = { confirmNew = true }) { Icon(Icons.Filled.NoteAdd, null); Spacer(Modifier.width(6.dp)); Text(tr("مشروع جديد (مسح الحالي)", "New project (clear)")) }
            }
        })
    if (confirmNew) AlertDialog(onDismissRequest = { confirmNew = false },
        confirmButton = { TextButton(onClick = { VEditor.reset(); confirmNew = false; onDismiss() }) { Text(tr("مسح", "Clear"), color = DangerRed) } },
        dismissButton = { TextButton(onClick = { confirmNew = false }) { Text(tr("إلغاء", "Cancel")) } },
        title = { Text(tr("بدء مشروع جديد؟", "Start a new project?")) }, text = { Text(tr("سيُحذف كل ما في المحرر الآن (لن تُحذف ملفاتك الأصلية).", "Everything in the editor will be cleared (your files stay).")) })
}

@Composable
private fun MicDialog(onDismiss: () -> Unit, onDone: (String) -> Unit) {
    val ctx = LocalContext.current
    var rec by remember { mutableStateOf<MediaRecorder?>(null) }
    var file by remember { mutableStateOf<File?>(null) }
    var secs by remember { mutableIntStateOf(0) }
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(rec) { while (rec != null) { delay(1000); secs++ } }
    fun stop(save: Boolean) {
        val r = rec ?: return
        runCatching { r.stop() }; r.release(); rec = null
        if (save) file?.takeIf { it.length() > 0 }?.let { onDone(it.absolutePath) } ?: onDismiss() else onDismiss()
    }
    DisposableEffect(Unit) { onDispose { rec?.let { runCatching { it.stop() }; it.release() } } }
    AlertDialog(onDismissRequest = {}, title = { Text(tr("🎙️ تسجيل صوت بالمايك", "🎙️ Record voice")) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                if (!granted) { Text(tr("يلزم إذن الميكروفون", "Microphone permission needed")); Button(onClick = { perm.launch(Manifest.permission.RECORD_AUDIO) }) { Text(tr("السماح", "Allow")) } }
                else {
                    Text(String.format(java.util.Locale.US, "%02d:%02d", secs / 60, secs % 60), fontSize = 36.sp, fontWeight = FontWeight.Bold, color = if (rec != null) DangerRed else MaterialTheme.colorScheme.onSurface)
                    Text(if (rec != null) tr("🔴 جارٍ التسجيل… سيُضاف عند مؤشر الزمن الحالي", "🔴 Recording… will be placed at the playhead") else tr("اضغط للبدء", "Tap to start"), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    FilledIconButton(onClick = {
                        if (rec == null) {
                            val f = File(vdir(ctx), "mic_" + System.currentTimeMillis() + ".m4a"); file = f; secs = 0
                            runCatching {
                                @Suppress("DEPRECATION") val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
                                r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                                r.setAudioEncodingBitRate(128_000); r.setAudioSamplingRate(44100); r.setOutputFile(f.absolutePath); r.prepare(); r.start(); rec = r
                            }.onFailure { toast(ctx, tr("تعذر بدء التسجيل", "Couldn't start recording")) }
                        } else stop(true)
                    }, modifier = Modifier.size(72.dp)) { Icon(if (rec == null) Icons.Filled.Mic else Icons.Filled.Stop, null, Modifier.size(36.dp)) }
                }
            }
        },
        confirmButton = { if (rec != null) TextButton(onClick = { stop(true) }) { Text(tr("إيقاف وإضافة", "Stop & add")) } },
        dismissButton = { TextButton(onClick = { if (rec != null) stop(false) else onDismiss() }) { Text(tr("إلغاء", "Cancel")) } })
}

@Composable
private fun ExportDialog(proj: VProject, nav: NavController, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var job by remember { mutableStateOf<MediaTools.Job?>(null) }
    var result by remember { mutableStateOf<Pair<Uri?, String?>?>(null) }
    var prog by remember { mutableIntStateOf(0) }
    LaunchedEffect(job, result) { while (job != null && result == null) { prog = MediaTools.progress(job!!).coerceAtLeast(0); delay(400) } }
    val (w, h) = proj.outSize()
    AlertDialog(onDismissRequest = { if (job == null || result != null) onDismiss() },
        title = { Text(tr("⬆️ تصدير الفيديو", "⬆️ Export video")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (job == null && result == null) {
                    Text(tr("المقاس: ", "Size: ") + "${proj.aspect} • $w×$h • ${proj.quality}p")
                    Text(tr("المدة: ", "Length: ") + fmtT(proj.totalMs))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(480, 720, 1080).forEach { q -> FilterChip(proj.quality == q, { VEditor.update { it.copy(quality = q) } }, label = { Text("${q}p") }) }
                    }
                    Text(tr("يتم الإنشاء على هاتفك ويُحفظ في المعرض (Movies/Sho3eb). أبقِ الشاشة مفتوحة حتى ينتهي.", "Rendered on your phone and saved to Movies/Sho3eb. Keep the screen on until done."), style = MaterialTheme.typography.labelSmall)
                } else if (result == null) {
                    Text(tr("⏳ جارٍ إنشاء الفيديو… $prog%", "⏳ Creating video… $prog%"), fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = { prog / 100f }, modifier = Modifier.fillMaxWidth())
                } else result?.let { (uri, err) ->
                    if (uri != null) {
                        Text(tr("✅ تم إنشاء الفيديو وحفظه في المعرض", "✅ Video created and saved to gallery"), color = SuccessGreen, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { MediaTools.queue.clear(); onDismiss(); nav.openPlayer(uri.toString(), tr("الفيديو", "Video")) }) { Icon(Icons.Filled.PlayArrow, null); Text(tr("تشغيل", "Play")) }
                            OutlinedButton(onClick = { runCatching { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/*").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null)) } }) { Icon(Icons.Filled.Share, null); Text(tr("مشاركة", "Share")) }
                        }
                    } else Text(tr("❌ تعذر إنشاء الفيديو: ", "❌ Export failed: ") + (err ?: "") + tr("\nجرّب جودة أقل (720p أو 480p).", "\nTry a lower quality (720p/480p)."), color = DangerRed)
                }
            }
        },
        confirmButton = {
            if (job == null && result == null) Button(onClick = {
                val r = runCatching { VExport.start(ctx.applicationContext, proj) { u, e -> result = u to e } }
                r.onSuccess { job = it }.onFailure { job = null; result = null to (it.javaClass.simpleName + ": " + (it.message ?: "")) }
            }) { Icon(Icons.Filled.Movie, null); Spacer(Modifier.width(6.dp)); Text(tr("إنشاء الفيديو", "Create video")) }
            else if (result != null) Row {
                if (result?.first == null) TextButton(onClick = { result = null; job = null }) { Text(tr("إعادة المحاولة", "Retry")) }
                TextButton(onClick = onDismiss) { Text(tr("حسناً", "OK")) }
            }
        },
        dismissButton = {
            if (job != null && result == null) TextButton(onClick = { runCatching { job?.transformer?.cancel() }; job = null }) { Text(tr("إلغاء", "Cancel"), color = DangerRed) }
            else if (job == null && result == null) TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) }
        })
}
