@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch

private data class MfgData(
    val products: List<Product>, val pmap: Map<Long, Product>, val stock: Map<Long, Double>,
    val bom: List<BomLine>, val prods: List<Production>, val lines: List<ProductionLine>
)

@Composable
private fun rememberMfg(): MfgData {
    val dao = remember { appDao() }
    val products by flowState(emptyList<Product>()) { dao.productsFlow() }
    val invs by flowState(emptyList<Invoice>()) { dao.invoicesFlow() }
    val items by flowState(emptyList<InvoiceItem>()) { dao.invoiceItemsFlow() }
    val adjs by flowState(emptyList<StockAdj>()) { dao.stockAdjsFlow() }
    val bom by flowState(emptyList<BomLine>()) { dao.bomFlow() }
    val prods by flowState(emptyList<Production>()) { dao.productionsFlow() }
    val lines by flowState(emptyList<ProductionLine>()) { dao.productionLinesFlow() }
    val stock = remember(products, invs, items, adjs) { Shop.stockMap(products, invs, items, adjs) }
    return MfgData(products, products.associateBy { it.id }, stock, bom, prods, lines)
}

@Composable
fun ManufactureScreen(nav: NavController) {
    ScreenScaffold(title = tr("التصنيع والإنتاج", "Manufacturing"), onBack = { nav.popBackStack() }) { p ->
        Box(Modifier.padding(p)) { ManufacturePane(nav) }
    }
}

/** التصنيع كتبويب داخل المحل */
@Composable
fun ManufacturePane(nav: NavController) {
    val ctx = LocalContext.current
    val d = rememberMfg()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var pickProduct by remember { mutableStateOf(false) }
    var produceFor by remember { mutableStateOf<Product?>(null) }
    var openOrder by remember { mutableStateOf<Production?>(null) }
    var newRaw by remember { mutableStateOf(false) }
    var editRaw by remember { mutableStateOf<Product?>(null) }
    var receive by remember { mutableStateOf<Product?>(null) }
    val made = d.bom.groupBy { it.productId }
    val raws = d.products.filter { Manufacture.isRaw(it) }
    var from by remember { mutableStateOf<Long?>(Fmt.today() - 30) }
    var to by remember { mutableStateOf<Long?>(Fmt.today()) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScrollableTabRow(tab, edgePadding = 8.dp) {
                Tab(tab == 0, { tab = 0 }, text = { Text(tr("🏭 المنتجات", "🏭 Products")) })
                Tab(tab == 1, { tab = 1 }, text = { Text(tr("🧱 الخامات (${raws.size})", "🧱 Materials (${raws.size})")) })
                Tab(tab == 2, { tab = 2 }, text = { Text(tr("📋 أوامر الإنتاج", "📋 Orders")) })
                Tab(tab == 3, { tab = 3 }, text = { Text(tr("📊 التقارير", "📊 Reports")) })
            }
            when (tab) {
                0 -> LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { InfoBanner(tr("حوّل الخامات أو منتجات المحل إلى منتج قابل للبيع: حدد مكونات كل منتج وكمياتها بأي وحدة (جرام، كيلو، كرتونة...) ثم سجّل أوامر الإنتاج ليتحدث المخزون والتكلفة تلقائياً. الخامات الخاصة بالتصنيع تضيفها من تبويب «الخامات» ولا تظهر في أصناف المحل.",
                        "Turn materials or shop items into sellable products: define components with any unit, then record production orders to update stock and cost automatically. Manufacturing-only materials are added in the «Materials» tab and don't appear in shop items.")) }
                    if (made.isEmpty()) item { EmptyState(Icons.Filled.PrecisionManufacturing, tr("لا توجد منتجات مُصنّعة بعد. اضغط «منتج مُصنَّع» لاختيار منتج من المحل وتحديد مكوناته.", "No manufactured products yet.")) }
                    items(made.keys.mapNotNull { d.pmap[it] }.sortedBy { it.name }, key = { it.id }) { pr ->
                        val bom = made[pr.id].orEmpty()
                        val uc = Manufacture.unitCost(bom, d.pmap)
                        val max = Manufacture.maxProducible(bom, d.stock, d.pmap)
                        Card(onClick = { nav.navigate("manufacture_bom/${pr.id}") }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    ProductThumb(pr.id, pr.name, 52.dp, emoji = "🏭"); Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(pr.name, fontWeight = FontWeight.Bold)
                                        Text(tr("${bom.size} مكونات • المخزون ", "${bom.size} components • stock ") + Manufacture.q(d.stock[pr.id] ?: 0.0) + " " + pr.unit, style = MaterialTheme.typography.bodySmall)
                                    }
                                    FilledTonalButton(onClick = { produceFor = pr }) { Text(tr("إنتاج", "Produce")) }
                                }
                                Row {
                                    Text(tr("تكلفة الوحدة: ", "Unit cost: ") + Fmt.money(uc), Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                                    if (pr.price > 0) Text(tr("الربح: ", "Margin: ") + Fmt.money(pr.price - uc), color = if (pr.price >= uc) SuccessGreen else DangerRed, style = MaterialTheme.typography.labelMedium)
                                }
                                Text(tr("يمكن إنتاج حتى ", "Can produce up to ") + Manufacture.q(max) + tr(" من المخزون الحالي", " from current stock"),
                                    style = MaterialTheme.typography.labelSmall, color = if (max > 0) MaterialTheme.colorScheme.primary else WarnAmber)
                            }
                        }
                    }
                }
                1 -> LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { InfoBanner(tr("خامات خاصة بالتصنيع فقط (غير مكوّدة في المحل). سجّل استلام كميات منها بتكلفتها ليتم حساب متوسط التكلفة تلقائياً.", "Manufacturing-only materials (not listed in the shop). Record received quantities with their cost; average cost is computed automatically.")) }
                    if (raws.isEmpty()) item { EmptyState(Icons.Filled.Category, tr("لا توجد خامات بعد. اضغط «خامة» لإضافة دقيق، سكر، قماش، عبوات...", "No materials yet. Tap «Material» to add flour, sugar, fabric, packaging...")) }
                    items(raws.sortedBy { it.name }, key = { it.id }) { r ->
                        val qty = d.stock[r.id] ?: 0.0
                        Card(onClick = { editRaw = r }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                ProductThumb(r.id, r.name, 52.dp, emoji = "🧱"); Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(r.name, fontWeight = FontWeight.Bold)
                                    Text(tr("الرصيد: ", "Stock: ") + Manufacture.q(qty) + " " + r.unit + " • " + tr("التكلفة ", "cost ") + Fmt.money(r.cost) + "/" + r.unit.ifBlank { tr("وحدة", "unit") },
                                        style = MaterialTheme.typography.bodySmall, color = if (r.minQty > 0 && qty <= r.minQty) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(tr("القيمة: ", "Value: ") + Fmt.money(qty.coerceAtLeast(0.0) * r.cost), style = MaterialTheme.typography.labelSmall)
                                }
                                FilledTonalButton(onClick = { receive = r }) { Text(tr("+ استلام", "+ Receive")) }
                            }
                        }
                    }
                    if (raws.isNotEmpty()) item {
                        Text(tr("إجمالي قيمة الخامات: ", "Total materials value: ") + Fmt.money(raws.sumOf { (d.stock[it.id] ?: 0.0).coerceAtLeast(0.0) * it.cost }), fontWeight = FontWeight.Bold)
                    }
                }
                2 -> LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (d.prods.isEmpty()) item { EmptyState(Icons.Filled.Inventory, tr("لا توجد أوامر إنتاج بعد", "No production orders yet")) }
                    items(d.prods, key = { it.id }) { pr ->
                        val prod = d.pmap[pr.productId]
                        Card(onClick = { openOrder = pr }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("#${pr.number} • " + (prod?.name ?: "?"), fontWeight = FontWeight.Bold)
                                    Text(Fmt.date(pr.date) + " • " + Manufacture.q(pr.qty) + " " + (prod?.unit ?: ""), style = MaterialTheme.typography.bodySmall)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(Fmt.money(pr.materialsCost + pr.extraCost), fontWeight = FontWeight.Bold)
                                    Text(tr("للوحدة ", "per unit ") + Fmt.money(if (pr.qty > 0) (pr.materialsCost + pr.extraCost) / pr.qty else 0.0), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
                else -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DateField(tr("من", "From"), from, { from = it }, allowClear = true, modifier = Modifier.weight(1f))
                        DateField(tr("إلى", "To"), to, { to = it }, allowClear = true, modifier = Modifier.weight(1f))
                    }
                    PdfShareButton(null, doc = { Manufacture.summaryDoc(d.prods, d.lines, d.pmap, from, to) }) { c -> Reports.doc(c, Manufacture.summaryDoc(d.prods, d.lines, d.pmap, from, to)) }
                    val f = d.prods.filter { (from == null || it.date >= from!!) && (to == null || it.date <= to!!) }
                    val cost = f.sumOf { it.materialsCost + it.extraCost }
                    val value = f.sumOf { it.qty * (d.pmap[it.productId]?.price ?: 0.0) }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard(tr("أوامر", "Orders"), "${f.size}", Icons.Filled.Inventory, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        StatCard(tr("التكلفة", "Cost"), Fmt.money(cost), Icons.Filled.Payments, WarnAmber, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard(tr("القيمة البيعية", "Sales value"), Fmt.money(value), Icons.Filled.Sell, SuccessGreen, Modifier.weight(1f))
                        StatCard(tr("الربح المتوقع", "Expected profit"), Fmt.money(value - cost), Icons.Filled.TrendingUp, if (value >= cost) SuccessGreen else DangerRed, Modifier.weight(1f))
                    }
                    SectionTitle(tr("حسب المنتج", "By product"))
                    f.groupBy { it.productId }.forEach { (pid, l) ->
                        val pr = d.pmap[pid]
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                ProductThumb(pr?.id, pr?.name ?: "?", 36.dp); Spacer(Modifier.width(8.dp))
                                Text(pr?.name ?: "?", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Text(Manufacture.q(l.sumOf { it.qty }) + " " + (pr?.unit ?: "") + " • " + Fmt.money(l.sumOf { it.materialsCost + it.extraCost }))
                            }
                        }
                    }
                    SectionTitle(tr("المواد الخام المستهلكة", "Raw materials consumed"))
                    val ids = f.map { it.id }.toSet()
                    d.lines.filter { it.productionId in ids }.groupBy { it.componentId }.forEach { (_, l) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(l.first().name, Modifier.weight(1f))
                            Text(Manufacture.q(l.sumOf { it.qty }) + " " + l.first().unit + " • " + Fmt.money(l.sumOf { it.qty * it.unitCost }), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        val fabMod = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        when (tab) {
            0 -> ExtendedFloatingActionButton(onClick = { pickProduct = true }, modifier = fabMod, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("منتج مُصنَّع", "Manufactured product")) })
            1 -> ExtendedFloatingActionButton(onClick = { newRaw = true }, modifier = fabMod, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("خامة", "Material")) })
            2 -> ExtendedFloatingActionButton(onClick = { if (made.isEmpty()) toast(ctx, tr("عرّف مكونات منتج أولاً", "Define a product's components first")) else pickProduct = true },
                modifier = fabMod, icon = { Icon(Icons.Filled.PrecisionManufacturing, null) }, text = { Text(tr("أمر إنتاج", "Production order")) })
            else -> {}
        }
    }

    if (pickProduct) ProductPickDialog(
        if (tab == 2) d.products.filter { made.containsKey(it.id) } else d.products.filter { !Manufacture.isRaw(it) },
        title = if (tab == 2) tr("اختر المنتج المراد إنتاجه", "Pick the product to produce") else tr("اختر المنتج المُصنَّع (أو أضفه من «الأصناف والمخزون»)", "Pick the product (or add it in «Items & stock»)"),
        onDismiss = { pickProduct = false }
    ) { pr -> pickProduct = false; if (tab == 2) produceFor = pr else nav.navigate("manufacture_bom/${pr.id}") }
    produceFor?.let { pr -> ProduceDialog(pr, d.bom.filter { it.productId == pr.id }, d.pmap, d.stock) { produceFor = null } }
    openOrder?.let { pr -> OrderDialog(pr, d.lines.filter { it.productionId == pr.id }, d.pmap[pr.productId]) { openOrder = null } }
    if (newRaw || editRaw != null) RawMaterialDialog(editRaw, onDismiss = { newRaw = false; editRaw = null })
    receive?.let { r -> ReceiveDialog(r) { receive = null } }
}

/** إضافة / تعديل خامة خاصة بالتصنيع */
@Composable
fun RawMaterialDialog(raw: Product?, onDismiss: () -> Unit, onCreated: ((Product) -> Unit)? = null) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var name by remember { mutableStateOf(raw?.name ?: "") }
    var unit by remember { mutableStateOf(raw?.unit ?: tr("كجم", "kg")) }
    var cost by remember { mutableStateOf(raw?.cost?.takeIf { it > 0 }?.toString() ?: "") }
    var opening by remember { mutableStateOf(raw?.openingQty?.takeIf { it != 0.0 }?.let { Manufacture.q(it).replace(",", "") } ?: "") }
    var min by remember { mutableStateOf(raw?.minQty?.takeIf { it > 0 }?.let { Manufacture.q(it).replace(",", "") } ?: "") }
    var notes by remember { mutableStateOf(raw?.notes ?: "") }
    var del by remember { mutableStateOf(false) }
    var photo by remember { mutableStateOf(ProductImages.get(raw?.id)) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (raw == null) tr("خامة جديدة", "New material") else tr("تعديل الخامة", "Edit material")) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ProductPhotoField(photo, name) { photo = it }
            OutlinedTextField(name, { name = it }, label = { Text(tr("اسم الخامة", "Material name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text(tr("وحدة القياس الأساسية", "Base unit"), style = MaterialTheme.typography.labelMedium)
            HChips { listOf(tr("كجم", "kg"), tr("جرام", "g"), tr("لتر", "L"), tr("متر", "m"), tr("قطعة", "piece"), tr("كرتونة", "carton"), tr("عبوة", "pack")).forEach { u -> FilterChip(unit == u, { unit = u }, label = { Text(u) }) } }
            OutlinedTextField(unit, { unit = it }, label = { Text(tr("الوحدة", "Unit")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            MoneyField(cost, { cost = it }, tr("تكلفة الوحدة", "Cost per unit"))
            NumberField(opening, { opening = it }, tr("الرصيد الافتتاحي", "Opening quantity"))
            NumberField(min, { min = it }, tr("حد إعادة الطلب (تنبيه)", "Reorder level (alert)"))
            OutlinedTextField(notes, { notes = it }, label = { Text(tr("ملاحظات / المورد", "Notes / supplier")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }, confirmButton = {
        TextButton(enabled = name.isNotBlank(), onClick = {
            scope.launch {
                val p = (raw ?: Product(name = "")).copy(name = name.trim(), unit = unit.trim(), category = Manufacture.RAW_CAT, cost = Fmt.parse(cost) ?: 0.0,
                    openingQty = Fmt.parse(opening) ?: 0.0, minQty = Fmt.parse(min) ?: 0.0, notes = notes.trim(), trackStock = true)
                val pid = if (raw == null) { val id = dao.insertProduct(p); onCreated?.invoke(p.copy(id = id)); id } else { dao.updateProduct(p); raw.id }
                if (photo != ProductImages.get(pid)) ProductImages.set(pid, photo)
                onDismiss()
            }
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = {
        Row {
            if (raw != null) TextButton(onClick = { del = true }) { Text(tr("حذف", "Delete"), color = DangerRed) }
            TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) }
        }
    })
    if (del && raw != null) ConfirmDialog(tr("حذف الخامة", "Delete material"), tr("حذف «${raw.name}» وحركاتها وإزالتها من قوائم المكونات؟", "Delete «${raw.name}», its movements and remove it from components?"), onDismiss = { del = false }) {
        del = false; scope.launch { dao.deleteProductFull(raw.id); onDismiss() }
    }
}

/** استلام كمية من خامة (شراء) مع تحديث متوسط التكلفة */
@Composable
private fun ReceiveDialog(raw: Product, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val d = rememberMfg()
    var qty by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }
    var date by remember { mutableStateOf<Long?>(Fmt.today()) }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("استلام: ", "Receive: ") + raw.name) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField(qty, { qty = it }, tr("الكمية", "Quantity") + " (" + raw.unit + ")")
            MoneyField(total, { total = it }, tr("إجمالي التكلفة المدفوعة", "Total cost paid"))
            DateField(tr("التاريخ", "Date"), date, { date = it })
            OutlinedTextField(note, { note = it }, label = { Text(tr("المورد / ملاحظة", "Supplier / note")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            val q = Fmt.parse(qty) ?: 0.0; val t = Fmt.parse(total) ?: 0.0
            if (q > 0 && t > 0) Text(tr("سعر الوحدة: ", "Unit price: ") + Fmt.money(t / q), fontWeight = FontWeight.Bold)
        }
    }, confirmButton = {
        TextButton(enabled = (Fmt.parse(qty) ?: 0.0) != 0.0, onClick = {
            val q = Fmt.parse(qty) ?: 0.0; val t = Fmt.parse(total) ?: 0.0
            scope.launch {
                dao.insertStockAdj(StockAdj(productId = raw.id, qty = q, date = date ?: Fmt.today(), note = tr("استلام خامة", "Material received") + if (note.isNotBlank()) " - " + note.trim() else ""))
                if (q > 0 && t > 0) {
                    val old = (d.stock[raw.id] ?: 0.0).coerceAtLeast(0.0)
                    val avg = (old * raw.cost + t) / (old + q)
                    dao.updateProduct(raw.copy(cost = Manufacture.round2x(avg)))
                }
                toast(ctx, tr("تم الاستلام ✅", "Received ✅"))
                onDismiss()
            }
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } })
}

@Composable
private fun ProductPickDialog(list: List<Product>, title: String, exclude: Set<Long> = emptySet(), allowNewRaw: Boolean = false, onDismiss: () -> Unit, onPick: (Product) -> Unit) {
    var q by remember { mutableStateOf("") }
    var newRaw by remember { mutableStateOf(false) }
    if (newRaw) { RawMaterialDialog(null, onDismiss = { newRaw = false }) { p -> newRaw = false; onPick(p) }; return }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SearchField(q) { q = it }
            if (allowNewRaw) OutlinedButton(onClick = { newRaw = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text(tr("خامة جديدة (للتصنيع فقط)", "New material (manufacturing only)")) }
            val f = list.filter { it.id !in exclude && (q.isBlank() || it.name.contains(q, true) || it.sku.contains(q, true)) }
            if (f.isEmpty()) Text(tr("لا توجد أصناف. أضف الأصناف (المواد الخام والمنتجات) من شاشة المحل ← المخزون.", "No items. Add items (raw materials & products) in Shop → Stock."), style = MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(f, key = { it.id }) { p ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        ProductThumb(p.id, p.name, 40.dp); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.SemiBold)
                            Text(listOf(if (Manufacture.isRaw(p)) tr("🧱 خامة تصنيع", "🧱 material") else p.category, p.unit, Fmt.money(p.cost)).filter { it.isNotBlank() }.joinToString(" • "), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } })
}

@Composable
fun BomScreen(nav: NavController, pid: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val d = rememberMfg()
    val product = d.pmap[pid]
    val bom = d.bom.filter { it.productId == pid }
    var addLine by remember { mutableStateOf(false) }
    var editLine by remember { mutableStateOf<BomLine?>(null) }
    var produce by remember { mutableStateOf(false) }
    var plan by remember { mutableStateOf("10") }
    if (product == null) { ScreenScaffold(title = "…", onBack = { nav.popBackStack() }) { }; return }
    val uc = Manufacture.unitCost(bom, d.pmap)

    ScreenScaffold(title = "🏭 " + product.name, onBack = { nav.popBackStack() }, actions = {
        PdfShareButton(null, doc = { Manufacture.bomDoc(product, bom, d.pmap) }) { c -> Reports.doc(c, Manufacture.bomDoc(product, bom, d.pmap)) }
    }, fab = { ExtendedFloatingActionButton(onClick = { addLine = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("مكوّن", "Component")) }) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(tr("تكلفة مواد الوحدة الواحدة", "Material cost per unit"), style = MaterialTheme.typography.bodySmall)
                        Text(Fmt.money(uc), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text(tr("سعر البيع ", "Price ") + Fmt.money(product.price) + " • " + tr("الربح ", "Margin ") + Fmt.money(product.price - uc) + " • " + tr("المخزون ", "Stock ") + Manufacture.q(d.stock[pid] ?: 0.0) + " " + product.unit,
                            style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { if (bom.isEmpty()) toast(ctx, tr("أضف المكونات أولاً", "Add components first")) else produce = true }) { Icon(Icons.Filled.PrecisionManufacturing, null); Spacer(Modifier.width(6.dp)); Text(tr("أمر إنتاج", "Produce")) }
                            if (uc > 0 && kotlin.math.abs(product.cost - uc) > 0.005) OutlinedButton(onClick = { scope.launch { dao.updateProduct(product.copy(cost = Manufacture.round2x(uc))); toast(ctx, tr("تم تحديث تكلفة المنتج", "Product cost updated")) } }) { Text(tr("اعتماد كتكلفة", "Set as cost")) }
                        }
                    }
                }
            }
            item { SectionTitle(tr("المكونات لإنتاج 1 ", "Components to make 1 ") + product.unit.ifBlank { tr("وحدة", "unit") }) }
            if (bom.isEmpty()) item { EmptyState(Icons.Filled.Category, tr("أضف المواد الخام أو المنتجات التي يتكون منها هذا المنتج.", "Add the raw materials or products it's made of.")) }
            items(bom, key = { it.id }) { l ->
                val c = d.pmap[l.componentId]
                val base = Manufacture.need(l, 1.0)
                Card(onClick = { editLine = l }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c?.name ?: "?", fontWeight = FontWeight.Bold)
                            Text(Manufacture.q(l.qty) + " " + Manufacture.unitLabel(l.unit) + (if (l.unit.isNotBlank() && l.factor != 1.0) " = " + Manufacture.q(l.qty * l.factor) + " " + (c?.unit ?: "") else "") +
                                (if (l.wastePct > 0) tr(" • هالك ", " • waste ") + Manufacture.q(l.wastePct) + "%" else ""), style = MaterialTheme.typography.bodySmall)
                            if (l.note.isNotBlank()) Text(l.note, style = MaterialTheme.typography.labelSmall)
                        }
                        Text(Fmt.money(base * (c?.cost ?: 0.0)), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            if (bom.isNotEmpty()) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionTitle(tr("📋 حساب احتياج المواد", "📋 Material requirements"))
                        NumberField(plan, { plan = it }, tr("الكمية المخطط إنتاجها", "Planned quantity"))
                        val reqs = Manufacture.requirements(bom, Fmt.parse(plan) ?: 0.0, d.pmap, d.stock)
                        reqs.forEach { r ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(r.component?.name ?: "?", Modifier.weight(1f))
                                Text(Manufacture.q(r.need) + " / " + Manufacture.q(r.have) + " " + (r.component?.unit ?: ""), style = MaterialTheme.typography.bodySmall,
                                    color = if (r.short > 0) DangerRed else SuccessGreen)
                            }
                        }
                        val short = reqs.filter { it.short > 0 }
                        Text(if (short.isEmpty()) tr("✅ المخزون يكفي", "✅ Stock is sufficient") else tr("⚠️ نقص في ${short.size} مادة — تكلفة الشراء التقريبية ", "⚠️ ${short.size} materials short — approx. purchase cost ") + Fmt.money(short.sumOf { it.short * (it.component?.cost ?: 0.0) }),
                            fontWeight = FontWeight.Bold, color = if (short.isEmpty()) SuccessGreen else DangerRed)
                        Text(tr("التكلفة الإجمالية للكمية: ", "Total cost for the quantity: ") + Fmt.money(uc * (Fmt.parse(plan) ?: 0.0)), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    if (addLine || editLine != null) BomLineDialog(product, editLine, d.products.filter { it.id != pid }, bom.map { it.componentId }.toSet(), onDismiss = { addLine = false; editLine = null })
    if (produce) ProduceDialog(product, bom, d.pmap, d.stock) { produce = false }
}

@Composable
private fun BomLineDialog(product: Product, line: BomLine?, candidates: List<Product>, used: Set<Long>, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var comp by remember { mutableStateOf(candidates.firstOrNull { it.id == line?.componentId }) }
    var pick by remember { mutableStateOf(false) }
    var qty by remember { mutableStateOf(line?.qty?.let { Manufacture.q(it).replace(",", "") } ?: "1") }
    var unit by remember { mutableStateOf(line?.unit ?: "") }
    var factor by remember { mutableStateOf(line?.factor?.let { Manufacture.q(it).replace(",", "") } ?: "1") }
    var waste by remember { mutableStateOf(line?.wastePct?.takeIf { it > 0 }?.let { Manufacture.q(it) } ?: "") }
    var note by remember { mutableStateOf(line?.note ?: "") }
    var unitMenu by remember { mutableStateOf(false) }
    val auto = comp?.let { Manufacture.autoFactor(unit, it.unit) }
    LaunchedEffect(unit, comp) { if (auto != null) factor = Manufacture.q(auto).replace(",", "") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (line == null) tr("إضافة مكوّن", "Add component") else tr("تعديل المكوّن", "Edit component")) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pick = true }, modifier = Modifier.fillMaxWidth()) {
                Text(comp?.let { it.name + (if (it.unit.isNotBlank()) " (" + it.unit + ")" else "") } ?: tr("اختر المادة الخام / المنتج", "Pick material / product"), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                NumberField(qty, { qty = it }, tr("الكمية", "Qty"), Modifier.weight(1f))
                Box {
                    OutlinedButton(onClick = { unitMenu = true }) { Text(if (unit.isBlank()) (comp?.unit?.ifBlank { null } ?: tr("الوحدة", "Unit")) else Manufacture.unitLabel(unit)) }
                    DropdownMenu(unitMenu, { unitMenu = false }, Modifier.heightIn(max = 340.dp)) {
                        DropdownMenuItem(text = { Text(tr("وحدة المادة نفسها", "Material's own unit") + (comp?.unit?.let { " ($it)" } ?: "")) }, onClick = { unit = ""; factor = "1"; unitMenu = false })
                        Manufacture.units.forEach { u -> DropdownMenuItem(text = { Text(u.label) }, onClick = { unit = u.key; unitMenu = false }) }
                    }
                }
            }
            if (unit.isNotBlank() && auto == null) {
                NumberField(factor, { factor = it }, tr("كم ", "How many ") + (comp?.unit?.ifBlank { null } ?: tr("وحدة أساسية", "base units")) + tr(" في ", " in 1 ") + Manufacture.unitLabel(unit) + "؟")
                Text(tr("مثال: الكرتونة = 12 قطعة، الشوال = 50 كيلو", "e.g. carton = 12 pieces, bag = 50 kg"), style = MaterialTheme.typography.labelSmall)
            } else if (unit.isNotBlank()) Text(tr("تحويل تلقائي: 1 ", "Auto conversion: 1 ") + Manufacture.unitLabel(unit) + " = " + factor + " " + (comp?.unit ?: ""), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            NumberField(waste, { waste = it }, tr("نسبة الهالك % (اختياري)", "Waste % (optional)"))
            OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة", "Note")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            comp?.let { c ->
                val l = BomLine(0, product.id, c.id, Fmt.parse(qty) ?: 0.0, unit, Fmt.parse(factor) ?: 1.0, Fmt.parse(waste) ?: 0.0)
                val n = Manufacture.need(l, 1.0)
                Text(tr("لكل وحدة منتج: ", "Per product unit: ") + Manufacture.q(n) + " " + c.unit + " • " + Fmt.money(n * c.cost), fontWeight = FontWeight.Bold)
            }
        }
    }, confirmButton = {
        TextButton(enabled = comp != null && (Fmt.parse(qty) ?: 0.0) > 0, onClick = {
            val c = comp ?: return@TextButton
            val l = BomLine(line?.id ?: 0, product.id, c.id, Fmt.parse(qty) ?: 1.0, unit, (Fmt.parse(factor) ?: 1.0).takeIf { it > 0 } ?: 1.0, Fmt.parse(waste) ?: 0.0, note.trim())
            scope.launch { if (line == null) dao.insertBom(l) else dao.updateBom(l); onDismiss() }
        }) { Text(tr("حفظ", "Save")) }
    }, dismissButton = {
        Row {
            if (line != null) TextButton(onClick = { scope.launch { dao.deleteBom(line.id); onDismiss() } }) { Text(tr("حذف", "Delete"), color = DangerRed) }
            TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) }
        }
    })
    if (pick) ProductPickDialog(candidates, tr("اختر المكوّن", "Pick component"), exclude = used - setOfNotNull(line?.componentId), allowNewRaw = true, onDismiss = { pick = false }) { comp = it; pick = false }
}

@Composable
private fun ProduceDialog(product: Product, bom: List<BomLine>, pmap: Map<Long, Product>, stock: Map<Long, Double>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var qty by remember { mutableStateOf("1") }
    var extra by remember { mutableStateOf("") }
    var date by remember { mutableStateOf<Long?>(Fmt.today()) }
    var note by remember { mutableStateOf("") }
    var updateCost by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    val q = Fmt.parse(qty) ?: 0.0
    val reqs = Manufacture.requirements(bom, q, pmap, stock)
    val mat = reqs.sumOf { it.need * (it.component?.cost ?: 0.0) }
    val ex = Fmt.parse(extra) ?: 0.0
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("أمر إنتاج: ", "Produce: ") + product.name) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField(qty, { qty = it }, tr("الكمية المنتجة", "Quantity produced") + if (product.unit.isNotBlank()) " (${product.unit})" else "")
            Text(tr("الحد الأقصى من المخزون: ", "Max from stock: ") + Manufacture.q(Manufacture.maxProducible(bom, stock, pmap)), style = MaterialTheme.typography.labelSmall)
            DateField(tr("التاريخ", "Date"), date, { date = it })
            MoneyField(extra, { extra = it }, tr("تكاليف إضافية (عمالة، كهرباء، تغليف...)", "Extra costs (labor, power, packing...)"))
            OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظات / رقم التشغيلة", "Notes / batch no.")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            HorizontalDivider()
            Text(tr("المواد التي ستُخصم من المخزون:", "Materials to deduct from stock:"), style = MaterialTheme.typography.labelLarge)
            reqs.forEach { r ->
                Row {
                    Text(r.component?.name ?: "?", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Text(Manufacture.q(r.need) + " " + (r.component?.unit ?: ""), style = MaterialTheme.typography.bodySmall, color = if (r.short > 0) DangerRed else MaterialTheme.colorScheme.onSurface)
                }
            }
            if (reqs.any { it.short > 0 }) Text(tr("⚠️ بعض المواد غير كافية؛ سيصبح رصيدها بالسالب.", "⚠️ Some materials are short; their stock will go negative."), color = DangerRed, style = MaterialTheme.typography.bodySmall)
            Text(tr("تكلفة المواد: ", "Materials: ") + Fmt.money(mat) + "\n" + tr("الإجمالي: ", "Total: ") + Fmt.money(mat + ex) + " • " + tr("للوحدة: ", "per unit: ") + Fmt.money(if (q > 0) (mat + ex) / q else 0.0), fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(updateCost, { updateCost = it }); Text(tr("تحديث تكلفة المنتج بتكلفة هذه التشغيلة", "Update product cost from this batch"), style = MaterialTheme.typography.bodySmall) }
        }
    }, confirmButton = {
        TextButton(enabled = q > 0 && !busy, onClick = {
            busy = true
            scope.launch {
                val lines = reqs.map { r -> ProductionLine(0, 0, r.line.componentId, r.component?.name ?: "?", Manufacture.round2x(r.need), r.component?.unit ?: "", r.component?.cost ?: 0.0) }
                dao.produce(Production(0, 0, product.id, q, date ?: Fmt.today(), Manufacture.round2x(mat), ex, note.trim()), lines, product.name)
                if (updateCost && q > 0) dao.updateProduct(product.copy(cost = Manufacture.round2x((mat + ex) / q)))
                toast(ctx, tr("تم تسجيل الإنتاج وتحديث المخزون ✅", "Production recorded & stock updated ✅"))
                onDismiss()
            }
        }) { Text(tr("تسجيل الإنتاج", "Record")) }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } })
}

@Composable
private fun OrderDialog(pr: Production, lines: List<ProductionLine>, product: Product?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var del by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(tr("أمر إنتاج #", "Production #") + pr.number) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            KeyValue(tr("المنتج", "Product"), product?.name ?: "?")
            KeyValue(tr("الكمية", "Quantity"), Manufacture.q(pr.qty) + " " + (product?.unit ?: ""))
            KeyValue(tr("التاريخ", "Date"), Fmt.date(pr.date))
            if (pr.note.isNotBlank()) KeyValue(tr("ملاحظات", "Notes"), pr.note)
            HorizontalDivider()
            lines.forEach { l -> Row { Text(l.name, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall); Text(Manufacture.q(l.qty) + " " + l.unit + " • " + Fmt.money(l.qty * l.unitCost), style = MaterialTheme.typography.bodySmall) } }
            HorizontalDivider()
            KeyValue(tr("تكلفة المواد", "Materials"), Fmt.money(pr.materialsCost))
            KeyValue(tr("تكاليف إضافية", "Extra"), Fmt.money(pr.extraCost))
            KeyValue(tr("تكلفة الوحدة", "Unit cost"), Fmt.money(if (pr.qty > 0) (pr.materialsCost + pr.extraCost) / pr.qty else 0.0))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PdfShareButton(null, doc = { Manufacture.productionDoc(pr, lines, product) }) { c -> Reports.doc(c, Manufacture.productionDoc(pr, lines, product)) }
                TextButton(onClick = { del = true }) { Text(tr("حذف الأمر", "Delete order"), color = DangerRed) }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text(tr("إغلاق", "Close")) } })
    if (del) ConfirmDialog(tr("حذف أمر الإنتاج", "Delete production order"), tr("سيتم التراجع عن حركات المخزون الخاصة به. متابعة؟", "Its stock movements will be reverted. Continue?"), onDismiss = { del = false }) {
        del = false
        scope.launch { dao.deleteProductionFull(pr.id); toast(ctx, tr("تم الحذف", "Deleted")); onDismiss() }
    }
}
