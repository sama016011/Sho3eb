package com.sho3eb.app.core

import com.sho3eb.app.data.CreditBook
import com.sho3eb.app.data.CreditEntry
import java.time.LocalDate

/** دفتر ديون البقالة (الشُّكك / الآجل) */
object Grocery {
    const val OWE_ME = "OWE_ME"
    const val I_OWE = "I_OWE"
    const val BUY = "BUY"
    const val PAY = "PAY"

    data class Row(val e: CreditEntry, val balance: Double)
    data class Book(val b: CreditBook, val entries: List<CreditEntry>) {
        val bought get() = round2(entries.filter { it.type == BUY }.sumOf { it.amount })
        val paid get() = round2(entries.filter { it.type == PAY }.sumOf { it.amount })
        val balance get() = round2(bought - paid)
        val lastPay get() = entries.filter { it.type == PAY }.maxOfOrNull { it.date }
        val lastBuy get() = entries.filter { it.type == BUY }.maxOfOrNull { it.date }
        val overLimit get() = b.creditLimit > 0 && balance > b.creditLimit
        /** أيام منذ آخر سداد (أو منذ أول سحب إن لم يسدد) */
        val daysSincePay: Long? get() {
            if (balance <= 0.01) return null
            val from = lastPay ?: entries.filter { it.type == BUY }.minOfOrNull { it.date } ?: return null
            return Fmt.today() - from
        }
        val monthBought get() = LivingAuto.monthRange().let { r -> round2(entries.filter { it.type == BUY && it.date in r }.sumOf { it.amount }) }
        fun rows(): List<Row> {
            var bal = 0.0
            return entries.sortedWith(compareBy({ it.date }, { it.id })).map { e -> bal += if (e.type == BUY) e.amount else -e.amount; Row(e, round2(bal)) }
        }
    }

    fun books(books: List<CreditBook>, entries: List<CreditEntry>): List<Book> {
        val g = entries.groupBy { it.bookId }
        return books.map { Book(it, g[it.id] ?: emptyList()) }
    }

    fun reminder(k: Book): String {
        val sb = StringBuilder()
        if (k.b.mode == OWE_ME) {
            sb.append(tr("السلام عليكم ${k.b.name} 🌹\n", "Hello ${k.b.name} 🌹\n"))
            sb.append(tr("رصيد حسابكم لدينا: ", "Your balance with us: ")).append(Fmt.money(k.balance)).append("\n")
            val last = k.rows().takeLast(5)
            if (last.isNotEmpty()) {
                sb.append(tr("آخر الحركات:\n", "Latest:\n"))
                last.forEach { r -> sb.append("• ").append(Fmt.date(r.e.date)).append(" ").append(if (r.e.type == BUY) tr("مشتريات", "Purchase") else tr("سداد", "Payment")).append(" ").append(Fmt.num(r.e.amount)).append(if (r.e.items.isNotBlank()) " (" + r.e.items.take(40) + ")" else "").append("\n") }
            }
            sb.append(tr("نرجو التكرم بالسداد، شاكرين تعاملكم.", "Kindly settle at your convenience. Thank you."))
            if (Extras.shopName.isNotBlank()) sb.append("\n").append(Extras.shopName)
        } else {
            sb.append(tr("السلام عليكم، أرجو إرسال كشف حسابي. حسب دفتري الرصيد: ", "Hello, please send my statement. My balance by my records: ")).append(Fmt.money(k.balance))
        }
        return sb.toString()
    }

    fun doc(k: Book, range: LongRange?): ReportDoc {
        val all = k.rows()
        val opening = if (range == null) 0.0 else all.lastOrNull { it.e.date < range.first }?.balance ?: 0.0
        val list = all.filter { range == null || it.e.date in range }
        return ReportDoc(
            tr("كشف دفتر الآجل", "Credit book statement"), k.b.name + (range?.let { " • " + Fmt.date(it.first) + " ← " + Fmt.date(it.last) } ?: ""),
            listOfNotNull(
                tr("الاسم", "Name") to k.b.name,
                k.b.phone.takeIf { it.isNotBlank() }?.let { tr("الجوال", "Phone") to it },
                tr("النوع", "Type") to (if (k.b.mode == OWE_ME) tr("زبون يشتري مني بالآجل", "Customer buying on credit") else tr("حسابي لدى البقالة", "My account at the grocer")),
                tr("إجمالي المشتريات", "Total purchases") to Fmt.money(k.bought),
                tr("إجمالي المسدد", "Total paid") to Fmt.money(k.paid),
                tr("الرصيد المستحق", "Balance due") to Fmt.money(k.balance)
            ),
            listOf(RTable(
                tr("الحركات", "Entries"),
                listOf(tr("التاريخ", "Date"), tr("البيان", "Description"), tr("مشتريات", "Purchase"), tr("سداد", "Payment"), tr("الرصيد", "Balance")),
                (if (range != null) listOf(listOf(Fmt.date(range.first), tr("رصيد سابق", "Previous balance"), "", "", Fmt.num(opening))) else emptyList()) +
                    list.map { r -> listOf(Fmt.date(r.e.date), (r.e.items.ifBlank { r.e.note }).ifBlank { if (r.e.type == BUY) tr("مشتريات", "Purchase") else tr("سداد", "Payment") }, if (r.e.type == BUY) Fmt.num(r.e.amount) else "", if (r.e.type == PAY) Fmt.num(r.e.amount) else "", Fmt.num(r.balance)) },
                (if (range != null) listOf(9) else emptyList<Int?>()) + list.map { if (it.e.type == PAY) 1 else null }
            )),
            listOf(tr("الرصيد المستحق", "Balance due") to Fmt.money(k.balance)),
            "", "credit_" + k.b.name
        )
    }

    fun allDoc(list: List<Book>, mode: String): ReportDoc = ReportDoc(
        if (mode == OWE_ME) tr("ديون الزبائن (الآجل)", "Customer credit balances") else tr("حساباتي لدى المحلات", "My shop credit accounts"),
        Fmt.date(Fmt.today()),
        listOf(tr("عدد الحسابات", "Accounts") to list.size.toString(), tr("إجمالي المستحق", "Total due") to Fmt.money(list.sumOf { it.balance })),
        listOf(RTable(
            tr("الأرصدة", "Balances"),
            listOf(tr("الاسم", "Name"), tr("الجوال", "Phone"), tr("المشتريات", "Purchases"), tr("المسدد", "Paid"), tr("الرصيد", "Balance"), tr("آخر سداد", "Last payment")),
            list.map { k -> listOf(k.b.name, k.b.phone, Fmt.num(k.bought), Fmt.num(k.paid), Fmt.num(k.balance), k.lastPay?.let { Fmt.date(it) } ?: "-") } +
                listOf(listOf(tr("الإجمالي", "Total"), "", Fmt.num(list.sumOf { it.bought }), Fmt.num(list.sumOf { it.paid }), Fmt.num(list.sumOf { it.balance }), "")),
            list.map { k -> if (k.balance <= 0.01) 1 else if ((k.daysSincePay ?: 0) > 30) 2 else null } + listOf(9)
        )),
        emptyList(), "", "credit_books"
    )
}
