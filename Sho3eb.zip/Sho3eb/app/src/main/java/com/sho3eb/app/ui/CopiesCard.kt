package com.sho3eb.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.sho3eb.app.core.Copies
import com.sho3eb.app.core.toast
import com.sho3eb.app.core.tr
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** إعدادات النسخة الأساسية: إنشاء «نسخة 1» و«نسخة 2» مستقلتين على نفس الهاتف */
@Composable
fun CopiesCard() {
    if (!Copies.enabled) return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    var busy by remember { mutableIntStateOf(0) }
    var prog by remember { mutableIntStateOf(0) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(tr("📱 نسخ إضافية على هذا الهاتف", "📱 Extra copies on this phone"))
            Text(tr("كل نسخة تطبيق مستقل بأيقونته وبياناته، تسجّل فيه برقم هاتف وبريد مختلفين، وتستقبل رسائله ومكالماته بجانب النسخة الأساسية.",
                "Each copy is a separate app with its own icon and data — sign in with a different phone and email; all copies receive their messages and calls."),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Copies.ids.forEach { n ->
                val inst = remember(tick, busy) { Copies.installed(ctx, n) }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !inst && busy == 0, onClick = {
                        if (!Copies.canInstall(ctx)) { toast(ctx, tr("اسمح للتطبيق بتثبيت التطبيقات ثم ارجع واضغط مرة أخرى", "Allow installing apps, then come back and tap again")); Copies.askInstallPermission(ctx); return@Button }
                        busy = n; prog = 0
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { runCatching { Copies.build(ctx, n) { p -> prog = p } } }
                            busy = 0
                            r.onSuccess { runCatching { Copies.install(ctx, it) }.onFailure { e -> toast(ctx, e.message ?: "") } }
                                .onFailure { toast(ctx, tr("تعذر إنشاء النسخة: ", "Couldn't create the copy: ") + (it.message ?: it.javaClass.simpleName)) }
                        }
                    }, modifier = Modifier.weight(1f)) {
                        Icon(if (inst) Icons.Filled.CheckCircle else Icons.Filled.AddToHomeScreen, null); Spacer(Modifier.width(6.dp))
                        Text(if (inst) tr("نسخة $n مثبتة", "Copy $n installed") else tr("إنشاء نسخة $n", "Create copy $n"))
                    }
                    if (inst) {
                        FilledTonalIconButton(onClick = { Copies.open(ctx, n) }) { Icon(Icons.Filled.OpenInNew, tr("فتح", "Open")) }
                        IconButton(onClick = { Copies.uninstall(ctx, n) }) { Icon(Icons.Filled.Delete, tr("حذف", "Remove"), tint = DangerRed) }
                    }
                }
                if (busy == n) {
                    Text(tr("⏳ جارٍ تجهيز نسخة $n… $prog%", "⏳ Preparing copy $n… $prog%"), style = MaterialTheme.typography.labelMedium)
                    LinearProgressIndicator(progress = { prog / 100f }, modifier = Modifier.fillMaxWidth())
                }
                if (inst) Text(tr("✅ يظهر الزر غير نشط طالما النسخة مثبتة. احذفها لتتمكن من إنشائها من جديد.", "✅ The button stays disabled while the copy is installed. Remove it to create it again."),
                    style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
            }
            Text(tr("💡 بعد الضغط سيطلب الهاتف تأكيد التثبيت. النسخ لا تحتوي على هذه الأزرار.", "💡 Your phone will ask to confirm the install. Copies don't have these buttons."),
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
