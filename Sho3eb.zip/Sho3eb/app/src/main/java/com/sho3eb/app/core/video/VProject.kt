package com.sho3eb.app.core.video

import androidx.compose.runtime.mutableStateOf
import com.sho3eb.app.core.Extras
import com.sho3eb.app.core.tr
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** عنصر في مسار الصور/الفيديو */
data class VClip(
    val id: String = uid(), val uri: String, val video: Boolean, val durMs: Long,
    val srcDurMs: Long = 0, val trimStartMs: Long = 0,
    val style: String = "NORMAL", val motion: String = "ZOOM_IN", val transition: String = "FADE",
    val muted: Boolean = false, val caption: String = "",
    /** media = صورة/فيديو، intro = بداية، outro = نهاية */
    val kind: String = "media", val title: String = "", val sub: String = "", val color: Int = 0xFFFFFFFF.toInt()
) { val isCard get() = kind != "media" }

/** مسار صوت: يُقص من الأصل (trimStart..trimEnd) ويبدأ عند startMs من الفيديو */
data class VAudio(
    val id: String = uid(), val uri: String, val name: String, val srcDurMs: Long,
    val trimStartMs: Long = 0, val trimEndMs: Long = srcDurMs, val startMs: Long = 0,
    val volume: Float = 1f, val loop: Boolean = false
) { val lenMs get() = (trimEndMs - trimStartMs).coerceAtLeast(0) }

/** طبقة فوق الفيديو: نص، شعار، ملصق، مؤثر، إطار — لكل منها وقت بداية ومدة */
data class VOverlay(
    val id: String = uid(), val kind: String, val startMs: Long = 0, val durMs: Long = 4000,
    val text: String = "", val color: Int = 0xFFFFFFFF.toInt(), val size: Float = 0.09f,
    val x: Float = 0.5f, val y: Float = 0.5f, val key: String = "", val uri: String = "",
    val anim: String = "FADE", val bg: Boolean = false, val opacity: Float = 1f,
    /** زاوية الدوران بالدرجات، vert = حروف عمودية */
    val rot: Float = 0f, val vert: Boolean = false
)

data class VProject(
    val aspect: String = "16:9", val quality: Int = 720, val filter: String = "NONE", val transitionMs: Long = 800,
    val clips: List<VClip> = emptyList(), val audios: List<VAudio> = emptyList(), val overlays: List<VOverlay> = emptyList(),
    val template: String = ""
) {
    val totalMs: Long get() = clips.sumOf { it.durMs }
    fun startOf(i: Int): Long = clips.take(i).sumOf { it.durMs }
    /** فهرس العنصر عند زمن t */
    fun clipAt(t: Long): Int {
        var acc = 0L
        clips.forEachIndexed { i, c -> if (t < acc + c.durMs) return i; acc += c.durMs }
        return clips.lastIndex
    }
    /** أبعاد الإخراج بحسب النسبة والجودة */
    fun outSize(): Pair<Int, Int> {
        val q = quality
        fun even(v: Int) = v - v % 2
        return when (aspect) {
            "9:16" -> q to even(q * 16 / 9)
            "1:1" -> q to q
            "4:5" -> q to even(q * 5 / 4)
            else -> even(q * 16 / 9) to q
        }
    }
    val ratio: Float get() = outSize().let { it.first.toFloat() / it.second }

    fun toJson(): JSONObject = JSONObject().put("aspect", aspect).put("quality", quality).put("filter", filter).put("tms", transitionMs).put("tpl", template)
        .put("clips", JSONArray(clips.map { c -> JSONObject().put("id", c.id).put("u", c.uri).put("v", c.video).put("d", c.durMs).put("sd", c.srcDurMs).put("ts", c.trimStartMs).put("st", c.style).put("m", c.motion).put("tr", c.transition).put("mu", c.muted).put("cap", c.caption).put("k", c.kind).put("ti", c.title).put("sb", c.sub).put("co", c.color) }))
        .put("audios", JSONArray(audios.map { a -> JSONObject().put("id", a.id).put("u", a.uri).put("n", a.name).put("sd", a.srcDurMs).put("ts", a.trimStartMs).put("te", a.trimEndMs).put("s", a.startMs).put("vol", a.volume.toDouble()).put("lp", a.loop) }))
        .put("ovs", JSONArray(overlays.map { o -> JSONObject().put("id", o.id).put("k", o.kind).put("s", o.startMs).put("d", o.durMs).put("t", o.text).put("c", o.color).put("sz", o.size.toDouble()).put("x", o.x.toDouble()).put("y", o.y.toDouble()).put("key", o.key).put("u", o.uri).put("a", o.anim).put("bg", o.bg).put("op", o.opacity.toDouble()).put("r", o.rot.toDouble()).put("vt", o.vert) }))

    companion object {
        fun fromJson(o: JSONObject): VProject {
            fun <T> arr(k: String, f: (JSONObject) -> T): List<T> = o.optJSONArray(k)?.let { a -> (0 until a.length()).mapNotNull { runCatching { f(a.getJSONObject(it)) }.getOrNull() } } ?: emptyList()
            return VProject(
                aspect = o.optString("aspect", "16:9"), quality = o.optInt("quality", 720), filter = o.optString("filter", "NONE"),
                transitionMs = o.optLong("tms", 800), template = o.optString("tpl"),
                clips = arr("clips") { c -> VClip(c.getString("id"), c.getString("u"), c.getBoolean("v"), c.getLong("d"), c.optLong("sd"), c.optLong("ts"), c.optString("st", "NORMAL"), c.optString("m", "ZOOM_IN"), c.optString("tr", "FADE"), c.optBoolean("mu"), c.optString("cap"), c.optString("k", "media"), c.optString("ti"), c.optString("sb"), c.optInt("co", -1)) },
                audios = arr("audios") { a -> VAudio(a.getString("id"), a.getString("u"), a.optString("n"), a.getLong("sd"), a.optLong("ts"), a.optLong("te", a.getLong("sd")), a.optLong("s"), a.optDouble("vol", 1.0).toFloat(), a.optBoolean("lp")) },
                overlays = arr("ovs") { v -> VOverlay(v.getString("id"), v.getString("k"), v.optLong("s"), v.optLong("d", 4000), v.optString("t"), v.optInt("c", -1), v.optDouble("sz", 0.09).toFloat(), v.optDouble("x", 0.5).toFloat(), v.optDouble("y", 0.5).toFloat(), v.optString("key"), v.optString("u"), v.optString("a", "FADE"), v.optBoolean("bg"), v.optDouble("op", 1.0).toFloat(), v.optDouble("r", 0.0).toFloat(), v.optBoolean("vt")) }
            )
        }
    }
}

fun uid(): String = UUID.randomUUID().toString().take(8)

/** خيار مع اسم عربي/إنجليزي ورمز */
data class VOpt(val key: String, val ar: String, val en: String, val emoji: String) { val label get() = tr(ar, en) }

/** المشروع الحالي في المحرر (يُحفظ كمسودة تلقائياً) */
object VEditor {
    val project = mutableStateOf(load())
    private fun load(): VProject = runCatching { VProject.fromJson(JSONObject(Extras.s("vproj_draft", "{}"))) }.getOrDefault(VProject())
    fun update(f: (VProject) -> VProject) { project.value = f(project.value); runCatching { Extras.ps("vproj_draft", project.value.toJson().toString()) } }
    fun reset() = update { VProject(aspect = it.aspect, quality = it.quality) }

    val styles = listOf(
        VOpt("NORMAL", "عادي سينمائي", "Cinematic", "🎞️"), VOpt("CARD", "بطاقة بولارويد", "Polaroid card", "🖼️"),
        VOpt("BOUNCE", "قفز مرح", "Bounce", "🏀"), VOpt("BALLOONS", "بالونات ترفع الصورة", "Balloons lift", "🎈"),
        VOpt("BIRDS", "طيور تحمل الصورة", "Birds carry", "🕊️"), VOpt("ANIMAL", "حيوان يرفع الصورة", "Animal holds", "🐘"),
        VOpt("ANIMAL2", "حيوانان يحملان الصورة", "Two animals", "🐻"), VOpt("PLANE", "طائرة تسحب الصورة", "Plane banner", "✈️"),
        VOpt("GIFT", "تخرج من هدية", "From a gift", "🎁"), VOpt("HEART", "داخل قلب", "In a heart", "💖"),
        VOpt("CIRCLE", "دائرة ذهبية", "Gold circle", "⭕"), VOpt("FILM", "شريط سينما", "Film strip", "📽️"),
        VOpt("TV", "تلفزيون قديم", "Retro TV", "📺"), VOpt("PHONE", "شاشة هاتف", "Phone screen", "📱"),
        VOpt("SPLIT", "صورتان معاً", "Split", "🪟")
    )
    val motions = listOf(
        VOpt("NONE", "ثابت", "Static", "⏸️"), VOpt("ZOOM_IN", "تقريب", "Zoom in", "🔍"), VOpt("ZOOM_OUT", "تبعيد", "Zoom out", "🔭"),
        VOpt("PAN_L", "تحريك يسار", "Pan left", "⬅️"), VOpt("PAN_R", "تحريك يمين", "Pan right", "➡️"), VOpt("PAN_UP", "تحريك لأعلى", "Pan up", "⬆️"),
        VOpt("ROTATE", "دوران خفيف", "Rotate", "🔃")
    )
    val transitions = listOf(
        VOpt("NONE", "بدون", "None", "⬜"), VOpt("FADE", "تلاشي متداخل", "Crossfade", "🌫️"), VOpt("BLACK", "عبر الأسود", "Dip to black", "⚫"),
        VOpt("WHITE", "وميض أبيض", "Flash", "⚪"), VOpt("SLIDE_L", "انزلاق لليسار", "Slide left", "⬅️"), VOpt("SLIDE_R", "انزلاق لليمين", "Slide right", "➡️"),
        VOpt("SLIDE_UP", "انزلاق لأعلى", "Slide up", "⬆️"), VOpt("ZOOM", "تكبير", "Zoom", "🔍"), VOpt("SPIN", "دوران", "Spin", "🌀"),
        VOpt("CIRCLE", "دائرة", "Circle reveal", "⭕"), VOpt("WIPE", "مسح", "Wipe", "🧹"), VOpt("BLINDS", "ستائر", "Blinds", "🪟"),
        VOpt("HEART", "قلب", "Heart", "💖"), VOpt("DIAMOND", "معيّن", "Diamond", "🔷"), VOpt("PUSH_DOWN", "دفع لأسفل", "Push down", "⬇️")
    )
    val filters = listOf(
        VOpt("NONE", "بدون", "None", "⬜"), VOpt("BW", "أبيض وأسود", "B&W", "⚫"), VOpt("SEPIA", "قديم", "Sepia", "🟤"),
        VOpt("WARM", "دافئ", "Warm", "🌅"), VOpt("COOL", "بارد", "Cool", "❄️"), VOpt("VIVID", "زاهي", "Vivid", "🌈"), VOpt("FADED", "باهت ناعم", "Soft", "🌸")
    )
    val fxKinds = listOf(
        VOpt("SNOW", "نزول الثلج", "Snow", "❄️"), VOpt("RAIN", "مطر", "Rain", "🌧️"), VOpt("FIREWORKS", "ألعاب نارية", "Fireworks", "🎆"),
        VOpt("CONFETTI", "قصاصات ملونة", "Confetti", "🎊"), VOpt("HEARTS", "قلوب طائرة", "Hearts", "💕"), VOpt("BALLOONS", "بالونات", "Balloons", "🎈"),
        VOpt("STARS", "نجوم تتلألأ", "Twinkling stars", "⭐"), VOpt("BUBBLES", "فقاعات", "Bubbles", "🫧"), VOpt("PETALS", "بتلات ورد", "Petals", "🌸"),
        VOpt("LEAVES", "أوراق الخريف", "Autumn leaves", "🍂"), VOpt("SPARKLES", "بريق", "Sparkles", "✨"), VOpt("BUTTERFLIES", "فراشات", "Butterflies", "🦋"),
        VOpt("LANTERNS", "فوانيس", "Lanterns", "🏮"), VOpt("LIGHTS", "إضاءات ملونة", "Bokeh lights", "🟡"),
        VOpt("C_BUTTERFLY", "فراشة تطير أمام الفيديو", "Butterfly flying", "🦋"), VOpt("C_CAT", "قطة تجري بالأسفل", "Running cat", "🐈"),
        VOpt("C_DOG", "كلب يجري", "Running dog", "🐕"), VOpt("C_HORSE", "حصان يركض", "Galloping horse", "🐎"),
        VOpt("C_UNICORN", "يونيكورن بقوس قزح", "Rainbow unicorn", "🦄"), VOpt("C_BIRDS", "سرب طيور", "Flock of birds", "🐦"),
        VOpt("C_BEE", "نحلة تطير", "Buzzing bee", "🐝"), VOpt("C_FISH", "أسماك تسبح", "Swimming fish", "🐠"),
        VOpt("C_DUCKS", "بطة وصغارها", "Duck family", "🦆"), VOpt("C_TURTLE", "سلحفاة بطيئة", "Slow turtle", "🐢"),
        VOpt("C_SANTA", "زلاجة سانتا", "Santa's sleigh", "🛷"), VOpt("C_PLANE", "طائرة بدخان", "Plane with trail", "✈️"),
        VOpt("C_CAR", "سيارة مسرعة", "Racing car", "🚗"), VOpt("C_BALLOON", "بالون يصعد", "Rising balloon", "🎈")
    )
    val frames = listOf(
        VOpt("GOLD", "ذهبي فاخر", "Gold", "🟨"), VOpt("FLOWERS", "ورود", "Flowers", "🌸"), VOpt("HEARTS", "قلوب", "Hearts", "💖"),
        VOpt("STARS", "نجوم", "Stars", "⭐"), VOpt("KIDS", "أطفال ملون", "Kids", "🧸"), VOpt("FILM", "سينما", "Cinema", "🎬"),
        VOpt("VINTAGE", "قديم (تعتيم)", "Vintage", "📷"), VOpt("XMAS", "كريسماس", "Christmas", "🎄"), VOpt("RAMADAN", "رمضان", "Ramadan", "🌙"),
        VOpt("WEDDING", "زفاف", "Wedding", "💍"), VOpt("BIRTHDAY", "عيد ميلاد", "Birthday", "🎂"), VOpt("NEON", "نيون", "Neon", "💡"),
        VOpt("BOOK", "كتاب الذكريات", "Scrapbook", "📒")
    )
    val intros = listOf(
        VOpt("I_CURTAIN", "ستارة مسرح", "Theater curtain", "🎭"), VOpt("I_GOLD", "ذهبي فاخر", "Luxury gold", "👑"),
        VOpt("I_NEON", "نيون", "Neon", "💡"), VOpt("I_COUNT", "عدّ تنازلي سينمائي", "Film countdown", "🎞️"),
        VOpt("I_STARS", "سماء النجوم", "Starry night", "🌌"), VOpt("I_HEARTS", "قلوب رومانسية", "Romantic hearts", "💞"),
        VOpt("I_PARTY", "احتفال", "Party", "🥳"), VOpt("I_MINIMAL", "بسيط أنيق", "Minimal", "➖"),
        VOpt("I_SPLASH", "دوائر ملونة", "Color splash", "🎨"), VOpt("I_BOOK", "كتاب الذكريات", "Memory book", "📖")
    )
    val outros = listOf(
        VOpt("O_THANKS", "شكراً للمشاهدة", "Thanks for watching", "🙏"), VOpt("O_SUBSCRIBE", "اشترك وفعّل الجرس", "Subscribe & bell", "🔔"),
        VOpt("O_END", "النهاية (سينما)", "The End", "🎬"), VOpt("O_LOGO", "الشعار في المنتصف", "Logo reveal", "🏷️"),
        VOpt("O_HEARTS", "مع حبي", "With love", "❤️"), VOpt("O_FIRE", "ألعاب نارية", "Fireworks", "🎆"),
        VOpt("O_GOLD", "ذهبي فاخر", "Luxury gold", "👑"), VOpt("O_MINIMAL", "بسيط أنيق", "Minimal", "➖")
    )
    fun defaultTitle(style: String): Pair<String, String> = when (style) {
        "O_THANKS" -> tr("شكراً للمشاهدة", "Thanks for watching") to ""
        "O_SUBSCRIBE" -> tr("اشترك في القناة", "Subscribe") to tr("وفعّل زر الجرس 🔔", "and hit the bell 🔔")
        "O_END" -> tr("النهاية", "The End") to ""
        "O_LOGO" -> "" to ""
        "O_HEARTS" -> tr("مع حبي ❤️", "With love ❤️") to ""
        "O_FIRE", "O_GOLD", "O_MINIMAL" -> tr("إلى اللقاء", "See you soon") to ""
        else -> tr("عنوان الفيديو", "Video title") to tr("اكتب وصفاً قصيراً", "A short subtitle")
    }
    /** إضافة أو استبدال البداية/النهاية */
    fun setCard(kind: String, style: String, title: String? = null, sub: String? = null, color: Int? = null): String {
        var newId = ""
        update { p ->
            val old = p.clips.firstOrNull { it.kind == kind }
            val (dt, ds) = defaultTitle(style)
            val c = (old ?: VClip(uri = "", video = false, durMs = 4000, kind = kind, transition = "FADE", color = 0xFFFFFFFF.toInt()))
                .copy(style = style, title = title ?: old?.title?.takeIf { it.isNotBlank() } ?: dt, sub = sub ?: old?.sub ?: ds, color = color ?: old?.color ?: 0xFFFFFFFF.toInt())
            newId = c.id
            val rest = p.clips.filter { it.kind != kind }
            p.copy(clips = if (kind == "intro") listOf(c) + rest else rest + c)
        }
        return newId
    }

    val textAnims = listOf(
        VOpt("NONE", "ثابت", "Static", "⏸️"), VOpt("FADE", "تلاشي", "Fade", "🌫️"), VOpt("POP", "قفز", "Pop", "💥"),
        VOpt("SLIDE", "صعود", "Slide up", "⬆️"), VOpt("TYPE", "آلة كاتبة", "Typewriter", "⌨️"), VOpt("GLOW", "توهج", "Glow", "✨"), VOpt("WAVE", "تموج", "Wave", "🌊")
    )
    val stickerAnims = listOf(
        VOpt("FLOAT", "طفو", "Float", "🎈"), VOpt("PULSE", "نبض", "Pulse", "💓"), VOpt("SPIN", "دوران", "Spin", "🌀"),
        VOpt("BOUNCE", "قفز", "Bounce", "🏀"), VOpt("SWING", "تأرجح", "Swing", "🔔"), VOpt("NONE", "ثابت", "Static", "⏸️")
    )
    val stickerSets = listOf(
        tr("عيد ميلاد", "Birthday") to "🎂 🎉 🎈 🎁 🥳 🕯️ 🍰 🎊",
        tr("حب", "Love") to "❤️ 💖 💕 💘 🌹 💌 😍 💝",
        tr("زفاف", "Wedding") to "💍 👰 🤵 💐 🕊️ 🥂 💒 🤍",
        tr("أطفال", "Kids") to "🧸 🍼 👶 🦄 🐣 🌈 🎠 🪁",
        tr("كريسماس", "Christmas") to "🎄 🎅 ⛄ 🎁 ❄️ 🔔 🦌 🌟",
        tr("رمضان والعيد", "Ramadan & Eid") to "🌙 ⭐ 🏮 🕌 🤲 🐑 🎊 📿",
        tr("تخرج ونجاح", "Graduation") to "🎓 📜 🏆 🥇 👏 💯 🌟 🎯",
        tr("حيوانات", "Animals") to "🐶 🐱 🐰 🐻 🐼 🦁 🐘 🦒 🐵 🐧 🦋 🐬",
        tr("عام", "General") to "😂 😍 👍 🔥 ✨ 💯 🙏 😎 🤩 👑"
    )
    val colors = listOf(0xFFFFFFFF, 0xFF000000, 0xFFFFD54F, 0xFFFF5252, 0xFFFF4081, 0xFFE040FB, 0xFF7C4DFF, 0xFF448AFF, 0xFF18FFFF, 0xFF69F0AE, 0xFFB2FF59, 0xFFFFAB40, 0xFFD4AF37, 0xFF8D6E63).map { it.toInt() }
    val animals = listOf("🐘", "🦒", "🐻", "🐼", "🐰", "🦁", "🐶", "🐱", "🐨", "🦄", "🐵", "🐧")

    // ---------------- القوالب الجاهزة ----------------
    data class Template(val key: String, val ar: String, val en: String, val emoji: String, val titleAr: String, val titleEn: String,
                        val styles: List<String>, val transitions: List<String>, val motions: List<String>,
                        val fx: List<String>, val frame: String, val stickers: String, val filter: String = "NONE", val color: Int = 0xFFFFFFFF.toInt(), val endAr: String = "", val endEn: String = "") {
        val label get() = tr(ar, en)
    }
    val templates = listOf(
        Template("BIRTHDAY", "عيد ميلاد", "Birthday", "🎂", "عيد ميلاد سعيد 🎂", "Happy Birthday 🎂", listOf("BALLOONS", "CARD", "GIFT", "BOUNCE", "ANIMAL"), listOf("ZOOM", "SPIN", "CIRCLE"), listOf("ZOOM_IN"), listOf("BALLOONS", "CONFETTI"), "BIRTHDAY", "🎂 🎉", color = 0xFFFFD54F.toInt(), endAr = "كل عام وأنت بخير 🎉", endEn = "Many happy returns 🎉"),
        Template("LOVE", "عيد الحب", "Valentine", "💖", "أحبك ❤️", "I love you ❤️", listOf("HEART", "CARD", "HEART", "CIRCLE"), listOf("HEART", "FADE"), listOf("ZOOM_IN"), listOf("HEARTS"), "HEARTS", "💖", filter = "WARM", color = 0xFFFF4081.toInt(), endAr = "معاً للأبد 💕", endEn = "Forever together 💕"),
        Template("WEDDING", "زفاف", "Wedding", "💍", "زفاف مبارك 💍", "Happy Wedding 💍", listOf("CARD", "CIRCLE", "NORMAL", "BIRDS"), listOf("FADE", "WHITE", "BLACK"), listOf("ZOOM_IN", "PAN_L"), listOf("PETALS", "SPARKLES"), "WEDDING", "💍", filter = "WARM", color = 0xFFD4AF37.toInt(), endAr = "بالرفاء والبنين 🤍", endEn = "Best wishes 🤍"),
        Template("KIDS", "أطفال", "Kids", "🧸", "أجمل أطفال 🧸", "Little stars 🧸", listOf("ANIMAL", "BOUNCE", "BALLOONS", "ANIMAL2"), listOf("SLIDE_L", "SPIN", "ZOOM"), listOf("ZOOM_IN"), listOf("BUBBLES"), "KIDS", "🧸 🌈", color = 0xFF69F0AE.toInt()),
        Template("ANIMALS", "حيوانات تحمل الصور", "Animal parade", "🐘", "رحلة الحيوانات 🐾", "Animal parade 🐾", listOf("ANIMAL", "BIRDS", "ANIMAL2", "PLANE", "BALLOONS"), listOf("SLIDE_L", "SLIDE_R", "CIRCLE"), listOf("NONE"), listOf("BUTTERFLIES"), "KIDS", "🐾", color = 0xFFFFAB40.toInt()),
        Template("XMAS", "كريسماس", "Christmas", "🎄", "عيد ميلاد مجيد 🎄", "Merry Christmas 🎄", listOf("CARD", "GIFT", "NORMAL", "CIRCLE"), listOf("FADE", "WIPE", "WHITE"), listOf("ZOOM_IN", "PAN_R"), listOf("SNOW"), "XMAS", "🎄 🎅", filter = "COOL", color = 0xFFFF5252.toInt(), endAr = "سنة سعيدة ⛄", endEn = "Happy holidays ⛄"),
        Template("RAMADAN", "رمضان كريم", "Ramadan", "🌙", "رمضان كريم 🌙", "Ramadan Kareem 🌙", listOf("CIRCLE", "CARD", "NORMAL"), listOf("FADE", "DIAMOND"), listOf("ZOOM_IN"), listOf("STARS", "LANTERNS"), "RAMADAN", "🌙", color = 0xFFD4AF37.toInt()),
        Template("EID", "عيد مبارك", "Eid", "🕌", "عيد مبارك 🎉", "Eid Mubarak 🎉", listOf("CARD", "BOUNCE", "NORMAL", "GIFT"), listOf("ZOOM", "CIRCLE", "WHITE"), listOf("ZOOM_IN"), listOf("FIREWORKS", "CONFETTI"), "GOLD", "🎊", color = 0xFFD4AF37.toInt(), endAr = "كل عام وأنتم بخير", endEn = "Blessed Eid"),
        Template("GRAD", "تخرج", "Graduation", "🎓", "مبروك التخرج 🎓", "Congrats Graduate 🎓", listOf("CARD", "BOUNCE", "PLANE"), listOf("ZOOM", "SLIDE_UP"), listOf("ZOOM_IN"), listOf("CONFETTI"), "GOLD", "🎓 🏆", color = 0xFFFFD54F.toInt()),
        Template("BABY", "مولود جديد", "New baby", "👶", "أهلاً بالمولود الجديد 👶", "Welcome baby 👶", listOf("BALLOONS", "CIRCLE", "ANIMAL", "BIRDS"), listOf("FADE", "HEART"), listOf("ZOOM_IN"), listOf("BUBBLES", "STARS"), "KIDS", "🍼 👶", filter = "FADED", color = 0xFF448AFF.toInt()),
        Template("TRAVEL", "سفر وذكريات", "Travel memories", "✈️", "ذكريات لا تُنسى ✈️", "Unforgettable ✈️", listOf("FILM", "NORMAL", "PLANE", "CARD"), listOf("SLIDE_L", "PUSH_DOWN", "BLINDS"), listOf("PAN_L", "PAN_R", "ZOOM_IN"), emptyList(), "BOOK", "✈️", filter = "VIVID"),
        Template("CINEMA", "سينمائي", "Cinematic", "🎬", "قصتنا 🎬", "Our story 🎬", listOf("NORMAL", "TV", "NORMAL", "FILM"), listOf("BLACK", "FADE"), listOf("ZOOM_IN", "PAN_L", "ZOOM_OUT", "PAN_R"), listOf("LIGHTS"), "FILM", "", filter = "SEPIA"),
        Template("NEWYEAR", "رأس السنة", "New Year", "🎆", "سنة سعيدة 🎆", "Happy New Year 🎆", listOf("CARD", "PHONE", "BOUNCE"), listOf("WHITE", "SPIN"), listOf("ZOOM_IN"), listOf("FIREWORKS", "SPARKLES"), "NEON", "🎆 ✨", color = 0xFF18FFFF.toInt()),
        Template("MOTHER", "عيد الأم", "Mother's day", "🌷", "كل عام وأنتِ بخير يا أمي 🌷", "Happy Mother's Day 🌷", listOf("HEART", "CARD", "BIRDS"), listOf("FADE", "HEART"), listOf("ZOOM_IN"), listOf("PETALS"), "FLOWERS", "🌷 💐", filter = "WARM", color = 0xFFFF4081.toInt())
    )

    /** تطبيق قالب على الصور الحالية: ترتيب الحركات والانتقالات والنصوص والمؤثرات */
    fun applyTemplate(t: Template, secsEach: Int = 4) = update { p ->
        val clips = p.clips.filter { !it.isCard }.mapIndexed { i, c ->
            c.copy(style = if (c.video) "NORMAL" else t.styles[i % t.styles.size], transition = t.transitions[i % t.transitions.size],
                motion = t.motions[i % t.motions.size], durMs = if (c.video) c.durMs else secsEach * 1000L)
        }
        val total = clips.sumOf { it.durMs }.coerceAtLeast(3000)
        val ovs = mutableListOf<VOverlay>()
        if (t.frame.isNotBlank()) ovs += VOverlay(kind = "FRAME", key = t.frame, startMs = 0, durMs = total)
        t.fx.forEachIndexed { i, f -> ovs += VOverlay(kind = "FX", key = f, startMs = 0, durMs = if (i == 0) total else minOf(total, 5000)) }
        ovs += VOverlay(kind = "TEXT", text = tr(t.titleAr, t.titleEn), color = t.color, size = 0.1f, x = 0.5f, y = 0.5f, startMs = 0, durMs = minOf(total, 3500), anim = "POP", bg = false)
        if (t.endAr.isNotBlank()) ovs += VOverlay(kind = "TEXT", text = tr(t.endAr, t.endEn), color = t.color, size = 0.085f, x = 0.5f, y = 0.82f, startMs = (total - 3500).coerceAtLeast(0), durMs = minOf(total, 3500), anim = "TYPE")
        t.stickers.split(" ").filter { it.isNotBlank() }.forEachIndexed { i, e ->
            ovs += VOverlay(kind = "STICKER", key = e, size = 0.11f, x = if (i % 2 == 0) 0.1f else 0.9f, y = 0.14f, startMs = 0, durMs = total, anim = if (i % 2 == 0) "SWING" else "PULSE")
        }
        // نحتفظ بالشعار والنصوص التي أضافها المستخدم
        val keep = p.overlays.filter { it.kind == "LOGO" }
        p.copy(clips = clips, overlays = keep + ovs, filter = t.filter, template = t.key)
    }.also {
        // بداية ونهاية مناسبة للقالب
        val (intro, outro) = when (t.key) {
            "BIRTHDAY", "KIDS", "ANIMALS", "BABY", "GRAD" -> "I_PARTY" to "O_HEARTS"
            "LOVE", "MOTHER" -> "I_HEARTS" to "O_HEARTS"
            "WEDDING" -> "I_GOLD" to "O_GOLD"
            "RAMADAN" -> "I_STARS" to "O_GOLD"
            "EID", "NEWYEAR" -> "I_SPLASH" to "O_FIRE"
            "CINEMA" -> "I_COUNT" to "O_END"
            "TRAVEL" -> "I_BOOK" to "O_THANKS"
            else -> "I_CURTAIN" to "O_THANKS"
        }
        setCard("intro", intro, tr(t.titleAr, t.titleEn), "", t.color)
        setCard("outro", outro, if (t.endAr.isNotBlank()) tr(t.endAr, t.endEn) else null, null, t.color)
        // العنوان صار في المقدمة: نحذف نص العنوان المتكرر ونزيح باقي الطبقات بعد المقدمة
        update { p ->
            val introDur = p.clips.firstOrNull { it.kind == "intro" }?.durMs ?: 0L
            val total = p.totalMs
            p.copy(overlays = p.overlays.filterNot { it.kind == "TEXT" && it.anim == "POP" && it.startMs == 0L }.map { o ->
                when (o.kind) {
                    "FRAME", "FX", "STICKER" -> if (o.startMs == 0L) o.copy(startMs = introDur, durMs = (total - introDur).coerceAtLeast(1000)) else o
                    "TEXT" -> o.copy(startMs = (total - (p.clips.lastOrNull()?.takeIf { it.kind == "outro" }?.durMs ?: 0L) - o.durMs).coerceAtLeast(0))
                    else -> o
                }
            })
        }
    }
}
