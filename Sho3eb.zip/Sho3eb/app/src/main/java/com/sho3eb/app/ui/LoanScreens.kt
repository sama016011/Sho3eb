@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.data.Person
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WhatsGreen
import kotlinx.coroutines.launch
import java.time.LocalDate

// ============================ قائمة السلف ============================
@Composable
fun LoanListScreen(nav: NavController, openNew: Boolean) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val txs by flowState(emptyList<LoanTx>()) { dao.loanTxFlow() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val pmap = remember(people) { people.associateBy { it.id } }
    val summaries = remember(txs) { loanSummaries(txs) }
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(1) }
    var showPicker by remember { mutableStateOf(openNew) }
    var newFor by remember { mutableStateOf<Person?>(null) }
    val today = remember { LocalDate.now() }
    val back: () -> Unit = { nav.popBackStack() }

    ScreenScaffold(
        title = tr("السلف", "Loans"),
        onBack = if (openNew) back else null,
        fab = {
            ExtendedFloatingActionButton(
                onClick = { showPicker = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(tr("سلفة جديدة", "New loan")) }
            )
        }
    ) { pad ->
        val totalOut = summaries.sumOf { it.balance.coerceAtLeast(0.0) }
        val list = summaries.filter { s ->
            val p = pmap[s.personId]
            (q.isBlank() || (p?.name?.contains(q, true) == true) || (p?.phone?.contains(q) == true)) &&
                when (filter) {
                    1 -> s.balance > 0.005
                    2 -> s.balance <= 0.005
                    else -> true
                }
        }.sortedByDescending { it.balance }
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(Icons.Filled.Payments, MaterialTheme.colorScheme.secondary, 48.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(tr("إجمالي الديون المستحقة لك", "Total owed to you"), color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(Fmt.money(totalOut), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(
                                tr("${summaries.count { it.balance > 0.005 }} أشخاص عليهم سلف", "${summaries.count { it.balance > 0.005 }} people owe you"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }
            item { SearchField(q) { q = it } }
            item { FilterRow(listOf(tr("الكل", "All"), tr("عليهم دين", "Owing"), tr("مسددة", "Settled")), filter) { filter = it } }
            if (list.isEmpty()) item { EmptyState(Icons.Filled.Savings, tr("لا توجد سلف هنا", "No loans here")) }
            items(list, key = { it.personId }) { s ->
                val p = pmap[s.personId]
                val late = s.dueDate != null && s.balance > 0.005 && LocalDate.ofEpochDay(s.dueDate).isBefore(today)
                Card(onClick = { nav.navigate("loan/${s.personId}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p?.photoPath, p?.name ?: "?", 46.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p?.name ?: "-", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                tr("أخذ ${Fmt.money(s.taken)} • سدد ${Fmt.money(s.paid)}", "Took ${Fmt.money(s.taken)} • Paid ${Fmt.money(s.paid)}"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (s.dueDate != null && s.balance > 0.005) {
                                Text(
                                    tr("موعد السداد: ", "Due: ") + Fmt.date(s.dueDate),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (late) DangerRed else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                Fmt.money(s.balance), fontWeight = FontWeight.ExtraBold,
                                color = if (s.balance > 0.005) MaterialTheme.colorScheme.secondary else SuccessGreen
                            )
                            if (s.balance <= 0.005) StatusChip(tr("مسددة", "Settled"), SuccessGreen)
                            else if (late) StatusChip(tr("متأخر", "Late"), DangerRed)
                        }
                    }
                }
            }
        }
    }

    if (showPicker) PersonPickerDialog(multi = false, onDismiss = { showPicker = false }) { list ->
        showPicker = false
        newFor = list.firstOrNull()
    }
    newFor?.let { p ->
        val bal = loanBalance(txs.filter { it.personId == p.id })
        val pending = remember { mutableStateListOf<android.net.Uri>() }
        val post = remember { mutableStateOf(Posting.lastAccount("loan")) }
        AmountDialog(
            pending = pending,
            postTo = post,
            postLabel = tr("صرف مبلغ السلفة من حساب (اختياري)", "Withdraw from account (optional)"),
            title = tr("سلفة جديدة: ${p.name}", "New loan: ${p.name}"),
            info = if (bal > 0.005) tr(
                "يوجد دين سابق بقيمة ${Fmt.money(bal)} وسيُضاف المبلغ الجديد عليه.",
                "Existing debt of ${Fmt.money(bal)}; the new amount will be added to it."
            ) else null,
            showDue = true,
            onDismiss = { newFor = null }
        ) { amount, date, due, note ->
            scope.launch {
                val txId = dao.insertLoanTx(LoanTx(personId = p.id, type = LoanTx.LOAN, amount = amount, date = date, dueDate = due, note = note))
                Attachments.addAll(ctx, Attachments.LOAN_TX, txId, pending.toList())
                Posting.setLastAccount("loan", post.value)
                Posting.post(post.value, AccountTx.SRC_LOAN, txId, false, amount, date, tr("سلفة لـ ${p.name}", "Loan to ${p.name}") + if (note.isNotBlank()) " - $note" else "")
                toast(ctx, tr("تمت الإضافة. الرصيد الجديد: ${Fmt.money(bal + amount)}", "Added. New balance: ${Fmt.money(bal + amount)}"))
                newFor = null
                nav.navigate("loan/${p.id}") { if (openNew) popUpTo("loans_new") { inclusive = true } }
            }
        }
    }
}

// ============================ كشف حساب سلفة لشخص ============================
@Composable
fun LoanDetailScreen(nav: NavController, personId: Long) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val person by flowState<Person?>(null, personId) { dao.personFlow(personId) }
    val txs by flowState(emptyList<LoanTx>(), personId) { dao.loanTxForPersonFlow(personId) }
    var showLoan by remember { mutableStateOf(false) }
    var showPay by remember { mutableStateOf(false) }
    var deleteTx by remember { mutableStateOf<LoanTx?>(null) }
    var editNotes by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val linkedIds = rememberLinkedIds(AccountTx.SRC_LOAN)
    var postTx by remember { mutableStateOf<LoanTx?>(null) }

    val p = person
    if (p == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val taken = txs.filter { it.type == LoanTx.LOAN }.sumOf { it.amount }
    val paid = txs.filter { it.type == LoanTx.PAY }.sumOf { it.amount }
    val balance = round2(taken - paid)
    val due = txs.filter { it.type == LoanTx.LOAN }.mapNotNull { it.dueDate }.maxOrNull()

    // الرصيد التراكمي لكل حركة
    val running = remember(txs) {
        var b = 0.0
        txs.map { t -> b += if (t.type == LoanTx.LOAN) t.amount else -t.amount; t to round2(b) }.reversed()
    }

    ScreenScaffold(
        title = tr("سلف: ", "Loans: ") + p.name,
        onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(p.phone, doc = { Docs.loan(p, txs) }) { c -> Reports.loan(c, p, txs) }
            IconButton(onClick = { confirmClear = true }) { Icon(Icons.Filled.DeleteSweep, null) }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.photoPath, p.name, 56.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                if (p.phone.isNotBlank()) Text(p.phone, style = MaterialTheme.typography.bodySmall)
                            }
                            if (p.phone.isNotBlank()) {
                                IconButton(onClick = { Share.dial(ctx, p.phone) }) { Icon(Icons.Filled.Call, null) }
                                IconButton(onClick = {
                                    Share.whatsappMessage(ctx, p.phone, Messages.loan(p.name, balance, due?.let { Fmt.date(it) }))
                                }) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(tr("الرصيد المتبقي", "Outstanding balance"), color = MaterialTheme.colorScheme.onSecondaryContainer)
                        Text(
                            Fmt.money(balance), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                            color = if (balance > 0.005) MaterialTheme.colorScheme.onSecondaryContainer else SuccessGreen
                        )
                        KeyValue(tr("إجمالي السلف", "Total borrowed"), Fmt.money(taken))
                        KeyValue(tr("إجمالي المسدد", "Total repaid"), Fmt.money(paid), SuccessGreen)
                        if (due != null && balance > 0.005) KeyValue(tr("موعد السداد", "Due date"), Fmt.date(due))
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { showPay = true }, enabled = balance > 0.005, modifier = Modifier.weight(1f).height(48.dp)) {
                        Icon(Icons.Filled.Remove, null); Spacer(Modifier.width(6.dp)); Text(tr("تسديد دفعة", "Repayment"))
                    }
                    OutlinedButton(onClick = { showLoan = true }, modifier = Modifier.weight(1f).height(48.dp)) {
                        Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text(tr("سلفة إضافية", "Add loan"))
                    }
                }
            }
            item {
                OutlinedCard(onClick = { editNotes = true }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Description, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text(p.notes.ifBlank { tr("إضافة ملاحظات...", "Add notes...") }, modifier = Modifier.weight(1f))
                        Icon(Icons.Filled.Edit, null)
                    }
                }
            }
            item { SectionTitle(tr("سجل الحركات", "Transactions")) }
            if (running.isEmpty()) item { EmptyState(Icons.Filled.ReceiptLong, tr("لا توجد حركات", "No transactions")) }
            items(running, key = { it.first.id }) { (t, bal) ->
                val isLoan = t.type == LoanTx.LOAN
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconCircle(
                            if (isLoan) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
                            if (isLoan) MaterialTheme.colorScheme.secondary else SuccessGreen, 38.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (isLoan) tr("سلفة", "Loan") else tr("سداد", "Repayment")) + " • " + Fmt.money(t.amount),
                                fontWeight = FontWeight.Bold,
                                color = if (isLoan) MaterialTheme.colorScheme.onSurface else SuccessGreen
                            )
                            Text(
                                Fmt.date(t.date) + (t.dueDate?.let { " • " + tr("استحقاق ", "due ") + Fmt.date(it) } ?: ""),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (t.note.isNotBlank()) Text(t.note, style = MaterialTheme.typography.bodySmall)
                            Text(tr("الرصيد بعدها: ", "Balance after: ") + Fmt.money(bal), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                        PostButton(t.id in linkedIds) { postTx = t }
                        AttachmentButton(Attachments.LOAN_TX, t.id, p.phone)
                        IconButton(onClick = { deleteTx = t }) { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)) }
                    }
                }
            }
        }
    }

    val pendingLoan = remember(showLoan) { mutableStateListOf<android.net.Uri>() }
    val pendingPay = remember(showPay) { mutableStateListOf<android.net.Uri>() }
    val postLoan = remember(showLoan) { mutableStateOf(Posting.lastAccount("loan")) }
    val postPay = remember(showPay) { mutableStateOf(Posting.lastAccount("loanpay")) }
    if (showLoan) AmountDialog(
        title = tr("سلفة إضافية", "Additional loan"),
        pending = pendingLoan,
        postTo = postLoan,
        postLabel = tr("صرف المبلغ من حساب (اختياري)", "Withdraw from account (optional)"),
        info = if (balance > 0.005) tr("سيُضاف المبلغ على الدين الحالي (${Fmt.money(balance)})", "Will be added to the current debt (${Fmt.money(balance)})") else null,
        showDue = true,
        onDismiss = { showLoan = false }
    ) { amount, date, dueD, note ->
        scope.launch {
            val txId = dao.insertLoanTx(LoanTx(personId = p.id, type = LoanTx.LOAN, amount = amount, date = date, dueDate = dueD, note = note))
            Attachments.addAll(ctx, Attachments.LOAN_TX, txId, pendingLoan.toList())
            Posting.setLastAccount("loan", postLoan.value)
            Posting.post(postLoan.value, AccountTx.SRC_LOAN, txId, false, amount, date, tr("سلفة لـ ${p.name}", "Loan to ${p.name}") + if (note.isNotBlank()) " - $note" else "")
            showLoan = false
        }
    }
    if (showPay) AmountDialog(
        title = tr("تسديد دفعة", "Record repayment"),
        initial = balance,
        pending = pendingPay,
        postTo = postPay,
        postLabel = tr("إيداع السداد في حساب (اختياري)", "Deposit into account (optional)"),
        info = tr("الرصيد الحالي: ${Fmt.money(balance)}", "Current balance: ${Fmt.money(balance)}"),
        maxAmount = balance,
        onDismiss = { showPay = false }
    ) { amount, date, _, note ->
        scope.launch {
            val txId = dao.insertLoanTx(LoanTx(personId = p.id, type = LoanTx.PAY, amount = amount, date = date, note = note))
            Attachments.addAll(ctx, Attachments.LOAN_TX, txId, pendingPay.toList())
            Posting.setLastAccount("loanpay", postPay.value)
            Posting.post(postPay.value, AccountTx.SRC_LOAN, txId, true, amount, date, tr("سداد سلفة من ${p.name}", "Loan repayment from ${p.name}") + if (note.isNotBlank()) " - $note" else "")
            showPay = false
            val left = round2(balance - amount)
            toast(ctx, if (left <= 0.005) tr("تم سداد السلفة بالكامل 🎉", "Loan fully repaid 🎉") else tr("المتبقي: ${Fmt.money(left)}", "Remaining: ${Fmt.money(left)}"))
        }
    }
    deleteTx?.let { t ->
        ConfirmDialog(
            title = tr("حذف الحركة", "Delete transaction"),
            text = tr("حذف حركة بمبلغ ${Fmt.money(t.amount)}؟", "Delete transaction of ${Fmt.money(t.amount)}?"),
            confirmText = tr("حذف", "Delete"),
            onDismiss = { deleteTx = null }
        ) { scope.launch { Attachments.deleteFor(Attachments.LOAN_TX, t.id); dao.deleteLinkedTx(AccountTx.SRC_LOAN, t.id); dao.deleteLoanTx(t.id) } }
    }
    if (confirmClear) ConfirmDialog(
        title = tr("حذف كل السلف", "Delete all loans"),
        text = tr("حذف جميع حركات السلف الخاصة بـ ${p.name}؟", "Delete all loan transactions of ${p.name}?"),
        confirmText = tr("حذف", "Delete"),
        onDismiss = { confirmClear = false }
    ) { scope.launch { dao.deleteLinkedOfPersonLoans(p.id); dao.deleteLoansOf(p.id); nav.popBackStack() } }
    postTx?.let { t ->
        val isIn = t.type == LoanTx.PAY
        PostToAccountDialog(
            if (isIn) tr("ترحيل السداد إلى حساب", "Post repayment to account") else tr("ترحيل السلفة إلى حساب", "Post loan to account"),
            isIn, onDismiss = { postTx = null }
        ) { accId ->
            postTx = null
            scope.launch {
                Posting.post(
                    accId, AccountTx.SRC_LOAN, t.id, isIn, t.amount, t.date,
                    (if (isIn) tr("سداد سلفة من ${p.name}", "Loan repayment from ${p.name}") else tr("سلفة لـ ${p.name}", "Loan to ${p.name}")) + if (t.note.isNotBlank()) " - ${t.note}" else ""
                )
                toast(ctx, tr("تم الترحيل إلى الحساب ✅", "Posted to account ✅"))
            }
        }
    }
    if (editNotes) NotesDialog(p.notes, onDismiss = { editNotes = false }) { n ->
        scope.launch { dao.updatePerson(p.copy(notes = n)); editNotes = false }
    }
}

@Composable
fun NotesDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("ملاحظات", "Notes")) },
        text = { OutlinedTextField(text, { text = it }, minLines = 4, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onSave(text.trim()) }) { Text(tr("حفظ", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
