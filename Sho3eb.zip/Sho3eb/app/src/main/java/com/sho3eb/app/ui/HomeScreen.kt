@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.WhatsGreen
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun rememberAllData(): AllData {
    val dao = remember { appDao() }
    val people by flowState(emptyList<Person>()) { dao.peopleFlow() }
    val assocs by flowState(emptyList<Association>()) { dao.associationsFlow() }
    val members by flowState(emptyList<AssocMember>()) { dao.allMembersFlow() }
    val ap by flowState(emptyList<AssocPayment>()) { dao.allAssocPaymentsFlow() }
    val po by flowState(emptyList<AssocPayout>()) { dao.allPayoutsFlow() }
    val loans by flowState(emptyList<LoanTx>()) { dao.loanTxFlow() }
    val sales by flowState(emptyList<Sale>()) { dao.salesFlow() }
    val sp by flowState(emptyList<SalePayment>()) { dao.allSalePaymentsFlow() }
    return AllData(people, assocs, members, ap, po, loans, sales, sp)
}

@Composable
fun HomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val d = rememberAllData()
    val today = remember { LocalDate.now() }
    val due = remember(d) { computeDueItems(d, today, 30, false) }
    val loanOut = remember(d.loanTx) { loanSummaries(d.loanTx).sumOf { it.balance.coerceAtLeast(0.0) } }
    val salesRem = remember(d.sales, d.salePayments) {
        d.sales.sumOf { s -> saleRemaining(s, d.salePayments.filter { it.saleId == s.id }) }
    }
    val activeAssoc = remember(d) {
        d.associations.count { a ->
            val r = associationRounds(
                a, d.members.filter { it.associationId == a.id },
                d.assocPayments.filter { it.associationId == a.id }, d.payouts.filter { it.associationId == a.id }
            )
            !assocFinished(r)
        }
    }
    val overdue = due.count { it.due.isBefore(today) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item { HeaderCard(today) { nav.navigate("profile") } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(tr("جمعيات نشطة", "Active associations"), "$activeAssoc", Icons.Filled.Groups, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                StatCard(tr("مستحقات متأخرة", "Overdue items"), "$overdue", Icons.Filled.Warning, DangerRed, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(tr("ديون السلف", "Loans outstanding"), Fmt.money(loanOut), Icons.Filled.Payments, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                StatCard(tr("أقساط متبقية", "Installments left"), Fmt.money(salesRem), Icons.Filled.ShoppingCart, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction(tr("جمعية جديدة", "New association"), Icons.Filled.GroupAdd, Modifier.weight(1f)) { nav.navigate("assoc_edit/0") }
                QuickAction(tr("سلفة جديدة", "New loan"), Icons.Filled.Savings, Modifier.weight(1f)) { nav.navigate("loans_new") }
                QuickAction(tr("بيع بالتقسيط", "New sale"), Icons.Filled.AddShoppingCart, Modifier.weight(1f)) { nav.navigate("sale_edit/0") }
                QuickAction(tr("الحسابات", "Accounts"), Icons.Filled.AccountBalanceWallet, Modifier.weight(1f)) { nav.navigate("accounts") }
            }
        }
        item { SectionTitle(tr("المستحقات خلال 30 يوماً", "Due within 30 days")) }
        if (due.isEmpty()) {
            item { EmptyState(Icons.Filled.EventAvailable, tr("لا توجد مستحقات قريبة 👌", "Nothing due soon 👌")) }
        } else {
            items(due) { item ->
                DueCard(item, today, onWhatsApp = {
                    Share.whatsappMessage(ctx, item.phone, Messages.due(item))
                }) {
                    when (item.kind) {
                        DueKind.ASSOC -> nav.navigate("assoc/${item.refId}")
                        DueKind.LOAN -> nav.navigate("loan/${item.refId}")
                        DueKind.SALE -> nav.navigate("sale/${item.refId}")
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderCard(today: LocalDate, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val dateText = today.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", if (AppState.isAr) Locale("ar") else Locale.ENGLISH))
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(primary, tertiary))).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(AppState.photoPath.value, AppState.displayName.value, 56.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr("مرحباً 👋", "Welcome 👋"), color = Color.White.copy(alpha = 0.85f))
                    Text(
                        AppState.displayName.value.ifBlank { "Sho3eb" }, color = Color.White,
                        fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(dateText, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                }
                Text("Sho3eb", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            Spacer(Modifier.height(6.dp))
            Text(label, fontSize = 12.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 2)
        }
    }
}

@Composable
fun DueCard(item: DueItem, today: LocalDate, onWhatsApp: () -> Unit, onClick: () -> Unit) {
    val (icon, color) = when (item.kind) {
        DueKind.ASSOC -> Icons.Filled.Groups to MaterialTheme.colorScheme.primary
        DueKind.LOAN -> Icons.Filled.Payments to MaterialTheme.colorScheme.secondary
        DueKind.SALE -> Icons.Filled.ShoppingCart to MaterialTheme.colorScheme.tertiary
    }
    val late = item.due.isBefore(today)
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconCircle(icon, color)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(Fmt.date(item.due), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (late) {
                        Spacer(Modifier.width(6.dp)); StatusChip(tr("متأخر", "Late"), DangerRed)
                    } else if (item.due == today) {
                        Spacer(Modifier.width(6.dp)); StatusChip(tr("اليوم", "Today"), MaterialTheme.colorScheme.secondary)
                    }
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.money(item.amount), fontWeight = FontWeight.Bold, color = if (late) DangerRed else MaterialTheme.colorScheme.onSurface)
                if (item.phone.isNotBlank()) {
                    IconButton(onClick = onWhatsApp, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Chat, null, tint = WhatsGreen) }
                }
            }
        }
    }
}
