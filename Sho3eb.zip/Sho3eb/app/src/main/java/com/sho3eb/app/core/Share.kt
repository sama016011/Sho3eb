package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object Share {
    private val waPackages = listOf("com.whatsapp", "com.whatsapp.w4b")

    /** تحويل الرقم لصيغة دولية بدون + (مثال 9665xxxxxxxx) */
    fun waNumber(phone: String): String {
        var d = Contacts.cleanPhone(phone).removePrefix("+")
        val cc = appPrefs().countryCode.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        else if (d.startsWith("0")) d = cc + d.drop(1)
        else if (d.length <= 9 && cc.isNotEmpty() && !d.startsWith(cc)) d = cc + d
        return d
    }

    private fun installed(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) {
        false
    }

    fun sharePdf(ctx: Context, file: File, phone: String?, viaWhatsApp: Boolean) =
        shareFile(ctx, file, "application/pdf", phone, viaWhatsApp)

    fun uriFor(ctx: Context, file: File) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)

    fun shareFile(ctx: Context, file: File, mime: String, phone: String?, viaWhatsApp: Boolean) {
        val uri = uriFor(ctx, file)
        val base = Intent(Intent.ACTION_SEND).apply {
            type = mime.ifBlank { "*/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (viaWhatsApp) {
            val pkg = waPackages.firstOrNull { installed(ctx, it) }
            if (pkg != null) {
                val wa = Intent(base).setPackage(pkg)
                if (!phone.isNullOrBlank()) wa.putExtra("jid", waNumber(phone) + "@s.whatsapp.net")
                try {
                    ctx.startActivity(wa); return
                } catch (_: Exception) {
                    try {
                        ctx.startActivity(Intent(base).setPackage(pkg)); return
                    } catch (_: Exception) {
                    }
                }
            } else {
                toast(ctx, tr("واتساب غير مثبت، اختر تطبيقاً آخر", "WhatsApp is not installed, choose another app"))
            }
        }
        ctx.startActivity(Intent.createChooser(base, tr("مشاركة التقرير", "Share report")))
    }

    fun whatsappMessage(ctx: Context, phone: String, msg: String) {
        if (phone.isBlank()) {
            toast(ctx, tr("لا يوجد رقم هاتف لهذا الشخص", "No phone number for this person")); return
        }
        val url = "https://wa.me/${waNumber(phone)}?text=" + Uri.encode(msg)
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast(ctx, tr("تعذر فتح واتساب", "Could not open WhatsApp"))
        }
    }

    fun openUrl(ctx: Context, url: String) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { toast(ctx, tr("لا يوجد تطبيق لفتح الرابط", "No app to open the link")) }
    }

    fun shareText(ctx: Context, text: String) {
        try { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("text", text))
        toast(ctx, tr("تم النسخ", "Copied"))
    }

    fun dial(ctx: Context, phone: String) {
        if (phone.isBlank()) return
        try {
            ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
        } catch (_: Exception) {
        }
    }
}
