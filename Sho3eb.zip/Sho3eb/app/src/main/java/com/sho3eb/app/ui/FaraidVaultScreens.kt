@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.core.Faraid.H
import com.sho3eb.app.data.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch
import java.util.Locale

// =====================================================================
//                       حاسبة المواريث
// =====================================================================
@Composable
fun FaraidScreen(nav: NavController) {
    val ctx = LocalContext.current
    var male by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var gross by rememberSaveable { mutableStateOf("") }
    var funeral by rememberSaveable { mutableStateOf("") }
    var debts by rememberSaveable { mutableStateOf("") }
    var will by rememberSaveable { mutableStateOf("") }
    var gfMode by rememberSaveable { mutableIntStateOf(0) }
    var showMore by rememberSaveable { mutableStateOf(false) }
    val counts = remember { mutableStateMapOf<H, Int>() }

    fun n(h: H) = counts[h] ?: 0
    val effective = counts.filterKeys { if (male) it != H.HUSBAND else it != H.WIFE }
    val r = remember(effective.toMap(), gfMode) { Faraid.solve(effective, gfMode) }
    val e = Faraid.Estate(Fmt.parse(gross) ?: 0.0, Fmt.parse(funeral) ?: 0.0, Fmt.parse(debts) ?: 0.0, Fmt.parse(will) ?: 0.0)
    val doc = { Docs.faraid(r, e, name, male) }

    val main = listOf(
        tr("الزوجية", "Spouse") to listOf(if (male) H.WIFE else H.HUSBAND),
        tr("الفروع", "Descendants") to listOf(H.SON, H.DAUGHTER, H.SON_SON, H.SON_DAUGHTER),
        tr("الأصول", "Ascendants") to listOf(H.FATHER, H.MOTHER, H.GRANDFATHER, H.GM_MOTHER, H.GM_FATHER),
        tr("الإخوة والأخوات", "Siblings") to listOf(H.FULL_BRO, H.FULL_SIS, H.PAT_BRO, H.PAT_SIS, H.MAT_BRO, H.MAT_SIS)
    )
    val more = tr("الحواشي البعيدة", "Distant male relatives") to listOf(H.FULL_NEPHEW, H.PAT_NEPHEW, H.FULL_UNCLE, H.PAT_UNCLE, H.FULL_COUSIN, H.PAT_COUSIN)

    ScreenScaffold(
        title = tr("حاسبة المواريث", "Inheritance calculator"), onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(null, doc = doc) { c -> Reports.doc(c, doc()) }
            IconButton(onClick = { counts.clear() }) { Icon(Icons.Filled.RestartAlt, null) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 60.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                InfoBanner(tr(
                    "قال ﷺ: «ألحقوا الفرائض بأهلها، فما بقي فلأولى رجل ذكر». تُقسم التركة بعد تجهيز الميت وسداد ديونه وتنفيذ وصيته في حدود الثلث لغير وارث. الحاسبة على قول جمهور العلماء.",
                    "Estate is divided after funeral costs, debts and a bequest (max 1/3, not to an heir). Based on the majority view."
                ))
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(name, { name = it }, label = { Text(tr("اسم المتوفى (اختياري)", "Deceased name (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(male, { male = true }, label = { Text(tr("المتوفى ذكر", "Deceased: male")) })
                            FilterChip(!male, { male = false }, label = { Text(tr("المتوفاة أنثى", "Deceased: female")) })
                        }
                        MoneyField(gross, { gross = it }, tr("إجمالي التركة", "Gross estate"))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MoneyField(funeral, { funeral = it }, tr("تجهيز ودفن", "Funeral"), Modifier.weight(1f))
                            MoneyField(debts, { debts = it }, tr("الديون", "Debts"), Modifier.weight(1f))
                        }
                        MoneyField(will, { will = it }, tr("الوصية لغير وارث", "Bequest (non-heir)"))
                        if (e.willExceeded) Text(tr("الوصية تزيد عن الثلث، فتُنفّذ في حدود الثلث فقط إلا بإجازة الورثة.", "Bequest exceeds 1/3; capped unless heirs consent."), color = WarnAmber, style = MaterialTheme.typography.bodySmall)
                        if (e.gross > 0) KeyValue(tr("الصافي للورثة", "Net for heirs"), Fmt.money(e.net), MaterialTheme.colorScheme.primary)
                    }
                }
            }
            main.forEach { (title, list) ->
                item { SectionTitle(title) }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) { list.forEach { h -> HeirRow(h, n(h)) { counts[h] = it } } }
                    }
                }
            }
            item {
                TextButton(onClick = { showMore = !showMore }) {
                    Icon(if (showMore) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null)
                    Text(more.first + tr(" (أبناء الإخوة والأعمام وأبناؤهم)", " (nephews, uncles, cousins)"))
                }
            }
            if (showMore) item {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) { more.second.forEach { h -> HeirRow(h, n(h)) { counts[h] = it } } } }
            }
            if (n(H.GRANDFATHER) > 0 && n(H.FATHER) == 0 && (n(H.FULL_BRO) + n(H.FULL_SIS) + n(H.PAT_BRO) + n(H.PAT_SIS)) > 0) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(tr("الجد مع الإخوة (مسألة خلافية)", "Grandfather with siblings (disputed)"), fontWeight = FontWeight.Bold)
                        FilterChip(gfMode == 0, { gfMode = 0 }, label = { Text(tr("الجمهور: يقاسم الإخوة (مالك والشافعي وأحمد)", "Majority: shares with siblings")) })
                        FilterChip(gfMode == 1, { gfMode = 1 }, label = { Text(tr("الجد كالأب يحجب الإخوة (أبو حنيفة، واختاره ابن تيمية)", "Grandfather excludes siblings (Hanafi)")) })
                    }
                }
            }

            // ---------- النتيجة ----------
            val heirs = r.shares.filter { it.blockedBy == null }
            if (heirs.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionTitle(tr("النتيجة", "Result"), Modifier.weight(1f))
                        StatusChip(tr("أصل المسألة ", "Base ") + r.asl + (if (r.awl) tr(" • عول", " • ‘awl") else "") + (if (r.radd) tr(" • رد", " • radd") else ""), MaterialTheme.colorScheme.primary)
                    }
                }
                items(heirs, key = { "r${it.h}" }) { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(s.h.label + if (s.count > 1) " × ${s.count}" else "", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(s.share.toString(), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Text(s.basis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(tr("السهام: ", "Parts: ") + "${r.sihaam(s)} / ${r.asl}" + "  •  " + String.format(Locale.US, "%.2f%%", s.share.v * 100), style = MaterialTheme.typography.bodySmall)
                            if (e.net > 0) {
                                KeyValue(tr("نصيبهم", "Group amount"), Fmt.money(e.net * s.share.v), SuccessGreen)
                                if (s.count > 1) KeyValue(tr("لكل فرد", "Each"), Fmt.money(e.net * s.each.v))
                            }
                        }
                    }
                }
                val blocked = r.shares.filter { it.blockedBy != null }
                if (blocked.isNotEmpty()) {
                    item { SectionTitle(tr("المحجوبون", "Excluded")) }
                    items(blocked, key = { "b${it.h}" }) { s ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                            Text("• " + s.h.label, Modifier.weight(1f), color = MaterialTheme.colorScheme.outline)
                            Text(tr("محجوب بـ ", "by ") + s.blockedBy, style = MaterialTheme.typography.bodySmall, color = DangerRed)
                        }
                    }
                }
                r.notes.forEach { nt -> item { Text("ℹ️ $nt", style = MaterialTheme.typography.bodySmall, color = WarnAmber) } }
                item {
                    OutlinedButton(onClick = {
                        val sb = StringBuilder(tr("تقسيم تركة ", "Estate of ") + name + "\n")
                        if (e.net > 0) sb.append(tr("الصافي: ", "Net: ")).append(Fmt.money(e.net)).append('\n')
                        heirs.forEach { s -> sb.append("• ").append(s.h.label).append(if (s.count > 1) " ×${s.count}" else "").append(": ").append(s.share).append(if (e.net > 0) " = " + Fmt.money(e.net * s.share.v) else "").append('\n') }
                        shareText(ctx, sb.toString())
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(6.dp)); Text(tr("مشاركة النتيجة نصياً", "Share as text")) }
                }
                item { Text(tr("أداة مساعدة؛ للحالات الخاصة والنزاع يُرجع إلى المحكمة الشرعية أو أهل العلم.", "A helper tool; consult a court or scholar for special cases."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else item { EmptyState(Icons.Filled.FamilyRestroom, tr("حدد الورثة الأحياء وقت الوفاة لعرض الأنصبة", "Select living heirs to see the shares")) }
        }
    }
}

@Composable
private fun HeirRow(h: H, v: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(h.label, Modifier.weight(1f), fontWeight = if (v > 0) FontWeight.Bold else FontWeight.Normal)
        IconButton(onClick = { if (v > 0) onChange(v - 1) }, enabled = v > 0) { Icon(Icons.Filled.RemoveCircleOutline, null) }
        Text("$v", Modifier.widthIn(min = 24.dp), fontWeight = FontWeight.Bold, color = if (v > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
        IconButton(onClick = { if (v < h.max) onChange(v + 1) }, enabled = v < h.max) { Icon(Icons.Filled.AddCircleOutline, null) }
    }
}

// =====================================================================
//                        خزنة المستندات
// =====================================================================
@Composable
fun VaultScreen(nav: NavController) {
    val dao = remember { appDao() }
    val docs by flowState(emptyList<VaultDoc>()) { dao.vaultDocsFlow() }
    var q by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("ALL") }
    var add by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<VaultDoc?>(null) }
    val expired = docs.count { Vault.isExpired(it) }
    val soon = docs.count { Vault.isSoon(it) }
    val list = docs.filter {
        (filter == "ALL" || (filter == "SOON" && (Vault.isSoon(it) || Vault.isExpired(it))) || it.type == filter) &&
            (q.isBlank() || it.title.contains(q, true) || it.holder.contains(q, true) || it.number.contains(q, true) || it.notes.contains(q, true))
    }

    ScreenScaffold(
        title = tr("خزنة المستندات", "Documents vault"), onBack = { nav.popBackStack() },
        actions = { PdfShareButton(null, doc = { Docs.vault(docs) }) { c -> Reports.doc(c, Docs.vault(docs)) } },
        fab = { ExtendedFloatingActionButton(onClick = { add = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text(tr("مستند", "Document")) }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("المستندات", "Documents"), "${docs.size}", Icons.Filled.FolderShared, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatCard(tr("تنتهي قريباً", "Expiring"), "$soon", Icons.Filled.Schedule, WarnAmber, Modifier.weight(1f))
                    StatCard(tr("منتهية", "Expired"), "$expired", Icons.Filled.ErrorOutline, DangerRed, Modifier.weight(1f))
                }
            }
            item { SearchField(q) { q = it } }
            item {
                HChips {
                    FilterChip(filter == "ALL", { filter = "ALL" }, label = { Text(tr("الكل", "All")) })
                    FilterChip(filter == "SOON", { filter = "SOON" }, label = { Text(tr("تحتاج تجديد", "Need renewal")) })
                    Vault.types.filter { t -> docs.any { it.type == t.key } }.forEach { t -> FilterChip(filter == t.key, { filter = t.key }, label = { Text(t.emoji + " " + t.label) }) }
                }
            }
            if (docs.isEmpty()) item {
                InfoBanner(tr("احفظ صور الهوية والجواز والإقامة والرخص والتأمين وضمانات الأجهزة والعقود في مكان واحد، وسيذكّرك التطبيق قبل انتهاء كل مستند. الصور تُحفظ داخل جوالك فقط.",
                    "Keep IDs, passports, licenses, insurance, warranties and contracts in one place with expiry reminders. Photos stay on your phone."))
            }
            items(list, key = { it.id }) { d ->
                val t = Vault.type(d.type)
                val color = when { Vault.isExpired(d) -> DangerRed; Vault.isSoon(d) -> WarnAmber; d.expiryDate != null -> SuccessGreen; else -> MaterialTheme.colorScheme.outline }
                Card(onClick = { edit = d }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.emoji, fontSize = 28.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.title, fontWeight = FontWeight.Bold)
                            Text(listOf(t.label, d.holder).filter { it.isNotBlank() }.joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                            Text(Vault.status(d), style = MaterialTheme.typography.bodySmall, color = color, fontWeight = FontWeight.SemiBold)
                        }
                        AttachmentButton(Attachments.VAULT, d.id)
                    }
                }
            }
        }
    }
    if (add) VaultDialog(null) { add = false }
    edit?.let { d -> VaultDialog(d) { edit = null } }
}

@Composable
private fun VaultDialog(existing: VaultDoc?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var type by remember { mutableStateOf(existing?.type ?: "ID") }
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var number by remember { mutableStateOf(existing?.number ?: "") }
    var holder by remember { mutableStateOf(existing?.holder ?: "") }
    var issuer by remember { mutableStateOf(existing?.issuer ?: "") }
    var issue by remember { mutableStateOf(existing?.issueDate) }
    var expiry by remember { mutableStateOf(existing?.expiryDate) }
    var remind by remember { mutableIntStateOf(existing?.remindDays ?: 30) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    val pending = remember { mutableStateListOf<Uri>() }
    var del by remember { mutableStateOf(false) }
    var renew by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(existing?.title ?: tr("مستند جديد", "New document")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HChips { Vault.types.forEach { t -> FilterChip(type == t.key, { type = t.key }, label = { Text(t.emoji + " " + t.label) }) } }
                OutlinedTextField(title, { title = it }, label = { Text(tr("اسم المستند", "Title")) }, placeholder = { Text(Vault.type(type).label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(holder, { holder = it }, label = { Text(tr("صاحب المستند (أنا، الزوجة، الابن...)", "Holder")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(number, { number = it }, label = { Text(tr("رقم المستند (اختياري)", "Number (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(issuer, { issuer = it }, label = { Text(tr("جهة الإصدار / المتجر (اختياري)", "Issuer / store (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                DateField(tr("تاريخ الإصدار", "Issue date"), issue, { issue = it }, allowClear = true)
                DateField(tr("تاريخ الانتهاء", "Expiry date"), expiry, { expiry = it }, allowClear = true)
                if (expiry != null) {
                    Text(tr("التذكير قبل الانتهاء:", "Remind before expiry:"), style = MaterialTheme.typography.labelLarge)
                    HChips { listOf(7, 30, 60, 90).forEach { d -> FilterChip(remind == d, { remind = d }, label = { Text(tr("$d يوم", "$d days")) }) } }
                }
                NotesField(notes) { notes = it }
                if (existing == null) PendingAttachRow(pending)
                else {
                    AttachmentButton(Attachments.VAULT, existing.id)
                    Row {
                        TextButton(onClick = { renew = true }) { Icon(Icons.Filled.Autorenew, null); Spacer(Modifier.width(4.dp)); Text(tr("تم التجديد", "Renewed")) }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { del = true }) { Text(tr("حذف", "Delete"), color = DangerRed) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val d = VaultDoc(title = title.trim().ifBlank { Vault.type(type).label }, type = type, number = number.trim(), holder = holder.trim(), issuer = issuer.trim(),
                    issueDate = issue, expiryDate = expiry, remindDays = remind, notes = notes.trim())
                scope.launch {
                    if (existing == null) {
                        val id = dao.insertVaultDoc(d)
                        Attachments.addAll(ctx, Attachments.VAULT, id, pending.toList())
                    } else dao.updateVaultDoc(d.copy(id = existing.id, createdAt = existing.createdAt))
                    onDismiss()
                }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
    if (renew && existing != null) {
        var years by remember { mutableIntStateOf(Vault.defaultYears(existing.type)) }
        AlertDialog(
            onDismissRequest = { renew = false },
            title = { Text(tr("تجديد المستند", "Renew document")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("مدة التجديد:", "Renewal period:"))
                    HChips { listOf(1, 2, 3, 5, 10).forEach { y -> FilterChip(years == y, { years = y }, label = { Text(tr("$y سنة", "$y yr")) }) } }
                    Text(tr("الانتهاء الجديد: ", "New expiry: ") + Fmt.date(Vault.renew(existing, years).expiryDate!!), color = MaterialTheme.colorScheme.primary)
                    Text(tr("لا تنسَ إضافة صورة المستند الجديد.", "Remember to attach the new copy."), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { scope.launch { dao.updateVaultDoc(Vault.renew(existing, years)); renew = false; onDismiss() } }) { Text(tr("تجديد", "Renew")) } },
            dismissButton = { TextButton(onClick = { renew = false }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
    if (del && existing != null) ConfirmDialog(tr("حذف المستند", "Delete document"), tr("حذف «${existing.title}» وصوره؟", "Delete with its photos?"), onDismiss = { del = false }) {
        scope.launch { Attachments.deleteFor(Attachments.VAULT, existing.id); dao.deleteVaultDoc(existing.id); del = false; onDismiss() }
    }
}
