package com.sho3eb.app.core

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * مصمم الغرف والشقق والأراضي: توليد مخطط تلقائي بقواعد التصميم الداخلي + تكلفة تقريبية بالجنيه المصري.
 * كل الأبعاد بالسنتيمتر. المحور x على عرض الغرفة، y على طولها. الجدران: 0 أعلى، 1 يمين، 2 أسفل، 3 يسار.
 */
object Design {

    // ======================= النماذج =======================
    data class Item(val key: String, val name: String, val x: Double, val y: Double, val w: Double, val d: Double, val h: Double, val color: Long, val price: Double, val flat: Boolean = false) {
        fun overlaps(o: Item, gap: Double = 0.0) = x < o.x + o.w + gap && o.x < x + w + gap && y < o.y + o.d + gap && o.y < y + d + gap
        val area get() = w * d
    }
    data class Opening(val wall: Int, val pos: Double, val width: Double)  // pos = نسبة المركز على الجدار 0..1
    data class Room(
        val type: String, val w: Double, val l: Double, val h: Double = 290.0, val door: Opening = Opening(2, 0.2, 90.0), val window: Opening? = Opening(0, 0.5, 140.0),
        val style: String = "MODERN", val tier: Int = 1, val factor: Double = 1.0, val excluded: Set<String> = emptySet()
    )
    data class Result(val items: List<Item>, val warnings: List<String>, val furniture: Double, val finishing: Double, val lines: List<Pair<String, Double>>) {
        val total get() = furniture + finishing
    }

    val roomTypes = listOf(
        Opt("MASTER", "غرفة نوم رئيسية", "Master bedroom", "🛏️"), Opt("BEDROOM", "غرفة نوم", "Bedroom", "🛌"), Opt("KIDS", "غرفة أطفال", "Kids room", "🧸"),
        Opt("LIVING", "ليفنج / معيشة", "Living room", "🛋️"), Opt("MAJLIS", "مجلس / صالون", "Majlis / salon", "🪑"), Opt("DINING", "سفرة", "Dining room", "🍽️"),
        Opt("OFFICE", "مكتب", "Office", "💼"), Opt("KITCHEN", "مطبخ", "Kitchen", "🍳"), Opt("BATH", "حمام", "Bathroom", "🚿")
    )
    fun roomType(k: String) = roomTypes.firstOrNull { it.key == k } ?: roomTypes.first()
    val styles = listOf(
        Opt("MODERN", "مودرن", "Modern", "⬜"), Opt("CLASSIC", "كلاسيك", "Classic", "👑"), Opt("NEO", "نيو كلاسيك", "Neo-classic", "🏛️"),
        Opt("BOHO", "بوهو / طبيعي", "Boho / natural", "🌿"), Opt("GULF", "خليجي / شرقي", "Gulf / oriental", "🕌")
    )
    val tiers = listOf(Opt("0", "اقتصادي", "Economy", "💵"), Opt("1", "متوسط", "Mid-range", "💰"), Opt("2", "فاخر", "Premium", "💎"))
    private val tierMul = doubleArrayOf(0.6, 1.0, 2.1)

    /** ألوان كل ستايل: خشب، قماش، معدن/إكسسوار */
    private fun palette(style: String): Triple<Long, Long, Long> = when (style) {
        "CLASSIC" -> Triple(0xFF6B4226, 0xFFC9A66B, 0xFFB8860B)
        "NEO" -> Triple(0xFFEDE6DA, 0xFF9E9E9E, 0xFFC5A253)
        "BOHO" -> Triple(0xFFB08968, 0xFFE6CCB2, 0xFF7F9172)
        "GULF" -> Triple(0xFF8D5524, 0xFF8E1F2F, 0xFFD4AF37)
        else -> Triple(0xFFD7CCC8, 0xFF607D8B, 0xFF37474F)
    }
    private val styleMul = mapOf("CLASSIC" to 1.35, "NEO" to 1.2, "BOHO" to 0.95, "GULF" to 1.15)

    // أسعار متوسطة تقريبية بالجنيه المصري (قابلة للتعديل بمعامل الأسعار)
    private val basePrice = mapOf(
        "bed_k" to 26000.0, "bed_q" to 21000.0, "bed_s" to 9500.0, "bunk" to 18000.0, "night" to 3800.0, "wardrobe" to 32000.0, "wardrobe_s" to 19000.0,
        "dresser" to 13000.0, "rug" to 6500.0, "rug_s" to 3000.0, "armchair" to 9500.0, "sofa3" to 30000.0, "sofa2" to 21000.0, "coffee" to 5500.0, "tv" to 9500.0,
        "side" to 2800.0, "shelf" to 6500.0, "table6" to 17000.0, "table4" to 11000.0, "chair" to 3200.0, "buffet" to 15000.0, "desk" to 8000.0, "ochair" to 5000.0,
        "cabinet" to 6000.0, "counter_m" to 13000.0, "fridge" to 32000.0, "stove" to 16000.0, "sink_k" to 6000.0, "toilet" to 6500.0, "basin" to 5000.0,
        "shower" to 14000.0, "tub" to 17000.0, "toys" to 4000.0, "majlis_m" to 9000.0, "plant" to 1500.0, "ktable" to 7000.0
    )
    private fun price(key: String, r: Room) = (basePrice[key] ?: 0.0) * tierMul[r.tier.coerceIn(0, 2)] * (styleMul[r.style] ?: 1.0) * r.factor

    // ======================= محرك التوزيع =======================
    private class Ctx(val r: Room) {
        val items = mutableListOf<Item>()
        val warns = mutableListOf<String>()
        val pal = palette(r.style)
        val doorZone: Item = doorRect(r)
        fun free(it: Item): Boolean =
            it.x >= -0.1 && it.y >= -0.1 && it.x + it.w <= r.w + 0.1 && it.y + it.d <= r.l + 0.1 &&
                (it.flat || !it.overlaps(doorZone)) && items.none { o -> !o.flat && !it.flat && it.overlaps(o) }
        fun add(it: Item): Boolean { if (it.key in r.excluded) return false; if (!free(it)) return false; items += it; return true }
        fun wallLen(w: Int) = if (w % 2 == 0) r.w else r.l
        /** قطعة ملاصقة لجدار؛ a على طول الجدار، b العمق */
        fun onWall(key: String, name: String, wall: Int, t: Double, a: Double, b: Double, h: Double, color: Long, pk: String, flat: Boolean = false): Item {
            val c = t * wallLen(wall)
            return when (wall) {
                0 -> Item(key, name, c - a / 2, 0.0, a, b, h, color, price(pk, r), flat)
                2 -> Item(key, name, c - a / 2, r.l - b, a, b, h, color, price(pk, r), flat)
                3 -> Item(key, name, 0.0, c - a / 2, b, a, h, color, price(pk, r), flat)
                else -> Item(key, name, r.w - b, c - a / 2, b, a, h, color, price(pk, r), flat)
            }
        }
        fun tryWalls(key: String, name: String, walls: List<Int>, a: Double, b: Double, h: Double, color: Long, pk: String, ts: List<Double> = listOf(0.5, 0.25, 0.75, 0.15, 0.85, 0.35, 0.65)): Item? {
            for (w in walls) for (t in ts) {
                val it = onWall(key, name, w, t, a, b, h, color, pk)
                if (add(it)) return it
            }
            return null
        }
        fun center(key: String, name: String, cx: Double, cy: Double, w: Double, d: Double, h: Double, color: Long, pk: String, flat: Boolean = false): Item? {
            val it = Item(key, name, cx - w / 2, cy - d / 2, w, d, h, color, price(pk, r), flat)
            return if (add(it)) it else null
        }
    }

    private fun doorRect(r: Room): Item {
        val d = r.door; val c = d.pos * (if (d.wall % 2 == 0) r.w else r.l); val s = d.width + 10
        return when (d.wall) {
            0 -> Item("door", "", c - s / 2, 0.0, s, s, 0.0, 0, 0.0)
            2 -> Item("door", "", c - s / 2, r.l - s, s, s, 0.0, 0, 0.0)
            3 -> Item("door", "", 0.0, c - s / 2, s, s, 0.0, 0, 0.0)
            else -> Item("door", "", r.w - s, c - s / 2, s, s, 0.0, 0, 0.0)
        }
    }

    private fun opposite(w: Int) = (w + 2) % 4
    /** ترتيب الجدران: الجدار الرئيسي (مقابل الباب أو الأطول بلا باب) أولاً */
    private fun wallsOrder(r: Room): List<Int> {
        val opp = opposite(r.door.wall)
        val others = (0..3).filter { it != r.door.wall && it != opp }.sortedByDescending { if (it % 2 == 0) r.w else r.l }
        return listOf(opp) + others + r.door.wall
    }

    fun generate(r: Room): Result {
        val c = Ctx(r)
        val (wood, fabric, accent) = c.pal
        val order = wallsOrder(r)
        when (r.type) {
            "MASTER", "BEDROOM" -> {
                val beds = if (r.type == "MASTER") listOf(Triple("bed_k", 180.0, tr("سرير كينج 180×200", "King bed 180×200")), Triple("bed_q", 160.0, tr("سرير 160×200", "Queen bed 160×200")), Triple("bed_s", 120.0, tr("سرير 120×200", "Bed 120×200")))
                    else listOf(Triple("bed_q", 160.0, tr("سرير 160×200", "Queen bed 160×200")), Triple("bed_s", 120.0, tr("سرير 120×200", "Bed 120×200")), Triple("bed_s", 100.0, tr("سرير فردي 100×190", "Single bed 100×190")))
                var bed: Item? = null; var bedWall = order.first()
                loop@ for ((pk, bw, name) in beds) for (w in order.take(3)) {
                    val it = c.onWall("bed", name, w, 0.5, bw, if (bw < 110) 190.0 else 205.0, 55.0, fabric, pk)
                    if (c.add(it)) { bed = it; bedWall = w; break@loop }
                }
                if (bed == null) c.warns += tr("الغرفة صغيرة على سرير مناسب", "Room too small for a bed")
                bed?.let { b ->
                    // كوميدينو على الجانبين
                    val along = bedWall % 2 == 0
                    for (side in listOf(-1, 1)) {
                        val n = if (along) Item("night", tr("كوميدينو", "Nightstand"), if (side < 0) b.x - 52 else b.x + b.w + 2, b.y + (if (bedWall == 2) b.d - 42 else 0.0), 50.0, 42.0, 55.0, wood, price("night", r))
                        else Item("night", tr("كوميدينو", "Nightstand"), b.x + (if (bedWall == 1) b.w - 42 else 0.0), if (side < 0) b.y - 52 else b.y + b.d + 2, 42.0, 50.0, 55.0, wood, price("night", r))
                        c.add(n)
                    }
                    // سجادة تحت السرير
                    val rw = if (along) b.w + 100 else b.w + 70; val rd = if (along) b.d * 0.65 + 60 else b.d + 100
                    val rx = b.x + b.w / 2 - rw / 2; val ry = if (along) (if (bedWall == 0) b.y + b.d * 0.35 else b.y - 60) else b.y + b.d / 2 - rd / 2
                    if ("rug" !in r.excluded) c.items += Item("rug", tr("سجادة", "Rug"), max(0.0, rx), max(0.0, ry), min(rw, r.w), min(rd, r.l), 1.0, accent, price("rug", r), true)
                }
                c.tryWalls("wardrobe", tr("دولاب 4 ضلف", "Wardrobe 200 cm"), order.drop(1), 200.0, 62.0, 240.0, wood, "wardrobe")
                    ?: c.tryWalls("wardrobe", tr("دولاب 3 ضلف", "Wardrobe 150 cm"), order, 150.0, 60.0, 230.0, wood, "wardrobe_s")
                    ?: c.warns.add(tr("لا توجد مساحة لدولاب؛ فكّر في دولاب حائط مدمج", "No space for a wardrobe; consider built-in"))
                if (r.type == "MASTER") c.tryWalls("dresser", tr("تسريحة بمرآة", "Dresser with mirror"), order, 120.0, 45.0, 80.0, wood, "dresser")
                if (r.w * r.l > 160000) c.tryWalls("armchair", tr("كرسي قراءة", "Reading chair"), order.drop(1), 75.0, 75.0, 85.0, fabric, "armchair", listOf(0.1, 0.9))
                c.tryWalls("plant", tr("نبات زينة", "Plant"), order, 40.0, 40.0, 120.0, 0xFF4CAF50, "plant", listOf(0.06, 0.94))
            }
            "KIDS" -> {
                val bunk = c.tryWalls("bunk", tr("سرير دورين 100×200", "Bunk bed"), order, 205.0, 105.0, 170.0, accent, "bunk")
                if (bunk == null) {
                    c.tryWalls("bed1", tr("سرير فردي", "Single bed"), order, 195.0, 100.0, 50.0, fabric, "bed_s")
                    c.tryWalls("bed2", tr("سرير فردي ثانٍ", "Second bed"), order.drop(1), 195.0, 100.0, 50.0, fabric, "bed_s")
                }
                val desk = c.tryWalls("desk", tr("مكتب مذاكرة", "Study desk"), order.drop(1), 120.0, 60.0, 75.0, wood, "desk")
                desk?.let { d -> c.add(Item("ochair", tr("كرسي مكتب", "Desk chair"), d.x + d.w / 2 - 22 + (if (d.w < d.d) (if (d.x < 1) d.w + 5 else -50.0) else 0.0), d.y + d.d / 2 - 22 + (if (d.w >= d.d) (if (d.y < 1) d.d + 5 else -50.0) else 0.0), 45.0, 45.0, 85.0, fabric, price("ochair", r))) }
                c.tryWalls("wardrobe", tr("دولاب", "Wardrobe"), order, 150.0, 60.0, 220.0, wood, "wardrobe_s")
                c.tryWalls("toys", tr("وحدة ألعاب وتخزين", "Toy storage"), order, 100.0, 40.0, 90.0, accent, "toys")
                if ("rug" !in r.excluded) c.items += Item("rug", tr("سجادة لعب", "Play rug"), r.w / 2 - 75, r.l / 2 - 50, 150.0, 100.0, 1.0, 0xFF90CAF9, price("rug_s", r), true)
            }
            "LIVING", "MAJLIS" -> {
                val sofaWall = order.first()
                val tvWall = opposite(sofaWall)
                val majlis = r.type == "MAJLIS"
                val sofa = if (majlis) null else c.tryWalls("sofa", tr("كنبة 3 مقاعد", "3-seat sofa"), listOf(sofaWall) + order.drop(1), 220.0, 90.0, 85.0, fabric, "sofa3")
                    ?: c.tryWalls("sofa", tr("كنبة مقعدين", "2-seat sofa"), order, 160.0, 85.0, 85.0, fabric, "sofa2")
                if (majlis) {
                    // جلسة على 3 جدران
                    var n = 0
                    for (w in order.take(3)) {
                        val len = c.wallLen(w) - 40
                        val segs = ((len - 20) / 200).toInt().coerceIn(0, 3)
                        for (i in 0 until segs) { val t = (20 + 100 + i * 200.0) / c.wallLen(w); if (c.add(c.onWall("majlis$w$i", tr("جلسة عربية / كنبة", "Majlis seating"), w, t, 195.0, 80.0, 75.0, fabric, "sofa2"))) n++ }
                    }
                    if (n == 0) c.warns += tr("المساحة لا تكفي جلسة على الجدران", "Not enough wall length for seating")
                    c.center("coffee", tr("طاولة وسط", "Center table"), r.w / 2, r.l / 2, 120.0, 70.0, 42.0, wood, "coffee")
                    c.center("side1", tr("طاولة ضيافة", "Serving table"), r.w / 2, r.l / 2 + 90, 60.0, 45.0, 50.0, accent, "side")
                } else {
                    c.tryWalls("tv", tr("وحدة تلفزيون", "TV unit"), listOf(tvWall) + order.drop(1), 180.0, 45.0, 55.0, wood, "tv")
                    sofa?.let { s ->
                        val horiz = s.w > s.d
                        val cx = s.x + s.w / 2; val cy = s.y + s.d / 2
                        val off = 45 + 30.0
                        val (tx, ty) = if (horiz) cx to (if (s.y < 1) s.y + s.d + off else s.y - off) else (if (s.x < 1) s.x + s.w + off else s.x - off) to cy
                        c.center("coffee", tr("طاولة قهوة", "Coffee table"), tx, ty, if (horiz) 120.0 else 60.0, if (horiz) 60.0 else 120.0, 42.0, wood, "coffee")
                        // كرسيان جانبيان
                        for (sd in listOf(-1, 1)) {
                            val ax = if (horiz) cx + sd * (s.w / 2 + 60) else tx + 0.0
                            val ay = if (horiz) ty + 0.0 else cy + sd * (s.d / 2 + 60)
                            c.center("armchair", tr("كرسي فوتيه", "Armchair"), ax, ay, 80.0, 80.0, 85.0, accent, "armchair")
                        }
                        c.center("side", tr("طاولة جانبية", "Side table"), if (horiz) s.x - 30 else cx, if (horiz) cy else s.y - 30, 45.0, 45.0, 55.0, wood, "side")
                        if ("rug" !in r.excluded) c.items += Item("rug", tr("سجادة", "Rug"), max(0.0, tx - 150), max(0.0, ty - 100), min(300.0, r.w), min(200.0, r.l), 1.0, accent, price("rug", r), true)
                    }
                    c.tryWalls("shelf", tr("مكتبة / رفوف", "Bookshelf"), order.drop(1), 100.0, 35.0, 200.0, wood, "shelf")
                }
                c.tryWalls("plant", tr("نبات زينة", "Plant"), order, 40.0, 40.0, 130.0, 0xFF4CAF50, "plant", listOf(0.06, 0.94))
            }
            "DINING" -> {
                val big = r.w >= 330 && r.l >= 300
                val tw = if (big) 180.0 else 120.0; val td = if (big) 95.0 else 80.0
                val horiz = r.w >= r.l
                val t = c.center("table", if (big) tr("سفرة 6 كراسي", "6-seat table") else tr("سفرة 4 كراسي", "4-seat table"), r.w / 2, r.l / 2, if (horiz) tw else td, if (horiz) td else tw, 76.0, wood, if (big) "table6" else "table4")
                t?.let { tb ->
                    val per = if (big) 2 else 1
                    for (i in 0 until per) {
                        val f = (i + 1.0) / (per + 1)
                        if (horiz) { c.add(Item("chair", tr("كرسي", "Chair"), tb.x + tb.w * f - 22, tb.y - 50, 45.0, 45.0, 95.0, fabric, price("chair", r))); c.add(Item("chair", tr("كرسي", "Chair"), tb.x + tb.w * f - 22, tb.y + tb.d + 5, 45.0, 45.0, 95.0, fabric, price("chair", r))) }
                        else { c.add(Item("chair", tr("كرسي", "Chair"), tb.x - 50, tb.y + tb.d * f - 22, 45.0, 45.0, 95.0, fabric, price("chair", r))); c.add(Item("chair", tr("كرسي", "Chair"), tb.x + tb.w + 5, tb.y + tb.d * f - 22, 45.0, 45.0, 95.0, fabric, price("chair", r))) }
                    }
                    if (horiz) { c.add(Item("chair", tr("كرسي", "Chair"), tb.x - 50, tb.y + tb.d / 2 - 22, 45.0, 45.0, 95.0, fabric, price("chair", r))); c.add(Item("chair", tr("كرسي", "Chair"), tb.x + tb.w + 5, tb.y + tb.d / 2 - 22, 45.0, 45.0, 95.0, fabric, price("chair", r))) }
                    else { c.add(Item("chair", tr("كرسي", "Chair"), tb.x + tb.w / 2 - 22, tb.y - 50, 45.0, 45.0, 95.0, fabric, price("chair", r))); c.add(Item("chair", tr("كرسي", "Chair"), tb.x + tb.w / 2 - 22, tb.y + tb.d + 5, 45.0, 45.0, 95.0, fabric, price("chair", r))) }
                } ?: c.warns.add(tr("المساحة صغيرة على سفرة؛ جرّب طاولة دائرية 90 سم", "Too small; try a 90 cm round table"))
                c.tryWalls("buffet", tr("بوفيه", "Buffet"), order, 160.0, 45.0, 85.0, wood, "buffet")
            }
            "OFFICE" -> {
                val desk = c.tryWalls("desk", tr("مكتب 140 سم", "Desk 140 cm"), order.drop(1) + order.first(), 140.0, 70.0, 75.0, wood, "desk")
                desk?.let { d -> val horiz = d.w > d.d; c.center("ochair", tr("كرسي مكتب", "Office chair"), d.x + d.w / 2 + (if (!horiz) (if (d.x < 1) d.w / 2 + 35 else -d.w / 2 - 35) else 0.0), d.y + d.d / 2 + (if (horiz) (if (d.y < 1) d.d / 2 + 35 else -d.d / 2 - 35) else 0.0), 55.0, 55.0, 110.0, fabric, "ochair") }
                c.tryWalls("shelf", tr("مكتبة", "Bookshelf"), order, 100.0, 35.0, 200.0, wood, "shelf")
                c.tryWalls("shelf2", tr("مكتبة ثانية", "Bookshelf 2"), order, 100.0, 35.0, 200.0, wood, "shelf")
                c.tryWalls("cabinet", tr("خزانة ملفات", "File cabinet"), order, 60.0, 45.0, 100.0, accent, "cabinet")
                if (r.w * r.l > 120000) c.tryWalls("sofa", tr("كنبة استقبال", "Guest sofa"), order, 150.0, 80.0, 80.0, fabric, "sofa2")
            }
            "KITCHEN" -> {
                // دواليب على جدارين أو ثلاثة (عمق 60)
                var meters = 0.0
                val runs = if (r.w >= 240 && r.l >= 240) order.take(3) else order.take(2)
                for (w in runs) {
                    val len = c.wallLen(w) - (if (w == r.door.wall) r.door.width + 20 else 0.0) - 20
                    if (len < 60) continue
                    val it = c.onWall("counter$w", tr("دواليب ورخامة", "Cabinets & counter"), w, 0.5, len.coerceAtMost(c.wallLen(w) - 2), 60.0, 90.0, wood, "counter_m")
                    var placed = c.add(it)
                    if (!placed) placed = c.add(c.onWall("counter$w", tr("دواليب ورخامة", "Cabinets & counter"), w, 0.3, len * 0.55, 60.0, 90.0, wood, "counter_m")).also { if (it) meters += len * 0.55 / 100 }
                    else meters += len / 100
                }
                // تصحيح سعر الدواليب حسب الأمتار
                c.items.replaceAll { if (it.key.startsWith("counter")) it.copy(price = price("counter_m", r) * (max(it.w, it.d) / 100.0)) else it }
                c.tryWalls("fridge", tr("ثلاجة", "Fridge"), order, 75.0, 72.0, 185.0, 0xFFE0E0E0, "fridge", listOf(0.05, 0.95, 0.1, 0.9))
                if (r.w >= 300 && r.l >= 300) c.center("ktable", tr("طاولة مطبخ / جزيرة", "Kitchen table / island"), r.w / 2, r.l / 2, 110.0, 70.0, 90.0, accent, "ktable")
                if (meters < 2.4) c.warns += tr("أمتار الرخامة قليلة؛ فكر في دولاب علوي إضافي", "Short counter; add wall cabinets")
            }
            "BATH" -> {
                val big = r.w >= 200 && r.l >= 240
                if (big) c.tryWalls("tub", tr("بانيو", "Bathtub"), order, 170.0, 75.0, 55.0, 0xFFFFFFFF, "tub")
                else c.tryWalls("shower", tr("كابينة شاور", "Shower cabin"), order, 90.0, 90.0, 200.0, 0xFFB3E5FC, "shower", listOf(0.08, 0.92, 0.5))
                c.tryWalls("toilet", tr("قاعدة (تواليت)", "Toilet"), order.drop(1) + order.first(), 40.0, 70.0, 75.0, 0xFFFFFFFF, "toilet", listOf(0.2, 0.8, 0.5))
                c.tryWalls("basin", tr("حوض بوحدة", "Vanity sink"), order, 70.0, 48.0, 85.0, wood, "basin")
            }
        }
        // التشطيبات
        val area = r.w * r.l / 10000.0
        val wallArea = 2 * (r.w + r.l) / 100.0 * r.h / 100.0 - 2.0
        val m = tierMul[r.tier.coerceIn(0, 2)] * r.factor
        val lines = mutableListOf<Pair<String, Double>>()
        val floorRate = if (r.type == "BATH" || r.type == "KITCHEN") 750.0 else 650.0
        lines += tr("أرضيات (بورسلين/باركيه) ", "Flooring ") + Fmt.num(area) + tr(" م²", " m²") to area * floorRate * m
        lines += tr("دهانات حوائط وسقف ", "Paint walls & ceiling ") + Fmt.num(wallArea + area) + tr(" م²", " m²") to (wallArea + area) * 180.0 * m
        if (r.type == "BATH" || r.type == "KITCHEN") lines += tr("سيراميك حوائط", "Wall tiles") to wallArea * 0.7 * 700.0 * m
        lines += tr("إضاءة ونجف وسبوتات", "Lighting") to (2500.0 + area * 450.0) * m
        if (r.window != null && r.type != "BATH") lines += tr("ستائر", "Curtains") to (r.window.width / 100.0 * 2200.0 + 1500.0) * m
        if (r.style == "CLASSIC" || r.style == "NEO") lines += tr("جبس بورد وكرانيش", "Gypsum ceiling & moldings") to area * 900.0 * m
        val fin = lines.sumOf { it.second }
        val fur = c.items.sumOf { it.price }
        return Result(c.items, c.warns, fur, fin, lines)
    }

    // ======================= تخطيط الشقة =======================
    data class Space(val key: String, val name: String, val x: Double, val y: Double, val w: Double, val d: Double, val color: Long) { val area get() = w * d / 10000.0 }
    data class Apartment(val w: Double, val l: Double, val bedrooms: Int, val baths: Int, val openKitchen: Boolean, val balcony: Boolean, val tier: Int = 1, val factor: Double = 1.0, val finishRate: Double = 0.0)
    data class AptResult(val spaces: List<Space>, val warnings: List<String>, val finishing: Double, val furniture: Double, val lines: List<Pair<String, Double>>) { val total get() = finishing + furniture }

    /** سعر تشطيب المتر بالجنيه (تقريبي): اقتصادي / متوسط / سوبر لوكس */
    val finishRates = doubleArrayOf(4500.0, 7500.0, 13000.0)

    fun apartment(a: Apartment): AptResult {
        val sp = mutableListOf<Space>(); val warn = mutableListOf<String>()
        val W = a.w; val L = a.l
        val nb = a.bedrooms.coerceIn(1, 5); val nbath = a.baths.coerceIn(1, 4)
        val corridor = 110.0
        val pubD = (L * 0.42).coerceIn(350.0, 650.0).coerceAtMost(L - corridor - 280)
        val privY = pubD + corridor
        val privD = L - privY
        if (privD < 280) warn += tr("العمق صغير؛ الغرف ستكون ضيقة", "Depth is small; rooms will be tight")
        // المنطقة الأمامية
        var x0 = 0.0
        if (a.balcony) { val bw = min(W * 0.45, 400.0); sp += Space("balcony", tr("بلكونة", "Balcony"), 0.0, 0.0, bw, 140.0, 0xFFB2DFDB) }
        val bY = if (a.balcony) 140.0 else 0.0
        val kitW = (W * 0.28).coerceIn(220.0, 380.0)
        val guestBath = nbath >= 2
        val gbW = if (guestBath) 170.0 else 0.0
        val livW = W - kitW - gbW
        if (a.openKitchen) {
            sp += Space("living", tr("ريسبشن (معيشة + سفرة)", "Reception (living + dining)"), 0.0, bY, livW + kitW * 0.25, pubD - bY, 0xFFFFE0B2)
            sp += Space("kitchen", tr("مطبخ مفتوح", "Open kitchen"), livW + kitW * 0.25, 0.0, kitW * 0.75, pubD, 0xFFFFF59D)
        } else {
            sp += Space("living", tr("ريسبشن (معيشة + سفرة)", "Reception (living + dining)"), 0.0, bY, livW, pubD - bY, 0xFFFFE0B2)
            sp += Space("kitchen", tr("مطبخ", "Kitchen"), livW, 0.0, kitW, pubD, 0xFFFFF59D)
        }
        if (guestBath) sp += Space("gbath", tr("حمام ضيوف", "Guest bath"), W - gbW, 0.0, gbW, min(pubD, 220.0), 0xFFB3E5FC)
        sp += Space("corridor", tr("طرقة", "Corridor"), 0.0, pubD, W, corridor, 0xFFEEEEEE)
        // المنطقة الخلفية: حمامات + غرف
        val privBaths = nbath - (if (guestBath) 1 else 0)
        val bathW = 200.0
        val bedTotal = W - privBaths * bathW
        val shares = (0 until nb).map { if (it == 0 && nb > 1) 1.35 else 1.0 }
        val sum = shares.sum()
        x0 = 0.0
        for (i in 0 until nb) {
            val bw = bedTotal * shares[i] / sum
            if (bw < 270) warn += tr("عرض غرفة ${i + 1} أقل من 2.7 م", "Bedroom ${i + 1} narrower than 2.7 m")
            sp += Space(if (i == 0) "master" else "bed$i", if (i == 0 && nb > 1) tr("غرفة نوم رئيسية", "Master bedroom") else tr("غرفة نوم ${i + 1}", "Bedroom ${i + 1}"), x0, privY, bw, privD, if (i == 0) 0xFFC5CAE9 else 0xFFD1C4E9)
            x0 += bw
            if (i == 0 && privBaths >= 2) { sp += Space("mbath", tr("حمام ماستر", "Master bath"), x0, privY, bathW, min(privD, 260.0), 0xFFB3E5FC); x0 += bathW }
        }
        val remainingBaths = privBaths - (if (privBaths >= 2) 1 else 0)
        for (j in 0 until remainingBaths) { sp += Space("bath$j", tr("حمام", "Bathroom"), x0, privY, bathW, min(privD, 260.0), 0xFFB3E5FC); x0 += bathW }
        // التكلفة
        val area = W * L / 10000.0
        val rate = if (a.finishRate > 0) a.finishRate else finishRates[a.tier.coerceIn(0, 2)]
        val fin = area * rate * a.factor
        val lines = mutableListOf(tr("تشطيب ", "Finishing ") + Fmt.num(area) + tr(" م² × ", " m² × ") + Fmt.num(rate) to fin)
        var furn = 0.0
        for (s in sp) {
            val type = when { s.key.startsWith("master") -> "MASTER"; s.key.startsWith("bed") -> "BEDROOM"; s.key == "living" -> "LIVING"; s.key == "kitchen" -> "KITCHEN"; s.key.contains("bath") -> "BATH"; else -> null } ?: continue
            val res = generate(Room(type, s.w, s.d, door = Opening(if (s.y >= pubD) 0 else 2, 0.15, 90.0), window = Opening(if (s.y >= pubD) 2 else 0, 0.5, 140.0), tier = a.tier, factor = a.factor))
            furn += res.furniture
            lines += tr("فرش ", "Furnish ") + s.name to res.furniture
        }
        return AptResult(sp, warn, fin, furn, lines)
    }

    // ======================= الأرض والمبنى =======================
    data class Land(val w: Double, val l: Double, val floors: Int, val front: Double = 3.0, val back: Double = 2.0, val side: Double = 0.0, val coverage: Double = 0.7, val aptArea: Double = 120.0, val ground: String = "APTS", val skeletonRate: Double = 0.0, val finishRate: Double = 0.0, val tier: Int = 1)
    data class LandResult(val footW: Double, val footL: Double, val footArea: Double, val bua: Double, val aptsPerFloor: Int, val totalApts: Int, val skeleton: Double, val finishing: Double, val extra: Double, val lines: List<Pair<String, Double>>, val warnings: List<String>) {
        val total get() = skeleton + finishing + extra
    }
    /** تكلفة المتر "عظم" تقريبية بالجنيه */
    const val skeletonDefault = 6500.0

    fun land(d: Land): LandResult {
        val warn = mutableListOf<String>()
        val W = d.w / 100.0; val L = d.l / 100.0   // الأبعاد مخزنة بالسنتيمتر، والحساب بالمتر
        var fw = W - 2 * d.side
        var fl = L - d.front - d.back
        if (fw <= 0 || fl <= 0) { warn += tr("الردود أكبر من الأرض", "Setbacks exceed the plot"); fw = max(fw, 1.0); fl = max(fl, 1.0) }
        val maxArea = W * L * d.coverage
        if (fw * fl > maxArea) { val k = maxArea / (fw * fl); fl *= k; warn += tr("تم تقليل المسطح ليطابق نسبة البناء ${(d.coverage * 100).roundToInt()}%", "Footprint reduced to ${(d.coverage * 100).roundToInt()}% coverage") }
        val foot = fw * fl
        val circulation = 18.0 // سلم ومصعد ومنور تقريبي
        val apts = max(1, ((foot - circulation) / d.aptArea).toInt())
        val residentialFloors = if (d.ground == "APTS") d.floors else d.floors - 1
        val totalApts = apts * residentialFloors.coerceAtLeast(0)
        val bua = foot * d.floors
        val sk = bua * (if (d.skeletonRate > 0) d.skeletonRate else skeletonDefault)
        val finRate = if (d.finishRate > 0) d.finishRate else finishRates[d.tier.coerceIn(0, 2)]
        val fin = bua * finRate
        val extra = (if (d.floors >= 5) 1_400_000.0 else 0.0) + bua * 450.0 // مصعد + مرافق وعدادات وتراخيص تقريبية
        val lines = listOf(
            tr("هيكل خرساني (عظم) ", "Concrete shell ") + Fmt.num(bua) + tr(" م²", " m²") to sk,
            tr("تشطيبات", "Finishing") to fin,
            (if (d.floors >= 5) tr("مصعد + ", "Elevator + ") else "") + tr("مرافق وتراخيص وعدادات (تقريبي)", "Utilities, permits, meters (approx.)") to extra
        )
        if (d.floors > 12) warn += tr("الارتفاع كبير؛ تحقق من اشتراطات الحي والكود", "Check local height limits")
        if (d.aptArea < 60) warn += tr("مساحة الشقة صغيرة جداً", "Apartment size is very small")
        return LandResult(fw, fl, foot, bua, apts, totalApts, sk, fin, extra, lines, warn)
    }

    // ======================= الحفظ =======================
    fun roomJson(r: Room) = JSONObject().apply {
        put("type", r.type); put("w", r.w); put("l", r.l); put("h", r.h); put("style", r.style); put("tier", r.tier); put("factor", r.factor)
        put("dw", r.door.wall); put("dp", r.door.pos); put("dwi", r.door.width)
        r.window?.let { put("ww", it.wall); put("wp", it.pos); put("wwi", it.width) }
        put("ex", JSONArray(r.excluded.toList()))
    }.toString()
    fun roomFrom(s: String): Room? = runCatching {
        val o = JSONObject(s)
        Room(o.getString("type"), o.getDouble("w"), o.getDouble("l"), o.optDouble("h", 290.0), Opening(o.getInt("dw"), o.getDouble("dp"), o.optDouble("dwi", 90.0)),
            if (o.has("ww")) Opening(o.getInt("ww"), o.getDouble("wp"), o.optDouble("wwi", 140.0)) else null, o.optString("style", "MODERN"), o.optInt("tier", 1), o.optDouble("factor", 1.0),
            o.optJSONArray("ex")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: emptySet())
    }.getOrNull()
    fun aptJson(a: Apartment) = JSONObject().apply { put("w", a.w); put("l", a.l); put("b", a.bedrooms); put("ba", a.baths); put("ok", a.openKitchen); put("bal", a.balcony); put("tier", a.tier); put("factor", a.factor); put("fr", a.finishRate) }.toString()
    fun aptFrom(s: String): Apartment? = runCatching { val o = JSONObject(s); Apartment(o.getDouble("w"), o.getDouble("l"), o.getInt("b"), o.getInt("ba"), o.getBoolean("ok"), o.getBoolean("bal"), o.optInt("tier", 1), o.optDouble("factor", 1.0), o.optDouble("fr", 0.0)) }.getOrNull()
    fun landJson(d: Land) = JSONObject().apply { put("w", d.w); put("l", d.l); put("f", d.floors); put("fr", d.front); put("bk", d.back); put("sd", d.side); put("cv", d.coverage); put("aa", d.aptArea); put("g", d.ground); put("sr", d.skeletonRate); put("fn", d.finishRate); put("tier", d.tier) }.toString()
    fun landFrom(s: String): Land? = runCatching { val o = JSONObject(s); Land(o.getDouble("w"), o.getDouble("l"), o.getInt("f"), o.optDouble("fr", 3.0), o.optDouble("bk", 2.0), o.optDouble("sd", 0.0), o.optDouble("cv", 0.7), o.optDouble("aa", 120.0), o.optString("g", "APTS"), o.optDouble("sr", 0.0), o.optDouble("fn", 0.0), o.optInt("tier", 1)) }.getOrNull()
}
