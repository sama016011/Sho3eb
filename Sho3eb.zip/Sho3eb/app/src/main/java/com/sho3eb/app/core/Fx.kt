package com.sho3eb.app.core

import com.sho3eb.app.islam.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** العملة الرئيسية + العملات الأجنبية + ما يملكه المستخدم من عملات بأسعار محدثة */
object Fx {
    data class Holding(val id: Long, val code: String, val amount: Double, val buyRate: Double, val note: String, val date: Long) {
        fun json() = JSONObject().put("id", id).put("code", code).put("amount", amount).put("buyRate", buyRate).put("note", note).put("date", date)
    }

    val symbols = mapOf(
        "USD" to "$", "EUR" to "€", "GBP" to "£", "SAR" to "ر.س", "AED" to "د.إ", "KWD" to "د.ك", "QAR" to "ر.ق", "BHD" to "د.ب", "OMR" to "ر.ع",
        "EGP" to "ج.م", "JOD" to "د.أ", "IQD" to "د.ع", "MAD" to "د.م", "DZD" to "د.ج", "TND" to "د.ت", "LYD" to "د.ل", "TRY" to "₺", "INR" to "₹",
        "PKR" to "Rs", "CHF" to "CHF", "CAD" to "C$", "AUD" to "A$", "MYR" to "RM", "IDR" to "Rp", "JPY" to "¥", "CNY" to "¥"
    )
    val flags = mapOf(
        "USD" to "🇺🇸", "EUR" to "🇪🇺", "GBP" to "🇬🇧", "SAR" to "🇸🇦", "AED" to "🇦🇪", "KWD" to "🇰🇼", "QAR" to "🇶🇦", "BHD" to "🇧🇭", "OMR" to "🇴🇲",
        "EGP" to "🇪🇬", "JOD" to "🇯🇴", "IQD" to "🇮🇶", "MAD" to "🇲🇦", "DZD" to "🇩🇿", "TND" to "🇹🇳", "LYD" to "🇱🇾", "TRY" to "🇹🇷", "INR" to "🇮🇳",
        "PKR" to "🇵🇰", "CHF" to "🇨🇭", "CAD" to "🇨🇦", "AUD" to "🇦🇺", "MYR" to "🇲🇾", "IDR" to "🇮🇩", "YER" to "🇾🇪", "SDG" to "🇸🇩", "LBP" to "🇱🇧",
        "SYP" to "🇸🇾", "BDT" to "🇧🇩", "NGN" to "🇳🇬", "JPY" to "🇯🇵", "CNY" to "🇨🇳"
    )
    val allCodes: List<String> get() = (Metals.currencies.map { it.code } + listOf("JPY", "CNY")).distinct()
    fun label(code: String) = when (code) { "JPY" -> tr("ين ياباني", "Japanese yen"); "CNY" -> tr("يوان صيني", "Chinese yuan"); else -> Metals.cur(code).label }
    fun flag(code: String) = flags[code] ?: "💱"

    /** العملة الرئيسية (رمز ISO) */
    var main: String
        get() = Metals.currency
        set(v) { Metals.currency = v; Metals.updatedAt = 0 }

    /** العملات الأجنبية المتابعة */
    var watched: List<String>
        get() = Extras.s("fx_watch", "USD,EUR,SAR,GBP").split(",").filter { it.isNotBlank() }
        set(v) = Extras.ps("fx_watch", v.distinct().joinToString(","))

    var auto: Boolean get() = Extras.b("fx_auto", true); set(v) = Extras.pb("fx_auto", v)
    var updatedAt: Long get() = Extras.l("fx_upd", 0L); set(v) = Extras.pl("fx_upd", v)

    private var usdRates: JSONObject?
        get() = runCatching { JSONObject(Extras.s("fx_rates", "")) }.getOrNull()
        set(v) = Extras.ps("fx_rates", v?.toString() ?: "")
    private var prevRates: JSONObject?
        get() = runCatching { JSONObject(Extras.s("fx_prev", "")) }.getOrNull()
        set(v) = Extras.ps("fx_prev", v?.toString() ?: "")

    /** أسعار يدوية (عند تفضيل سعر السوق المحلي) : قيمة الوحدة بالعملة الرئيسية */
    fun manual(code: String): Double = Extras.d("fx_man_$code", 0.0)
    fun setManual(code: String, v: Double) = Extras.pd("fx_man_$code", v)

    private fun usdPer(code: String, j: JSONObject?): Double? = when {
        code == "USD" -> 1.0
        j == null -> null
        else -> j.optDouble(code).takeIf { !it.isNaN() && it > 0 } ?: j.optDouble(code.lowercase()).takeIf { !it.isNaN() && it > 0 }
    }

    /** قيمة وحدة واحدة من العملة بالعملة الرئيسية */
    fun rate(code: String, base: String = main): Double? {
        if (code == base) return 1.0
        if (base == main) manual(code).takeIf { it > 0 }?.let { return it }
        val j = usdRates
        val a = usdPer(code, j) ?: return null
        val b = usdPer(base, j) ?: return null
        return b / a
    }

    /** اتجاه التغير منذ آخر تحديث: 1 صعود، -1 هبوط */
    fun trend(code: String): Int {
        if (manual(code) > 0) return 0
        val p = prevRates ?: return 0
        val now = rate(code) ?: return 0
        val a = usdPer(code, p) ?: return 0
        val b = usdPer(main, p) ?: return 0
        val old = b / a
        return when { now > old * 1.0001 -> 1; now < old * 0.9999 -> -1; else -> 0 }
    }

    fun convert(amount: Double, from: String, to: String): Double? {
        val r1 = rate(from, "USD") ?: return null
        val r2 = rate(to, "USD") ?: return null
        return amount * r1 / r2
    }

    suspend fun refresh(force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (!force && System.currentTimeMillis() - updatedAt < 60_000 && usdRates != null) return@withContext true
        val j = runCatching { JSONObject(Net.get("https://open.er-api.com/v6/latest/USD", 15000)).getJSONObject("rates") }.getOrNull()
            ?: runCatching {
                val u = JSONObject(Net.get("https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json", 15000)).getJSONObject("usd")
                val o = JSONObject(); u.keys().forEach { k -> o.put(k.uppercase(), u.optDouble(k)) }; o
            }.getOrNull()
        if (j == null) return@withContext false
        usdRates?.let { old -> if (old.toString() != j.toString()) prevRates = old }
        usdRates = j
        updatedAt = System.currentTimeMillis()
        true
    }

    // ---------- الحيازات ----------
    var holdings: List<Holding>
        get() = runCatching {
            val a = JSONArray(Extras.s("fx_hold", "[]"))
            (0 until a.length()).map { i -> a.getJSONObject(i).let { o -> Holding(o.optLong("id"), o.optString("code"), o.optDouble("amount", 0.0), o.optDouble("buyRate", 0.0), o.optString("note"), o.optLong("date")) } }
        }.getOrDefault(emptyList())
        set(v) = Extras.ps("fx_hold", JSONArray().apply { v.forEach { put(it.json()) } }.toString())

    fun upsert(h: Holding) { holdings = holdings.filter { it.id != h.id } + h }
    fun delete(id: Long) { holdings = holdings.filter { it.id != id } }

    fun value(h: Holding): Double? = rate(h.code)?.let { it * h.amount }
    /** سعر شراء الوحدة الفعلي (يصحح الإدخالات القديمة التي كُتب فيها المبلغ الإجمالي بدلاً من سعر الوحدة) */
    fun unitBuy(h: Holding): Double {
        if (h.buyRate <= 0) return 0.0
        val r = rate(h.code)
        return if (h.amount > 1 && r != null && r > 0 && h.buyRate > r * 15) h.buyRate / h.amount else h.buyRate
    }
    /** إجمالي ما دُفع */
    fun cost(h: Holding): Double = unitBuy(h) * h.amount
    /** الربح (+) أو الخسارة (-) بفارق العملة */
    fun profit(h: Holding): Double? = if (h.buyRate <= 0) null else value(h)?.let { it - cost(h) }
    fun totalValue(): Double = holdings.sumOf { value(it) ?: 0.0 }
    fun totalCost(): Double = holdings.filter { it.buyRate > 0 }.sumOf { cost(it) }

    /** تجميع حسب العملة */
    fun byCurrency(): List<Pair<String, Double>> = holdings.groupBy { it.code }.map { it.key to it.value.sumOf { h -> h.amount } }.sortedByDescending { (c, a) -> (rate(c) ?: 0.0) * a }

    fun agoText(): String {
        if (updatedAt <= 0) return tr("لم يُحدَّث بعد", "Not updated yet")
        val sec = (System.currentTimeMillis() - updatedAt) / 1000
        return when {
            sec < 60 -> tr("الآن", "just now")
            sec < 3600 -> tr("منذ ${sec / 60} د", "${sec / 60} min ago")
            sec < 86400 -> tr("منذ ${sec / 3600} س", "${sec / 3600} h ago")
            else -> tr("منذ ${sec / 86400} يوم", "${sec / 86400} d ago")
        }
    }

    fun fmt(v: Double, code: String): String = String.format(java.util.Locale.US, if (kotlin.math.abs(v) >= 100) "%,.2f" else "%,.4f", v) + " " + code
}
