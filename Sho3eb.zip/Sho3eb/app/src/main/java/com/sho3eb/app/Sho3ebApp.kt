package com.sho3eb.app

import android.app.Application
import com.sho3eb.app.core.AppState
import com.sho3eb.app.core.Notifier
import com.sho3eb.app.core.Prefs
import com.sho3eb.app.core.ReminderWorker
import com.sho3eb.app.data.AppDatabase

class Sho3ebApp : Application() {
    lateinit var db: AppDatabase
    lateinit var prefs: Prefs

    override fun onCreate() {
        super.onCreate()
        instance = this
        runCatching { com.sho3eb.app.core.chat.Cloud.onAppStart(this) }
        prefs = Prefs(this)
        AppState.init(prefs)
        db = AppDatabase.build(this)
        Notifier.createChannel(this)
        ReminderWorker.schedule(this, prefs.remindHour)
        com.sho3eb.app.islam.IslamNotify.createChannels(this)
        try { com.sho3eb.app.islam.IslamAlarms.rescheduleAll(this) } catch (_: Exception) {}
        try { com.sho3eb.app.core.LivingWorker.schedule(this) } catch (_: Exception) {}
        try { com.sho3eb.app.islam.OccasionWorker.schedule(this) } catch (_: Exception) {}
        try { com.sho3eb.app.core.FootballAlerts.channel(this); com.sho3eb.app.core.FootballAlerts.schedule(this) } catch (_: Exception) {}
        try { if (com.sho3eb.app.core.chat.Supa.configured) { com.sho3eb.app.core.chat.Chat.channels(); com.sho3eb.app.core.chat.ChatService.apply(this) } } catch (_: Exception) {}
        try { com.sho3eb.app.core.Alarms.channel(this); com.sho3eb.app.core.Alarms.rescheduleAll(this) } catch (_: Exception) {}
        try { if (com.sho3eb.app.core.AutoBackup.everyDays > 0) com.sho3eb.app.core.AutoBackup.schedule(this) } catch (_: Exception) {}
    }

    companion object {
        lateinit var instance: Sho3ebApp
            private set
    }
}
