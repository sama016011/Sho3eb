package com.sho3eb.app

import android.app.Application
import com.sho3eb.app.core.AppState
import com.sho3eb.app.core.Notifier
import com.sho3eb.app.core.Prefs
import com.sho3eb.app.core.ReminderWorker
import com.sho3eb.app.data.AppDatabase

class Sho3ebApp : Application() {
    lateinit var db: AppDatabase
    lateinit var prefs: Prefs

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        AppState.init(prefs)
        db = AppDatabase.build(this)
        Notifier.createChannel(this)
        ReminderWorker.schedule(this, prefs.remindHour)
        com.sho3eb.app.islam.IslamNotify.createChannels(this)
        try { com.sho3eb.app.islam.IslamAlarms.rescheduleAll(this) } catch (_: Exception) {}
    }

    companion object {
        lateinit var instance: Sho3ebApp
            private set
    }
}
