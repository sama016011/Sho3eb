package com.sho3eb.app.islam

import android.content.Context
import android.content.SharedPreferences
import com.sho3eb.app.Sho3ebApp
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val global: Int, val page: Int, val time: Long, val label: String = "")
data class CustomReciter(val id: String, val name: String, val template: String)
data class AzanSound(val name: String, val path: String)

/** إعدادات قسم الإسلاميات */
object IslamPrefs {
    private val sp: SharedPreferences
        get() = Sho3ebApp.instance.getSharedPreferences("islam_prefs", Context.MODE_PRIVATE)

    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun ps(k: String, v: String) = sp.edit().putString(k, v).apply()
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun pi(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun pb(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun d(k: String, def: Double) = java.lang.Double.longBitsToDouble(sp.getLong(k, java.lang.Double.doubleToLongBits(def)))
    private fun pd(k: String, v: Double) = sp.edit().putLong(k, java.lang.Double.doubleToLongBits(v)).apply()

    // ---------- المصحف ----------
    var mushafMode: String get() = s("mMode", "text"); set(v) = ps("mMode", v)          // text / image
    var mushafTheme: String get() = s("mTheme", "cream"); set(v) = ps("mTheme", v)      // white / cream / night
    var fontSize: Int get() = i("mFont", 24); set(v) = pi("mFont", v)
    var lastPage: Int get() = i("lastPage", 1); set(v) = pi("lastPage", v)
    var keepScreenOn: Boolean get() = b("keepOn", true); set(v) = pb("keepOn", v)
    var reciter: String get() = s("reciter", "ar.alafasy"); set(v) = ps("reciter", v)
    var reciterName: String get() = s("reciterName", "مشاري راشد العفاسي"); set(v) = ps("reciterName", v)
    var tafsir: String get() = s("tafsir", "ar.muyassar"); set(v) = ps("tafsir", v)
    var tafsirName: String get() = s("tafsirName", "التفسير الميسر"); set(v) = ps("tafsirName", v)
    var translation: String get() = s("transl", "en.sahih"); set(v) = ps("transl", v)
    var translationName: String get() = s("translName", "Saheeh International"); set(v) = ps("translName", v)
    var repeatAyah: Int get() = i("repeat", 1); set(v) = pi("repeat", v)

    var bookmarks: List<Bookmark>
        get() = try {
            val arr = JSONArray(s("bookmarks", "[]"))
            (0 until arr.length()).map { k ->
                val o = arr.getJSONObject(k)
                Bookmark(o.getInt("g"), o.getInt("p"), o.getLong("t"), o.optString("l"))
            }
        } catch (e: Exception) {
            emptyList()
        }
        set(v) {
            val arr = JSONArray()
            v.forEach { arr.put(JSONObject().put("g", it.global).put("p", it.page).put("t", it.time).put("l", it.label)) }
            ps("bookmarks", arr.toString())
        }

    var customReciters: List<CustomReciter>
        get() = try {
            val arr = JSONArray(s("customRec", "[]"))
            (0 until arr.length()).map { k ->
                val o = arr.getJSONObject(k)
                CustomReciter(o.getString("id"), o.getString("n"), o.getString("t"))
            }
        } catch (e: Exception) {
            emptyList()
        }
        set(v) {
            val arr = JSONArray()
            v.forEach { arr.put(JSONObject().put("id", it.id).put("n", it.name).put("t", it.template)) }
            ps("customRec", arr.toString())
        }

    // ---------- الصلاة ----------
    var lat: Double get() = d("lat", 24.7136); set(v) = pd("lat", v)
    var lng: Double get() = d("lng", 46.6753); set(v) = pd("lng", v)
    var cityName: String get() = s("city", "الرياض"); set(v) = ps("city", v)
    var zoneId: String get() = s("zone", ""); set(v) = ps("zone", v)   // فارغ = منطقة الجهاز
    var method: String get() = s("method", "UMM_AL_QURA"); set(v) = ps("method", v)
    var asrHanafi: Boolean get() = b("hanafi", false); set(v) = pb("hanafi", v)
    var prayerNotify: Boolean get() = b("pNotify", true); set(v) = pb("pNotify", v)
    fun notifyFor(p: Int): Boolean = b("pn_$p", p != 1)      // 1 = الشروق (معطل افتراضياً)
    fun setNotifyFor(p: Int, v: Boolean) = pb("pn_$p", v)
    fun offsetFor(p: Int): Int = i("off_$p", 0)               // تعديل يدوي بالدقائق
    fun setOffsetFor(p: Int, v: Int) = pi("off_$p", v)
    var preReminder: Int get() = i("preRem", 0); set(v) = pi("preRem", v)   // تنبيه قبل الأذان بالدقائق
    var azanPath: String get() = s("azan", ""); set(v) = ps("azan", v)      // فارغ = صوت الإشعار
    var fajrAzanPath: String get() = s("azanFajr", ""); set(v) = ps("azanFajr", v)

    var azanSounds: List<AzanSound>
        get() = try {
            val arr = JSONArray(s("azans", "[]"))
            (0 until arr.length()).map { k -> val o = arr.getJSONObject(k); AzanSound(o.getString("n"), o.getString("p")) }
        } catch (e: Exception) {
            emptyList()
        }
        set(v) {
            val arr = JSONArray()
            v.forEach { arr.put(JSONObject().put("n", it.name).put("p", it.path)) }
            ps("azans", arr.toString())
        }

    // ---------- الأذكار والأحاديث ----------
    var azkarRemind: Boolean get() = b("azRem", true); set(v) = pb("azRem", v)
    var morningMin: Int get() = i("azM", 6 * 60 + 30); set(v) = pi("azM", v)   // دقائق من منتصف الليل
    var eveningMin: Int get() = i("azE", 17 * 60); set(v) = pi("azE", v)
    var hadithHours: Int get() = i("hadH", 6); set(v) = pi("hadH", v)          // 0 = متوقف
    var readerFont: Int get() = i("rFont", 18); set(v) = pi("rFont", v)
    var ttsRate: Float get() = sp.getFloat("ttsRate", 0.9f); set(v) = sp.edit().putFloat("ttsRate", v).apply()
    /** "" = تلقائي (صوت رجل إن وُجد) ، "default" = صوت المحرك الافتراضي ، غير ذلك = اسم الصوت */
    var ttsVoice: String get() = s("ttsVoice", ""); set(v) = ps("ttsVoice", v)
    /** -1 = تلقائي */
    var ttsPitch: Float get() = sp.getFloat("ttsPitch", -1f); set(v) = sp.edit().putFloat("ttsPitch", v).apply()
    /** "" = محرك الهاتف الافتراضي */
    var ttsEngine: String get() = s("ttsEngine", ""); set(v) = ps("ttsEngine", v)

    // تذكير الاستغفار والصلاة على النبي ﷺ (بالدقائق، 0 = متوقف)
    var istighfarMin: Int get() = i("istgMin", 0); set(v) = pi("istgMin", v)
    var salawatMin: Int get() = i("slwMin", 0); set(v) = pi("slwMin", v)
    var quietFrom: Int get() = i("quietFrom", 23); set(v) = pi("quietFrom", v)   // ساعة
    var quietTo: Int get() = i("quietTo", 6); set(v) = pi("quietTo", v)
    var dhikrSilent: Boolean get() = b("dhikrSilent", false); set(v) = pb("dhikrSilent", v)
    var salawatFridayBoost: Boolean get() = b("slwFri", true); set(v) = pb("slwFri", v)

    fun azkarCount(key: String): Int = i("zc_$key", 0)
    fun setAzkarCount(key: String, v: Int) = pi("zc_$key", v)
    var azkarCountDay: Long get() = sp.getLong("zcDay", 0); set(v) = sp.edit().putLong("zcDay", v).apply()
    fun resetAzkarCounts() {
        val e = sp.edit()
        sp.all.keys.filter { it.startsWith("zc_") }.forEach { e.remove(it) }
        e.apply()
    }
}
