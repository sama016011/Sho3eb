@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.DesignProject
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

@Composable
fun DesignScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val list by flowState(emptyList<DesignProject>()) { dao.designsFlow() }
    var newKind by remember { mutableStateOf<String?>(null) }
    var del by remember { mutableStateOf<DesignProject?>(null) }
    ScreenScaffold(title = tr("التصميم والأثاث", "Design & furniture"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(tr("صمّم مساحتك", "Design your space"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(tr("أدخل الأبعاد ونوع المساحة، وسيُولَّد مخطط ثنائي الأبعاد ونموذج ثلاثي الأبعاد متحرك مع قائمة الأثاث وتكلفة تقريبية في مصر.", "Enter dimensions and space type to get a 2D plan, an animated 3D model, a furniture list and an approximate cost in Egypt."), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KindTile("🛋️", tr("غرفة وأثاث", "Room & furniture"), Modifier.weight(1f)) { newKind = "ROOM" }
                    KindTile("🏢", tr("شقة كاملة", "Apartment"), Modifier.weight(1f)) { newKind = "APARTMENT" }
                    KindTile("🏗️", tr("قطعة أرض", "Land plot"), Modifier.weight(1f)) { newKind = "LAND" }
                }
            }
            if (list.isNotEmpty()) item { SectionTitle(tr("مشاريعي", "My projects")) }
            items(list, key = { it.id }) { p ->
                Card(onClick = { nav.navigate("design/${p.id}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(when (p.kind) { "APARTMENT" -> "🏢"; "LAND" -> "🏗️"; else -> Design.roomFrom(p.data)?.let { Design.roomType(it.type).emoji } ?: "🛋️" }, fontSize = 28.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text(tr("التكلفة التقريبية: ", "Approx. cost: ") + Fmt.num(p.cost) + tr(" ج.م", " EGP"), style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { del = p }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                    }
                }
            }
        }
    }
    newKind?.let { k ->
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newKind = null },
            title = { Text(tr("مشروع جديد", "New project")) },
            text = { OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم (مثال: غرفة نوم الأولاد)", "Name (e.g. kids bedroom)")) }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val data = when (k) {
                        "APARTMENT" -> Design.aptJson(Design.Apartment(1200.0, 1100.0, 3, 2, false, true))
                        "LAND" -> Design.landJson(Design.Land(1500.0, 2000.0, 5))
                        else -> Design.roomJson(Design.Room("MASTER", 400.0, 450.0))
                    }
                    scope.launch {
                        val id = dao.insertDesign(DesignProject(kind = k, name = name.trim().ifBlank { when (k) { "APARTMENT" -> tr("شقتي", "My apartment"); "LAND" -> tr("أرضي", "My plot"); else -> tr("غرفتي", "My room") } }, data = data))
                        newKind = null; nav.navigate("design/$id")
                    }
                }) { Text(tr("ابدأ", "Start")) }
            },
            dismissButton = { TextButton(onClick = { newKind = null }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
    del?.let { p -> ConfirmDialog(tr("حذف المشروع", "Delete project"), p.name, onDismiss = { del = null }) { scope.launch { if (p.photoPath.isNotBlank()) File(p.photoPath).delete(); dao.deleteDesign(p.id); del = null } } }
}

@Composable
private fun KindTile(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 30.sp); Text(label, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun DesignEditScreen(nav: NavController, id: Long) {
    val dao = remember { appDao() }
    val list by flowState(emptyList<DesignProject>()) { dao.designsFlow() }
    val p = list.firstOrNull { it.id == id }
    if (p == null) { ScreenScaffold(tr("التصميم", "Design"), onBack = { nav.popBackStack() }) { pad -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }; return }
    key(p.id) {
        when (p.kind) {
            "APARTMENT" -> ApartmentEditor(nav, p)
            "LAND" -> LandEditor(nav, p)
            else -> RoomEditor(nav, p)
        }
    }
}

// ---------------- أدوات إدخال مشتركة ----------------
@Composable
private fun MetersField(label: String, cm: Double, modifier: Modifier = Modifier, onCm: (Double) -> Unit) {
    var t by remember { mutableStateOf(Fmt.plain(cm / 100.0)) }
    OutlinedTextField(t, { v -> t = v; Fmt.parse(v)?.takeIf { it in 0.5..200.0 }?.let { onCm(it * 100) } }, label = { Text(label) }, singleLine = true, modifier = modifier,
        suffix = { Text(tr("م", "m")) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal))
}

@Composable
private fun ViewToggle(mode: Int, onMode: (Int) -> Unit) {
    HChips {
        FilterChip(mode == 0, { onMode(0) }, label = { Text(tr("🧊 ثلاثي الأبعاد", "🧊 3D")) })
        FilterChip(mode == 1, { onMode(1) }, label = { Text(tr("📐 مخطط", "📐 2D plan")) })
    }
}

@Composable
private fun CostCard(title: String, lines: List<Pair<String, Double>>, total: Double, note: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            lines.filter { it.second > 0 }.forEach { (l, v) -> KeyValue(l, Fmt.num(v) + tr(" ج", " EGP")) }
            HorizontalDivider()
            Row { Text(tr("الإجمالي التقريبي", "Approximate total"), Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(Fmt.num(total) + tr(" ج.م", " EGP"), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary) }
            Text(note, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private val wallNames get() = listOf(tr("أعلى", "Top"), tr("يمين", "Right"), tr("أسفل", "Bottom"), tr("يسار", "Left"))

// =============================== محرر الغرفة ===============================
@Composable
private fun RoomEditor(nav: NavController, p: DesignProject) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var room by remember { mutableStateOf(Design.roomFrom(p.data) ?: Design.Room("MASTER", 400.0, 450.0)) }
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var photo by remember { mutableStateOf(p.photoPath) }
    var factorTxt by remember { mutableStateOf(Fmt.plain(room.factor)) }
    var shopFor by remember { mutableStateOf<String?>(null) }
    val res = remember(room) { Design.generate(room) }
    val boxes = remember(res) { res.items.mapIndexed { i, it -> Box3(it.x, it.y, 0.0, it.w, it.d, it.h, Color(it.color), it.name, i) } }
    val parts = remember(res) { res.items.flatMapIndexed { i, it -> furnitureParts(it, i) } }
    val si = remember(room.style) { Design.styleInfo(room.style) }
    val openings = remember(room) { listOfNotNull(Opening3(room.door.wall, room.door.pos, room.door.width, true), room.window?.let { Opening3(it.wall, it.pos, it.width, false) }) }
    val checks = remember(res) { Design.checks(room, res) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val f = withContext(Dispatchers.IO) {
                val mime = ctx.contentResolver.getType(uri) ?: ""
                val out = File(File(ctx.filesDir, "attachments").apply { mkdirs() }, "design_${p.id}_${System.currentTimeMillis()}" + if (mime.startsWith("video")) ".mp4" else ".jpg")
                runCatching { ctx.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { i.copyTo(it) } } }
                out
            }
            if (photo.isNotBlank()) File(photo).delete()
            photo = f.absolutePath
            dao.updateDesign(p.copy(photoPath = photo))
        }
    }
    fun save() = scope.launch { dao.updateDesign(p.copy(data = Design.roomJson(room), cost = res.total, photoPath = photo)); toast(ctx, tr("تم الحفظ ✅", "Saved ✅")) }
    val doc = {
        ReportDoc(
            tr("تصميم غرفة", "Room design"), p.name,
            listOf(tr("النوع", "Type") to Design.roomType(room.type).label, tr("الأبعاد", "Size") to "${Fmt.num(room.w / 100)} × ${Fmt.num(room.l / 100)} " + tr("م", "m"),
                tr("المساحة", "Area") to Fmt.num(room.w * room.l / 10000) + tr(" م²", " m²"), tr("الستايل", "Style") to (Design.styles.firstOrNull { it.key == room.style }?.label ?: ""),
                tr("المستوى", "Tier") to Design.tiers[room.tier].label),
            listOf(
                RTable(tr("الأثاث", "Furniture"), listOf(tr("القطعة", "Item"), tr("المقاس سم", "Size cm"), tr("السعر التقريبي", "Approx. price")),
                    res.items.map { listOf(it.name, "${it.w.toInt()}×${it.d.toInt()}×${it.h.toInt()}", Fmt.num(it.price)) } + listOf(listOf(tr("إجمالي الأثاث", "Furniture total"), "", Fmt.num(res.furniture))), res.items.map { null } + listOf(9)),
                RTable(tr("التشطيبات", "Finishing"), listOf(tr("البند", "Item"), tr("التكلفة", "Cost")), res.lines.map { listOf(it.first, Fmt.num(it.second)) } + listOf(listOf(tr("الإجمالي", "Total"), Fmt.num(res.finishing))), res.lines.map { null } + listOf(9))
            ),
            listOf(tr("الإجمالي التقريبي", "Approximate total") to Fmt.num(res.total) + tr(" ج.م", " EGP")),
            tr("أسعار تقريبية في مصر وتختلف حسب المدينة والخامة والمورد.", "Approximate Egyptian prices; vary by city, material and supplier."), "room_" + p.name
        )
    }
    ScreenScaffold(
        title = p.name, onBack = { nav.popBackStack() },
        actions = {
            PdfShareButton(null, doc = doc) { c -> Reports.doc(c, doc()) }
            IconButton(onClick = { save() }) { Icon(Icons.Filled.Save, null) }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth().height(380.dp)) {
                    if (mode == 0) Iso3DView(parts, room.w, room.l, room.h, true, Color(si.floor), Modifier.fillMaxSize(), key = res, wallColor = Color(si.wall), openings = openings, planks = si.planks)
                    else Plan2DView(room.w, room.l, boxes, Modifier.fillMaxSize().padding(6.dp), room.door.wall to room.door.pos, room.window?.let { it.wall to it.pos }, room.door.width, room.window?.width ?: 140.0)
                }
            }
            item { ViewToggle(mode) { mode = it } }
            res.warnings.forEach { w -> item { Text("⚠️ $w", color = WarnAmber, style = MaterialTheme.typography.bodySmall) } }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("📷 صورة/فيديو الغرفة (مرجع)", "📷 Room photo/video (reference)"), fontWeight = FontWeight.Bold)
                        if (photo.isNotBlank()) {
                            val bmp = remember(photo) { if (photo.endsWith(".jpg")) runCatching { BitmapFactory.decodeFile(photo, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap() }.getOrNull() else null }
                            if (bmp != null) Image(bmp, null, Modifier.fillMaxWidth().height(160.dp), contentScale = ContentScale.Crop)
                            else Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Movie, null); Spacer(Modifier.width(6.dp)); Text(tr("تم حفظ الفيديو كمرجع", "Video saved as reference")) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { pick.launch(arrayOf("image/*", "video/*")) }) { Icon(Icons.Filled.AddAPhoto, null); Spacer(Modifier.width(4.dp)); Text(if (photo.isBlank()) tr("إضافة", "Add") else tr("تغيير", "Change")) }
                            if (photo.isNotBlank() && photo.endsWith(".mp4")) OutlinedButton(onClick = { runCatching { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(Share.uriFor(ctx, File(photo)), "video/*").addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }) { Text(tr("تشغيل", "Play")) }
                        }
                        Text(tr("الصورة للمقارنة فقط؛ التصميم يُولَّد من الأبعاد التي تدخلها. قِس الغرفة بالمتر من الجدار للجدار.", "The photo is a reference; the design is generated from your measurements."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("📏 الأبعاد ونوع الغرفة", "📏 Size & room type"), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetersField(tr("العرض", "Width"), room.w, Modifier.weight(1f)) { room = room.copy(w = it) }
                            MetersField(tr("الطول", "Length"), room.l, Modifier.weight(1f)) { room = room.copy(l = it) }
                            MetersField(tr("الارتفاع", "Height"), room.h, Modifier.weight(1f)) { room = room.copy(h = it) }
                        }
                        Text(tr("المساحة: ", "Area: ") + Fmt.num(room.w * room.l / 10000) + tr(" م²", " m²"), style = MaterialTheme.typography.bodySmall)
                        HChips { Design.roomTypes.forEach { t -> FilterChip(room.type == t.key, { room = room.copy(type = t.key, excluded = emptySet()) }, label = { Text(t.emoji + " " + t.label) }) } }
                        Text(tr("الستايل", "Style"), style = MaterialTheme.typography.labelLarge)
                        HChips { Design.styles.forEach { t -> FilterChip(room.style == t.key, { room = room.copy(style = t.key) }, label = { Text(t.emoji + " " + t.label) }) } }
                        Text(tr("مستوى الخامات", "Quality tier"), style = MaterialTheme.typography.labelLarge)
                        HChips { Design.tiers.forEachIndexed { i, t -> FilterChip(room.tier == i, { room = room.copy(tier = i) }, label = { Text(t.emoji + " " + t.label) }) } }
                        Text(tr("🚪 مكان الباب", "🚪 Door"), style = MaterialTheme.typography.labelLarge)
                        HChips { wallNames.forEachIndexed { i, n -> FilterChip(room.door.wall == i, { room = room.copy(door = room.door.copy(wall = i)) }, label = { Text(n) }) } }
                        Slider(room.door.pos.toFloat(), { room = room.copy(door = room.door.copy(pos = it.toDouble())) }, valueRange = 0.1f..0.9f)
                        Text(tr("🪟 مكان الشباك", "🪟 Window"), style = MaterialTheme.typography.labelLarge)
                        HChips {
                            FilterChip(room.window == null, { room = room.copy(window = null) }, label = { Text(tr("بدون", "None")) })
                            wallNames.forEachIndexed { i, n -> FilterChip(room.window?.wall == i, { room = room.copy(window = (room.window ?: Design.Opening(i, 0.5, 140.0)).copy(wall = i)) }, label = { Text(n) }) }
                        }
                        room.window?.let { w -> Slider(w.pos.toFloat(), { room = room.copy(window = w.copy(pos = it.toDouble())) }, valueRange = 0.15f..0.85f) }
                        OutlinedTextField(factorTxt, { v -> factorTxt = v; Fmt.parse(v)?.takeIf { it in 0.2..10.0 }?.let { room = room.copy(factor = it) } }, label = { Text(tr("معامل الأسعار (1 = الأسعار الافتراضية)", "Price factor (1 = default)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(tr("🎨 لوحة ألوان الستايل", "🎨 Style palette"), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            si.palette.forEach { (n, c) ->
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Surface(color = Color(c), shape = MaterialTheme.shapes.small, modifier = Modifier.fillMaxWidth().height(36.dp), tonalElevation = 1.dp) {}
                                    Text(n, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                }
                            }
                        }
                        si.tips.forEach { Text("✨ $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(tr("📐 فحص التصميم", "📐 Design check"), fontWeight = FontWeight.Bold)
                        checks.forEach { (ok, t) -> Text((if (ok) "✅ " else "⚠️ ") + t, style = MaterialTheme.typography.bodySmall, color = if (ok) SuccessGreen else WarnAmber) }
                    }
                }
            }
            item { SectionTitle(tr("🪑 قائمة الأثاث (${res.items.size})", "🪑 Furniture (${res.items.size})")) }
            items(res.items, key = { it.key + it.x + it.y }) { it2 ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(18.dp)) { Surface(color = Color(it2.color), shape = MaterialTheme.shapes.extraSmall, modifier = Modifier.fillMaxSize()) {} }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(it2.name, fontWeight = FontWeight.SemiBold)
                            Text("${it2.w.toInt()} × ${it2.d.toInt()} × ${it2.h.toInt()} " + tr("سم", "cm"), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(Fmt.num(it2.price), fontWeight = FontWeight.Bold)
                        IconButton(onClick = { shopFor = it2.name }) { Icon(Icons.Filled.ShoppingCart, contentDescription = tr("شراء", "Buy"), tint = MaterialTheme.colorScheme.primary) }
                        IconButton(onClick = { room = room.copy(excluded = room.excluded + it2.key) }) { Icon(Icons.Filled.RemoveCircleOutline, null, tint = DangerRed) }
                    }
                }
            }
            if (room.excluded.isNotEmpty()) item { TextButton(onClick = { room = room.copy(excluded = emptySet()) }) { Text(tr("↩️ إعادة القطع المحذوفة (${room.excluded.size})", "↩️ Restore removed (${room.excluded.size})")) } }
            item { CostCard(tr("💰 التكلفة التقريبية في مصر", "💰 Approximate cost in Egypt"), listOf(tr("الأثاث", "Furniture") to res.furniture) + res.lines, res.total, tr("أسعار تقريبية لعام 2026 وتتغير بسرعة؛ عدّل «معامل الأسعار» حسب عروض الأسعار التي تحصل عليها.", "Rough 2026 prices that change fast; adjust the price factor to match quotes.")) }
            item { Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Save, null); Spacer(Modifier.width(6.dp)); Text(tr("حفظ التصميم", "Save design")) } }
        }
    }
    shopFor?.let { n ->
        AlertDialog(onDismissRequest = { shopFor = null }, title = { Text(tr("🛒 اشترِ: ", "🛒 Buy: ") + n) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Design.shopLinks(n).forEach { (store, url) -> OutlinedButton(onClick = { Share.openUrl(ctx, url) }, modifier = Modifier.fillMaxWidth()) { Text(store) } } } },
            confirmButton = { TextButton(onClick = { shopFor = null }) { Text(tr("إغلاق", "Close")) } })
    }
}

// =============================== محرر الشقة ===============================
@Composable
private fun ApartmentEditor(nav: NavController, p: DesignProject) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var a by remember { mutableStateOf(Design.aptFrom(p.data) ?: Design.Apartment(1200.0, 1100.0, 3, 2, false, true)) }
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var rateTxt by remember { mutableStateOf(if (a.finishRate > 0) Fmt.plain(a.finishRate) else "") }
    val res = remember(a) { Design.apartment(a) }
    val boxes = remember(res) {
        val out = mutableListOf<Box3>()
        res.spaces.forEachIndexed { i, s ->
            out += Box3(s.x, s.y, 0.0, s.w, s.d, 1.0, Color(s.color), s.name + " " + Fmt.num(s.area) + "م²", i)
            // جدران منخفضة لكل مساحة (قطع مقطعي)
            val wh = 110.0; val t = 12.0; val c = Color(0xFFBDBDBD)
            out += Box3(s.x, s.y, 0.0, s.w, t, wh, c, "", i); out += Box3(s.x, s.y + s.d - t, 0.0, s.w, t, wh, c, "", i)
            out += Box3(s.x, s.y, 0.0, t, s.d, wh, c, "", i); out += Box3(s.x + s.w - t, s.y, 0.0, t, s.d, wh, c, "", i)
            // فرش الغرفة تلقائياً داخل النموذج
            Design.roomTypeFor(s.key)?.let { type ->
                val pubD = res.spaces.firstOrNull { it.key == "corridor" }?.y ?: 0.0
                val rr = Design.generate(Design.Room(type, s.w - 2 * t, s.d - 2 * t, door = Design.Opening(if (s.y >= pubD) 0 else 2, 0.15, 90.0), window = Design.Opening(if (s.y >= pubD) 2 else 0, 0.5, 140.0), tier = a.tier, factor = a.factor))
                rr.items.forEach { itx -> out += furnitureParts(itx.copy(x = itx.x + s.x + t, y = itx.y + s.y + t), i) }
            }
        }
        out
    }
    fun save() = scope.launch { dao.updateDesign(p.copy(data = Design.aptJson(a), cost = res.total)); toast(ctx, tr("تم الحفظ ✅", "Saved ✅")) }
    val doc = {
        ReportDoc(tr("مخطط شقة", "Apartment layout"), p.name,
            listOf(tr("الأبعاد", "Size") to "${Fmt.num(a.w / 100)} × ${Fmt.num(a.l / 100)} " + tr("م", "m"), tr("المساحة", "Area") to Fmt.num(a.w * a.l / 10000) + tr(" م²", " m²"),
                tr("الغرف", "Bedrooms") to a.bedrooms.toString(), tr("الحمامات", "Baths") to a.baths.toString(), tr("المستوى", "Tier") to Design.tiers[a.tier].label),
            listOf(
                RTable(tr("المساحات", "Spaces"), listOf(tr("المساحة", "Space"), tr("الأبعاد م", "Size m"), tr("م²", "m²")), res.spaces.map { listOf(it.name, "${Fmt.num(it.w / 100)}×${Fmt.num(it.d / 100)}", Fmt.num(it.area)) }),
                RTable(tr("التكلفة", "Cost"), listOf(tr("البند", "Item"), tr("ج.م", "EGP")), res.lines.map { listOf(it.first, Fmt.num(it.second)) } + listOf(listOf(tr("الإجمالي", "Total"), Fmt.num(res.total))), res.lines.map { null } + listOf(9))
            ), listOf(tr("الإجمالي التقريبي", "Approximate total") to Fmt.num(res.total) + tr(" ج.م", " EGP")),
            tr("مخطط مبدئي استرشادي؛ يلزم مهندس معماري للتصميم التنفيذي.", "Preliminary guide; consult an architect for construction drawings."), "apartment_" + p.name)
    }
    ScreenScaffold(title = p.name, onBack = { nav.popBackStack() }, actions = { PdfShareButton(null, doc = doc) { c -> Reports.doc(c, doc()) }; IconButton(onClick = { save() }) { Icon(Icons.Filled.Save, null) } }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth().height(340.dp)) {
                    if (mode == 0) Iso3DView(boxes, a.w, a.l, 150.0, false, Color(0xFFF5F5F5), Modifier.fillMaxSize(), key = res)
                    else Plan2DView(a.w, a.l, res.spaces.map { Box3(it.x, it.y, 0.0, it.w, it.d, 1.0, Color(it.color), it.name) }, Modifier.fillMaxSize().padding(6.dp))
                }
            }
            item { ViewToggle(mode) { mode = it } }
            res.warnings.forEach { w -> item { Text("⚠️ $w", color = WarnAmber, style = MaterialTheme.typography.bodySmall) } }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("📏 مواصفات الشقة", "📏 Apartment specs"), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetersField(tr("العرض (الواجهة)", "Width (front)"), a.w, Modifier.weight(1f)) { a = a.copy(w = it) }
                            MetersField(tr("العمق", "Depth"), a.l, Modifier.weight(1f)) { a = a.copy(l = it) }
                        }
                        Text(tr("المساحة: ", "Area: ") + Fmt.num(a.w * a.l / 10000) + tr(" م²", " m²"), style = MaterialTheme.typography.bodySmall)
                        Text(tr("غرف النوم", "Bedrooms"), style = MaterialTheme.typography.labelLarge)
                        HChips { (1..5).forEach { n -> FilterChip(a.bedrooms == n, { a = a.copy(bedrooms = n) }, label = { Text("$n") }) } }
                        Text(tr("الحمامات", "Bathrooms"), style = MaterialTheme.typography.labelLarge)
                        HChips { (1..4).forEach { n -> FilterChip(a.baths == n, { a = a.copy(baths = n) }, label = { Text("$n") }) } }
                        SwitchRow(tr("مطبخ مفتوح (أمريكي)", "Open kitchen"), null, a.openKitchen) { a = a.copy(openKitchen = it) }
                        SwitchRow(tr("بلكونة", "Balcony"), null, a.balcony) { a = a.copy(balcony = it) }
                        Text(tr("مستوى التشطيب", "Finishing tier"), style = MaterialTheme.typography.labelLarge)
                        HChips { Design.tiers.forEachIndexed { i, t -> FilterChip(a.tier == i, { a = a.copy(tier = i) }, label = { Text(t.emoji + " " + t.label + " ≈ " + Fmt.num(Design.finishRates[i]) + tr("/م²", "/m²")) }) } }
                        OutlinedTextField(rateTxt, { v -> rateTxt = v; a = a.copy(finishRate = Fmt.parse(v) ?: 0.0) }, label = { Text(tr("سعر تشطيب المتر (اختياري لتعديل التقدير)", "Finishing rate per m² (optional override)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item { SectionTitle(tr("المساحات", "Spaces")) }
            items(res.spaces, key = { it.key }) { s -> KeyValue(s.name, "${Fmt.num(s.w / 100)} × ${Fmt.num(s.d / 100)} = " + Fmt.num(s.area) + tr(" م²", " m²")) }
            item { CostCard(tr("💰 التكلفة التقريبية (تشطيب + فرش)", "💰 Approximate cost (finishing + furnishing)"), res.lines, res.total, tr("تقدير استرشادي بأسعار مصر 2026؛ يلزم مهندس للتصميم التنفيذي وعروض أسعار فعلية.", "Indicative Egypt 2026 estimate; get real quotes and an architect.")) }
        }
    }
}

// =============================== محرر الأرض ===============================
@Composable
private fun LandEditor(nav: NavController, p: DesignProject) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var d by remember { mutableStateOf(Design.landFrom(p.data) ?: Design.Land(1500.0, 2000.0, 5)) }
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var skTxt by remember { mutableStateOf(if (d.skeletonRate > 0) Fmt.plain(d.skeletonRate) else "") }
    var finTxt by remember { mutableStateOf(if (d.finishRate > 0) Fmt.plain(d.finishRate) else "") }
    var aptTxt by remember { mutableStateOf(Fmt.plain(d.aptArea)) }
    var covTxt by remember { mutableStateOf(Fmt.plain(d.coverage * 100)) }
    val res = remember(d) { Design.land(d) }
    val fx = d.side * 100; val fy = d.front * 100
    val fw = res.footW * 100; val fl = res.footL * 100
    val boxes = remember(res) {
        val out = mutableListOf<Box3>()
        val fh = 320.0
        for (f in 0 until d.floors) {
            val c = if (f == 0 && d.ground != "APTS") Color(0xFF90A4AE) else Color(0xFFFFCC80)
            out += Box3(fx, fy, f * fh, fw, fl, fh - 25, c, "", f)
            out += Box3(fx - 15, fy - 15, f * fh + fh - 25, fw + 30, fl + 30, 25.0, Color(0xFFE0E0E0), "", f)
            // شبابيك الواجهات
            val glass = Color(0xFF64B5F6)
            val nx = max(1, (fw / 300).toInt()); val ny = max(1, (fl / 300).toInt())
            for (k in 0 until nx) { val wx = fx + (k + 0.5) * fw / nx - 60; out += Box3(wx, fy - 3, f * fh + 90, 120.0, 3.0, 140.0, glass, "", f, true); out += Box3(wx, fy + fl, f * fh + 90, 120.0, 3.0, 140.0, glass, "", f, true) }
            for (k in 0 until ny) { val wy = fy + (k + 0.5) * fl / ny - 60; out += Box3(fx - 3, wy, f * fh + 90, 3.0, 120.0, 140.0, glass, "", f, true); out += Box3(fx + fw, wy, f * fh + 90, 3.0, 120.0, 140.0, glass, "", f, true) }
            if (f > 0) out += Box3(fx + fw * 0.3, fy - 120, f * fh, fw * 0.4, 120.0, 12.0, Color(0xFFBDBDBD), "", f) // بلكونة
            if (f > 0) out += Box3(fx + fw * 0.3, fy - 120, f * fh + 12, fw * 0.4, 4.0, 95.0, Color(0xFF90A4AE).copy(alpha = 0.6f), "", f, true)
        }
        // سور السطح وغرفة السلم
        val top = d.floors * fh
        out += Box3(fx, fy, top, fw, 8.0, 100.0, Color(0xFFE0E0E0), "", d.floors); out += Box3(fx, fy + fl - 8, top, fw, 8.0, 100.0, Color(0xFFE0E0E0), "", d.floors)
        out += Box3(fx, fy, top, 8.0, fl, 100.0, Color(0xFFE0E0E0), "", d.floors); out += Box3(fx + fw - 8, fy, top, 8.0, fl, 100.0, Color(0xFFE0E0E0), "", d.floors)
        out += Box3(fx + fw * 0.4, fy + fl * 0.4, top, 350.0, 450.0, 280.0, Color(0xFFFFCC80), "", d.floors)
        // أشجار على الرصيف
        var tx = 150.0
        while (tx < d.w - 100) { out += Box3(tx, 60.0, 0.0, 30.0, 30.0, 180.0, Color(0xFF795548), "", 0); out += Box3(tx - 50, 15.0, 180.0, 130.0, 120.0, 160.0, Color(0xFF66BB6A), "", 0); tx += 500 }
        out
    }
    fun save() = scope.launch { dao.updateDesign(p.copy(data = Design.landJson(d), cost = res.total)); toast(ctx, tr("تم الحفظ ✅", "Saved ✅")) }
    val doc = {
        ReportDoc(tr("دراسة قطعة أرض", "Land study"), p.name,
            listOf(tr("الأرض", "Plot") to "${Fmt.num(d.w / 100)} × ${Fmt.num(d.l / 100)} " + tr("م", "m") + " = " + Fmt.num(d.w * d.l / 10000) + tr(" م²", " m²"),
                tr("مسطح الدور", "Floor footprint") to Fmt.num(res.footArea) + tr(" م²", " m²"), tr("عدد الأدوار", "Floors") to d.floors.toString(),
                tr("إجمالي المسطحات", "Built-up area") to Fmt.num(res.bua) + tr(" م²", " m²"), tr("شقق في الدور", "Units per floor") to res.aptsPerFloor.toString(), tr("إجمالي الشقق", "Total units") to res.totalApts.toString()),
            listOf(RTable(tr("التكلفة", "Cost"), listOf(tr("البند", "Item"), tr("ج.م", "EGP")), res.lines.map { listOf(it.first, Fmt.num(it.second)) } + listOf(listOf(tr("الإجمالي", "Total"), Fmt.num(res.total))), res.lines.map { null } + listOf(9))),
            listOf(tr("الإجمالي التقريبي", "Approximate total") to Fmt.num(res.total) + tr(" ج.م", " EGP")),
            tr("دراسة مبدئية؛ الاشتراطات البنائية تختلف حسب المدينة والحي ويلزم مكتب هندسي.", "Preliminary; building codes vary by city — consult an engineering office."), "land_" + p.name)
    }
    ScreenScaffold(title = p.name, onBack = { nav.popBackStack() }, actions = { PdfShareButton(null, doc = doc) { c -> Reports.doc(c, doc()) }; IconButton(onClick = { save() }) { Icon(Icons.Filled.Save, null) } }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth().height(340.dp)) {
                    if (mode == 0) Iso3DView(boxes, d.w, d.l, d.floors * 320.0, false, Color(0xFFC5E1A5), Modifier.fillMaxSize(), key = res)
                    else {
                        val apts = (0 until res.aptsPerFloor).map { i -> Box3(fx + i * fw / res.aptsPerFloor, fy, 0.0, fw / res.aptsPerFloor, fl, 2.0, Color(0xFFFFCC80), tr("شقة ${i + 1}", "Unit ${i + 1}")) }
                        Plan2DView(d.w, d.l, listOf(Box3(fx, fy, 0.0, fw, fl, 1.0, Color(0xFFFFE0B2), "")) + apts + listOf(Box3(0.0, 0.0, 0.0, d.w, fy, 1.0, Color(0xFFA5D6A7), tr("ردود أمامية", "Front setback"))), Modifier.fillMaxSize().padding(6.dp))
                    }
                }
            }
            item { ViewToggle(mode) { mode = it } }
            res.warnings.forEach { w -> item { Text("⚠️ $w", color = WarnAmber, style = MaterialTheme.typography.bodySmall) } }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("📏 بيانات الأرض", "📏 Plot data"), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetersField(tr("العرض", "Width"), d.w, Modifier.weight(1f)) { d = d.copy(w = it) }
                            MetersField(tr("الطول", "Length"), d.l, Modifier.weight(1f)) { d = d.copy(l = it) }
                        }
                        Text(tr("المساحة: ", "Area: ") + Fmt.num(d.w * d.l / 10000) + tr(" م²", " m²"), style = MaterialTheme.typography.bodySmall)
                        Text(tr("عدد الأدوار (مع الأرضي)", "Floors (incl. ground)"), style = MaterialTheme.typography.labelLarge)
                        HChips { listOf(1, 2, 3, 4, 5, 6, 7, 8, 10, 12).forEach { n -> FilterChip(d.floors == n, { d = d.copy(floors = n) }, label = { Text("$n") }) } }
                        Text(tr("الدور الأرضي", "Ground floor"), style = MaterialTheme.typography.labelLarge)
                        HChips {
                            FilterChip(d.ground == "APTS", { d = d.copy(ground = "APTS") }, label = { Text(tr("شقق", "Units")) })
                            FilterChip(d.ground == "SHOPS", { d = d.copy(ground = "SHOPS") }, label = { Text(tr("محلات", "Shops")) })
                            FilterChip(d.ground == "GARAGE", { d = d.copy(ground = "GARAGE") }, label = { Text(tr("جراج", "Garage")) })
                        }
                        Text(tr("الردود (متر)", "Setbacks (m)"), style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            NumField(tr("أمامي", "Front"), d.front, Modifier.weight(1f)) { d = d.copy(front = it) }
                            NumField(tr("خلفي", "Back"), d.back, Modifier.weight(1f)) { d = d.copy(back = it) }
                            NumField(tr("جانبي", "Side"), d.side, Modifier.weight(1f)) { d = d.copy(side = it) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(covTxt, { v -> covTxt = v; Fmt.parse(v)?.takeIf { it in 10.0..100.0 }?.let { d = d.copy(coverage = it / 100) } }, label = { Text(tr("نسبة البناء %", "Coverage %")) }, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(aptTxt, { v -> aptTxt = v; Fmt.parse(v)?.takeIf { it >= 30 }?.let { d = d.copy(aptArea = it) } }, label = { Text(tr("مساحة الشقة م²", "Unit size m²")) }, singleLine = true, modifier = Modifier.weight(1f))
                        }
                        Text(tr("مستوى التشطيب", "Finishing tier"), style = MaterialTheme.typography.labelLarge)
                        HChips { Design.tiers.forEachIndexed { i, t -> FilterChip(d.tier == i, { d = d.copy(tier = i) }, label = { Text(t.emoji + " " + t.label) }) } }
                        OutlinedTextField(skTxt, { v -> skTxt = v; d = d.copy(skeletonRate = Fmt.parse(v) ?: 0.0) }, label = { Text(tr("سعر متر العظم (افتراضي ", "Shell rate per m² (default ") + Fmt.num(Design.skeletonDefault) + ")") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(finTxt, { v -> finTxt = v; d = d.copy(finishRate = Fmt.parse(v) ?: 0.0) }, label = { Text(tr("سعر متر التشطيب (اختياري)", "Finishing rate per m² (optional)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(tr("📊 النتائج", "📊 Results"), fontWeight = FontWeight.Bold)
                        KeyValue(tr("أبعاد المبنى", "Building size"), "${Fmt.num(res.footW)} × ${Fmt.num(res.footL)} " + tr("م", "m"))
                        KeyValue(tr("مسطح الدور", "Floor area"), Fmt.num(res.footArea) + tr(" م²", " m²"))
                        KeyValue(tr("إجمالي المسطحات", "Built-up area"), Fmt.num(res.bua) + tr(" م²", " m²"))
                        KeyValue(tr("شقق في الدور", "Units per floor"), res.aptsPerFloor.toString() + tr(" (≈ ", " (≈ ") + Fmt.num((res.footArea - 18) / res.aptsPerFloor) + tr(" م² للشقة)", " m² each)"))
                        KeyValue(tr("إجمالي الشقق", "Total units"), res.totalApts.toString(), SuccessGreen)
                        KeyValue(tr("تكلفة المتر الكلية", "All-in cost per m²"), Fmt.num(res.total / res.bua.coerceAtLeast(1.0)))
                    }
                }
            }
            item { CostCard(tr("💰 تكلفة البناء التقريبية", "💰 Approximate build cost"), res.lines, res.total, tr("تقدير استرشادي بأسعار مصر 2026 ويتغير مع أسعار الحديد والأسمنت؛ عدّل أسعار المتر حسب عروض المقاولين. لا يشمل ثمن الأرض.", "Indicative Egypt 2026 estimate; adjust rates to contractor quotes. Excludes land price.")) }
        }
    }
}

@Composable
private fun NumField(label: String, v: Double, modifier: Modifier, on: (Double) -> Unit) {
    var t by remember { mutableStateOf(Fmt.plain(v)) }
    OutlinedTextField(t, { x -> t = x; Fmt.parse(x)?.takeIf { it in 0.0..50.0 }?.let(on) ?: if (x.isBlank()) on(0.0) else Unit }, label = { Text(label) }, singleLine = true, modifier = modifier)
}
