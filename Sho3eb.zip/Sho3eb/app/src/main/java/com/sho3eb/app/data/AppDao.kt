package com.sho3eb.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
abstract class AppDao {

    // ---------------- People ----------------
    @Query("SELECT * FROM people ORDER BY name COLLATE NOCASE")
    abstract fun peopleFlow(): Flow<List<Person>>

    @Query("SELECT * FROM people")
    abstract suspend fun allPeople(): List<Person>

    @Query("SELECT * FROM people WHERE id = :id")
    abstract suspend fun person(id: Long): Person?

    @Query("SELECT * FROM people WHERE id = :id")
    abstract fun personFlow(id: Long): Flow<Person?>

    @Query("SELECT * FROM people WHERE phone = :phone LIMIT 1")
    abstract suspend fun personByPhone(phone: String): Person?

    @Insert
    abstract suspend fun insertPerson(p: Person): Long

    @Update
    abstract suspend fun updatePerson(p: Person)

    @Query("DELETE FROM people WHERE id = :id")
    abstract suspend fun deletePerson(id: Long)

    @Query(
        "SELECT (SELECT COUNT(*) FROM assoc_members WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM loan_tx WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM sales WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM accounts WHERE personId = :id)"
    )
    abstract suspend fun personUsage(id: Long): Int

    // ---------------- Associations ----------------
    @Query("SELECT * FROM associations ORDER BY createdAt DESC")
    abstract fun associationsFlow(): Flow<List<Association>>

    @Query("SELECT * FROM associations")
    abstract suspend fun allAssociations(): List<Association>

    @Query("SELECT * FROM associations WHERE id = :id")
    abstract fun associationFlow(id: Long): Flow<Association?>

    @Query("SELECT * FROM associations WHERE id = :id")
    abstract suspend fun association(id: Long): Association?

    @Insert
    abstract suspend fun insertAssociation(a: Association): Long

    @Update
    abstract suspend fun updateAssociation(a: Association)

    @Query("DELETE FROM associations WHERE id = :id")
    abstract suspend fun deleteAssociationRow(id: Long)

    @Query("SELECT * FROM assoc_members ORDER BY turnOrder")
    abstract fun allMembersFlow(): Flow<List<AssocMember>>

    @Query("SELECT * FROM assoc_members")
    abstract suspend fun allMembers(): List<AssocMember>

    @Query("SELECT * FROM assoc_members WHERE associationId = :aid ORDER BY turnOrder")
    abstract fun membersFlow(aid: Long): Flow<List<AssocMember>>

    @Query("SELECT * FROM assoc_members WHERE associationId = :aid ORDER BY turnOrder")
    abstract suspend fun members(aid: Long): List<AssocMember>

    @Insert
    abstract suspend fun insertMember(m: AssocMember): Long

    @Update
    abstract suspend fun updateMember(m: AssocMember)

    @Query("DELETE FROM assoc_members WHERE id = :id")
    abstract suspend fun deleteMemberRow(id: Long)

    @Query("DELETE FROM assoc_members WHERE associationId = :aid")
    abstract suspend fun deleteMembersOf(aid: Long)

    @Query("SELECT * FROM assoc_payments")
    abstract fun allAssocPaymentsFlow(): Flow<List<AssocPayment>>

    @Query("SELECT * FROM assoc_payments")
    abstract suspend fun allAssocPayments(): List<AssocPayment>

    @Query("SELECT * FROM assoc_payments WHERE associationId = :aid")
    abstract fun assocPaymentsFlow(aid: Long): Flow<List<AssocPayment>>

    @Insert
    abstract suspend fun insertAssocPayment(p: AssocPayment): Long

    @Query("DELETE FROM assoc_payments WHERE associationId = :aid AND memberId = :mid AND round = :round")
    abstract suspend fun deleteAssocPayment(aid: Long, mid: Long, round: Int)

    @Query("DELETE FROM assoc_payments WHERE memberId = :mid")
    abstract suspend fun deletePaymentsOfMember(mid: Long)

    @Query("DELETE FROM assoc_payments WHERE associationId = :aid")
    abstract suspend fun deletePaymentsOf(aid: Long)

    @Query("SELECT * FROM assoc_payouts")
    abstract fun allPayoutsFlow(): Flow<List<AssocPayout>>

    @Query("SELECT * FROM assoc_payouts")
    abstract suspend fun allPayouts(): List<AssocPayout>

    @Query("SELECT * FROM assoc_payouts WHERE associationId = :aid")
    abstract fun payoutsFlow(aid: Long): Flow<List<AssocPayout>>

    @Insert
    abstract suspend fun insertPayout(p: AssocPayout): Long

    @Query("DELETE FROM assoc_payouts WHERE associationId = :aid AND round = :round")
    abstract suspend fun deletePayout(aid: Long, round: Int)

    @Query("DELETE FROM assoc_payouts WHERE memberId = :mid")
    abstract suspend fun deletePayoutsOfMember(mid: Long)

    @Query("DELETE FROM assoc_payouts WHERE associationId = :aid")
    abstract suspend fun deletePayoutsOf(aid: Long)

    @Transaction
    open suspend fun removeMember(mid: Long) {
        deletePaymentsOfMember(mid)
        deletePayoutsOfMember(mid)
        deleteMemberRow(mid)
    }

    @Transaction
    open suspend fun deleteAssociationFull(aid: Long) {
        deletePaymentsOf(aid)
        deletePayoutsOf(aid)
        deleteMembersOf(aid)
        deleteAssociationRow(aid)
    }

    // ---------------- Loans ----------------
    @Query("SELECT * FROM loan_tx ORDER BY date, id")
    abstract fun loanTxFlow(): Flow<List<LoanTx>>

    @Query("SELECT * FROM loan_tx ORDER BY date, id")
    abstract suspend fun allLoanTx(): List<LoanTx>

    @Query("SELECT * FROM loan_tx WHERE personId = :pid ORDER BY date, id")
    abstract fun loanTxForPersonFlow(pid: Long): Flow<List<LoanTx>>

    @Query("SELECT * FROM loan_tx WHERE personId = :pid ORDER BY date, id")
    abstract suspend fun loanTxForPerson(pid: Long): List<LoanTx>

    @Insert
    abstract suspend fun insertLoanTx(t: LoanTx): Long

    @Query("DELETE FROM loan_tx WHERE id = :id")
    abstract suspend fun deleteLoanTx(id: Long)

    @Query("DELETE FROM loan_tx WHERE personId = :pid")
    abstract suspend fun deleteLoansOf(pid: Long)

    // ---------------- Installment sales ----------------
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    abstract fun salesFlow(): Flow<List<Sale>>

    @Query("SELECT * FROM sales")
    abstract suspend fun allSales(): List<Sale>

    @Query("SELECT * FROM sales WHERE id = :id")
    abstract fun saleFlow(id: Long): Flow<Sale?>

    @Query("SELECT * FROM sales WHERE id = :id")
    abstract suspend fun sale(id: Long): Sale?

    @Insert
    abstract suspend fun insertSale(s: Sale): Long

    @Update
    abstract suspend fun updateSale(s: Sale)

    @Query("DELETE FROM sales WHERE id = :id")
    abstract suspend fun deleteSaleRow(id: Long)

    @Query("SELECT * FROM sale_payments ORDER BY date, id")
    abstract fun allSalePaymentsFlow(): Flow<List<SalePayment>>

    @Query("SELECT * FROM sale_payments ORDER BY date, id")
    abstract suspend fun allSalePayments(): List<SalePayment>

    @Query("SELECT * FROM sale_payments WHERE saleId = :sid ORDER BY date, id")
    abstract fun salePaymentsFlow(sid: Long): Flow<List<SalePayment>>

    @Insert
    abstract suspend fun insertSalePayment(p: SalePayment): Long

    @Query("DELETE FROM sale_payments WHERE id = :id")
    abstract suspend fun deleteSalePayment(id: Long)

    @Query("DELETE FROM sale_payments WHERE saleId = :sid")
    abstract suspend fun deletePaymentsOfSale(sid: Long)

    @Transaction
    open suspend fun deleteSaleFull(sid: Long) {
        deleteLinkedOfSale(sid)
        deletePaymentsOfSale(sid)
        deleteSaleRow(sid)
    }

    // ---------------- Accounts ----------------
    @Query("SELECT * FROM accounts ORDER BY name COLLATE NOCASE")
    abstract fun accountsFlow(): Flow<List<Account>>

    @Query("SELECT * FROM accounts WHERE id = :id")
    abstract fun accountFlow(id: Long): Flow<Account?>

    @Insert
    abstract suspend fun insertAccount(a: Account): Long

    @Update
    abstract suspend fun updateAccount(a: Account)

    @Query("DELETE FROM accounts WHERE id = :id")
    abstract suspend fun deleteAccountRow(id: Long)

    @Query("SELECT * FROM account_tx ORDER BY date, id")
    abstract fun allAccountTxFlow(): Flow<List<AccountTx>>

    @Query("SELECT * FROM account_tx WHERE accountId = :aid ORDER BY date, id")
    abstract fun accountTxFlow(aid: Long): Flow<List<AccountTx>>

    @Insert
    abstract suspend fun insertAccountTx(t: AccountTx): Long

    @Update
    abstract suspend fun updateAccountTx(t: AccountTx)

    @Query("DELETE FROM account_tx WHERE id = :id")
    abstract suspend fun deleteAccountTx(id: Long)

    @Query("DELETE FROM account_tx WHERE accountId = :aid")
    abstract suspend fun deleteTxOfAccount(aid: Long)

    @Transaction
    open suspend fun deleteAccountFull(aid: Long) {
        deleteTxOfAccount(aid)
        deleteAccountRow(aid)
    }

    // ---------------- Attachments ----------------
    @Query("SELECT * FROM attachments WHERE ownerType = :type AND ownerId = :id ORDER BY createdAt")
    abstract fun attachmentsFlow(type: String, id: Long): Flow<List<Attachment>>

    @Query("SELECT * FROM attachments WHERE ownerType = :type AND ownerId = :id")
    abstract suspend fun attachmentsOf(type: String, id: Long): List<Attachment>

    @Insert
    abstract suspend fun insertAttachment(a: Attachment): Long

    @Query("DELETE FROM attachments WHERE id = :id")
    abstract suspend fun deleteAttachment(id: Long)

    // ---------------- ترحيل الحركات إلى الحسابات ----------------
    @Query("SELECT * FROM accounts ORDER BY name COLLATE NOCASE")
    abstract suspend fun allAccounts(): List<Account>

    @Query("SELECT * FROM account_tx WHERE srcType IS NOT NULL")
    abstract fun linkedAccountTxFlow(): Flow<List<AccountTx>>

    @Query("DELETE FROM account_tx WHERE srcType = :type AND srcId = :id")
    abstract suspend fun deleteLinkedTx(type: String, id: Long)

    @Query("DELETE FROM account_tx WHERE srcType = 'LOAN_TX' AND srcId IN (SELECT id FROM loan_tx WHERE personId = :pid)")
    abstract suspend fun deleteLinkedOfPersonLoans(pid: Long)

    @Query("DELETE FROM account_tx WHERE (srcType = 'SALE_PAY' AND srcId IN (SELECT id FROM sale_payments WHERE saleId = :sid)) OR (srcType = 'SALE_DOWN' AND srcId = :sid)")
    abstract suspend fun deleteLinkedOfSale(sid: Long)

    // ---------------- مصاريف المعيشة ----------------
    @Query("SELECT * FROM liv_items ORDER BY kind DESC, category, name")
    abstract fun livItemsFlow(): Flow<List<LivItem>>

    @Insert
    abstract suspend fun insertLivItem(i: LivItem): Long

    @Update
    abstract suspend fun updateLivItem(i: LivItem)

    @Query("DELETE FROM liv_items WHERE id = :id")
    abstract suspend fun deleteLivItem(id: Long)

    @Query("SELECT * FROM liv_periods ORDER BY startDate DESC")
    abstract fun livPeriodsFlow(): Flow<List<LivPeriod>>

    @Query("SELECT * FROM liv_periods WHERE id = :id")
    abstract fun livPeriodFlow(id: Long): Flow<LivPeriod?>

    @Insert
    abstract suspend fun insertLivPeriod(p: LivPeriod): Long

    @Update
    abstract suspend fun updateLivPeriod(p: LivPeriod)

    @Query("SELECT * FROM liv_entries ORDER BY date, id")
    abstract fun allLivEntriesFlow(): Flow<List<LivEntry>>

    @Query("SELECT * FROM liv_entries WHERE periodId = :pid ORDER BY date, id")
    abstract fun livEntriesFlow(pid: Long): Flow<List<LivEntry>>

    @Insert
    abstract suspend fun insertLivEntry(e: LivEntry): Long

    @Query("DELETE FROM liv_entries WHERE id = :id")
    abstract suspend fun deleteLivEntry(id: Long)

    @Query("DELETE FROM liv_entries WHERE periodId = :pid")
    abstract suspend fun deleteLivEntriesOf(pid: Long)

    @Query("DELETE FROM liv_periods WHERE id = :id")
    abstract suspend fun deleteLivPeriodRow(id: Long)

    @Query("DELETE FROM account_tx WHERE srcType = 'LIV' AND srcId IN (SELECT id FROM liv_entries WHERE periodId = :pid)")
    abstract suspend fun deleteLinkedOfLivPeriod(pid: Long)

    @Transaction
    open suspend fun deleteLivPeriodFull(pid: Long) {
        deleteLinkedOfLivPeriod(pid)
        deleteLivEntriesOf(pid)
        deleteLivPeriodRow(pid)
    }

    // ---------------- قوائم كاملة (للتصدير واللوحة والبحث) ----------------
    @Query("SELECT * FROM account_tx ORDER BY date, id")
    abstract suspend fun allAccountTx(): List<AccountTx>

    @Query("SELECT * FROM liv_periods ORDER BY startDate DESC")
    abstract suspend fun allLivPeriods(): List<LivPeriod>

    @Query("SELECT * FROM liv_entries ORDER BY date, id")
    abstract suspend fun allLivEntries(): List<LivEntry>

    @Query("SELECT * FROM liv_items ORDER BY kind DESC, category, name")
    abstract suspend fun allLivItems(): List<LivItem>

    @Query("SELECT * FROM liv_entries WHERE periodId = :pid")
    abstract suspend fun livEntriesOnce(pid: Long): List<LivEntry>

    // ---------------- العقارات والإيجارات ----------------
    @Query("SELECT * FROM properties ORDER BY name")
    abstract fun propertiesFlow(): Flow<List<Property>>
    @Query("SELECT * FROM properties WHERE id = :id")
    abstract fun propertyFlow(id: Long): Flow<Property?>
    @Query("SELECT * FROM properties ORDER BY name")
    abstract suspend fun allProperties(): List<Property>
    @Insert abstract suspend fun insertProperty(p: Property): Long
    @Update abstract suspend fun updateProperty(p: Property)

    @Query("SELECT * FROM prop_units ORDER BY propertyId, name")
    abstract fun unitsFlow(): Flow<List<PropUnit>>
    @Query("SELECT * FROM prop_units ORDER BY propertyId, name")
    abstract suspend fun allUnits(): List<PropUnit>
    @Insert abstract suspend fun insertUnit(u: PropUnit): Long
    @Update abstract suspend fun updateUnit(u: PropUnit)

    @Query("SELECT * FROM leases ORDER BY startDate DESC")
    abstract fun leasesFlow(): Flow<List<Lease>>
    @Query("SELECT * FROM leases WHERE id = :id")
    abstract fun leaseFlow(id: Long): Flow<Lease?>
    @Query("SELECT * FROM leases ORDER BY startDate DESC")
    abstract suspend fun allLeases(): List<Lease>
    @Insert abstract suspend fun insertLease(l: Lease): Long
    @Update abstract suspend fun updateLease(l: Lease)

    @Query("SELECT * FROM lease_payments ORDER BY date, id")
    abstract fun leasePaymentsFlow(): Flow<List<LeasePayment>>
    @Query("SELECT * FROM lease_payments ORDER BY date, id")
    abstract suspend fun allLeasePayments(): List<LeasePayment>
    @Insert abstract suspend fun insertLeasePayment(p: LeasePayment): Long
    @Query("DELETE FROM lease_payments WHERE id = :id")
    abstract suspend fun deleteLeasePayment(id: Long)

    @Query("SELECT * FROM prop_expenses ORDER BY date DESC, id DESC")
    abstract fun propExpensesFlow(): Flow<List<PropExpense>>
    @Query("SELECT * FROM prop_expenses ORDER BY date DESC, id DESC")
    abstract suspend fun allPropExpenses(): List<PropExpense>
    @Insert abstract suspend fun insertPropExpense(e: PropExpense): Long
    @Query("DELETE FROM prop_expenses WHERE id = :id")
    abstract suspend fun deletePropExpense(id: Long)

    @Query("DELETE FROM account_tx WHERE (srcType = 'RENT_PAY' AND srcId IN (SELECT id FROM lease_payments WHERE leaseId = :lid)) OR (srcType = 'LEASE_DEP' AND srcId = :lid)")
    abstract suspend fun deleteLinkedOfLease(lid: Long)
    @Query("DELETE FROM lease_payments WHERE leaseId = :lid")
    abstract suspend fun deleteLeasePaymentsOf(lid: Long)
    @Query("DELETE FROM leases WHERE id = :lid")
    abstract suspend fun deleteLeaseRow(lid: Long)

    @Transaction
    open suspend fun deleteLeaseFull(lid: Long) {
        deleteLinkedOfLease(lid); deleteLeasePaymentsOf(lid); deleteLeaseRow(lid)
    }

    @Query("SELECT id FROM leases WHERE unitId = :uid")
    abstract suspend fun leaseIdsOfUnit(uid: Long): List<Long>
    @Query("DELETE FROM prop_units WHERE id = :uid")
    abstract suspend fun deleteUnitRow(uid: Long)

    @Transaction
    open suspend fun deleteUnitFull(uid: Long) {
        leaseIdsOfUnit(uid).forEach { deleteLeaseFull(it) }
        deleteUnitRow(uid)
    }

    @Query("SELECT id FROM prop_units WHERE propertyId = :pid")
    abstract suspend fun unitIdsOf(pid: Long): List<Long>
    @Query("DELETE FROM account_tx WHERE srcType = 'PROP_EXP' AND srcId IN (SELECT id FROM prop_expenses WHERE propertyId = :pid)")
    abstract suspend fun deleteLinkedOfPropExpenses(pid: Long)
    @Query("DELETE FROM prop_expenses WHERE propertyId = :pid")
    abstract suspend fun deletePropExpensesOf(pid: Long)
    @Query("DELETE FROM properties WHERE id = :pid")
    abstract suspend fun deletePropertyRow(pid: Long)

    @Transaction
    open suspend fun deletePropertyFull(pid: Long) {
        unitIdsOf(pid).forEach { deleteUnitFull(it) }
        deleteLinkedOfPropExpenses(pid); deletePropExpensesOf(pid); deletePropertyRow(pid)
    }

    // ---------------- ديوني ----------------
    @Query("SELECT * FROM debts ORDER BY closed, priority, createdAt DESC")
    abstract fun debtsFlow(): Flow<List<Debt>>
    @Query("SELECT * FROM debts WHERE id = :id")
    abstract fun debtFlow(id: Long): Flow<Debt?>
    @Query("SELECT * FROM debts")
    abstract suspend fun allDebts(): List<Debt>
    @Insert abstract suspend fun insertDebt(d: Debt): Long
    @Update abstract suspend fun updateDebt(d: Debt)

    @Query("SELECT * FROM debt_tx ORDER BY date, id")
    abstract fun debtTxFlow(): Flow<List<DebtTx>>
    @Query("SELECT * FROM debt_tx ORDER BY date, id")
    abstract suspend fun allDebtTx(): List<DebtTx>
    @Insert abstract suspend fun insertDebtTx(t: DebtTx): Long
    @Query("DELETE FROM debt_tx WHERE id = :id")
    abstract suspend fun deleteDebtTx(id: Long)

    @Query("DELETE FROM account_tx WHERE srcType = 'DEBT_TX' AND srcId IN (SELECT id FROM debt_tx WHERE debtId = :did)")
    abstract suspend fun deleteLinkedOfDebt(did: Long)
    @Query("DELETE FROM debt_tx WHERE debtId = :did")
    abstract suspend fun deleteDebtTxOf(did: Long)
    @Query("DELETE FROM debts WHERE id = :did")
    abstract suspend fun deleteDebtRow(did: Long)

    @Transaction
    open suspend fun deleteDebtFull(did: Long) {
        deleteLinkedOfDebt(did); deleteDebtTxOf(did); deleteDebtRow(did)
    }

    // ---------------- العمال، الأصول، التقسيم، السيارة، الاشتراكات ----------------
    @Query("SELECT * FROM workers ORDER BY active DESC, name")
    abstract fun workersFlow(): Flow<List<Worker>>
    @Query("SELECT * FROM workers ORDER BY active DESC, name")
    abstract suspend fun allWorkers(): List<Worker>
    @Insert abstract suspend fun insertWorker(x: Worker): Long
    @Update abstract suspend fun updateWorker(x: Worker)
    @Query("DELETE FROM workers WHERE id = :id")
    abstract suspend fun deleteWorker(id: Long)
    @Query("SELECT * FROM workers WHERE id = :id")
    abstract fun workerFlow(id: Long): Flow<Worker?>

    @Query("SELECT * FROM worker_entries ORDER BY date, id")
    abstract fun workerEntrysFlow(): Flow<List<WorkerEntry>>
    @Query("SELECT * FROM worker_entries ORDER BY date, id")
    abstract suspend fun allWorkerEntrys(): List<WorkerEntry>
    @Insert abstract suspend fun insertWorkerEntry(x: WorkerEntry): Long
    @Update abstract suspend fun updateWorkerEntry(x: WorkerEntry)
    @Query("DELETE FROM worker_entries WHERE id = :id")
    abstract suspend fun deleteWorkerEntry(id: Long)
    @Query("DELETE FROM worker_entries WHERE workerId = :pid")
    abstract suspend fun deleteWorkerEntrysOf(pid: Long)

    @Query("SELECT * FROM assets ORDER BY sold, type, name")
    abstract fun assetsFlow(): Flow<List<Asset>>
    @Query("SELECT * FROM assets ORDER BY sold, type, name")
    abstract suspend fun allAssets(): List<Asset>
    @Insert abstract suspend fun insertAsset(x: Asset): Long
    @Update abstract suspend fun updateAsset(x: Asset)
    @Query("DELETE FROM assets WHERE id = :id")
    abstract suspend fun deleteAsset(id: Long)
    @Query("SELECT * FROM assets WHERE id = :id")
    abstract fun assetFlow(id: Long): Flow<Asset?>

    @Query("SELECT * FROM split_groups ORDER BY closed, createdAt DESC")
    abstract fun splitGroupsFlow(): Flow<List<SplitGroup>>
    @Query("SELECT * FROM split_groups ORDER BY closed, createdAt DESC")
    abstract suspend fun allSplitGroups(): List<SplitGroup>
    @Insert abstract suspend fun insertSplitGroup(x: SplitGroup): Long
    @Update abstract suspend fun updateSplitGroup(x: SplitGroup)
    @Query("DELETE FROM split_groups WHERE id = :id")
    abstract suspend fun deleteSplitGroup(id: Long)
    @Query("SELECT * FROM split_groups WHERE id = :id")
    abstract fun splitGroupFlow(id: Long): Flow<SplitGroup?>

    @Query("SELECT * FROM split_members ORDER BY isMe DESC, id")
    abstract fun splitMembersFlow(): Flow<List<SplitMember>>
    @Query("SELECT * FROM split_members ORDER BY isMe DESC, id")
    abstract suspend fun allSplitMembers(): List<SplitMember>
    @Insert abstract suspend fun insertSplitMember(x: SplitMember): Long
    @Update abstract suspend fun updateSplitMember(x: SplitMember)
    @Query("DELETE FROM split_members WHERE id = :id")
    abstract suspend fun deleteSplitMember(id: Long)
    @Query("DELETE FROM split_members WHERE groupId = :pid")
    abstract suspend fun deleteSplitMembersOf(pid: Long)

    @Query("SELECT * FROM split_expenses ORDER BY date DESC, id DESC")
    abstract fun splitExpensesFlow(): Flow<List<SplitExpense>>
    @Query("SELECT * FROM split_expenses ORDER BY date DESC, id DESC")
    abstract suspend fun allSplitExpenses(): List<SplitExpense>
    @Insert abstract suspend fun insertSplitExpense(x: SplitExpense): Long
    @Update abstract suspend fun updateSplitExpense(x: SplitExpense)
    @Query("DELETE FROM split_expenses WHERE id = :id")
    abstract suspend fun deleteSplitExpense(id: Long)
    @Query("DELETE FROM split_expenses WHERE groupId = :pid")
    abstract suspend fun deleteSplitExpensesOf(pid: Long)

    @Query("SELECT * FROM split_settles ORDER BY date DESC, id DESC")
    abstract fun splitSettlesFlow(): Flow<List<SplitSettle>>
    @Query("SELECT * FROM split_settles ORDER BY date DESC, id DESC")
    abstract suspend fun allSplitSettles(): List<SplitSettle>
    @Insert abstract suspend fun insertSplitSettle(x: SplitSettle): Long
    @Update abstract suspend fun updateSplitSettle(x: SplitSettle)
    @Query("DELETE FROM split_settles WHERE id = :id")
    abstract suspend fun deleteSplitSettle(id: Long)
    @Query("DELETE FROM split_settles WHERE groupId = :pid")
    abstract suspend fun deleteSplitSettlesOf(pid: Long)

    @Query("SELECT * FROM vehicles ORDER BY name")
    abstract fun vehiclesFlow(): Flow<List<Vehicle>>
    @Query("SELECT * FROM vehicles ORDER BY name")
    abstract suspend fun allVehicles(): List<Vehicle>
    @Insert abstract suspend fun insertVehicle(x: Vehicle): Long
    @Update abstract suspend fun updateVehicle(x: Vehicle)
    @Query("DELETE FROM vehicles WHERE id = :id")
    abstract suspend fun deleteVehicle(id: Long)
    @Query("SELECT * FROM vehicles WHERE id = :id")
    abstract fun vehicleFlow(id: Long): Flow<Vehicle?>

    @Query("SELECT * FROM car_expenses ORDER BY date DESC, id DESC")
    abstract fun carExpensesFlow(): Flow<List<CarExpense>>
    @Query("SELECT * FROM car_expenses ORDER BY date DESC, id DESC")
    abstract suspend fun allCarExpenses(): List<CarExpense>
    @Insert abstract suspend fun insertCarExpense(x: CarExpense): Long
    @Update abstract suspend fun updateCarExpense(x: CarExpense)
    @Query("DELETE FROM car_expenses WHERE id = :id")
    abstract suspend fun deleteCarExpense(id: Long)
    @Query("DELETE FROM car_expenses WHERE vehicleId = :pid")
    abstract suspend fun deleteCarExpensesOf(pid: Long)

    @Query("SELECT * FROM car_reminders ORDER BY id")
    abstract fun carRemindersFlow(): Flow<List<CarReminder>>
    @Query("SELECT * FROM car_reminders ORDER BY id")
    abstract suspend fun allCarReminders(): List<CarReminder>
    @Insert abstract suspend fun insertCarReminder(x: CarReminder): Long
    @Update abstract suspend fun updateCarReminder(x: CarReminder)
    @Query("DELETE FROM car_reminders WHERE id = :id")
    abstract suspend fun deleteCarReminder(id: Long)
    @Query("DELETE FROM car_reminders WHERE vehicleId = :pid")
    abstract suspend fun deleteCarRemindersOf(pid: Long)

    @Query("SELECT * FROM subscriptions ORDER BY active DESC, nextDate")
    abstract fun subscriptionsFlow(): Flow<List<Subscription>>
    @Query("SELECT * FROM subscriptions ORDER BY active DESC, nextDate")
    abstract suspend fun allSubscriptions(): List<Subscription>
    @Insert abstract suspend fun insertSubscription(x: Subscription): Long
    @Update abstract suspend fun updateSubscription(x: Subscription)
    @Query("DELETE FROM subscriptions WHERE id = :id")
    abstract suspend fun deleteSubscription(id: Long)
    @Query("SELECT * FROM subscriptions WHERE id = :id")
    abstract fun subscriptionFlow(id: Long): Flow<Subscription?>

    @Query("SELECT * FROM sub_payments ORDER BY date DESC, id DESC")
    abstract fun subPaymentsFlow(): Flow<List<SubPayment>>
    @Query("SELECT * FROM sub_payments ORDER BY date DESC, id DESC")
    abstract suspend fun allSubPayments(): List<SubPayment>
    @Insert abstract suspend fun insertSubPayment(x: SubPayment): Long
    @Update abstract suspend fun updateSubPayment(x: SubPayment)
    @Query("DELETE FROM sub_payments WHERE id = :id")
    abstract suspend fun deleteSubPayment(id: Long)
    @Query("DELETE FROM sub_payments WHERE subId = :pid")
    abstract suspend fun deleteSubPaymentsOf(pid: Long)


    @Query("DELETE FROM liv_entries WHERE itemId = :code")
    abstract suspend fun deleteLivByCode(code: Long)

    @Query("DELETE FROM account_tx WHERE srcType = :type AND srcId IN (SELECT id FROM worker_entries WHERE workerId = :pid)")
    abstract suspend fun deleteLinkedOfWorker(type: String, pid: Long)
    @Query("DELETE FROM liv_entries WHERE itemId <= -3000000000000 AND itemId > -4000000000000 AND (-itemId - 3000000000000) IN (SELECT id FROM worker_entries WHERE workerId = :pid)")
    abstract suspend fun deleteLivOfWorker(pid: Long)
    @Transaction
    open suspend fun deleteWorkerFull(pid: Long) {
        deleteLinkedOfWorker("WORKER_TX", pid); deleteLivOfWorker(pid); deleteWorkerEntrysOf(pid); deleteWorker(pid)
    }

    @Query("DELETE FROM account_tx WHERE srcType = 'CAR_EXP' AND srcId IN (SELECT id FROM car_expenses WHERE vehicleId = :pid)")
    abstract suspend fun deleteLinkedOfCar(pid: Long)
    @Query("DELETE FROM liv_entries WHERE itemId <= -2000000000000 AND itemId > -3000000000000 AND (-itemId - 2000000000000) IN (SELECT id FROM car_expenses WHERE vehicleId = :pid)")
    abstract suspend fun deleteLivOfCar(pid: Long)
    @Transaction
    open suspend fun deleteVehicleFull(pid: Long) {
        deleteLinkedOfCar(pid); deleteLivOfCar(pid); deleteCarExpensesOf(pid); deleteCarRemindersOf(pid); deleteVehicle(pid)
    }

    @Query("DELETE FROM account_tx WHERE srcType = 'SUB_PAY' AND srcId IN (SELECT id FROM sub_payments WHERE subId = :pid)")
    abstract suspend fun deleteLinkedOfSub(pid: Long)
    @Query("DELETE FROM liv_entries WHERE itemId <= -1000000000000 AND itemId > -2000000000000 AND (-itemId - 1000000000000) IN (SELECT id FROM sub_payments WHERE subId = :pid)")
    abstract suspend fun deleteLivOfSub(pid: Long)
    @Transaction
    open suspend fun deleteSubscriptionFull(pid: Long) {
        deleteLinkedOfSub(pid); deleteLivOfSub(pid); deleteSubPaymentsOf(pid); deleteSubscription(pid)
    }

    @Query("DELETE FROM account_tx WHERE srcType = 'SPLIT_EXP' AND srcId IN (SELECT id FROM split_expenses WHERE groupId = :pid)")
    abstract suspend fun deleteLinkedOfSplit(pid: Long)
    @Transaction
    open suspend fun deleteSplitGroupFull(pid: Long) {
        deleteLinkedOfSplit(pid); deleteSplitExpensesOf(pid); deleteSplitSettlesOf(pid); deleteSplitMembersOf(pid); deleteSplitGroup(pid)
    }

    // ---------------- المحل والمخزون والفواتير، خزنة المستندات ----------------
    @Query("SELECT * FROM products ORDER BY active DESC, name")
    abstract fun productsFlow(): Flow<List<Product>>
    @Query("SELECT * FROM products ORDER BY active DESC, name")
    abstract suspend fun allProducts(): List<Product>
    @Insert abstract suspend fun insertProduct(x: Product): Long
    @Update abstract suspend fun updateProduct(x: Product)
    @Query("DELETE FROM products WHERE id = :id")
    abstract suspend fun deleteProduct(id: Long)
    @Query("SELECT * FROM products WHERE id = :id")
    abstract fun productFlow(id: Long): Flow<Product?>

    @Query("SELECT * FROM invoices ORDER BY date DESC, id DESC")
    abstract fun invoicesFlow(): Flow<List<Invoice>>
    @Query("SELECT * FROM invoices ORDER BY date DESC, id DESC")
    abstract suspend fun allInvoices(): List<Invoice>
    @Insert abstract suspend fun insertInvoice(x: Invoice): Long
    @Update abstract suspend fun updateInvoice(x: Invoice)
    @Query("DELETE FROM invoices WHERE id = :id")
    abstract suspend fun deleteInvoice(id: Long)
    @Query("SELECT * FROM invoices WHERE id = :id")
    abstract fun invoiceFlow(id: Long): Flow<Invoice?>

    @Query("SELECT * FROM invoice_items ORDER BY id")
    abstract fun invoiceItemsFlow(): Flow<List<InvoiceItem>>
    @Query("SELECT * FROM invoice_items ORDER BY id")
    abstract suspend fun allInvoiceItems(): List<InvoiceItem>
    @Insert abstract suspend fun insertInvoiceItem(x: InvoiceItem): Long
    @Update abstract suspend fun updateInvoiceItem(x: InvoiceItem)
    @Query("DELETE FROM invoice_items WHERE id = :id")
    abstract suspend fun deleteInvoiceItem(id: Long)
    @Query("DELETE FROM invoice_items WHERE invoiceId = :pid")
    abstract suspend fun deleteInvoiceItemsOf(pid: Long)

    @Query("SELECT * FROM invoice_payments ORDER BY date, id")
    abstract fun invoicePaymentsFlow(): Flow<List<InvoicePayment>>
    @Query("SELECT * FROM invoice_payments ORDER BY date, id")
    abstract suspend fun allInvoicePayments(): List<InvoicePayment>
    @Insert abstract suspend fun insertInvoicePayment(x: InvoicePayment): Long
    @Update abstract suspend fun updateInvoicePayment(x: InvoicePayment)
    @Query("DELETE FROM invoice_payments WHERE id = :id")
    abstract suspend fun deleteInvoicePayment(id: Long)
    @Query("DELETE FROM invoice_payments WHERE invoiceId = :pid")
    abstract suspend fun deleteInvoicePaymentsOf(pid: Long)

    @Query("SELECT * FROM stock_adjs ORDER BY date, id")
    abstract fun stockAdjsFlow(): Flow<List<StockAdj>>
    @Query("SELECT * FROM stock_adjs ORDER BY date, id")
    abstract suspend fun allStockAdjs(): List<StockAdj>
    @Insert abstract suspend fun insertStockAdj(x: StockAdj): Long
    @Update abstract suspend fun updateStockAdj(x: StockAdj)
    @Query("DELETE FROM stock_adjs WHERE id = :id")
    abstract suspend fun deleteStockAdj(id: Long)
    @Query("DELETE FROM stock_adjs WHERE productId = :pid")
    abstract suspend fun deleteStockAdjsOf(pid: Long)

    @Query("SELECT * FROM vault_docs ORDER BY expiryDate IS NULL, expiryDate, title")
    abstract fun vaultDocsFlow(): Flow<List<VaultDoc>>
    @Query("SELECT * FROM vault_docs ORDER BY expiryDate IS NULL, expiryDate, title")
    abstract suspend fun allVaultDocs(): List<VaultDoc>
    @Insert abstract suspend fun insertVaultDoc(x: VaultDoc): Long
    @Update abstract suspend fun updateVaultDoc(x: VaultDoc)
    @Query("DELETE FROM vault_docs WHERE id = :id")
    abstract suspend fun deleteVaultDoc(id: Long)
    @Query("SELECT * FROM vault_docs WHERE id = :id")
    abstract fun vaultDocFlow(id: Long): Flow<VaultDoc?>

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :id ORDER BY id")
    abstract suspend fun itemsOfInvoice(id: Long): List<InvoiceItem>
    @Query("SELECT COALESCE(MAX(number), 0) FROM invoices WHERE type = :type")
    abstract suspend fun maxInvoiceNumber(type: String): Long
    @Query("DELETE FROM account_tx WHERE srcType = 'INV_PAY' AND srcId IN (SELECT id FROM invoice_payments WHERE invoiceId = :pid)")
    abstract suspend fun deleteLinkedOfInvoice(pid: Long)
    @Transaction
    open suspend fun deleteInvoiceFull(pid: Long) {
        deleteLinkedOfInvoice(pid); deleteInvoiceItemsOf(pid); deleteInvoicePaymentsOf(pid); deleteInvoice(pid)
    }
    @Transaction
    open suspend fun saveInvoice(inv: Invoice, items: List<InvoiceItem>): Long {
        val id = if (inv.id == 0L) insertInvoice(inv) else { updateInvoice(inv); deleteInvoiceItemsOf(inv.id); inv.id }
        items.forEach { insertInvoiceItem(it.copy(id = 0, invoiceId = id)) }
        return id
    }
    @Transaction
    open suspend fun deleteProductFull(pid: Long) { deleteStockAdjsOf(pid); deleteProduct(pid) }

    // ---------------- العملاء والموردون ----------------
    @Query("SELECT * FROM parties ORDER BY type, name")
    abstract fun partysFlow(): Flow<List<Party>>
    @Query("SELECT * FROM parties ORDER BY type, name")
    abstract suspend fun allPartys(): List<Party>
    @Insert abstract suspend fun insertParty(x: Party): Long
    @Update abstract suspend fun updateParty(x: Party)
    @Query("DELETE FROM parties WHERE id = :id")
    abstract suspend fun deleteParty(id: Long)
    @Query("SELECT * FROM parties WHERE id = :id")
    abstract fun partyFlow(id: Long): Flow<Party?>

    @Query("SELECT * FROM party_tx ORDER BY date, id")
    abstract fun partyTxsFlow(): Flow<List<PartyTx>>
    @Query("SELECT * FROM party_tx ORDER BY date, id")
    abstract suspend fun allPartyTxs(): List<PartyTx>
    @Insert abstract suspend fun insertPartyTx(x: PartyTx): Long
    @Update abstract suspend fun updatePartyTx(x: PartyTx)
    @Query("DELETE FROM party_tx WHERE id = :id")
    abstract suspend fun deletePartyTx(id: Long)
    @Query("DELETE FROM party_tx WHERE partyId = :pid")
    abstract suspend fun deletePartyTxsOf(pid: Long)

    @Query("SELECT COUNT(*) FROM parties WHERE type = :type")
    abstract suspend fun countParties(type: String): Int
    @Query("UPDATE invoices SET partyId = :pid WHERE id = :iid")
    abstract suspend fun setInvoiceParty(iid: Long, pid: Long)
    @Query("DELETE FROM account_tx WHERE srcType = 'PARTY_TX' AND srcId IN (SELECT id FROM party_tx WHERE partyId = :pid)")
    abstract suspend fun deleteLinkedOfParty(pid: Long)
    @Query("UPDATE invoices SET partyId = NULL WHERE partyId = :pid")
    abstract suspend fun unlinkPartyInvoices(pid: Long)
    @Transaction
    open suspend fun deletePartyFull(pid: Long) { deleteLinkedOfParty(pid); deletePartyTxsOf(pid); unlinkPartyInvoices(pid); deleteParty(pid) }

    // ---------------- دفتر البقالة ----------------
    @Query("SELECT * FROM credit_books ORDER BY closed, name")
    abstract fun creditBooksFlow(): Flow<List<CreditBook>>
    @Query("SELECT * FROM credit_books ORDER BY closed, name")
    abstract suspend fun allCreditBooks(): List<CreditBook>
    @Insert abstract suspend fun insertCreditBook(x: CreditBook): Long
    @Update abstract suspend fun updateCreditBook(x: CreditBook)
    @Query("DELETE FROM credit_books WHERE id = :id")
    abstract suspend fun deleteCreditBookRow(id: Long)
    @Query("SELECT * FROM credit_entries ORDER BY date, id")
    abstract fun creditEntriesFlow(): Flow<List<CreditEntry>>
    @Query("SELECT * FROM credit_entries ORDER BY date, id")
    abstract suspend fun allCreditEntries(): List<CreditEntry>
    @Insert abstract suspend fun insertCreditEntry(x: CreditEntry): Long
    @Update abstract suspend fun updateCreditEntry(x: CreditEntry)
    @Query("DELETE FROM credit_entries WHERE id = :id")
    abstract suspend fun deleteCreditEntry(id: Long)
    @Query("DELETE FROM credit_entries WHERE bookId = :bid")
    abstract suspend fun deleteCreditEntriesOf(bid: Long)
    @Query("DELETE FROM account_tx WHERE srcType = 'CREDIT' AND srcId IN (SELECT id FROM credit_entries WHERE bookId = :bid)")
    abstract suspend fun deleteLinkedOfCreditBook(bid: Long)
    @Transaction
    open suspend fun deleteCreditBookFull(bid: Long) { deleteLinkedOfCreditBook(bid); deleteCreditEntriesOf(bid); deleteCreditBookRow(bid) }

    // ---------------- الوصفات والسكري والتصاميم ----------------
    @Query("SELECT * FROM user_recipes ORDER BY favorite DESC, name")
    abstract fun userRecipesFlow(): Flow<List<UserRecipe>>
    @Insert abstract suspend fun insertUserRecipe(x: UserRecipe): Long
    @Update abstract suspend fun updateUserRecipe(x: UserRecipe)
    @Query("DELETE FROM user_recipes WHERE id = :id")
    abstract suspend fun deleteUserRecipe(id: Long)

    @Query("SELECT * FROM glucose_logs ORDER BY date DESC, minute DESC")
    abstract fun glucoseFlow(): Flow<List<GlucoseLog>>
    @Insert abstract suspend fun insertGlucose(x: GlucoseLog): Long
    @Query("DELETE FROM glucose_logs WHERE id = :id")
    abstract suspend fun deleteGlucose(id: Long)

    @Query("SELECT * FROM design_projects ORDER BY createdAt DESC")
    abstract fun designsFlow(): Flow<List<DesignProject>>
    @Insert abstract suspend fun insertDesign(x: DesignProject): Long
    @Update abstract suspend fun updateDesign(x: DesignProject)
    @Query("DELETE FROM design_projects WHERE id = :id")
    abstract suspend fun deleteDesign(id: Long)
}
