package com.sho3eb.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
abstract class AppDao {

    // ---------------- People ----------------
    @Query("SELECT * FROM people ORDER BY name COLLATE NOCASE")
    abstract fun peopleFlow(): Flow<List<Person>>

    @Query("SELECT * FROM people")
    abstract suspend fun allPeople(): List<Person>

    @Query("SELECT * FROM people WHERE id = :id")
    abstract suspend fun person(id: Long): Person?

    @Query("SELECT * FROM people WHERE id = :id")
    abstract fun personFlow(id: Long): Flow<Person?>

    @Query("SELECT * FROM people WHERE phone = :phone LIMIT 1")
    abstract suspend fun personByPhone(phone: String): Person?

    @Insert
    abstract suspend fun insertPerson(p: Person): Long

    @Update
    abstract suspend fun updatePerson(p: Person)

    @Query("DELETE FROM people WHERE id = :id")
    abstract suspend fun deletePerson(id: Long)

    @Query(
        "SELECT (SELECT COUNT(*) FROM assoc_members WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM loan_tx WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM sales WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM accounts WHERE personId = :id)"
    )
    abstract suspend fun personUsage(id: Long): Int

    // ---------------- Associations ----------------
    @Query("SELECT * FROM associations ORDER BY createdAt DESC")
    abstract fun associationsFlow(): Flow<List<Association>>

    @Query("SELECT * FROM associations")
    abstract suspend fun allAssociations(): List<Association>

    @Query("SELECT * FROM associations WHERE id = :id")
    abstract fun associationFlow(id: Long): Flow<Association?>

    @Query("SELECT * FROM associations WHERE id = :id")
    abstract suspend fun association(id: Long): Association?

    @Insert
    abstract suspend fun insertAssociation(a: Association): Long

    @Update
    abstract suspend fun updateAssociation(a: Association)

    @Query("DELETE FROM associations WHERE id = :id")
    abstract suspend fun deleteAssociationRow(id: Long)

    @Query("SELECT * FROM assoc_members ORDER BY turnOrder")
    abstract fun allMembersFlow(): Flow<List<AssocMember>>

    @Query("SELECT * FROM assoc_members")
    abstract suspend fun allMembers(): List<AssocMember>

    @Query("SELECT * FROM assoc_members WHERE associationId = :aid ORDER BY turnOrder")
    abstract fun membersFlow(aid: Long): Flow<List<AssocMember>>

    @Query("SELECT * FROM assoc_members WHERE associationId = :aid ORDER BY turnOrder")
    abstract suspend fun members(aid: Long): List<AssocMember>

    @Insert
    abstract suspend fun insertMember(m: AssocMember): Long

    @Update
    abstract suspend fun updateMember(m: AssocMember)

    @Query("DELETE FROM assoc_members WHERE id = :id")
    abstract suspend fun deleteMemberRow(id: Long)

    @Query("DELETE FROM assoc_members WHERE associationId = :aid")
    abstract suspend fun deleteMembersOf(aid: Long)

    @Query("SELECT * FROM assoc_payments")
    abstract fun allAssocPaymentsFlow(): Flow<List<AssocPayment>>

    @Query("SELECT * FROM assoc_payments")
    abstract suspend fun allAssocPayments(): List<AssocPayment>

    @Query("SELECT * FROM assoc_payments WHERE associationId = :aid")
    abstract fun assocPaymentsFlow(aid: Long): Flow<List<AssocPayment>>

    @Insert
    abstract suspend fun insertAssocPayment(p: AssocPayment): Long

    @Query("DELETE FROM assoc_payments WHERE associationId = :aid AND memberId = :mid AND round = :round")
    abstract suspend fun deleteAssocPayment(aid: Long, mid: Long, round: Int)

    @Query("DELETE FROM assoc_payments WHERE memberId = :mid")
    abstract suspend fun deletePaymentsOfMember(mid: Long)

    @Query("DELETE FROM assoc_payments WHERE associationId = :aid")
    abstract suspend fun deletePaymentsOf(aid: Long)

    @Query("SELECT * FROM assoc_payouts")
    abstract fun allPayoutsFlow(): Flow<List<AssocPayout>>

    @Query("SELECT * FROM assoc_payouts")
    abstract suspend fun allPayouts(): List<AssocPayout>

    @Query("SELECT * FROM assoc_payouts WHERE associationId = :aid")
    abstract fun payoutsFlow(aid: Long): Flow<List<AssocPayout>>

    @Insert
    abstract suspend fun insertPayout(p: AssocPayout): Long

    @Query("DELETE FROM assoc_payouts WHERE associationId = :aid AND round = :round")
    abstract suspend fun deletePayout(aid: Long, round: Int)

    @Query("DELETE FROM assoc_payouts WHERE memberId = :mid")
    abstract suspend fun deletePayoutsOfMember(mid: Long)

    @Query("DELETE FROM assoc_payouts WHERE associationId = :aid")
    abstract suspend fun deletePayoutsOf(aid: Long)

    @Transaction
    open suspend fun removeMember(mid: Long) {
        deletePaymentsOfMember(mid)
        deletePayoutsOfMember(mid)
        deleteMemberRow(mid)
    }

    @Transaction
    open suspend fun deleteAssociationFull(aid: Long) {
        deletePaymentsOf(aid)
        deletePayoutsOf(aid)
        deleteMembersOf(aid)
        deleteAssociationRow(aid)
    }

    // ---------------- Loans ----------------
    @Query("SELECT * FROM loan_tx ORDER BY date, id")
    abstract fun loanTxFlow(): Flow<List<LoanTx>>

    @Query("SELECT * FROM loan_tx ORDER BY date, id")
    abstract suspend fun allLoanTx(): List<LoanTx>

    @Query("SELECT * FROM loan_tx WHERE personId = :pid ORDER BY date, id")
    abstract fun loanTxForPersonFlow(pid: Long): Flow<List<LoanTx>>

    @Query("SELECT * FROM loan_tx WHERE personId = :pid ORDER BY date, id")
    abstract suspend fun loanTxForPerson(pid: Long): List<LoanTx>

    @Insert
    abstract suspend fun insertLoanTx(t: LoanTx): Long

    @Query("DELETE FROM loan_tx WHERE id = :id")
    abstract suspend fun deleteLoanTx(id: Long)

    @Query("DELETE FROM loan_tx WHERE personId = :pid")
    abstract suspend fun deleteLoansOf(pid: Long)

    // ---------------- Installment sales ----------------
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    abstract fun salesFlow(): Flow<List<Sale>>

    @Query("SELECT * FROM sales")
    abstract suspend fun allSales(): List<Sale>

    @Query("SELECT * FROM sales WHERE id = :id")
    abstract fun saleFlow(id: Long): Flow<Sale?>

    @Query("SELECT * FROM sales WHERE id = :id")
    abstract suspend fun sale(id: Long): Sale?

    @Insert
    abstract suspend fun insertSale(s: Sale): Long

    @Update
    abstract suspend fun updateSale(s: Sale)

    @Query("DELETE FROM sales WHERE id = :id")
    abstract suspend fun deleteSaleRow(id: Long)

    @Query("SELECT * FROM sale_payments ORDER BY date, id")
    abstract fun allSalePaymentsFlow(): Flow<List<SalePayment>>

    @Query("SELECT * FROM sale_payments ORDER BY date, id")
    abstract suspend fun allSalePayments(): List<SalePayment>

    @Query("SELECT * FROM sale_payments WHERE saleId = :sid ORDER BY date, id")
    abstract fun salePaymentsFlow(sid: Long): Flow<List<SalePayment>>

    @Insert
    abstract suspend fun insertSalePayment(p: SalePayment): Long

    @Query("DELETE FROM sale_payments WHERE id = :id")
    abstract suspend fun deleteSalePayment(id: Long)

    @Query("DELETE FROM sale_payments WHERE saleId = :sid")
    abstract suspend fun deletePaymentsOfSale(sid: Long)

    @Transaction
    open suspend fun deleteSaleFull(sid: Long) {
        deletePaymentsOfSale(sid)
        deleteSaleRow(sid)
    }

    // ---------------- Accounts ----------------
    @Query("SELECT * FROM accounts ORDER BY name COLLATE NOCASE")
    abstract fun accountsFlow(): Flow<List<Account>>

    @Query("SELECT * FROM accounts WHERE id = :id")
    abstract fun accountFlow(id: Long): Flow<Account?>

    @Insert
    abstract suspend fun insertAccount(a: Account): Long

    @Update
    abstract suspend fun updateAccount(a: Account)

    @Query("DELETE FROM accounts WHERE id = :id")
    abstract suspend fun deleteAccountRow(id: Long)

    @Query("SELECT * FROM account_tx ORDER BY date, id")
    abstract fun allAccountTxFlow(): Flow<List<AccountTx>>

    @Query("SELECT * FROM account_tx WHERE accountId = :aid ORDER BY date, id")
    abstract fun accountTxFlow(aid: Long): Flow<List<AccountTx>>

    @Insert
    abstract suspend fun insertAccountTx(t: AccountTx): Long

    @Update
    abstract suspend fun updateAccountTx(t: AccountTx)

    @Query("DELETE FROM account_tx WHERE id = :id")
    abstract suspend fun deleteAccountTx(id: Long)

    @Query("DELETE FROM account_tx WHERE accountId = :aid")
    abstract suspend fun deleteTxOfAccount(aid: Long)

    @Transaction
    open suspend fun deleteAccountFull(aid: Long) {
        deleteTxOfAccount(aid)
        deleteAccountRow(aid)
    }
}
