package com.sho3eb.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
abstract class AppDao {

    // ---------------- People ----------------
    @Query("SELECT * FROM people ORDER BY name COLLATE NOCASE")
    abstract fun peopleFlow(): Flow<List<Person>>

    @Query("SELECT * FROM people")
    abstract suspend fun allPeople(): List<Person>

    @Query("SELECT * FROM people WHERE id = :id")
    abstract suspend fun person(id: Long): Person?

    @Query("SELECT * FROM people WHERE id = :id")
    abstract fun personFlow(id: Long): Flow<Person?>

    @Query("SELECT * FROM people WHERE phone = :phone LIMIT 1")
    abstract suspend fun personByPhone(phone: String): Person?

    @Insert
    abstract suspend fun insertPerson(p: Person): Long

    @Update
    abstract suspend fun updatePerson(p: Person)

    @Query("DELETE FROM people WHERE id = :id")
    abstract suspend fun deletePerson(id: Long)

    @Query(
        "SELECT (SELECT COUNT(*) FROM assoc_members WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM loan_tx WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM sales WHERE personId = :id) + " +
            "(SELECT COUNT(*) FROM accounts WHERE personId = :id)"
    )
    abstract suspend fun personUsage(id: Long): Int

    // ---------------- Associations ----------------
    @Query("SELECT * FROM associations ORDER BY createdAt DESC")
    abstract fun associationsFlow(): Flow<List<Association>>

    @Query("SELECT * FROM associations")
    abstract suspend fun allAssociations(): List<Association>

    @Query("SELECT * FROM associations WHERE id = :id")
    abstract fun associationFlow(id: Long): Flow<Association?>

    @Query("SELECT * FROM associations WHERE id = :id")
    abstract suspend fun association(id: Long): Association?

    @Insert
    abstract suspend fun insertAssociation(a: Association): Long

    @Update
    abstract suspend fun updateAssociation(a: Association)

    @Query("DELETE FROM associations WHERE id = :id")
    abstract suspend fun deleteAssociationRow(id: Long)

    @Query("SELECT * FROM assoc_members ORDER BY turnOrder")
    abstract fun allMembersFlow(): Flow<List<AssocMember>>

    @Query("SELECT * FROM assoc_members")
    abstract suspend fun allMembers(): List<AssocMember>

    @Query("SELECT * FROM assoc_members WHERE associationId = :aid ORDER BY turnOrder")
    abstract fun membersFlow(aid: Long): Flow<List<AssocMember>>

    @Query("SELECT * FROM assoc_members WHERE associationId = :aid ORDER BY turnOrder")
    abstract suspend fun members(aid: Long): List<AssocMember>

    @Insert
    abstract suspend fun insertMember(m: AssocMember): Long

    @Update
    abstract suspend fun updateMember(m: AssocMember)

    @Query("DELETE FROM assoc_members WHERE id = :id")
    abstract suspend fun deleteMemberRow(id: Long)

    @Query("DELETE FROM assoc_members WHERE associationId = :aid")
    abstract suspend fun deleteMembersOf(aid: Long)

    @Query("SELECT * FROM assoc_payments")
    abstract fun allAssocPaymentsFlow(): Flow<List<AssocPayment>>

    @Query("SELECT * FROM assoc_payments")
    abstract suspend fun allAssocPayments(): List<AssocPayment>

    @Query("SELECT * FROM assoc_payments WHERE associationId = :aid")
    abstract fun assocPaymentsFlow(aid: Long): Flow<List<AssocPayment>>

    @Insert
    abstract suspend fun insertAssocPayment(p: AssocPayment): Long

    @Query("DELETE FROM assoc_payments WHERE associationId = :aid AND memberId = :mid AND round = :round")
    abstract suspend fun deleteAssocPayment(aid: Long, mid: Long, round: Int)

    @Query("DELETE FROM assoc_payments WHERE memberId = :mid")
    abstract suspend fun deletePaymentsOfMember(mid: Long)

    @Query("DELETE FROM assoc_payments WHERE associationId = :aid")
    abstract suspend fun deletePaymentsOf(aid: Long)

    @Query("SELECT * FROM assoc_payouts")
    abstract fun allPayoutsFlow(): Flow<List<AssocPayout>>

    @Query("SELECT * FROM assoc_payouts")
    abstract suspend fun allPayouts(): List<AssocPayout>

    @Query("SELECT * FROM assoc_payouts WHERE associationId = :aid")
    abstract fun payoutsFlow(aid: Long): Flow<List<AssocPayout>>

    @Insert
    abstract suspend fun insertPayout(p: AssocPayout): Long

    @Query("DELETE FROM assoc_payouts WHERE associationId = :aid AND round = :round")
    abstract suspend fun deletePayout(aid: Long, round: Int)

    @Query("DELETE FROM assoc_payouts WHERE memberId = :mid")
    abstract suspend fun deletePayoutsOfMember(mid: Long)

    @Query("DELETE FROM assoc_payouts WHERE associationId = :aid")
    abstract suspend fun deletePayoutsOf(aid: Long)

    @Transaction
    open suspend fun removeMember(mid: Long) {
        deletePaymentsOfMember(mid)
        deletePayoutsOfMember(mid)
        deleteMemberRow(mid)
    }

    @Transaction
    open suspend fun deleteAssociationFull(aid: Long) {
        deletePaymentsOf(aid)
        deletePayoutsOf(aid)
        deleteMembersOf(aid)
        deleteAssociationRow(aid)
    }

    // ---------------- Loans ----------------
    @Query("SELECT * FROM loan_tx ORDER BY date, id")
    abstract fun loanTxFlow(): Flow<List<LoanTx>>

    @Query("SELECT * FROM loan_tx ORDER BY date, id")
    abstract suspend fun allLoanTx(): List<LoanTx>

    @Query("SELECT * FROM loan_tx WHERE personId = :pid ORDER BY date, id")
    abstract fun loanTxForPersonFlow(pid: Long): Flow<List<LoanTx>>

    @Query("SELECT * FROM loan_tx WHERE personId = :pid ORDER BY date, id")
    abstract suspend fun loanTxForPerson(pid: Long): List<LoanTx>

    @Insert
    abstract suspend fun insertLoanTx(t: LoanTx): Long

    @Query("DELETE FROM loan_tx WHERE id = :id")
    abstract suspend fun deleteLoanTx(id: Long)

    @Query("DELETE FROM loan_tx WHERE personId = :pid")
    abstract suspend fun deleteLoansOf(pid: Long)

    // ---------------- Installment sales ----------------
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    abstract fun salesFlow(): Flow<List<Sale>>

    @Query("SELECT * FROM sales")
    abstract suspend fun allSales(): List<Sale>

    @Query("SELECT * FROM sales WHERE id = :id")
    abstract fun saleFlow(id: Long): Flow<Sale?>

    @Query("SELECT * FROM sales WHERE id = :id")
    abstract suspend fun sale(id: Long): Sale?

    @Insert
    abstract suspend fun insertSale(s: Sale): Long

    @Update
    abstract suspend fun updateSale(s: Sale)

    @Query("DELETE FROM sales WHERE id = :id")
    abstract suspend fun deleteSaleRow(id: Long)

    @Query("SELECT * FROM sale_payments ORDER BY date, id")
    abstract fun allSalePaymentsFlow(): Flow<List<SalePayment>>

    @Query("SELECT * FROM sale_payments ORDER BY date, id")
    abstract suspend fun allSalePayments(): List<SalePayment>

    @Query("SELECT * FROM sale_payments WHERE saleId = :sid ORDER BY date, id")
    abstract fun salePaymentsFlow(sid: Long): Flow<List<SalePayment>>

    @Insert
    abstract suspend fun insertSalePayment(p: SalePayment): Long

    @Query("DELETE FROM sale_payments WHERE id = :id")
    abstract suspend fun deleteSalePayment(id: Long)

    @Query("DELETE FROM sale_payments WHERE saleId = :sid")
    abstract suspend fun deletePaymentsOfSale(sid: Long)

    @Transaction
    open suspend fun deleteSaleFull(sid: Long) {
        deleteLinkedOfSale(sid)
        deletePaymentsOfSale(sid)
        deleteSaleRow(sid)
    }

    // ---------------- Accounts ----------------
    @Query("SELECT * FROM accounts ORDER BY name COLLATE NOCASE")
    abstract fun accountsFlow(): Flow<List<Account>>

    @Query("SELECT * FROM accounts WHERE id = :id")
    abstract fun accountFlow(id: Long): Flow<Account?>

    @Insert
    abstract suspend fun insertAccount(a: Account): Long

    @Update
    abstract suspend fun updateAccount(a: Account)

    @Query("DELETE FROM accounts WHERE id = :id")
    abstract suspend fun deleteAccountRow(id: Long)

    @Query("SELECT * FROM account_tx ORDER BY date, id")
    abstract fun allAccountTxFlow(): Flow<List<AccountTx>>

    @Query("SELECT * FROM account_tx WHERE accountId = :aid ORDER BY date, id")
    abstract fun accountTxFlow(aid: Long): Flow<List<AccountTx>>

    @Insert
    abstract suspend fun insertAccountTx(t: AccountTx): Long

    @Update
    abstract suspend fun updateAccountTx(t: AccountTx)

    @Query("DELETE FROM account_tx WHERE id = :id")
    abstract suspend fun deleteAccountTx(id: Long)

    @Query("DELETE FROM account_tx WHERE accountId = :aid")
    abstract suspend fun deleteTxOfAccount(aid: Long)

    @Transaction
    open suspend fun deleteAccountFull(aid: Long) {
        deleteTxOfAccount(aid)
        deleteAccountRow(aid)
    }

    // ---------------- Attachments ----------------
    @Query("SELECT * FROM attachments WHERE ownerType = :type AND ownerId = :id ORDER BY createdAt")
    abstract fun attachmentsFlow(type: String, id: Long): Flow<List<Attachment>>

    @Query("SELECT * FROM attachments WHERE ownerType = :type AND ownerId = :id")
    abstract suspend fun attachmentsOf(type: String, id: Long): List<Attachment>

    @Insert
    abstract suspend fun insertAttachment(a: Attachment): Long

    @Query("DELETE FROM attachments WHERE id = :id")
    abstract suspend fun deleteAttachment(id: Long)

    // ---------------- ترحيل الحركات إلى الحسابات ----------------
    @Query("SELECT * FROM accounts ORDER BY name COLLATE NOCASE")
    abstract suspend fun allAccounts(): List<Account>

    @Query("SELECT * FROM account_tx WHERE srcType IS NOT NULL")
    abstract fun linkedAccountTxFlow(): Flow<List<AccountTx>>

    @Query("DELETE FROM account_tx WHERE srcType = :type AND srcId = :id")
    abstract suspend fun deleteLinkedTx(type: String, id: Long)

    @Query("DELETE FROM account_tx WHERE srcType = 'LOAN_TX' AND srcId IN (SELECT id FROM loan_tx WHERE personId = :pid)")
    abstract suspend fun deleteLinkedOfPersonLoans(pid: Long)

    @Query("DELETE FROM account_tx WHERE (srcType = 'SALE_PAY' AND srcId IN (SELECT id FROM sale_payments WHERE saleId = :sid)) OR (srcType = 'SALE_DOWN' AND srcId = :sid)")
    abstract suspend fun deleteLinkedOfSale(sid: Long)

    // ---------------- مصاريف المعيشة ----------------
    @Query("SELECT * FROM liv_items ORDER BY kind DESC, category, name")
    abstract fun livItemsFlow(): Flow<List<LivItem>>

    @Insert
    abstract suspend fun insertLivItem(i: LivItem): Long

    @Update
    abstract suspend fun updateLivItem(i: LivItem)

    @Query("DELETE FROM liv_items WHERE id = :id")
    abstract suspend fun deleteLivItem(id: Long)

    @Query("SELECT * FROM liv_periods ORDER BY startDate DESC")
    abstract fun livPeriodsFlow(): Flow<List<LivPeriod>>

    @Query("SELECT * FROM liv_periods WHERE id = :id")
    abstract fun livPeriodFlow(id: Long): Flow<LivPeriod?>

    @Insert
    abstract suspend fun insertLivPeriod(p: LivPeriod): Long

    @Update
    abstract suspend fun updateLivPeriod(p: LivPeriod)

    @Query("SELECT * FROM liv_entries ORDER BY date, id")
    abstract fun allLivEntriesFlow(): Flow<List<LivEntry>>

    @Query("SELECT * FROM liv_entries WHERE periodId = :pid ORDER BY date, id")
    abstract fun livEntriesFlow(pid: Long): Flow<List<LivEntry>>

    @Insert
    abstract suspend fun insertLivEntry(e: LivEntry): Long

    @Query("DELETE FROM liv_entries WHERE id = :id")
    abstract suspend fun deleteLivEntry(id: Long)

    @Query("DELETE FROM liv_entries WHERE periodId = :pid")
    abstract suspend fun deleteLivEntriesOf(pid: Long)

    @Query("DELETE FROM liv_periods WHERE id = :id")
    abstract suspend fun deleteLivPeriodRow(id: Long)

    @Query("DELETE FROM account_tx WHERE srcType = 'LIV' AND srcId IN (SELECT id FROM liv_entries WHERE periodId = :pid)")
    abstract suspend fun deleteLinkedOfLivPeriod(pid: Long)

    @Transaction
    open suspend fun deleteLivPeriodFull(pid: Long) {
        deleteLinkedOfLivPeriod(pid)
        deleteLivEntriesOf(pid)
        deleteLivPeriodRow(pid)
    }

    // ---------------- قوائم كاملة (للتصدير واللوحة والبحث) ----------------
    @Query("SELECT * FROM account_tx ORDER BY date, id")
    abstract suspend fun allAccountTx(): List<AccountTx>

    @Query("SELECT * FROM liv_periods ORDER BY startDate DESC")
    abstract suspend fun allLivPeriods(): List<LivPeriod>

    @Query("SELECT * FROM liv_entries ORDER BY date, id")
    abstract suspend fun allLivEntries(): List<LivEntry>

    @Query("SELECT * FROM liv_items ORDER BY kind DESC, category, name")
    abstract suspend fun allLivItems(): List<LivItem>

    @Query("SELECT * FROM liv_entries WHERE periodId = :pid")
    abstract suspend fun livEntriesOnce(pid: Long): List<LivEntry>

    // ---------------- العقارات والإيجارات ----------------
    @Query("SELECT * FROM properties ORDER BY name")
    abstract fun propertiesFlow(): Flow<List<Property>>
    @Query("SELECT * FROM properties WHERE id = :id")
    abstract fun propertyFlow(id: Long): Flow<Property?>
    @Query("SELECT * FROM properties ORDER BY name")
    abstract suspend fun allProperties(): List<Property>
    @Insert abstract suspend fun insertProperty(p: Property): Long
    @Update abstract suspend fun updateProperty(p: Property)

    @Query("SELECT * FROM prop_units ORDER BY propertyId, name")
    abstract fun unitsFlow(): Flow<List<PropUnit>>
    @Query("SELECT * FROM prop_units ORDER BY propertyId, name")
    abstract suspend fun allUnits(): List<PropUnit>
    @Insert abstract suspend fun insertUnit(u: PropUnit): Long
    @Update abstract suspend fun updateUnit(u: PropUnit)

    @Query("SELECT * FROM leases ORDER BY startDate DESC")
    abstract fun leasesFlow(): Flow<List<Lease>>
    @Query("SELECT * FROM leases WHERE id = :id")
    abstract fun leaseFlow(id: Long): Flow<Lease?>
    @Query("SELECT * FROM leases ORDER BY startDate DESC")
    abstract suspend fun allLeases(): List<Lease>
    @Insert abstract suspend fun insertLease(l: Lease): Long
    @Update abstract suspend fun updateLease(l: Lease)

    @Query("SELECT * FROM lease_payments ORDER BY date, id")
    abstract fun leasePaymentsFlow(): Flow<List<LeasePayment>>
    @Query("SELECT * FROM lease_payments ORDER BY date, id")
    abstract suspend fun allLeasePayments(): List<LeasePayment>
    @Insert abstract suspend fun insertLeasePayment(p: LeasePayment): Long
    @Query("DELETE FROM lease_payments WHERE id = :id")
    abstract suspend fun deleteLeasePayment(id: Long)

    @Query("SELECT * FROM prop_expenses ORDER BY date DESC, id DESC")
    abstract fun propExpensesFlow(): Flow<List<PropExpense>>
    @Query("SELECT * FROM prop_expenses ORDER BY date DESC, id DESC")
    abstract suspend fun allPropExpenses(): List<PropExpense>
    @Insert abstract suspend fun insertPropExpense(e: PropExpense): Long
    @Query("DELETE FROM prop_expenses WHERE id = :id")
    abstract suspend fun deletePropExpense(id: Long)

    @Query("DELETE FROM account_tx WHERE (srcType = 'RENT_PAY' AND srcId IN (SELECT id FROM lease_payments WHERE leaseId = :lid)) OR (srcType = 'LEASE_DEP' AND srcId = :lid)")
    abstract suspend fun deleteLinkedOfLease(lid: Long)
    @Query("DELETE FROM lease_payments WHERE leaseId = :lid")
    abstract suspend fun deleteLeasePaymentsOf(lid: Long)
    @Query("DELETE FROM leases WHERE id = :lid")
    abstract suspend fun deleteLeaseRow(lid: Long)

    @Transaction
    open suspend fun deleteLeaseFull(lid: Long) {
        deleteLinkedOfLease(lid); deleteLeasePaymentsOf(lid); deleteLeaseRow(lid)
    }

    @Query("SELECT id FROM leases WHERE unitId = :uid")
    abstract suspend fun leaseIdsOfUnit(uid: Long): List<Long>
    @Query("DELETE FROM prop_units WHERE id = :uid")
    abstract suspend fun deleteUnitRow(uid: Long)

    @Transaction
    open suspend fun deleteUnitFull(uid: Long) {
        leaseIdsOfUnit(uid).forEach { deleteLeaseFull(it) }
        deleteUnitRow(uid)
    }

    @Query("SELECT id FROM prop_units WHERE propertyId = :pid")
    abstract suspend fun unitIdsOf(pid: Long): List<Long>
    @Query("DELETE FROM account_tx WHERE srcType = 'PROP_EXP' AND srcId IN (SELECT id FROM prop_expenses WHERE propertyId = :pid)")
    abstract suspend fun deleteLinkedOfPropExpenses(pid: Long)
    @Query("DELETE FROM prop_expenses WHERE propertyId = :pid")
    abstract suspend fun deletePropExpensesOf(pid: Long)
    @Query("DELETE FROM properties WHERE id = :pid")
    abstract suspend fun deletePropertyRow(pid: Long)

    @Transaction
    open suspend fun deletePropertyFull(pid: Long) {
        unitIdsOf(pid).forEach { deleteUnitFull(it) }
        deleteLinkedOfPropExpenses(pid); deletePropExpensesOf(pid); deletePropertyRow(pid)
    }

    // ---------------- ديوني ----------------
    @Query("SELECT * FROM debts ORDER BY closed, priority, createdAt DESC")
    abstract fun debtsFlow(): Flow<List<Debt>>
    @Query("SELECT * FROM debts WHERE id = :id")
    abstract fun debtFlow(id: Long): Flow<Debt?>
    @Query("SELECT * FROM debts")
    abstract suspend fun allDebts(): List<Debt>
    @Insert abstract suspend fun insertDebt(d: Debt): Long
    @Update abstract suspend fun updateDebt(d: Debt)

    @Query("SELECT * FROM debt_tx ORDER BY date, id")
    abstract fun debtTxFlow(): Flow<List<DebtTx>>
    @Query("SELECT * FROM debt_tx ORDER BY date, id")
    abstract suspend fun allDebtTx(): List<DebtTx>
    @Insert abstract suspend fun insertDebtTx(t: DebtTx): Long
    @Query("DELETE FROM debt_tx WHERE id = :id")
    abstract suspend fun deleteDebtTx(id: Long)

    @Query("DELETE FROM account_tx WHERE srcType = 'DEBT_TX' AND srcId IN (SELECT id FROM debt_tx WHERE debtId = :did)")
    abstract suspend fun deleteLinkedOfDebt(did: Long)
    @Query("DELETE FROM debt_tx WHERE debtId = :did")
    abstract suspend fun deleteDebtTxOf(did: Long)
    @Query("DELETE FROM debts WHERE id = :did")
    abstract suspend fun deleteDebtRow(did: Long)

    @Transaction
    open suspend fun deleteDebtFull(did: Long) {
        deleteLinkedOfDebt(did); deleteDebtTxOf(did); deleteDebtRow(did)
    }
}
