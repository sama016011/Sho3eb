package com.sho3eb.app.core

import android.content.Context
import android.content.Intent
import com.sho3eb.app.Sho3ebApp
import com.sho3eb.app.data.AppDatabase
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** ربط Google Drive: رفع النسخة الاحتياطية مباشرة لتطبيق Drive، والحفظ/الاستعادة عبر منتقي الملفات */
object Drive {
    const val PKG = "com.google.android.apps.docs"
    var lastUpload: Long get() = Extras.l("drive_last", 0L); set(v) = Extras.pl("drive_last", v)

    fun installed(ctx: Context) = runCatching { ctx.packageManager.getPackageInfo(PKG, 0); true }.getOrDefault(false)

    fun fileName() = "Sho3eb_backup_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm")) + ".db"

    /** نسخة جاهزة للرفع في مجلد مؤقت */
    fun makeBackup(ctx: Context): File {
        Sho3ebApp.instance.db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        val dir = File(ctx.cacheDir, "drive").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val f = File(dir, fileName())
        ctx.getDatabasePath(AppDatabase.NAME).copyTo(f, overwrite = true)
        return f
    }

    /** يفتح نافذة «الحفظ في Drive» مباشرة */
    fun upload(ctx: Context): Boolean = runCatching {
        val f = makeBackup(ctx)
        val uri = Share.uriFor(ctx, f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, f.name)
            putExtra(Intent.EXTRA_SUBJECT, f.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (installed(ctx)) ctx.startActivity(Intent(i).setPackage(PKG))
        else ctx.startActivity(Intent.createChooser(i, tr("رفع النسخة إلى", "Upload backup to")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        lastUpload = System.currentTimeMillis()
        true
    }.getOrDefault(false)

    fun openApp(ctx: Context) {
        val i = ctx.packageManager.getLaunchIntentForPackage(PKG)
        runCatching {
            if (i != null) ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=$PKG")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
