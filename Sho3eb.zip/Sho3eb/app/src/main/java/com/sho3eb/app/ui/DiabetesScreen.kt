@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.GlucoseLog
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.launch
import java.time.LocalTime

@Composable
fun DiabetesScreen(nav: NavController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    ScreenScaffold(title = tr("ركن مرضى السكري", "Diabetes corner"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(tab, edgePadding = 8.dp) {
                listOf(tr("فاحص الأطعمة", "Food checker"), tr("يرفع / يخفض", "Raises / lowers"), tr("الدليل والأنظمة", "Guide"), tr("وصفات مناسبة", "Recipes"), tr("قراءاتي", "My readings")).forEachIndexed { i, t ->
                    Tab(tab == i, { tab = i }, text = { Text(t) })
                }
            }
            when (tab) {
                0 -> FoodCheckerTab()
                1 -> RaiseLowerTab()
                2 -> GuideTab()
                3 -> DiabRecipesTab(nav)
                else -> GlucoseTab()
            }
        }
    }
}

@Composable
private fun Disclaimer() {
    Text(tr("⚕️ معلومات توعوية عامة ولا تغني عن استشارة الطبيب أو أخصائي التغذية. لا تغيّر جرعات أدويتك دون الرجوع لطبيبك.", "⚕️ General education only — not a substitute for your doctor. Don't change medication without medical advice."),
        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun FoodCheckerTab() {
    val ctx = LocalContext.current
    var q by rememberSaveable { mutableStateOf("") }
    var open by remember { mutableStateOf<Food.FoodItem?>(null) }
    val res = remember(q) { if (q.isBlank()) emptyList() else Food.searchFoods(ctx, q) }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr("🔍 اكتب أي طعام أو خضار أو فاكهة أو منتج", "🔍 Type any food, fruit, vegetable or product"), fontWeight = FontWeight.Bold)
                    Text(tr("اعرف تأثيره على سكر الدم، وكميته المناسبة، والبديل الأفضل.", "See its effect on blood sugar, the right portion and better swaps."), style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { SearchField(q) { q = it } }
                        MicButton { q = it }
                    }
                }
            }
        }
        if (q.isBlank()) {
            item { Text(tr("أمثلة سريعة:", "Quick examples:"), style = MaterialTheme.typography.labelLarge) }
            item { HChips { listOf("تمر", "أرز أبيض", "عيش بلدي", "بطاطس", "مانجو", "عسل", "شوفان", "عدس", "قهوة", "مشروب غازي", "منتجات دايت", "قرفة").forEach { s -> AssistChip({ q = s }, label = { Text(s) }) } } }
            item { Legend() }
        } else if (res.isEmpty()) item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(tr("لم أجد «$q» في القائمة", "\"$q\" isn't in the list"), fontWeight = FontWeight.Bold)
                    Text(tr("قاعدة عامة لأي طعام:\n• إذا كان نشوياً أبيض أو سكرياً أو عصيراً أو مهروساً ← غالباً يرفع السكر بسرعة\n• إذا كان غنياً بالألياف أو البروتين أو الدهون الصحية ← يرفع ببطء\n• الخضار الورقية والبيض واللحوم والأسماك ← لا ترفع السكر تقريباً\n• اقرأ الملصق: الكربوهيدرات الكلية ÷ 15 = عدد حصص الكربوهيدرات",
                        "General rule:\n• White starch, sugary, juiced or mashed → usually spikes\n• High fiber, protein or healthy fat → slower rise\n• Leafy greens, eggs, meat, fish → barely raise sugar\n• Label: total carbs ÷ 15 = carb servings"), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { Share.openUrl(ctx, Food.google(q + tr(" المؤشر الجلايسيمي والسعرات", " glycemic index calories"))) }) { Text(tr("🔎 ابحث عن مؤشره الجلايسيمي", "🔎 Look up its glycemic index")) }
                }
            }
        }
        items(res.take(20), key = { "f" + it.ar }) { f -> FoodRow(f) { open = f } }
        item { Disclaimer() }
    }
    open?.let { f -> FoodDialog(f) { open = null } }
}

@Composable
private fun Legend() {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(tr("دليل الألوان", "Legend"), fontWeight = FontWeight.Bold)
            Text(tr("💚 قد يساعد على ضبط السكر (بدليل علمي متفاوت)", "💚 May help control sugar"), style = MaterialTheme.typography.bodySmall)
            Text(tr("🟢 لا يرفع أو يرفع ببطء — آمن بالكمية المعقولة", "🟢 Little or slow rise"), style = MaterialTheme.typography.bodySmall)
            Text(tr("🟡 رفع متوسط — بحصة محسوبة ومع بروتين وألياف", "🟡 Moderate — measured portion"), style = MaterialTheme.typography.bodySmall)
            Text(tr("🟠 يرفع بوضوح — قلّله", "🟠 Noticeable rise — limit"), style = MaterialTheme.typography.bodySmall)
            Text(tr("🔴 يرفع بسرعة كبيرة — تجنبه (إلا لعلاج الهبوط)", "🔴 Spikes fast — avoid (except to treat lows)"), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun RaiseLowerTab() {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf<Food.FoodItem?>(null) }
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val all = remember { Food.foods(ctx) }
    val groups = remember(all) { all.groupBy { Food.effect(it).level } }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            HChips {
                FilterChip(mode == 0, { mode = 0 }, label = { Text(tr("🔴 ترفع السكر", "🔴 Raise sugar")) })
                FilterChip(mode == 1, { mode = 1 }, label = { Text(tr("💚 تساعد على خفضه", "💚 Help lower it")) })
                FilterChip(mode == 2, { mode = 2 }, label = { Text(tr("🟢 آمنة", "🟢 Safe")) })
                FilterChip(mode == 3, { mode = 3 }, label = { Text(tr("🏷️ منتجات السوق", "🏷️ Market products")) })
            }
        }
        when (mode) {
            0 -> {
                item { InfoCard(DangerRed, tr("أطعمة ومنتجات ترفع السكر بسرعة", "Foods that spike sugar"), tr("النشويات البيضاء (أرز، خبز أبيض، بطاطس، كورن فليكس)، السكريات والحلويات، العصائر حتى الطبيعية، المشروبات الغازية والطاقة، التمر والزبيب بكثرة، الفواكه الناضجة جداً. البديل: الحبوب الكاملة، الفاكهة الكاملة بقشرها، تقليل الكمية مع بروتين وسلطة.", "White starches, sweets, juices, sodas, too many dates. Swap for whole grains and whole fruit with protein and salad.")) }
                items((groups[5].orEmpty() + groups[4].orEmpty()).sortedByDescending { it.gi }, key = { "r" + it.ar }) { f -> FoodRow(f) { open = f } }
                item { SectionTitle(tr("🟡 ترفع بشكل متوسط", "🟡 Moderate")) }
                items(groups[3].orEmpty(), key = { "m" + it.ar }) { f -> FoodRow(f) { open = f } }
            }
            1 -> {
                item { InfoCard(SuccessGreen, tr("أطعمة قد تساعد على ضبط السكر", "Foods that may help"), tr("هذه الأطعمة قد تبطئ امتصاص السكر أو تحسن حساسية الإنسولين بدرجة بسيطة إلى متوسطة. هي مكمل للدواء والنظام وليست بديلاً عنه. ⚠️ الإكثار من الأعشاب (الحلبة، القرفة، حبة البركة) مع أدوية السكر أو الإنسولين قد يسبب هبوطاً — أخبر طبيبك.", "These may modestly slow sugar absorption or improve insulin sensitivity. They complement, not replace, treatment. ⚠️ Herbs with medication can cause lows.")) }
                items(groups[0].orEmpty(), key = { "l" + it.ar }) { f -> FoodRow(f) { open = f } }
                item { SectionTitle(tr("🟢 مؤشر منخفض (اختيارات ممتازة)", "🟢 Low GI (great choices)")) }
                items(groups[2].orEmpty(), key = { "g" + it.ar }) { f -> FoodRow(f) { open = f } }
                item {
                    InfoCard(MaterialTheme.colorScheme.primary, tr("عادات تخفض السكر بعد الأكل", "Habits that lower post-meal sugar"),
                        tr("• ابدأ الوجبة بالسلطة ثم البروتين ثم النشويات\n• امشِ 10–15 دقيقة بعد الأكل\n• أضف ليموناً أو خلاً للأكل\n• اختر الأرز المبرد ثم المسخن (نشا مقاوم)\n• لا تشرب العصائر، كُل الفاكهة كاملة\n• نم جيداً وقلل التوتر",
                            "• Eat salad, then protein, then carbs\n• Walk 10-15 min after meals\n• Add lemon or vinegar\n• Cooled-then-reheated rice\n• Whole fruit, not juice\n• Sleep well, reduce stress"))
                }
            }
            2 -> {
                item { InfoCard(SuccessGreen, tr("أطعمة لا ترفع السكر تقريباً", "Foods that barely raise sugar"), tr("الخضار غير النشوية، البيض، اللحوم والدجاج والأسماك، الجبن، المكسرات، الماء والقهوة والشاي بدون سكر. انتبه فقط للدهون والملح والسعرات.", "Non-starchy veg, eggs, meat, fish, cheese, nuts, unsweetened drinks.")) }
                items(groups[1].orEmpty(), key = { "s" + it.ar }) { f -> FoodRow(f) { open = f } }
            }
            else -> {
                item { InfoCard(WarnAmber, tr("منتجات «دايت» و«بدون سكر»", "\"Diet\" and \"sugar-free\" products"), tr("• «بدون سكر» قد تحتوي دقيقاً أبيض أو مالتيتول يرفع السكر\n• «دايت» قد تعني دهوناً أقل لكن نشويات أعلى\n• المحليات الآمنة نسبياً: ستيفيا، سكرالوز، وبحذر الإريثريتول\n• احذر: مالتوديكسترين، شراب الذرة، الدكستروز، الفركتوز\n• المعيار: الكربوهيدرات الكلية في الحصة", "• Sugar-free may still contain white flour or maltitol\n• Check total carbs per serving\n• Safer sweeteners: stevia, sucralose; erythritol with caution")) }
                items(all.filter { it.type == "PRODUCT" || it.type == "SWEET" || it.type == "DRINK" }, key = { "p" + it.ar }) { f -> FoodRow(f) { open = f } }
            }
        }
        item { Disclaimer() }
    }
    open?.let { f -> FoodDialog(f) { open = null } }
}

@Composable
private fun InfoCard(color: Color, title: String, text: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f))) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = color)
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun GuideTab() {
    val ctx = LocalContext.current
    val list = remember { Food.guide(ctx) }
    var open by rememberSaveable { mutableIntStateOf(-1) }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Disclaimer() }
        items(list.size) { i ->
            val g = list[i]
            Card(Modifier.fillMaxWidth().clickable { open = if (open == i) -1 else i }) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(g.emoji, fontSize = 24.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(g.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Icon(if (open == i) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null)
                    }
                    if (open == i) { Spacer(Modifier.height(8.dp)); Text(g.body, style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp) }
                }
            }
        }
    }
}

@Composable
private fun DiabRecipesTab(nav: NavController) {
    val all = rememberAllRecipes()
    var meal by rememberSaveable { mutableStateOf("ALL") }
    val list = all.filter { it.diab == "G" && (meal == "ALL" || it.meal == meal) }.sortedBy { it.carbs }
    val moderate = all.filter { it.diab == "M" && (meal == "ALL" || it.meal == meal) }.sortedBy { it.carbs }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { HChips { Food.meals.forEach { m -> FilterChip(meal == m.key, { meal = m.key }, label = { Text(m.emoji + " " + m.label) }) } } }
        item { Text(tr("🟢 مناسبة (مرتبة من الأقل نشويات)", "🟢 Suitable (fewest carbs first)"), fontWeight = FontWeight.Bold) }
        items(list, key = { "g" + it.id }) { r -> RecipeCard(r) { nav.navigate("recipe/${r.id}") } }
        if (moderate.isNotEmpty()) {
            item { Text(tr("🟡 باعتدال (نصف الحصة مع سلطة)", "🟡 In moderation (half portion + salad)"), fontWeight = FontWeight.Bold) }
            items(moderate, key = { "m" + it.id }) { r -> RecipeCard(r) { nav.navigate("recipe/${r.id}") } }
        }
    }
}

@Composable
private fun GlucoseTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    val logs by flowState(emptyList<GlucoseLog>()) { dao.glucoseFlow() }
    var add by remember { mutableStateOf(false) }
    var days by rememberSaveable { mutableIntStateOf(30) }
    var unit by remember { mutableStateOf(Food.glucoseUnit) }
    val from = Fmt.today() - days
    val shown = logs.filter { it.date >= from }
    val avg = if (shown.isNotEmpty()) shown.sumOf { it.value } / shown.size else 0.0
    val inRange = if (shown.isNotEmpty()) shown.count { it.value in 70.0..180.0 } * 100 / shown.size else 0
    val lows = shown.count { it.value < 70 }
    LazyColumn(contentPadding = PaddingValues(16.dp, 10.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { add = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text(tr("قراءة جديدة", "New reading")) }
                FilterChip(unit == "mg", { unit = "mg"; Food.glucoseUnit = "mg" }, label = { Text("mg/dL") })
                FilterChip(unit == "mmol", { unit = "mmol"; Food.glucoseUnit = "mmol" }, label = { Text("mmol/L") })
            }
        }
        item { HChips { listOf(7, 14, 30, 90).forEach { d -> FilterChip(days == d, { days = d }, label = { Text(tr("$d يوم", "$d days")) }) } } }
        if (shown.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(tr("المتوسط", "Average"), Food.fmtGlucose(avg), Icons.Filled.Insights, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatCard(tr("ضمن النطاق", "In range"), "$inRange%", Icons.Filled.CheckCircle, if (inRange >= 70) SuccessGreen else WarnAmber, Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(tr("التراكمي التقديري", "Estimated A1c"), String.format(java.util.Locale.US, "%.1f%%", Food.estimatedA1c(avg)), Icons.Filled.Bloodtype, if (Food.estimatedA1c(avg) < 7) SuccessGreen else DangerRed, Modifier.weight(1f))
                    StatCard(tr("مرات الهبوط", "Lows"), "$lows", Icons.Filled.Warning, if (lows > 0) DangerRed else SuccessGreen, Modifier.weight(1f))
                }
            }
            item { GlucoseChart(shown.sortedWith(compareBy({ it.date }, { it.minute }))) }
            item { Text(tr("التراكمي التقديري محسوب من متوسط قراءاتك ويختلف عن تحليل المعمل؛ يحتاج 2–3 أشهر من القراءات المنتظمة ليكون مفيداً.", "Estimated A1c is derived from your average and differs from a lab test."), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Food.glucoseContexts.forEach { c ->
                val l = shown.filter { it.context == c.key }
                if (l.isNotEmpty()) item(key = "ctx" + c.key) { KeyValue(c.emoji + " " + tr("متوسط ", "Avg ") + c.label, Food.fmtGlucose(l.sumOf { it.value } / l.size) + " (${l.size})") }
            }
        } else item { EmptyState(Icons.Filled.Bloodtype, tr("سجّل قراءات السكر لتتابع المتوسط ونسبة الوقت في النطاق والتراكمي التقديري.", "Log readings to track average, time in range and estimated A1c.")) }
        items(shown, key = { "g" + it.id }) { g ->
            val lv = Food.glucoseLevel(g.value, g.context)
            val c = when (lv) { 0 -> DangerRed; 1 -> SuccessGreen; 2 -> WarnAmber; else -> DangerRed }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = c.copy(alpha = 0.15f), shape = MaterialTheme.shapes.small) { Text(Food.fmtGlucose(g.value), Modifier.padding(8.dp), color = c, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text((Food.glucoseContexts.firstOrNull { it.key == g.context }?.let { it.emoji + " " + it.label } ?: "") + " • " + Food.levelLabel(lv), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                        Text(Fmt.date(g.date) + " " + String.format(java.util.Locale.US, "%02d:%02d", g.minute / 60, g.minute % 60) + (if (g.note.isNotBlank()) " • " + g.note else ""), style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { scope.launch { dao.deleteGlucose(g.id) } }) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                }
            }
        }
        item { Disclaimer() }
    }
    if (add) GlucoseDialog { add = false }
}

@Composable
private fun GlucoseChart(list: List<GlucoseLog>) {
    if (list.size < 2) return
    val line = MaterialTheme.colorScheme.primary
    val band = SuccessGreen.copy(alpha = 0.12f)
    val lowC = DangerRed
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(tr("منحنى القراءات (المنطقة الخضراء 70–180)", "Readings (green band 70–180)"), style = MaterialTheme.typography.labelLarge)
            Canvas(Modifier.fillMaxWidth().height(160.dp).padding(top = 8.dp)) {
                val mx = maxOf(250.0, list.maxOf { it.value } + 20); val mn = 40.0
                fun y(v: Double) = (size.height * (1 - (v - mn) / (mx - mn))).toFloat()
                drawRect(band, topLeft = Offset(0f, y(180.0)), size = androidx.compose.ui.geometry.Size(size.width, y(70.0) - y(180.0)))
                val step = size.width / (list.size - 1)
                val p = Path()
                list.forEachIndexed { i, g -> val x = i * step; val yy = y(g.value); if (i == 0) p.moveTo(x, yy) else p.lineTo(x, yy) }
                drawPath(p, line, style = Stroke(3.dp.toPx()))
                list.forEachIndexed { i, g -> drawCircle(if (g.value < 70 || g.value > 180) lowC else line, 4.dp.toPx(), Offset(i * step, y(g.value))) }
            }
        }
    }
}

@Composable
private fun GlucoseDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { appDao() }
    var v by remember { mutableStateOf("") }
    val now = LocalTime.now()
    var ctxKey by remember { mutableStateOf(when (now.hour) { in 4..9 -> "FASTING"; in 21..23 -> "BEDTIME"; else -> "BEFORE" }) }
    var date by remember { mutableStateOf(Fmt.today()) }
    var minute by remember { mutableIntStateOf(now.hour * 60 + now.minute) }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("قراءة سكر", "Glucose reading")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(v, { v = it }, label = { Text(if (Food.glucoseUnit == "mmol") "mmol/L" else "mg/dL") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal), trailingIcon = { MicButton { t -> VoiceParse.amount(t)?.let { v = Fmt.plain(it) } } })
                HChips { Food.glucoseContexts.forEach { c -> FilterChip(ctxKey == c.key, { ctxKey = c.key }, label = { Text(c.emoji + " " + c.label) }) } }
                DateField(tr("التاريخ", "Date"), date, { d -> if (d != null) date = d })
                Text(tr("الوقت: ", "Time: ") + String.format(java.util.Locale.US, "%02d:%02d", minute / 60, minute % 60), style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(note, { note = it }, label = { Text(tr("ملاحظة (أكلت، رياضة، دواء…)", "Note (meal, exercise, meds…)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                val mg = Fmt.parse(v)?.let { Food.toMg(it) }
                if (mg != null && mg > 0) {
                    val lv = Food.glucoseLevel(mg, ctxKey)
                    Text(Food.levelLabel(lv), fontWeight = FontWeight.Bold, color = when (lv) { 1 -> SuccessGreen; 2 -> WarnAmber; else -> DangerRed })
                    if (lv == 0) Text(tr("⚠️ هبوط: تناول 15 جم سكر سريع (نصف كوب عصير أو 3 أقراص جلوكوز) وأعد القياس بعد 15 دقيقة.", "⚠️ Low: take 15 g fast sugar and recheck in 15 minutes."), color = DangerRed, style = MaterialTheme.typography.bodySmall)
                    if (mg >= 300) Text(tr("⚠️ مرتفع جداً: اشرب ماء وراجع طبيبك؛ اطلب الطوارئ إن وُجد قيء أو ألم بطن أو نعاس شديد.", "⚠️ Very high: hydrate and contact your doctor; seek emergency care with vomiting or drowsiness."), color = DangerRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val x = Fmt.parse(v)?.let { Food.toMg(it) }
                if (x == null || x < 20 || x > 700) { toast(ctx, tr("أدخل قراءة صحيحة", "Enter a valid reading")); return@TextButton }
                scope.launch { dao.insertGlucose(GlucoseLog(value = x, context = ctxKey, date = date, minute = minute, note = note.trim())); onDismiss() }
            }) { Text(tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("إلغاء", "Cancel")) } }
    )
}
