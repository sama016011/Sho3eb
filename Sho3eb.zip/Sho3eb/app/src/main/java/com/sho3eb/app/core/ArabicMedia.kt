package com.sho3eb.app.core

import java.net.URLEncoder

/** أقسام المحتوى العربي: أفلام ومسلسلات مصرية، رمضان، تركية مدبلجة، وكرتون عربي — من مصادر رسمية وقانونية */
object ArabicMedia {
    data class Cat(val key: String, val ar: String, val en: String, val emoji: String, val suffix: String, val titles: List<String>, val channels: List<Pair<String, String>>, val iaQuery: String = "", val tvGroups: List<String> = emptyList()) {
        val label get() = tr(ar, en)
    }
    data class Platform(val name: String, val pkg: String, val url: String)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    fun yt(q: String) = "https://m.youtube.com/results?search_query=" + enc(q)
    /** بحث عن الحلقات/الأفلام الكاملة (فيديوهات طويلة) */
    fun ytLong(q: String) = "https://m.youtube.com/results?search_query=" + enc(q) + "&sp=EgIYAg%3D%3D"
    fun ytPlaylist(q: String) = "https://m.youtube.com/results?search_query=" + enc(q) + "&sp=EgIQAw%3D%3D"

    val platforms = listOf(
        Platform("Shahid شاهد", "net.mbc.shahid", "https://shahid.mbc.net/ar"),
        Platform("WATCH IT", "com.watchit.vod", "https://www.watchit.com"),
        Platform("Yango Play", "com.yango.play", "https://play.yango.com"),
        Platform("Netflix", "com.netflix.mediaclient", "https://www.netflix.com"),
        Platform("OSN+", "com.osn.go", "https://www.osnplus.com"),
        Platform("TOD", "com.beinmedia.tod", "https://www.tod.tv")
    )

    val cats = listOf(
        Cat("eg_movies", "أفلام مصرية", "Egyptian movies", "🎬", "فيلم كامل",
            listOf("الإرهاب والكباب", "الناظر", "اللمبي", "صعيدي في الجامعة الأمريكية", "الكيف", "عسل إسود", "الفيل الأزرق", "الجزيرة", "ولاد رزق", "كيرة والجن", "الممر", "بوحة", "مرجان أحمد مرجان", "عمارة يعقوبيان", "الحرامي والعبيط", "إشاعة حب", "باب الحديد", "الأرض", "دعاء الكروان", "رد قلبي", "شيء من الخوف", "الزوجة الثانية", "إسماعيل ياسين في الجيش", "غزل البنات"),
            listOf("روتانا سينما" to "Rotana Cinema", "أفلام السبكي" to "السبكي للإنتاج السينمائي", "ميلودي أفلام" to "Melody Aflam", "أفلام الأبيض والأسود" to "أفلام أبيض وأسود كاملة", "سينما زمان" to "أفلام زمان كاملة"),
            iaQuery = "egyptian film", tvGroups = listOf("movies", "cinema", "aflam", "أفلام")),
        Cat("eg_series", "مسلسلات مصرية", "Egyptian series", "📺", "الحلقة 1 كاملة",
            listOf("ليالي الحلمية", "رأفت الهجان", "لن أعيش في جلباب أبي", "الضوء الشارد", "الاختيار", "جعفر العمدة", "الكبير أوي", "نسل الأغراب", "بـ100 وش", "لعبة نيوتن", "الزيبق", "العائدون", "تحت السيطرة", "أبو العروسة", "حديث الصباح والمساء", "المال والبنون", "ذئاب الجبل", "الحاج متولي"),
            listOf("قناة CBC دراما" to "CBC Drama", "قناة DMC دراما" to "DMC Drama", "ON دراما" to "ON Drama", "الحياة" to "قناة الحياة مسلسلات", "Synergy" to "Synergy مسلسلات", "ماسبيرو زمان" to "ماسبيرو زمان مسلسلات"),
            tvGroups = listOf("series", "drama", "دراما", "مسلسلات")),
        Cat("ramadan", "مسلسلات رمضان المصرية", "Ramadan Egyptian series", "🌙", "رمضان الحلقة 1",
            listOf("مسلسلات رمضان 2026", "مسلسلات رمضان 2025", "مسلسلات رمضان 2024", "مسلسلات رمضان 2023", "مسلسلات رمضان 2022", "مسلسلات رمضان 2021", "كوميديا رمضان", "دراما رمضان الصعيدية", "مسلسلات رمضان 15 حلقة"),
            listOf("CBC Drama" to "CBC Drama رمضان", "DMC" to "DMC رمضان مسلسلات", "ON" to "ON مسلسلات رمضان", "Synergy" to "Synergy رمضان", "Watch iT" to "WATCH IT رمضان"),
            tvGroups = listOf("series", "drama")),
        Cat("turkish", "مسلسلات تركية مدبلجة", "Turkish series dubbed in Arabic", "🇹🇷", "مدبلج للعربية الحلقة 1",
            listOf("قيامة أرطغرل", "المؤسس عثمان", "وادي الذئاب", "حريم السلطان", "نور", "سنوات الضياع", "العشق الممنوع", "فاطمة", "عاصفة الحب", "اليتيمة", "الطائر الرفراف", "ألب أرسلان", "صلاح الدين الأيوبي", "زهرة القصر", "الحفرة", "حب أعمى"),
            listOf("MBC دراما" to "MBC Drama مدبلج", "قناة مسلسلات تركية مدبلجة" to "مسلسلات تركية مدبلجة كاملة", "TRT عربي" to "TRT عربي مسلسلات"),
            tvGroups = listOf("series", "drama")),
        Cat("cartoon", "كرتون عربي", "Arabic cartoons", "🧸", "مدبلج الحلقة 1",
            listOf("كابتن ماجد", "النمر المقنع", "ريمي", "سالي", "عدنان ولينا", "جزيرة الكنز", "دروب ريمي", "الكابتن رابح", "سلاحف النينجا", "المحقق كونان", "ون بيس", "هزيم الرعد", "بوكيمون", "أبطال الديجيتال", "سندباد", "ساندي بل", "بسيط", "ماوكلي", "بكار", "عائلة سمسم", "افتح يا سمسم", "بابار", "مدرسة الكونغ فو", "توم وجيري", "الحديقة السرية", "بشر وسامي"),
            listOf("سبيستون" to "Spacetoon official", "براعم" to "براعم الجزيرة للأطفال", "جيم" to "قناة جيم للأطفال", "ماجد" to "Majid TV official", "طيور الجنة" to "طيور الجنة الرسمية", "ماسبيرو زمان أطفال" to "ماسبيرو زمان كرتون"),
            iaQuery = "arabic cartoon", tvGroups = listOf("kids", "animation", "أطفال", "cartoon"))
    )
    fun cat(key: String) = cats.firstOrNull { it.key == key }

    /** قنوات أون سبورت */
    val onSport = listOf("ON Time Sports" to listOf("ON Time Sports", "ON Sport", "اون تايم سبورت"), "ON Time Sports 2" to listOf("ON Time Sports 2", "ON Sport 2"), "ON Time Sports 3" to listOf("ON Time Sports 3", "ON Sport 3"),
        "ON E" to listOf("ON E", "ON TV"), "ON Drama" to listOf("ON Drama"), "ON Live" to listOf("ON Live"))
    /** قائمة قنوات بي إن سبورت */
    val beIn = (listOf("beIN SPORTS NEWS" to listOf("beIN SPORTS NEWS", "beIN Sports News")) +
        (1..9).map { "beIN SPORTS $it HD" to listOf("beIN SPORTS $it", "beIN Sports $it", "beIN SPORT $it") } +
        listOf("beIN SPORTS XTRA 1" to listOf("beIN SPORTS XTRA 1", "beIN Xtra 1"), "beIN SPORTS XTRA 2" to listOf("beIN SPORTS XTRA 2", "beIN Xtra 2"),
            "beIN SPORTS 4K" to listOf("beIN SPORTS 4K"), "beIN SPORTS MAX 1" to listOf("beIN SPORTS MAX 1"), "beIN SPORTS MAX 2" to listOf("beIN SPORTS MAX 2"),
            "beIN SPORTS PREMIUM 1" to listOf("beIN SPORTS PREMIUM 1"), "beIN SPORTS PREMIUM 2" to listOf("beIN SPORTS PREMIUM 2"), "beIN SPORTS PREMIUM 3" to listOf("beIN SPORTS PREMIUM 3"),
            "beIN SPORTS AFC 1" to listOf("beIN SPORTS AFC 1", "beIN AFC 1"), "beIN SPORTS AFC 2" to listOf("beIN SPORTS AFC 2", "beIN AFC 2")))
}
