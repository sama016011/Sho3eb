@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import android.app.TimePickerDialog
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.islam.*
import com.sho3eb.app.ui.theme.DangerRed
import com.sho3eb.app.ui.theme.SuccessGreen
import com.sho3eb.app.ui.theme.WarnAmber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.ZonedDateTime

@Composable
private fun IChips(content: @Composable RowScope.() -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), content = content)

private fun pickTimeDialog(ctx: Context, cur: Int, set: (Int) -> Unit) =
    TimePickerDialog(ctx, { _, h, m -> set(h * 60 + m) }, cur / 60, cur % 60, false).show()

private fun hm(v: Int) = String.format(java.util.Locale.US, "%02d:%02d", v / 60, v % 60)

private fun countdown(sec: Long): String {
    if (sec <= 0) return "00:00:00"
    return String.format(java.util.Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
}

// =====================================================================
//                          أسماء الله الحسنى
// =====================================================================
@Composable
fun AsmaScreen(nav: NavController) {
    val ctx = LocalContext.current
    val groups = remember { Content.load(ctx, "asma") }
    val items = groups.firstOrNull()?.items ?: emptyList()
    var q by remember { mutableStateOf("") }
    var open by remember { mutableStateOf<Int?>(null) }
    val shown = items.withIndex().filter { q.isBlank() || it.value.title.contains(q) || it.value.body.contains(q) }
    val all = remember(items) { items.joinToString("\n") { it.title + ". " + it.body } }

    ScreenScaffold(title = tr("أسماء الله الحسنى", "Names of Allah"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Card(Modifier.fillMaxWidth().padding(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(14.dp)) {
                    Text(tr("قال ﷺ: «إن لله تسعة وتسعين اسماً، مائة إلا واحداً، من أحصاها دخل الجنة» (متفق عليه)", "“Allah has ninety-nine names; whoever enumerates them enters Paradise.” (Bukhari & Muslim)"), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.SemiBold)
                    Text(tr("وإحصاؤها: حفظها وفهم معانيها والعمل بمقتضاها ودعاء الله بها.", "Enumerating means memorizing, understanding and calling upon Him by them."), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    TtsControls(all, "Asma_Allah_Alhusna")
                }
            }
            SearchField(q) { q = it }
            LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.index }) { (i, it0) ->
                    Card(onClick = { open = i }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${i + 1}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(it0.title, fontWeight = FontWeight.Bold, fontSize = if (it0.title.length > 10) 13.sp else 18.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
    open?.let { i ->
        val it0 = items[i]
        AlertDialog(
            onDismissRequest = { open = null; Tts.stop() },
            title = { Text(it0.title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(it0.body, fontSize = 18.sp, textAlign = TextAlign.Center, lineHeight = 30.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(tr("ادعُ: «يا ", "Pray: “Ya ") + it0.title.removePrefix("ال") + "»", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    IconButton(onClick = { Tts.speak(ctx, it0.title + ". " + it0.body) }) { Icon(Icons.Filled.VolumeUp, null, tint = MaterialTheme.colorScheme.primary) }
                }
            },
            confirmButton = { if (i < items.size - 1) TextButton(onClick = { open = i + 1 }) { Text(tr("التالي", "Next")) } },
            dismissButton = { if (i > 0) TextButton(onClick = { open = i - 1 }) { Text(tr("السابق", "Previous")) } }
        )
    }
}

// =====================================================================
//                          السبحة الإلكترونية
// =====================================================================
private val dhikrs get() = listOf(
    tr("سبحان الله", "SubhanAllah"), tr("الحمد لله", "Alhamdulillah"), tr("الله أكبر", "Allahu Akbar"), tr("لا إله إلا الله", "La ilaha illallah"),
    tr("أستغفر الله", "Astaghfirullah"), tr("سبحان الله وبحمده", "SubhanAllahi wa bihamdih"), tr("سبحان الله وبحمده، سبحان الله العظيم", "SubhanAllahi wa bihamdihi, SubhanAllahil-'Azim"),
    tr("لا حول ولا قوة إلا بالله", "La hawla wa la quwwata illa billah"), tr("اللهم صلِّ وسلم على نبينا محمد", "Salawat upon the Prophet ﷺ"),
    tr("لا إله إلا الله وحده لا شريك له، له الملك وله الحمد، وهو على كل شيء قدير", "La ilaha illallahu wahdahu la sharika lah...")
)

@Composable
fun TasbeehScreen(nav: NavController) {
    val ctx = LocalContext.current
    var idx by remember { mutableIntStateOf(Extras.tasbeehIndex) }
    var count by remember { mutableIntStateOf(Extras.tasbeehCount) }
    var target by remember { mutableIntStateOf(Extras.tasbeehTarget) }
    var vib by remember { mutableStateOf(Extras.tasbeehVibrate) }
    var custom by remember { mutableStateOf(Extras.tasbeehCustom) }
    var editCustom by remember { mutableStateOf(false) }
    var rounds by remember { mutableIntStateOf(0) }
    var todayTotal by remember { mutableIntStateOf(Extras.tasbeehDay(Fmt.today())) }
    val list = dhikrs + listOfNotNull(custom.takeIf { it.isNotBlank() })
    val text = list.getOrElse(idx) { list.first() }
    val key = if (idx < dhikrs.size) "d$idx" else "custom"
    val vibrator = remember { ctx.getSystemService(Vibrator::class.java) }

    fun buzz(ms: Long) {
        if (!vib) return
        try {
            if (Build.VERSION.SDK_INT >= 26) vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    fun tap() {
        count++
        Extras.tasbeehCount = count
        Extras.addTasbeehDay(Fmt.today(), 1); todayTotal++
        Extras.addTasbeehTotal(key, 1)
        if (target > 0 && count % target == 0) { rounds++; buzz(400) } else buzz(25)
    }

    ScreenScaffold(
        title = tr("السبحة الإلكترونية", "Digital tasbeeh"), onBack = { nav.popBackStack() },
        actions = { IconButton(onClick = { count = 0; rounds = 0; Extras.tasbeehCount = 0 }) { Icon(Icons.Filled.RestartAlt, tr("تصفير", "Reset")) } }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            IChips {
                list.forEachIndexed { i, s ->
                    FilterChip(idx == i, { idx = i; Extras.tasbeehIndex = i; count = 0; rounds = 0; Extras.tasbeehCount = 0 }, label = { Text(if (s.length > 22) s.take(22) + "…" else s) })
                }
                AssistChip(onClick = { editCustom = true }, label = { Text(tr("➕ ذكر خاص", "➕ Custom")) })
            }
            Text(text, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary, lineHeight = 34.sp)
            Box(
                Modifier.size(240.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer).clickable { tap() },
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    progress = { if (target > 0) (count % target).toFloat() / target else 0f },
                    modifier = Modifier.fillMaxSize().padding(8.dp), strokeWidth = 10.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$count", fontSize = 64.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    if (target > 0) Text("${count % target} / $target", style = MaterialTheme.typography.bodyMedium)
                    Text(tr("اضغط للتسبيح", "Tap to count"), style = MaterialTheme.typography.bodySmall)
                }
            }
            if (rounds > 0) Text(tr("أتممت $rounds دورة ✅", "$rounds rounds completed ✅"), color = SuccessGreen, fontWeight = FontWeight.SemiBold)
            Text(tr("العدد المستهدف", "Target"), style = MaterialTheme.typography.labelLarge)
            IChips {
                listOf(33, 100, 1000, 0).forEach { t -> FilterChip(target == t, { target = t; Extras.tasbeehTarget = t }, label = { Text(if (t == 0) "∞" else "$t") }) }
            }
            SwitchRow(tr("اهتزاز مع كل تسبيحة", "Vibrate"), tr("اهتزاز أطول عند إتمام العدد", "Longer at target"), vib, Icons.Filled.Vibration) { vib = it; Extras.tasbeehVibrate = it }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(tr("إحصائياتك", "Your stats"), fontWeight = FontWeight.Bold)
                    KeyValue(tr("اليوم", "Today"), "$todayTotal")
                    KeyValue(tr("آخر 7 أيام", "Last 7 days"), "${(0 until 7).sumOf { Extras.tasbeehDay(Fmt.today() - it) }}")
                    KeyValue(tr("إجمالي هذا الذكر", "Total for this dhikr"), "${Extras.tasbeehTotal(key)}")
                }
            }
            Text(tr("«كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن: سبحان الله وبحمده، سبحان الله العظيم» (متفق عليه)", "Two words light on the tongue, heavy on the scale... (Bukhari & Muslim)"), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
    }
    if (editCustom) {
        var v by remember { mutableStateOf(custom) }
        AlertDialog(
            onDismissRequest = { editCustom = false },
            title = { Text(tr("ذكر خاص", "Custom dhikr")) },
            text = { OutlinedTextField(v, { v = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tr("نص الذكر", "Text")) }) },
            confirmButton = { TextButton(onClick = { custom = v.trim(); Extras.tasbeehCustom = custom; if (custom.isNotBlank()) { idx = dhikrs.size; Extras.tasbeehIndex = idx }; editCustom = false }) { Text(tr("حفظ", "Save")) } },
            dismissButton = { TextButton(onClick = { editCustom = false }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
}

// =====================================================================
//                     المناسبات الإسلامية والتقويم الهجري
// =====================================================================
@Composable
fun OccasionsScreen(nav: NavController) {
    var ver by remember { mutableIntStateOf(0) }
    val today = LocalDate.now()
    val h = remember(ver) { Occ.hijri(today) }
    val list = remember(ver) { Occ.upcoming(today) }
    val white = remember(ver) { Occ.nextWhiteDays(today) }
    var remind by remember { mutableStateOf(Extras.occasionsRemind) }
    var before by remember { mutableIntStateOf(Extras.occasionsDaysBefore) }
    var whiteR by remember { mutableStateOf(Extras.whiteDaysRemind) }
    var mt by remember { mutableStateOf(Extras.monThuRemind) }

    ScreenScaffold(title = tr("المناسبات الإسلامية", "Islamic occasions"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(tr("اليوم", "Today"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f))
                        Text("${h.d} ${Occ.hijriMonths[h.m - 1]} ${h.y}" + tr(" هـ", " AH"), color = MaterialTheme.colorScheme.onPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(Fmt.date(today), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { Extras.hijriAdjust = (Extras.hijriAdjust - 1).coerceAtLeast(-2); ver++ }) { Text("−1", color = MaterialTheme.colorScheme.onPrimary) }
                            Text(tr("تعديل التاريخ: ${Extras.hijriAdjust}", "Adjust: ${Extras.hijriAdjust}"), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { Extras.hijriAdjust = (Extras.hijriAdjust + 1).coerceAtMost(2); ver++ }) { Text("+1", color = MaterialTheme.colorScheme.onPrimary) }
                        }
                        Text(tr("حسب تقويم أم القرى؛ عدّله يوماً إن اختلفت رؤية الهلال في بلدك", "Umm al-Qura; adjust by a day if your local sighting differs"), color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                    }
                }
            }
            items(list, key = { "${it.def.m}_${it.def.d}_${it.hijriYear}" }) { u ->
                Card(Modifier.fillMaxWidth(), colors = if (u.isNow) CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.12f)) else CardDefaults.cardColors()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(u.def.emoji, fontSize = 26.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(u.def.name, fontWeight = FontWeight.Bold)
                                Text("${u.def.d} ${Occ.hijriMonths[u.def.m - 1]} ${u.hijriYear} • " + Fmt.date(u.date) + if (u.def.days > 1) tr(" (${u.def.days} أيام)", " (${u.def.days} days)") else "", style = MaterialTheme.typography.bodySmall)
                            }
                            when {
                                u.isNow -> StatusChip(tr("الآن", "Now"), SuccessGreen)
                                u.daysLeft == 1 -> StatusChip(tr("غداً", "Tomorrow"), WarnAmber)
                                else -> StatusChip(tr("بعد ${u.daysLeft} يوم", "${u.daysLeft} d"), MaterialTheme.colorScheme.primary)
                            }
                        }
                        Text(u.def.desc, style = MaterialTheme.typography.bodyMedium)
                        if (u.def.fasting) Text(tr("🍽️ يُستحب الصيام", "🍽️ Recommended fasting"), style = MaterialTheme.typography.bodySmall, color = SuccessGreen)
                    }
                }
            }
            white?.let { w ->
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🌕", fontSize = 26.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(tr("الأيام البيض القادمة", "Next white days"), fontWeight = FontWeight.Bold)
                                Text(Fmt.date(w) + " ← " + Fmt.date(w.plusDays(2)) + tr(" (13-15 من الشهر الهجري)", " (13th–15th)"), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            item { SectionTitle(tr("التذكير", "Reminders")) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        SwitchRow(tr("تذكير قبل المناسبات", "Remind before occasions"), tr("إشعار مساءً قبل المناسبة", "Evening notification beforehand"), remind, Icons.Filled.NotificationsActive) { remind = it; Extras.occasionsRemind = it }
                        if (remind) IChips {
                            listOf(1, 2, 3, 7).forEach { d -> FilterChip(before == d, { before = d; Extras.occasionsDaysBefore = d }, label = { Text(if (d == 1) tr("قبلها بيوم", "1 day") else tr("قبلها بـ $d أيام", "$d days")) }) }
                        }
                        SwitchRow(tr("تذكير صيام الأيام البيض", "White days fasting"), null, whiteR, Icons.Filled.Brightness2) { whiteR = it; Extras.whiteDaysRemind = it }
                        SwitchRow(tr("تذكير صيام الاثنين والخميس", "Monday & Thursday fasting"), null, mt, Icons.Filled.CalendarMonth) { mt = it; Extras.monThuRemind = it }
                    }
                }
            }
        }
    }
}

// =====================================================================
//                         أوقات رمضان والإمساكية
// =====================================================================
@Composable
fun RamadanScreen(nav: NavController) {
    val ctx = LocalContext.current
    val info = remember { Occ.ramadan() }
    var now by remember { mutableStateOf(ZonedDateTime.now(Prayer.zone())) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = ZonedDateTime.now(Prayer.zone()) } }
    var suhoor by remember { mutableStateOf(Extras.suhoorRemind) }
    var suhoorMin by remember { mutableIntStateOf(Extras.suhoorMinutes) }
    var imsak by remember { mutableIntStateOf(Extras.imsakMinutes) }
    var dua by remember { mutableStateOf(Extras.iftarDua) }

    val rows = remember(info, imsak) {
        info?.let { (y, start, len) ->
            (0 until len).map { i ->
                val d = start.plusDays(i.toLong())
                val t = Prayer.timesFor(d)
                listOf("${i + 1}", Fmt.date(d), Prayer.fmt(t[Prayer.FAJR].minusMinutes(imsak.toLong())), Prayer.fmt(t[Prayer.FAJR]), Prayer.fmt(t[Prayer.DHUHR]), Prayer.fmt(t[Prayer.ASR]), Prayer.fmt(t[Prayer.MAGHRIB]), Prayer.fmt(t[Prayer.ISHA]))
            }
        } ?: emptyList()
    }
    val doc = {
        ReportDoc(
            tr("إمساكية رمضان ", "Ramadan timetable ") + (info?.first ?: ""), IslamPrefs.cityName,
            listOf(tr("المدينة", "City") to IslamPrefs.cityName, tr("الإمساك", "Imsak") to tr("قبل الفجر بـ $imsak دقيقة", "$imsak min before Fajr")),
            listOf(RTable(tr("الإمساكية", "Timetable"), listOf(tr("اليوم", "Day"), tr("التاريخ", "Date"), tr("الإمساك", "Imsak"), tr("الفجر", "Fajr"), tr("الظهر", "Dhuhr"), tr("العصر", "Asr"), tr("المغرب", "Maghrib"), tr("العشاء", "Isha")), rows)),
            fileName = "imsakiya_" + IslamPrefs.cityName
        )
    }

    ScreenScaffold(
        title = tr("أوقات رمضان", "Ramadan times"), onBack = { nav.popBackStack() },
        actions = { if (rows.isNotEmpty()) PdfShareButton(null, doc = doc) { c -> Reports.doc(c, doc()) } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(18.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        val on = MaterialTheme.colorScheme.onPrimary
                        if (info == null) Text(tr("تعذر حساب رمضان", "Could not compute Ramadan"), color = on)
                        else {
                            val (y, start, len) = info
                            val end = start.plusDays((len - 1).toLong())
                            val today = now.toLocalDate()
                            if (today.isBefore(start)) {
                                val days = start.toEpochDay() - today.toEpochDay()
                                Text("🌙 " + tr("رمضان $y هـ", "Ramadan $y AH"), color = on, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                Text(tr("بعد $days يوم", "In $days days"), color = on, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                Text(tr("يبدأ تقريباً ", "Starts around ") + Fmt.date(start) + tr(" (حسب الرؤية)", " (subject to sighting)"), color = on.copy(alpha = 0.85f))
                            } else {
                                val t = Prayer.timesFor(today)
                                val fajr = t[Prayer.FAJR]; val maghrib = t[Prayer.MAGHRIB]
                                val dayNo = today.toEpochDay() - start.toEpochDay() + 1
                                Text(tr("اليوم $dayNo من رمضان", "Day $dayNo of Ramadan"), color = on, fontWeight = FontWeight.Bold)
                                if (now.isBefore(fajr)) {
                                    Text(tr("المتبقي على الإمساك (الفجر)", "Until Fajr (suhoor ends)"), color = on.copy(alpha = 0.85f))
                                    Text(countdown(java.time.Duration.between(now, fajr).seconds), color = on, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                                } else if (now.isBefore(maghrib)) {
                                    Text(tr("المتبقي على الإفطار", "Until iftar"), color = on.copy(alpha = 0.85f))
                                    Text(countdown(java.time.Duration.between(now, maghrib).seconds), color = on, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                                    Text(tr("الإفطار: ", "Iftar: ") + Prayer.fmt(maghrib), color = on)
                                } else {
                                    val f2 = Prayer.timesFor(today.plusDays(1))[Prayer.FAJR]
                                    Text(tr("تقبّل الله صيامك 🤍 المتبقي على السحور", "May Allah accept 🤍 Until suhoor ends"), color = on.copy(alpha = 0.85f))
                                    Text(countdown(java.time.Duration.between(now, f2).seconds), color = on, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(tr("ينتهي تقريباً ", "Ends around ") + Fmt.date(end), color = on.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        SwitchRow(tr("تذكير السحور", "Suhoor reminder"), tr("قبل الفجر بـ $suhoorMin دقيقة", "$suhoorMin min before Fajr"), suhoor, Icons.Filled.Alarm) {
                            suhoor = it; Extras.suhoorRemind = it; IslamAlarms.scheduleRamadan(ctx)
                        }
                        if (suhoor) IChips { listOf(20, 30, 45, 60, 90).forEach { m -> FilterChip(suhoorMin == m, { suhoorMin = m; Extras.suhoorMinutes = m; IslamAlarms.scheduleRamadan(ctx) }, label = { Text(tr("$m د", "${m}m")) }) } }
                        SwitchRow(tr("دعاء الإفطار عند المغرب", "Iftar du'a at Maghrib"), null, dua, Icons.Filled.Restaurant) { dua = it; Extras.iftarDua = it; IslamAlarms.scheduleRamadan(ctx) }
                        Text(tr("الإمساك قبل الفجر بـ:", "Imsak before Fajr:"), style = MaterialTheme.typography.labelLarge)
                        IChips { listOf(0, 5, 10, 15, 20).forEach { m -> FilterChip(imsak == m, { imsak = m; Extras.imsakMinutes = m }, label = { Text(if (m == 0) tr("عند الفجر", "At Fajr") else tr("$m د", "${m}m")) }) } }
                        Text(tr("الإمساك الشرعي يكون عند أذان الفجر، والإمساك قبله احتياط.", "Fasting legally starts at Fajr; imsak earlier is precautionary."), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { SectionTitle(tr("الإمساكية • ", "Timetable • ") + IslamPrefs.cityName) }
            item {
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp)).padding(6.dp)) {
                    listOf(tr("يوم", "Day"), tr("إمساك", "Imsak"), tr("فجر", "Fajr"), tr("مغرب", "Maghrib"), tr("عشاء", "Isha")).forEachIndexed { i, s ->
                        Text(s, Modifier.weight(if (i == 0) 0.6f else 1f), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            items(rows) { r ->
                val isToday = r[1] == Fmt.date(LocalDate.now())
                Row(Modifier.fillMaxWidth().background(if (isToday) SuccessGreen.copy(alpha = 0.15f) else Color.Transparent).padding(vertical = 6.dp, horizontal = 6.dp)) {
                    listOf(r[0], r[2], r[3], r[6], r[7]).forEachIndexed { i, s ->
                        Text(s, Modifier.weight(if (i == 0) 0.6f else 1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

// =====================================================================
//                           الختمة والورد اليومي
// =====================================================================
@Composable
fun KhatmaScreen(nav: NavController) {
    val ctx = LocalContext.current
    var ver by remember { mutableIntStateOf(0) }
    var days by remember { mutableIntStateOf(Extras.khatmaDays) }
    var fromPage by remember { mutableStateOf("1") }
    var markTo by remember { mutableStateOf<String?>(null) }
    var remind by remember { mutableStateOf(Extras.wirdRemind) }
    var minute by remember { mutableIntStateOf(Extras.wirdMinute) }
    val active = remember(ver) { Khatma.active }

    ScreenScaffold(title = tr("الختمة والورد اليومي", "Khatma & daily portion"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!active) {
                InfoBanner(tr("اختر عدد أيام الختمة وسيحسب التطبيق وردك اليومي من الصفحات، ويذكّرك به كل يوم.", "Choose your khatma length; the app computes your daily pages and reminds you."))
                Text(tr("أختم القرآن خلال:", "Finish the Quran in:"), fontWeight = FontWeight.Bold)
                IChips {
                    listOf(7, 10, 15, 20, 30, 40, 60, 90, 120, 365).forEach { d -> FilterChip(days == d, { days = d }, label = { Text(tr("$d يوم", "$d days")) }) }
                }
                NumberField(fromPage, { fromPage = it }, tr("البدء من صفحة", "Start from page"))
                val fp = (Fmt.parseInt(fromPage) ?: 1).coerceIn(1, 604)
                Text(tr("الورد اليومي: نحو ", "Daily: about ") + "${kotlin.math.ceil((604 - fp + 1).toDouble() / days).toInt()}" + tr(" صفحة (≈ ", " pages (≈ ") + String.format(java.util.Locale.US, "%.1f", (604 - fp + 1).toDouble() / days / 20) + tr(" جزء)", " juz)"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                Button(onClick = { Khatma.start(days, fp); IslamAlarms.scheduleWird(ctx); ver++ }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(tr("ابدأ الختمة", "Start khatma"))
                }
                if (Extras.khatmaCount > 0) Text(tr("عدد ختماتك السابقة: ${Extras.khatmaCount} 🌟", "Completed khatmas: ${Extras.khatmaCount} 🌟"), color = SuccessGreen)
            } else {
                val target = Khatma.todayTarget()
                val done = Extras.khatmaDone
                val ahead = Khatma.ahead
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(tr("اليوم ${Khatma.dayNo} من ${Extras.khatmaDays}", "Day ${Khatma.dayNo} of ${Extras.khatmaDays}"), fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(progress = { Khatma.progress }, modifier = Modifier.fillMaxWidth().height(10.dp))
                        Text(tr("قرأت حتى صفحة $done من 604 (${(Khatma.progress * 100).toInt()}%)", "Read up to page $done of 604 (${(Khatma.progress * 100).toInt()}%)"))
                        Text(tr("ورد اليوم: من صفحة ${target.first} إلى ${target.last}", "Today: pages ${target.first}–${target.last}"), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        Text(
                            when {
                                Khatma.finished -> tr("🎉 ختمت القرآن! «اللهم ارحمني بالقرآن»", "🎉 Khatma complete!")
                                ahead >= 0 -> tr("✅ أنت على الخطة" + if (ahead > 0) " ومتقدم $ahead صفحة" else "", "✅ On track" + if (ahead > 0) ", $ahead pages ahead" else "")
                                else -> tr("⏳ متأخر ${-ahead} صفحة عن الخطة", "⏳ ${-ahead} pages behind")
                            },
                            color = if (ahead >= 0 || Khatma.finished) SuccessGreen else WarnAmber
                        )
                    }
                }
                Button(onClick = { nav.navigate("mushaf/${(done + 1).coerceIn(1, 604)}") }, modifier = Modifier.fillMaxWidth().height(50.dp), enabled = !Khatma.finished) {
                    Icon(Icons.Filled.MenuBook, null); Spacer(Modifier.width(6.dp)); Text(tr("اقرأ الآن من صفحة ${(done + 1).coerceIn(1, 604)}", "Read from page ${(done + 1).coerceIn(1, 604)}"))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { Khatma.markRead(target.last); ver++; toast(ctx, tr("بارك الله فيك ✅", "Well done ✅")) }, modifier = Modifier.weight(1f)) { Text(tr("أتممت ورد اليوم", "Done today"), maxLines = 1) }
                    OutlinedButton(onClick = { markTo = "${IslamPrefs.lastPage}" }, modifier = Modifier.weight(1f)) { Text(tr("وصلت إلى صفحة…", "I reached page…"), maxLines = 1) }
                }
                SwitchRow(tr("تذكير يومي بالورد", "Daily reminder"), hm(minute), remind, Icons.Filled.Alarm) { remind = it; Extras.wirdRemind = it; IslamAlarms.scheduleWird(ctx) }
                if (remind) OutlinedButton(onClick = { pickTimeDialog(ctx, minute) { v -> minute = v; Extras.wirdMinute = v; IslamAlarms.scheduleWird(ctx) } }) { Text(tr("وقت التذكير: ", "Time: ") + hm(minute)) }
                if (Khatma.finished) Button(onClick = { Khatma.start(Extras.khatmaDays, 1); ver++ }, modifier = Modifier.fillMaxWidth()) { Text(tr("ابدأ ختمة جديدة", "Start a new khatma")) }
                TextButton(onClick = { Khatma.stop(); IslamAlarms.scheduleWird(ctx); ver++ }, modifier = Modifier.fillMaxWidth()) { Text(tr("إيقاف الختمة الحالية", "Stop current khatma"), color = DangerRed) }
                Text(tr("آخر صفحة فتحتها في المصحف: ${IslamPrefs.lastPage}", "Last page opened in Mushaf: ${IslamPrefs.lastPage}"), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    markTo?.let { v0 ->
        var v by remember { mutableStateOf(v0) }
        AlertDialog(
            onDismissRequest = { markTo = null },
            title = { Text(tr("وصلت إلى صفحة", "Reached page")) },
            text = { NumberField(v, { v = it }, tr("رقم الصفحة (1-604)", "Page (1-604)")) },
            confirmButton = { TextButton(onClick = { Fmt.parseInt(v)?.let { Khatma.markRead(it) }; markTo = null; ver++ }) { Text(tr("حفظ", "Save")) } },
            dismissButton = { TextButton(onClick = { markTo = null }) { Text(tr("إلغاء", "Cancel")) } }
        )
    }
}

// =====================================================================
//                            متابعة الصلوات
// =====================================================================
@Composable
fun PrayerTrackerScreen(nav: NavController) {
    var day by remember { mutableStateOf(Fmt.today()) }
    var ver by remember { mutableIntStateOf(0) }
    val st = remember(day, ver) { PrayerLog.get(day) }
    val sunnah = remember(day, ver) { Extras.sunnahDay(day) }
    val colors = listOf(MaterialTheme.colorScheme.outline, SuccessGreen, Color(0xFF0E7490), WarnAmber, Color(0xFF7C3AED), DangerRed)
    var track by remember { mutableStateOf(Extras.prayerTrackNotify) }

    ScreenScaffold(title = tr("متابعة الصلوات", "Prayer tracker"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(tr("آخر 7 أيام", "Last 7 days"), "${PrayerLog.percent(7)}%", Icons.Filled.Insights, SuccessGreen, Modifier.weight(1f))
                    StatCard(tr("آخر 30 يوماً", "Last 30 days"), "${PrayerLog.percent(30)}%", Icons.Filled.CalendarMonth, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatCard(tr("أيام متتالية", "Streak"), "${PrayerLog.streak()} 🔥", Icons.Filled.Whatshot, WarnAmber, Modifier.weight(1f))
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { day -= 1 }) { Icon(Icons.Filled.ChevronRight, null) }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (day == Fmt.today()) tr("اليوم", "Today") else Fmt.date(day), fontWeight = FontWeight.Bold)
                        Text(Occ.format(LocalDate.ofEpochDay(day)), style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { if (day < Fmt.today()) day += 1 }, enabled = day < Fmt.today()) { Icon(Icons.Filled.ChevronLeft, null) }
                }
            }
            items(5) { i ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(PrayerLog.names[i], fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            StatusChip(PrayerLog.statusNames[st[i]], colors[st[i]])
                        }
                        IChips {
                            (1..5).forEach { s ->
                                FilterChip(st[i] == s, { PrayerLog.set(day, i, if (st[i] == s) 0 else s); ver++ }, label = { Text(PrayerLog.statusNames[s]) })
                            }
                        }
                    }
                }
            }
            item { SectionTitle(tr("السنن الرواتب والنوافل", "Sunnah prayers")) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        PrayerLog.sunnahNames.forEachIndexed { b, n ->
                            val on = (sunnah shr b) and 1 == 1
                            Row(Modifier.fillMaxWidth().clickable { Extras.setSunnah(day, sunnah xor (1 shl b)); ver++ }, verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(on, { Extras.setSunnah(day, sunnah xor (1 shl b)); ver++ })
                                Text(n)
                            }
                        }
                        Text(tr("«من صلى اثنتي عشرة ركعة في يوم وليلة بُني له بهن بيت في الجنة» (مسلم)", "Twelve sunnah rak'ahs daily earn a house in Paradise (Muslim)"), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
                    }
                }
            }
            item { SectionTitle(tr("آخر 7 أيام", "Last 7 days")) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        (6 downTo 0).forEach { k ->
                            val d = Fmt.today() - k
                            val s = PrayerLog.get(d)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(Fmt.date(d).take(5), Modifier.width(56.dp), style = MaterialTheme.typography.bodySmall)
                                s.forEach { v -> Box(Modifier.padding(2.dp).size(28.dp).clip(RoundedCornerShape(6.dp)).background(colors[v].copy(alpha = if (v == 0) 0.25f else 0.85f))) }
                                Spacer(Modifier.width(8.dp))
                                Text("${s.count { PrayerLog.done(it) }}/5", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            item {
                SwitchRow(tr("زر «صليت» في إشعار الأذان", "“Prayed” button on azan notification"), tr("تسجيل الصلاة بلمسة من الإشعار", "Log with one tap"), track, Icons.Filled.TouchApp) { track = it; Extras.prayerTrackNotify = it }
            }
        }
    }
}

// =====================================================================
//                         إعدادات الأذان الاحترافية
// =====================================================================
@Composable
fun AzanSettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ver by remember { mutableIntStateOf(0) }
    var downloading by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableFloatStateOf(0f) }
    var playing by remember { mutableStateOf<String?>(null) }
    var showCustom by remember { mutableStateOf(false) }
    var pickFor by remember { mutableStateOf<Int?>(null) }
    var vol by remember { mutableIntStateOf(Extras.azanVolume) }
    var fade by remember { mutableStateOf(Extras.azanFadeIn) }
    var short by remember { mutableIntStateOf(Extras.azanShortSec) }
    var dua by remember { mutableStateOf(Extras.azanDuaAfter) }
    var silent by remember { mutableStateOf(Extras.azanSilentInPocket) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    DisposableEffect(Unit) { onDispose { player[0]?.release(); player[0] = null } }
    val sounds = remember(ver) { IslamPrefs.azanSounds }

    fun stopPreview() { try { player[0]?.stop() } catch (_: Exception) {}; player[0]?.release(); player[0] = null; playing = null }
    fun preview(id: String, src: String) {
        if (playing == id) { stopPreview(); return }
        stopPreview()
        playing = id
        try {
            player[0] = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(src)
                setVolume(vol / 100f, vol / 100f)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { playing = null }
                setOnErrorListener { _, _, _ -> playing = null; toast(ctx, tr("تعذر التشغيل، تحقق من الإنترنت", "Playback failed, check connection")); true }
                prepareAsync()
            }
        } catch (e: Exception) { playing = null }
    }
    fun nameOf(path: String): String = when {
        path.isBlank() -> tr("الافتراضي", "Default")
        path == "none" -> tr("إشعار فقط بدون أذان", "Notification only")
        else -> sounds.firstOrNull { it.path == path }?.name ?: File(path).name
    }

    ScreenScaffold(title = tr("صوت الأذان", "Azan sounds"), onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { SectionTitle(tr("مكتبة المؤذنين", "Muezzin library")) }
            item { Text(tr("استمع للأذان قبل تنزيله، ثم نزّله ليعمل بدون إنترنت. المصدر: AlAdhan.com", "Preview, then download for offline use. Source: AlAdhan.com"), style = MaterialTheme.typography.bodySmall) }
            items(AzanCatalog.items, key = { it.id }) { it0 ->
                val f = AzanCatalog.fileFor(ctx, it0)
                val have = f.exists() && f.length() > 10_000
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (it0.fajr) Icons.Filled.Brightness3 else Icons.Filled.Campaign, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(it0.name, fontWeight = FontWeight.SemiBold)
                            if (downloading == it0.id) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                            else Text(if (have) tr("✅ منزّل", "✅ Downloaded") else tr("غير منزّل", "Not downloaded"), style = MaterialTheme.typography.bodySmall, color = if (have) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { preview(it0.id, if (have) f.absolutePath else it0.url) }) {
                            Icon(if (playing == it0.id) Icons.Filled.StopCircle else Icons.Filled.PlayCircle, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        if (!have) IconButton(onClick = {
                            if (downloading != null) return@IconButton
                            downloading = it0.id; progress = 0f
                            scope.launch {
                                val ok = withContext(Dispatchers.IO) {
                                    try { Net.download(it0.url, f) { d, t -> if (t > 0) progress = d.toFloat() / t }; true } catch (e: Exception) { false }
                                }
                                downloading = null
                                if (ok) {
                                    if (IslamPrefs.azanSounds.none { s -> s.path == f.absolutePath }) IslamPrefs.azanSounds = IslamPrefs.azanSounds + AzanSound(it0.name, f.absolutePath)
                                    if (it0.fajr && IslamPrefs.fajrAzanPath.isBlank()) IslamPrefs.fajrAzanPath = f.absolutePath
                                    else if (!it0.fajr && IslamPrefs.azanPath.isBlank()) IslamPrefs.azanPath = f.absolutePath
                                    toast(ctx, tr("تم التنزيل ✅", "Downloaded ✅")); ver++
                                } else toast(ctx, tr("تعذر التنزيل، تحقق من الإنترنت", "Download failed"))
                            }
                        }) { Icon(Icons.Filled.Download, null) }
                    }
                }
            }
            item {
                OutlinedButton(onClick = { showCustom = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.LibraryMusic, null); Spacer(Modifier.width(6.dp)); Text(tr("إضافة أذان من ملف أو رابط", "Add from file or link"))
                }
            }
            item { SectionTitle(tr("الأذان لكل صلاة", "Azan per prayer")) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(vertical = 4.dp)) {
                        ListItem(
                            headlineContent = { Text(tr("الأذان العام (لكل الصلوات)", "General azan")) },
                            supportingContent = { Text(nameOf(IslamPrefs.azanPath)) },
                            leadingContent = { Icon(Icons.Filled.Campaign, null) },
                            modifier = Modifier.clickable { pickFor = -1 }
                        )
                        ListItem(
                            headlineContent = { Text(tr("أذان الفجر", "Fajr azan")) },
                            supportingContent = { Text(if (IslamPrefs.fajrAzanPath.isBlank()) tr("مثل الأذان العام", "Same as general") else nameOf(IslamPrefs.fajrAzanPath)) },
                            leadingContent = { Icon(Icons.Filled.Brightness3, null) },
                            modifier = Modifier.clickable { pickFor = -2 }
                        )
                        HorizontalDivider()
                        listOf(Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA).forEach { k ->
                            ListItem(
                                headlineContent = { Text(Prayer.names[k]) },
                                supportingContent = { Text(Extras.azanFor(k).let { if (it.isBlank()) tr("الأذان العام", "General") else nameOf(it) }) },
                                modifier = Modifier.clickable { pickFor = k }
                            )
                        }
                    }
                }
            }
            item { SectionTitle(tr("خيارات التشغيل", "Playback options")) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(tr("مستوى الصوت: $vol%", "Volume: $vol%"))
                        Slider(vol.toFloat(), { vol = it.toInt() }, valueRange = 10f..100f, onValueChangeFinished = { Extras.azanVolume = vol })
                        SwitchRow(tr("رفع الصوت تدريجياً", "Gradual volume"), tr("يبدأ هادئاً ويرتفع خلال 10 ثوانٍ", "Starts soft, rises over 10s"), fade, Icons.Filled.TrendingUp) { fade = it; Extras.azanFadeIn = it }
                        Text(tr("مدة الأذان", "Duration"), style = MaterialTheme.typography.labelLarge)
                        IChips {
                            listOf(0 to tr("كامل", "Full"), 30 to tr("30 ثانية", "30 s"), 15 to tr("التكبير فقط", "Takbir only")).forEach { (s, l) -> FilterChip(short == s, { short = s; Extras.azanShortSec = s }, label = { Text(l) }) }
                        }
                        SwitchRow(tr("الدعاء بعد الأذان", "Du'a after azan"), tr("إشعار بدعاء الوسيلة عند انتهاء الأذان", "Show the wasilah du'a after"), dua, Icons.Filled.FavoriteBorder) { dua = it; Extras.azanDuaAfter = it }
                        SwitchRow(tr("احترام الوضع الصامت والاهتزاز", "Respect silent/vibrate mode"), tr("لا يُشغَّل الأذان إذا كان الهاتف صامتاً", "Skip audio when phone is silenced"), silent, Icons.Filled.VolumeOff) { silent = it; Extras.azanSilentInPocket = it }
                        Text(tr("لإيقاف الأذان أثناء التشغيل: اضغط «إيقاف» في الإشعار.", "To stop during playback: tap “Stop” in the notification."), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Button(onClick = {
                    val p = IslamPrefs.azanPath
                    if (p.isNotBlank() && File(p).exists()) AzanService.start(ctx, p, tr("تجربة", "Test"), preview = true) else toast(ctx, tr("اختر أذاناً عاماً أولاً", "Choose a general azan first"))
                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(tr("تجربة الأذان كما سيعمل", "Test azan as it will play")) }
            }
        }
    }

    if (showCustom) AzanDialog(onDismiss = { showCustom = false; ver++ })
    pickFor?.let { k ->
        val current = when (k) { -1 -> IslamPrefs.azanPath; -2 -> IslamPrefs.fajrAzanPath; else -> Extras.azanFor(k) }
        AlertDialog(
            onDismissRequest = { pickFor = null },
            title = { Text(when (k) { -1 -> tr("الأذان العام", "General azan"); -2 -> tr("أذان الفجر", "Fajr azan"); else -> Prayer.names[k] }) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    val opts = mutableListOf<Pair<String, String>>()
                    when (k) {
                        -1 -> opts += "" to tr("صوت الإشعار فقط", "Notification sound only")
                        -2 -> opts += "" to tr("مثل الأذان العام", "Same as general")
                        else -> { opts += "" to tr("الأذان العام", "General azan"); opts += "none" to tr("إشعار فقط بدون أذان", "Notification only") }
                    }
                    sounds.forEach { opts += it.path to it.name }
                    if (sounds.isEmpty()) Text(tr("نزّل أذاناً من المكتبة أولاً", "Download an azan first"), style = MaterialTheme.typography.bodySmall)
                    opts.forEach { (path, label) ->
                        Row(Modifier.fillMaxWidth().clickable {
                            when (k) { -1 -> IslamPrefs.azanPath = path; -2 -> IslamPrefs.fajrAzanPath = path; else -> Extras.setAzanFor(k, path) }
                            pickFor = null; ver++
                        }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(current == path, null)
                            Text(label)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickFor = null }) { Text(tr("إغلاق", "Close")) } }
        )
    }
}

// =====================================================================
//              الرقية الشرعية كاملة بأصوات المشايخ (استماع وتنزيل)
// =====================================================================
@Composable
fun RuqyahAudioScreen(nav: NavController) {
    val ctx = LocalContext.current
    var expanded by rememberSaveable { mutableStateOf("afasy") }
    var wifiOnly by rememberSaveable { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var confirmDel by remember { mutableStateOf<RuqyahAudio.Track?>(null) }
    LaunchedEffect(Unit) { while (true) { RuqyahAudio.tick(); tick++; kotlinx.coroutines.delay(1000) } }

    ScreenScaffold(title = tr("الرقية بأصوات المشايخ", "Ruqyah by sheikhs"), onBack = { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    InfoBanner(tr(
                        "استمع للرقية الشرعية كاملة بأصوات كبار القراء: رقية السحر، والمس، والعين والحسد، وآيات العذاب. نزّلها مرة واحدة لتسمعها بدون إنترنت، ويتم التنزيل في الخلفية.",
                        "Listen to the complete ruqyah by renowned reciters. Download once to listen offline; downloads run in the background."
                    ), MaterialTheme.colorScheme.primary)
                }
                item {
                    key(tick / 5) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                SwitchRow(tr("التنزيل عبر Wi-Fi فقط", "Download over Wi-Fi only"), null, wifiOnly) { wifiOnly = it }
                            }
                        }
                        Text(tr("المساحة المستخدمة: ", "Storage used: ") + RuqyahAudio.downloadedSizeMb(ctx) + tr(" ميجا", " MB"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                items(RuqyahAudio.sheikhs, key = { it.id }) { sh ->
                    val tracks = RuqyahAudio.tracksOf(sh.id)
                    val open = expanded == sh.id
                    key(tick) {
                        val have = tracks.count { RuqyahAudio.isDownloaded(ctx, it) }
                        Card(Modifier.fillMaxWidth()) {
                            Column {
                                Row(Modifier.fillMaxWidth().clickable { expanded = if (open) "" else sh.id }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.RecordVoiceOver, null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(tr("الشيخ ", "") + sh.label, fontWeight = FontWeight.Bold)
                                        Text(
                                            (if (tracks.size > 1) tr("${tracks.size} أجزاء", "${tracks.size} parts") else tr("تسجيل كامل", "Full recording")) + " • " +
                                                tr("${tracks.sumOf { it.minutes }} دقيقة", "${tracks.sumOf { it.minutes }} min") +
                                                if (have > 0) tr(" • منزّل $have", " • $have downloaded") else "",
                                            style = MaterialTheme.typography.bodySmall, color = if (have == tracks.size) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Icon(if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null)
                                }
                                if (open) {
                                    HorizontalDivider()
                                    tracks.forEach { t -> RuqyahTrackRow(t, wifiOnly) { confirmDel = t } }
                                    if (have < tracks.size) TextButton(onClick = {
                                        tracks.forEach { RuqyahAudio.download(ctx, it, wifiOnly) }
                                        toast(ctx, tr("بدأ التنزيل في الخلفية ⬇️", "Download started ⬇️")); tick++
                                    }, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                                        Icon(Icons.Filled.CloudDownload, null); Spacer(Modifier.width(6.dp))
                                        Text(tr("تنزيل الرقية كاملة (", "Download all (") + tracks.filter { !RuqyahAudio.isDownloaded(ctx, it) }.sumOf { it.sizeMb } + tr(" ميجا)", " MB)"))
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    Text(tr("المصدر: أرشيف الإنترنت (archive.org). يُستحب مع الاستماع أن يرقي المسلم نفسه ويقرأ بيقين أن الشفاء من الله وحده.", "Source: archive.org. It is recommended to also recite ruqyah yourself with certainty that healing is from Allah alone."),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            key(tick) { RuqyahPlayerBar() }
        }
    }
    confirmDel?.let { t ->
        ConfirmDialog(tr("حذف الملف", "Delete file"), tr("حذف «${t.part?.label ?: t.sheikh.label}» من الجهاز؟", "Delete this file from the device?"), onDismiss = { confirmDel = null }) {
            if (RuqyahAudio.current.value?.id == t.id) RuqyahAudio.stop()
            RuqyahAudio.delete(ctx, t); confirmDel = null
        }
    }
}

@Composable
private fun RuqyahTrackRow(t: RuqyahAudio.Track, wifiOnly: Boolean, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val isCur = RuqyahAudio.current.value?.id == t.id
    val playing = isCur && RuqyahAudio.playing.value
    val downloaded = RuqyahAudio.isDownloaded(ctx, t)
    val prog = if (downloaded) null else RuqyahAudio.progress(ctx, t)
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalIconButton(onClick = { RuqyahAudio.toggle(ctx, t) }) {
                if (isCur && RuqyahAudio.loading.value) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text((t.part?.emoji ?: "🤲") + " " + (t.part?.label ?: tr("الرقية الشرعية كاملة", "Complete ruqyah")), fontWeight = if (isCur) FontWeight.Bold else FontWeight.SemiBold,
                    color = if (isCur) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                Text(
                    tr("${t.minutes} دقيقة • ${t.sizeMb} ميجا", "${t.minutes} min • ${t.sizeMb} MB") + when {
                        downloaded -> tr(" • ✅ متاح بدون إنترنت", " • ✅ offline")
                        prog?.failed == true -> tr(" • تعذّر التنزيل", " • download failed")
                        prog?.running == true -> " • " + (if (prog.total > 0) "${prog.done * 100 / prog.total}%" else tr("بانتظار الشبكة", "waiting"))
                        else -> tr(" • استماع مباشر", " • streaming")
                    },
                    style = MaterialTheme.typography.bodySmall, color = if (downloaded) SuccessGreen else if (prog?.failed == true) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            when {
                downloaded -> IconButton(onClick = onDelete) { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) }
                prog?.running == true -> IconButton(onClick = { RuqyahAudio.cancel(ctx, t) }) { Icon(Icons.Filled.Close, null) }
                else -> IconButton(onClick = {
                    if (prog?.failed == true) RuqyahAudio.cancel(ctx, t)
                    RuqyahAudio.download(ctx, t, wifiOnly); toast(ctx, tr("بدأ التنزيل ⬇️", "Download started ⬇️"))
                }) { Icon(Icons.Filled.Download, null, tint = MaterialTheme.colorScheme.primary) }
            }
        }
        if (prog?.running == true && prog.total > 0) LinearProgressIndicator(progress = { (prog.done.toFloat() / prog.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
    }
}

@Composable
fun RuqyahPlayerBar() {
    val ctx = LocalContext.current
    val t = RuqyahAudio.current.value ?: return
    val dur = RuqyahAudio.durMs.intValue
    val pos = RuqyahAudio.position.intValue
    Surface(tonalElevation = 6.dp, shadowElevation = 8.dp, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(t.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (dur > 0) {
                Slider(value = pos.toFloat().coerceIn(0f, dur.toFloat()), onValueChange = { RuqyahAudio.seekTo(it.toInt()) }, valueRange = 0f..dur.toFloat())
                Row { Text(RuqyahAudio.fmt(pos), style = MaterialTheme.typography.labelSmall); Spacer(Modifier.weight(1f)); Text(RuqyahAudio.fmt(dur), style = MaterialTheme.typography.labelSmall) }
            } else if (RuqyahAudio.loading.value) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { RuqyahAudio.setLoop(!RuqyahAudio.loop.value) }) {
                    Icon(Icons.Filled.Repeat, null, tint = if (RuqyahAudio.loop.value) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                }
                IconButton(onClick = { RuqyahAudio.seekBy(-30_000) }) { Icon(Icons.Filled.Replay30, null) }
                FilledIconButton(onClick = { RuqyahAudio.toggle(ctx, t) }, modifier = Modifier.size(52.dp)) {
                    Icon(if (RuqyahAudio.playing.value) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                }
                IconButton(onClick = { RuqyahAudio.seekBy(30_000) }) { Icon(Icons.Filled.Forward30, null) }
                IconButton(onClick = { RuqyahAudio.stop() }) { Icon(Icons.Filled.Stop, null) }
            }
        }
    }
}
