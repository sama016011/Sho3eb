package com.sho3eb.app.core

import com.sho3eb.app.data.*
import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

data class Opt(val key: String, val ar: String, val en: String, val emoji: String = "") { val label get() = tr(ar, en) }

private fun List<Opt>.find(k: String) = firstOrNull { it.key == k } ?: last()

/** ربط الأقسام بمصاريف المعيشة: كود سالب في itemId يميّز مصدر الحركة لحذفها معها */
object LivingLink {
    const val SUB = 1_000_000_000_000L
    const val CAR = 2_000_000_000_000L
    const val WORKER = 3_000_000_000_000L
    fun code(base: Long, id: Long) = -(base + id)

    /** يضيف مصروفاً للبند الشهري الذي يغطي التاريخ (وينشئ بند الشهر إن لزم) */
    suspend fun addExpense(ctx: android.content.Context, codeBase: Long, srcId: Long, name: String, category: String, amount: Double, date: Long, note: String) {
        val dao = appDao()
        var period = dao.allLivPeriods().firstOrNull { date in it.startDate..it.endDate }
        if (period == null) {
            if (!Extras.autoCreateMonth) return
            val d = LocalDate.ofEpochDay(date)
            val p = LivPeriod(name = Living.monthTitle(d), startDate = d.withDayOfMonth(1).toEpochDay(), endDate = d.withDayOfMonth(d.lengthOfMonth()).toEpochDay())
            period = p.copy(id = dao.insertLivPeriod(p))
        }
        dao.insertLivEntry(
            LivEntry(
                periodId = period.id, kind = Living.EXPENSE, itemId = code(codeBase, srcId), name = name, category = category,
                priority = Living.cat(Living.EXPENSE, category).priority, amount = amount, date = date, note = note
            )
        )
        LivingAuto.checkBudget(ctx, category)
    }

    suspend fun remove(codeBase: Long, srcId: Long) = appDao().deleteLivByCode(code(codeBase, srcId))
}

// ======================= العمال واليوميات =======================
object Workers {
    const val ATT = "ATT"; const val OT = "OT"; const val BONUS = "BONUS"; const val DEDUCT = "DEDUCT"; const val ADVANCE = "ADVANCE"; const val PAY = "PAY"
    val wageTypes = listOf(Opt("DAY", "يومية", "Daily"), Opt("WEEK", "أسبوعي", "Weekly"), Opt("MONTH", "شهري", "Monthly"))
    val entryTypes = listOf(
        Opt(ATT, "حضور", "Attendance", "✅"), Opt(OT, "ساعات إضافية", "Overtime", "⏱️"), Opt(BONUS, "مكافأة", "Bonus", "🎁"),
        Opt(DEDUCT, "خصم", "Deduction", "➖"), Opt(ADVANCE, "سلفة للعامل", "Advance", "💵"), Opt(PAY, "دفع أجر", "Wage paid", "💰")
    )
    fun wageType(k: String) = wageTypes.find(k)
    fun entryType(k: String) = entryTypes.find(k)

    /** أجر اليوم الواحد (الأسبوع 6 أيام عمل، والشهر 30 يوماً) */
    fun dailyRate(w: Worker) = when (w.wageType) { "WEEK" -> w.wage / 6.0; "MONTH" -> w.wage / 30.0; else -> w.wage }

    data class Sum(val days: Double, val otHours: Double, val earned: Double, val bonus: Double, val deduct: Double, val advances: Double, val paid: Double) {
        val due get() = round2(earned + bonus - deduct)
        /** المتبقي للعامل (موجب = عليّ له) */
        val balance get() = round2(due - advances - paid)
    }

    /** قيمة الحركة: الحضور = عدد الأيام × أجر اليوم، الإضافي = الساعات × أجر الساعة */
    fun value(w: Worker, e: WorkerEntry): Double = when (e.type) {
        ATT -> if (e.amount > 0) e.amount else e.qty * dailyRate(w)
        OT -> if (e.amount > 0) e.amount else e.qty * w.otRate
        else -> e.amount
    }

    fun sum(w: Worker, entries: List<WorkerEntry>, range: LongRange? = null): Sum {
        val es = entries.filter { it.workerId == w.id && (range == null || it.date in range) }
        fun t(k: String) = es.filter { it.type == k }
        return Sum(
            t(ATT).sumOf { it.qty }, t(OT).sumOf { it.qty },
            round2(t(ATT).sumOf { value(w, it) } + t(OT).sumOf { value(w, it) }),
            t(BONUS).sumOf { it.amount }, t(DEDUCT).sumOf { it.amount }, t(ADVANCE).sumOf { it.amount }, t(PAY).sumOf { it.amount }
        )
    }

    fun isPayment(t: String) = t == ADVANCE || t == PAY
    fun attOf(entries: List<WorkerEntry>, workerId: Long, day: Long) = entries.firstOrNull { it.workerId == workerId && it.date == day && it.type == ATT }
}

// ======================= الذهب والاستثمارات والأصول =======================
object Assets {
    val types = listOf(
        Opt("GOLD", "ذهب", "Gold", "🪙"), Opt("SILVER", "فضة", "Silver", "🥈"), Opt("STOCK", "أسهم", "Stocks", "📈"),
        Opt("FUND", "صناديق استثمار", "Funds", "🏦"), Opt("CRYPTO", "عملات رقمية", "Crypto", "₿"), Opt("FX", "عملات أجنبية", "Foreign currency", "💱"),
        Opt("REAL_ESTATE", "عقار", "Real estate", "🏠"), Opt("LAND", "أرض", "Land", "🌍"), Opt("CAR", "سيارة", "Vehicle", "🚗"),
        Opt("BUSINESS", "مشروع / حصة تجارية", "Business share", "🏪"), Opt("DEPOSIT", "وديعة / ادخار", "Deposit / savings", "💰"),
        Opt("TRADE", "بضاعة للتجارة", "Trade goods", "📦"), Opt("OTHER", "أخرى", "Other", "💼")
    )
    fun type(k: String) = types.find(k)
    fun defaultUnit(k: String) = when (k) { "GOLD", "SILVER" -> tr("جرام", "g"); "STOCK", "FUND" -> tr("سهم", "shares"); "CRYPTO", "FX" -> tr("وحدة", "units"); else -> "" }
    fun defaultZakatable(k: String) = k in listOf("GOLD", "SILVER", "STOCK", "FUND", "CRYPTO", "FX", "DEPOSIT", "TRADE")
    val karats = listOf(24, 22, 21, 18)

    /** القيمة الحالية: الذهب والفضة بسعر اليوم من حاسبة الزكاة، وغيرها بسعر الوحدة أو القيمة اليدوية */
    fun value(a: Asset): Double {
        if (a.sold) return 0.0
        return when {
            a.type == "GOLD" && Extras.goldPrice24 > 0 && a.qty > 0 -> a.qty * a.karat / 24.0 * Extras.goldPrice24
            a.type == "SILVER" && Extras.silverPrice > 0 && a.qty > 0 -> a.qty * Extras.silverPrice
            a.unitPrice > 0 && a.qty > 0 -> a.qty * a.unitPrice
            a.currentValue > 0 -> a.currentValue
            else -> a.buyPrice
        }.let { round2(it) }
    }

    fun profit(a: Asset) = if (a.sold) round2(a.sellPrice - a.buyPrice) else round2(value(a) - a.buyPrice)
    fun pct(a: Asset) = if (a.buyPrice > 0) profit(a) / a.buyPrice * 100 else 0.0
    fun pureGold(a: Asset) = if (a.type == "GOLD" && !a.sold) a.qty * a.karat / 24.0 else 0.0
    fun zakatableValue(list: List<Asset>) = list.filter { it.zakatable && !it.sold }.sumOf { value(it) }
}

// ======================= تقسيم المصاريف =======================
object Split {
    fun parse(s: String): Map<Long, Double> = s.split(",").mapNotNull { p ->
        val kv = p.split(":"); if (kv.size == 2) kv[0].trim().toLongOrNull()?.let { k -> kv[1].trim().toDoubleOrNull()?.let { k to it } } else null
    }.toMap()

    fun encode(m: Map<Long, Double>) = m.entries.joinToString(",") { "${it.key}:${round2(it.value)}" }

    /** تقسيم بالتساوي مع توزيع الكسور على الأوائل */
    fun equal(amount: Double, ids: List<Long>): Map<Long, Double> {
        if (ids.isEmpty()) return emptyMap()
        val cents = (amount * 100).roundToInt()
        val base = cents / ids.size
        var rem = cents - base * ids.size
        return ids.associateWith { (base + if (rem-- > 0) 1 else 0) / 100.0 }
    }

    /** الصافي لكل عضو: موجب = له عند الآخرين، سالب = عليه */
    fun balances(members: List<SplitMember>, expenses: List<SplitExpense>, settles: List<SplitSettle>): Map<Long, Double> {
        val b = members.associate { it.id to 0.0 }.toMutableMap()
        expenses.forEach { e ->
            b[e.payerId] = (b[e.payerId] ?: 0.0) + e.amount
            parse(e.shares).forEach { (m, v) -> b[m] = (b[m] ?: 0.0) - v }
        }
        settles.forEach { s ->
            b[s.fromId] = (b[s.fromId] ?: 0.0) + s.amount
            b[s.toId] = (b[s.toId] ?: 0.0) - s.amount
        }
        return b.mapValues { round2(it.value) }
    }

    data class Transfer(val from: Long, val to: Long, val amount: Double)

    /** أقل عدد من التحويلات لتسوية المجموعة */
    fun settlements(bal: Map<Long, Double>): List<Transfer> {
        val debt = bal.filter { it.value < -0.005 }.map { it.key to -it.value }.sortedByDescending { it.second }.toMutableList()
        val cred = bal.filter { it.value > 0.005 }.map { it.key to it.value }.sortedByDescending { it.second }.toMutableList()
        val out = mutableListOf<Transfer>()
        var i = 0; var j = 0
        val d = debt.map { it.second }.toMutableList(); val c = cred.map { it.second }.toMutableList()
        while (i < debt.size && j < cred.size) {
            val x = min(d[i], c[j])
            if (x > 0.005) out += Transfer(debt[i].first, cred[j].first, round2(x))
            d[i] -= x; c[j] -= x
            if (d[i] < 0.005) i++
            if (c[j] < 0.005) j++
        }
        return out
    }

    fun spentBy(memberId: Long, expenses: List<SplitExpense>) = expenses.filter { it.payerId == memberId }.sumOf { it.amount }
    fun shareOf(memberId: Long, expenses: List<SplitExpense>) = expenses.sumOf { parse(it.shares)[memberId] ?: 0.0 }
}

// ======================= السيارة =======================
object Cars {
    val expenseTypes = listOf(
        Opt("FUEL", "وقود", "Fuel", "⛽"), Opt("OIL", "تغيير زيت", "Oil change", "🛢️"), Opt("MAINT", "صيانة وإصلاح", "Maintenance", "🔧"),
        Opt("TIRES", "إطارات", "Tires", "🛞"), Opt("PARTS", "قطع غيار", "Parts", "⚙️"), Opt("INSURANCE", "تأمين", "Insurance", "🛡️"),
        Opt("REG", "استمارة / ترخيص", "Registration", "📄"), Opt("INSPECT", "فحص دوري", "Inspection", "🔍"), Opt("WASH", "غسيل", "Car wash", "🧽"),
        Opt("PARK", "مواقف ورسوم طرق", "Parking & tolls", "🅿️"), Opt("FINE", "مخالفات", "Fines", "🚨"), Opt("INSTALL", "قسط السيارة", "Car installment", "🏦"),
        Opt("OTHER", "أخرى", "Other", "📦")
    )
    fun type(k: String) = expenseTypes.find(k)

    /** تذكيرات جاهزة: (النوع، الاسم، كل كم شهر، كل كم كيلو) */
    val presets get() = listOf(
        Triple("OIL", tr("تغيير الزيت", "Oil change"), 6 to 5000L),
        Triple("INSURANCE", tr("تجديد التأمين", "Insurance renewal"), 12 to 0L),
        Triple("REG", tr("تجديد الاستمارة", "Registration renewal"), 12 to 0L),
        Triple("INSPECT", tr("الفحص الدوري", "Periodic inspection"), 12 to 0L),
        Triple("TIRES", tr("تغيير الإطارات", "Tire change"), 36 to 40000L),
        Triple("MAINT", tr("صيانة دورية شاملة", "Full service"), 12 to 10000L)
    )

    fun nextDate(r: CarReminder): LocalDate? = r.dueDate?.let { LocalDate.ofEpochDay(it) }
        ?: if (r.intervalMonths > 0 && r.lastDate != null) LocalDate.ofEpochDay(r.lastDate).plusMonths(r.intervalMonths.toLong()) else null

    fun nextKm(r: CarReminder): Long? = if (r.intervalKm > 0 && r.lastKm > 0) r.lastKm + r.intervalKm else null

    /** هل حان الموعد؟ (خلال 7 أيام أو 500 كم) */
    fun isDue(r: CarReminder, odo: Long, today: LocalDate = LocalDate.now()): Boolean {
        if (!r.enabled) return false
        val d = nextDate(r); val k = nextKm(r)
        return (d != null && !d.isAfter(today.plusDays(7))) || (k != null && odo >= k - 500)
    }

    fun statusText(r: CarReminder, odo: Long): String {
        val parts = mutableListOf<String>()
        nextDate(r)?.let { d ->
            val left = d.toEpochDay() - Fmt.today()
            parts += Fmt.date(d.toEpochDay()) + if (left < 0) tr(" (متأخر ${-left} يوم)", " (${-left} d overdue)") else tr(" (بعد $left يوم)", " (in $left d)")
        }
        nextKm(r)?.let { k ->
            val left = k - odo
            parts += tr("عند ", "at ") + Fmt.num(k.toDouble()).removeSuffix(".00") + tr(" كم", " km") + if (odo > 0) (if (left < 0) tr(" (تجاوزت ${-left})", " (${-left} over)") else tr(" (باقي $left)", " ($left left)")) else ""
        }
        return parts.joinToString(" • ").ifBlank { tr("حدّد الموعد", "Set schedule") }
    }

    data class Stats(val total: Double, val fuel: Double, val km: Long, val liters: Double) {
        val per100 get() = if (km > 0 && liters > 0) liters / km * 100 else 0.0
        val costPerKm get() = if (km > 0) total / km else 0.0
        val kmPerLiter get() = if (liters > 0) km / liters else 0.0
    }

    fun stats(list: List<CarExpense>): Stats {
        val withKm = list.filter { it.odometer > 0 }
        val km = if (withKm.size >= 2) withKm.maxOf { it.odometer } - withKm.minOf { it.odometer } else 0L
        val fuel = list.filter { it.type == "FUEL" }
        val fuelKm = fuel.filter { it.odometer > 0 && it.liters > 0 }.sortedBy { it.odometer }
        // الاستهلاك: لترات كل التعبئات عدا الأولى مقسومة على المسافة بين أول وآخر تعبئة
        val liters = if (fuelKm.size >= 2) fuelKm.drop(1).sumOf { it.liters } else 0.0
        val fuelSpan = if (fuelKm.size >= 2) fuelKm.last().odometer - fuelKm.first().odometer else 0L
        return Stats(list.sumOf { it.amount }, fuel.sumOf { it.amount }, if (fuelSpan > 0) fuelSpan else km, liters)
    }
}

// ======================= الاشتراكات والفواتير الدورية =======================
object Subs {
    /** النوع، والفئة المقابلة في مصاريف المعيشة */
    val cats = listOf(
        Opt("INTERNET", "إنترنت", "Internet", "🌐") to "TELECOM", Opt("MOBILE", "جوال", "Mobile", "📱") to "TELECOM",
        Opt("ELECTRIC", "كهرباء", "Electricity", "💡") to "BILLS", Opt("WATER", "مياه", "Water", "🚰") to "BILLS",
        Opt("GAS", "غاز", "Gas", "🔥") to "BILLS", Opt("RENT", "إيجار سكن", "Rent", "🏠") to "HOUSING",
        Opt("STREAM", "منصات مشاهدة", "Streaming", "📺") to "ENTERTAIN", Opt("APP", "تطبيقات وبرامج", "Apps & software", "💻") to "ENTERTAIN",
        Opt("GYM", "نادي رياضي", "Gym", "🏋️") to "PERSONAL", Opt("SCHOOL", "مدارس ودورات", "School & courses", "🎓") to "EDUCATION",
        Opt("INSURANCE", "تأمين", "Insurance", "🛡️") to "HEALTH", Opt("CHARITY", "تبرع شهري", "Monthly charity", "🤲") to "CHARITY",
        Opt("OTHER", "أخرى", "Other", "📦") to "OTHER"
    )
    fun cat(k: String) = (cats.firstOrNull { it.first.key == k } ?: cats.last()).first
    fun livingCat(k: String) = (cats.firstOrNull { it.first.key == k } ?: cats.last()).second
    val periods = listOf(1, 2, 3, 6, 12)

    fun monthly(s: Subscription) = s.amount / s.periodMonths.coerceAtLeast(1)
    fun yearly(s: Subscription) = monthly(s) * 12
    fun daysLeft(s: Subscription) = (s.nextDate - Fmt.today()).toInt()
    fun isDue(s: Subscription) = s.active && daysLeft(s) <= s.remindDays
    fun advance(s: Subscription): Long = LocalDate.ofEpochDay(s.nextDate).plusMonths(s.periodMonths.toLong().coerceAtLeast(1)).toEpochDay()
}

fun round2Safe(v: Double) = if (abs(v) < 0.005) 0.0 else round2(v)
