package com.sho3eb.app.core

import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object Bio {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK

    fun available(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS

    fun findActivity(ctx: Context): FragmentActivity? {
        var c: Context? = ctx
        while (c is ContextWrapper) {
            if (c is FragmentActivity) return c
            c = c.baseContext
        }
        return null
    }

    fun prompt(ctx: Context, onSuccess: () -> Unit) {
        val activity = findActivity(ctx) ?: return
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Sho3eb")
            .setSubtitle(tr("الدخول باستخدام البصمة", "Sign in with biometrics"))
            .setNegativeButtonText(tr("إلغاء", "Cancel"))
            .setAllowedAuthenticators(AUTH)
            .build()
        prompt.authenticate(info)
    }
}
