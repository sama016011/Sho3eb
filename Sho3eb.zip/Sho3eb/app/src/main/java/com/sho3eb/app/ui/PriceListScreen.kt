@file:OptIn(ExperimentalLayoutApi::class)

package com.sho3eb.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sho3eb.app.core.*
import com.sho3eb.app.data.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private fun loadOpts(): PriceList.Opts = runCatching {
    val o = JSONObject(Extras.s("pl_opts", "{}"))
    PriceList.Opts(o.optString("layout", "GRID"), o.optInt("cols", 3), o.optBoolean("group", true), o.optBoolean("images", true), o.optString("style", "CLASSIC"),
        o.optString("title", "").ifBlank { tr("قائمة الأسعار", "Price list") }, o.optString("note"), o.optBoolean("unit", true), o.optBoolean("sku"), o.optBoolean("desc"), o.optString("sort", "NAME"),
        o.optJSONArray("cats")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() })
}.getOrDefault(PriceList.Opts())

private fun saveOpts(o: PriceList.Opts) = Extras.ps("pl_opts", JSONObject().put("layout", o.layout).put("cols", o.cols).put("group", o.group).put("images", o.images).put("style", o.style)
    .put("title", o.title).put("note", o.note).put("unit", o.showUnit).put("sku", o.showSku).put("desc", o.showDesc).put("sort", o.sort)
    .apply { o.cats?.let { put("cats", JSONArray(it.toList())) } }.toString())

@Composable
fun PriceListScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { appDao() }
    val scope = rememberCoroutineScope()
    val products by flowState(emptyList<Product>()) { dao.productsFlow() }
    var o by remember { mutableStateOf(loadOpts()) }
    fun set(n: PriceList.Opts) { o = n; saveOpts(n) }
    val allCats = remember(products) { PriceList.items(products, PriceList.Opts(cats = null)).map { it.cat }.distinct().sorted() }
    val items = remember(products, o) { PriceList.items(products, o) }
    var page by remember { mutableIntStateOf(0) }
    val pages = remember(items, o) { PriceList.pageCount(items, o) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(items, o, page, ProductImages.version.intValue) {
        PriceList.clearImages()
        bmp = withContext(Dispatchers.Default) { runCatching { PriceList.preview(ctx, items, o, page) }.getOrNull() }
    }
    var busy by remember { mutableStateOf(false) }

    ScreenScaffold(title = tr("📋 قائمة الأسعار", "📋 Price list"), onBack = { nav.popBackStack() }, actions = {
        IconButton(onClick = { nav.navigate("brand") }) { Icon(Icons.Filled.Storefront, tr("شعار وبيانات المحل", "Shop logo & details")) }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!Brand.enabled || !Brand.logo(ctx).exists()) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), onClick = { nav.navigate("brand") }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🏪", style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.width(10.dp))
                    Text(tr("أضف شعار المحل واسمه ورقمه ليظهروا أعلى القائمة (اضغط هنا)", "Add your shop logo, name and phone to the list header (tap here)"), Modifier.weight(1f))
                }
            }
            // ===== المعاينة =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (items.isEmpty()) Text(tr("لا توجد أصناف للبيع بعد. أضف أصنافاً بسعر بيع من المخزون أو استوردها.", "No items for sale yet. Add items with a sale price or import them."), Modifier.padding(20.dp))
                    else bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(595f / 842f).border(1.dp, MaterialTheme.colorScheme.outlineVariant), contentScale = ContentScale.Fit) }
                        ?: Box(Modifier.fillMaxWidth().aspectRatio(595f / 842f), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    if (pages > 1) Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { page = (page - 1).coerceAtLeast(0) }, enabled = page > 0) { Icon(Icons.Filled.ChevronRight, null) }
                        Text(tr("صفحة ${page + 1} من $pages", "Page ${page + 1} of $pages"))
                        IconButton(onClick = { page = (page + 1).coerceAtMost(pages - 1) }, enabled = page < pages - 1) { Icon(Icons.Filled.ChevronLeft, null) }
                    }
                    Text(tr("${items.size} صنف معروض للبيع", "${items.size} items for sale"), style = MaterialTheme.typography.labelMedium)
                }
            }
            Button(onClick = {
                busy = true
                scope.launch {
                    val f = withContext(Dispatchers.IO) { runCatching { PriceList.pdf(ctx, items, o) }.getOrNull() }
                    busy = false
                    if (f != null) Share.sharePdf(ctx, f, null, false) else toast(ctx, tr("تعذر إنشاء الملف", "Couldn't create the file"))
                }
            }, enabled = items.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth()) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.PictureAsPdf, null)
                Spacer(Modifier.width(8.dp)); Text(tr("تصدير PDF ومشاركته", "Export & share PDF"))
            }
            OutlinedButton(onClick = {
                scope.launch {
                    val f = withContext(Dispatchers.IO) { runCatching { PriceList.excel(ctx, items, o) }.getOrNull() }
                    if (f != null) Share.shareFile(ctx, f, Xlsx.MIME, null, false) else toast(ctx, tr("تعذر إنشاء الملف", "Couldn't create the file"))
                }
            }, enabled = items.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.TableChart, null); Spacer(Modifier.width(8.dp)); Text(tr("تصدير Excel", "Export Excel")) }
            // ===== الشكل =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("🎨 شكل القائمة", "🎨 Layout"))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(o.layout == "LIST", { set(o.copy(layout = "LIST")); page = 0 }, label = { Text(tr("☰ قائمة (List)", "☰ List")) })
                        FilterChip(o.layout == "GRID", { set(o.copy(layout = "GRID")); page = 0 }, label = { Text(tr("▦ مربعات (Grid)", "▦ Grid")) })
                    }
                    if (o.layout == "GRID") {
                        Text(tr("عدد المربعات في كل صف", "Boxes per row"), style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (2..5).forEach { n -> FilterChip(o.cols == n, { set(o.copy(cols = n)); page = 0 }, label = { Text("$n") }) } }
                    }
                    SwitchRow(tr("تقسيم حسب التصنيف", "Group by category"), null, o.group) { set(o.copy(group = it)); page = 0 }
                    SwitchRow(tr("إظهار صور الأصناف", "Show item photos"), null, o.images) { set(o.copy(images = it)) }
                    Text(tr("النمط", "Style"), style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("CLASSIC" to tr("كلاسيكي بلون المحل", "Classic (brand)"), "ELEGANT" to tr("فاخر ذهبي", "Elegant gold"), "MODERN" to tr("عصري", "Modern"), "FRESH" to tr("مبهج", "Fresh")).forEach { (k, l) ->
                            FilterChip(o.style == k, { set(o.copy(style = k)) }, label = { Text(l) })
                        }
                    }
                    Text(tr("ترتيب الأصناف", "Sort items"), style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("NAME" to tr("أبجدي", "A–Z"), "PRICE_UP" to tr("السعر ↑", "Price ↑"), "PRICE_DOWN" to tr("السعر ↓", "Price ↓"), "CATEGORY" to tr("التصنيف", "Category")).forEach { (k, l) ->
                            FilterChip(o.sort == k, { set(o.copy(sort = k)) }, label = { Text(l) })
                        }
                    }
                }
            }
            // ===== المحتوى =====
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr("📝 المحتوى", "📝 Content"))
                    OutlinedTextField(o.title, { set(o.copy(title = it)) }, label = { Text(tr("عنوان القائمة", "List title")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(o.note, { set(o.copy(note = it)) }, label = { Text(tr("ملاحظة أعلى القائمة (عروض، توصيل…)", "Note (offers, delivery…)")) }, modifier = Modifier.fillMaxWidth())
                    SwitchRow(tr("إظهار الوحدة", "Show unit"), null, o.showUnit) { set(o.copy(showUnit = it)) }
                    SwitchRow(tr("إظهار الكود", "Show code"), null, o.showSku) { set(o.copy(showSku = it)) }
                    SwitchRow(tr("إظهار الوصف (الملاحظات)", "Show description"), null, o.showDesc) { set(o.copy(showDesc = it)) }
                    if (allCats.size > 1) {
                        Text(tr("التصنيفات المعروضة", "Categories shown"), style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(o.cats == null, { set(o.copy(cats = null)); page = 0 }, label = { Text(tr("الكل", "All")) })
                            allCats.forEach { c ->
                                val on = o.cats?.contains(c) ?: false
                                FilterChip(on, {
                                    val cur = o.cats ?: emptySet()
                                    val n = if (on) cur - c else cur + c
                                    set(o.copy(cats = n.ifEmpty { null })); page = 0
                                }, label = { Text(c) })
                            }
                        }
                    }
                    Text(tr("💡 تظهر الأصناف المعروضة للبيع فقط (المفعّلة ولها سعر بيع)، وليس خامات التصنيع.", "💡 Only items for sale (active with a sale price) are shown — not raw materials."),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
