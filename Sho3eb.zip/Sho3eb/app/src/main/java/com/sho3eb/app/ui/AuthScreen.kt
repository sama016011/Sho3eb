@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sho3eb.app.R
import com.sho3eb.app.core.*
import com.sho3eb.app.core.chat.Chat
import com.sho3eb.app.core.chat.Cloud
import com.sho3eb.app.core.chat.Supa
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AppLogo(size: Int = 96) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(
            Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary))
        ),
        contentAlignment = Alignment.Center
    ) {
        val edIcon = remember { com.sho3eb.app.core.Edition.iconBitmap }
        if (edIcon != null) Image(edIcon.asImageBitmap(), null, Modifier.fillMaxSize())
        else Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size((size * 1.4).dp))
    }
}

@Composable
fun AuthScreen() {
    val prefs = remember { appPrefs() }
    var registerMode by remember { mutableStateOf(!prefs.hasUser) }
    val cloud = remember { Cloud.available }
    var localMode by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            var langMenu by remember { mutableStateOf(false) }
            Box {
                TextButton(onClick = { langMenu = true }) {
                    Icon(Icons.Filled.Language, null); Spacer(Modifier.width(6.dp))
                    Text(I18n.name(AppState.lang.value))
                }
                DropdownMenu(langMenu, { langMenu = false }) {
                    I18n.languages.forEach { lg ->
                        DropdownMenuItem(text = { Text(lg.name) }, onClick = { langMenu = false; prefs.lang = lg.code; AppState.lang.value = lg.code })
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        AppLogo()
        Spacer(Modifier.height(12.dp))
        Text(com.sho3eb.app.core.Edition.appName, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text(
            tr("إدارة الجمعيات والسلف والبيع بالتقسيط", "Manage associations, loans & installment sales"),
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (cloud && !localMode) {
                    // مستخدم قديم أم جديد؟
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(!registerMode, { registerMode = false }, label = { Text(tr("👤 لدي حساب", "👤 I have an account")) }, modifier = Modifier.weight(1f))
                        FilterChip(registerMode, { registerMode = true }, label = { Text(tr("🆕 حساب جديد", "🆕 New account")) }, modifier = Modifier.weight(1f))
                    }
                    if (registerMode) CloudRegisterForm(prefs) else CloudLoginForm(prefs)
                    if (prefs.hasUser) TextButton(onClick = { localMode = true; registerMode = false }, modifier = Modifier.fillMaxWidth()) { Text(tr("الدخول المحلي على هذا الجهاز (بدون إنترنت)", "Local sign-in on this device (offline)"), style = MaterialTheme.typography.labelMedium) }
                } else {
                    if (registerMode) RegisterForm(prefs) else LoginForm(prefs)
                    if (cloud) TextButton(onClick = { localMode = false }, modifier = Modifier.fillMaxWidth()) { Text(tr("☁️ الدخول بحسابي (رقم الهاتف)", "☁️ Sign in with my account (phone)")) }
                }
            }
        }
    }
}

@Composable
private fun PasswordField(value: String, onChange: (String) -> Unit, label: String) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        leadingIcon = { Icon(Icons.Filled.Lock, null) },
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
            }
        },
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun LoginForm(prefs: Prefs) {
    val ctx = LocalContext.current
    var user by remember { mutableStateOf(if (prefs.rememberMe) prefs.username else "") }
    var pass by remember { mutableStateOf(if (prefs.rememberMe) prefs.savedPassword ?: "" else "") }
    var rememberMe by remember { mutableStateOf(prefs.rememberMe) }
    var error by remember { mutableStateOf<String?>(null) }
    var showForgot by remember { mutableStateOf(false) }
    val bioReady = remember { prefs.biometric && Bio.available(ctx) }

    fun enter() {
        AppState.displayName.value = prefs.displayName
        AppState.photoPath.value = prefs.photoPath
        AppState.loggedIn.value = true
    }

    LaunchedEffect(Unit) { if (bioReady) Bio.prompt(ctx) { enter() } }

    Text(tr("تسجيل الدخول", "Sign in"), fontWeight = FontWeight.Bold, fontSize = 20.sp)
    OutlinedTextField(
        user, { user = it; error = null }, label = { Text(tr("اسم المستخدم أو البريد الإلكتروني", "Username or email")) }, singleLine = true,
        leadingIcon = { Icon(Icons.Filled.Person, null) }, modifier = Modifier.fillMaxWidth()
    )
    PasswordField(pass, { pass = it; error = null }, tr("كلمة المرور", "Password"))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = rememberMe, onCheckedChange = { rememberMe = it })
        Text(tr("حفظ اسم المستخدم وكلمة المرور", "Remember username & password"))
    }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(
        onClick = {
            if (prefs.verify(user, pass)) {
                prefs.rememberMe = rememberMe
                prefs.savedPassword = if (rememberMe) pass else null
                enter()
            } else error = tr("اسم المستخدم أو كلمة المرور غير صحيحة", "Wrong username or password")
        },
        modifier = Modifier.fillMaxWidth().height(50.dp)
    ) { Text(tr("دخول", "Sign in"), fontSize = 16.sp) }
    if (bioReady) {
        OutlinedButton(onClick = { Bio.prompt(ctx) { enter() } }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(tr("الدخول بالبصمة", "Use biometrics"))
        }
    }
    TextButton(onClick = { showForgot = true }, modifier = Modifier.fillMaxWidth()) { Text(tr("نسيت كلمة المرور؟", "Forgot password?")) }
    if (showForgot && prefs.hasRecovery) {
        var code by remember { mutableStateOf("") }
        var p1 by remember { mutableStateOf("") }
        var p2 by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showForgot = false },
            icon = { Icon(Icons.Filled.Email, null) },
            title = { Text(tr("استعادة كلمة المرور", "Reset password")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        tr("أدخل رمز الاستعادة المرسل إلى بريدك ", "Enter the recovery code sent to ") + maskEmail(prefs.email) +
                            tr(" ثم اختر كلمة مرور جديدة.", ", then choose a new password."),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(code, { code = it; err = null }, label = { Text(tr("رمز الاستعادة", "Recovery code")) }, singleLine = true, placeholder = { Text("XXXX-XXXX-XXXX") }, modifier = Modifier.fillMaxWidth())
                    PasswordField(p1, { p1 = it; err = null }, tr("كلمة المرور الجديدة", "New password"))
                    PasswordField(p2, { p2 = it; err = null }, tr("تأكيد كلمة المرور", "Confirm password"))
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    Text(tr("اسم المستخدم: ", "Username: ") + prefs.username, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    err = when {
                        !prefs.verifyRecovery(code) -> tr("رمز الاستعادة غير صحيح", "Wrong recovery code")
                        p1.length < 4 -> tr("كلمة المرور 4 أحرف على الأقل", "Password must be at least 4 characters")
                        p1 != p2 -> tr("كلمتا المرور غير متطابقتين", "Passwords do not match")
                        else -> null
                    }
                    if (err == null) {
                        prefs.setPassword(p1)
                        user = prefs.username; pass = p1
                        showForgot = false
                        toast(ctx, tr("تم تغيير كلمة المرور ✅ يُفضّل إرسال رمز استعادة جديد من الملف الشخصي", "Password changed ✅ Send a new recovery code from Profile"))
                    }
                }) { Text(tr("تغيير", "Reset")) }
            },
            dismissButton = { TextButton(onClick = { showForgot = false }) { Text(tr("إلغاء", "Cancel")) } }
        )
    } else if (showForgot) {
        AlertDialog(
            onDismissRequest = { showForgot = false },
            title = { Text(tr("استعادة الدخول", "Recover access")) },
            text = {
                Text(
                    tr(
                        "لم يتم ربط الحساب ببريد إلكتروني ورمز استعادة.\n\n• إن فعّلت الدخول بالبصمة يمكنك الدخول بها ثم تغيير كلمة المرور من الملف الشخصي.\n• إن حفظت كلمة المرور سابقاً ستظهر تلقائياً في الحقل.",
                        "Your data lives only on this device; there is no server to reset your password.\n\n• If biometrics is enabled, sign in with it and change your password from Profile.\n• If you saved your password before, it is pre-filled."
                    )
                )
            },
            confirmButton = { TextButton(onClick = { showForgot = false }) { Text(tr("حسناً", "OK")) } }
        )
    }
}

@Composable
private fun RegisterForm(prefs: Prefs) {
    var name by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    var phone by remember { mutableStateOf("") }

    Text(tr("إنشاء حساب جديد", "Create your account"), fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Text(tr("الحساب محلي ويحمي بياناتك على هذا الجهاز", "A local account that protects your data on this device"), style = MaterialTheme.typography.bodySmall)
    OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم الكامل", "Full name")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Badge, null) }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(user, { user = it.trim() }, label = { Text(tr("اسم المستخدم", "Username")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Person, null) }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(phone, { phone = it }, label = { Text(tr("رقم الهاتف", "Phone number")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Phone, null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
    OutlinedTextField(
        email, { email = it.trim() }, label = { Text(tr("البريد الإلكتروني (لاستعادة كلمة المرور)", "Email (for password recovery)")) }, singleLine = true,
        leadingIcon = { Icon(Icons.Filled.Email, null) }, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email)
    )
    PasswordField(pass, { pass = it }, tr("كلمة المرور", "Password"))
    PasswordField(pass2, { pass2 = it }, tr("تأكيد كلمة المرور", "Confirm password"))
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(
        onClick = {
            error = when {
                name.isBlank() -> tr("أدخل الاسم", "Enter your name")
                user.length < 3 -> tr("اسم المستخدم 3 أحرف على الأقل", "Username must be at least 3 characters")
                pass.length < 4 -> tr("كلمة المرور 4 أحرف على الأقل", "Password must be at least 4 characters")
                pass != pass2 -> tr("كلمتا المرور غير متطابقتين", "Passwords do not match")
                email.isNotBlank() && !Mail.valid(email) -> tr("البريد الإلكتروني غير صحيح", "Invalid email")
                else -> null
            }
            if (error == null) {
                prefs.register(user, pass, name)
                if (phone.isNotBlank()) prefs.phone = Chat.latinDigits(phone).trim()
                if (email.isNotBlank()) { prefs.email = email; Mail.sendRecovery(ctx, prefs) }
                prefs.rememberMe = true
                prefs.savedPassword = pass
                AppState.displayName.value = name.trim()
                AppState.loggedIn.value = true
            }
        },
        modifier = Modifier.fillMaxWidth().height(50.dp)
    ) { Text(tr("إنشاء الحساب", "Create account"), fontSize = 16.sp) }
}

fun maskEmail(e: String): String {
    val at = e.indexOf('@')
    if (at <= 1) return e
    return e.take(2) + "•".repeat((at - 2).coerceAtMost(6)) + e.substring(at)
}


private fun enterApp(prefs: Prefs) {
    AppState.displayName.value = prefs.displayName
    AppState.photoPath.value = prefs.photoPath
    AppState.loggedIn.value = true
}

/** حفظ بيانات الدخول محلياً (للدخول بدون إنترنت وبالبصمة) */
private fun saveLocal(prefs: Prefs, phone: String, pass: String, name: String, remember: Boolean) {
    val u = Chat.normPhone(phone).ifBlank { phone.trim() }
    if (!prefs.hasUser) prefs.register(u, pass, name.ifBlank { prefs.displayName })
    else { prefs.setUsername(u); prefs.setPassword(pass) }
    if (name.isNotBlank() && prefs.displayName.isBlank()) prefs.displayName = name
    if (phone.isNotBlank() && !phone.contains('@')) prefs.phone = Chat.latinDigits(phone)
    prefs.rememberMe = remember
    prefs.savedPassword = if (remember) pass else null
}

@Composable
private fun RestoreAfterLogin(prefs: Prefs, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf("check") }
    LaunchedEffect(Unit) { state = if (withContext(Dispatchers.IO) { Cloud.hasBackup() }) "ask" else "none" }
    when (state) {
        "none" -> LaunchedEffect(Unit) { onDone() }
        "check" -> AlertDialog(onDismissRequest = {}, confirmButton = {}, text = { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(22.dp)); Spacer(Modifier.width(12.dp)); Text(tr("جارٍ البحث عن بياناتك المحفوظة…", "Looking for your saved data…")) } })
        "ask" -> AlertDialog(onDismissRequest = {}, icon = { Icon(Icons.Filled.CloudDownload, null) }, title = { Text(tr("وجدنا بياناتك المحفوظة", "We found your saved data")) },
            text = { Text(tr("استعادة كل بياناتك القديمة (الجمعيات والسلف والتقسيط، الإعدادات، الأذكار والمصحف، التواصل…) على هذا الجهاز؟ سيُعاد تشغيل التطبيق.", "Restore all your previous data (finance, settings, Islamic, chat…) on this device? The app will restart.")) },
            confirmButton = { Button(onClick = { state = "restoring"; scope.launch { val r = withContext(Dispatchers.IO) { runCatching { Cloud.restore(ctx) } }; r.onFailure { toast(ctx, it.message ?: ""); onDone() } } }) { Text(tr("استعادة بياناتي", "Restore my data")) } },
            dismissButton = { TextButton(onClick = onDone) { Text(tr("بدء من جديد", "Start fresh")) } })
        else -> AlertDialog(onDismissRequest = {}, confirmButton = {}, text = { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(22.dp)); Spacer(Modifier.width(12.dp)); Text(tr("جارٍ استعادة بياناتك…", "Restoring your data…")) } })
    }
}

@Composable
private fun CloudLoginForm(prefs: Prefs) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var user by remember { mutableStateOf(if (prefs.rememberMe) prefs.phone.ifBlank { prefs.username } else "") }
    var pass by remember { mutableStateOf(if (prefs.rememberMe) prefs.savedPassword ?: "" else "") }
    var rememberMe by remember { mutableStateOf(prefs.rememberMe) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var forgot by remember { mutableStateOf(false) }
    var restore by remember { mutableStateOf(false) }
    val bioReady = remember { prefs.biometric && Bio.available(ctx) && prefs.hasUser }

    Text(tr("تسجيل الدخول", "Sign in"), fontWeight = FontWeight.Bold, fontSize = 20.sp)
    OutlinedTextField(user, { user = it; error = null }, label = { Text(tr("رقم الهاتف (أو البريد الإلكتروني)", "Phone number (or email)")) }, singleLine = true,
        leadingIcon = { Icon(Icons.Filled.Phone, null) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
    PasswordField(pass, { pass = it; error = null }, tr("كلمة المرور", "Password"))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(rememberMe, { rememberMe = it }); Text(tr("حفظ كلمة المرور على هذا الجهاز", "Remember password on this device"))
    }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(enabled = !busy, onClick = {
        if (user.isBlank() || pass.isBlank()) { error = tr("أدخل رقم الهاتف وكلمة المرور", "Enter phone and password"); return@Button }
        busy = true; error = null
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Cloud.signIn(user, pass) } }
            busy = false
            r.onSuccess { saveLocal(prefs, user, pass, "", rememberMe); restore = true }
                .onFailure { e ->
                    // بدون إنترنت: نسمح بالدخول المحلي إن طابقت البيانات المحفوظة
                    if (e is java.io.IOException && prefs.verify(Chat.normPhone(user).ifBlank { user }, pass)) enterApp(prefs)
                    else error = if (e is java.io.IOException) tr("تعذر الاتصال بالإنترنت", "No internet connection") else e.message
                }
        }
    }, modifier = Modifier.fillMaxWidth().height(50.dp)) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text(tr("دخول", "Sign in"), fontSize = 16.sp) }
    if (bioReady) OutlinedButton(onClick = { Bio.prompt(ctx) { enterApp(prefs) } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(tr("الدخول بالبصمة", "Use biometrics")) }
    TextButton(onClick = { forgot = true }, modifier = Modifier.fillMaxWidth()) { Text(tr("نسيت كلمة المرور؟", "Forgot password?")) }
    if (restore) RestoreAfterLogin(prefs) { restore = false; enterApp(prefs) }
    if (forgot) ForgotDialog(user, onClose = { forgot = false }) { newPass -> forgot = false; saveLocal(prefs, user, newPass, "", rememberMe); restore = true }
    if (Cloud.pendingLink.value != null) LinkResetDialog { newPass, who -> forgot = false; saveLocal(prefs, who.ifBlank { user }, newPass, "", rememberMe); restore = true }
}

/** نافذة تعيين كلمة مرور جديدة بعد الضغط على رابط البريد */
@Composable
fun LinkResetDialog(onDone: (String, String) -> Unit) {
    val scope = rememberCoroutineScope()
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = {}, icon = { Icon(Icons.Filled.LockReset, null) }, title = { Text(tr("تعيين كلمة مرور جديدة", "Set a new password")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("✅ تم التحقق من بريدك. اختر كلمة مرور جديدة لحسابك.", "✅ Email verified. Choose a new password."), style = MaterialTheme.typography.bodySmall)
                PasswordField(p1, { p1 = it }, tr("كلمة المرور الجديدة", "New password"))
                PasswordField(p2, { p2 = it }, tr("تأكيد كلمة المرور", "Confirm password"))
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (msg.isNotBlank()) Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(enabled = !busy, onClick = {
                if (p1.length < 6 || p1 != p2) { msg = if (p1.length < 6) tr("كلمة المرور 6 أحرف على الأقل", "Password must be at least 6 characters") else tr("كلمتا المرور غير متطابقتين", "Passwords do not match"); return@Button }
                val link = Cloud.pendingLink.value ?: return@Button
                busy = true; msg = ""
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { Cloud.resetWithLink(link, p1) } }
                    busy = false
                    r.onSuccess { onDone(p1, it) }.onFailure { msg = Cloud.friendly(it.message ?: "") }
                }
            }) { Text(tr("حفظ ودخول", "Save & sign in")) }
        }, dismissButton = { TextButton(onClick = { Cloud.pendingLink.value = null }) { Text(tr("إلغاء", "Cancel")) } })
}

@Composable
private fun ForgotDialog(initial: String, onClose: () -> Unit, onReset: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var id by remember { mutableStateOf(initial) }
    var channel by remember { mutableStateOf(Supa.otpChannel) }
    var sent by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, icon = { Icon(Icons.Filled.LockReset, null) }, title = { Text(tr("استعادة كلمة المرور", "Reset password")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(id, { id = it }, label = { Text(tr("رقم الهاتف أو البريد", "Phone or email")) }, singleLine = true, enabled = !sent, modifier = Modifier.fillMaxWidth())
                if (!sent) {
                    Text(tr("أرسل رمز الاستعادة عبر:", "Send the reset code via:"), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(channel == "whatsapp", { channel = "whatsapp" }, label = { Text(tr("واتساب", "WhatsApp")) })
                        FilterChip(channel == "sms", { channel = "sms" }, label = { Text("SMS") })
                        FilterChip(channel == "email", { channel = "email" }, label = { Text(tr("البريد", "Email")) })
                    }
                } else {
                    OutlinedTextField(code, { code = it.filter { c -> c.isDigit() }.take(8) }, label = { Text(tr("الرمز المرسل", "Code")) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
                    PasswordField(p1, { p1 = it }, tr("كلمة المرور الجديدة", "New password"))
                    PasswordField(p2, { p2 = it }, tr("تأكيد كلمة المرور", "Confirm password"))
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (msg.isNotBlank()) Text(msg, color = if (msg.startsWith("✅")) com.sho3eb.app.ui.theme.SuccessGreen else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(enabled = !busy, onClick = {
                if (sent && (p1.length < 6 || p1 != p2)) { msg = if (p1.length < 6) tr("كلمة المرور 6 أحرف على الأقل", "Password must be at least 6 characters") else tr("كلمتا المرور غير متطابقتين", "Passwords do not match"); return@Button }
                busy = true; msg = ""
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { if (!sent) Cloud.sendResetCode(id, channel) else Cloud.resetWithCode(code, p1) } }
                    busy = false
                    r.onSuccess { if (!sent) { sent = true; msg = if (channel == "email") tr("✅ أُرسل البريد. افتحه من هذا الهاتف واضغط «Sign in» ليفتح التطبيق وتختار كلمة مرور جديدة (أو اكتب الرمز إن وُجد)", "✅ Email sent. Open it on this phone and tap \"Sign in\" to set a new password (or type the code if shown)") else tr("✅ أُرسل الرمز", "✅ Code sent") } else onReset(p1) }.onFailure { msg = Cloud.friendly(it.message ?: "") }
                }
            }) { Text(if (!sent) tr("إرسال الرمز", "Send code") else tr("تغيير ودخول", "Reset & sign in")) }
        }, dismissButton = { TextButton(onClick = onClose) { Text(tr("إلغاء", "Cancel")) } })
}

@Composable
private fun CloudRegisterForm(prefs: Prefs) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(prefs.displayName) }
    var phone by remember { mutableStateOf(prefs.phone) }
    var email by remember { mutableStateOf(prefs.email) }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var verify by remember { mutableStateOf(false) }

    Text(tr("إنشاء حساب جديد", "Create your account"), fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Text(tr("حسابك محفوظ على الخادم: تدخل به من أي جهاز وتستعيد بياناتك.", "Your account lives on the server: sign in from any device and restore your data."), style = MaterialTheme.typography.bodySmall)
    OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم الكامل", "Full name")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Badge, null) }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(phone, { phone = it }, label = { Text(tr("رقم الهاتف", "Phone number")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Phone, null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
    OutlinedTextField(email, { email = it.trim() }, label = { Text(tr("البريد الإلكتروني (اختياري للاستعادة)", "Email (optional, for recovery)")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Email, null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
    PasswordField(pass, { pass = it }, tr("كلمة المرور (6 أحرف على الأقل)", "Password (min 6)"))
    PasswordField(pass2, { pass2 = it }, tr("تأكيد كلمة المرور", "Confirm password"))
    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(rememberMe, { rememberMe = it }); Text(tr("حفظ كلمة المرور على هذا الجهاز", "Remember password on this device")) }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(enabled = !busy, onClick = {
        error = when {
            name.isBlank() -> tr("أدخل الاسم", "Enter your name")
            Chat.normPhone(phone).length < 8 -> tr("أدخل رقم هاتف صحيح", "Enter a valid phone number")
            email.isNotBlank() && !Mail.valid(email) -> tr("البريد الإلكتروني غير صحيح", "Invalid email")
            pass.length < 6 -> tr("كلمة المرور 6 أحرف على الأقل", "Password must be at least 6 characters")
            pass != pass2 -> tr("كلمتا المرور غير متطابقتين", "Passwords do not match")
            else -> null
        }
        if (error != null) return@Button
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Cloud.register(name.trim(), phone, email, pass) } }
            busy = false
            r.onSuccess {
                prefs.displayName = name.trim(); if (email.isNotBlank()) prefs.email = email
                saveLocal(prefs, phone, pass, name.trim(), rememberMe)
                if (Supa.verifyPhone) verify = true else enterApp(prefs)
            }.onFailure { error = it.message }
        }
    }, modifier = Modifier.fillMaxWidth().height(50.dp)) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text(tr("إنشاء الحساب", "Create account"), fontSize = 16.sp) }
    if (verify) PhoneVerifyDialog(phone) { verify = false; enterApp(prefs) }
}
