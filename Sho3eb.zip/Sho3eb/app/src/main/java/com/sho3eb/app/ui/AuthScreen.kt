@file:OptIn(ExperimentalMaterial3Api::class)

package com.sho3eb.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sho3eb.app.R
import com.sho3eb.app.core.*

@Composable
fun AppLogo(size: Int = 96) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(
            Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary))
        ),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size((size * 1.4).dp))
    }
}

@Composable
fun AuthScreen() {
    val prefs = remember { appPrefs() }
    var registerMode by remember { mutableStateOf(!prefs.hasUser) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = {
                val nl = if (AppState.isAr) "en" else "ar"
                prefs.lang = nl; AppState.lang.value = nl
            }) {
                Icon(Icons.Filled.Language, null); Spacer(Modifier.width(6.dp))
                Text(if (AppState.isAr) "English" else "العربية")
            }
        }
        Spacer(Modifier.height(16.dp))
        AppLogo()
        Spacer(Modifier.height(12.dp))
        Text("Sho3eb", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text(
            tr("إدارة الجمعيات والسلف والبيع بالتقسيط", "Manage associations, loans & installment sales"),
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (registerMode) RegisterForm(prefs) else LoginForm(prefs)
            }
        }
    }
}

@Composable
private fun PasswordField(value: String, onChange: (String) -> Unit, label: String) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        leadingIcon = { Icon(Icons.Filled.Lock, null) },
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
            }
        },
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun LoginForm(prefs: Prefs) {
    val ctx = LocalContext.current
    var user by remember { mutableStateOf(if (prefs.rememberMe) prefs.username else "") }
    var pass by remember { mutableStateOf(if (prefs.rememberMe) prefs.savedPassword ?: "" else "") }
    var rememberMe by remember { mutableStateOf(prefs.rememberMe) }
    var error by remember { mutableStateOf<String?>(null) }
    var showForgot by remember { mutableStateOf(false) }
    val bioReady = remember { prefs.biometric && Bio.available(ctx) }

    fun enter() {
        AppState.displayName.value = prefs.displayName
        AppState.photoPath.value = prefs.photoPath
        AppState.loggedIn.value = true
    }

    LaunchedEffect(Unit) { if (bioReady) Bio.prompt(ctx) { enter() } }

    Text(tr("تسجيل الدخول", "Sign in"), fontWeight = FontWeight.Bold, fontSize = 20.sp)
    OutlinedTextField(
        user, { user = it; error = null }, label = { Text(tr("اسم المستخدم", "Username")) }, singleLine = true,
        leadingIcon = { Icon(Icons.Filled.Person, null) }, modifier = Modifier.fillMaxWidth()
    )
    PasswordField(pass, { pass = it; error = null }, tr("كلمة المرور", "Password"))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = rememberMe, onCheckedChange = { rememberMe = it })
        Text(tr("حفظ اسم المستخدم وكلمة المرور", "Remember username & password"))
    }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(
        onClick = {
            if (prefs.verify(user, pass)) {
                prefs.rememberMe = rememberMe
                prefs.savedPassword = if (rememberMe) pass else null
                enter()
            } else error = tr("اسم المستخدم أو كلمة المرور غير صحيحة", "Wrong username or password")
        },
        modifier = Modifier.fillMaxWidth().height(50.dp)
    ) { Text(tr("دخول", "Sign in"), fontSize = 16.sp) }
    if (bioReady) {
        OutlinedButton(onClick = { Bio.prompt(ctx) { enter() } }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(tr("الدخول بالبصمة", "Use biometrics"))
        }
    }
    TextButton(onClick = { showForgot = true }, modifier = Modifier.fillMaxWidth()) { Text(tr("نسيت كلمة المرور؟", "Forgot password?")) }
    if (showForgot) {
        AlertDialog(
            onDismissRequest = { showForgot = false },
            title = { Text(tr("استعادة الدخول", "Recover access")) },
            text = {
                Text(
                    tr(
                        "بياناتك محفوظة على هذا الجهاز فقط ولا يوجد خادم لاستعادة كلمة المرور.\n\n• إن فعّلت الدخول بالبصمة يمكنك الدخول بها ثم تغيير كلمة المرور من الملف الشخصي.\n• إن حفظت كلمة المرور سابقاً ستظهر تلقائياً في الحقل.",
                        "Your data lives only on this device; there is no server to reset your password.\n\n• If biometrics is enabled, sign in with it and change your password from Profile.\n• If you saved your password before, it is pre-filled."
                    )
                )
            },
            confirmButton = { TextButton(onClick = { showForgot = false }) { Text(tr("حسناً", "OK")) } }
        )
    }
}

@Composable
private fun RegisterForm(prefs: Prefs) {
    var name by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Text(tr("إنشاء حساب جديد", "Create your account"), fontWeight = FontWeight.Bold, fontSize = 20.sp)
    Text(tr("الحساب محلي ويحمي بياناتك على هذا الجهاز", "A local account that protects your data on this device"), style = MaterialTheme.typography.bodySmall)
    OutlinedTextField(name, { name = it }, label = { Text(tr("الاسم الكامل", "Full name")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Badge, null) }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(user, { user = it.trim() }, label = { Text(tr("اسم المستخدم", "Username")) }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Person, null) }, modifier = Modifier.fillMaxWidth())
    PasswordField(pass, { pass = it }, tr("كلمة المرور", "Password"))
    PasswordField(pass2, { pass2 = it }, tr("تأكيد كلمة المرور", "Confirm password"))
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Button(
        onClick = {
            error = when {
                name.isBlank() -> tr("أدخل الاسم", "Enter your name")
                user.length < 3 -> tr("اسم المستخدم 3 أحرف على الأقل", "Username must be at least 3 characters")
                pass.length < 4 -> tr("كلمة المرور 4 أحرف على الأقل", "Password must be at least 4 characters")
                pass != pass2 -> tr("كلمتا المرور غير متطابقتين", "Passwords do not match")
                else -> null
            }
            if (error == null) {
                prefs.register(user, pass, name)
                prefs.rememberMe = true
                prefs.savedPassword = pass
                AppState.displayName.value = name.trim()
                AppState.loggedIn.value = true
            }
        },
        modifier = Modifier.fillMaxWidth().height(50.dp)
    ) { Text(tr("إنشاء الحساب", "Create account"), fontSize = 16.sp) }
}
