package com.sho3eb.app.core.video

import android.content.Context
import android.graphics.*
import android.net.Uri
import java.io.File
import com.sho3eb.app.core.tr
import java.util.concurrent.Executors
import kotlin.math.*

/**
 * يرسم إطار الفيديو كاملاً في لحظة معينة: الصور بحركاتها وأنماط ظهورها، الانتقالات بين الصور،
 * النصوص، الشعار، الملصقات، المؤثرات (ثلج، مطر، ألعاب نارية…) والإطارات.
 * يُستخدم نفس الرسام للمعاينة داخل المحرر وللتصدير النهائي، فيظهر الناتج كما في المعاينة تماماً.
 */
class VPainter(private val ctx: Context, @Volatile var proj: VProject, val w: Int, val h: Int, private val async: Boolean) {
    private val s = min(w, h) / 720f
    var onReady: (() -> Unit)? = null
    /** حدود الطبقات المرسومة (للمس والسحب في المعاينة) */
    val bounds = java.util.concurrent.ConcurrentHashMap<String, RectF>()

    class Prep(val bg: Bitmap, val photo: Bitmap)

    // ---------------- تحميل الصور ----------------
    companion object {
        private val cache = object : LinkedHashMap<String, Any>(16, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Any>?): Boolean = size > 7
        }
        private val pending = HashSet<String>()
        private val loader = Executors.newSingleThreadExecutor()
        fun clearCache() = synchronized(cache) { cache.clear() }

        fun openStream(ctx: Context, uri: String) = if (uri.startsWith("/")) File(uri).inputStream() else ctx.contentResolver.openInputStream(Uri.parse(uri))

        /** فك ترميز صورة بحجم مناسب مع تصحيح الاتجاه (EXIF) */
        fun decode(ctx: Context, uri: String, maxDim: Int): Bitmap? = runCatching {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            openStream(ctx, uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            if (o.outWidth <= 0) return null
            var sample = 1
            while (max(o.outWidth, o.outHeight) / (sample * 2) >= maxDim) sample *= 2
            var b = openStream(ctx, uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }) } ?: return null
            val rot = runCatching { openStream(ctx, uri)?.use { android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1) } }.getOrNull() ?: 1
            val deg = when (rot) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
            val k = maxDim.toFloat() / max(b.width, b.height)
            if (k < 1f) b = Bitmap.createScaledBitmap(b, max(1, (b.width * k).toInt()), max(1, (b.height * k).toInt()), true)
            b
        }.getOrNull()

        /** صورة مصغرة لإطار من فيديو */
        fun videoFrame(ctx: Context, uri: String, atMs: Long, maxDim: Int): Bitmap? = runCatching {
            val r = android.media.MediaMetadataRetriever()
            try {
                if (uri.startsWith("/")) r.setDataSource(uri) else r.setDataSource(ctx, Uri.parse(uri))
                r.getFrameAtTime(atMs * 1000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { b ->
                    val k = maxDim.toFloat() / max(b.width, b.height); if (k < 1f) Bitmap.createScaledBitmap(b, max(1, (b.width * k).toInt()), max(1, (b.height * k).toInt()), true) else b
                }
            } finally { r.release() }
        }.getOrNull()
    }

    private fun makePrep(uri: String, video: Boolean, enh: String): Prep? {
        val photo0 = (if (video) videoFrame(ctx, uri, 500, max(w, h)) else decode(ctx, uri, max(w, h))) ?: return null
        val photo = if (enh.isNotBlank() && !video) runCatching { VEnhance.apply(photo0, enh) }.getOrDefault(photo0) else photo0
        // خلفية ضبابية: تصغير شديد ثم تكبير بفلترة ناعمة
        val tiny = Bitmap.createScaledBitmap(photo, max(2, photo.width / 28), max(2, photo.height / 28), true)
        val bw = max(4, w / 6); val bh = max(4, h / 6)
        val bg = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        Canvas(bg).apply {
            val k = max(bw.toFloat() / tiny.width, bh.toFloat() / tiny.height)
            val dw = tiny.width * k; val dh = tiny.height * k
            drawBitmap(tiny, null, RectF((bw - dw) / 2, (bh - dh) / 2, (bw + dw) / 2, (bh + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        return Prep(bg, photo)
    }

    fun prep(uri: String, video: Boolean = false, enh: String = ""): Prep? {
        val key = "$uri|$w|$h|$enh"
        synchronized(cache) { (cache[key] as? Prep)?.let { return it } }
        if (!async) { val p = makePrep(uri, video, enh) ?: return null; synchronized(cache) { cache[key] = p }; return p }
        synchronized(cache) { if (!pending.add(key)) return null }
        loader.execute {
            val p = runCatching { makePrep(uri, video, enh) }.getOrNull()
            synchronized(cache) { pending.remove(key); if (p != null) cache[key] = p }
            onReady?.invoke()
        }
        return null
    }
    fun warm(uri: String, video: Boolean = false, enh: String = "") { prep(uri, video, enh) }
    fun ready(uri: String, enh: String = ""): Boolean = synchronized(cache) { cache.containsKey("$uri|$w|$h|$enh") }

    private fun logo(path: String): Bitmap? {
        val key = "logo|$path"
        synchronized(cache) { (cache[key] as? Bitmap)?.let { return it } }
        val b = decode(ctx, path, 512) ?: return null
        synchronized(cache) { cache[key] = b }
        return b
    }


    // ---------------- خلفيات الفيديو ----------------
    private val vidSize = HashMap<String, Pair<Int, Int>>()
    private fun videoDims(uri: String): Pair<Int, Int>? = vidSize[uri] ?: runCatching {
        val r = android.media.MediaMetadataRetriever()
        try {
            if (uri.startsWith("/")) r.setDataSource(uri) else r.setDataSource(ctx, Uri.parse(uri))
            var vw = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            var vh = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            val rot = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val x = vw; vw = vh; vh = x }
            (vw to vh).also { vidSize[uri] = it }
        } finally { r.release() }
    }.getOrNull()

    /** تلوين الشريطين حول الفيديو بالخلفية المختارة */
    private fun videoBars(c: Canvas, clip: VClip) {
        val (vw, vh) = videoDims(clip.uri) ?: return
        val r = fitRect(vw, vh, w.toFloat(), h.toFloat(), w / 2f, h / 2f)
        if (r.width() >= w - 2 && r.height() >= h - 2) return
        c.save()
        clipOut(c, r)
        val pr = if (proj.bg == "BLUR") prep(clip.uri, true) else null
        drawBg(c, pr, 1.0f)
        c.restore()
    }

    @Suppress("DEPRECATION")
    private fun clipOut(c: Canvas, r: RectF) { if (android.os.Build.VERSION.SDK_INT >= 26) c.clipOutRect(r) else c.clipRect(r, Region.Op.DIFFERENCE) }

    private fun presetBg(c: Canvas, sec: Float) {
        val W = w.toFloat(); val H = h.toFloat()
        fun grad(vararg cols: Int) { fill.shader = LinearGradient(0f, 0f, W * 0.3f, H, cols, null, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, fill); fill.shader = null }
        when (proj.bg) {
            "COLOR" -> c.drawColor(proj.bgColor)
            "SUNBURST" -> {
                grad(0xFFFFE082.toInt(), 0xFFFF8F00.toInt())
                val n = 18; val R = hypot(W, H)
                c.save(); c.rotate(sec * 8f, W / 2, H / 2)
                fill.color = 0x33FFFFFF
                for (k in 0 until n step 1) if (k % 2 == 0) {
                    val a1 = (k * 360f / n) * PI.toFloat() / 180f; val a2 = ((k + 1) * 360f / n) * PI.toFloat() / 180f
                    c.drawPath(Path().apply { moveTo(W / 2, H / 2); lineTo(W / 2 + cos(a1) * R, H / 2 + sin(a1) * R); lineTo(W / 2 + cos(a2) * R, H / 2 + sin(a2) * R); close() }, fill)
                }
                c.restore()
                fill.shader = RadialGradient(W / 2, H / 2, H * 0.5f, 0x88FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP); c.drawCircle(W / 2, H / 2, H * 0.5f, fill); fill.shader = null
            }
            "SNOWFLAKES" -> { grad(0xFF0D47A1.toInt(), 0xFF64B5F6.toInt()); for (i in 0 until 26) { val y = ((rnd(i, 3) * (H + 60) + sec * (20 + 30 * rnd(i, 2)) * s) % (H + 60)) - 30; c.save(); c.rotate(sec * 20 + i * 30, rnd(i, 1) * W, y); emoji(c, "❄️", rnd(i, 1) * W, y, (18 + 30 * rnd(i, 4)) * s, 170); c.restore() }; particles(c, "SNOW", sec, 0.6f, 4) }
            "GIFTS" -> { grad(0xFFB71C1C.toInt(), 0xFF880E4F.toInt()); patternEmoji(c, listOf("🎁", "🎀", "✨"), sec, 0.55f) }
            "HEARTS" -> { grad(0xFFFF80AB.toInt(), 0xFFC2185B.toInt()); patternEmoji(c, listOf("💗", "💕", "❤️"), sec, 0.5f) }
            "STARS" -> { grad(0xFF0B1033.toInt(), 0xFF283593.toInt()); particles(c, "STARS", sec, 1f, 8) }
            "BALLOONS" -> { grad(0xFF81D4FA.toInt(), 0xFFE1F5FE.toInt()); particles(c, "BALLOONS", sec, 0.9f, 6) }
            "GLITTER" -> { grad(0xFF3E2723.toInt(), 0xFF000000.toInt()); particles(c, "SPARKLES", sec, 1f, 9); particles(c, "LIGHTS", sec, 0.8f, 10) }
            "BOKEH" -> { grad(0xFF1A1A2E.toInt(), 0xFF16213E.toInt()); particles(c, "LIGHTS", sec, 1f, 12) }
            "SUNSET" -> grad(0xFFFF7043.toInt(), 0xFFAB47BC.toInt(), 0xFF283593.toInt())
            "OCEAN" -> { grad(0xFF00BCD4.toInt(), 0xFF01579B.toInt()); particles(c, "BUBBLES", sec, 0.5f, 7) }
            "PURPLE" -> grad(0xFF4A148C.toInt(), 0xFF12005E.toInt())
            "CONFETTI" -> { grad(0xFFFFF8E1.toInt(), 0xFFFFE0B2.toInt()); particles(c, "CONFETTI", sec, 0.9f, 3) }
            "RAMADAN" -> { grad(0xFF1A237E.toInt(), 0xFF000000.toInt()); particles(c, "STARS", sec, 1f, 5); particles(c, "LANTERNS", sec, 1f, 5) }
            else -> c.drawColor(0xFF101018.toInt())
        }
    }
    private fun patternEmoji(c: Canvas, list: List<String>, sec: Float, alpha: Float) {
        val W = w.toFloat(); val H = h.toFloat(); val step = 90 * s
        var row = 0; var y = -step / 2 + (sec * 10 * s) % step
        while (y < H + step) { var x = if (row % 2 == 0) 0f else step / 2
            while (x < W + step) { emoji(c, list[(row + (x / step).toInt()) % list.size], x, y, 38 * s, (255 * alpha).toInt()); x += step }
            y += step * 0.8f; row++ }
    }

    // ---------------- أدوات مساعدة ----------------
    private fun cl(v: Float) = v.coerceIn(0f, 1f)
    private fun easeOutCubic(t: Float) = 1 - (1 - cl(t)).pow(3)
    private fun easeInOut(t: Float) = cl(t).let { it * it * (3 - 2 * it) }
    private fun easeOutBack(t: Float): Float { val x = cl(t); val c1 = 1.70158f; val c3 = c1 + 1; return 1 + c3 * (x - 1).pow(3) + c1 * (x - 1).pow(2) }
    private fun easeOutBounce(t: Float): Float {
        var x = cl(t); val n1 = 7.5625f; val d1 = 2.75f
        return when {
            x < 1 / d1 -> n1 * x * x
            x < 2 / d1 -> { x -= 1.5f / d1; n1 * x * x + 0.75f }
            x < 2.5 / d1 -> { x -= 2.25f / d1; n1 * x * x + 0.9375f }
            else -> { x -= 2.625f / d1; n1 * x * x + 0.984375f }
        }
    }
    private fun rnd(i: Int, k: Int): Float { val v = sin(i * 12.9898 + k * 78.233) * 43758.5453; return (v - floor(v)).toFloat() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    private fun filterMatrix(): ColorMatrix? = when (proj.filter) {
        "BW" -> ColorMatrix().apply { setSaturation(0f) }
        "SEPIA" -> ColorMatrix(floatArrayOf(0.393f, 0.769f, 0.189f, 0f, 0f, 0.349f, 0.686f, 0.168f, 0f, 0f, 0.272f, 0.534f, 0.131f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
        "WARM" -> ColorMatrix(floatArrayOf(1.12f, 0f, 0f, 0f, 8f, 0f, 1.02f, 0f, 0f, 0f, 0f, 0f, 0.85f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
        "COOL" -> ColorMatrix(floatArrayOf(0.88f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.15f, 0f, 8f, 0f, 0f, 0f, 1f, 0f))
        "VIVID" -> ColorMatrix().apply { setSaturation(1.45f) }
        "FADED" -> ColorMatrix(floatArrayOf(0.85f, 0f, 0f, 0f, 30f, 0f, 0.85f, 0f, 0f, 30f, 0f, 0f, 0.85f, 0f, 34f, 0f, 0f, 0f, 1f, 0f)).apply { postConcat(ColorMatrix().apply { setSaturation(0.75f) }) }
        else -> null
    }
    private var lastFilter = "?"
    private fun photoPaint(): Paint {
        if (lastFilter != proj.filter) { lastFilter = proj.filter; bmpPaint.colorFilter = filterMatrix()?.let { ColorMatrixColorFilter(it) } }
        return bmpPaint
    }
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private var bgFilterKey = "?"
    private fun bgPaint(): Paint {
        if (bgFilterKey != proj.filter) {
            bgFilterKey = proj.filter
            val m = ColorMatrix().apply { setScale(0.55f, 0.55f, 0.55f, 1f) }
            filterMatrix()?.let { m.preConcat(it) }
            bgPaint.colorFilter = ColorMatrixColorFilter(m)
        }
        return bgPaint
    }

    private fun fitRect(bw: Int, bh: Int, maxW: Float, maxH: Float, cx: Float, cy: Float): RectF {
        val k = min(maxW / bw, maxH / bh); val dw = bw * k; val dh = bh * k
        return RectF(cx - dw / 2, cy - dh / 2, cx + dw / 2, cy + dh / 2)
    }
    private fun coverSrc(b: Bitmap, rw: Float, rh: Float): Rect {
        val k = max(rw / b.width, rh / b.height); val sw = (rw / k).toInt(); val sh = (rh / k).toInt()
        val l = (b.width - sw) / 2; val t = (b.height - sh) / 2
        return Rect(l, t, l + sw, t + sh)
    }
    private var curT = 0L
    private fun drawBg(c: Canvas, p: Prep?, zoom: Float = 1.06f) {
        if (proj.bg != "BLUR" || p == null) { presetBg(c, curT / 1000f); return }
        c.save(); c.scale(zoom, zoom, w / 2f, h / 2f)
        c.drawBitmap(p.bg, coverSrc(p.bg, w.toFloat(), h.toFloat()), RectF(0f, 0f, w.toFloat(), h.toFloat()), bgPaint())
        c.restore()
    }

    // ---------------- الإطار الكامل ----------------
    /** يرسم الإطار عند الزمن t (ملّي ثانية من بداية الفيديو). clipHint = رقم العنصر عند التصدير */
    fun draw(c: Canvas, t: Long, clipHint: Int = -1) {
        bounds.clear(); curT = t
        val clips = proj.clips
        if (clips.isEmpty()) { c.drawColor(0xFF15151A.toInt()); drawOverlays(c, t); return }
        val i = if (clipHint in clips.indices) clipHint else proj.clipAt(t).coerceAtLeast(0)
        val clip = clips[i]
        val start = proj.startOf(i)
        val local = (t - start).coerceIn(0, clip.durMs)
        val next = clips.getOrNull(i + 1)
        val tr = min(proj.transitionMs, min(clip.durMs / 2, next?.durMs?.div(2) ?: Long.MAX_VALUE))
        val inTrans = next != null && clip.transition != "NONE" && tr > 50 && local > clip.durMs - tr
        if (!inTrans) { if (clip.video) videoBars(c, clip); drawClip(c, i, local) }
        else transition(c, i, local, cl((local - (clip.durMs - tr)).toFloat() / tr), if (clip.video || next!!.video) (if (clip.transition == "WHITE") "WHITE" else "BLACK") else clip.transition)
        // عنصر فيديو بعد انتقال: يظهر تدريجياً من الأسود
        val prev = clips.getOrNull(i - 1)
        if (clip.video && prev != null && prev.transition != "NONE") {
            val half = (min(proj.transitionMs, prev.durMs / 2) / 2).coerceAtLeast(1)
            if (local < half) { fill.color = if (prev.transition == "WHITE") Color.WHITE else Color.BLACK; fill.alpha = (255 * (1 - local.toFloat() / half)).toInt(); c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill); fill.alpha = 255 }
        }
        drawOverlays(c, t)
    }

    private fun transition(c: Canvas, i: Int, localA: Long, p0: Float, kind: String) {
        val p = easeInOut(p0)
        val W = w.toFloat(); val H = h.toFloat()
        fun a() = drawClip(c, i, localA)
        fun b() = drawClip(c, i + 1, 0)
        when (kind) {
            "BLACK", "WHITE" -> {
                val col = if (kind == "WHITE") Color.WHITE else Color.BLACK
                if (p0 < 0.5f) { a(); fill.color = col; fill.alpha = (255 * p0 * 2).toInt() }
                else { if (proj.clips[i + 1].video) { fill.color = col; fill.alpha = 255 } else { b(); fill.color = col; fill.alpha = (255 * (1 - p0) * 2).toInt() } }
                c.drawRect(0f, 0f, W, H, fill); fill.alpha = 255
            }
            "FADE" -> { a(); val l = c.saveLayerAlpha(0f, 0f, W, H, (255 * p).toInt()); b(); c.restoreToCount(l) }
            "SLIDE_L", "SLIDE_R", "SLIDE_UP", "PUSH_DOWN" -> {
                val (dx, dy) = when (kind) { "SLIDE_L" -> -W to 0f; "SLIDE_R" -> W to 0f; "SLIDE_UP" -> 0f to -H; else -> 0f to H }
                c.save(); c.translate(dx * p, dy * p); a(); c.restore()
                c.save(); c.translate(-dx * (1 - p), -dy * (1 - p)); b(); c.restore()
            }
            "ZOOM" -> {
                c.save(); c.scale(1 + p * 0.7f, 1 + p * 0.7f, W / 2, H / 2); a(); c.restore()
                val l = c.saveLayerAlpha(0f, 0f, W, H, (255 * p).toInt()); c.scale(0.5f + 0.5f * p, 0.5f + 0.5f * p, W / 2, H / 2); b(); c.restoreToCount(l)
            }
            "CUBE", "CUBE_V" -> {
                val vert = kind == "CUBE_V"
                val ang = 90f * p
                fun face(draw: () -> Unit, deg: Float, pivotX: Float, pivotY: Float, tx: Float, ty: Float) { c.save(); c.translate(tx, ty); cam3d(c, if (vert) deg else 0f, if (vert) 0f else deg, 0f, pivotX, pivotY); draw(); c.restore() }
                val first: () -> Unit = { if (vert) face({ a() }, -ang, W / 2, H, 0f, -p * H) else face({ a() }, ang, W, H / 2, -p * W, 0f) }
                val second: () -> Unit = { if (vert) face({ b() }, 90f - ang, W / 2, 0f, 0f, (1 - p) * H) else face({ b() }, -(90f - ang), 0f, H / 2, (1 - p) * W, 0f) }
                c.drawColor(Color.BLACK)
                if (p < 0.5f) { second(); first() } else { first(); second() }
            }
            "FLIP", "FLIP_V" -> {
                c.drawColor(Color.BLACK)
                val v = kind == "FLIP_V"
                c.save()
                if (p < 0.5f) { cam3d(c, if (v) 180f * p else 0f, if (v) 0f else 180f * p, 0f, W / 2, H / 2); a() }
                else { cam3d(c, if (v) -180f * (1 - p) else 0f, if (v) 0f else -180f * (1 - p), 0f, W / 2, H / 2); b() }
                c.restore()
            }
            "DOOR" -> {
                b()
                c.save(); c.clipRect(0f, 0f, W / 2, H); cam3d(c, 0f, -100f * p, 0f, 0f, H / 2); a(); c.restore()
                c.save(); c.clipRect(W / 2, 0f, W, H); cam3d(c, 0f, 100f * p, 0f, W, H / 2); a(); c.restore()
            }
            "PAGE" -> {
                b()
                c.save(); cam3d(c, 0f, -110f * p, 0f, 0f, H / 2); a()
                fill.color = Color.BLACK; fill.alpha = (120 * p).toInt(); c.drawRect(0f, 0f, W, H, fill); fill.alpha = 255; c.restore()
            }
            "SWING" -> {
                a()
                c.save(); cam3d(c, -95f * (1 - p), 0f, 0f, W / 2, 0f); b(); c.restore()
            }
            "TUNNEL" -> {
                c.drawColor(Color.BLACK)
                c.save(); c.scale(1 - 0.75f * p, 1 - 0.75f * p, W / 2, H / 2); c.rotate(200f * p, W / 2, H / 2)
                val l1 = c.saveLayerAlpha(0f, 0f, W, H, (255 * (1 - p)).toInt()); a(); c.restoreToCount(l1); c.restore()
                c.save(); val k = 3f - 2f * p; c.scale(k, k, W / 2, H / 2); c.rotate(-120f * (1 - p), W / 2, H / 2)
                val l2 = c.saveLayerAlpha(0f, 0f, W, H, (255 * p).toInt()); b(); c.restoreToCount(l2); c.restore()
            }
            "VORTEX" -> {
                c.drawColor(Color.BLACK)
                if (p < 0.5f) { c.save(); cam3d(c, 0f, 180f * p, 360f * p, W / 2, H / 2); c.scale(1 - p, 1 - p, W / 2, H / 2); a(); c.restore() }
                else { c.save(); cam3d(c, 0f, -180f * (1 - p), -360f * (1 - p), W / 2, H / 2); c.scale(p, p, W / 2, H / 2); b(); c.restore() }
            }
            "FOLD" -> {
                b()
                val n = 6; val sw = W / n
                for (k in 0 until n) {
                    c.save(); c.clipRect(k * sw, 0f, (k + 1) * sw, H)
                    cam3d(c, 0f, (if (k % 2 == 0) 1f else -1f) * 90f * cl(p * 1.4f - k * 0.06f), 0f, k * sw + sw / 2, H / 2)
                    a(); c.restore()
                }
            }
            "SHATTER" -> {
                b()
                val n = 5; val m = 4; val cw = W / n; val ch = H / m
                for (yy in 0 until m) for (xx in 0 until n) {
                    val k = yy * n + xx; val d = cl(p * 1.6f - rnd(k, 2) * 0.6f)
                    if (d >= 1f) continue
                    c.save()
                    val cx = xx * cw + cw / 2; val cy = yy * ch + ch / 2
                    c.translate((rnd(k, 3) - 0.5f) * W * d, H * d * d * 0.9f)
                    c.rotate((rnd(k, 4) - 0.5f) * 180f * d, cx, cy)
                    c.clipRect(xx * cw, yy * ch, (xx + 1) * cw, (yy + 1) * ch)
                    val l = c.saveLayerAlpha(0f, 0f, W, H, (255 * (1 - d)).toInt()); a(); c.restoreToCount(l)
                    c.restore()
                }
            }
            "SPIN" -> {
                a()
                c.save(); c.rotate(-200f * (1 - p), W / 2, H / 2); c.scale(max(0.01f, p), max(0.01f, p), W / 2, H / 2); b(); c.restore()
            }
            else -> {
                a()
                val path = Path()
                val cx = W / 2; val cy = H / 2; val R = hypot(W, H) / 2 * p
                when (kind) {
                    "CIRCLE" -> path.addCircle(cx, cy, R, Path.Direction.CW)
                    "WIPE" -> path.addRect(0f, 0f, W * p, H, Path.Direction.CW)
                    "BLINDS" -> { val n = 8; val bh = H / n; for (k in 0 until n) path.addRect(0f, k * bh, W, k * bh + bh * p, Path.Direction.CW) }
                    "DIAMOND" -> { val r = R * 1.45f; path.moveTo(cx, cy - r); path.lineTo(cx + r, cy); path.lineTo(cx, cy + r); path.lineTo(cx - r, cy); path.close() }
                    "HEART" -> heartPath(path, cx, cy + R * 0.1f, R * 2.4f)
                    else -> path.addRect(0f, 0f, W, H, Path.Direction.CW)
                }
                c.save(); c.clipPath(path); b(); c.restore()
            }
        }
    }

    private val camera = Camera()
    private val camM = Matrix()
    /** منظور ثلاثي الأبعاد حول نقطة */
    private fun cam3d(c: Canvas, rx: Float, ry: Float, rz: Float, px: Float, py: Float) {
        camera.save()
        camera.setLocation(0f, 0f, -max(w, h) / 72f * 1.6f)
        camera.rotateX(rx); camera.rotateY(ry); camera.rotateZ(rz)
        camera.getMatrix(camM); camera.restore()
        camM.preTranslate(-px, -py); camM.postTranslate(px, py)
        c.concat(camM)
    }

    private fun heartPath(p: Path, cx: Float, cy: Float, size: Float) {
        val s2 = size / 2
        p.moveTo(cx, cy + s2 * 0.9f)
        p.cubicTo(cx - s2 * 1.3f, cy + s2 * 0.1f, cx - s2 * 0.9f, cy - s2 * 1.0f, cx, cy - s2 * 0.45f)
        p.cubicTo(cx + s2 * 0.9f, cy - s2 * 1.0f, cx + s2 * 1.3f, cy + s2 * 0.1f, cx, cy + s2 * 0.9f)
        p.close()
    }
    private fun starPath(p: Path, cx: Float, cy: Float, r: Float, points: Int = 5, inner: Float = 0.45f) {
        for (k in 0 until points * 2) {
            val rr = if (k % 2 == 0) r else r * inner
            val a = -PI / 2 + k * PI / points
            val x = cx + (rr * cos(a)).toFloat(); val y = cy + (rr * sin(a)).toFloat()
            if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }
    private var fxScale = 1f
    private fun emoji(c: Canvas, e: String, x: Float, y: Float, size0: Float, alpha: Int = 255) {
        val size = size0 * fxScale
        emojiPaint.textSize = size; emojiPaint.alpha = alpha
        val fm = emojiPaint.fontMetrics
        c.drawText(e, x, y - (fm.ascent + fm.descent) / 2, emojiPaint)
        emojiPaint.alpha = 255
    }

    // ---------------- رسم الصورة بأنماطها ----------------
    private fun drawClip(c: Canvas, i: Int, local: Long) {
        val clip = proj.clips.getOrNull(i) ?: return
        if (clip.isCard) { titleCard(c, clip, local); return }
        if (clip.video) return  // الفيديو نفسه يُعرض تحت الرسم
        val W = w.toFloat(); val H = h.toFloat()
        val pr = prep(clip.uri, false, clip.enh) ?: run { c.drawColor(0xFF1E1E24.toInt()); return }
        val dur = clip.durMs.coerceAtLeast(1)
        val p = local.toFloat() / dur
        val e = local / 900f
        val ph = photoPaint()
        when (clip.style) {
            "NORMAL" -> {
                c.save()
                when (clip.motion) {
                    "ZOOM_IN" -> (1f + 0.16f * p).let { c.scale(it, it, W / 2, H / 2) }
                    "ZOOM_OUT" -> (1.16f - 0.16f * p).let { c.scale(it, it, W / 2, H / 2) }
                    "PAN_L" -> { c.scale(1.16f, 1.16f, W / 2, H / 2); c.translate((0.06f - 0.12f * p) * W, 0f) }
                    "PAN_R" -> { c.scale(1.16f, 1.16f, W / 2, H / 2); c.translate((-0.06f + 0.12f * p) * W, 0f) }
                    "PAN_UP" -> { c.scale(1.16f, 1.16f, W / 2, H / 2); c.translate(0f, (0.06f - 0.12f * p) * H) }
                    "ROTATE" -> { c.scale(1.14f, 1.14f, W / 2, H / 2); c.rotate(-2.5f + 5f * p, W / 2, H / 2) }
                }
                drawBg(c, pr, 1f)
                c.drawBitmap(pr.photo, null, fitRect(pr.photo.width, pr.photo.height, W, H, W / 2, H / 2), ph)
                c.restore()
            }
            "CARD" -> {
                drawBg(c, pr)
                val cy = -H * 0.6f + (H * 0.5f + H * 0.6f) * easeOutBounce(e)
                val rot = -7f + 9f * easeOutCubic(e) + sin(local / 900f) * 1.2f
                card(c, pr, W / 2, cy, W * 0.6f, H * 0.66f, rot, 1f, clip.caption)
            }
            "BOUNCE" -> {
                drawBg(c, pr)
                val sc = easeOutBack(e).coerceAtLeast(0.01f)
                card(c, pr, W / 2, H * 0.5f + sin(local / 450f) * H * 0.012f, W * 0.62f, H * 0.68f, sin(local / 700f) * 2f, sc, clip.caption)
            }
            "BALLOONS" -> {
                drawBg(c, pr)
                val r0 = fitRect(pr.photo.width, pr.photo.height, W * 0.5f, H * 0.42f, 0f, 0f)
                val ch = r0.height() * 1.18f
                val cy = H + ch - (H + ch - H * 0.62f) * easeOutCubic(local / (dur * 0.5f)) + sin(local / 700f) * H * 0.015f
                val cx = W / 2 + sin(local / 1100f) * W * 0.015f
                val rect = card(c, pr, cx, cy, W * 0.5f, H * 0.42f, sin(local / 800f) * 2.5f, 1f, clip.caption, drawNow = false)
                val cols = intArrayOf(0xFFE53935.toInt(), 0xFFFFB300.toInt(), 0xFF43A047.toInt(), 0xFF1E88E5.toInt(), 0xFF8E24AA.toInt())
                val offs = floatArrayOf(-0.36f, -0.18f, 0f, 0.18f, 0.36f); val hs = floatArrayOf(0.5f, 0.66f, 0.76f, 0.64f, 0.48f)
                for (k in 0 until 5) {
                    val bx = cx + offs[k] * rect.width() * 1.3f + sin(local / 600f + k) * 6 * s
                    val by = rect.top - hs[k] * rect.height()
                    balloon(c, bx, by, H * 0.075f, cols[k], cx, rect.top)
                }
                card(c, pr, cx, cy, W * 0.5f, H * 0.42f, sin(local / 800f) * 2.5f, 1f, clip.caption)
            }
            "BIRDS" -> {
                drawBg(c, pr)
                val r0 = fitRect(pr.photo.width, pr.photo.height, W * 0.5f, H * 0.5f, 0f, 0f)
                val cx = W + r0.width() - (W + r0.width() - W * 0.5f) * easeOutCubic(local / (dur * 0.5f))
                val cy = H * 0.6f + sin(local / 500f) * H * 0.02f
                val rect = card(c, pr, cx, cy, W * 0.5f, H * 0.5f, sin(local / 500f) * 3f, 1f, clip.caption, drawNow = false)
                val flap = if ((local / 170) % 2 == 0L) 1f else 0.78f
                stroke.color = 0xCCFFFFFF.toInt(); stroke.strokeWidth = 2.5f * s
                val b1 = PointF(rect.left + rect.width() * 0.15f, rect.top - H * 0.2f); val b2 = PointF(rect.right - rect.width() * 0.15f, rect.top - H * 0.24f)
                c.drawLine(b1.x, b1.y + H * 0.04f, rect.left + rect.width() * 0.12f, rect.top, stroke)
                c.drawLine(b2.x, b2.y + H * 0.04f, rect.right - rect.width() * 0.12f, rect.top, stroke)
                card(c, pr, cx, cy, W * 0.5f, H * 0.5f, sin(local / 500f) * 3f, 1f, clip.caption)
                for (b in listOf(b1, b2)) { c.save(); c.scale(1f, flap, b.x, b.y); emoji(c, "🕊️", b.x, b.y, H * 0.14f); c.restore() }
            }
            "ANIMAL" -> {
                drawBg(c, pr)
                val an = VEditor.animals[i % VEditor.animals.size]
                val asz = H * 0.34f
                val ax = -W * 0.25f + (W * 0.75f) * easeOutCubic(local / (dur * 0.5f))
                val walking = local < dur * 0.5f
                val bob = if (walking) abs(sin(local / 170f)) * H * 0.03f else sin(local / 600f) * H * 0.008f
                val ay = H - asz * 0.5f - bob
                val r0 = fitRect(pr.photo.width, pr.photo.height, W * 0.46f, H * 0.42f, 0f, 0f)
                val ccy = ay - asz * 0.42f - r0.height() * 0.62f
                val rect = card(c, pr, ax, ccy, W * 0.46f, H * 0.42f, sin(local / 340f) * (if (walking) 3f else 1f), 1f, clip.caption, drawNow = false)
                stroke.color = 0xFF6D4C41.toInt(); stroke.strokeWidth = 9f * s; stroke.strokeCap = Paint.Cap.ROUND
                c.drawLine(ax - asz * 0.32f, ay - asz * 0.05f, rect.left + rect.width() * 0.2f, rect.bottom - 4 * s, stroke)
                c.drawLine(ax + asz * 0.32f, ay - asz * 0.05f, rect.right - rect.width() * 0.2f, rect.bottom - 4 * s, stroke)
                card(c, pr, ax, ccy, W * 0.46f, H * 0.42f, sin(local / 340f) * (if (walking) 3f else 1f), 1f, clip.caption)
                emoji(c, an, ax, ay, asz)
                stroke.strokeCap = Paint.Cap.BUTT
            }
            "ANIMAL2" -> {
                drawBg(c, pr)
                val a1 = VEditor.animals[i % VEditor.animals.size]; val a2 = VEditor.animals[(i + 3) % VEditor.animals.size]
                val asz = H * 0.3f
                val k = easeOutCubic(local / (dur * 0.5f))
                val walking = local < dur * 0.5f
                val bob = if (walking) abs(sin(local / 160f)) * H * 0.03f else sin(local / 600f) * H * 0.006f
                val r0 = fitRect(pr.photo.width, pr.photo.height, W * 0.56f, H * 0.42f, 0f, 0f)
                val gap = r0.width() * 0.5f
                val x1 = -W * 0.3f + (W / 2 - gap + W * 0.3f) * k; val x2 = W * 1.3f - (W * 1.3f - (W / 2 + gap)) * k
                val ay = H - asz * 0.5f - bob
                val cxm = (x1 + x2) / 2
                val ccy = ay - asz * 0.45f - r0.height() * 0.6f
                if (k > 0.85f) card(c, pr, cxm, ccy, W * 0.56f, H * 0.42f, sin(local / 500f) * 1.5f, easeOutBack((k - 0.85f) / 0.15f), clip.caption)
                emoji(c, a1, x1, ay, asz); emoji(c, a2, x2, ay, asz)
            }
            "PLANE" -> {
                drawBg(c, pr)
                val r0 = fitRect(pr.photo.width, pr.photo.height, W * 0.48f, H * 0.5f, 0f, 0f)
                val px = W * 1.15f - (W * 1.15f - W * 0.14f) * easeOutCubic(local / (dur * 0.55f)) - p * W * 0.03f
                val py = H * 0.3f + sin(local / 600f) * H * 0.03f
                val cx = px + W * 0.12f + r0.width() / 2; val cy = py + H * 0.16f
                stroke.color = 0xCCFFFFFF.toInt(); stroke.strokeWidth = 2.5f * s
                val rope = Path().apply { moveTo(px + H * 0.06f, py); quadTo(px + W * 0.08f, py + H * 0.12f + sin(local / 200f) * 6 * s, cx - r0.width() / 2, cy - r0.height() * 0.3f) }
                c.drawPath(rope, stroke)
                card(c, pr, cx, cy, W * 0.48f, H * 0.5f, sin(local / 300f) * 3f, 1f, clip.caption)
                c.save(); c.scale(-1f, 1f, px, py); emoji(c, "✈️", px, py, H * 0.16f); c.restore()
            }
            "GIFT" -> {
                drawBg(c, pr)
                val gsz = H * 0.3f; val gy = H - gsz * 0.55f
                val k = easeOutBack(local / (dur * 0.45f))
                val cy = gy - (gy - H * 0.42f) * cl(k)
                if (local > 150) card(c, pr, W / 2, cy, W * 0.55f, H * 0.56f, sin(local / 700f) * 2f, (0.15f + 0.85f * k).coerceAtLeast(0.05f), clip.caption)
                emoji(c, "🎁", W / 2, gy, gsz)
                if (local < dur * 0.6f) for (j in 0 until 10) {
                    val a = rnd(j, i) * 2 * PI.toFloat(); val r = (0.15f + 0.3f * cl(local / 1200f)) * H
                    emoji(c, "✨", W / 2 + cos(a) * r * 1.3f, H * 0.45f + sin(a) * r, H * 0.05f, (255 * (1 - cl(local / (dur * 0.6f)))).toInt())
                }
            }
            "HEART", "CIRCLE" -> {
                drawBg(c, pr)
                val pulse = 1f + 0.025f * sin(local / 300f)
                val size = H * 0.84f * pulse * easeOutBack(e).coerceAtLeast(0.01f)
                val path = Path()
                if (clip.style == "HEART") heartPath(path, W / 2, H / 2, size * 1.05f) else path.addCircle(W / 2, H / 2, size / 2, Path.Direction.CW)
                c.save(); c.clipPath(path)
                c.drawBitmap(pr.photo, coverSrc(pr.photo, size, size), RectF(W / 2 - size / 2, H / 2 - size / 2, W / 2 + size / 2, H / 2 + size / 2), ph)
                c.restore()
                if (clip.style == "HEART") {
                    stroke.strokeWidth = 7 * s; stroke.color = 0xFFFF4081.toInt(); stroke.setShadowLayer(14 * s, 0f, 0f, 0xFFFF80AB.toInt()); c.drawPath(path, stroke); stroke.clearShadowLayer()
                } else {
                    stroke.strokeWidth = 9 * s; stroke.shader = LinearGradient(0f, 0f, W, H, intArrayOf(0xFFF9E79F.toInt(), 0xFFD4AF37.toInt(), 0xFF9C7A1E.toInt()), null, Shader.TileMode.CLAMP)
                    c.drawCircle(W / 2, H / 2, size / 2, stroke); stroke.shader = null
                    stroke.strokeWidth = 3 * s; stroke.color = 0xCCFFFFFF.toInt(); stroke.pathEffect = DashPathEffect(floatArrayOf(14 * s, 10 * s), local / 20f)
                    c.drawCircle(W / 2, H / 2, size / 2 + 14 * s, stroke); stroke.pathEffect = null
                }
            }
            "FILM" -> {
                drawBg(c, pr)
                val bh = H * 0.8f; val top = (H - bh) / 2
                fill.color = 0xFF111111.toInt(); c.drawRect(0f, top, W, top + bh, fill)
                val hole = bh * 0.06f; val stepX = hole * 2.2f; val off = (local / 8f) % stepX
                fill.color = 0xFFEDE7D9.toInt()
                var x = -stepX + off
                while (x < W) { c.drawRoundRect(x, top + hole * 0.5f, x + hole * 1.2f, top + hole * 1.5f, 3 * s, 3 * s, fill); c.drawRoundRect(x, top + bh - hole * 1.5f, x + hole * 1.2f, top + bh - hole * 0.5f, 3 * s, 3 * s, fill); x += stepX }
                val inner = RectF(W * 0.08f, top + hole * 2.2f, W * 0.92f, top + bh - hole * 2.2f)
                val r = fitRect(pr.photo.width, pr.photo.height, inner.width(), inner.height(), W / 2 + (0.5f - p) * W * 0.04f, H / 2)
                c.drawBitmap(pr.photo, null, r, ph)
            }
            "TV" -> {
                drawBg(c, pr)
                val th = H * 0.84f; val tw = min(W * 0.86f, th * 1.35f)
                val body = RectF(W / 2 - tw / 2, H / 2 - th / 2 + H * 0.04f, W / 2 + tw / 2, H / 2 + th / 2 + H * 0.04f)
                stroke.color = 0xFF3E2723.toInt(); stroke.strokeWidth = 5 * s
                c.drawLine(W / 2, body.top, W / 2 - tw * 0.18f, body.top - H * 0.1f, stroke); c.drawLine(W / 2, body.top, W / 2 + tw * 0.18f, body.top - H * 0.12f, stroke)
                fill.shader = LinearGradient(0f, body.top, 0f, body.bottom, 0xFF8D6E63.toInt(), 0xFF4E342E.toInt(), Shader.TileMode.CLAMP)
                c.drawRoundRect(body, 30 * s, 30 * s, fill); fill.shader = null
                val scr = RectF(body.left + tw * 0.06f, body.top + th * 0.08f, body.right - tw * 0.2f, body.bottom - th * 0.08f)
                val on = cl(local / 500f)
                val vis = RectF(scr.left, scr.centerY() - scr.height() / 2 * max(0.02f, on), scr.right, scr.centerY() + scr.height() / 2 * max(0.02f, on))
                fill.color = Color.BLACK; c.drawRoundRect(scr, 24 * s, 24 * s, fill)
                c.save(); c.clipRect(vis)
                c.drawBitmap(pr.photo, coverSrc(pr.photo, scr.width(), scr.height()), scr, ph)
                fill.color = 0x22000000; var yy = scr.top; while (yy < scr.bottom) { c.drawRect(scr.left, yy, scr.right, yy + 2 * s, fill); yy += 5 * s }
                c.restore()
                fill.color = 0xFF263238.toInt()
                c.drawCircle(body.right - tw * 0.1f, body.top + th * 0.3f, tw * 0.04f, fill); c.drawCircle(body.right - tw * 0.1f, body.top + th * 0.5f, tw * 0.04f, fill)
            }
            "PHONE" -> {
                drawBg(c, pr)
                val ph2 = H * 0.92f; val pw = ph2 * 0.48f
                val cy = H + ph2 - (H + ph2 - H / 2) * easeOutBack(local / (dur * 0.4f))
                val body = RectF(W / 2 - pw / 2, cy - ph2 / 2, W / 2 + pw / 2, cy + ph2 / 2)
                fill.color = 0xFF111111.toInt(); fill.setShadowLayer(20 * s, 0f, 10 * s, 0x88000000.toInt()); c.drawRoundRect(body, pw * 0.14f, pw * 0.14f, fill); fill.clearShadowLayer()
                val scr = RectF(body.left + pw * 0.04f, body.top + pw * 0.04f, body.right - pw * 0.04f, body.bottom - pw * 0.04f)
                c.save(); c.clipPath(Path().apply { addRoundRect(scr, pw * 0.11f, pw * 0.11f, Path.Direction.CW) })
                c.drawBitmap(pr.photo, coverSrc(pr.photo, scr.width(), scr.height()), scr, ph); c.restore()
                fill.color = 0xFF111111.toInt(); c.drawRoundRect(W / 2 - pw * 0.15f, scr.top + 6 * s, W / 2 + pw * 0.15f, scr.top + pw * 0.08f, 20 * s, 20 * s, fill)
            }
            "SPLIT" -> {
                val other = proj.clips.getOrNull(i + 1)?.takeIf { !it.video && !it.isCard }?.let { prep(it.uri, false, it.enh) } ?: pr
                val k = easeOutCubic(e)
                val half = RectF(0f, 0f, W / 2, H)
                c.save(); c.translate(-(1 - k) * W / 2, 0f); c.clipRect(half); c.drawBitmap(pr.photo, coverSrc(pr.photo, W / 2, H), half, ph); c.restore()
                val half2 = RectF(W / 2, 0f, W, H)
                c.save(); c.translate((1 - k) * W / 2, 0f); c.clipRect(half2); c.drawBitmap(other.photo, coverSrc(other.photo, W / 2, H), half2, ph); c.restore()
                fill.color = Color.WHITE; c.drawRect(W / 2 - 3 * s, 0f, W / 2 + 3 * s, H, fill)
            }
            else -> drawBg(c, pr)
        }
    }

    // ---------------- البدايات والنهايات ----------------
    private val titleP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private fun title(c: Canvas, t: String, x: Float, y: Float, size: Float, color: Int, alpha: Float = 1f, glow: Int = 0, serif: Boolean = false, shader: Shader? = null) {
        if (t.isBlank()) return
        titleP.textSize = size; titleP.typeface = if (serif) Typeface.create(Typeface.SERIF, Typeface.BOLD) else Typeface.DEFAULT_BOLD
        // تصغير تلقائي إن كان النص أعرض من الشاشة
        val mw = titleP.measureText(t); if (mw > w * 0.9f) titleP.textSize = size * w * 0.9f / mw
        titleP.color = color; titleP.alpha = (255 * cl(alpha)).toInt(); titleP.shader = shader
        if (glow != 0) titleP.setShadowLayer(titleP.textSize * 0.35f, 0f, 0f, glow) else titleP.setShadowLayer(titleP.textSize * 0.08f, 0f, titleP.textSize * 0.05f, 0x88000000.toInt())
        c.drawText(t, x, y, titleP); titleP.clearShadowLayer(); titleP.shader = null
    }
    private fun gradBg(c: Canvas, top: Int, bottom: Int) {
        fill.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bottom, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill); fill.shader = null
    }

    private fun titleCard(c: Canvas, clip: VClip, local: Long) {
        val W = w.toFloat(); val H = h.toFloat()
        val dur = clip.durMs.coerceAtLeast(1); val p = local.toFloat() / dur; val sec = local / 1000f
        val col = clip.color; val tsz = H * 0.12f; val ssz = H * 0.055f
        val ty = H * 0.5f; val sy = H * 0.62f
        when (clip.style) {
            "I_CURTAIN" -> {
                gradBg(c, 0xFF1A0F0A.toInt(), 0xFF000000.toInt())
                fill.shader = RadialGradient(W / 2, H * 0.1f, H, intArrayOf(0x66FFE082, 0x00000000), null, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, fill); fill.shader = null
                title(c, clip.title, W / 2, ty, tsz, col, cl((p - 0.25f) / 0.2f), serif = true)
                title(c, clip.sub, W / 2, sy, ssz, 0xFFFFE082.toInt(), cl((p - 0.4f) / 0.2f))
                val open = easeInOut(cl(p / 0.55f)); val cw = W / 2 * (1 - open * 0.92f)
                for (side in 0..1) {
                    val l = if (side == 0) 0f else W - cw; val r = if (side == 0) cw else W
                    fill.shader = LinearGradient(l, 0f, l + 40 * s, 0f, intArrayOf(0xFF7F0000.toInt(), 0xFFC62828.toInt(), 0xFF7F0000.toInt()), null, Shader.TileMode.MIRROR)
                    c.drawRect(l, 0f, r, H, fill); fill.shader = null
                }
                fill.color = 0xFF5D0000.toInt(); c.drawRect(0f, 0f, W, H * 0.08f, fill)
                fill.shader = LinearGradient(0f, H * 0.06f, 0f, H * 0.1f, 0xFFD4AF37.toInt(), 0x00D4AF37, Shader.TileMode.CLAMP); c.drawRect(0f, H * 0.06f, W, H * 0.1f, fill); fill.shader = null
            }
            "I_GOLD", "O_GOLD" -> {
                fill.shader = RadialGradient(W / 2, H / 2, max(W, H) * 0.7f, 0xFF3E2C10.toInt(), 0xFF080604.toInt(), Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, fill); fill.shader = null
                particles(c, "SPARKLES", sec, 1f, 7)
                val gold = LinearGradient(0f, ty - tsz, W, ty, intArrayOf(0xFF8C6D1F.toInt(), 0xFFF9E79F.toInt(), 0xFFD4AF37.toInt(), 0xFFF9E79F.toInt(), 0xFF8C6D1F.toInt()), null, Shader.TileMode.CLAMP)
                val sc2 = 0.85f + 0.15f * easeOutCubic(p / 0.4f)
                c.save(); c.scale(sc2, sc2, W / 2, ty)
                title(c, clip.title, W / 2, ty, tsz, Color.WHITE, cl(p / 0.3f), serif = true, shader = gold)
                c.restore()
                // لمعة تعبر النص
                val sx = -W * 0.3f + W * 1.6f * cl((p - 0.3f) / 0.4f)
                fill.shader = LinearGradient(sx - 60 * s, 0f, sx + 60 * s, 0f, intArrayOf(0x00FFFFFF, 0x88FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
                c.save(); c.clipRect(0f, ty - tsz, W, ty + tsz * 0.3f); c.drawRect(0f, 0f, W, H, fill); c.restore(); fill.shader = null
                stroke.color = 0xFFD4AF37.toInt(); stroke.strokeWidth = 2 * s; val lw = W * 0.3f * easeOutCubic((p - 0.2f) / 0.4f)
                c.drawLine(W / 2 - lw, ty + tsz * 0.35f, W / 2 + lw, ty + tsz * 0.35f, stroke)
                title(c, clip.sub, W / 2, sy + ssz * 0.4f, ssz, 0xFFF9E79F.toInt(), cl((p - 0.45f) / 0.2f))
            }
            "I_NEON" -> {
                gradBg(c, 0xFF12002B.toInt(), 0xFF000000.toInt())
                stroke.color = 0x3300E5FF; stroke.strokeWidth = 1.5f * s
                for (k in 0..12) { val y = H * 0.6f + k * k * H * 0.004f; c.drawLine(0f, y, W, y, stroke) }
                for (k in -10..10) c.drawLine(W / 2 + k * W * 0.02f, H * 0.6f, W / 2 + k * W * 0.12f, H, stroke)
                val on = if (p < 0.35f) (if (rnd((local / 60).toInt(), 3) > 0.45f) 1f else 0.15f) else 1f
                title(c, clip.title, W / 2, ty, tsz, 0xFFFF4FD8.toInt(), on, glow = 0xFFFF00C8.toInt())
                title(c, clip.sub, W / 2, sy, ssz, 0xFF00E5FF.toInt(), cl((p - 0.4f) / 0.2f), glow = 0xFF00E5FF.toInt())
            }
            "I_COUNT" -> {
                gradBg(c, 0xFF5D4E37.toInt(), 0xFF2B2318.toInt())
                val cd = 0.6f
                if (p < cd) {
                    val k = (p / cd * 3).toInt().coerceIn(0, 2); val f = (p / cd * 3) % 1f
                    stroke.color = 0xFFEFE6D2.toInt(); stroke.strokeWidth = 3 * s
                    val r = H * 0.32f; c.drawCircle(W / 2, H / 2, r, stroke); c.drawCircle(W / 2, H / 2, r * 0.85f, stroke)
                    c.drawLine(0f, H / 2, W, H / 2, stroke); c.drawLine(W / 2, 0f, W / 2, H, stroke)
                    fill.color = 0x55000000; c.drawArc(W / 2 - r, H / 2 - r, W / 2 + r, H / 2 + r, -90f, 360f * f, true, fill)
                    title(c, (3 - k).toString(), W / 2, H / 2 + H * 0.09f, H * 0.28f, 0xFFEFE6D2.toInt())
                } else {
                    val q = (p - cd) / (1 - cd)
                    title(c, clip.title, W / 2, ty, tsz, col, cl(q / 0.3f), serif = true)
                    title(c, clip.sub, W / 2, sy, ssz, 0xFFEFE6D2.toInt(), cl((q - 0.3f) / 0.3f))
                }
                frame(c, "VINTAGE", sec, 1f)
            }
            "I_STARS" -> {
                gradBg(c, 0xFF0B1033.toInt(), 0xFF1B2A5C.toInt())
                particles(c, "STARS", sec, 1f, 3)
                emoji(c, "🌙", W * 0.82f, H * 0.2f, H * 0.18f, (255 * cl(p / 0.3f)).toInt())
                title(c, clip.title, W / 2, ty + (1 - easeOutCubic(p / 0.4f)) * H * 0.05f, tsz, col, cl(p / 0.35f), glow = 0x88FFF59D.toInt(), serif = true)
                title(c, clip.sub, W / 2, sy, ssz, 0xFFFFF59D.toInt(), cl((p - 0.35f) / 0.25f))
            }
            "I_HEARTS", "O_HEARTS" -> {
                gradBg(c, 0xFFFF8FB1.toInt(), 0xFFAD1457.toInt())
                particles(c, "HEARTS", sec, 1f, 11)
                val pulse = 1f + 0.04f * sin(local / 250f)
                c.save(); c.scale(pulse, pulse, W / 2, ty)
                title(c, clip.title, W / 2, ty, tsz, col, cl(p / 0.3f), glow = 0xAAFFFFFF.toInt(), serif = true)
                c.restore()
                title(c, clip.sub, W / 2, sy, ssz, Color.WHITE, cl((p - 0.35f) / 0.2f))
            }
            "I_PARTY" -> {
                gradBg(c, 0xFF4A148C.toInt(), 0xFF880E4F.toInt())
                particles(c, "CONFETTI", sec, 1f, 5); particles(c, "BALLOONS", sec, 1f, 9)
                val sc2 = easeOutBack(p / 0.35f).coerceAtLeast(0.01f)
                c.save(); c.scale(sc2, sc2, W / 2, ty); c.rotate(sin(local / 300f) * 2f, W / 2, ty)
                title(c, clip.title, W / 2, ty, tsz, col, 1f, glow = 0x99000000.toInt()); c.restore()
                title(c, clip.sub, W / 2, sy, ssz, Color.WHITE, cl((p - 0.35f) / 0.2f))
            }
            "I_MINIMAL", "O_MINIMAL" -> {
                c.drawColor(0xFFF7F5F0.toInt())
                val lw = W * 0.32f * easeOutCubic(p / 0.35f)
                stroke.color = 0xFF222222.toInt(); stroke.strokeWidth = 3 * s; c.drawLine(W / 2 - lw, H * 0.55f, W / 2 + lw, H * 0.55f, stroke)
                c.save(); c.clipRect(0f, 0f, W, H * 0.55f)
                title(c, clip.title, W / 2, H * 0.5f + (1 - easeOutCubic((p - 0.2f) / 0.3f)) * tsz * 1.2f, tsz * 0.85f, if (col == Color.WHITE) 0xFF222222.toInt() else col)
                c.restore()
                c.save(); c.clipRect(0f, H * 0.55f, W, H)
                title(c, clip.sub, W / 2, H * 0.55f + ssz * 1.3f - (1 - easeOutCubic((p - 0.35f) / 0.3f)) * ssz * 1.6f, ssz, 0xFF666666.toInt())
                c.restore()
            }
            "I_SPLASH" -> {
                c.drawColor(0xFF111111.toInt())
                val cols = intArrayOf(0xFFFFC107.toInt(), 0xFFE91E63.toInt(), 0xFF3F51B5.toInt(), 0xFF00BCD4.toInt())
                for (k in cols.indices) { val q = easeOutCubic((p - k * 0.09f) / 0.35f); if (q > 0) { fill.color = cols[k]; c.drawCircle(W / 2, H / 2, hypot(W, H) * 0.6f * q, fill) } }
                val sc2 = easeOutBack((p - 0.4f) / 0.25f).coerceAtLeast(0.01f)
                c.save(); c.scale(sc2, sc2, W / 2, ty); title(c, clip.title, W / 2, ty, tsz, col, 1f, glow = 0x66000000); c.restore()
                title(c, clip.sub, W / 2, sy, ssz, Color.WHITE, cl((p - 0.6f) / 0.2f))
            }
            "I_BOOK" -> {
                c.drawColor(0xFF5D4037.toInt())
                val page = RectF(W * 0.12f, H * 0.12f, W * 0.88f, H * 0.88f)
                fill.color = 0xFFF5EBDD.toInt(); fill.setShadowLayer(20 * s, 0f, 8 * s, 0x88000000.toInt()); c.drawRect(page, fill); fill.clearShadowLayer()
                stroke.color = 0x33000000; stroke.strokeWidth = 2 * s; c.drawLine(W / 2, page.top, W / 2, page.bottom, stroke)
                // غلاف يُفتح
                val open = easeInOut(cl(p / 0.45f))
                if (open < 1f) { c.save(); c.scale(1 - open, 1f, page.right, H / 2); fill.color = 0xFF8D6E63.toInt(); c.drawRect(W / 2, page.top, page.right, page.bottom, fill); c.restore() }
                title(c, clip.title, W / 2, ty, tsz * 0.8f, if (col == Color.WHITE) 0xFF4E342E.toInt() else col, cl((p - 0.4f) / 0.2f), serif = true)
                title(c, clip.sub, W / 2, sy, ssz, 0xFF795548.toInt(), cl((p - 0.55f) / 0.2f))
            }
            "O_THANKS" -> {
                gradBg(c, 0xFF1A237E.toInt(), 0xFF000000.toInt())
                particles(c, "SPARKLES", sec, 1f, 13)
                title(c, clip.title, W / 2, ty, tsz, col, cl(p / 0.3f), glow = 0x8840C4FF.toInt())
                title(c, clip.sub, W / 2, sy, ssz, 0xFFB3E5FC.toInt(), cl((p - 0.3f) / 0.2f))
                fill.color = Color.BLACK; fill.alpha = (255 * cl((p - 0.85f) / 0.15f)).toInt(); c.drawRect(0f, 0f, W, H, fill); fill.alpha = 255
            }
            "O_SUBSCRIBE" -> {
                gradBg(c, 0xFF212121.toInt(), 0xFF000000.toInt())
                title(c, clip.title, W / 2, H * 0.32f, tsz * 0.8f, col, cl(p / 0.25f))
                val pressed = p in 0.45f..0.55f
                val bw = W * 0.34f; val bh = H * 0.13f; val by = H * 0.5f
                val subscribed = p > 0.5f
                fill.color = if (subscribed) 0xFF757575.toInt() else 0xFFE53935.toInt()
                val sc2 = if (pressed) 0.92f else easeOutBack(p / 0.3f).coerceAtLeast(0.01f)
                c.save(); c.scale(sc2, sc2, W / 2, by)
                c.drawRoundRect(W / 2 - bw / 2, by - bh / 2, W / 2 + bw / 2, by + bh / 2, bh * 0.2f, bh * 0.2f, fill)
                title(c, if (subscribed) tr("✓ مشترك", "✓ Subscribed") else tr("اشترك", "SUBSCRIBE"), W / 2, by + bh * 0.18f, bh * 0.45f, Color.WHITE)
                c.restore()
                c.save(); c.rotate(if (p > 0.6f) sin(local / 60f) * 18f * (1 - cl((p - 0.6f) / 0.3f)) else 0f, W / 2 + bw * 0.75f, by - bh * 0.4f)
                emoji(c, "🔔", W / 2 + bw * 0.75f, by, bh * 0.9f, (255 * cl((p - 0.3f) / 0.2f)).toInt()); c.restore()
                if (p in 0.42f..0.6f) emoji(c, "👆", W / 2 + bw * 0.1f, by + bh * 0.8f, bh * 0.8f)
                title(c, clip.sub, W / 2, H * 0.75f, ssz, 0xFFBDBDBD.toInt(), cl((p - 0.6f) / 0.2f))
            }
            "O_END" -> {
                gradBg(c, 0xFF3E2F1C.toInt(), 0xFF1A140C.toInt())
                title(c, clip.title, W / 2, ty, tsz * 1.2f, 0xFFEFE6D2.toInt(), cl(p / 0.3f), serif = true)
                title(c, clip.sub, W / 2, sy + ssz * 0.6f, ssz, 0xFFBCAAA4.toInt(), cl((p - 0.3f) / 0.2f))
                frame(c, "VINTAGE", sec, 1f)
                // إغلاق دائري
                val q = cl((p - 0.7f) / 0.3f)
                if (q > 0) { val path = Path().apply { fillType = Path.FillType.EVEN_ODD; addRect(0f, 0f, W, H, Path.Direction.CW); addCircle(W / 2, H / 2, hypot(W, H) / 2 * (1 - q), Path.Direction.CW) }; fill.color = Color.BLACK; c.drawPath(path, fill) }
            }
            "O_LOGO" -> {
                c.drawColor(0xFF0D0D0D.toInt())
                val lg = proj.overlays.firstOrNull { it.kind == "LOGO" }?.let { logo(it.uri) }
                val sc2 = easeOutBack(p / 0.4f).coerceAtLeast(0.01f)
                fill.shader = RadialGradient(W / 2, H * 0.45f, H * 0.45f, intArrayOf(0x55FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP); c.drawCircle(W / 2, H * 0.45f, H * 0.45f, fill); fill.shader = null
                if (lg != null) {
                    val lh = H * 0.38f * sc2; val lw = lh * lg.width / lg.height
                    c.drawBitmap(lg, null, RectF(W / 2 - lw / 2, H * 0.45f - lh / 2, W / 2 + lw / 2, H * 0.45f + lh / 2), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
                } else title(c, clip.title.ifBlank { "LOGO" }, W / 2, H * 0.5f, tsz * sc2, col)
                title(c, clip.title.takeIf { lg != null } ?: clip.sub, W / 2, H * 0.82f, ssz, 0xFFE0E0E0.toInt(), cl((p - 0.4f) / 0.2f))
            }
            "O_FIRE" -> {
                gradBg(c, 0xFF000814.toInt(), 0xFF001D3D.toInt())
                particles(c, "FIREWORKS", sec, 1f, 17)
                title(c, clip.title, W / 2, H * 0.78f, tsz, col, cl(p / 0.3f), glow = 0x88FFD54F.toInt())
                title(c, clip.sub, W / 2, H * 0.88f, ssz, Color.WHITE, cl((p - 0.3f) / 0.2f))
            }
            else -> { c.drawColor(Color.BLACK); title(c, clip.title, W / 2, ty, tsz, col) }
        }
    }

    /** بطاقة صورة بإطار أبيض وظل (بولارويد) وتعيد مستطيلها */
    private fun card(c: Canvas, pr: Prep, cx: Float, cy: Float, maxW: Float, maxH: Float, rot: Float, scale: Float, caption: String, drawNow: Boolean = true): RectF {
        val inner = fitRect(pr.photo.width, pr.photo.height, maxW * 0.9f, maxH * (if (caption.isNotBlank()) 0.8f else 0.88f), 0f, 0f)
        val pad = min(inner.width(), inner.height()) * 0.045f + 4 * s
        val bottom = if (caption.isNotBlank()) inner.height() * 0.16f + pad else pad * 2.2f
        val cw = inner.width() + pad * 2; val chh = inner.height() + pad + bottom
        val rect = RectF(cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2)
        if (!drawNow) return rect
        c.save(); c.rotate(rot, cx, cy); c.scale(scale, scale, cx, cy)
        fill.color = Color.WHITE; fill.setShadowLayer(18 * s, 0f, 8 * s, 0x77000000)
        c.drawRect(rect, fill); fill.clearShadowLayer()
        val ir = RectF(rect.left + pad, rect.top + pad, rect.right - pad, rect.top + pad + inner.height())
        c.drawBitmap(pr.photo, null, ir, photoPaint())
        if (caption.isNotBlank()) {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt(); textAlign = Paint.Align.CENTER; textSize = bottom * 0.5f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC) }
            c.drawText(caption, rect.centerX(), ir.bottom + (rect.bottom - ir.bottom) / 2 + tp.textSize * 0.35f, tp)
        }
        c.restore()
        return rect
    }

    private fun balloon(c: Canvas, x: Float, y: Float, r: Float, color: Int, sx: Float, sy: Float) {
        stroke.color = 0xAAFFFFFF.toInt(); stroke.strokeWidth = 1.8f * s
        c.drawPath(Path().apply { moveTo(x, y + r * 1.25f); quadTo(x + (sx - x) * 0.3f + 8 * s, (y + sy) / 2, sx, sy) }, stroke)
        fill.shader = RadialGradient(x - r * 0.35f, y - r * 0.45f, r * 1.6f, intArrayOf(Color.WHITE, color, darker(color)), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        c.drawOval(x - r, y - r * 1.2f, x + r, y + r * 1.2f, fill); fill.shader = null
        fill.color = darker(color); c.drawPath(Path().apply { moveTo(x, y + r * 1.15f); lineTo(x - r * 0.15f, y + r * 1.35f); lineTo(x + r * 0.15f, y + r * 1.35f); close() }, fill)
    }
    private fun darker(c: Int) = Color.argb(Color.alpha(c), (Color.red(c) * 0.6f).toInt(), (Color.green(c) * 0.6f).toInt(), (Color.blue(c) * 0.6f).toInt())

    // ---------------- الطبقات ----------------
    private val order = mapOf("FX" to 0, "FRAME" to 1, "STICKER" to 2, "TEXT" to 3, "LOGO" to 4)
    private fun drawOverlays(c: Canvas, t: Long) {
        // الطبقات تُرسم بترتيبها في القائمة (الأخيرة في الأعلى)، والإطار دائماً فوق الصور
        for (o in proj.overlays) {
            if (t < o.startMs || t >= o.startMs + o.durMs) continue
            val lt = t - o.startMs
            val fadeMs = if (o.kind == "FX" || o.kind == "FRAME") 400f else 250f
            val a = if (o.anim == "NONE" && o.kind != "FX") 1f else min(1f, min(lt / fadeMs, (o.durMs - lt) / fadeMs)).coerceIn(0f, 1f)
            runCatching {
                when (o.kind) {
                    "TEXT" -> text(c, o, lt, a)
                    "LOGO" -> logo(o.uri)?.let { b ->
                        val lw = o.size * w * 2f; val lh = lw * b.height / b.width
                        val r = RectF(o.x * w - lw / 2, o.y * h - lh / 2, o.x * w + lw / 2, o.y * h + lh / 2)
                        bmpPaint.alpha = (255 * a * o.opacity).toInt(); val cf = bmpPaint.colorFilter; bmpPaint.colorFilter = null
                        c.save(); c.rotate(o.rot, r.centerX(), r.centerY())
                        c.drawBitmap(b, null, r, bmpPaint); c.restore(); bmpPaint.alpha = 255; bmpPaint.colorFilter = cf
                        bounds[o.id] = rotated(r, o.rot, r.centerX(), r.centerY())
                    }
                    "STICKER" -> sticker(c, o, lt, a)
                    "IMAGE" -> imageLayer(c, o, lt, a)
                    "FX" -> {
                        fxScale = (o.size / 0.09f).coerceIn(0.3f, 4f)
                        c.save(); if (o.key.startsWith("C_")) c.translate((o.x - 0.5f) * w, (o.y - 0.5f) * h)
                        particles(c, o.key, lt / 1000f, a * o.opacity, o.id.hashCode())
                        c.restore(); fxScale = 1f
                    }
                    "FRAME" -> frame(c, o.key, lt / 1000f, a)
                    else -> {}
                }
            }
        }
    }

    private fun rotated(r: RectF, deg: Float, px: Float, py: Float): RectF {
        if (deg == 0f) return r
        val out = RectF(r); Matrix().apply { setRotate(deg, px, py) }.mapRect(out); return out
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val outPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private fun text(c: Canvas, o: VOverlay, lt: Long, a: Float) {
        val size = o.size * h
        textPaint.textSize = size; outPaint.textSize = size; outPaint.strokeWidth = size * 0.14f
        val dark = Color.red(o.color) + Color.green(o.color) + Color.blue(o.color) < 200
        outPaint.color = if (dark) 0xDDFFFFFF.toInt() else 0xDD000000.toInt()
        var lines = if (o.vert) o.text.replace("\n", " ").map { if (it == ' ') "" else it.toString() } else o.text.split("\n")
        if (o.anim == "TYPE") {
            var n = (lt / 70).toInt(); lines = lines.map { l -> val k = n.coerceIn(0, l.length); n -= l.length; l.substring(0, k) }
        }
        val lh = size * (if (o.vert) 1.05f else 1.22f)
        val cx = o.x * w; var cy = o.y * h - (lines.size - 1) * lh / 2
        var sc = 1f; var dy = 0f; var rot = o.rot
        when (o.anim) {
            "POP" -> sc = easeOutBack(lt / 450f).coerceAtLeast(0.01f)
            "SLIDE" -> dy = (1 - easeOutCubic(lt / 550f)) * h * 0.2f
            "WAVE" -> { rot += sin(lt / 400f) * 3f; dy = sin(lt / 300f) * size * 0.12f }
        }
        val maxW = lines.maxOfOrNull { textPaint.measureText(it) } ?: 0f
        val full = RectF(cx - maxW / 2 - size * 0.3f, cy - size * 1.0f, cx + maxW / 2 + size * 0.3f, cy + (lines.size - 1) * lh + size * 0.4f)
        bounds[o.id] = rotated(RectF(full).apply { offset(0f, dy) }, o.rot, cx, o.y * h)
        c.save(); c.translate(0f, dy); c.rotate(rot, cx, o.y * h); c.scale(sc, sc, cx, o.y * h)
        val alpha = (255 * a * o.opacity).toInt()
        if (o.bg) { fill.color = 0x88000000.toInt(); fill.alpha = (0x88 * a).toInt(); c.drawRoundRect(full, size * 0.3f, size * 0.3f, fill); fill.alpha = 255 }
        if (o.anim == "GLOW") textPaint.setShadowLayer(size * (0.25f + 0.15f * sin(lt / 250f)), 0f, 0f, o.color) else textPaint.setShadowLayer(size * 0.08f, 0f, size * 0.04f, 0x66000000)
        val outA = Color.alpha(outPaint.color)
        for (l in lines) {
            outPaint.alpha = (outA * a).toInt()
            if (!o.bg) c.drawText(l, cx, cy, outPaint)
            textPaint.color = o.color; textPaint.alpha = alpha
            c.drawText(l, cx, cy, textPaint)
            cy += lh
        }
        textPaint.clearShadowLayer()
        c.restore()
    }

    // ---------------- طبقة صورة / GIF فوق الفيديو ----------------
    private fun layerBitmap(o: VOverlay): Bitmap? {
        val key = "layer|${o.uri}|${o.has("CUT")}"
        synchronized(cache) { (cache[key] as? Bitmap)?.let { return it } }
        val b0 = decode(ctx, o.uri, 900) ?: return null
        val b = if (o.has("CUT")) (runCatching { VEnhance.cutout(b0) }.getOrNull() ?: b0) else b0
        synchronized(cache) { cache[key] = b }
        return b
    }
    @Suppress("DEPRECATION")
    private fun gif(path: String): android.graphics.Movie? {
        val key = "gif|$path"
        synchronized(cache) { (cache[key] as? android.graphics.Movie)?.let { return it } }
        val mv = runCatching { val bytes = openStream(ctx, path)!!.use { it.readBytes() }; android.graphics.Movie.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
        if (mv != null) synchronized(cache) { cache[key] = mv }
        return mv
    }

    private fun imageLayer(c: Canvas, o: VOverlay, lt: Long, a: Float) {
        val isGif = o.uri.lowercase().endsWith(".gif")
        @Suppress("DEPRECATION") val mv = if (isGif) gif(o.uri) else null
        val bmp = if (mv == null) layerBitmap(o) ?: return else null
        val iw = mv?.width() ?: bmp!!.width; val ih = mv?.height() ?: bmp!!.height
        if (iw <= 0 || ih <= 0) return
        val lw = o.size * w * 4f; val lh = lw * ih / iw
        val cx = o.x * w; val cy = o.y * h
        val dur = o.durMs.coerceAtLeast(1)
        val e = cl(lt / 600f); val out = cl((dur - lt) / 400f)
        val ent = min(e, out)
        c.save()
        c.rotate(o.rot, cx, cy)
        var alpha = a * o.opacity
        when (o.anim) {
            "ZOOM" -> (0.2f + 0.8f * easeOutBack(ent)).coerceAtLeast(0.01f).let { c.scale(it, it, cx, cy) }
            "BOUNCE" -> c.translate(0f, -(1 - easeOutBounce(ent)) * h * 0.6f)
            "SLIDE_L" -> c.translate((1 - easeOutCubic(ent)) * w, 0f)
            "SLIDE_R" -> c.translate(-(1 - easeOutCubic(ent)) * w, 0f)
            "SLIDE_UP" -> c.translate(0f, (1 - easeOutCubic(ent)) * h)
            "SPIN" -> { c.rotate((1 - easeOutCubic(ent)) * -360f, cx, cy); (0.3f + 0.7f * ent).let { c.scale(it, it, cx, cy) } }
            "FLIP3D" -> cam3d(c, 0f, (1 - easeOutCubic(ent)) * 90f, 0f, cx, cy)
            "FLOAT" -> c.translate(0f, sin(lt / 600f) * h * 0.015f)
            "NONE" -> alpha = o.opacity
        }
        val r = RectF(cx - lw / 2, cy - lh / 2, cx + lw / 2, cy + lh / 2)
        val shape = o.key.ifBlank { "ROUND" }
        val l = c.saveLayerAlpha(r.left - 40 * s, r.top - 40 * s, r.right + 40 * s, r.bottom + 120 * s, (255 * alpha.coerceIn(0f, 1f)).toInt())
        if (shape == "POLAROID") {
            fill.color = Color.WHITE; fill.setShadowLayer(16 * s, 0f, 6 * s, 0x66000000)
            c.drawRect(r.left - lw * 0.05f, r.top - lw * 0.05f, r.right + lw * 0.05f, r.bottom + lh * 0.2f, fill); fill.clearShadowLayer()
        } else if (o.has("SHADOW") && !o.has("CUT")) {
            fill.color = Color.BLACK; fill.alpha = 90; fill.setShadowLayer(18 * s, 0f, 8 * s, 0x88000000.toInt())
            c.drawRoundRect(r, 12 * s, 12 * s, fill); fill.clearShadowLayer(); fill.alpha = 255
        }
        val path = Path()
        when (shape) {
            "ROUND" -> path.addRoundRect(r, min(lw, lh) * 0.08f, min(lw, lh) * 0.08f, Path.Direction.CW)
            "CIRCLE" -> path.addCircle(cx, cy, min(lw, lh) / 2, Path.Direction.CW)
            "HEART" -> heartPath(path, cx, cy, min(lw, lh) * 1.05f)
            "STAR" -> starPath(path, cx, cy, min(lw, lh) * 0.62f, 5, 0.5f)
            else -> path.addRect(r, Path.Direction.CW)
        }
        c.save()
        if (!o.has("CUT") || shape != "RECT") c.clipPath(path)
        if (mv != null) {
            @Suppress("DEPRECATION")
            run {
                val md = mv.duration().takeIf { it > 0 } ?: 1000
                mv.setTime((lt % md).toInt())
                c.save(); c.translate(r.left, r.top); c.scale(lw / iw, lh / ih); mv.draw(c, 0f, 0f); c.restore()
            }
        } else {
            val src = if (shape in setOf("CIRCLE", "HEART", "STAR")) {
                val side = min(bmp!!.width, bmp.height); Rect((bmp.width - side) / 2, (bmp.height - side) / 2, (bmp.width + side) / 2, (bmp.height + side) / 2)
            } else null
            val dst = if (src != null) { val d = min(lw, lh); RectF(cx - d / 2, cy - d / 2, cx + d / 2, cy + d / 2) } else r
            bmpPaint.colorFilter = null; bmpPaint.alpha = 255
            c.drawBitmap(bmp!!, src, dst, bmpPaint)
            lastFilter = "?"
        }
        c.restore()
        if (o.has("BORDER")) { stroke.color = Color.WHITE; stroke.strokeWidth = 5 * s; c.drawPath(path, stroke) }
        c.restoreToCount(l)
        c.restore()
        bounds[o.id] = rotated(RectF(r), o.rot, cx, cy)
    }

    private fun sticker(c: Canvas, o: VOverlay, lt: Long, a: Float) {
        val size = o.size * h * 1.4f
        val x = o.x * w; var y = o.y * h
        c.save(); c.rotate(o.rot, x, y)
        when (o.anim) {
            "FLOAT" -> y += sin(lt / 500f) * size * 0.12f
            "PULSE" -> (1f + 0.12f * sin(lt / 220f)).let { c.scale(it, it, x, y) }
            "SPIN" -> c.rotate(lt / 8f, x, y)
            "BOUNCE" -> y -= abs(sin(lt / 300f)) * size * 0.35f
            "SWING" -> c.rotate(sin(lt / 400f) * 14f, x, y - size / 2)
            "SHAKE" -> c.rotate(sin(lt / 45f) * 9f * (if ((lt / 900) % 2 == 0L) 1f else 0.15f), x, y)
            "JELLY" -> { val k = sin(lt / 160f) * 0.12f; c.scale(1 + k, 1 - k, x, y + size / 2) }
            "HEARTBEAT" -> { val ph = (lt % 1000) / 1000f; val k = if (ph < 0.12f) 1 + ph * 2 else if (ph < 0.24f) 1.24f - (ph - 0.12f) * 2 else if (ph < 0.36f) 1 + (ph - 0.24f) * 1.5f else max(1f, 1.18f - (ph - 0.36f) * 0.6f); c.scale(k, k, x, y) }
            "POP" -> easeOutBack(lt / 450f).coerceAtLeast(0.01f).let { c.scale(it, it, x, y) }
            "BURST" -> {
                val ph = (lt % 2200) / 2200f
                if (ph < 0.6f) for (k in 0 until 26) {
                    val ang = 2 * PI.toFloat() * k / 26 + rnd(k, 1); val d = size * (0.4f + 2.2f * ph) * (0.6f + 0.4f * rnd(k, 2))
                    fill.color = palette[k % palette.size]; fill.alpha = (255 * a * (1 - ph / 0.6f)).toInt()
                    c.drawRect(x + cos(ang) * d - 4 * s, y + sin(ang) * d - 4 * s + ph * ph * size, x + cos(ang) * d + 4 * s, y + sin(ang) * d + 4 * s + ph * ph * size, fill)
                }
                fill.alpha = 255
                val k = if (ph < 0.1f) 1f + ph * 3 else 1.3f - min(0.3f, (ph - 0.1f)); c.scale(k, k, x, y)
            }
        }
        emoji(c, o.key.ifBlank { "⭐" }, x, y, size, (255 * a * o.opacity).toInt())
        c.restore()
        bounds[o.id] = RectF(x - size / 2, o.y * h - size / 2, x + size / 2, o.y * h + size / 2)
    }

    // ---------------- المؤثرات المتحركة ----------------
    private val palette = intArrayOf(0xFFE53935.toInt(), 0xFFFFB300.toInt(), 0xFF43A047.toInt(), 0xFF1E88E5.toInt(), 0xFF8E24AA.toInt(), 0xFFFF4081.toInt(), 0xFF00BCD4.toInt(), 0xFFFFEB3B.toInt())
    private fun particles(c: Canvas, key: String, sec: Float, a: Float, seed: Int) {
        val W = w.toFloat(); val H = h.toFloat()
        @Suppress("NAME_SHADOWING") val s = this.s * fxScale
        val sd = (seed and 0xff)
        fun al(v: Float) = (255 * v * a).toInt().coerceIn(0, 255)
        when (key) {
            "SNOW" -> { fill.color = Color.WHITE
                for (i in 0 until 110) { val sp = (0.05f + 0.1f * rnd(i, sd)) * H; val y = ((rnd(i, 3) * (H + 20) + sp * sec) % (H + 20)) - 10
                    val x = rnd(i, 1) * W + sin(sec * 0.8f + i) * 18 * s; fill.alpha = al(0.6f + 0.4f * rnd(i, 5)); c.drawCircle(x, y, (1.5f + 3.5f * rnd(i, 4)) * s, fill) } }
            "RAIN" -> { stroke.color = 0xCCB3E5FC.toInt(); stroke.strokeWidth = 1.6f * s
                for (i in 0 until 130) { val sp = (1.1f + 0.6f * rnd(i, 2)) * H; val y = ((rnd(i, 3) * (H + 60) + sp * sec) % (H + 60)) - 30; val x = rnd(i, 1) * W * 1.1f - W * 0.05f + y * 0.12f
                    stroke.alpha = al(0.5f + 0.4f * rnd(i, 6)); c.drawLine(x, y, x - 5 * s, y - 26 * s, stroke) }
                fill.color = 0x22000000; fill.alpha = al(0.13f); c.drawRect(0f, 0f, W, H, fill); fill.alpha = 255 }
            "CONFETTI" -> for (i in 0 until 90) {
                val sp = (0.14f + 0.18f * rnd(i, 2)) * H; val y = ((rnd(i, 3) * (H + 30) + sp * sec) % (H + 30)) - 15; val x = rnd(i, 1) * W + sin(sec * 2 + i) * 14 * s
                fill.color = palette[i % palette.size]; fill.alpha = al(1f)
                c.save(); c.rotate(sec * 180 * (rnd(i, 7) - 0.5f) * 2 + i * 30, x, y); c.scale(cos(sec * 4 + i), 1f, x, y); c.drawRect(x - 4 * s, y - 7 * s, x + 4 * s, y + 7 * s, fill); c.restore() }
            "HEARTS" -> for (i in 0 until 20) {
                val sp = (0.08f + 0.1f * rnd(i, 2)) * H; val y = H + 30 * s - ((rnd(i, 3) * (H + 60) + sp * sec) % (H + 60)); val x = rnd(i, 1) * W + sin(sec * 1.5f + i) * 24 * s
                val sz = (16 + 22 * rnd(i, 4)) * s; fill.color = if (i % 3 == 0) 0xFFE91E63.toInt() else if (i % 3 == 1) 0xFFFF5252.toInt() else 0xFFFF80AB.toInt()
                fill.alpha = al(cl(y / H) * 0.9f + 0.1f); c.drawPath(Path().also { heartPath(it, x, y, sz) }, fill) }
            "BALLOONS" -> for (i in 0 until 9) {
                val sp = (0.06f + 0.06f * rnd(i, 2)) * H; val y = H + 80 * s - ((rnd(i, 3) * (H + 160 * s) + sp * sec) % (H + 160 * s)); val x = rnd(i, 1) * W + sin(sec + i) * 20 * s
                val r = (18 + 12 * rnd(i, 4)) * s
                val l = c.saveLayerAlpha(x - r * 2, y - r * 2, x + r * 2, y + r * 4, al(0.95f)); balloon(c, x, y, r, palette[i % 5], x + 6 * s, y + r * 3.2f); c.restoreToCount(l) }
            "FIREWORKS" -> {
                val period = 0.75f; val life = 1.9f
                val cur = floor(sec / period).toInt()
                for (b in (cur - 3)..cur) {
                    if (b < 0) continue
                    val age = sec - b * period; if (age < 0 || age > life) continue
                    val bx = (0.12f + 0.76f * rnd(b, 11 + sd)) * W; val by = (0.12f + 0.4f * rnd(b, 12 + sd)) * H
                    val col = palette[(b * 3 + sd) % palette.size]; val n = 40
                    val alpha = 1f - age / life
                    for (j in 0 until n) {
                        val ang = 2 * PI.toFloat() * j / n + rnd(b, j) * 0.2f; val spd = (0.2f + 0.08f * rnd(j, b)) * H
                        val d = spd * age * (1 - age / (life * 2)); val gy = 0.09f * H * age * age
                        val x = bx + cos(ang) * d; val y = by + sin(ang) * d + gy
                        fill.color = if (j % 4 == 0) Color.WHITE else col; fill.alpha = al(alpha)
                        c.drawCircle(x, y, 2.6f * s * (1 - age / life * 0.5f), fill)
                        stroke.color = col; stroke.strokeWidth = 1.3f * s; stroke.alpha = al(alpha * 0.5f)
                        c.drawLine(x, y, bx + cos(ang) * d * 0.82f, by + sin(ang) * d * 0.82f + gy * 0.8f, stroke)
                    }
                    if (age < 0.15f) { fill.color = Color.WHITE; fill.alpha = al(1 - age / 0.15f); c.drawCircle(bx, by, 14 * s, fill) }
                }
                fill.alpha = 255
            }
            "STARS" -> for (i in 0 until 45) {
                val x = rnd(i, 1) * W; val y = rnd(i, 2) * H * 0.75f; val tw = 0.25f + 0.75f * abs(sin(sec * (1.2f + rnd(i, 3) * 2) + i))
                fill.color = if (i % 4 == 0) 0xFFFFF59D.toInt() else Color.WHITE; fill.alpha = al(tw)
                c.drawPath(Path().also { starPath(it, x, y, (4 + 7 * rnd(i, 4)) * s * (0.7f + 0.3f * tw), 4, 0.35f) }, fill) }
            "BUBBLES" -> for (i in 0 until 26) {
                val sp = (0.07f + 0.09f * rnd(i, 2)) * H; val y = H + 30 * s - ((rnd(i, 3) * (H + 60 * s) + sp * sec) % (H + 60 * s)); val x = rnd(i, 1) * W + sin(sec * 1.3f + i) * 22 * s
                val r = (8 + 22 * rnd(i, 4)) * s
                stroke.color = Color.WHITE; stroke.strokeWidth = 1.8f * s; stroke.alpha = al(0.75f); c.drawCircle(x, y, r, stroke)
                fill.color = Color.WHITE; fill.alpha = al(0.5f); c.drawCircle(x - r * 0.35f, y - r * 0.35f, r * 0.2f, fill) }
            "PETALS", "LEAVES" -> for (i in 0 until 24) {
                val sp = (0.06f + 0.08f * rnd(i, 2)) * H; val y = ((rnd(i, 3) * (H + 40) + sp * sec) % (H + 40)) - 20; val x = rnd(i, 1) * W + sin(sec + i) * 40 * s
                val e = if (key == "PETALS") (if (i % 3 == 0) "🌸" else "🌺") else (if (i % 2 == 0) "🍂" else "🍁")
                c.save(); c.rotate(sec * 60 + i * 40, x, y); emoji(c, e, x, y, (18 + 14 * rnd(i, 4)) * s, al(0.95f)); c.restore() }
            "SPARKLES" -> for (i in 0 until 34) {
                val ph = (sec * (0.6f + rnd(i, 3)) + rnd(i, 4)) % 1f; val k = sin(ph * PI.toFloat())
                val x = rnd(i + (sec * 0.6f + rnd(i, 4)).toInt() * 7, 1) * W; val y = rnd(i + (sec * 0.6f + rnd(i, 4)).toInt() * 7, 2) * H
                fill.color = if (i % 2 == 0) 0xFFFFF8E1.toInt() else 0xFFFFD54F.toInt(); fill.alpha = al(k)
                c.drawPath(Path().also { starPath(it, x, y, (6 + 10 * rnd(i, 5)) * s * k, 4, 0.25f) }, fill) }
            "BUTTERFLIES" -> for (i in 0 until 6) {
                val x = ((rnd(i, 1) + sec * (0.05f + 0.04f * rnd(i, 2))) % 1.2f - 0.1f) * W; val y = (0.2f + 0.6f * rnd(i, 3)) * H + sin(sec * 1.7f + i) * H * 0.08f
                c.save(); c.scale(if ((sec * 8 + i).toInt() % 2 == 0) 1f else 0.6f, 1f, x, y); emoji(c, "🦋", x, y, (28 + 16 * rnd(i, 4)) * s, al(1f)); c.restore() }
            "LANTERNS" -> for (i in 0 until 5) {
                val x = W * (0.1f + 0.2f * i); val len = H * (0.08f + 0.1f * rnd(i, 2)); val ang = sin(sec * 1.3f + i) * 8f
                c.save(); c.rotate(ang, x, 0f); stroke.color = 0xFFD4AF37.toInt(); stroke.strokeWidth = 2 * s; stroke.alpha = al(1f)
                c.drawLine(x, 0f, x, len, stroke); emoji(c, "🏮", x, len + H * 0.045f, H * 0.09f, al(1f)); c.restore() }
            "LIGHTS" -> for (i in 0 until 26) {
                val x = (rnd(i, 1) * W + sec * 12 * s * (rnd(i, 2) - 0.5f)) ; val y = rnd(i, 3) * H + sin(sec * 0.6f + i) * 12 * s; val r = (20 + 40 * rnd(i, 4)) * s
                val col = palette[i % palette.size]
                fill.shader = RadialGradient(x, y, r, intArrayOf(Color.argb(al(0.4f), Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
                c.drawCircle(x, y, r, fill); fill.shader = null }
            "C_BUTTERFLY", "C_CAT", "C_DOG", "C_HORSE", "C_BIRDS", "C_BEE", "C_FISH", "C_UNICORN", "C_SANTA", "C_PLANE", "C_CAR", "C_DUCKS", "C_BALLOON", "C_TURTLE" -> creature(c, key, sec, a)
            else -> if (key.isNotBlank()) for (i in 0 until 18) {  // مطر رموز مخصص
                val sp = (0.08f + 0.1f * rnd(i, 2)) * H; val y = ((rnd(i, 3) * (H + 60) + sp * sec) % (H + 60)) - 30; val x = rnd(i, 1) * W + sin(sec + i) * 20 * s
                emoji(c, key, x, y, (22 + 16 * rnd(i, 4)) * s, al(1f)) }
        }
        fill.alpha = 255; stroke.alpha = 255
    }

    /** كائنات متحركة تعبر أمام الفيديو (فراشة، قطة تجري، طيور…) */
    private fun creature(c: Canvas, key: String, sec: Float, a: Float) {
        val W = w.toFloat(); val H = h.toFloat()
        val al = (255 * a).toInt()
        fun cross(period: Float, off: Float = 0f) = W * 1.15f - W * 1.3f * (((sec / period) + off) % 1f)
        fun runner(e: String, size: Float, period: Float, speedBob: Float, off: Float = 0f, y0: Float = H - size * 0.48f) {
            val x = cross(period, off); val bob = abs(sin(sec * speedBob)) * size * 0.16f
            c.save(); c.rotate(sin(sec * speedBob * 2) * 5f, x, y0)
            // ظل
            fill.color = 0x33000000; c.drawOval(x - size * 0.35f, y0 + size * 0.38f, x + size * 0.35f, y0 + size * 0.48f, fill)
            emoji(c, e, x, y0 - bob, size, al); c.restore()
            // غبار خلف الجري
            fill.color = 0x55FFFFFF
            for (k in 1..3) { val d = ((sec * 6 + k) % 3f); fill.alpha = (85 * a * (1 - d / 3)).toInt(); c.drawCircle(x + size * 0.35f + d * size * 0.15f, y0 + size * 0.38f - d * 4 * s, size * 0.06f * (1 + d), fill) }
            fill.alpha = 255
        }
        when (key) {
            "C_BUTTERFLY" -> for (k in 0 until 2) {
                val per = 7f + k * 2f; val q = ((sec / per) + k * 0.5f) % 1f
                val x = W * 1.1f - W * 1.2f * q; val y = H * (0.35f + 0.25f * k) + sin(q * 14f + k) * H * 0.12f
                val flap = 0.35f + 0.65f * abs(cos(sec * 14f + k))
                c.save(); c.rotate(sin(q * 14f) * 12f, x, y); c.scale(flap, 1f, x, y); emoji(c, "🦋", x, y, H * (0.17f - 0.05f * k), al); c.restore()
            }
            "C_CAT" -> runner("🐈", H * 0.2f, 6f, 9f)
            "C_DOG" -> runner("🐕", H * 0.22f, 5.5f, 10f)
            "C_HORSE" -> runner("🐎", H * 0.28f, 5f, 7f)
            "C_UNICORN" -> {
                val size = H * 0.24f; val x = cross(6f); val y0 = H - size * 0.55f - abs(sin(sec * 6f)) * size * 0.2f
                val cols = intArrayOf(0xFFE53935.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(), 0xFF2196F3.toInt(), 0xFF9C27B0.toInt())
                stroke.strokeWidth = size * 0.05f; stroke.strokeCap = Paint.Cap.ROUND
                for (k in cols.indices) { stroke.color = cols[k]; stroke.alpha = (200 * a).toInt(); val yy = y0 - size * 0.12f + k * stroke.strokeWidth
                    c.drawPath(Path().apply { moveTo(x + size * 0.3f, yy); var xx = x + size * 0.3f; while (xx < x + W * 0.45f) { xx += 20 * s; lineTo(xx, yy + sin((xx - x) / (40 * s) - sec * 6) * 6 * s) } }, stroke) }
                stroke.strokeCap = Paint.Cap.BUTT; stroke.alpha = 255
                emoji(c, "🦄", x, y0, size, al)
            }
            "C_BIRDS" -> for (k in 0 until 4) {
                val x = cross(8f, k * 0.06f) + k * 50 * s; val y = H * 0.16f + k % 2 * H * 0.06f + sin(sec * 2 + k) * H * 0.02f
                c.save(); c.scale(1f, if ((sec * 7 + k).toInt() % 2 == 0) 1f else 0.7f, x, y); emoji(c, "🐦", x, y, H * 0.08f, al); c.restore()
            }
            "C_BEE" -> {
                val x = cross(7f); val y = H * 0.45f + sin(sec * 9f) * H * 0.06f + sin(sec * 1.3f) * H * 0.15f
                stroke.color = 0x66FFFFFF; stroke.strokeWidth = 2 * s; stroke.pathEffect = DashPathEffect(floatArrayOf(6 * s, 6 * s), 0f)
                c.drawPath(Path().apply { moveTo(x, y); for (k in 1..20) { val t2 = sec - k * 0.04f; lineTo(x + k * W * 1.3f / 7f * 0.04f, H * 0.45f + sin(t2 * 9f) * H * 0.06f + sin(t2 * 1.3f) * H * 0.15f) } }, stroke)
                stroke.pathEffect = null; emoji(c, "🐝", x, y, H * 0.09f, al)
            }
            "C_FISH" -> for (k in 0 until 3) {
                val x = cross(9f + k * 2, k * 0.33f); val y = H * (0.3f + 0.2f * k) + sin(sec * 2 + k) * H * 0.04f
                c.save(); c.rotate(sin(sec * 6 + k) * 6f, x, y); emoji(c, if (k == 1) "🐟" else "🐠", x, y, H * 0.1f, al); c.restore()
                stroke.color = Color.WHITE; stroke.strokeWidth = 1.5f * s
                for (b in 0 until 3) { val ph = (sec * 0.8f + b * 0.33f + k) % 1f; stroke.alpha = (200 * a * (1 - ph)).toInt(); c.drawCircle(x - H * 0.06f, y - ph * H * 0.15f, (3 + 4 * ph) * s, stroke) }
                stroke.alpha = 255
            }
            "C_SANTA" -> {
                val x = cross(9f); val y = H * 0.2f + sin(sec * 1.5f) * H * 0.04f; val sz = H * 0.09f
                particles(c, "SPARKLES", sec, a * 0.6f, 21)
                emoji(c, "🦌", x, y, sz, al); emoji(c, "🦌", x + sz * 0.9f, y + sz * 0.1f, sz, al); emoji(c, "🛷", x + sz * 2f, y + sz * 0.25f, sz * 1.1f, al); emoji(c, "🎅", x + sz * 2f, y - sz * 0.15f, sz * 0.8f, al)
                stroke.color = 0xFF8D6E63.toInt(); stroke.strokeWidth = 1.5f * s; c.drawLine(x + sz * 0.3f, y, x + sz * 1.6f, y + sz * 0.2f, stroke)
            }
            "C_PLANE" -> {
                val x = cross(8f); val y = H * 0.22f + sin(sec) * H * 0.03f
                stroke.strokeCap = Paint.Cap.ROUND
                for (k in 1..12) { stroke.color = Color.WHITE; stroke.alpha = (160 * a * (1 - k / 12f)).toInt(); stroke.strokeWidth = (10 - k * 0.5f) * s; c.drawPoint(x + H * 0.06f + k * 14 * s, y + sin(sec * 3 + k * 0.5f) * 2 * s, stroke) }
                stroke.strokeCap = Paint.Cap.BUTT; stroke.alpha = 255
                c.save(); c.scale(-1f, 1f, x, y); c.rotate(45f, x, y); emoji(c, "✈️", x, y, H * 0.11f, al); c.restore()
            }
            "C_CAR" -> { val sz = H * 0.16f; runner("🚗", sz, 4.5f, 18f) }
            "C_DUCKS" -> for (k in 0 until 4) { val sz = H * (if (k == 0) 0.13f else 0.09f); val x = cross(10f) + k * sz * 0.95f; val y0 = H - sz * 0.5f - abs(sin(sec * 5 + k)) * sz * 0.08f
                c.save(); c.rotate(sin(sec * 10 + k) * 6f, x, y0); emoji(c, if (k == 0) "🦆" else "🐤", x, y0, sz, al); c.restore() }
            "C_TURTLE" -> { val sz = H * 0.13f; val x = cross(16f); val y0 = H - sz * 0.5f; c.save(); c.rotate(sin(sec * 4) * 3f, x, y0); emoji(c, "🐢", x, y0, sz, al); c.restore() }
            "C_BALLOON" -> {
                val q = (sec / 10f) % 1f; val x = W * 0.2f + sin(sec * 0.7f) * W * 0.1f + q * W * 0.4f; val y = H * 1.15f - H * 1.35f * q
                emoji(c, "🎈", x, y, H * 0.2f, al)
            }
        }
    }

    // ---------------- الإطارات ----------------
    private fun frame(c: Canvas, key: String, sec: Float, a: Float) {
        val W = w.toFloat(); val H = h.toFloat()
        val l = c.saveLayerAlpha(0f, 0f, W, H, (255 * a).toInt())
        val m = 14 * s
        fun corners(e: List<String>, size: Float = H * 0.13f) {
            emoji(c, e[0], size * 0.55f, size * 0.55f, size); emoji(c, e[1 % e.size], W - size * 0.55f, size * 0.55f, size)
            emoji(c, e[2 % e.size], size * 0.55f, H - size * 0.55f, size); emoji(c, e[3 % e.size], W - size * 0.55f, H - size * 0.55f, size)
        }
        fun alongBorder(step: Float, f: (Float, Float, Int) -> Unit) {
            var k = 0; var x = step / 2; while (x < W) { f(x, m * 1.4f, k++); f(x, H - m * 1.4f, k++); x += step }
            var y = step * 1.5f; while (y < H - step) { f(m * 1.4f, y, k++); f(W - m * 1.4f, y, k++); y += step }
        }
        when (key) {
            "GOLD" -> {
                stroke.shader = LinearGradient(0f, 0f, W, H, intArrayOf(0xFFF9E79F.toInt(), 0xFFD4AF37.toInt(), 0xFF8C6D1F.toInt(), 0xFFF9E79F.toInt()), null, Shader.TileMode.MIRROR)
                stroke.strokeWidth = 12 * s; c.drawRect(m, m, W - m, H - m, stroke)
                stroke.strokeWidth = 3 * s; c.drawRect(m * 2.6f, m * 2.6f, W - m * 2.6f, H - m * 2.6f, stroke)
                fill.shader = stroke.shader
                for ((x, y) in listOf(m * 2.6f to m * 2.6f, W - m * 2.6f to m * 2.6f, m * 2.6f to H - m * 2.6f, W - m * 2.6f to H - m * 2.6f)) c.drawPath(Path().also { starPath(it, x, y, 16 * s, 4, 0.4f) }, fill)
                stroke.shader = null; fill.shader = null
            }
            "FLOWERS" -> { stroke.color = 0xFFF48FB1.toInt(); stroke.strokeWidth = 4 * s; c.drawRoundRect(m, m, W - m, H - m, 20 * s, 20 * s, stroke); corners(listOf("🌸", "🌺", "🌷", "🌼")) }
            "HEARTS" -> alongBorder(46 * s) { x, y, k -> fill.color = if (k % 2 == 0) 0xFFE91E63.toInt() else 0xFFFF80AB.toInt(); c.drawPath(Path().also { heartPath(it, x, y, (20 + 4 * sin(sec * 4 + k)) * s) }, fill) }
            "STARS" -> alongBorder(50 * s) { x, y, k -> fill.color = if (k % 2 == 0) 0xFFFFD54F.toInt() else Color.WHITE; fill.alpha = (150 + 105 * abs(sin(sec * 2 + k))).toInt(); c.drawPath(Path().also { starPath(it, x, y, 12 * s) }, fill); fill.alpha = 255 }
            "KIDS" -> {
                stroke.strokeWidth = 14 * s; stroke.strokeCap = Paint.Cap.ROUND
                val seg = 40 * s; var k = 0
                fun edge(x1: Float, y1: Float, x2: Float, y2: Float) { val len = hypot(x2 - x1, y2 - y1); var d = 0f
                    while (d < len) { val e = min(len, d + seg * 0.6f); stroke.color = palette[k++ % palette.size]; c.drawLine(x1 + (x2 - x1) * d / len, y1 + (y2 - y1) * d / len, x1 + (x2 - x1) * e / len, y1 + (y2 - y1) * e / len, stroke); d += seg } }
                edge(m, m, W - m, m); edge(W - m, m, W - m, H - m); edge(W - m, H - m, m, H - m); edge(m, H - m, m, m)
                stroke.strokeCap = Paint.Cap.BUTT
                corners(listOf("🧸", "🎈", "🌈", "⭐"), H * 0.12f)
            }
            "FILM" -> {
                val bh = H * 0.09f; fill.color = Color.BLACK; c.drawRect(0f, 0f, W, bh, fill); c.drawRect(0f, H - bh, W, H, fill)
                fill.color = 0xFFDDDDDD.toInt(); val hs = bh * 0.38f; var x = 10 * s
                while (x < W) { c.drawRoundRect(x, (bh - hs) / 2, x + hs * 1.3f, (bh + hs) / 2, 3 * s, 3 * s, fill); c.drawRoundRect(x, H - (bh + hs) / 2, x + hs * 1.3f, H - (bh - hs) / 2, 3 * s, 3 * s, fill); x += hs * 2.6f }
            }
            "VINTAGE" -> {
                fill.shader = RadialGradient(W / 2, H / 2, hypot(W, H) * 0.6f, intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, 0xCC000000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, W, H, fill); fill.shader = null
                fill.color = 0x18FFB74D; c.drawRect(0f, 0f, W, H, fill)
                val fr = (sec * 24).toInt(); fill.color = 0x40FFFFFF
                for (i in 0 until 60) c.drawCircle(rnd(i, fr) * W, rnd(i, fr + 1) * H, 1.2f * s, fill)
                if (fr % 11 == 0) { stroke.color = 0x30FFFFFF; stroke.strokeWidth = 1.5f * s; val x = rnd(fr, 3) * W; c.drawLine(x, 0f, x + 4 * s, H, stroke) }
            }
            "XMAS" -> {
                stroke.color = 0xFF2E7D32.toInt(); stroke.strokeWidth = 3 * s
                val wire = Path().apply { moveTo(0f, H * 0.03f); quadTo(W * 0.25f, H * 0.12f, W * 0.5f, H * 0.04f); quadTo(W * 0.75f, H * 0.12f, W, H * 0.03f) }
                c.drawPath(wire, stroke)
                val pm = PathMeasure(wire, false); val pos = FloatArray(2); val n = 16
                for (k in 0 until n) { pm.getPosTan(pm.length * (k + 0.5f) / n, pos, null); val on = ((sec * 3).toInt() + k) % 2 == 0
                    fill.color = palette[k % 5]; fill.alpha = if (on) 255 else 110; c.drawOval(pos[0] - 6 * s, pos[1], pos[0] + 6 * s, pos[1] + 16 * s, fill)
                    if (on) { fill.shader = RadialGradient(pos[0], pos[1] + 8 * s, 22 * s, intArrayOf(Color.argb(90, Color.red(palette[k % 5]), Color.green(palette[k % 5]), Color.blue(palette[k % 5])), Color.TRANSPARENT), null, Shader.TileMode.CLAMP); c.drawCircle(pos[0], pos[1] + 8 * s, 22 * s, fill); fill.shader = null } }
                fill.alpha = 255; fill.color = Color.WHITE
                c.drawPath(Path().apply { moveTo(0f, H); lineTo(0f, H * 0.94f); var x = 0f; while (x < W) { quadTo(x + 30 * s, H * 0.9f, x + 60 * s, H * 0.94f); x += 60 * s }; lineTo(W, H); close() }, fill)
                emoji(c, "🎄", H * 0.1f, H * 0.86f, H * 0.18f); emoji(c, "🎅", W - H * 0.1f, H * 0.86f, H * 0.16f)
            }
            "RAMADAN" -> {
                stroke.color = 0xFFD4AF37.toInt(); stroke.strokeWidth = 3 * s; c.drawRect(m, m, W - m, H - m, stroke)
                for (i in 0 until 4) { val x = W * (0.14f + 0.24f * i); val len = H * (0.06f + 0.05f * (i % 2)); c.save(); c.rotate(sin(sec * 1.4f + i) * 7f, x, 0f); c.drawLine(x, 0f, x, len, stroke); emoji(c, "🏮", x, len + H * 0.04f, H * 0.08f); c.restore() }
                emoji(c, "🌙", W - H * 0.1f, H * 0.12f, H * 0.14f)
                fill.color = 0xFFFFF59D.toInt(); for (i in 0 until 6) { fill.alpha = (120 + 135 * abs(sin(sec * 2 + i))).toInt(); c.drawPath(Path().also { starPath(it, W * (0.55f + 0.06f * i), H * (0.06f + 0.05f * (i % 2)), 6 * s) }, fill) }; fill.alpha = 255
            }
            "WEDDING" -> {
                stroke.color = Color.WHITE; stroke.strokeWidth = 5 * s; c.drawRoundRect(m, m, W - m, H - m, 26 * s, 26 * s, stroke)
                stroke.strokeWidth = 2 * s; c.drawRoundRect(m * 2.2f, m * 2.2f, W - m * 2.2f, H - m * 2.2f, 20 * s, 20 * s, stroke)
                emoji(c, "💍", W / 2, m * 2.4f, H * 0.08f); emoji(c, "🕊️", H * 0.1f, H - H * 0.1f, H * 0.12f); emoji(c, "🕊️", W - H * 0.1f, H - H * 0.1f, H * 0.12f)
            }
            "BIRTHDAY" -> {
                stroke.color = 0xFF795548.toInt(); stroke.strokeWidth = 2 * s
                val line = Path().apply { moveTo(0f, H * 0.02f); quadTo(W / 2, H * 0.14f, W, H * 0.02f) }; c.drawPath(line, stroke)
                val pm = PathMeasure(line, false); val p1 = FloatArray(2); val p2 = FloatArray(2); val n = 14
                for (k in 0 until n) { pm.getPosTan(pm.length * k / n, p1, null); pm.getPosTan(pm.length * (k + 1) / n, p2, null)
                    fill.color = palette[k % palette.size]; val sw = sin(sec * 3 + k) * 3 * s
                    c.drawPath(Path().apply { moveTo(p1[0], p1[1]); lineTo(p2[0], p2[1]); lineTo((p1[0] + p2[0]) / 2 + sw, (p1[1] + p2[1]) / 2 + H * 0.07f); close() }, fill) }
                emoji(c, "🎈", H * 0.08f, H * 0.82f, H * 0.16f); emoji(c, "🎂", W - H * 0.1f, H * 0.86f, H * 0.14f)
            }
            "NEON" -> {
                val k = 0.6f + 0.4f * abs(sin(sec * 2.5f))
                stroke.strokeWidth = 6 * s; stroke.color = 0xFF18FFFF.toInt(); stroke.alpha = (255 * k).toInt(); stroke.setShadowLayer(18 * s, 0f, 0f, 0xFF18FFFF.toInt())
                c.drawRoundRect(m, m, W - m, H - m, 24 * s, 24 * s, stroke)
                stroke.color = 0xFFFF4081.toInt(); stroke.alpha = (255 * (1.6f - k)).toInt().coerceIn(0, 255); stroke.setShadowLayer(18 * s, 0f, 0f, 0xFFFF4081.toInt())
                c.drawRoundRect(m * 2.4f, m * 2.4f, W - m * 2.4f, H - m * 2.4f, 18 * s, 18 * s, stroke)
                stroke.clearShadowLayer(); stroke.alpha = 255
            }
            "BOOK" -> {
                fill.color = 0xFFF5EBDD.toInt(); val b = 22 * s
                c.drawRect(0f, 0f, W, b, fill); c.drawRect(0f, H - b, W, H, fill); c.drawRect(0f, 0f, b, H, fill); c.drawRect(W - b, 0f, W, H, fill)
                fill.color = 0xB3E8D5A8.toInt()
                for ((x, y, r) in listOf(Triple(b * 2f, b * 1.5f, -35f), Triple(W - b * 2f, b * 1.5f, 35f), Triple(b * 2f, H - b * 1.5f, 35f), Triple(W - b * 2f, H - b * 1.5f, -35f))) {
                    c.save(); c.rotate(r, x, y); c.drawRect(x - 40 * s, y - 11 * s, x + 40 * s, y + 11 * s, fill); c.restore() }
            }
        }
        c.restoreToCount(l)
    }
}
