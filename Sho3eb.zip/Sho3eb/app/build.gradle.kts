import java.util.Properties
import java.util.zip.GZIPOutputStream
import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

// ===== خادم التواصل (اختياري): supabase.properties في جذر المستودع =====
val supaProps = Properties().apply { rootProject.file("supabase.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) } }

// ===== نسخة المشاركة: تُفعّل بـ -Pedition=true عند وجود edition/edition.json =====
val editionDir = rootProject.file("edition")
val editionOn = (project.findProperty("edition")?.toString() == "true") && File(editionDir, "edition.json").exists()
@Suppress("UNCHECKED_CAST")
val editionCfg: Map<String, Any?> = if (editionOn) (groovy.json.JsonSlurper().parse(File(editionDir, "edition.json"), "UTF-8") as Map<String, Any?>) else emptyMap()
val editionName: String = (editionCfg["name"] as? String)?.takeIf { it.isNotBlank() } ?: "Sho3eb"
// نسخة إضافية مستقلة على نفس الهاتف (برقم وبريد مختلفين): -Pcopy=2 أو 3…
val copyNo: Int = project.findProperty("copy")?.toString()?.toIntOrNull()?.takeIf { it in 2..9 } ?: 0
val editionSuffix: String = (editionCfg["idSuffix"] as? String)?.filter { it.isLetterOrDigit() }?.lowercase()?.takeIf { it.isNotBlank() } ?: "shared"
val editionIcon = File(editionDir, "icon.png")
val editionRes = layout.buildDirectory.dir("generated/edition_res").get().asFile
if (editionOn && editionIcon.exists()) {
    File(editionRes, "drawable-nodpi").mkdirs()
    editionIcon.copyTo(File(editionRes, "drawable-nodpi/edition_icon.png"), overwrite = true)
}

// ===== نص المصحف مضمّن داخل التطبيق: يُجلب مرة واحدة أثناء البناء =====
val quranAssets = layout.buildDirectory.dir("generated/quran_assets").get().asFile
val fetchQuran = tasks.register("fetchQuran") {
    outputs.dir(quranAssets)
    outputs.upToDateWhen { File(quranAssets, "quran/quran-uthmani.json.gz").let { it.exists() && it.length() > 200_000 } }
    doLast {
        val f = File(quranAssets, "quran/quran-uthmani.json.gz")
        if (f.exists() && f.length() > 200_000) return@doLast
        f.parentFile.mkdirs()
        try {
            val c = URI("https://api.alquran.cloud/v1/quran/quran-uthmani").toURL().openConnection()
            c.connectTimeout = 30_000; c.readTimeout = 180_000
            c.setRequestProperty("User-Agent", "Sho3eb-build")
            c.getInputStream().use { i -> GZIPOutputStream(f.outputStream()).use { o -> i.copyTo(o) } }
            println("Quran text bundled: " + f.length() + " bytes")
        } catch (e: Exception) { println("Quran fetch skipped: " + e.message); f.delete() }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchQuran) }

android {
    namespace = "com.sho3eb.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sho3eb.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        vectorDrawables { useSupportLibrary = true }
        buildConfigField("String", "SUPABASE_URL", "\"" + (supaProps.getProperty("SUPABASE_URL") ?: "").trim() + "\"")
        buildConfigField("String", "SUPABASE_KEY", "\"" + (supaProps.getProperty("SUPABASE_ANON_KEY") ?: "").trim() + "\"")
        resValue("string", "app_name_c1", (editionName + " 1").replace("'", "\\'").replace("\"", "\\\""))
        resValue("string", "app_name_c2", (editionName + " 2").replace("'", "\\'").replace("\"", "\\\""))
        resValue("string", "app_name", (editionName + if (copyNo > 0) " $copyNo" else "").replace("'", "\\'").replace("\"", "\\\""))
        val iconRef = if (editionOn && editionIcon.exists()) "@drawable/edition_icon" else "@mipmap/ic_launcher"
        manifestPlaceholders["appIcon"] = iconRef
        manifestPlaceholders["appRoundIcon"] = if (editionOn && editionIcon.exists()) "@drawable/edition_icon" else "@mipmap/ic_launcher_round"
        if (editionOn) applicationIdSuffix = ".$editionSuffix"
        if (copyNo > 0) applicationIdSuffix = (if (editionOn) ".$editionSuffix" else "") + ".copy$copyNo"
        buildConfigField("int", "COPY_NO", copyNo.toString())
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // موقّع بمفتاح التطوير حتى يمكن تثبيته مباشرة. للنشر على Google Play استخدم مفتاحك الخاص.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; resValues = true; buildConfig = true }
    sourceSets["main"].apply {
        assets.srcDir(quranAssets)
        if (editionOn) {
            assets.srcDir(editionDir)
            if (editionIcon.exists()) res.srcDir(editionRes)
        }
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.3")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-effect:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
